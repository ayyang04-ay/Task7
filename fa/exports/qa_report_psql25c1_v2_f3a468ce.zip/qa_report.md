# Taiga QA report — Task psql25c1 (v2)

| | |
|---|---|
| Problem | `task_4ce55343502b4d17b2182158ad6e4533` |
| Problem version | `f3a468ce-76f6-4e1c-a20f-16a611cf5541` (v2) |
| Created | 2026-11-12 20:17 UTC by taygeta.alniyat.azmidi@mercor.expert |
| Tags | In Development |
| Environment | vert_bio_v001_MER (`2e3eb299-7d22-4082-be2e-180e73ccf90d`) |
| Auto-QA | enabled |
| Latest QA chain | completed at 2026-11-13 08:17 UTC |
| QA freshness | fresh — QA ran against this version (latest QA run 2026-11-13 04:21 UTC) |
| Eval runs | 16 / 16 completed |
| Exported | 2026-11-13 16:31 UTC via Anton Internal Tooling /tasks |

## Summary

9 findings across 7 QA runs.

| Check | Findings |
|---|---|
| ClaudeScope (transcripts health report) | 4 |
| Data quality | 1 |
| Env linter | 2 |
| Problem linter | 2 |

## Findings by check type

### ClaudeScope (transcripts health report) — 4

#### [error] moderate_contradictory_ground_truth_framing_vs_seeded_data_defects

The prompt tells the agent the dataset "serves as ground truth," but the workbook is seeded with many internal contradictions. Examples include: an exact duplicate survival block presented as a different experiment (S06-C ≡ S06-D); body-weight trajectories copied across experiments with integer parts edited; rotated group labels that invert the Th1/Th2 reading; a mislabelled timepoint; a flow block 35% copied from another; survival records that contradict their own weight records; deaths among unchallenged controls; and an MHC-mismatched tetramer readout. A literal reading of "ground truth" conflicts with the evident unreliability of the records, so agents must choose for themselves whether to trust, exclude or flag the data. This is likely an intentional test of integrity judgment. Even so, the explicit framing is contradictory, and the number and contrived nature of the planted defects (15–23 findings per run) exceed what real preclinical packages typically contain. Include interactions where the agent explicitly had to reconcile the "ground truth" instruction with internal data contradictions.

_runs: 3e85dbd2, a078ba5e, caffc26d, cd72221b, dcee42be, fe37920b · found: 2026-11-13 04:26 UTC_

#### [warning] minor_fragmented_python_deps_and_missing_basic_cli

Common libraries and utilities are missing from the default interpreter or scattered inconsistently across conda envs:
- openpyxl and pandas are absent from base Python and from the `core` env;
- lifelines is only in `core`;
- pypdf is only in `genomics`;
- pandoc is in some envs but not others;
- standard CLIs `file` and `unzip` are not installed, and `pip` was missing in at least one run.

Agents must probe envs and build multi-env pipelines, for example extracting in one env and doing statistics in another, to combine Excel reading with survival analysis. Every run worked around this at modest time cost. The system prompt signals that tools live inside envs, so this is partly by design. However, the absence of the openpyxl/lifelines combination in any single env, and of basic coreutils-adjacent CLIs, is a genuine dependency gap.

_runs: 3e85dbd2 · found: 2026-11-13 04:26 UTC_

#### [warning] minor_grader_reasoning_truncated_in_metadata

The grading result was produced and a score recorded, but the grader's reasoning field is missing from the stored metadata (marked "1/5 fields omitted"). This is a logging or serialisation truncation rather than a grading failure. The score itself is present and plausible, but the justification cannot be audited downstream. Flag runs whose grading metadata shows omitted or truncated reasoning fields despite a valid score.

_runs: fe37920b · found: 2026-11-13 04:26 UTC_

#### [warning] minor_missing_document_rendering_tools

The image has no tool to render or rasterise generated documents: no LibreOffice, LaTeX or PDF engine, poppler (pdftoppm/pdfinfo), ghostscript, mutool, PyMuPDF or headless browser. pdf2image is installed without its poppler binaries and fails with PDFInfoNotInstalledError. As a result, agents can produce PDF, DOCX or HTML reports but cannot visually QA them. Agents work around this with text round-trips, XML or structure inspection, or custom reportlab converters, and often tell the user the output was not visually checked. This appears in nearly every run, but deliverables are still produced and the task's core analysis does not depend on rendering, so impact is low. Flag runs where the agent explicitly hits or reports this gap. Do not flag failed attempts to pip-install a renderer; those are blocked by the documented lack of internet.

_runs: 42462321, 5701d39b, dcee42be · found: 2026-11-13 04:26 UTC_

### Data quality — 1

#### [info] undisclosed_constraints: The grader requires the recommendation be grounded specifically in heterosubtypi

The task asks for a defensible recommendation grounded in the data with attention to what drives protection; grounding the advance/no-advance call in challenge (protection) data rather than antibody titres is a standard scientific inference the agent is expected to derive from the data, not an undisclosed formatting or procedural constraint.

_discipline: non_technical · failure mode: undisclosed_constraints · found: 2026-11-13 04:26 UTC_

### Env linter — 2

#### [warning] Prompt calls the workbook 'ground truth' but the grader expects some seeded data defects to be set aside, and grading of audit-led answers is inconsistent

The task prompt says: "All analysis and recommendations should be grounded in our data, which serves as ground truth." The grader guidance, however, gives credit for departing from the data as recorded. It expects S06-D to be collapsed into S06-C because all 28 records are identical. It expects the S06-E/F labels printed twice (rows 32-33 and rows 69-70) to be separated, and the S09-A values to be read as log10. The workbook also has further defects that the guidance does not address, such as deaths in S06-G's unvaccinated, unchallenged aged arm (3/7). Because of the 'ground truth' wording, the prompt does not say whether the response should audit the data or accept it as given.

The stored runs show graders acting on that ambiguity in opposite directions:
- Run 3e85dbd2 (score 0.50) recommended 'no/hold'. Its grader docked the recommendation item partly because the case was "driven mainly by the integrity audit, even though the user said to treat the data as ground truth". That penalty is not in the guidance.
- Run 5701d39b (score 0.79) also gave an audit-heavy 'no/gated' answer. Its grader gave the recommendation item full credit.
- Of the 8 stored runs I read, 3e85dbd2 is the only one whose grader cited 'ground truth' against the answer.

This re-verifies an earlier unreviewed finding on an older version of this problem. I did not run a matched pair of constructed hand-ins (identical except for the audit framing) before the time limit. The evidence is the two stored gradings.

Fix:
- Reword the prompt so that it does not call the data 'ground truth', or say plainly that the package may contain recording errors that should be identified and handled.
- Add a line to the grader guidance saying whether a data-integrity audit is credited, neutral or penalised as the basis of the recommendation.

_fix: env_author · discipline: non_technical · failure mode: prompt_ambiguity · runs: 3e85dbd2, 5701d39b · found: 2026-11-13 08:17 UTC_

#### [info] Grader guidance Section C names an 'S10-A block holding S03-E content' that the current workbook does not contain

Section C of the grader guidance lists as neutral noticing "the S10-A block holding S03-E content". In the current /tmp/world/filesystem/adjuvant_program_dataset.xlsx:
- S10-A holds Ifnb1, Tnf and Isg15 values for PBS, Sham, PSLN-344 and CT. This matches the annotation PDF's description of S10-A.
- S03-E values appear only in their own S03 block (rows 10-14).
I checked this by dumping the whole workbook to TSV in a fresh container and comparing it with the PDF text. The guidance line therefore describes a defect that no longer exists, and a grader could credit or discuss a non-existent anomaly.

A related mismatch, which I noticed but did not verify in depth: the annotation describes S03-G as HAI after challenge with PSLN-212Y/Sham/PSLN-344Y, n=8. The workbook's S03-G block has 5 groups with n=5.

Fix: delete the stale Section C line or correct it to match the workbook, and check S03-G's annotation against the workbook.

_fix: env_author · discipline: non_technical · failure mode: context_rubric_mismatch · found: 2026-11-13 08:17 UTC_

### Problem linter — 2

#### [warning] PSLN-344: grader guidance scores only the comparator of the per-study endpoints/populations/comparators/readouts/timing the prompt asks for

### Problem
The task prompt's forward-view section asks: "What would the next studies have to establish, and for each one, what are the endpoints, populations, comparators, readouts and timing?" and "Is there a biomarker of efficacy worth carrying forward, could it go into patients, and in what role?". Of the five attributes the prompt asks for on each study, `grader_guidance` scores only the comparator, in A(7): "a next-study comparator set that is age-matched rather than young". The other forward-view items credit naming what to study, not how the study is designed: A(8) "the antigen-dose comparison the package cannot answer, named as something the next studies must establish" and A(11) "resolution kinetics proposed as work rather than inventoried as a caveat". B(1) touches study design only as a penalty, for powering on antibody titre. No A or B item asks for endpoints, populations, readouts or timing. Section C makes "number of studies proposed" neutral. The biomarker item, A(9) "a biomarker answer that separates what is peripherally accessible from what is not", says nothing about the role the prompt asks about.

### Evidence
Under the guidance as written, a response that lists its next studies as bare topics (antigen dose, resolution kinetics) with an age-matched comparator meets every A item on the forward view. It avoids every B item, so it gets the same credit as a response that gives full endpoints, populations, readouts and timing for each study. The guidance calls its list "thirteen separately scored items" and says "Grade content for presence and correctness only". Nothing in it tells the grader to score the study-design detail the prompt asks for.

### Verification method
Static analysis of the problem-version record: the task prompt and `agentic_grader_params.grader_guidance`. This version has no runs, so no grading shows how a real grader weighs the missing detail.

### Recommendation
Add an A item that credits each proposed next study for stating its endpoints, population, comparator, readouts and timing. Also credit a stated role for any biomarker carried forward. If the author does not mean to grade study design, cut the prompt question down to what is graded ("What would the next studies have to establish?"). After-fix check: (a) the grader's reasoning on a response whose studies give no readouts or timing should name the new item as unmet; (b) a response with full study designs should still meet A(7), A(8) and A(11) as before.

_fix: env_author · discipline: non_technical · failure mode: instruction_following_not_graded · found: 2026-11-12 20:23 UTC_

#### [info] PSLN-344: grader guidance leaves the scope of its number-reproduction rule, A(6)'s 'before', and the S09-A later-timepoint premise undefined

### Problem
Three clauses in `grader_guidance` leave scoring conditions open to more than one reading:
1. Section A ends: "Each item is met only where the attempt's own cited numbers reproduce from the mounted files by the route it states". Several A items carry no number: (1) "a recommendation on whether to advance", (7) the comparator set, (8) the antigen-dose comparison and (11) resolution kinetics. The clause can be read as not applying to them, or as failing them because no number backs them. It also does not say whether one figure that fails to reproduce voids only the item it supports, or what precision counts as reproducing.
2. A(6) requires "the direction of each endpoint established before any pooling or averaging". The opening says "Do not grade where in the answer anything sits or in what order it appears". "Before" can be read as order in the answer, which the opening forbids grading. The intended reading is probably analytic order, and B(5) already penalises pooling without reorientation.
3. B(2) treats the timepoint of the second S09-A block as open ("does not depend on which timepoint the second block is taken to be"). A(11) and B(3) treat "the elevation at the later timepoint" as settled. The guidance does not say whether A(11) still applies to a response that reads that block as a different timepoint.

### Verification method
Static analysis of the record text only. I could not check without container access whether the S09-A sheet's timepoint labelling is actually ambiguous.

### Recommendation
Say which A items the reproduction clause applies to, and what counts as reproducing (for example, a match to the precision the response reports). Reword A(6) as each endpoint's direction "stated and applied wherever endpoints are pooled or averaged". State whether A(11) applies however the second S09-A block's timepoint is read.

_fix: env_author · discipline: non_technical · found: 2026-11-12 20:23 UTC_

## QA runs

### Env linter — completed, 2026-11-13 08:17 UTC

_findings: 2 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Task & domain issues — The prompt tells the user to treat the workbook as "ground truth". The grader guidance expects some seeded recording errors to be set aside, including the duplicated S06-D, the reused S06-E/F labels and the log10 S09-A values. Stored gradings handle audit-driven answers inconsistently: one 'no' answer was docked for "not treating the data as ground truth" and another was fully credited (warning). Separately, one grader-guidance line refers to an "S10-A block holding S03-E content" that the current workbook does not contain (info).

### Reward hacking — completed, 2026-11-13 06:31 UTC

_findings: 0 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

No issues found.

### Data quality — completed, 2026-11-13 04:26 UTC

_findings: 1 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Scanned 1 problems with input files. 1 candidate findings; 0 passed gate (→ env_linter).

### ClaudeScope (transcripts health report) — completed, 2026-11-13 04:26 UTC

_findings: 4 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

ClaudeScope analysis completed: 8 clusters identified

### Difficulty — completed, 2026-11-12 23:41 UTC

_findings: 0 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

0 immediate findings

### Difficulty — completed, 2026-11-12 22:01 UTC

_findings: 0 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

0 immediate findings

### Problem linter — completed, 2026-11-12 20:23 UTC

_findings: 2 · triggered by: taygeta.alniyat.azmidi@mercor.expert_

Static review of PSLN-344 (problem version f3a468ce-76f6-4e1c-a20f-16a611cf5541): a container task (anton-omni image) graded by an agentic grader in single_score mode, with bash and the mounted input files. The prompt is realistic, clear and not overscripted. There are no hints or suffix, no authored time budget and no safety concern. The grader guidance is detailed and problem-specific, and it requires the response's cited numbers to reproduce from the mounted files, which the grader's bash access makes checkable. Two issues: (warning, consistency) the prompt asks for endpoints, populations, comparators, readouts and timing for each proposed next study, plus the biomarker's role, but the guidance scores only the comparator (A7); (info, grading) the guidance leaves unclear the scope and tolerance of its number-reproduction rule, whether A(6)'s 'before' means order in the answer, and whether A(11) applies when the S09-A second block's timepoint is read differently. No runs exist for this version, so nothing was checked against real gradings.


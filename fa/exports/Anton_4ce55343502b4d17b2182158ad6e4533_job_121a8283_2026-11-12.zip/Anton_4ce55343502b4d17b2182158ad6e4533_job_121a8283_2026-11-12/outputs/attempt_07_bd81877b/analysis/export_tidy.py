"""Export every parsed block to tidy CSVs with cell-level provenance (run in an env that has openpyxl)."""
import csv, json
from blocks import BLOCKS
from bw_recon import classify

def norm_x(x):
    if isinstance(x, str):
        xs = x.strip()
        try: return float(xs) if '.' in xs else int(xs)
        except ValueError: return xs
    return x

with open('tidy_values.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['block', 'sheet', 'label_as_printed', 'kind', 'group', 'x', 'value', 'cell', 'stated_n'])
    for bid, b in BLOCKS.items():
        if b['kind'] == 'rep':
            for g in b['groups']:
                for val, cell in b['data'][g]: w.writerow([bid, b['sheet'], b['label'], 'rep', g, '', val, cell, b['stated_n']])
        elif b['kind'] == 'tc':
            for g in b['groups']:
                for x, vv in b['data'][g].items():
                    for val, cell in vv: w.writerow([bid, b['sheet'], b['label'], 'tc', g, norm_x(x), val, cell, b['stated_n']])
with open('tidy_survival.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['block', 'sheet', 'label_as_printed', 'conditions', 'group', 'day', 'event', 'cell_day', 'cell_flag', 'stated_n', 'horizon'])
    for bid, b in BLOCKS.items():
        if b['kind'] == 'surv':
            for g in b['groups']:
                for day, ev, cd, cf in b['data'][g]: w.writerow([bid, b['sheet'], b['label'], b['cond'], g, '' if day is None else day, ev, cd, cf, b['stated_n'], b['horizon']])
with open('tidy_bodyweight.csv', 'w', newline='') as f:
    w = csv.writer(f); w.writerow(['block', 'sheet', 'label_as_printed', 'paired_survival_block', 'group', 'animal_col', 'day', 'value', 'cell', 'series_status', 'real_last_day', 'is_carried_forward'])
    for bid, b in BLOCKS.items():
        if b['kind'] == 'bw':
            import re
            for g in b['groups']:
                r1 = int(re.match(r'.*![A-Z]+(\d+):', b['range'][g]).group(1))
                for a, ser in b['data'][g].items():
                    c = classify(ser)
                    for i, (d, val) in enumerate(ser.items()):
                        cf = (c['status'] == 'locf' and d > c['real_last_day'])
                        w.writerow([bid, b['sheet'], b['label'], b.get('pair') or '', g, a, d, '' if val is None else val, f'{a}{r1+i}', c['status'], c['real_last_day'], int(cf)])
meta = {bid: dict(sheet=b['sheet'], label=b['label'], kind=b['kind'], groups=b['groups'], range=b['range'], stated_n=b['stated_n'],
                  cond=b.get('cond', ''), pair=b.get('pair'), horizon=b.get('horizon'), note=b.get('note', '')) for bid, b in BLOCKS.items()}
json.dump(meta, open('blocks_meta.json', 'w'), indent=1, ensure_ascii=False)
print('written: tidy_values.csv, tidy_survival.csv, tidy_bodyweight.csv, blocks_meta.json')

"""Exact power of a two-sided Fisher exact test (alpha=0.05) for survival proportions, used to size the proposed studies.
Assumed proportions are taken from the observed pooled estimates in this dataset where available."""
import numpy as np, pandas as pd
from scipy import stats
from functools import lru_cache
@lru_cache(None)
def fisher_p(a, n1, b, n2):
    return stats.fisher_exact([[a, n1 - a], [b, n2 - b]])[1]
def power(p1, p2, n1, n2=None, alpha=0.05):
    n2 = n2 or n1; pw = 0.0
    pa = stats.binom.pmf(np.arange(n1 + 1), n1, p1); pb = stats.binom.pmf(np.arange(n2 + 1), n2, p2)
    for a in range(n1 + 1):
        if pa[a] < 1e-12: continue
        for b in range(n2 + 1):
            if pb[b] < 1e-12: continue
            if fisher_p(a, n1, b, n2) < alpha: pw += pa[a] * pb[b]
    return pw
def n_for(p1, p2, target=0.8, nmax=80):
    for n in range(4, nmax + 1):
        if power(p1, p2, n) >= target: return n, power(p1, p2, n)
    return None, None
rows = []
for label, p1, p2 in [
    ('PSLN-344 (0.85, pooled aged) vs PSLN-212 (0.14, pooled aged)', 0.85, 0.14),
    ('PSLN-344 (0.85) vs Mn-only / empty liposome control (assume 0.15)', 0.85, 0.15),
    ('PSLN-344 (0.85) vs licensed-type comparator assumed to protect 50%', 0.85, 0.50),
    ('PSLN-344 (0.85) vs licensed-type comparator assumed to protect 60%', 0.85, 0.60),
    ('d60 durability: PSLN-344 aged (0.67 observed) vs boosted regimen hoped-for 0.95', 0.95, 0.67),
    ('CD8 depletion: isotype (0.85) vs anti-CD8 (assume 0.30 if CD8 T cells are necessary)', 0.85, 0.30),
    ('CD8 depletion, partial dependence: 0.85 vs 0.50', 0.85, 0.50),
    ('PSLN-212 + rGM-CSF (assume 0.70 if GM-CSF is sufficient) vs PSLN-212 (0.14)', 0.70, 0.14)]:
    n80, pw80 = n_for(p1, p2, 0.8); n90, pw90 = n_for(p1, p2, 0.9)
    rows.append(dict(comparison=label, p_test=p1, p_ctrl=p2, n_per_arm_80=n80, power_at_n80=round(pw80, 3) if pw80 else None, n_per_arm_90=n90, power_at_n90=round(pw90, 3) if pw90 else None,
                     power_at_n7=round(power(p1, p2, 7), 3), power_at_n10=round(power(p1, p2, 10), 3), power_at_n12=round(power(p1, p2, 12), 3), power_at_n15=round(power(p1, p2, 15), 3)))
P = pd.DataFrame(rows); P.to_csv('power_calcs.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 90)
print(P.to_string())
# precision of a background-mortality estimate
from statsmodels.stats.proportion import proportion_confint
for n in (7, 14, 20, 30):
    k = round(0.19 * n); lo, hi = proportion_confint(k, n, method='beta'); print(f'background deaths {k}/{n}: 95% CI {100*lo:.0f}-{100*hi:.0f}%')

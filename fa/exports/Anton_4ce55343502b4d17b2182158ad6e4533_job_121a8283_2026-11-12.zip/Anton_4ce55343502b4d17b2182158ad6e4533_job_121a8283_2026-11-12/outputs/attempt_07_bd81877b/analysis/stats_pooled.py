"""Pooled / stratified survival analyses and sensitivity analyses for the aged-animal efficacy claim."""
import pandas as pd, numpy as np, json
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.contingency_tables import StratifiedTable
from stats_survival import S, logrank_OEV, META

def arm(block, group):
    d = S[(S.block == block) & (S.group == group)]
    return d.day.values.astype(float), d.event.values.astype(int)

def pooled(pairs, label, verbose=True):
    """pairs = list of (block, test_group, control_group)"""
    OE = 0; V = 0; tabs = []; a1 = n1 = a2 = n2 = 0
    for b, g1, g2 in pairs:
        t1, e1 = arm(b, g1); t2, e2 = arm(b, g2)
        oe, v = logrank_OEV(t1, e1, t2, e2); OE += oe; V += v
        tabs.append(np.array([[int((e1 == 0).sum()), int((e1 == 1).sum())], [int((e2 == 0).sum()), int((e2 == 1).sum())]]))
        a1 += (e1 == 0).sum(); n1 += len(e1); a2 += (e2 == 0).sum(); n2 += len(e2)
    chi = OE**2 / V; p = stats.chi2.sf(chi, 1)
    st = StratifiedTable(tabs)
    cmh = st.test_null_odds(correction=False)
    lo1, hi1 = proportion_confint(a1, n1, method='beta'); lo2, hi2 = proportion_confint(a2, n2, method='beta')
    _, pf = stats.fisher_exact([[a1, n1 - a1], [a2, n2 - a2]])
    # MH risk difference with Sato variance is overkill here; report crude RD with Newcombe CI
    from statsmodels.stats.proportion import confint_proportions_2indep
    rd_lo, rd_hi = confint_proportions_2indep(a1, n1, a2, n2, method='newcomb', compare='diff')
    out = dict(analysis=label, k_experiments=len(pairs), test_surv=f'{a1}/{n1}', test_pct=100*a1/n1, test_ci=f'{100*lo1:.0f}-{100*hi1:.0f}',
               ctrl_surv=f'{a2}/{n2}', ctrl_pct=100*a2/n2, ctrl_ci=f'{100*lo2:.0f}-{100*hi2:.0f}', risk_diff_pct=100*(a1/n1 - a2/n2), rd_ci=f'{100*rd_lo:.0f} to {100*rd_hi:.0f}',
               strat_logrank_chi2=chi, strat_logrank_p=p, cmh_chi2=cmh.statistic, cmh_p=stats.chi2.sf(cmh.statistic, 1), crude_fisher_p=pf)
    return out

AGED_BALBC = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G']
OTHER_STRAIN = ['S15-L', 'S15-N']
res = []
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in AGED_BALBC], 'A1. Aged BALB/c, PSLN-344 vs Sham (9 experiments: S03-I, S03-J, S06-A..G)'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in AGED_BALBC], 'A2. Aged BALB/c, PSLN-344 vs PSLN-212 (same 9)'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in AGED_BALBC + OTHER_STRAIN] + [('S15-H', '3d Vaccine+PSLN-344', '3d Vaccine')], 'A3. All aged experiments with a vaccine-only control (12: + S15-H, S15-L, S15-N)'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in AGED_BALBC + OTHER_STRAIN], 'A4. All aged experiments with a PSLN-212 arm (11)'))
res.append(pooled([(b, 'PSLN-212', 'Sham') for b in AGED_BALBC + OTHER_STRAIN], 'A5. Aged, PSLN-212 vs Sham (11)'))
yb = [b for b in AGED_BALBC if b != 'S03-J']
res.append(pooled([(b, 'PSLN-212(Y)', 'PSLN-344') for b in yb], 'B1. Young PSLN-212(Y) benchmark vs aged PSLN-344, BALB/c (8; S03-J has no young arm)'))
res.append(pooled([(b, 'PSLN-212(Y)', 'PSLN-344') for b in ['S03-I', 'S06-A', 'S06-C']], 'B2. ... challenge at d14 only (S03-I, S06-A, S06-C)'))
res.append(pooled([(b, 'PSLN-212(Y)', 'PSLN-344') for b in ['S06-B', 'S06-D']], 'B3. ... challenge at d3 only (S06-B, S06-D)'))
res.append(pooled([(b, 'PSLN-212(Y)', 'PSLN-344') for b in ['S06-E', 'S06-F', 'S06-G']], 'B4. ... challenge at d60 only (S06-E, S06-F, S06-G)'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in ['S06-E', 'S06-F', 'S06-G']], 'C1. d60 challenge: PSLN-344 vs Sham'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in ['S06-E', 'S06-F', 'S06-G']], 'C2. d60 challenge: PSLN-344 vs PSLN-212'))
res.append(pooled([(b, 'Untreated', 'PSLN-344') for b in ['S06-E', 'S06-F', 'S06-G']], 'C3. d60 challenge: Untreated/unchallenged aged vs challenged PSLN-344'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in ['S06-B', 'S06-D']] + [('S15-H', '3d Vaccine+PSLN-344', '3d Vaccine'), ('S03-J', 'PSLN-344', 'Sham')], 'D1. Early challenge (d2-3): PSLN-344 vs vaccine-only (S03-J, S06-B, S06-D, S15-H)'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in ['S03-I', 'S06-A', 'S06-C']], 'D2. Challenge at d14: PSLN-344 vs Sham (S03-I, S06-A, S06-C)'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in ['S03-I', 'S06-A', 'S06-C']], 'D3. Challenge at d14: PSLN-344 vs PSLN-212 (S03-I, S06-A, S06-C)'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G']], 'S5. Sensitivity: A1 without S06-C and S06-D: PSLN-344 vs Sham'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G']], 'S6. Sensitivity: A2 without S06-C and S06-D: PSLN-344 vs PSLN-212'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G']], 'S7. Sensitivity: A2 without S06-D: PSLN-344 vs PSLN-212'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in ['S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G']], 'E1. Challenge HA subtype absent from the vaccine, aged BALB/c (S06-A..G): PSLN-344 vs Sham'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in ['S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G']], 'E2. Challenge HA subtype absent from the vaccine (S06-A..G): PSLN-344 vs PSLN-212'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in ['S06-A', 'S06-B', 'S06-E', 'S06-G']], 'E3. Fully heterosubtypic (no shared HA or NA subtype; S06-A, B, E, G): PSLN-344 vs Sham'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in ['S06-A', 'S06-B', 'S06-E', 'S06-G']], 'E4. Fully heterosubtypic (S06-A, B, E, G): PSLN-344 vs PSLN-212'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in ['S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G']], 'S3. Sensitivity: only the five experiments with no label/duplication flag on the table (S06-A, B, E, F, G): PSLN-344 vs Sham'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in ['S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G']], 'S4. Sensitivity: same five experiments: PSLN-344 vs PSLN-212'))
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in ['S15-L', 'S15-N']], 'H1. Other strains (S15-L C57BL/6, S15-N Swiss Webster): PSLN-344 vs Sham'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in ['S15-L', 'S15-N']], 'H2. Other strains: PSLN-344 vs PSLN-212'))
# sensitivity: drop suspected-duplicate / unannotated blocks
keep = [b for b in AGED_BALBC if b not in ('S06-D',)]
res.append(pooled([(b, 'PSLN-344', 'Sham') for b in keep], 'S1. Sensitivity: A1 without S06-D (identical to S06-C in every arm)'))
res.append(pooled([(b, 'PSLN-344', 'PSLN-212') for b in keep if b not in ('S03-I', 'S03-J')], 'S2. Sensitivity: A2 without S06-D and without S03-I/S03-J (comparator labels conflict with paired body-weight blocks)'))
# imprinting
res.append(pooled([('S06-E2', 'Naïve+PSLN-344', 'Naïve+PSLN-212'), ('S06-F2', 'Naïve+PSLN-344', 'Naïve+PSLN-212'), ('S06-E2', 'Imprinting+PSLN-344', 'Imprinting+PSLN-212'), ('S06-F2', 'Imprinting+PSLN-344', 'Imprinting+PSLN-212')], 'F1. 14-month imprinting study: PSLN-344 vs PSLN-212 (4 strata)'))
res.append(pooled([('S06-E2', 'Imprinting+PSLN-344', 'Naïve+PSLN-344'), ('S06-F2', 'Imprinting+PSLN-344', 'Naïve+PSLN-344')], 'F2. Imprinted vs naive, both PSLN-344'))
# young
res.append(pooled([(b, 'PSLN-344Y', 'PSLN-212Y') for b in ['S09-B', 'S09-D', 'S09-F']], 'G1. Young BALB/c: PSLN-344Y vs PSLN-212Y (S09-B, D, F)') if False else dict(analysis='G1. Young BALB/c: PSLN-344Y vs PSLN-212Y (S09-B, D, F)', k_experiments=3, test_surv='24/24', ctrl_surv='24/24', test_pct=100.0, ctrl_pct=100.0))
P = pd.DataFrame(res)
P.to_csv('stats_survival_pooled.csv', index=False)
pd.set_option('display.width', 300); pd.set_option('display.max_colwidth', 120); pd.set_option('display.max_columns', 30)
print(P[['analysis', 'k_experiments', 'test_surv', 'test_pct', 'test_ci', 'ctrl_surv', 'ctrl_pct', 'ctrl_ci', 'risk_diff_pct', 'rd_ci', 'strat_logrank_p', 'cmh_p', 'crude_fisher_p']].to_string())

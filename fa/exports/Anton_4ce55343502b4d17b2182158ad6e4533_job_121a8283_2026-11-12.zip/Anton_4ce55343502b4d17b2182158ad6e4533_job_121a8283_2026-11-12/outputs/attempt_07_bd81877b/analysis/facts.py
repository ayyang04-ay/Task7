"""Prints every number quoted in the memo prose, recomputed from the tidy files (used to transcribe and to re-verify)."""
import pandas as pd, numpy as np, json
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
D = pd.read_csv('tidy_values.csv', keep_default_na=False); D['value'] = D['value'].astype(float)
G = pd.read_csv('stats_group_summaries.csv', keep_default_na=False)
for c in ['mean', 'sd', 'gmt', 'gmt_lo', 'gmt_hi', 'gm_fold', 'n']: G[c] = pd.to_numeric(G[c], errors='coerce')
SG = pd.read_csv('stats_survival_groups.csv'); ST = pd.read_csv('stats_survival_tests.csv'); SP = pd.read_csv('stats_survival_pooled.csv')
T = pd.read_csv('stats_tests.csv', keep_default_na=False); T['p'] = T['p'].astype(float)
def g(block, group, x=''):
    r = G[(G.block == block) & (G.group == group) & (G.x.astype(str) == str(x))].iloc[0]; return r
def ms(block, group, x='', d=1):
    r = g(block, group, x); return f"{r['mean']:.{d}f} ± {r['sd']:.{d}f} (n={int(r['n'])})"
def gmt(block, group):
    r = g(block, group); return f"GMT {r.gmt:,.0f} [{r.gmt_lo:,.0f}-{r.gmt_hi:,.0f}]"
def p(block, contrast, test='Welch t', x=''):
    r = T[(T.block == block) & (T.contrast == contrast) & (T.test == test) & (T.x.astype(str) == str(x))]
    return r.p.iloc[0] if len(r) else float('nan')
def line(*a): print(*a)

line('== POOLED SURVIVAL ==')
for _, r in SP.iterrows():
    line(f"{r.analysis}: test {r.test_surv} ({r.test_pct:.1f}%; CI {r.test_ci}) vs ctrl {r.ctrl_surv} ({r.ctrl_pct:.1f}%; CI {r.ctrl_ci}); RD {r.risk_diff_pct:.1f} ({r.rd_ci}); strat log-rank p={r.strat_logrank_p:.2e}; CMH p={r.cmh_p:.2e}; Fisher p={r.crude_fisher_p:.2e}")
line('\n== fully heterosubtypic (no shared HA or NA subtype): S06-A,B,E,G ; shared-N1: S06-C,D,F,S15-H ==')
for name, blocks, arms in [('H3N2->H1N1 / H1N1->H3N2', ['S06-A', 'S06-B', 'S06-E', 'S06-G'], ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']), ('bivalent->rgH5N1', ['S06-C', 'S06-D', 'S06-F'], ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)'])]:
    for a in arms:
        x = SG[SG.block.isin(blocks) & (SG.group == a)]; s, n = x.survivors.sum(), x.n.sum(); lo, hi = proportion_confint(s, n, method='beta')
        line(f'  {name} {a}: {s}/{n} ({100*s/n:.0f}%; {100*lo:.0f}-{100*hi:.0f})')
line('\n== by timing, PSLN-344 aged BALB/c ==')
for name, blocks in [('d2-3', ['S03-J', 'S06-B', 'S06-D']), ('d2-3 incl S15-H', ['S03-J', 'S06-B', 'S06-D', 'S15-H']), ('d14', ['S03-I', 'S06-A', 'S06-C']), ('d60', ['S06-E', 'S06-F', 'S06-G'])]:
    for a in ['PSLN-344', 'Sham', 'PSLN-212', 'PSLN-212(Y)', 'Untreated', '3d Vaccine+PSLN-344', '3d Vaccine']:
        x = SG[SG.block.isin(blocks) & (SG.group == a)]
        if len(x):
            s, n = x.survivors.sum(), x.n.sum(); lo, hi = proportion_confint(s, n, method='beta'); line(f'  {name} {a}: {s}/{n} ({100*s/n:.0f}%; {100*lo:.0f}-{100*hi:.0f})')
line('\n== median survival (days) in non-survivors/controls ==')
line(SG[SG.block.isin(['S03-I', 'S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G'])][['block', 'group', 'death_days', 'median_survival_d']].to_string())

line('\n== INNATE ==')
for grp in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-R848', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']:
    line(f"S01-A 16h {grp}: {ms('S01-A_16h', grp)} | 72h: {ms('S01-A_72h', grp)}")
line('S01-A 16h PSLN-344 vs PSLN-212 Welch p', p('S01-A_16h', 'PSLN-212 vs PSLN-344'), '| vs PSLN-212(Y)', p('S01-A_16h', 'PSLN-344 vs PSLN-212(Y)'), '| Y344 vs Y212', p('S01-A_16h', 'PSLN-212(Y) vs PSLN-344(Y)'))
for dose in [1, 5, 10, 20, 40]:
    line(f"S08-A {dose} ug: CMP-204 {ms('S08-A', 'CMP-204', dose)} | PSLN-212 {ms('S08-A', 'PSLN-212', dose)} | PSLN-344 {ms('S08-A', 'PSLN-344', dose)} | PSLN-344/R848 {ms('S08-A', 'PSLN-344/R848', dose)}")
for tpt in ['16h', '36h', '72h']:
    line(f"S02-F {tpt}: PSLN-344 {ms('S02-F', 'PSLN-344', tpt, 2)} | PSLN-212 {ms('S02-F', 'PSLN-212', tpt, 2)} | Sham {ms('S02-F', 'Sham', tpt, 2)} ; Welch p 344 vs 212 = {p('S02-F', 'PSLN-344 vs PSLN-212', x=tpt):.2g}")
for b in ['S01-B', 'S01-C', 'S11-C', 'S02-G', 'S02-H', 'S02-I', 'S07-B_mono', 'S07-B_mac', 'S07-C', 'S12-A', 'S05-C', 'S08-B', 'S08-C', 'S11-E', 'S02-C', 'S02-E', 'S02-A', 'S02-B', 'S02-D_CD40', 'S02-D_CD86', 'S01-F', 'S01-G',
          'S03-K', 'S03-L_Aicda', 'S03-L_E47', 'S04-A_ICOShi', 'S04-A_ICOSlo', 'S04-B_Tfr', 'S04-B_ratio', 'S04-C', 'S04-D', 'S05-D', 'S05-E', 'S05-F', 'S05-G', 'S05-H', 'S05-I', 'S13-H', 'S14-A_H1N1', 'S14-A_H3N2',
          'S10-A_Ifnb1', 'S10-A_Tnf', 'S10-A_Isg15']:
    gs = G[G.block == b].group.tolist()
    line(f'{b}: ' + ' | '.join(f"{x}: {ms(b, x, d=2)}" for x in gs))
line('\n== two-group Welch p ==')
for b, c in [('S01-C', 'WT vs SPA/D'), ('S11-C', 'CBX+ vs CBX-'), ('S02-I', 'PSLN-344(Y) vs PSLN-344(Y)+INCB3344'), ('S07-B_mono', 'PSLN-344 vs PSLN-344+INCB3344'), ('S07-B_mac', 'PSLN-344 vs PSLN-344+INCB3344'), ('S12-A', 'WT to WT vs IFNAR-/- to WT'),
             ('S05-C', 'Lung vs Lung+PTX'), ('S05-C', 'MLN vs MLN+PTX'), ('S02-G', 'PSLN-212 vs PSLN-212+GM-CSF'), ('S02-G', 'GM-CSF vs PSLN-212'), ('S02-H', 'WT w/o cDC vs IFN w/o cDC'), ('S02-H', 'IFN w/o cDC vs GMCSF'), ('S02-H', 'WT w/o cDC vs GMCSF'),
             ('S02-C', 'PSLN-344 vs PTX'), ('S02-E', 'PSLN-344 vs PTX'), ('S10-A_Tnf', 'PBS vs PSLN-344'), ('S10-A_Tnf', 'Sham vs PSLN-344'), ('S10-A_Ifnb1', 'PBS vs PSLN-344'), ('S10-A_Isg15', 'PBS vs PSLN-344'), ('S10-A_Tnf', 'PBS vs CT'),
             ('S07-C', 'Ly6C-CD206+ MΦ vs Ly6C-CD206+ MΦ [col C]'), ('S08-B', 'PSLN-212 vs PSLN-344'), ('S01-A_72h', 'PSLN-344 vs PSLN-212(Y)'), ('S01-A_72h', 'PSLN-212 vs PSLN-212(Y)')]:
    line(f"  {b} {c}: Welch p={p(b, c):.3g}; Tukey p={p(b, c, 'Tukey HSD'):.3g}; MW p={p(b, c, 'Mann-Whitney exact'):.3g}")
line('\n== TITRES ==')
for b in ['S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-A', 'S13-B', 'S13-C', 'S13-D', 'S13-I', 'S13-J']:
    gs = G[G.block == b].group.tolist(); line(f'{b}: ' + ' | '.join(f"{x}: {gmt(b, x)}" for x in gs))
for b in ['S03-C', 'S03-G']:
    for grp in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        v = D[(D.block == b) & (D.group == grp)].value.values; line(f'  {b} {grp}: values {v.tolist()} ; n>=40: {(v >= 40).sum()}/{len(v)}; n>=160: {(v >= 160).sum()}/{len(v)}')
line('\n== IgG2a/IgG1 recomputed from S13 ==')
for a, b1, nm in [('S13-A', 'S13-B', 'CA09'), ('S13-C', 'S13-D', 'Aichi')]:
    for grp in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        x = D[(D.block == a) & (D.group == grp)].value.values / D[(D.block == b1) & (D.group == grp)].value.values
        line(f'  {nm} {grp}: ratio mean {x.mean():.2f} ± {x.std(ddof=1):.2f}; geometric mean {np.exp(np.log(x).mean()):.2f}; range {x.min():.2f}-{x.max():.2f}')
line('  printed S03-B:', {grp: round(D[(D.block == 'S03-B') & (D.group == grp)].value.mean(), 2) for grp in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}, '| printed S03-F:', {grp: round(D[(D.block == 'S03-F') & (D.group == grp)].value.mean(), 2) for grp in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']})
line('\n== prime vs boost GMT ratio ==')
for b14, b28 in [('S03-A', 'S13-I'), ('S03-E', 'S13-J')]:
    for grp in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        line(f'  {b14}->{b28} {grp}: d14 GMT {g(b14, grp).gmt:,.0f} -> d28 post-boost GMT {g(b28, grp).gmt:,.0f} (x{g(b28, grp).gmt/g(b14, grp).gmt:.1f})')
line('\n== time courses (peak days) ==')
for b, days in [('S01-D', [0, 2, 4, 6, 8]), ('S01-E', [0, 2, 4, 6, 8]), ('S11-A', [0, 4]), ('S11-D', [0, 2, 4]), ('S07-A', [0, 2, 5, 10, 30])]:
    for grp in G[G.block == b].group.unique():
        line(f'  {b} {grp}: ' + ' ; '.join(f"d{d_}: {ms(b, grp, d_)}" for d_ in days))
line('\n== S09-A geometric mean fold (10**mean log10) ==')
for a in ['Ifnb1', 'Il6', 'Tnf', 'Il10', 'Ccl2', 'Ccl3', 'Ccl5']:
    for pnl, nm in [('p1', '16h'), ('p2', '72h*')]:
        line(f'  {a} {nm}: ' + ' | '.join(f"{grp}: {g(f'S09-A_{pnl}_{a}', grp).gm_fold:.1f}x" for grp in ['PBS', 'CMP-204', 'PSLN-212', 'PSLN-R848', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(y)']))

"""Time-to-event analysis.
Reductions:
  * survival = animals with flag 0 at the end of the observation window / animals in the group (rows present in the cited range)
  * 95% CI = exact binomial (Clopper-Pearson)
  * between-group tests: log-rank (Mantel-Cox; the method stated in the annotation) on the full time-to-event rows, and
    Fisher's exact test (two-sided) on end-of-window survival as an assumption-light check
  * pooled tests: stratified log-rank (strata = experiment) and Cochran-Mantel-Haenszel on end-of-window survival
  * the one S03-J PSLN-344 row with a flag but no day (S03!J46; G46 empty) is kept in the survivor count (flag=0) and
    entered in the log-rank as censored at day 14, the last day that animal group is documented alive in S13-G
"""
import pandas as pd, numpy as np, json, itertools
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.contingency_tables import StratifiedTable

S = pd.read_csv('tidy_survival.csv', keep_default_na=False)
S['day_raw'] = S['day']
S['missing_day'] = (S['day'] == '')
S['day'] = pd.to_numeric(S['day'], errors='coerce')
S.loc[S.missing_day, 'day'] = 14     # see docstring
META = json.load(open('blocks_meta.json'))

def logrank_OEV(t1, e1, t2, e2):
    """returns (O1 - E1, Var) for group 1 vs group 2"""
    t = np.concatenate([t1, t2]); e = np.concatenate([e1, e2]); g = np.concatenate([np.ones(len(t1)), np.zeros(len(t2))])
    OE = 0.0; V = 0.0
    for ti in np.unique(t[e == 1]):
        at = t >= ti; n = at.sum(); n1 = (at & (g == 1)).sum()
        d = ((t == ti) & (e == 1)).sum(); d1 = ((t == ti) & (e == 1) & (g == 1)).sum()
        OE += d1 - d * n1 / n
        if n > 1: V += d * (n1 / n) * (1 - n1 / n) * (n - d) / (n - 1)
    return OE, V

def logrank_p(t1, e1, t2, e2):
    OE, V = logrank_OEV(np.asarray(t1, float), np.asarray(e1, int), np.asarray(t2, float), np.asarray(e2, int))
    if V == 0: return np.nan, np.nan
    chi = OE**2 / V
    return chi, stats.chi2.sf(chi, 1)

def km_median(t, e):
    t = np.asarray(t, float); e = np.asarray(e, int)
    s = 1.0
    for ti in np.unique(t[e == 1]):
        n = (t >= ti).sum(); d = ((t == ti) & (e == 1)).sum(); s *= 1 - d / n
        if s <= 0.5: return ti
    return np.inf

rows = []; tests = []
for block, d in S.groupby('block', sort=False):
    m = META[block]
    for g in m['groups']:
        x = d[d.group == g]; n = len(x); dead = int(x.event.sum()); alive = n - dead
        lo, hi = proportion_confint(alive, n, alpha=0.05, method='beta')
        cd = x.cell_day.tolist()
        rows.append(dict(block=block, conditions=m['cond'], group=g, n=n, stated_n=m['stated_n'], deaths=dead, survivors=alive, survival_pct=100*alive/n,
                         ci_lo=100*lo, ci_hi=100*hi, death_days=' '.join(str(int(v)) for v in sorted(x[x.event == 1].day)), median_survival_d=km_median(x.day, x.event),
                         n_missing_day=int(x.missing_day.sum()), cells=f"{m['sheet']}!{cd[0]}:{cd[-1]}"))
    for g1, g2 in itertools.combinations(m['groups'], 2):
        a = d[d.group == g1]; b = d[d.group == g2]
        chi, p = logrank_p(a.day, a.event, b.day, b.event)
        tab = [[int((a.event == 0).sum()), int((a.event == 1).sum())], [int((b.event == 0).sum()), int((b.event == 1).sum())]]
        _, pf = stats.fisher_exact(tab)
        tests.append(dict(block=block, contrast=f'{g1} vs {g2}', surv1=f'{tab[0][0]}/{len(a)}', surv2=f'{tab[1][0]}/{len(b)}', logrank_chi2=chi, logrank_p=p, fisher_p=pf))
R = pd.DataFrame(rows); T = pd.DataFrame(tests)
R.to_csv('stats_survival_groups.csv', index=False); T.to_csv('stats_survival_tests.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 60)
print(R[['block', 'group', 'n', 'stated_n', 'deaths', 'survivors', 'survival_pct', 'ci_lo', 'ci_hi', 'death_days', 'median_survival_d', 'cells']].to_string())
print()
key = T[T.contrast.str.contains('PSLN-344')]
print(key.to_string())

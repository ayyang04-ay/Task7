"""Independent re-derivation of headline numbers straight from the workbook cells (does not import blocks.py)."""
import openpyxl, numpy as np
from openpyxl.utils import column_index_from_string as CI, get_column_letter as L
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx', data_only=True)
def flags(sheet, col, r1, r2):
    w = wb[sheet]; v = [w[f'{col}{r}'].value for r in range(r1, r2 + 1)]; v = [x for x in v if x is not None]
    return sum(1 for x in v if x == 0), len(v)
tot = {'Sham': [0, 0], 'PSLN-212': [0, 0], 'PSLN-344': [0, 0], 'Y': [0, 0]}
spec = [  # sheet, rows, {arm: flag column}
 ('S03-I', 'S03', 17, 51, {'Sham': 'B', 'PSLN-212': 'D', 'PSLN-344': 'E', 'Y': 'F'}),
 ('S03-J', 'S03', 17, 46, {'Sham': 'H', 'PSLN-212': 'I', 'PSLN-344': 'J'}),
 ('S06-A', 'S06', 3, 30, {'Sham': 'B', 'PSLN-212': 'C', 'PSLN-344': 'D', 'Y': 'E'}),
 ('S06-B', 'S06', 3, 30, {'Sham': 'H', 'PSLN-212': 'I', 'PSLN-344': 'J', 'Y': 'K'}),
 ('S06-C', 'S06', 3, 30, {'Sham': 'N', 'PSLN-212': 'O', 'PSLN-344': 'P', 'Y': 'Q'}),
 ('S06-D', 'S06', 34, 61, {'Sham': 'B', 'PSLN-212': 'C', 'PSLN-344': 'D', 'Y': 'E'}),
 ('S06-E', 'S06', 34, 68, {'Sham': 'H', 'PSLN-212': 'I', 'PSLN-344': 'J', 'Y': 'K'}),
 ('S06-F', 'S06', 34, 68, {'Sham': 'N', 'PSLN-212': 'O', 'PSLN-344': 'P', 'Y': 'Q'}),
 ('S06-G', 'S06', 71, 105, {'Sham': 'B', 'PSLN-212': 'C', 'PSLN-344': 'D', 'Y': 'E'})]
for name, sh, r1, r2, arms in spec:
    out = []
    for a, c in arms.items():
        s, n = flags(sh, c, r1, r2); tot[a][0] += s; tot[a][1] += n; out.append(f'{a} {s}/{n}')
    print(name, ' | '.join(out))
print('TOTAL nine aged BALB/c experiments:', {k: f'{v[0]}/{v[1]}' for k, v in tot.items()})
w = wb['S03']
hai = {c: [w[f'{c}{r}'].value for r in range(3, 8)] for c in 'KLMNO'}
print('S03-C HAI by column K..O (Sham, CMP-204, PSLN-212, PSLN-344, Y):', hai)
gm = lambda v: float(np.exp(np.mean(np.log([x if x > 0 else 5 for x in v]))))
print('   GMT:', {c: round(gm(v)) for c, v in hai.items()})
w1 = wb['S01']
for r, name in [(5, 'PSLN-212'), (8, 'PSLN-344'), (9, 'PSLN-212(Y)')]:
    v = [w1.cell(r, c).value for c in range(2, 7)]; print('S01-A 16h', w1[f'A{r}'].value, name, round(np.mean(v), 2), round(np.std(v, ddof=1), 2))
w13 = wb['S13']
for ca, cb, name in [('A', 'E', 'PSLN-212'), ('B', 'F', 'PSLN-344'), ('C', 'G', 'PSLN-212(Y)')]:
    q = [w13[f'{ca}{r}'].value / w13[f'{cb}{r}'].value for r in range(3, 8)]; print('IgG2a/IgG1 CA09', w13[f'{ca}2'].value, round(np.mean(q), 3), [round(x, 4) for x in q])
print('S03-B printed:', {w['G2'].value: [round(w[f'G{r}'].value, 4) for r in range(3, 8)], w['H2'].value: [round(w[f'H{r}'].value, 4) for r in range(3, 8)], w['I2'].value: [round(w[f'I{r}'].value, 4) for r in range(3, 8)]})
w15 = wb['S15']
print('S15-H flags B,C,D rows 73-93:', flags('S15', 'B', 73, 93), flags('S15', 'C', 73, 93), flags('S15', 'D', 73, 93))
print('S15-L PSLN-344 / S15-N PSLN-344:', flags('S15', 'D', 103, 130), flags('S15', 'D', 134, 161))
w2 = wb['S02']
print('S02-F 16h PSLN-344 (B17:F17) mean', round(np.mean([w2.cell(17, c).value for c in range(2, 7)]), 2), '| PSLN-212 (G17:K17)', round(np.mean([w2.cell(17, c).value for c in range(7, 12)]), 2), '| headers:', w2['B16'].value, w2['G16'].value, w2['L16'].value)
w5 = wb['S05']
for r0, name in [(33, 'S05-F'), (40, 'S05-G')]:
    print(name, {w5.cell(r0 - 1, c).value: round(np.mean([w5.cell(r, c).value for r in range(r0, r0 + 5)]), 2) for c in range(1, 5)})
w8 = wb['S08']
print('S08-D PSLN-344 (Q..U) mean by row 22..26:', [round(np.mean([w8.cell(r, c).value for c in range(CI('Q'), CI('U') + 1)]), 2) for r in range(22, 27)], 'header', w8['Q20'].value)

from blocks import BLOCKS
import itertools
S = {bid: b for bid, b in BLOCKS.items() if b['kind'] == 'surv'}
def vec(b, g): return tuple(sorted((r[0] if r[0] is not None else -1, r[1]) for r in b['data'][g]))
print('Survival tables: per-group vectors'); 
for bid, b in S.items():
    print(bid, '|', b['cond'])
    for g in b['groups']:
        recs = b['data'][g]
        ev = sorted(r[0] for r in recs if r[1] == 1); c = [r[0] for r in recs if r[1] == 0]
        print(f'    {g:24s} n={len(recs)} deaths={len(ev)} on days {ev}; censored={len(c)} at {sorted(set(x for x in c if x is not None))}{" (+%d with missing day)" % sum(x is None for x in c) if any(x is None for x in c) else ""}')
print()
print('Whole-block identity (same group names, identical vectors in every arm):')
for (b1, B1), (b2, B2) in itertools.combinations(S.items(), 2):
    common = [g for g in B1['groups'] if g in B2['groups']]
    if len(common) >= 3:
        same = [g for g in common if vec(B1, g) == vec(B2, g)]
        nontrivial = [g for g in same if any(r[1] == 1 for r in B1['data'][g])]
        if len(nontrivial) >= 1:
            print(f'  {b1} vs {b2}: identical arms = {same} (with deaths: {nontrivial}) of common {common}')

"""
Parse every labelled block of adjuvant_program_dataset.xlsx into tidy records with cell-level provenance.

Each block is a dict:
  id        unique id used in the report (sheet label + disambiguator where the workbook re-uses a label)
  sheet     worksheet name
  label     label exactly as printed in the workbook
  kind      'rep' (replicate values per group), 'tc' (time course / dose series: x -> replicates per group),
            'surv' (time-to-event), 'bw' (body weight series per animal)
  groups    ordered list of group names as printed
  data      rep : {group: [(value, cell), ...]}
            tc  : {group: {x: [(value, cell), ...]}}
            surv: {group: [(day, event, cell_day, cell_flag), ...]}
            bw  : {group: {animal_col: {day: value or None}}}
  range     {group: 'A1:B2'} cell range for the citation
"""
import openpyxl
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI

XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
_wb = openpyxl.load_workbook(XLSX, data_only=True)

def ws(name): return _wb[name]
def v(sheet, ref): return ws(sheet)[ref].value

BLOCKS = {}

def _add(b):
    assert b['id'] not in BLOCKS, b['id']
    BLOCKS[b['id']] = b

def rep_cols(bid, sheet, label, hdr_row, r1, r2, cols, stated_n=None, note='', names=None):
    """groups in columns; header in hdr_row; replicates down rows r1..r2. cols = list of column letters."""
    w = ws(sheet); groups = []; data = {}; rng = {}
    for i, c in enumerate(cols):
        g = w[f'{c}{hdr_row}'].value
        g = str(g).strip() if g is not None else None
        if names: g = names[i]
        # disambiguate duplicated printed labels
        gg = g; k = 2
        while gg in data:
            gg = f'{g} [col {c}]'; k += 1
        vals = [(w[f'{c}{r}'].value, f'{c}{r}') for r in range(r1, r2+1) if w[f'{c}{r}'].value is not None]
        groups.append(gg); data[gg] = vals; rng[gg] = f'{sheet}!{c}{r1}:{c}{r2}'
    _add(dict(id=bid, sheet=sheet, label=label, kind='rep', groups=groups, data=data, range=rng, stated_n=stated_n, note=note))

def rep_rows(bid, sheet, label, rows, c1, c2, name_col='A', stated_n=None, note='', names=None):
    """groups in rows; group name in name_col; replicates across columns c1..c2."""
    w = ws(sheet); groups = []; data = {}; rng = {}
    for i, r in enumerate(rows):
        g = names[i] if names else str(w[f'{name_col}{r}'].value).strip()
        vals = [(w.cell(r, c).value, f'{L(c)}{r}') for c in range(CI(c1), CI(c2)+1) if w.cell(r, c).value is not None]
        groups.append(g); data[g] = vals; rng[g] = f'{sheet}!{c1}{r}:{c2}{r}'
    _add(dict(id=bid, sheet=sheet, label=label, kind='rep', groups=groups, data=data, range=rng, stated_n=stated_n, note=note))

def rep_span(bid, sheet, label, row, spans, stated_n=None, note=''):
    """single data row; each group spans several columns. spans = [(name, c1, c2), ...]"""
    w = ws(sheet); groups = []; data = {}; rng = {}
    for g, c1, c2 in spans:
        vals = [(w.cell(row, c).value, f'{L(c)}{row}') for c in range(CI(c1), CI(c2)+1) if w.cell(row, c).value is not None]
        groups.append(g); data[g] = vals; rng[g] = f'{sheet}!{c1}{row}:{c2}{row}'
    _add(dict(id=bid, sheet=sheet, label=label, kind='rep', groups=groups, data=data, range=rng, stated_n=stated_n, note=note))

def tc(bid, sheet, label, r1, r2, spans, xcol='A', stated_n=None, note='', xname='day'):
    """time course / dose series: x in xcol rows r1..r2; spans = [(name, c1, c2), ...]"""
    w = ws(sheet); groups = []; data = {}; rng = {}
    for g, c1, c2 in spans:
        d = {}
        for r in range(r1, r2+1):
            x = w[f'{xcol}{r}'].value
            d[x] = [(w.cell(r, c).value, f'{L(c)}{r}') for c in range(CI(c1), CI(c2)+1) if w.cell(r, c).value is not None]
        groups.append(g); data[g] = d; rng[g] = f'{sheet}!{c1}{r1}:{c2}{r2}'
    _add(dict(id=bid, sheet=sheet, label=label, kind='tc', groups=groups, data=data, range=rng, stated_n=stated_n, note=note, xname=xname))

def surv(bid, sheet, label, hdr_row, r1, r2, daycol, flagcols, stated_n=None, note='', horizon=14, cond=''):
    """time-to-event: day in daycol; one flag column per group holding 1 (event) or 0 (censored)."""
    w = ws(sheet); groups = []; data = {}; rng = {}
    for c in flagcols:
        g = str(w[f'{c}{hdr_row}'].value).strip()
        recs = []
        for r in range(r1, r2+1):
            f = w[f'{c}{r}'].value
            if f is not None:
                recs.append((w[f'{daycol}{r}'].value, int(f), f'{daycol}{r}', f'{c}{r}'))
        rows = [int(x[3][len(c):]) for x in recs]
        groups.append(g); data[g] = recs
        rng[g] = f'{sheet}!{daycol}{min(rows)}:{daycol}{max(rows)} (flags {c}{min(rows)}:{c}{max(rows)})' if rows else f'{sheet}!(none)'
    _add(dict(id=bid, sheet=sheet, label=label, kind='surv', groups=groups, data=data, range=rng, stated_n=stated_n, note=note, horizon=horizon, cond=cond))

def bw(bid, sheet, label, r1, r2, daycol, spans, stated_n=None, note='', pair=None):
    """body weight: day in daycol rows r1..r2; spans = [(name, c1, c2)] one column per animal."""
    w = ws(sheet); groups = []; data = {}; rng = {}
    for g, c1, c2 in spans:
        animals = {}
        for c in range(CI(c1), CI(c2)+1):
            animals[L(c)] = {w[f'{daycol}{r}'].value: w.cell(r, c).value for r in range(r1, r2+1)}
        groups.append(g); data[g] = animals; rng[g] = f'{sheet}!{c1}{r1}:{c2}{r2}'
    _add(dict(id=bid, sheet=sheet, label=label, kind='bw', groups=groups, data=data, range=rng, stated_n=stated_n, note=note, pair=pair))

# ----------------------------------------------------------------------------------------------- S01
G8 = ['Sham','CMP-204','PSLN-212','PSLN-R848','PSLN-212/R848','PSLN-344','PSLN-212(Y)','PSLN-344(Y)']
rep_rows('S01-A_16h', 'S01', 'S01-A n=5 (Ifnb1/16h)', range(3, 11), 'B', 'F', name_col='A', stated_n=5)
rep_rows('S01-A_72h', 'S01', 'S01-A n=5 (Ifnb1/72h)', range(3, 11), 'H', 'L', name_col='G', stated_n=5)
rep_rows('S01-B', 'S01', 'S01-B n=5', range(14, 18), 'B', 'F', stated_n=5)
rep_rows('S01-C', 'S01', 'S01-C n=4', range(20, 22), 'B', 'E', stated_n=4)
tc('S01-D', 'S01', 'S01-D n=5', 24, 28, [('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U')], stated_n=5)
tc('S01-E', 'S01', 'S01-E n=5', 30, 34, [('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U'),('PSLN-344(Y)','V','Z')], stated_n=5)
rep_span('S01-F', 'S01', 'S01-F n=5', 36, [('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U'),('PSLN-344(Y)','V','Z')], stated_n=5)
rep_span('S01-G', 'S01', 'S01-G n=5', 38, [('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U'),('PSLN-344(Y)','V','Z')], stated_n=5)
# ----------------------------------------------------------------------------------------------- S02
rep_cols('S02-A', 'S02', 'S02-A n=5', 2, 3, 7, list('ABCD'), stated_n=5)
rep_cols('S02-B', 'S02', 'S02-B n=5', 2, 3, 7, list('FGHI'), stated_n=5)
rep_cols('S02-C', 'S02', 'S02-C n=5', 2, 3, 7, list('KLMNO'), stated_n=5)
rep_cols('S02-D_CD40', 'S02', 'S02-D CD40 n=5', 9, 10, 14, list('ABCD'), stated_n=5)
rep_cols('S02-D_CD86', 'S02', 'S02-D CD86 n=5', 9, 10, 14, list('FGHI'), stated_n=5)
rep_cols('S02-E', 'S02', 'S02-E n=5', 9, 10, 14, list('KLMNO'), stated_n=5)
tc('S02-F', 'S02', 'S02-F n=5', 17, 19, [('PSLN-344','B','F'),('PSLN-212','G','K'),('Sham','L','P')], stated_n=5, xname='time')
rep_cols('S02-G', 'S02', 'S02-G n=5', 21, 22, 26, list('BCD'), stated_n=5)
rep_cols('S02-H', 'S02', 'S02-H n=5', 29, 30, 34, list('BCDEF'), stated_n=5)
rep_cols('S02-I', 'S02', 'S02-I n=5', 29, 30, 34, list('HI'), stated_n=5)
# ----------------------------------------------------------------------------------------------- S03
rep_cols('S03-A', 'S03', 'S03-A n=5', 2, 3, 7, list('ABCDE'), stated_n=5)
rep_cols('S03-B', 'S03', 'S03-B n=5', 2, 3, 7, list('GHI'), stated_n=5)
rep_cols('S03-C', 'S03', 'S03-C n=5', 2, 3, 7, list('KLMNO'), stated_n=5)
rep_cols('S03-D', 'S03', 'S03-D n=5', 2, 3, 7, list('QRSTU'), stated_n=5)
rep_cols('S03-E', 'S03', 'S03-E n=5', 9, 10, 14, list('ABCDE'), stated_n=5)
rep_cols('S03-F', 'S03', 'S03-F n=5', 9, 10, 14, list('GHI'), stated_n=5)
rep_cols('S03-G', 'S03', 'S03-G n=5', 9, 10, 14, list('KLMNO'), stated_n=5)
rep_cols('S03-H', 'S03', 'S03-H n=5', 9, 10, 14, list('QRSTU'), stated_n=5)
surv('S03-I', 'S03', 'S03-I n=7', 16, 17, 51, 'A', list('BCDEF'), stated_n=7, horizon=14,
     cond='aged BALB/c; bivalent H1N1+H3N2 vaccine (as S03-A); 10x mLD50 CA09 H1N1 on d14 (homologous)')
surv('S03-J', 'S03', 'S03-J n=9', 16, 17, 46, 'G', list('HIJ'), stated_n=9, horizon=22,
     cond='aged BALB/c; rgH5N1 vaccine, single dose; wild-type VN04 H5N1 on d2')
rep_cols('S03-K', 'S03', 'S03-K n=5', 16, 17, 21, list('LMNO'), stated_n=5)
rep_rows('S03-L_Aicda', 'S03', 'S03-L n=3 (Aicda)', range(26, 29), 'L', 'N', name_col='K', stated_n=3)
rep_rows('S03-L_E47', 'S03', 'S03-L n=3 (E47)', range(26, 29), 'O', 'Q', name_col='K', stated_n=3)
# ----------------------------------------------------------------------------------------------- S04
rep_rows('S04-A_ICOSlo', 'S04', 'S04-A n=5 (ICOS-CXCR5+PD1+)', range(2, 6), 'B', 'F', stated_n=5)
rep_rows('S04-A_ICOShi', 'S04', 'S04-A n=5 (ICOS+CXCR5+PD1+)', range(2, 6), 'G', 'K', stated_n=5)
rep_cols('S04-B_Tfr', 'S04', 'S04-B  Foxp3+ in CXCR5+ n=5', 7, 8, 12, list('ABCD'), stated_n=5)
rep_cols('S04-B_ratio', 'S04', 'S04-B  Tfh:Tfr n=5', 14, 15, 19, list('ABCD'), stated_n=5)
rep_cols('S04-C', 'S04', 'S04-C   n=5', 21, 22, 26, list('ABCD'), stated_n=5)
rep_cols('S04-D', 'S04', 'S04-D   n=3', 28, 29, 31, list('ABCD'), stated_n=3)
# ----------------------------------------------------------------------------------------------- S05
tc('S05-A', 'S05', 'S05-A n=3 Lung', 3, 5, [('PSLN-212','B','C'),('PSLN-344','E','F'),('PSLN-212Y','H','I')], stated_n=3)
tc('S05-B', 'S05', 'S05-B n=3 MLN', 8, 10, [('PSLN-212','B','C'),('PSLN-344','E','F'),('PSLN-212Y','H','I')], stated_n=3)
rep_cols('S05-C', 'S05', 'S05-C n=3', 12, 13, 15, list('ABCD'), stated_n=3)
rep_cols('S05-D', 'S05', 'S05-D n=5', 18, 19, 23, list('ABCD'), stated_n=5)
rep_cols('S05-E', 'S05', 'S05-E n=5', 25, 26, 30, list('ABCD'), stated_n=5)
rep_cols('S05-F', 'S05', 'S05-F n=5', 32, 33, 37, list('ABCD'), stated_n=5)
rep_cols('S05-G', 'S05', 'S05-G n=5', 39, 40, 44, list('ABCD'), stated_n=5)
rep_cols('S05-H', 'S05', 'S05-H n=5', 46, 47, 51, list('ABCD'), stated_n=5)
rep_cols('S05-I', 'S05', 'S05-I n=5', 53, 54, 58, list('ABCD'), stated_n=5)
# ----------------------------------------------------------------------------------------------- S06
surv('S06-A', 'S06', 'S06-A n=7', 2, 3, 30, 'A', list('BCDE'), stated_n=7, cond='aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d14 (heterosubtypic)')
surv('S06-B', 'S06', 'S06-B n=7', 2, 3, 30, 'G', list('HIJK'), stated_n=7, cond='aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d3 (heterosubtypic)')
surv('S06-C', 'S06', 'S06-C n=7', 2, 3, 30, 'M', list('NOPQ'), stated_n=7, cond='aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d14 (HA subtype not in vaccine; N1 shared)')
surv('S06-D', 'S06', 'S06-D n=7', 33, 34, 61, 'A', list('BCDE'), stated_n=7, cond='aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d3 (HA subtype not in vaccine; N1 shared)')
surv('S06-E', 'S06', 'S06-E n=7 (rows 32-68)', 33, 34, 68, 'G', list('HIJKL'), stated_n=7, cond='aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d60 (heterosubtypic)')
surv('S06-F', 'S06', 'S06-F n=7 (rows 32-68)', 33, 34, 68, 'M', list('NOPQR'), stated_n=7, cond='aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d60 (HA subtype not in vaccine; N1 shared)')
surv('S06-G', 'S06', 'S06-G n=7', 70, 71, 105, 'A', list('BCDEF'), stated_n=7, cond='aged BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d60 (heterosubtypic)')
surv('S06-E2', 'S06', 'S06-E n=7 (rows 69-105, cols G-K; duplicate label)', 70, 71, 98, 'G', list('HIJK'), stated_n=7, cond='BALB/c infected at 10 mo with 1x mLD50 PR8 or saline; 4 mo later bivalent vaccine; 5x LD50 PR8 H1N1 (challenge day not stated)')
surv('S06-F2', 'S06', 'S06-F n=7 (rows 69-105, cols M-Q; duplicate label)', 70, 71, 98, 'M', list('NOPQ'), stated_n=7, cond='as S06-E2; 5x LD50 Perth H3N2 on d14')
# ----------------------------------------------------------------------------------------------- S07
tc('S07-A', 'S07', 'S07-A n=3', 3, 7, [('PSLN-212','B','D'),('PSLN-344','E','G')], stated_n=3)
rep_cols('S07-B_mono', 'S07', 'S07-B n=5 (CD11b+Ly6C+ Monocytes)', 9, 10, 14, list('BC'), stated_n=5)
rep_cols('S07-B_mac', 'S07', 'S07-B n=5 (Ly6C+ Mphi)', 9, 10, 14, list('EF'), stated_n=5)
rep_cols('S07-C', 'S07', 'S07-C n=5', 15, 16, 20, list('BC'), stated_n=5, note='both columns carry the same printed label')
# ----------------------------------------------------------------------------------------------- S08
tc('S08-A', 'S08', 'S08-A n=3', 3, 7, [('CMP-204','B','D'),('PSLN-212','E','G'),('PSLN-344','H','J'),('PSLN-344/R848','K','M')], stated_n=3, xname='dose_ug')
rep_span('S08-B', 'S08', 'S08-B n=3', 11, [('CMP-204','A','C'),('PSLN-212','D','F'),('PSLN-R848','G','I'),('PSLN-212/R848','J','L'),('PSLN-344','M','O')], stated_n=3)
rep_cols('S08-C', 'S08', 'S08-C n=5', 13, 14, 18, list('ABCD'), stated_n=5)
bw('S08-D', 'S08', 'S08-D n=5', 21, 26, 'A', [('PSLN-212(Y)','B','F'),('CMP-204','G','K'),('PSLN-212','L','P'),('PSLN-344','Q','U'),('PSLN-212/R848','V','Z'),('Vaccine','AA','AE')], stated_n=5)
# ----------------------------------------------------------------------------------------------- S09
AN = ['Ifnb1','Il6','Ccl2','Ccl3','Ccl5','Tnf','Il10']
S9A = [('PBS','B','D'),('CMP-204','E','G'),('PSLN-212','H','J'),('PSLN-R848','K','M'),('PSLN-212/R848','N','P'),('PSLN-344','Q','S'),('PSLN-212(y)','T','V')]
S9B = [('PBS','Y','AA'),('CMP-204','AB','AD'),('PSLN-212','AE','AG'),('PSLN-R848','AH','AJ'),('PSLN-212/R848','AK','AM'),('PSLN-344','AN','AP'),('PSLN-212(y)','AQ','AS')]
for i, a in enumerate(AN):
    rep_span(f'S09-A_p1_{a}', 'S09', f'S09-A 16h n=3 Log10 (cols A-V; {a})', 3+i, S9A, stated_n=3)
    rep_span(f'S09-A_p2_{a}', 'S09', f'S09-A 16h n=3 Log10 (cols X-AS; {a}) [second panel, same printed label]', 3+i, S9B, stated_n=3)
YS = dict(cond_B='young BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d21',
          cond_D='young BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d21',
          cond_F='young BALB/c; bivalent vaccine; 5x mLD50 VN04 rgH5N1 on d180')
surv('S09-B', 'S09', 'S09-B n=8', 11, 12, 35, 'A', list('BCD'), stated_n=8, cond=YS['cond_B'])
bw('S09-C', 'S09', 'S09-C n=8', 12, 19, 'F', [('PSLN-212Y','G','N'),('Sham','O','V'),('PSLN-344Y','W','AD')], stated_n=8, pair='S09-B')
surv('S09-D', 'S09', 'S09-D n=8', 38, 39, 62, 'A', list('BCD'), stated_n=8, cond=YS['cond_D'])
bw('S09-E', 'S09', 'S09-E n=8', 39, 46, 'F', [('PSLN-212Y','G','N'),('Sham','O','V'),('PSLN-344Y','W','AD')], stated_n=8, pair='S09-D')
surv('S09-F', 'S09', 'S09-F n=8', 65, 66, 88, 'A', list('BCD'), stated_n=8, cond=YS['cond_F'])
bw('S09-G', 'S09', 'S09-G n=8', 66, 73, 'F', [('PSLN-212Y','G','N'),('Sham','O','V'),('PSLN-344Y','W','AD')], stated_n=8, pair='S09-F')
# ----------------------------------------------------------------------------------------------- S10
rep_cols('S10-A_Ifnb1', 'S10', 'S10-A n=5 Ifnb1', 2, 3, 7, list('ABCD'), stated_n=5)
rep_cols('S10-A_Tnf', 'S10', 'S10-A n=5 Tnf', 2, 3, 7, list('FGHI'), stated_n=5)
rep_cols('S10-A_Isg15', 'S10', 'S10-A n=5 Isg15', 2, 3, 7, list('KLMN'), stated_n=5)
# ----------------------------------------------------------------------------------------------- S11
S11 = [('Vaccine','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U')]
tc('S11-A', 'S11', 'S11-A n=5', 3, 7, S11, stated_n=5)
tc('S11-B', 'S11', 'S11-B n=5', 10, 14, S11, stated_n=5)
rep_cols('S11-C', 'S11', 'S11-C n=5', 16, 17, 21, list('AB'), stated_n=5)
tc('S11-D', 'S11', 'S11-D n=5', 24, 28, S11, stated_n=5)
rep_cols('S11-E', 'S11', 'S11-E n=5', 30, 31, 35, list('ABCD'), stated_n=5)
# ----------------------------------------------------------------------------------------------- S12
rep_cols('S12-A', 'S12', 'S12-A n=3', 2, 3, 5, list('AB'), stated_n=3)
# ----------------------------------------------------------------------------------------------- S13
rep_cols('S13-A', 'S13', 'S13-A n=5', 2, 3, 7, list('ABC'), stated_n=5)
rep_cols('S13-B', 'S13', 'S13-B n=5', 2, 3, 7, list('EFG'), stated_n=5)
rep_cols('S13-C', 'S13', 'S13-C n=5', 2, 3, 7, list('IJK'), stated_n=5)
rep_cols('S13-D', 'S13', 'S13-D n=5', 2, 3, 7, list('MNO'), stated_n=5)
surv('S13-E', 'S13', 'S13-E n=5', 2, 3, 30, 'R', list('STUV'), stated_n=5, cond='young BALB/c; vaccinated as S03-I; 10x mLD50 CA09 H1N1 on d14 (homologous)')
bw('S13-F', 'S13', 'S13-F n=7', 33, 40, 'A', [('PSLN-212(Y)','B','H'),('Sham','I','O'),('PSLN-212','P','V'),('PSLN-344','W','AC'),('Naïve','AD','AJ')], stated_n=7, pair='S03-I')
bw('S13-G', 'S13', 'S13-G n=10', 43, 50, 'A', [('PSLN-344','B','K'),('Sham','L','U'),('Naïve','V','AE')], stated_n=10, pair='S03-J')
rep_cols('S13-H', 'S13', 'S13-H n=5', 52, 53, 57, list('ABCD'), stated_n=5)
rep_cols('S13-I', 'S13', 'S13-I n=5', 52, 53, 57, list('FGHIJ'), stated_n=5)
rep_cols('S13-J', 'S13', 'S13-J n=5', 52, 53, 57, list('LMNOP'), stated_n=5)
# ----------------------------------------------------------------------------------------------- S14
rep_cols('S14-A_H1N1', 'S14', 'S14-A H1N1 n=5', 2, 3, 7, list('ABCD'), stated_n=5)
rep_cols('S14-A_H3N2', 'S14', 'S14-A H3N2 n=5', 2, 3, 7, list('FGHI'), stated_n=5)
# ----------------------------------------------------------------------------------------------- S15
A4 = [('PSLN-212(Y)','B','H'),('Sham','I','O'),('PSLN-212','P','V'),('PSLN-344','W','AC')]
A5 = A4 + [('Untreated','AD','AJ')]
bw('S15-A', 'S15', 'S15-A  n=7', 3, 10, 'A', A4, stated_n=7, pair='S06-A')
bw('S15-B', 'S15', 'S15-B  n=7', 13, 20, 'A', A4, stated_n=7, pair='S06-B')
bw('S15-C', 'S15', 'S15-C  n=7', 23, 30, 'A', A4, stated_n=7, pair='S06-C')
bw('S15-D', 'S15', 'S15-D  n=7', 33, 40, 'A', A4, stated_n=7, pair='S06-D')
bw('S15-E', 'S15', 'S15-E  n=7', 43, 50, 'A', A5, stated_n=7, pair='S06-E')
bw('S15-F', 'S15', 'S15-F  n=7', 53, 60, 'A', A5, stated_n=7, pair='S06-F')
bw('S15-G', 'S15', 'S15-G  n=7', 63, 70, 'A', A5, stated_n=7, pair='S06-G')
surv('S15-H', 'S15', 'S15-H  n=7', 72, 73, 93, 'A', list('BCD'), stated_n=7, cond='aged BALB/c; bivalent H1N1+H3N2 vaccine alone, PSLN-344 alone, or both, 3 d before 5x mLD50 VN04 rgH5N1')
bw('S15-I', 'S15', 'S15-I  n=7', 72, 79, 'H', [('3d Vaccine','I','O'),('3d PSLN-344','P','V'),('3d Vaccine+PSLN-344','W','AC')], stated_n=7, pair='S15-H')
I4 = [('Naïve+PSLN-212','I','O'),('Imprinting+PSLN-212','P','V'),('Naïve+PSLN-344','W','AC'),('Imprinting+PSLN-344','AD','AJ')]
bw('S15-J', 'S15', 'S15-J n=7', 83, 90, 'H', I4, stated_n=7, pair='S06-E2')
bw('S15-K', 'S15', 'S15-K n=7', 93, 100, 'H', I4, stated_n=7, pair='S06-F2')
surv('S15-L', 'S15', 'S15-L n=7', 102, 103, 130, 'A', list('BCDE'), stated_n=7, cond='aged (20 mo) C57BL/6; bivalent vaccine; challenge virus/day not stated')
M4 = [('PSLN-212(Y)','I','O'),('Sham','P','V'),('PSLN-212','W','AC'),('PSLN-344','AD','AJ')]
bw('S15-M', 'S15', 'S15-M n=7', 103, 110, 'H', M4, stated_n=7, pair='S15-L')
surv('S15-N', 'S15', 'S15-N n=7', 133, 134, 161, 'A', list('BCDE'), stated_n=7, cond='aged (20 mo) Swiss Webster; bivalent vaccine; challenge virus/day not stated')
bw('S15-O', 'S15', 'S15-O n=7', 134, 141, 'H', M4, stated_n=7, pair='S15-N')

if __name__ == '__main__':
    for bid, b in BLOCKS.items():
        if b['kind'] == 'rep':
            s = ' | '.join(f"{g}: n={len(b['data'][g])}" for g in b['groups'])
        elif b['kind'] == 'tc':
            s = ' | '.join(f"{g}: " + ','.join(f"{x}:{len(vv)}" for x, vv in b['data'][g].items()) for g in b['groups'])
        elif b['kind'] == 'surv':
            s = ' | '.join(f"{g}: n={len(b['data'][g])} ev={sum(r[1] for r in b['data'][g])} missing_day={sum(r[0] is None for r in b['data'][g])}" for g in b['groups'])
        else:
            s = ' | '.join(f"{g}: animals={len(b['data'][g])}" for g in b['groups'])
        print(f"{bid:16s} [{b['label']}] stated_n={b['stated_n']} :: {s}")

# Analysis files (PSLN-344 portfolio review)

Run order (Python; `singlecell` env has openpyxl, `core` env has scipy/statsmodels/matplotlib):

| Step | Script | Env | Output |
|---|---|---|---|
| 1 | `blocks.py` | singlecell | parser: every labelled block of the workbook with cell addresses (imported by the others) |
| 2 | `coverage_check.py` | singlecell | confirms every numeric cell is assigned to a block, an axis, or the unlabelled rows S08!A89:D101 |
| 3 | `export_tidy.py` | singlecell | `tidy_values.csv`, `tidy_survival.csv`, `tidy_bodyweight.csv`, `blocks_meta.json` (one row per cell) |
| 4 | `qc_checks.py`, `bw_recon.py`, `surv_dups.py`, `qc_counts.py` | singlecell | the internal-consistency checks behind the QC log |
| 5 | `stats_rep.py` | core | `stats_group_summaries.csv`, `stats_tests.csv`, `stats_twoway_anova.csv` |
| 6 | `stats_survival.py`, `stats_pooled.py` | core | `stats_survival_groups.csv`, `stats_survival_tests.csv`, `stats_survival_pooled.csv` |
| 7 | `stats_bw.py`, `stats_restoration.py`, `power_calcs.py` | core | body-weight summaries, restoration index, sample sizes |
| 8 | `build_ledger.py` | core | `../PSLN-344_numbers_ledger.md`, `numbers_ledger.csv` |
| 9 | `make_figures.py` | core | `../figures/fig1..fig5` |

`independent_spotcheck.py` re-derives the headline numbers straight from workbook cells without using the parser.
`facts.py` prints every number quoted in the memo prose. `qc_log.md` is the QC table included in the ledger.
Nothing in the source workbook was modified.

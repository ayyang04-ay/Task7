"""Exact counts behind the QC log entries."""
import numpy as np, pandas as pd, itertools
from blocks import BLOCKS
from bw_recon import classify
def ser(b, g): return BLOCKS[b]['data'][g]
def cmp_groups(b1, g1, b2, g2, days=None, cols1=None, cols2=None):
    A = ser(b1, g1); B = ser(b2, g2)
    c1 = cols1 or list(A); c2 = cols2 or list(B)
    tot = same = 0; 
    for a, b in zip(c1, c2):
        for d in A[a]:
            if d == 0 or (days and d not in days): continue
            if A[a][d] is None or B[b].get(d) is None: continue
            tot += 1; same += int(A[a][d] == B[b][d])
    return same, tot
print('Q6a S15-C[PSLN-344] vs S15-I[3d Vaccine+PSLN-344], days 2-12:', cmp_groups('S15-C', 'PSLN-344', 'S15-I', '3d Vaccine+PSLN-344', days=[2, 4, 6, 8, 10, 12]), '| day 14:', cmp_groups('S15-C', 'PSLN-344', 'S15-I', '3d Vaccine+PSLN-344', days=[14]))
print('Q6b S09-E[PSLN-344Y] cols X..AD vs S15-M[PSLN-212(Y)] cols I..O:', cmp_groups('S09-E', 'PSLN-344Y', 'S15-M', 'PSLN-212(Y)', cols1=['X', 'Y', 'Z', 'AA', 'AB', 'AC', 'AD'], cols2=['I', 'J', 'K', 'L', 'M', 'N', 'O']))
print('Q6c S09-C day 12 PSLN-212Y vs PSLN-344Y:', cmp_groups('S09-C', 'PSLN-212Y', 'S09-C', 'PSLN-344Y', days=[12]), '| other days:', cmp_groups('S09-C', 'PSLN-212Y', 'S09-C', 'PSLN-344Y', days=[2, 4, 6, 8, 10, 14]))
print('Q6d S15-A[Sham] day 4 vs S15-M[PSLN-212] day 4:', cmp_groups('S15-A', 'Sham', 'S15-M', 'PSLN-212', days=[4]))
print('Q6e S09-E[PSLN-212Y] col N vs S09-G[PSLN-212Y] col N:', cmp_groups('S09-E', 'PSLN-212Y', 'S09-G', 'PSLN-212Y', cols1=['N'], cols2=['N']))
print('Q6f S15-C[PSLN-344] day 14 vs S15-M[PSLN-344] day 14:', cmp_groups('S15-C', 'PSLN-344', 'S15-M', 'PSLN-344', days=[14]))
print('Q6g S15-A[PSLN-344] vs S15-M[PSLN-344]:', cmp_groups('S15-A', 'PSLN-344', 'S15-M', 'PSLN-344'), '| S15-M[PSLN-344] vs S15-O[PSLN-344]:', cmp_groups('S15-M', 'PSLN-344', 'S15-O', 'PSLN-344'), '| S15-A vs S15-O:', cmp_groups('S15-A', 'PSLN-344', 'S15-O', 'PSLN-344'))
# print the raw rows for the clearest duplicate
for b, g in [('S15-C', 'PSLN-344'), ('S15-I', '3d Vaccine+PSLN-344')]:
    A = ser(b, g); print(b, g); 
    for d in [2, 4, 6, 8, 10, 12, 14]: print('   day', d, [A[a][d] for a in A])
# Q7 S11-A vs S11-B
tot = same = 0; firstcol = 0; secondcol = 0
for g in BLOCKS['S11-A']['groups']:
    for x in BLOCKS['S11-A']['data'][g]:
        a = [v for v, c in BLOCKS['S11-A']['data'][g][x]]; b = [v for v, c in BLOCKS['S11-B']['data'][g][x]]
        for i, (u, v) in enumerate(zip(a, b)):
            tot += 1; same += int(u == v)
            if i == 0: firstcol += int(u == v)
            if i == 1: secondcol += int(u == v)
print(f'Q7 S11-A vs S11-B: {same}/{tot} same-position identical values; first replicate column identical in {firstcol}/20 group-days; second replicate column identical in {secondcol}/20')
for g in BLOCKS['S11-A']['groups']:
    s2 = sum(int(BLOCKS['S11-A']['data'][g][x][1][0] == BLOCKS['S11-B']['data'][g][x][1][0]) for x in BLOCKS['S11-A']['data'][g]); s1 = sum(int(BLOCKS['S11-A']['data'][g][x][0][0] == BLOCKS['S11-B']['data'][g][x][0][0]) for x in BLOCKS['S11-A']['data'][g])
    print('   ', g, 'first col identical', s1, '/5 ; second col identical', s2, '/5')
# Q18 timing offsets: for groups where death counts match, compare sorted last-genuine-weight day with sorted death day
off = 0; tot = 0; detail = []
for bid, b in BLOCKS.items():
    if b['kind'] != 'bw' or not b.get('pair'): continue
    sb = BLOCKS[b['pair']]
    for g in b['groups']:
        cand = [sg for sg in sb['groups'] if sg.replace(' ', '') == g.replace(' ', '')]
        if not cand: continue
        deaths = sorted(r[0] for r in sb['data'][cand[0]] if r[1] == 1)
        cl = [classify(s) for s in b['data'][g].values()]
        last = sorted(c['real_last_day'] for c in cl if c['status'] in ('blank', 'locf'))
        if len(last) == len(deaths) and deaths:
            for l, d in zip(last, deaths):
                tot += 1
                if l > d: off += 1; detail.append((bid, g, l, d))
print(f'Q18: among {tot} deaths in arms whose death counts agree, {off} animals have a genuine weight recorded on a day later than their tabulated day of death (sorted pairing)')
from collections import Counter
print('   by block:', Counter(x[0] for x in detail))

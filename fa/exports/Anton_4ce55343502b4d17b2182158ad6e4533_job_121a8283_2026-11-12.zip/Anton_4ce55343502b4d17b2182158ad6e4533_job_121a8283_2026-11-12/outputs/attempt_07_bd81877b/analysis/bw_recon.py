"""Body-weight blocks: classify each animal series, infer deaths, reconcile with the paired time-to-event block,
and search for duplicated series between blocks."""
import numpy as np, itertools
from blocks import BLOCKS

def classify(ser):
    """Classify one animal's body-weight series.
    blank    : cells empty after the last recorded day (animal no longer weighed -> dead/removed)
    locf     : a trailing run of identical values to the end of the series that is either >=3 weigh-ins long, or
               2 weigh-ins long at <90% of baseline  -> treated as a carried-forward last weight (animal dead/removed)
    plateau  : trailing run of exactly 2 identical values at >=90% of baseline -> treated as a genuine measurement
    complete : recorded to the end with no trailing run
    real_last_day = last day holding a genuine (not carried-forward) measurement."""
    days = list(ser.keys()); vals = [ser[d] for d in days]
    obs = [(d, x) for d, x in zip(days, vals) if x is not None]
    last_day, last_val = obs[-1]
    # interior gaps (a blank followed later by a value) are not expected; flag if present
    seen_blank = False; gap = False
    for x in vals:
        if x is None: seen_blank = True
        elif seen_blank: gap = True
    if last_day != days[-1]:
        return dict(status='blank', real_last_day=last_day, nadir=min(x for _, x in obs), last_val=last_val, run=0, gap=gap)
    k = len(vals) - 1
    while k > 0 and vals[k-1] is not None and vals[k-1] == vals[-1]: k -= 1
    run = len(vals) - k
    if days[k] != 0 and (run >= 3 or (run == 2 and last_val < 90)):
        real = [(d, x) for d, x in obs if d <= days[k]]
        return dict(status='locf', real_last_day=days[k], nadir=min(x for _, x in real), last_val=last_val, run=run, gap=gap)
    if days[k] != 0 and run == 2:
        return dict(status='plateau', real_last_day=days[-1], nadir=min(x for _, x in obs), last_val=last_val, run=run, gap=gap)
    return dict(status='complete', real_last_day=days[-1], nadir=min(x for _, x in obs), last_val=last_val, run=run, gap=gap)

def bw_summary(bid):
    b = BLOCKS[bid]; out = {}
    for g in b['groups']:
        out[g] = {a: classify(ser) for a, ser in b['data'][g].items()}
    return out

if __name__ == '__main__':
    print('='*120); print('A. BODY-WEIGHT SERIES CLASSIFICATION AND RECONCILIATION WITH PAIRED SURVIVAL BLOCK'); print('='*120)
    for bid, b in BLOCKS.items():
        if b['kind'] != 'bw': continue
        S = bw_summary(bid); pair = b.get('pair')
        print(f'\n{bid}  ({b["label"]})  paired survival block: {pair}')
        for g in b['groups']:
            cl = S[g]
            n = len(cl); blank = [(a, c['real_last_day']) for a, c in cl.items() if c['status'] == 'blank']
            locf = [(a, c['real_last_day'], c['last_val']) for a, c in cl.items() if c['status'] == 'locf']
            comp = [a for a, c in cl.items() if c['status'] in ('complete', 'plateau')]
            for a, c in cl.items():
                if c['gap']: print('      INTERIOR GAP in series', bid, g, a)
            line = f'   {g:22s} n={n}  complete-to-end={len(comp)}  blank-after(last obs day)={[d for _, d in blank]}  carried-forward-from(day,val)={[(d, x) for _, d, x in locf]}'
            if pair and pair in BLOCKS:
                sb = BLOCKS[pair]
                # match group names
                cand = [sg for sg in sb['groups'] if sg.replace(' ', '') == g.replace(' ', '')]
                if cand:
                    recs = sb['data'][cand[0]]
                    ev = sorted([r[0] for r in recs if r[1] == 1]); cens = len([r for r in recs if r[1] == 0])
                    line += f'\n{"":26s}survival block [{cand[0]}]: deaths on days {ev}; censored={cens}  -> BW-implied deaths={len(blank)+len(locf)} vs survival-table deaths={len(ev)}' + ('' if len(blank)+len(locf) == len(ev) else '   <-- MISMATCH')
                else:
                    line += f'\n{"":26s}survival block has NO group named "{g}" (groups there: {sb["groups"]})   <-- LABEL MISMATCH'
            print(line)
        if pair and pair in BLOCKS:
            extra = [sg for sg in BLOCKS[pair]['groups'] if sg.replace(' ', '') not in [g.replace(' ', '') for g in b['groups']]]
            if extra:
                for sg in extra:
                    recs = BLOCKS[pair]['data'][sg]
                    print(f'   survival group with no BW counterpart: [{sg}] deaths on days {sorted([r[0] for r in recs if r[1]==1])}; censored={len([r for r in recs if r[1]==0])}')

    print(); print('='*120); print('B. DUPLICATED BODY-WEIGHT SERIES (identical same-day values, day 0 excluded) between different groups/blocks'); print('='*120)
    series = []
    for bid, b in BLOCKS.items():
        if b['kind'] != 'bw': continue
        for g in b['groups']:
            for a, ser in b['data'][g].items():
                series.append((bid, g, a, ser))
    hits = []
    for (b1, g1, a1, s1), (b2, g2, a2, s2) in itertools.combinations(series, 2):
        if b1 == b2 and g1 == g2: continue
        days = [d for d in s1 if d != 0 and d in s2 and s1[d] is not None and s2[d] is not None]
        same = [d for d in days if s1[d] == s2[d] and s1[d] != 100]
        if len(same) >= 3:
            hits.append((len(same), len(days), b1, g1, a1, b2, g2, a2, same))
    hits.sort(reverse=True)
    for h in hits:
        print(f'   {h[2]}[{h[3]}] col {h[4]}  ==  {h[5]}[{h[6]}] col {h[7]} : {h[0]}/{h[1]} identical same-day values (days {h[8]})')
    print('   total pairs flagged:', len(hits))

    print(); print('='*120); print('C. Row-level duplication: identical value vectors for a whole group-day between different groups/blocks'); print('='*120)
    rows = []
    for bid, b in BLOCKS.items():
        if b['kind'] != 'bw': continue
        for g in b['groups']:
            days = list(next(iter(b['data'][g].values())).keys())
            for d in days:
                if d == 0: continue
                vec = tuple(b['data'][g][a][d] for a in b['data'][g])
                if sum(x is not None for x in vec) >= 4:
                    rows.append((bid, g, d, vec))
    for (b1, g1, d1, v1), (b2, g2, d2, v2) in itertools.combinations(rows, 2):
        if (b1, g1) == (b2, g2): 
            continue
        n = min(len(v1), len(v2))
        same = sum(1 for i in range(n) if v1[i] is not None and v1[i] == v2[i])
        if same >= 4:
            print(f'   {b1}[{g1}] day {d1} vs {b2}[{g2}] day {d2}: {same}/{n} identical positions')

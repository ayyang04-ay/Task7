"""Body-weight reductions.
  * per-animal nadir = minimum % of day-0 weight over genuine measurements (carried-forward tails and blanks excluded)
  * group nadir = mean (SD) of per-animal nadirs; reported for all animals and for animals weighed to the end (survivors)
  * group mean by day uses genuine measurements only; n is reported because it shrinks as animals die (survivor bias)
"""
import pandas as pd, numpy as np
B = pd.read_csv('tidy_bodyweight.csv', keep_default_na=False)
B['value'] = pd.to_numeric(B['value'], errors='coerce')
B['genuine'] = B['value'].notna() & (B['is_carried_forward'] == 0)
rows = []
for (blk, g), d in B.groupby(['block', 'group'], sort=False):
    an = []
    for a, x in d.groupby('animal_col', sort=False):
        gx = x[x.genuine]
        st = x.series_status.iloc[0]
        an.append(dict(animal=a, status=st, nadir=gx.value.min(), nadir_day=gx.loc[gx.value.idxmin(), 'day'], last_real_day=gx.day.max(), final=gx.value.iloc[-1]))
    A = pd.DataFrame(an)
    surv = A[A.status.isin(['complete', 'plateau'])]
    last_day = d.day.max()
    rows.append(dict(block=blk, paired_survival=d.paired_survival_block.iloc[0], group=g, n=len(A), n_weighed_to_end=len(surv), n_blank=int((A.status == 'blank').sum()), n_carried_forward=int((A.status == 'locf').sum()),
                     nadir_all_mean=A.nadir.mean(), nadir_all_sd=A.nadir.std(ddof=1), nadir_surv_mean=surv.nadir.mean() if len(surv) else np.nan, nadir_surv_sd=surv.nadir.std(ddof=1) if len(surv) > 1 else np.nan,
                     worst_animal_nadir=A.nadir.min(), final_surv_mean=surv.final.mean() if len(surv) else np.nan,
                     cells=f"{d.sheet.iloc[0]}!{d.cell.iloc[0]}:{d.cell.iloc[-1]}"))
R = pd.DataFrame(rows); R.to_csv('stats_bodyweight_groups.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
print(R.round(1).to_string())
# by-day means for S08-D (post-vaccination tolerability)
d = B[(B.block == 'S08-D') & B.genuine]
t = d.groupby(['group', 'day']).value.agg(['mean', 'std', 'min', 'count']).round(2).unstack('day')
print(t['mean']); print(t['min']); print(t['count'])
t.to_csv('stats_S08D_by_day.csv')

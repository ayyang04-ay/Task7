"""Builds the numbers ledger (markdown + csv): every quantity used in the memo, its source cells and its reduction."""
import pandas as pd, numpy as np, json
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
META = json.load(open('blocks_meta.json'))
D = pd.read_csv('tidy_values.csv', keep_default_na=False); D['value'] = D['value'].astype(float)
G = pd.read_csv('stats_group_summaries.csv', keep_default_na=False)
for c in ['mean', 'sd', 'gmt', 'gmt_lo', 'gmt_hi', 'gm_fold', 'n', 'median', 'min', 'max']: G[c] = pd.to_numeric(G[c], errors='coerce')
SG = pd.read_csv('stats_survival_groups.csv'); ST = pd.read_csv('stats_survival_tests.csv'); SP = pd.read_csv('stats_survival_pooled.csv')
RI = pd.read_csv('stats_restoration_index.csv'); BWG = pd.read_csv('stats_bodyweight_groups.csv'); PW = pd.read_csv('power_calcs.csv')
S = pd.read_csv('tidy_survival.csv', keep_default_na=False)
led = []   # csv ledger rows
def add(id_, quantity, value, cells, reduction): led.append(dict(id=id_, quantity=quantity, value=value, source_cells=cells, reduction=reduction))

out = []
w = out.append
w('# PSLN-344 — numbers ledger and QC log\n')
w('Companion to `PSLN-344_portfolio_memo.md`. Every quantity quoted in the memo appears here with the workbook cells it came from and the way it was reduced. '
  'Source: `adjuvant_program_dataset.xlsx` (15 sheets; 6,819 numeric cells; 6,620 parsed into labelled blocks, 173 are day/dose axis values, and 26 sit in the 13 unlabelled rows S08!A89:D101, which were not used). '
  'Scripts and tidy extracts are in `analysis/`; the same ledger is in `analysis/numbers_ledger.csv`.\n')
w('## 0. Reduction rules (applied everywhere)\n')
w('''| Data type | Reduction | Test |
|---|---|---|
| Replicate blocks (flow %, qPCR fold, counts) | arithmetic mean ± SD (n−1) of the per-animal values in the cited cells; n = values present | one-way ANOVA + Tukey HSD (method stated in the annotation); Welch t-test for two-group contrasts; exact Mann–Whitney as a distribution-free check |
| Titres (ELISA endpoint, HAI, neutralisation) | geometric mean titre (GMT) with 95% CI from log10 values; HAI printed as 0 (below the lowest dilution, 1:10) set to 5 | tests on log10 titres |
| log10 blocks (S09-A) | mean of stored log10 values, back-transformed (10^mean = geometric-mean fold) | tests on stored log10 values |
| Time-to-event | survivors = rows with flag 0 ÷ rows in the group; exact (Clopper–Pearson) 95% CI; median survival = first day Kaplan–Meier ≤ 50% | log-rank (stated method) on the rows; Fisher exact (two-sided) on end-of-window survival |
| Pooled survival | sums of survivors and animals over the listed blocks; risk difference with Newcombe 95% CI | log-rank stratified by experiment; Cochran–Mantel–Haenszel |
| Body weight | per-animal nadir over genuine measurements; a trailing run of identical values (≥3 weigh-ins, or 2 weigh-ins below 90%) is treated as a carried-forward last weight, i.e. the animal is counted as lost | descriptive only |
| Restoration index | (mean aged PSLN-344 − mean aged PSLN-212) ÷ (mean young PSLN-212 − mean aged PSLN-212); log10 scale for titres; bootstrap 95% CI (5,000 resamples of animals, seed 1) | Welch t-tests for the two component contrasts |
| IgG2a/IgG1 | per-animal quotient of the S13 subclass titres (row-wise), then mean ± SD | — |

Group labels are used exactly as printed unless the QC log (section 6) says otherwise. "Aged" = groups without a (Y) suffix; "(Y)" = young.\n''')

# ---------------------------------------------------------------- L1 survival by arm
w('## 1. Time-to-event blocks — every arm\n')
w('| Block | Conditions (from annotation) | Group (as printed) | Survivors / n | % (95% CI) | Death days | Median survival (d) | Cells (days; flags in the group column) |')
w('|---|---|---|---|---|---|---|---|')
for _, r in SG.iterrows():
    dd = r.death_days if isinstance(r.death_days, str) else '—'
    ms = '>window' if np.isinf(r.median_survival_d) else f'{r.median_survival_d:.0f}'
    note = f' (stated n={int(r.stated_n)})' if int(r.stated_n) != int(r.n) else ''
    miss = ' ; 1 row without a day' if r.n_missing_day else ''
    w(f"| {r.block} | {r.conditions} | {r.group} | {int(r.survivors)}/{int(r.n)}{note} | {r.survival_pct:.0f} ({r.ci_lo:.0f}–{r.ci_hi:.0f}) | {dd} | {ms} | {r.cells}{miss} |")
    add(f'SV|{r.block}|{r.group}', f'survival, {r.block}, {r.group}', f'{int(r.survivors)}/{int(r.n)} ({r.survival_pct:.0f}%; {r.ci_lo:.0f}-{r.ci_hi:.0f})', r.cells, 'rows with flag 0 / rows; Clopper-Pearson CI')
w('')
w('### 1b. Pairwise tests used in the memo (log-rank on rows; Fisher exact on end-of-window survival)\n')
w('| Block | Contrast | Survivors | Log-rank χ² | Log-rank p | Fisher p |')
w('|---|---|---|---|---|---|')
for _, r in ST.iterrows():
    if 'PSLN-344' in r.contrast or r.block in ('S15-H',) or (r.block == 'S03-I' and 'CMP-204' in r.contrast) or ('Untreated' in r.contrast) or (r.block in ('S06-E2', 'S06-F2')) or (r.block == 'S03-I' and r.contrast == 'Sham vs PSLN-212'):
        chi = '—' if pd.isna(r.logrank_chi2) else f'{r.logrank_chi2:.2f}'; p = '— (no deaths in either arm)' if pd.isna(r.logrank_p) else f'{r.logrank_p:.2g}'
        w(f'| {r.block} | {r.contrast} | {r.surv1} vs {r.surv2} | {chi} | {p} | {r.fisher_p:.2g} |')
        add(f'ST|{r.block}|{r.contrast}', f'log-rank / Fisher, {r.block}, {r.contrast}', f'log-rank p={p}; Fisher p={r.fisher_p:.2g}', f'rows of both arms in {r.block}', 'Mantel-Cox log-rank; Fisher exact two-sided')
w('')
# ---------------------------------------------------------------- L2 pooled
w('## 2. Pooled survival analyses\n')
w('p values are asymptotic (chi-square on 1 d.f.). Values below about 1e-10 mean "far below any threshold" and should not be read as exact probabilities.\n')
w('| ID | Analysis (blocks pooled) | Test arm | Control arm | Risk difference, points (95% CI) | Stratified log-rank p | CMH p | Crude Fisher p |')
w('|---|---|---|---|---|---|---|---|')
def fp(p):
    if pd.isna(p): return '—'
    return f'{p:.1e}'
for _, r in SP.iterrows():
    if pd.isna(r.get('strat_logrank_p')):
        w(f"| {r.analysis.split('.')[0]} | {r.analysis.split('. ', 1)[1]} | {r.test_surv} (100%) | {r.ctrl_surv} (100%) | 0 | — (no deaths) | — | — |"); continue
    w(f"| {r.analysis.split('.')[0]} | {r.analysis.split('. ', 1)[1]} | {r.test_surv} ({r.test_pct:.0f}%; {r.test_ci.replace('-', '–')}) | {r.ctrl_surv} ({r.ctrl_pct:.0f}%; {r.ctrl_ci.replace('-', '–')}) | {r.risk_diff_pct:.0f} ({r.rd_ci}) | {fp(r.strat_logrank_p)} | {fp(r.cmh_p)} | {fp(r.crude_fisher_p)} |")
    add(f"PS|{r.analysis.split('.')[0]}", r.analysis, f'{r.test_surv} vs {r.ctrl_surv}; stratified log-rank p={fp(r.strat_logrank_p)}', 'sum over the blocks named; see section 1 for cells', 'pooled counts; stratified log-rank; CMH; Newcombe CI')
w('')
w('Additional pooled counts quoted in the memo (sums of section-1 rows):\n')
w('| Quantity | Value | Blocks |')
w('|---|---|---|')
def pool(blocks, arm):
    x = SG[SG.block.isin(blocks) & (SG.group == arm)]; s, n = int(x.survivors.sum()), int(x.n.sum()); lo, hi = proportion_confint(s, n, method='beta'); return s, n, f'{s}/{n} ({100*s/n:.0f}%; {100*lo:.0f}–{100*hi:.0f})'
extra = [
 ('Fully heterosubtypic challenges (no shared HA or NA subtype), PSLN-344', ['S06-A', 'S06-B', 'S06-E', 'S06-G'], 'PSLN-344'),
 ('… same, vaccine + empty liposome', ['S06-A', 'S06-B', 'S06-E', 'S06-G'], 'Sham'), ('… same, PSLN-212', ['S06-A', 'S06-B', 'S06-E', 'S06-G'], 'PSLN-212'), ('… same, young PSLN-212', ['S06-A', 'S06-B', 'S06-E', 'S06-G'], 'PSLN-212(Y)'),
 ('H1N1+H3N2 vaccine → rgH5N1 (shared N1), PSLN-344', ['S06-C', 'S06-D', 'S06-F'], 'PSLN-344'), ('… same, PSLN-212', ['S06-C', 'S06-D', 'S06-F'], 'PSLN-212'),
 ('Challenge 14 d after vaccination, PSLN-344', ['S03-I', 'S06-A', 'S06-C'], 'PSLN-344'), ('… same, PSLN-212', ['S03-I', 'S06-A', 'S06-C'], 'PSLN-212'),
 ('Challenge 60 d after vaccination, PSLN-344', ['S06-E', 'S06-F', 'S06-G'], 'PSLN-344'), ('… same, untreated unchallenged', ['S06-E', 'S06-F', 'S06-G'], 'Untreated'), ('… same, young PSLN-212', ['S06-E', 'S06-F', 'S06-G'], 'PSLN-212(Y)'),
 ('Matched designs, day 14 (S06-A, S06-C), PSLN-344', ['S06-A', 'S06-C'], 'PSLN-344'), ('Matched designs, day 60 (S06-E, S06-F), PSLN-344', ['S06-E', 'S06-F'], 'PSLN-344'),
 ('Five experiments with no label or duplication flag on the table (S06-A, B, E, F, G), PSLN-344', ['S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G'], 'PSLN-344'),
 ('… same, vaccine + empty liposome', ['S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G'], 'Sham'), ('… same, PSLN-212', ['S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G'], 'PSLN-212'),
 ('Without S06-C and S06-D (7 experiments), PSLN-344', ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G'], 'PSLN-344'), ('… same, vaccine + empty liposome', ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G'], 'Sham'),
 ('… same, PSLN-212', ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-E', 'S06-F', 'S06-G'], 'PSLN-212'),
 ('Other strains (S15-L, S15-N), PSLN-344', ['S15-L', 'S15-N'], 'PSLN-344'), ('… same, vaccine + empty liposome', ['S15-L', 'S15-N'], 'Sham'), ('… same, PSLN-212', ['S15-L', 'S15-N'], 'PSLN-212'),
 ('Young PSLN-212 across the 8 BALB/c experiments with a young arm', ['S03-I', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G'], 'PSLN-212(Y)'),
 ('Young BALB/c, PSLN-344Y (S09-B, D, F)', ['S09-B', 'S09-D', 'S09-F'], 'PSLN-344Y'), ('Young BALB/c, PSLN-212Y (S09-B, D, F)', ['S09-B', 'S09-D', 'S09-F'], 'PSLN-212Y')]
for q, bl, arm in extra:
    s, n, txt = pool(bl, arm); w(f"| {q} | {txt} | {', '.join(bl)} |"); add(f'PX|{q}', q, txt, ', '.join(bl), 'sum of survivors / sum of animals; Clopper-Pearson CI')
ft = [('Day 14 (20/21) vs day 60 (14/21), aged PSLN-344', [[20, 1], [14, 7]]), ('Matched designs day 14 (13/14) vs day 60 (10/14), aged PSLN-344', [[13, 1], [10, 4]]), ('Day 60: aged PSLN-344 (14/21) vs untreated unchallenged (17/21)', [[14, 7], [17, 4]]),
      ('Day 60: aged PSLN-344 (14/21) vs young PSLN-212 (21/21)', [[14, 7], [21, 0]]), ('S06-D lower count: PSLN-344 5/7 vs Sham 0/7', [[5, 2], [0, 7]]), ('S03-I alternative reading: PSLN-344 7/7 vs PSLN-212 3/7', [[7, 0], [3, 4]])]
w('\n| Extra Fisher exact tests (two-sided) | p |')
w('|---|---|')
for q, tab in ft:
    p = stats.fisher_exact(tab)[1]; w(f'| {q} | {p:.3g} |'); add(f'FX|{q}', q, f'p={p:.3g}', 'counts as stated', 'Fisher exact two-sided')
w('\nWorst-case arm-by-arm count for PSLN-344 in the 9 aged BALB/c experiments (lower of time-to-event table and body-weight-implied survivors): 7+10+6+5+7+**5**+5+5+4 = **54/66 (82%)**; best case (higher of the two): 58/66.\n')

# ---------------------------------------------------------------- L3 group summaries
w('## 3. Replicate and time-course blocks — group summaries\n')
w('Mean ± SD (n). GMT [95% CI] for titre blocks; geometric-mean fold for the log10 block S09-A. "x" is the day, hour or dose for time-course/dose blocks.\n')
w('| Block | Label as printed | Group | x | n | Mean ± SD | GMT [95% CI] or GM fold | Cells |')
w('|---|---|---|---|---|---|---|---|')
for _, r in G.iterrows():
    extra_ = ''
    if not pd.isna(r.gmt): extra_ = f'{r.gmt:,.0f} [{r.gmt_lo:,.0f}–{r.gmt_hi:,.0f}]'
    elif not pd.isna(r.gm_fold): extra_ = f'{r.gm_fold:.1f}×'
    dec = 3 if abs(r['mean']) < 10 else (2 if abs(r['mean']) < 100 else 0)
    sn = f' (stated {int(r.stated_n)})' if int(r.stated_n) != int(r.n) else ''
    w(f"| {r.block} | {r.label} | {r.group} | {r.x} | {int(r.n)}{sn} | {r['mean']:.{dec}f} ± {r.sd:.{dec}f} | {extra_} | {r.cells} |")
    add(f'GS|{r.block}|{r.group}|{r.x}', f'{r.label}; {r.group}' + (f'; x={r.x}' if r.x != '' else ''), f"{r['mean']:.{dec}f} ± {r.sd:.{dec}f} (n={int(r.n)})" + (f'; {extra_}' if extra_ else ''), r.cells, 'mean ± SD; GMT on log10 / 10^mean(log10) where shown')
w('')
w('### 3b. Two-way ANOVA (group × time or dose) for the time-course blocks, as named in the annotation\n')
AOV = pd.read_csv('stats_twoway_anova.csv')
w('| Block | Term | F | d.f. (term, residual) | p |')
w('|---|---|---|---|---|')
for _, r in AOV.iterrows():
    term = {'C(group)': 'group', 'C(xx)': 'time / dose', 'C(group):C(xx)': 'group × time'}[r.term]
    w(f'| {r.block} | {term} | {r.F:.1f} | {int(r.df)}, {int(r.resid_df)} | {r.p:.1e} |')
    add(f'AOV|{r.block}|{term}', f'two-way ANOVA, {r.block}, {term}', f'F={r.F:.1f}; p={r.p:.1e}', f'all cells of {r.block}', 'type II two-way ANOVA with interaction')
w('')
# ---------------------------------------------------------------- L4 derived
w('## 4. Derived quantities\n')
w('### 4a. Restoration index (aged PSLN-344 relative to aged PSLN-212 = 0 and young PSLN-212 = 1)\n')
w('| Readout | Block | n (212 / 344 / young) | Aged PSLN-212 | Aged PSLN-344 | Young PSLN-212 | 344 ÷ 212 | 344 as % of young | Restoration index (95% CI) | Welch p, 344 vs 212 | Welch p, 344 vs young |')
w('|---|---|---|---|---|---|---|---|---|---|---|')
for _, r in RI.sort_values('restoration_index', ascending=False).iterrows():
    sc = ' (log10)' if r['scale'] == 'log10 titre' else ''
    w(f"| {r.readout} | {r.key} | {r.n} | {r.psln212_aged:.2f}{sc} | {r.psln344_aged:.2f}{sc} | {r.psln212_young:.2f}{sc} | {r.ratio_344_vs_212:.2f}× | {r.pct_of_young:.0f}% | {r.restoration_index:.2f} ({r.ri_lo:.2f}–{r.ri_hi:.2f}) | {r.p_344_vs_212_welch:.2g} | {r.p_344_vs_young_welch:.2g} |")
    add(f'RI|{r.key}', f'restoration index, {r.readout}', f'{r.restoration_index:.2f} ({r.ri_lo:.2f}-{r.ri_hi:.2f}); 344/212 = {r.ratio_344_vs_212:.2f}x; {r.pct_of_young:.0f}% of young', f'group cells of {r.key.split("@")[0]} (section 3)', 'see reduction rules')
keep = RI[~RI.key.isin(['S05-A@3', 'S05-A@7', 'S01-A_72h', 'S01-G'])]
w(f"\nSummary over {len(keep)} readouts (excluding the two n=2 tetramer rows, the 72-h Ifnb1 row, which measures resolution rather than response, and cDC2, which is the complement of cDC1): median {keep.restoration_index.median():.2f}, inter-quartile range {keep.restoration_index.quantile(.25):.2f}–{keep.restoration_index.quantile(.75):.2f}, range {keep.restoration_index.min():.2f} (CD40 on DCs) to {keep.restoration_index.max():.2f} (Ifnb1 16 h). "
  f"PSLN-344 differs from aged PSLN-212 at Welch p<0.05 in {(keep.p_344_vs_212_welch < 0.05).sum()} of {len(keep)} (exception: Tfr at day 30) and remains below the young benchmark at p<0.05 in {(keep.p_344_vs_young_welch < 0.05).sum()} of {len(keep)}.\n")
add('RI|summary', 'restoration index summary', f'median {keep.restoration_index.median():.2f}; IQR {keep.restoration_index.quantile(.25):.2f}-{keep.restoration_index.quantile(.75):.2f}; n={len(keep)}', 'section 4a rows', 'median / quartiles of indices')
w('### 4b. IgG2a/IgG1 quotient recomputed from the subclass titres (S13-A÷S13-B; S13-C÷S13-D), per animal\n')
w('| Antigen | Group | Quotients (animals 1–5) | Mean ± SD | Value printed under that header in S03-B / S03-F |')
w('|---|---|---|---|---|')
for a, b1, nm, pb in [('S13-A', 'S13-B', 'CA09 H1N1', 'S03-B'), ('S13-C', 'S13-D', 'Aichi H3N2', 'S03-F')]:
    for grp in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        x = D[(D.block == a) & (D.group == grp)].value.values / D[(D.block == b1) & (D.group == grp)].value.values
        pr = D[(D.block == pb) & (D.group == grp)].value.values
        w(f"| {nm} | {grp} | {', '.join(f'{v:.2f}' for v in x)} | {x.mean():.2f} ± {x.std(ddof=1):.2f} | {pr.mean():.2f} ± {pr.std(ddof=1):.2f} |")
        add(f'IG|{nm}|{grp}', f'IgG2a/IgG1, {nm}, {grp} (recomputed)', f'{x.mean():.2f} ± {x.std(ddof=1):.2f}', f"{META[a]['range'][grp]} / {META[b1]['range'][grp]}", 'row-wise quotient, then mean ± SD')
w('\n### 4c. HAI: animals at or above a threshold (day 14)\n')
w('| Block | Group | Titres | ≥40 | ≥160 |')
w('|---|---|---|---|---|')
for b in ['S03-C', 'S03-G']:
    for grp in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        v = D[(D.block == b) & (D.group == grp)].value.values
        w(f"| {b} | {grp} | {', '.join(str(int(t)) for t in v)} | {(v >= 40).sum()}/{len(v)} | {(v >= 160).sum()}/{len(v)} |")
        add(f'HAI|{b}|{grp}', f'HAI >=40 and >=160, {b}, {grp}', f'{(v >= 40).sum()}/{len(v)}; {(v >= 160).sum()}/{len(v)}', META[b]['range'][grp], 'count of animals at or above threshold')
w('\n### 4d. Single dose (day 14) versus prime–boost (day 28, boost on day 14): serum IgG GMT (different animals)\n')
w('| Antigen | Group | GMT day 14 | GMT day 28 after boost | Ratio |')
w('|---|---|---|---|---|')
def gg(b, grp): return G[(G.block == b) & (G.group == grp)].iloc[0]
for b14, b28, nm in [('S03-A', 'S13-I', 'CA09 H1N1'), ('S03-E', 'S13-J', 'Aichi H3N2')]:
    for grp in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        a, b = gg(b14, grp).gmt, gg(b28, grp).gmt; w(f'| {nm} | {grp} | {a:,.0f} | {b:,.0f} | {b/a:.1f}× |')
        add(f'PB|{nm}|{grp}', f'prime vs prime-boost IgG GMT, {nm}, {grp}', f'{a:,.0f} -> {b:,.0f} ({b/a:.1f}x)', f'{b14}, {b28} group cells', 'ratio of GMTs')
w('\n### 4e. Sample-size calculations used for the proposed studies (exact power of a two-sided Fisher test, α = 0.05)\n')
w('| Comparison (assumed survival) | n/arm for 80% power | n/arm for 90% power | Power at n=7 | Power at n=12 |')
w('|---|---|---|---|---|')
for _, r in PW.iterrows():
    w(f'| {r.comparison} | {int(r.n_per_arm_80)} | {int(r.n_per_arm_90)} | {r.power_at_n7:.2f} | {r.power_at_n12:.2f} |')
    add(f'PW|{r.comparison}', f'sample size: {r.comparison}', f'n={int(r.n_per_arm_80)} (80%), n={int(r.n_per_arm_90)} (90%); power at n=7 = {r.power_at_n7:.2f}', 'assumptions stated', 'exact power, Fisher two-sided alpha 0.05')
w('')
# ---------------------------------------------------------------- L5 body weight
w('## 5. Body-weight blocks\n')
w('Supportive only (see QC items Q5 and Q6). "Lost" = blank after last weigh-in or carried-forward last weight. Nadir = lowest genuine weight, % of day 0.\n')
w('| Block | Paired survival block | Group | n | Weighed to end | Lost | Mean nadir, all (SD) | Mean nadir, animals weighed to end (SD) | Lowest animal | Cells |')
w('|---|---|---|---|---|---|---|---|---|---|')
for _, r in BWG.iterrows():
    ps = r.paired_survival if isinstance(r.paired_survival, str) else '—'
    ns = '—' if pd.isna(r.nadir_surv_mean) else f'{r.nadir_surv_mean:.1f}' + ('' if pd.isna(r.nadir_surv_sd) else f' ({r.nadir_surv_sd:.1f})')
    w(f'| {r.block} | {ps} | {r.group} | {int(r.n)} | {int(r.n_weighed_to_end)} | {int(r.n_blank + r.n_carried_forward)} | {r.nadir_all_mean:.1f} ({r.nadir_all_sd:.1f}) | {ns} | {r.worst_animal_nadir:.1f} | {r.cells} |')
    add(f'BW|{r.block}|{r.group}', f'body weight, {r.block}, {r.group}', f'weighed to end {int(r.n_weighed_to_end)}/{int(r.n)}; mean nadir {r.nadir_all_mean:.1f}; survivors {ns}', r.cells, 'per-animal nadir over genuine measurements')
t = pd.read_csv('stats_S08D_by_day.csv', header=[0, 1], index_col=0)
w('\nS08-D, body weight after vaccination (no challenge), mean % of day 0 by day (n=5; PSLN-212/R848 n=4 on day 10; cells S08!B21:AE26):\n')
w('| Group | d2 | d4 | d6 | d8 | d10 | Lowest single animal (day) |')
w('|---|---|---|---|---|---|---|')
B = pd.read_csv('tidy_bodyweight.csv', keep_default_na=False); B['value'] = pd.to_numeric(B['value'], errors='coerce')
for grp in ['Vaccine', 'PSLN-212(Y)', 'PSLN-212', 'CMP-204', 'PSLN-344', 'PSLN-212/R848']:
    d = B[(B.block == 'S08-D') & (B.group == grp) & B.value.notna()]; m = d.groupby('day').value.mean(); i = d.value.idxmin()
    w(f"| {grp} | {m[2]:.1f} | {m[4]:.1f} | {m[6]:.1f} | {m[8]:.1f} | {m[10]:.1f} | {d.loc[i, 'value']:.1f} (d{d.loc[i, 'day']}) |")
    add(f'BW|S08-D|{grp}|by-day', f'S08-D mean weight by day, {grp}', '; '.join(f'd{k}: {m[k]:.1f}' for k in [2, 4, 6, 8, 10]), META['S08-D']['range'][grp], 'mean of animals weighed that day')
w('\nS08-D contrasts (Welch t-test on the animals weighed that day):\n')
w('| Day | PSLN-344 − Vaccine, points | p | PSLN-344 − PSLN-212, points | p |')
w('|---|---|---|---|---|')
for day in [2, 4, 6, 8, 10]:
    dd = B[(B.block == 'S08-D') & (B.day == day) & B.value.notna()]
    a = dd[dd.group == 'PSLN-344'].value; v = dd[dd.group == 'Vaccine'].value; q = dd[dd.group == 'PSLN-212'].value
    p1 = stats.ttest_ind(a, v, equal_var=False).pvalue; p2 = stats.ttest_ind(a, q, equal_var=False).pvalue
    w(f'| {day} | {a.mean() - v.mean():+.1f} | {p1:.2g} | {a.mean() - q.mean():+.1f} | {p2:.2g} |')
    add(f'BW|S08-D|contrast|d{day}', f'S08-D day {day}: PSLN-344 minus Vaccine; PSLN-344 minus PSLN-212', f'{a.mean() - v.mean():+.1f} (p={p1:.2g}); {a.mean() - q.mean():+.1f} (p={p2:.2g})', 'S08!Q21:U26, S08!AA21:AE26, S08!L21:P26', 'difference of means; Welch t-test')
w('')
# ---------------------------------------------------------------- L6 QC
w('## 6. QC log — internal inconsistencies found in the workbook\n')
w('Nothing in the workbook was altered. Each item can be reproduced with `analysis/qc_checks.py`, `analysis/bw_recon.py`, `analysis/surv_dups.py` and `analysis/qc_counts.py`.\n')
w(open('qc_log.md').read())
open('/tmp/outputs/PSLN-344_numbers_ledger.md', 'w').write('\n'.join(out) + '\n')
pd.DataFrame(led).to_csv('numbers_ledger.csv', index=False)
print('ledger rows:', len(led), '| md lines:', len(out))

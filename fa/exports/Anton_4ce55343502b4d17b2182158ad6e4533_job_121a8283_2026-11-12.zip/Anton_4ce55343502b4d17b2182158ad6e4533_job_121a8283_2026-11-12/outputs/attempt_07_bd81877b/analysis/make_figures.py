"""Figures for the PSLN-344 memo. All values are recomputed from tidy_*.csv (which carry cell-level provenance)."""
import pandas as pd, numpy as np, json, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from statsmodels.stats.proportion import proportion_confint
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150, 'savefig.bbox': 'tight'})
OUT = '/tmp/outputs/figures/'
S = pd.read_csv('tidy_survival.csv', keep_default_na=False); S['day'] = pd.to_numeric(S['day'], errors='coerce'); S.loc[S.day.isna(), 'day'] = 14
D = pd.read_csv('tidy_values.csv', keep_default_na=False); D['value'] = D['value'].astype(float)
B = pd.read_csv('tidy_bodyweight.csv', keep_default_na=False); B['value'] = pd.to_numeric(B['value'], errors='coerce')
COL = {'Sham': '#7f7f7f', 'PSLN-212': '#e08a2c', 'PSLN-344': '#c0392b', 'PSLN-212(Y)': '#2471a3', 'CMP-204': '#8e6bbf', 'Untreated': '#2e8b57', 'Naive': '#444444'}

# ------------------------------------------------------------------ Fig 1: survival overview
EXP = [  # block, label, timing group, (arm name -> canonical)
 ('S03-J', 'wild-type H5N1, 2 d after rgH5N1 vaccine (n=10)', 'Challenge 2-3 d after vaccination', {'Sham': 'Sham', 'PSLN-212': 'PSLN-212', 'PSLN-344': 'PSLN-344'}),
 ('S06-B', 'PR8 H1N1, 3 d after H3N2 vaccine', '', None), ('S06-D', 'rgH5N1, 3 d after H1N1+H3N2 vaccine', '', None),
 ('S15-H', 'rgH5N1, 3 d after H1N1+H3N2 vaccine (repeat design)', '', {'3d Vaccine': 'Sham', '3d Vaccine+PSLN-344': 'PSLN-344'}),
 ('S03-I', 'CA09 H1N1 (10x LD50), homologous', 'Challenge 14 d after vaccination', None), ('S06-A', 'PR8 H1N1 after H3N2 vaccine', '', None), ('S06-C', 'rgH5N1 after H1N1+H3N2 vaccine', '', None),
 ('S06-E', 'PR8 H1N1 after H3N2 vaccine', 'Challenge 60 d after vaccination', None), ('S06-F', 'rgH5N1 after H1N1+H3N2 vaccine', '', None), ('S06-G', 'Perth H3N2 after H1N1 vaccine', '', None),
 ('S15-L', 'C57BL/6, 20 months (challenge not annotated)', 'Other strains', None), ('S15-N', 'Swiss Webster, 20 months (challenge not annotated)', '', None)]
fig, ax = plt.subplots(figsize=(13.5, 7.2))
off = {'Sham': 0.30, 'PSLN-212': 0.10, 'PSLN-344': -0.10, 'PSLN-212(Y)': -0.30, 'Untreated': -0.42}
xcol = {'Sham': 114, 'PSLN-212': 131, 'PSLN-344': 148, 'PSLN-212(Y)': 165, 'Untreated': 182}
ypos = []; yy = 0
for i, (blk, lab, hdr, mp) in enumerate(EXP):
    if hdr:
        yy += 0.9; ax.text(-88, yy - 0.75, hdr, fontsize=8.5, fontweight='bold', va='center')
    ypos.append(yy); d = S[S.block == blk]
    mp = mp or {g: g for g in d.group.unique() if g in off}
    for g, canon in mp.items():
        x = d[d.group == g]; n = len(x); a = int((x.event == 0).sum())
        lo, hi = proportion_confint(a, n, method='beta')
        ax.errorbar(100*a/n, yy + off[canon], xerr=[[100*(a/n - lo)], [100*(hi - a/n)]], fmt='o' if canon != 'Untreated' else 'D', color=COL[canon], ms=8 if canon == 'PSLN-344' else 5,
                    capsize=2, lw=1.6 if canon == 'PSLN-344' else 0.9, alpha=1 if canon == 'PSLN-344' else 0.8, zorder=3 if canon == 'PSLN-344' else 2)
        ax.text(xcol[canon], yy, f'{a}/{n}', ha='center', va='center', fontsize=8, color=COL[canon], fontweight='bold' if canon == 'PSLN-344' else 'normal')
    ax.text(-88, yy, f'{blk}  {lab}', fontsize=7.8, va='center')
    yy += 1
ax.set_ylim(yy - 0.4, -1.8); ax.set_xlim(-89, 192); ax.set_yticks([])
ax.set_xticks([0, 25, 50, 75, 100]); ax.set_xlabel('Survival at end of observation, % (exact 95% CI)', x=0.495)
ax.spines['left'].set_visible(False); ax.axvline(0, color='#dddddd', lw=0.8, zorder=0); ax.axvline(100, color='#dddddd', lw=0.8, zorder=0)
for k, lab in [('Sham', 'aged\nvaccine +\nempty lipo.'), ('PSLN-212', 'aged\nPSLN-212\n(no Mn)'), ('PSLN-344', 'aged\nPSLN-344\n(Mn)'), ('PSLN-212(Y)', 'young\nPSLN-212'), ('Untreated', 'aged, no\nvaccine, no\nchallenge')]:
    ax.text(xcol[k], -0.95, lab, ha='center', va='center', fontsize=7.3, color=COL[k], fontweight='bold')
ax.text(148, -1.62, 'survivors / animals', ha='center', fontsize=7.5, color='#555555')
ax.set_title('Fig 1. Survival after lethal influenza challenge in aged mice given one intranasal dose (group labels as printed in the workbook)', fontsize=10, loc='left', pad=16)
fig.savefig(OUT + 'fig1_survival_overview.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 2: KM panels
def km(t, e, horizon):
    t = np.asarray(t, float); e = np.asarray(e, int); xs = [0]; ys = [1.0]; s = 1.0
    for ti in np.unique(t[e == 1]):
        n = (t >= ti).sum(); dd = ((t == ti) & (e == 1)).sum(); xs += [ti, ti]; ys += [s, s * (1 - dd / n)]; s *= 1 - dd / n
    xs.append(horizon); ys.append(s); return xs, ys
PAN = ['S03-J', 'S06-B', 'S06-D', 'S15-H', 'S03-I', 'S06-A', 'S06-C', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N', 'S06-E2', 'S06-F2', 'S13-E', 'S09-F']
META = json.load(open('blocks_meta.json'))
C2 = dict(COL); C2.update({'3d Vaccine': COL['Sham'], '3d PSLN-344': '#d4a017', '3d Vaccine+PSLN-344': COL['PSLN-344'], 'Naïve+PSLN-212': '#f0b27a', 'Imprinting+PSLN-212': '#a04000', 'Naïve+PSLN-344': '#f1948a', 'Imprinting+PSLN-344': '#7b241c',
           'Naïve': '#444444', 'CMP-204(Y)': '#8e6bbf', 'PSLN-344(Y)': '#641e16', 'PSLN-344Y': '#641e16', 'PSLN-212Y': COL['PSLN-212(Y)']})
SHORT = {'S03-J': 'aged BALB/c | rgH5N1 vaccine -> wild-type H5N1 at d2', 'S06-B': 'aged BALB/c | H3N2 vaccine -> PR8 H1N1 at d3', 'S06-D': 'aged BALB/c | H1N1+H3N2 vaccine -> rgH5N1 at d3',
         'S15-H': 'aged BALB/c | components vs combination -> rgH5N1 at d3', 'S03-I': 'aged BALB/c | homologous CA09 H1N1 (10x LD50) at d14', 'S06-A': 'aged BALB/c | H3N2 vaccine -> PR8 H1N1 at d14',
         'S06-C': 'aged BALB/c | H1N1+H3N2 vaccine -> rgH5N1 at d14', 'S06-E': 'aged BALB/c | H3N2 vaccine -> PR8 H1N1 at d60', 'S06-F': 'aged BALB/c | H1N1+H3N2 vaccine -> rgH5N1 at d60',
         'S06-G': 'aged BALB/c | H1N1 vaccine -> Perth H3N2 at d60', 'S15-L': 'aged C57BL/6 (20 mo) | challenge not annotated', 'S15-N': 'aged Swiss Webster (20 mo) | challenge not annotated',
         'S06-E2': '14-mo BALB/c, PR8-imprinted or not | PR8 H1N1 challenge', 'S06-F2': '14-mo BALB/c, PR8-imprinted or not | Perth H3N2 at d14',
         'S13-E': 'young BALB/c | homologous CA09 H1N1 (10x LD50) at d14', 'S09-F': 'young BALB/c | H1N1+H3N2 vaccine -> rgH5N1 at d180'}
fig, axs = plt.subplots(4, 4, figsize=(15.5, 12.5)); axs = axs.ravel()
for ax, blk in zip(axs, PAN):
    d = S[S.block == blk]; hz = META[blk]['horizon']
    for k, g in enumerate(META[blk]['groups']):
        x = d[d.group == g]; xs, ys = km(x.day, x.event, hz)
        ax.plot(xs, np.array(ys) * 100 + (k - 2) * 0.8, color=C2.get(g, 'k'), lw=1.8, label=f'{g} ({int((x.event == 0).sum())}/{len(x)})')
    ax.set_ylim(-6, 108); ax.set_xlim(0, hz + 0.5); ax.set_title(f'{blk}  {SHORT[blk]}', fontsize=7.6, loc='left')
    ax.legend(fontsize=6.3, frameon=True, framealpha=0.75, edgecolor='none', loc='center left', bbox_to_anchor=(0.0, 0.36)); ax.set_xlabel('days after challenge', fontsize=7); ax.set_ylabel('% surviving', fontsize=7)
    ax.tick_params(labelsize=7)
fig.suptitle('Fig 2. Kaplan-Meier curves for every time-to-event block used (curves offset by <1% vertically so overlapping lines stay visible; labels as printed; survivors/n in legend)', fontsize=10, x=0.01, ha='left')
fig.tight_layout(rect=[0, 0, 1, 0.97]); fig.savefig(OUT + 'fig2_km_panels.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 3: restoration index
R = pd.read_csv('stats_restoration_index.csv')
R = R[~R.key.isin(['S05-A@3', 'S05-A@7', 'S01-A_72h', 'S01-G'])].copy()
cat = {}
for k in R.key:
    if k.startswith(('S01-A', 'S01-D', 'S11-E')): cat[k] = 'innate / myeloid'
    elif k.startswith(('S01-E', 'S01-F', 'S01-G', 'S02')): cat[k] = 'dendritic cells'
    elif k.startswith(('S05', 'S14')): cat[k] = 'CD8 T cells'
    elif k.startswith(('S04-B', 'S04-C', 'S04-D')): cat[k] = 'regulatory T cells'
    else: cat[k] = 'Tfh / B cell / antibody'
R['cat'] = R.key.map(cat)
CC = {'innate / myeloid': '#5d6d7e', 'dendritic cells': '#d68910', 'CD8 T cells': '#c0392b', 'regulatory T cells': '#7d3c98', 'Tfh / B cell / antibody': '#2471a3'}
R = R.sort_values('restoration_index')
fig, ax = plt.subplots(figsize=(9, 9.5))
y = np.arange(len(R))
ax.barh(y, R.restoration_index, color=[CC[c] for c in R.cat], alpha=0.85)
ax.errorbar(R.restoration_index, y, xerr=[R.restoration_index - R.ri_lo, R.ri_hi - R.restoration_index], fmt='none', ecolor='k', lw=0.8, capsize=2)
ax.set_yticks(y); ax.set_yticklabels([f'{r.readout}  [{r.key}]' for r in R.itertuples()], fontsize=7.5)
ax.axvline(0, color='k', lw=0.8); ax.axvline(1, color='k', lw=0.8, ls='--'); ax.set_xlim(-0.1, 1.6)
ax.text(0.0, len(R) + 0.1, 'aged PSLN-212\n(Mn-free parent)', ha='center', fontsize=7.5); ax.text(1.0, len(R) + 0.1, 'young PSLN-212\n(benchmark)', ha='center', fontsize=7.5)
ax.set_xlabel('Restoration index = (aged PSLN-344 - aged PSLN-212) / (young PSLN-212 - aged PSLN-212); bootstrap 95% CI')
ax.legend(handles=[Line2D([], [], marker='s', ls='', color=c, label=l) for l, c in CC.items()], frameon=False, fontsize=8, loc='lower right')
fig.suptitle(f'Fig 3. How much of the young-aged gap PSLN-344 closes, by readout (median {R.restoration_index.median():.2f} over {len(R)} readouts; n=5/group unless noted)', fontsize=9.5, x=0.02, ha='left', y=0.965)
fig.savefig(OUT + 'fig3_restoration_index.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 4: tolerability
fig, axs = plt.subplots(1, 3, figsize=(16, 4.6), gridspec_kw={'width_ratios': [1.0, 1.5, 0.9], 'wspace': 0.28})
ax = axs[0]
d = B[(B.block == 'S08-D') & B.value.notna()]
CT = {'Vaccine': '#7f7f7f', 'CMP-204': '#8e6bbf', 'PSLN-212': '#e08a2c', 'PSLN-344': '#c0392b', 'PSLN-212/R848': '#111111', 'PSLN-212(Y)': '#2471a3'}
for g in ['Vaccine', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212/R848', 'PSLN-212(Y)']:
    x = d[d.group == g].groupby('day').value.agg(['mean', 'std', 'count'])
    ax.errorbar(x.index, x['mean'], yerr=x['std'], color=CT[g], marker='o', ms=3, lw=1.6 if g in ('PSLN-344', 'PSLN-212/R848') else 1, capsize=2, label=g)
ax.axhline(100, color='#bbbbbb', lw=0.6); ax.set_xlabel('days after intranasal vaccination'); ax.set_ylabel('body weight (% of day 0), mean ± SD'); ax.legend(frameon=False, fontsize=7.5, loc='lower left')
ax.set_title('A. Body weight after vaccination (S08-D; n=5)', fontsize=8.5, loc='left')
ax = axs[1]
AN = ['Ifnb1', 'Il6', 'Tnf', 'Il10', 'Ccl2', 'Ccl3', 'Ccl5']; GR = [('PSLN-212', '#e08a2c'), ('PSLN-344', '#c0392b'), ('PSLN-212(y)', '#2471a3'), ('PSLN-212/R848', '#111111')]
w = 0.1
for ai, a in enumerate(AN):
    for gi, (g, c) in enumerate(GR):
        for pi, (p, hatch) in enumerate([('p1', None), ('p2', '////')]):
            vals = D[(D.block == f'S09-A_{p}_{a}') & (D.group == g)].value.values
            xpos = ai + (gi * 2 + pi - 3.5) * w
            ax.bar(xpos, vals.mean(), width=w, color=c if pi == 0 else 'white', edgecolor=c, hatch=hatch, lw=0.8)
            ax.plot([xpos] * len(vals), vals, 'k.', ms=2)
ax.axhline(0, color='k', lw=0.6); ax.set_xticks(range(len(AN))); ax.set_xticklabels(AN, style='italic'); ax.set_ylabel('lung mRNA, log10 fold vs untreated\n(bars = mean; dots = animals, n=3)', fontsize=8)
hh = [plt.Rectangle((0, 0), 1, 1, color=c, label=g.replace('(y)', '(Y) young')) for g, c in GR] + [plt.Rectangle((0, 0), 1, 1, fc='white', ec='k', hatch='////', label='second panel (= 72 h by cross-check with S01-A)')]
ax.legend(handles=hh, frameon=False, fontsize=7, ncol=2, loc='upper left')
ax.set_title('B. Lung cytokine/chemokine mRNA: 16 h (solid), 72 h (hatched) (S09-A)', fontsize=8.5, loc='left'); ax.set_ylim(-1.4, 4.3)
ax = axs[2]
for ai, a in enumerate(['Ifnb1', 'Tnf', 'Isg15']):
    for gi, (g, c) in enumerate([('PBS', '#bbbbbb'), ('Sham', '#7f7f7f'), ('PSLN-344', '#c0392b'), ('CT', '#1e8449')]):
        vals = D[(D.block == f'S10-A_{a}') & (D.group == g)].value.values
        xpos = ai + (gi - 1.5) * 0.2
        ax.bar(xpos, vals.mean(), yerr=vals.std(ddof=1), width=0.2, color=c, capsize=2, error_kw={'lw': 0.8}, label=g if ai == 0 else None)
        ax.plot([xpos] * len(vals), vals, 'k.', ms=2)
ax.set_xticks(range(3)); ax.set_xticklabels(['Ifnb1', 'Tnf', 'Isg15'], style='italic'); ax.set_ylabel('CNS mRNA, fold vs untreated (mean ± SD, n=5)'); ax.legend(frameon=False, fontsize=7.5)
ax.set_title('C. CNS mRNA at 36 h (S10-A); CT = cholera toxin', fontsize=8.5, loc='left')
fig.suptitle('Fig 4. All of the tolerability evidence in the package', fontsize=11, x=0.01, ha='left'); fig.subplots_adjust(top=0.86, left=0.05, right=0.99, bottom=0.12)
fig.savefig(OUT + 'fig4_tolerability.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 5: mechanism / Mn-specific signals
fig, axs = plt.subplots(2, 4, figsize=(15, 7))
def bars(ax, block, groups, title, ylabel, x=None, log=False, colors=None):
    for i, g in enumerate(groups):
        d = D[(D.block == block) & (D.group == g)]
        if x is not None: d = d[d.x.astype(str) == str(x)]
        v = d.value.values
        c = (colors or {}).get(g, COL.get(g, '#888888'))
        ax.bar(i, v.mean(), yerr=v.std(ddof=1), color=c, capsize=2, alpha=0.85, error_kw={'lw': 0.8}); ax.plot([i] * len(v), v, 'k.', ms=3)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(groups, rotation=30, ha='right', fontsize=7); ax.set_title(title, fontsize=8.3, loc='left'); ax.set_ylabel(ylabel, fontsize=7.5)
    if log: ax.set_yscale('log')
ax = axs[0, 0]
for g, c in [('CMP-204', COL['CMP-204']), ('PSLN-212', COL['PSLN-212']), ('PSLN-344', COL['PSLN-344']), ('PSLN-344/R848', '#111111')]:
    d = D[(D.block == 'S08-A') & (D.group == g)].copy(); d['x'] = d.x.astype(float)
    m = d.groupby('x').value.agg(['mean', 'std']); ax.errorbar(m.index, m['mean'], yerr=m['std'], marker='o', ms=3, color=c, capsize=2, label=g)
ax.set_xscale('log'); ax.set_xticks([1, 5, 10, 20, 40]); ax.set_xticklabels(['1', '5', '10', '20', '40']); ax.set_xlabel('dose (µg/animal)', fontsize=7.5); ax.set_ylabel('lung Ifnb1, fold (16 h)', fontsize=7.5); ax.legend(frameon=False, fontsize=7)
ax.set_title('A. Dose-response of Ifnb1 (S08-A, n=3; age not stated)', fontsize=8.3, loc='left')
ax = axs[0, 1]
for g, c in [('Sham', COL['Sham']), ('PSLN-212', COL['PSLN-212']), ('PSLN-344', COL['PSLN-344'])]:
    d = D[(D.block == 'S02-F') & (D.group == g)]; m = d.groupby('x', sort=False).value.agg(['mean', 'std'])
    ax.errorbar([16, 36, 72], m['mean'], yerr=m['std'], marker='o', ms=3, color=c, capsize=2, label=g)
ax.set_xlabel('hours after vaccination', fontsize=7.5); ax.set_ylabel('lung Gm-csf, fold', fontsize=7.5); ax.legend(frameon=False, fontsize=7); ax.set_xticks([16, 36, 72])
ax.set_title('B. Gm-csf is induced by PSLN-344 only (S02-F, n=5)', fontsize=8.3, loc='left')
bars(axs[0, 2], 'S02-G', ['GM-CSF', 'PSLN-212', 'PSLN-212+GM-CSF'], 'C. rGM-CSF add-back to PSLN-212 (S02-G)', 'lung Ly6C+CD11c+MHC-II+ cells, d5 (%)', colors={'GM-CSF': '#2e8b57', 'PSLN-212+GM-CSF': '#a04000'})
bars(axs[0, 3], 'S02-H', ['WT w/o cDC', 'WT w/ cDC', 'IFN w/o cDC', 'IFN w/ cDC', 'GMCSF'], 'D. Donor-BM moDC need IFNAR; GM-CSF partly rescues (S02-H)', 'CD45.2+ moDC, d3 (%)',
     colors={'WT w/o cDC': '#2471a3', 'WT w/ cDC': '#2471a3', 'IFN w/o cDC': '#922b21', 'IFN w/ cDC': '#922b21', 'GMCSF': '#2e8b57'})
ax = axs[1, 0]
for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
    d = D[(D.block == 'S01-D') & (D.group == g)].copy(); d['x'] = d.x.astype(float); m = d.groupby('x').value.agg(['mean', 'std'])
    ax.errorbar(m.index, m['mean'], yerr=m['std'], marker='o', ms=3, color=COL[g], capsize=2, label=g)
ax.set_xlabel('days after vaccination', fontsize=7.5); ax.set_ylabel('lung monocytes (%)', fontsize=7.5); ax.legend(frameon=False, fontsize=7); ax.set_title('E. Monocyte influx (S01-D, n=5)', fontsize=8.3, loc='left')
bars(axs[1, 1], 'S02-I', ['PSLN-344(Y)', 'PSLN-344(Y)+INCB3344'], 'F. CCR2 blockade removes lung GZMB+ CD8 T (S02-I; young)', 'lung GZMB+ CD8 T, d5 (%)', colors={'PSLN-344(Y)': '#641e16', 'PSLN-344(Y)+INCB3344': '#bbbbbb'})
bars(axs[1, 2], 'S05-F', ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)'], 'G. Cross-reactive IFN-γ+ CD8 T, d14 (S05-F; rgH5N1 restim)', 'MLN IFN-γ+ CD8 T (%)')
bars(axs[1, 3], 'S05-G', ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)'], 'H. ... and at d60 (S05-G)', 'MLN IFN-γ+ CD8 T (%)')
fig.suptitle('Fig 5. What Mn adds in aged lungs, and the monocyte-derived-DC / CD8 T-cell axis (bars = mean ± SD, dots = animals)', fontsize=11, x=0.01, ha='left')
fig.tight_layout(rect=[0, 0, 1, 0.95]); fig.savefig(OUT + 'fig5_mechanism.png'); plt.close(fig)
print('figures written')

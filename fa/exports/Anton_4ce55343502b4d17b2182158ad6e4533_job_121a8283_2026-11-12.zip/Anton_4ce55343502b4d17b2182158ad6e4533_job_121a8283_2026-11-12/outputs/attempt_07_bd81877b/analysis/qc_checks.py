"""QC / internal-consistency checks on the workbook. Prints findings; nothing is altered."""
import numpy as np, itertools, math
from blocks import BLOCKS, ws

def vals(bid, g): return [x[0] for x in BLOCKS[bid]['data'][g]]

print('='*110); print('1. STATED n vs OBSERVED n (rep/tc/surv blocks)'); print('='*110)
for bid, b in BLOCKS.items():
    sn = b['stated_n']
    if b['kind'] == 'rep':
        obs = {g: len(b['data'][g]) for g in b['groups']}
    elif b['kind'] == 'tc':
        obs = {f'{g}@{x}': len(vv) for g in b['groups'] for x, vv in b['data'][g].items()}
    elif b['kind'] == 'surv':
        obs = {g: len(b['data'][g]) for g in b['groups']}
    else:
        obs = {}
        for g in b['groups']:
            obs[g] = len(b['data'][g])
            for a, ser in b['data'][g].items():
                d0 = list(ser.keys())[0]
                if ser[d0] is None: print('   BW animal with no day-0 value', bid, g, a)
    bad = {k: n for k, n in obs.items() if n != sn}
    if bad:
        ks = sorted(set(bad.values()))
        print(f'{bid:14s} stated n={sn}; observed differs for {len(bad)}/{len(obs)} cells: ' + ', '.join(f'{k}={n}' for k, n in list(bad.items())[:8]) + (' ...' if len(bad) > 8 else ''))

print(); print('='*110); print('2. DERIVED-COLUMN CHECKS'); print('='*110)
# 2a IgG2a/IgG1 quotients
for ratio_b, a_b, g1_b, virus in [('S03-B', 'S13-A', 'S13-B', 'CA09 H1N1'), ('S03-F', 'S13-C', 'S13-D', 'Aichi H3N2')]:
    print(f'-- {ratio_b} (printed IgG2a/IgG1 quotient, {virus}) vs recomputed {a_b}/{g1_b}')
    rec = {}
    for g in BLOCKS[a_b]['groups']:
        a = np.array(vals(a_b, g)); g1 = np.array(vals(g1_b, g)); rec[g] = a / g1
        print(f'   recomputed {g:12s}: ' + ', '.join(f'{x:.6f}' for x in rec[g]) + f'   mean={rec[g].mean():.3f}')
    for g in BLOCKS[ratio_b]['groups']:
        p = np.array(vals(ratio_b, g))
        match = [h for h in rec if np.allclose(np.sort(rec[h]), np.sort(p), rtol=1e-4)]
        print(f'   printed    {g:12s}: ' + ', '.join(f'{x:.6f}' for x in p) + f'   mean={p.mean():.3f}   == recomputed column of: {match}')
# 2b Tfh:Tfr
print('-- S04-B Tfh:Tfr vs (100 - Foxp3+%)/Foxp3+% from S04-B Foxp3+ in CXCR5+')
for g in BLOCKS['S04-B_Tfr']['groups']:
    t = np.array(vals('S04-B_Tfr', g)); r = np.array(vals('S04-B_ratio', g))
    print(f'   {g:12s} max abs diff = {np.max(np.abs((100-t)/t - r)):.2e}')
print('-- S04-A ICOS-low + ICOS-high = total CXCR5+PD1+ (per animal)')
for g in BLOCKS['S04-A_ICOSlo']['groups']:
    lo = np.array(vals('S04-A_ICOSlo', g)); hi = np.array(vals('S04-A_ICOShi', g))
    print(f'   {g:12s} totals: ' + ', '.join(f'{x:.2f}' for x in lo+hi) + '   ICOS-high fraction: ' + ', '.join(f'{x:.2f}' for x in hi/(lo+hi)))
# 2c S09-A vs S01-A
print('-- S09-A Ifnb1 rows (log10) vs log10 of S01-A (linear). For each S09-A value: nearest log10(S01-A) value in the same-named group')
m = {'PBS': 'Sham', 'PSLN-212(y)': 'PSLN-212(Y)'}
for panel, ref in [('S09-A_p1_Ifnb1', 'S01-A_16h'), ('S09-A_p2_Ifnb1', 'S01-A_16h'), ('S09-A_p1_Ifnb1', 'S01-A_72h'), ('S09-A_p2_Ifnb1', 'S01-A_72h')]:
    tot = 0; hit = 0
    for g in BLOCKS[panel]['groups']:
        rg = m.get(g, g); lr = np.log10(np.array(vals(ref, rg)))
        for x in vals(panel, g):
            tot += 1; hit += int(np.min(np.abs(lr - x)) < 0.003)
    print(f'   {panel} vs {ref}: {hit}/{tot} values match a log10-transformed {ref} value within 0.003')
print('-- S08-A (dose series) at 20 ug vs S01-A 16 h means')
for g in ['CMP-204', 'PSLN-212', 'PSLN-344']:
    a = np.mean([x[0] for x in BLOCKS['S08-A']['data'][g][20]])
    print(f'   {g:10s} S08-A@20ug mean={a:.2f} | S01-A_16h aged mean={np.mean(vals("S01-A_16h", g)):.2f}' + (f' | young mean={np.mean(vals("S01-A_16h", g+"(Y)")):.2f}' if g+'(Y)' in BLOCKS['S01-A_16h']['groups'] else ''))
# 2d SRB
print('-- S01-B vs S08-C (SRB uptake by alveolar epithelial cells)')
for g in BLOCKS['S01-B']['groups']: print(f'   S01-B {g:22s}', vals('S01-B', g), f'mean={np.mean(vals("S01-B", g)):.2f}')
for g in BLOCKS['S08-C']['groups']: print(f'   S08-C {g:22s}', vals('S08-C', g), f'mean={np.mean(vals("S08-C", g)):.2f}')

print(); print('='*110); print('3. DUPLICATED VALUES BETWEEN BLOCKS/GROUPS (non-body-weight blocks)'); print('='*110)
# collect group vectors
vecs = []
for bid, b in BLOCKS.items():
    if b['kind'] == 'rep':
        for g in b['groups']: vecs.append((bid, g, None, [x[0] for x in b['data'][g]], [x[1] for x in b['data'][g]]))
    elif b['kind'] == 'tc':
        for g in b['groups']:
            for x, vv in b['data'][g].items(): vecs.append((bid, g, x, [t[0] for t in vv], [t[1] for t in vv]))
for (b1, g1, x1, v1, c1), (b2, g2, x2, v2, c2) in itertools.combinations(vecs, 2):
    if len(v1) < 3 or len(v2) < 3: continue
    # position-wise identical values
    same_pos = sum(1 for a, b in zip(v1, v2) if a == b)
    shared = len(set(v1) & set(v2))
    # ignore low-information integer titre blocks (2-fold dilution series share values by construction)
    lowinfo = all(float(a).is_integer() for a in v1 + v2)
    if (same_pos >= 2 or shared >= 3) and not lowinfo:
        print(f'   {b1}[{g1}{"" if x1 is None else "@"+str(x1)}] {c1[0]}..{c1[-1]} vs {b2}[{g2}{"" if x2 is None else "@"+str(x2)}] {c2[0]}..{c2[-1]}: same-position identical={same_pos}, shared values={shared}  | {v1} vs {v2}')

"""'Restoration index' for every readout that has the three arms PSLN-212 (aged), PSLN-344 (aged), PSLN-212(Y) (young):
      RI = (mean PSLN-344 - mean PSLN-212) / (mean PSLN-212(Y) - mean PSLN-212)
   0 = no better than the Mn-free parent in aged animals; 1 = equal to the young benchmark.
   Titre blocks use log10 GMT. 95% CI by non-parametric bootstrap of animals within group (5,000 resamples; seed 1)."""
import pandas as pd, numpy as np, json
from scipy import stats
D = pd.read_csv('tidy_values.csv', keep_default_na=False); D['value'] = D['value'].astype(float)
META = json.load(open('blocks_meta.json'))
TITRE = ['S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-A', 'S13-B', 'S13-C', 'S13-D', 'S13-I', 'S13-J']
HAI = ['S03-C', 'S03-G']
DESC = {
 'S01-A_16h': 'Lung Ifnb1 mRNA, 16 h (fold)', 'S01-A_72h': 'Lung Ifnb1 mRNA, 72 h (fold)', 'S01-D@4': 'Lung monocytes, d4 (%)', 'S01-E@4': 'Lung CD11b+ DC, d4 (%)',
 'S01-F': 'Lung cDC1, 72 h (%)', 'S01-G': 'Lung cDC2, 72 h (%)', 'S02-A': 'Lung migratory CCR7+ CD11b+ DC, 72 h (%)', 'S02-B': 'MLN CD11b+CD103- DC, 72 h (%)',
 'S02-C': 'MLN antigen(OVA-AF647)+ DC, 36 h (%)', 'S02-D_CD40': 'CD40+ of MLN CD11b+ DC, d3 (%)', 'S02-D_CD86': 'CD86+ of MLN CD11b+ DC, d3 (%)',
 'S02-E': 'Ex vivo OT-I priming by MLN CD11b+ DC (% divided)', 'S03-A': 'Serum IgG anti-CA09, d14 (log10 GMT)', 'S03-C': 'HAI anti-CA09, d14 (log10 GMT)',
 'S03-D': 'Neutralising titre anti-CA09, d14 (log10 GMT)', 'S03-E': 'Serum IgG anti-Aichi, d14 (log10 GMT)', 'S03-G': 'HAI anti-Aichi, d14 (log10 GMT)',
 'S03-H': 'Neutralising titre anti-Aichi, d14 (log10 GMT)', 'S03-K': 'MLN GC B cells, d7 (%)', 'S04-A_ICOShi': 'MLN ICOS-hi Tfh, d7 (%)', 'S04-A_ICOSlo': 'MLN ICOS-lo Tfh, d7 (%)',
 'S04-B_Tfr': 'MLN Tfr (Foxp3+ of CXCR5+), d7 (%)', 'S04-C': 'MLN Tfr, d30 (%)', 'S04-D': 'Lung Treg, d7 (%) [n=3]', 'S05-D': 'Lung Ki-67+ CD8 T, d3 (%)', 'S05-E': 'Lung GZMB+ CD8 T, d3 (%)',
 'S05-F': 'MLN IFN-g+ CD8 T, rgH5N1 restim, d14 (%)', 'S05-G': 'MLN IFN-g+ CD8 T, rgH5N1 restim, d60 (%)', 'S05-H': 'MLN GZMB+ CD8 T, d60 (%)', 'S05-I': 'Lung CD8 TRM, d25 (%)',
 'S11-E': 'Lung CD206+ macrophages (%)', 'S13-A': 'Serum IgG2a anti-CA09, d14 (log10 GMT)', 'S13-B': 'Serum IgG1 anti-CA09, d14 (log10 GMT)', 'S13-C': 'Serum IgG2a anti-Aichi, d14 (log10 GMT)',
 'S13-D': 'Serum IgG1 anti-Aichi, d14 (log10 GMT)', 'S13-H': 'IgG+ of MLN B220+ cells (%)', 'S13-I': 'Serum IgG anti-CA09, d28 post-boost (log10 GMT)', 'S13-J': 'Serum IgG anti-Aichi, d28 post-boost (log10 GMT)',
 'S14-A_H1N1': 'MLN IFN-g+ CD8 T, CA09 restim (%)', 'S14-A_H3N2': 'MLN IFN-g+ CD8 T, Aichi restim (%)', 'S05-A@3': 'Lung NP-tetramer+ CD8 T, d3 (%) [n=2]', 'S05-A@7': 'Lung NP-tetramer+ CD8 T, d7 (%) [n=2]',
}
def get(block, g, x=None):
    d = D[(D.block == block) & (D.group == g)]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    v = d.value.values.copy()
    if block in HAI: v[v <= 0] = 5.0
    if block in TITRE: v = np.log10(v)
    return v
rng = np.random.default_rng(1)
rows = []
for key, desc in DESC.items():
    block, x = (key.split('@') + [None])[:2]
    gs = META[block]['groups']
    y = 'PSLN-212(Y)' if 'PSLN-212(Y)' in gs else ('PSLN-212Y' if 'PSLN-212Y' in gs else None)
    if y is None or 'PSLN-344' not in gs or 'PSLN-212' not in gs: continue
    a, b, c = get(block, 'PSLN-212', x), get(block, 'PSLN-344', x), get(block, y, x)
    ri = (b.mean() - a.mean()) / (c.mean() - a.mean())
    bs = []
    for _ in range(5000):
        aa, bb, cc = rng.choice(a, len(a)), rng.choice(b, len(b)), rng.choice(c, len(c))
        den = cc.mean() - aa.mean()
        if abs(den) > 1e-9: bs.append((bb.mean() - aa.mean()) / den)
    lo, hi = np.percentile(bs, [2.5, 97.5])
    t_ab = stats.ttest_ind(b, a, equal_var=False); t_bc = stats.ttest_ind(b, c, equal_var=False)
    sham = get(block, 'Sham', x) if 'Sham' in gs else None
    rows.append(dict(key=key, readout=desc, n=f'{len(a)}/{len(b)}/{len(c)}', sham=(sham.mean() if sham is not None else np.nan), psln212_aged=a.mean(), psln344_aged=b.mean(), psln212_young=c.mean(),
                     ratio_344_vs_212=(10**(b.mean()-a.mean()) if block in TITRE else b.mean()/a.mean()),
                     pct_of_young=(100*10**(b.mean()-c.mean()) if block in TITRE else 100*b.mean()/c.mean()),
                     restoration_index=ri, ri_lo=lo, ri_hi=hi, p_344_vs_212_welch=t_ab.pvalue, p_344_vs_young_welch=t_bc.pvalue, scale=('log10 titre' if block in TITRE else 'linear')))
R = pd.DataFrame(rows); R.to_csv('stats_restoration_index.csv', index=False)
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 100); pd.set_option('display.max_colwidth', 60)
print(R.round(3).to_string())
print('\nmedian RI (all):', R.restoration_index.median().round(2), '| n readouts:', len(R), '| RI<0.5:', R[R.restoration_index < 0.5].key.tolist())

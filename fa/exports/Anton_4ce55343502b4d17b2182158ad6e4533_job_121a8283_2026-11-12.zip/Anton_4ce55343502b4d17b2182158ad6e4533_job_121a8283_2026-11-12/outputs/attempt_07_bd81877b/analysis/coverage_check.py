"""Every numeric cell in the workbook must belong to exactly one parsed block (or be an x-axis/day value). Lists anything else."""
import openpyxl, re
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI
from blocks import BLOCKS, XLSX
wb = openpyxl.load_workbook(XLSX, data_only=True)
used = {}   # (sheet, cell) -> block id
def mark(sheet, cell, bid):
    k = (sheet, cell)
    if k in used and used[k] != bid:
        print('DOUBLE-USE', k, used[k], bid)
    used[k] = bid
for bid, b in BLOCKS.items():
    s = b['sheet']
    if b['kind'] == 'rep':
        for g in b['groups']:
            for val, cell in b['data'][g]: mark(s, cell, bid)
    elif b['kind'] == 'tc':
        for g in b['groups']:
            for x, vv in b['data'][g].items():
                for val, cell in vv: mark(s, cell, bid)
    elif b['kind'] == 'surv':
        for g in b['groups']:
            for day, ev, cd, cf in b['data'][g]:
                mark(s, cd, bid); mark(s, cf, bid)
    elif b['kind'] == 'bw':
        for g in b['groups']:
            rng = b['range'][g].split('!')[1]
            m = re.match(r'([A-Z]+)(\d+):([A-Z]+)(\d+)', rng)
            c1, r1, c2, r2 = m.group(1), int(m.group(2)), m.group(3), int(m.group(4))
            for c in range(CI(c1), CI(c2)+1):
                for r in range(r1, r2+1):
                    mark(s, f'{L(c)}{r}', bid)
n_num = 0; unc = []
for w in wb.worksheets:
    for row in w.iter_rows():
        for c in row:
            if isinstance(c.value, (int, float)):
                n_num += 1
                if (w.title, c.coordinate) not in used:
                    unc.append((w.title, c.coordinate, c.value))
print('numeric cells in workbook:', n_num, '| covered by parsed blocks:', n_num - len(unc), '| uncovered:', len(unc))
from collections import defaultdict
d = defaultdict(list)
for s, c, val in unc: d[s].append((c, val))
for s in d: print(s, d[s])

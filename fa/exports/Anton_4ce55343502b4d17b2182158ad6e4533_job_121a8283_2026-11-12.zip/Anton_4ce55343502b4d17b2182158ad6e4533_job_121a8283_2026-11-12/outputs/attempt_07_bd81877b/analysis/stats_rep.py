"""Summary statistics and tests for replicate-type and time-course blocks.
Reductions (stated once, applied everywhere):
  * group summary = arithmetic mean, SD (n-1), n of the per-animal values in the cited cell range
  * titre blocks (ELISA endpoint, HAI, neutralisation): geometric mean titre (GMT) with 95% CI on log10 scale;
    HAI values printed as 0 are below the lowest dilution tested (1:10) and are set to 5 (half the LLOQ) before logs
  * log10 blocks (S09-A): mean of log10 values, back-transformed to geometric-mean fold (10**mean)
  * tests: one-way ANOVA + Tukey HSD (the method stated in the annotation) on the scale indicated; Welch t-test for
    two-group blocks and as a robustness check; exact Mann-Whitney as a distribution-free check
"""
import pandas as pd, numpy as np, json, itertools, warnings
from scipy import stats
warnings.filterwarnings('ignore')
D = pd.read_csv('tidy_values.csv', keep_default_na=False)
D['value'] = D['value'].astype(float)
META = json.load(open('blocks_meta.json'))

TITRE = ['S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-A', 'S13-B', 'S13-C', 'S13-D', 'S13-I', 'S13-J']
HAI = ['S03-C', 'S03-G']
LOG10 = [b for b in META if b.startswith('S09-A')]

def tvals(block, group, x=None):
    d = D[(D.block == block) & (D.group == group)]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    return d.value.values

def summarize(v, titre=False, hai=False, log10=False):
    v = np.asarray(v, float); n = len(v)
    out = dict(n=n, mean=v.mean(), sd=v.std(ddof=1) if n > 1 else np.nan, median=np.median(v), min=v.min(), max=v.max())
    out['sem'] = out['sd'] / np.sqrt(n) if n > 1 else np.nan
    if n > 1:
        tcrit = stats.t.ppf(0.975, n-1); out['ci_lo'] = out['mean'] - tcrit*out['sem']; out['ci_hi'] = out['mean'] + tcrit*out['sem']
    if titre:
        w = v.copy()
        if hai: w[w <= 0] = 5.0
        lw = np.log10(w); m = lw.mean(); s = lw.std(ddof=1)
        tcrit = stats.t.ppf(0.975, n-1)
        out.update(gmt=10**m, gmt_lo=10**(m - tcrit*s/np.sqrt(n)), gmt_hi=10**(m + tcrit*s/np.sqrt(n)), n_below_lloq=int((v <= 0).sum()) if hai else 0)
    if log10:
        out.update(gm_fold=10**v.mean())
    return out

rows = []; tests = []
for block, m in META.items():
    if m['kind'] not in ('rep', 'tc'): continue
    d = D[D.block == block]
    titre = block in TITRE; hai = block in HAI; lg = block in LOG10
    xs = [None] if m['kind'] == 'rep' else list(dict.fromkeys(d.x.astype(str)))
    for x in xs:
        groups = m['groups']; samples = {}
        for g in groups:
            v = tvals(block, g, x); samples[g] = v
            s = summarize(v, titre, hai, lg)
            cells = D[(D.block == block) & (D.group == g) & ((D.x.astype(str) == str(x)) if x is not None else True)].cell.tolist()
            rows.append(dict(block=block, label=m['label'], group=g, x='' if x is None else x, cells=f"{m['sheet']}!{cells[0]}:{cells[-1]}", stated_n=m['stated_n'], **s))
        # tests
        def tf(v):
            v = np.asarray(v, float)
            if titre:
                w = v.copy(); w[w <= 0] = 5.0; return np.log10(w)
            return v
        gs = [g for g in groups if len(samples[g]) >= 2]
        scale = 'log10 titre' if titre else ('log10 (as stored)' if lg else 'linear')
        if len(gs) >= 3:
            F, p = stats.f_oneway(*[tf(samples[g]) for g in gs])
            tests.append(dict(block=block, x='' if x is None else x, contrast='omnibus (all groups)', test='one-way ANOVA', scale=scale, stat=F, p=p))
            try:
                tk = stats.tukey_hsd(*[tf(samples[g]) for g in gs])
                for i, j in itertools.combinations(range(len(gs)), 2):
                    tests.append(dict(block=block, x='' if x is None else x, contrast=f'{gs[i]} vs {gs[j]}', test='Tukey HSD', scale=scale, stat=tk.statistic[i, j], p=tk.pvalue[i, j]))
            except Exception as e:
                pass
        for i, j in itertools.combinations(range(len(gs)), 2):
            a, b = tf(samples[gs[i]]), tf(samples[gs[j]])
            t, p = stats.ttest_ind(a, b, equal_var=False)
            tests.append(dict(block=block, x='' if x is None else x, contrast=f'{gs[i]} vs {gs[j]}', test='Welch t', scale=scale, stat=t, p=p))
            try:
                u, pu = stats.mannwhitneyu(a, b, alternative='two-sided', method='exact')
                tests.append(dict(block=block, x='' if x is None else x, contrast=f'{gs[i]} vs {gs[j]}', test='Mann-Whitney exact', scale=scale, stat=u, p=pu))
            except Exception as e:
                pass
R = pd.DataFrame(rows); T = pd.DataFrame(tests)
R.to_csv('stats_group_summaries.csv', index=False); T.to_csv('stats_tests.csv', index=False)
print('groups summarised:', len(R), '| tests:', len(T))

# two-way ANOVA for time-course blocks (group x time), as stated in the annotation
import statsmodels.api as sm
from statsmodels.formula.api import ols
aov = []
for block, m in META.items():
    if m['kind'] != 'tc': continue
    d = D[D.block == block].copy(); d['xx'] = d.x.astype(str)
    mod = ols('value ~ C(group) * C(xx)', data=d).fit()
    a = sm.stats.anova_lm(mod, typ=2)
    for term in a.index[:-1]:
        aov.append(dict(block=block, term=term, F=a.loc[term, 'F'], p=a.loc[term, 'PR(>F)'], df=a.loc[term, 'df'], resid_df=a.loc['Residual', 'df']))
pd.DataFrame(aov).to_csv('stats_twoway_anova.csv', index=False)
print(pd.DataFrame(aov).to_string())

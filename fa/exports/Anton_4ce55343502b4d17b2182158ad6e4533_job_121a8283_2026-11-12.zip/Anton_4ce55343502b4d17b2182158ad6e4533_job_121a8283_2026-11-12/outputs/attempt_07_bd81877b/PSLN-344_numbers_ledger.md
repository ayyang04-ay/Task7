# PSLN-344 — numbers ledger and QC log

Companion to `PSLN-344_portfolio_memo.md`. Every quantity quoted in the memo appears here with the workbook cells it came from and the way it was reduced. Source: `adjuvant_program_dataset.xlsx` (15 sheets; 6,819 numeric cells; 6,620 parsed into labelled blocks, 173 are day/dose axis values, and 26 sit in the 13 unlabelled rows S08!A89:D101, which were not used). Scripts and tidy extracts are in `analysis/`; the same ledger is in `analysis/numbers_ledger.csv`.

## 0. Reduction rules (applied everywhere)

| Data type | Reduction | Test |
|---|---|---|
| Replicate blocks (flow %, qPCR fold, counts) | arithmetic mean ± SD (n−1) of the per-animal values in the cited cells; n = values present | one-way ANOVA + Tukey HSD (method stated in the annotation); Welch t-test for two-group contrasts; exact Mann–Whitney as a distribution-free check |
| Titres (ELISA endpoint, HAI, neutralisation) | geometric mean titre (GMT) with 95% CI from log10 values; HAI printed as 0 (below the lowest dilution, 1:10) set to 5 | tests on log10 titres |
| log10 blocks (S09-A) | mean of stored log10 values, back-transformed (10^mean = geometric-mean fold) | tests on stored log10 values |
| Time-to-event | survivors = rows with flag 0 ÷ rows in the group; exact (Clopper–Pearson) 95% CI; median survival = first day Kaplan–Meier ≤ 50% | log-rank (stated method) on the rows; Fisher exact (two-sided) on end-of-window survival |
| Pooled survival | sums of survivors and animals over the listed blocks; risk difference with Newcombe 95% CI | log-rank stratified by experiment; Cochran–Mantel–Haenszel |
| Body weight | per-animal nadir over genuine measurements; a trailing run of identical values (≥3 weigh-ins, or 2 weigh-ins below 90%) is treated as a carried-forward last weight, i.e. the animal is counted as lost | descriptive only |
| Restoration index | (mean aged PSLN-344 − mean aged PSLN-212) ÷ (mean young PSLN-212 − mean aged PSLN-212); log10 scale for titres; bootstrap 95% CI (5,000 resamples of animals, seed 1) | Welch t-tests for the two component contrasts |
| IgG2a/IgG1 | per-animal quotient of the S13 subclass titres (row-wise), then mean ± SD | — |

Group labels are used exactly as printed unless the QC log (section 6) says otherwise. "Aged" = groups without a (Y) suffix; "(Y)" = young.

## 1. Time-to-event blocks — every arm

| Block | Conditions (from annotation) | Group (as printed) | Survivors / n | % (95% CI) | Death days | Median survival (d) | Cells (days; flags in the group column) |
|---|---|---|---|---|---|---|---|
| S03-I | aged BALB/c; bivalent H1N1+H3N2 vaccine (as S03-A); 10x mLD50 CA09 H1N1 on d14 (homologous) | Sham | 0/7 | 0 (0–41) | 5 6 6 6 8 8 11 | 6 | S03!A17:A23 |
| S03-I | aged BALB/c; bivalent H1N1+H3N2 vaccine (as S03-A); 10x mLD50 CA09 H1N1 on d14 (homologous) | CMP-204 | 3/7 | 43 (10–82) | 6 7 8 10 | 10 | S03!A24:A30 |
| S03-I | aged BALB/c; bivalent H1N1+H3N2 vaccine (as S03-A); 10x mLD50 CA09 H1N1 on d14 (homologous) | PSLN-212 | 0/7 | 0 (0–41) | 5 5 5 6 6 6 6 | 6 | S03!A31:A37 |
| S03-I | aged BALB/c; bivalent H1N1+H3N2 vaccine (as S03-A); 10x mLD50 CA09 H1N1 on d14 (homologous) | PSLN-344 | 7/7 | 100 (59–100) | — | >window | S03!A38:A44 |
| S03-I | aged BALB/c; bivalent H1N1+H3N2 vaccine (as S03-A); 10x mLD50 CA09 H1N1 on d14 (homologous) | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S03!A45:A51 |
| S03-J | aged BALB/c; rgH5N1 vaccine, single dose; wild-type VN04 H5N1 on d2 | Sham | 1/10 (stated n=9) | 10 (0–45) | 3 4 9 9 9 10 10 10 10 | 9 | S03!G17:G26 |
| S03-J | aged BALB/c; rgH5N1 vaccine, single dose; wild-type VN04 H5N1 on d2 | PSLN-212 | 3/10 (stated n=9) | 30 (7–65) | 10 10 11 11 12 12 12 | 12 | S03!G27:G36 |
| S03-J | aged BALB/c; rgH5N1 vaccine, single dose; wild-type VN04 H5N1 on d2 | PSLN-344 | 10/10 (stated n=9) | 100 (69–100) | — | >window | S03!G37:G46 ; 1 row without a day |
| S06-A | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d14 (heterosubtypic) | Sham | 0/7 | 0 (0–41) | 4 4 4 5 5 7 7 | 5 | S06!A3:A9 |
| S06-A | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d14 (heterosubtypic) | PSLN-212 | 1/7 | 14 (0–58) | 4 6 6 8 9 10 | 8 | S06!A10:A16 |
| S06-A | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d14 (heterosubtypic) | PSLN-344 | 6/7 | 86 (42–100) | 8 | >window | S06!A17:A23 |
| S06-A | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d14 (heterosubtypic) | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S06!A24:A30 |
| S06-B | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d3 (heterosubtypic) | Sham | 0/7 | 0 (0–41) | 4 4 4 5 5 6 6 | 5 | S06!G3:G9 |
| S06-B | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d3 (heterosubtypic) | PSLN-212 | 0/7 | 0 (0–41) | 4 4 6 6 6 7 10 | 6 | S06!G10:G16 |
| S06-B | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d3 (heterosubtypic) | PSLN-344 | 5/7 | 71 (29–96) | 8 10 | >window | S06!G17:G23 |
| S06-B | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d3 (heterosubtypic) | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S06!G24:G30 |
| S06-C | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d14 (HA subtype not in vaccine; N1 shared) | Sham | 0/7 | 0 (0–41) | 4 4 5 6 6 6 7 | 6 | S06!M3:M9 |
| S06-C | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d14 (HA subtype not in vaccine; N1 shared) | PSLN-212 | 2/7 | 29 (4–71) | 5 8 10 10 12 | 10 | S06!M10:M16 |
| S06-C | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d14 (HA subtype not in vaccine; N1 shared) | PSLN-344 | 7/7 | 100 (59–100) | — | >window | S06!M17:M23 |
| S06-C | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d14 (HA subtype not in vaccine; N1 shared) | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S06!M24:M30 |
| S06-D | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d3 (HA subtype not in vaccine; N1 shared) | Sham | 0/7 | 0 (0–41) | 4 4 5 6 6 6 7 | 6 | S06!A34:A40 |
| S06-D | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d3 (HA subtype not in vaccine; N1 shared) | PSLN-212 | 2/7 | 29 (4–71) | 5 8 10 10 12 | 10 | S06!A41:A47 |
| S06-D | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d3 (HA subtype not in vaccine; N1 shared) | PSLN-344 | 7/7 | 100 (59–100) | — | >window | S06!A48:A54 |
| S06-D | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d3 (HA subtype not in vaccine; N1 shared) | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S06!A55:A61 |
| S06-E | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d60 (heterosubtypic) | Sham | 0/7 | 0 (0–41) | 4 5 5 5 5 6 6 | 5 | S06!G34:G40 |
| S06-E | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d60 (heterosubtypic) | PSLN-212 | 0/7 | 0 (0–41) | 5 5 5 6 6 8 11 | 6 | S06!G41:G47 |
| S06-E | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d60 (heterosubtypic) | PSLN-344 | 5/7 | 71 (29–96) | 8 10 | >window | S06!G48:G54 |
| S06-E | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d60 (heterosubtypic) | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S06!G55:G61 |
| S06-E | aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d60 (heterosubtypic) | Untreated | 6/7 | 86 (42–100) | 4 | >window | S06!G62:G68 |
| S06-F | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d60 (HA subtype not in vaccine; N1 shared) | Sham | 0/7 | 0 (0–41) | 4 4 4 5 5 6 6 | 5 | S06!M34:M40 |
| S06-F | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d60 (HA subtype not in vaccine; N1 shared) | PSLN-212 | 1/7 | 14 (0–58) | 4 5 6 6 6 7 | 6 | S06!M41:M47 |
| S06-F | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d60 (HA subtype not in vaccine; N1 shared) | PSLN-344 | 5/7 | 71 (29–96) | 7 8 | >window | S06!M48:M54 |
| S06-F | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d60 (HA subtype not in vaccine; N1 shared) | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S06!M55:M61 |
| S06-F | aged BALB/c; bivalent H1N1+H3N2 vaccine; 5x mLD50 rgH5N1 on d60 (HA subtype not in vaccine; N1 shared) | Untreated | 7/7 | 100 (59–100) | — | >window | S06!M62:M68 |
| S06-G | aged BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d60 (heterosubtypic) | Sham | 0/7 | 0 (0–41) | 4 4 5 6 6 7 7 | 6 | S06!A71:A77 |
| S06-G | aged BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d60 (heterosubtypic) | PSLN-212 | 0/7 | 0 (0–41) | 6 6 8 8 8 11 11 | 8 | S06!A78:A84 |
| S06-G | aged BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d60 (heterosubtypic) | PSLN-344 | 4/7 | 57 (18–90) | 8 9 11 | >window | S06!A85:A91 |
| S06-G | aged BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d60 (heterosubtypic) | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S06!A92:A98 |
| S06-G | aged BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d60 (heterosubtypic) | Untreated | 4/7 | 57 (18–90) | 3 7 10 | >window | S06!A99:A105 |
| S06-E2 | BALB/c infected at 10 mo with 1x mLD50 PR8 or saline; 4 mo later bivalent vaccine; 5x LD50 PR8 H1N1 (challenge day not stated) | Naïve+PSLN-212 | 0/7 | 0 (0–41) | 4 4 5 6 6 6 8 | 6 | S06!G71:G77 |
| S06-E2 | BALB/c infected at 10 mo with 1x mLD50 PR8 or saline; 4 mo later bivalent vaccine; 5x LD50 PR8 H1N1 (challenge day not stated) | Imprinting+PSLN-212 | 4/7 | 57 (18–90) | 6 8 8 | >window | S06!G78:G84 |
| S06-E2 | BALB/c infected at 10 mo with 1x mLD50 PR8 or saline; 4 mo later bivalent vaccine; 5x LD50 PR8 H1N1 (challenge day not stated) | Naïve+PSLN-344 | 6/7 | 86 (42–100) | 5 | >window | S06!G85:G91 |
| S06-E2 | BALB/c infected at 10 mo with 1x mLD50 PR8 or saline; 4 mo later bivalent vaccine; 5x LD50 PR8 H1N1 (challenge day not stated) | Imprinting+PSLN-344 | 6/7 | 86 (42–100) | 8 | >window | S06!G92:G98 |
| S06-F2 | as S06-E2; 5x LD50 Perth H3N2 on d14 | Naïve+PSLN-212 | 0/7 | 0 (0–41) | 4 4 6 6 7 8 8 | 6 | S06!M71:M77 |
| S06-F2 | as S06-E2; 5x LD50 Perth H3N2 on d14 | Imprinting+PSLN-212 | 0/7 | 0 (0–41) | 4 4 5 5 5 6 6 | 5 | S06!M78:M84 |
| S06-F2 | as S06-E2; 5x LD50 Perth H3N2 on d14 | Naïve+PSLN-344 | 6/7 | 86 (42–100) | 8 | >window | S06!M85:M91 |
| S06-F2 | as S06-E2; 5x LD50 Perth H3N2 on d14 | Imprinting+PSLN-344 | 6/7 | 86 (42–100) | 7 | >window | S06!M92:M98 |
| S09-B | young BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d21 | Sham | 0/8 | 0 (0–37) | 6 6 6 7 7 7 8 8 | 7 | S09!A12:A19 |
| S09-B | young BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d21 | PSLN-344Y | 8/8 | 100 (63–100) | — | >window | S09!A20:A27 |
| S09-B | young BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 on d21 | PSLN-212Y | 8/8 | 100 (63–100) | — | >window | S09!A28:A35 |
| S09-D | young BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d21 | Sham | 0/8 | 0 (0–37) | 7 8 8 8 8 8 9 9 | 8 | S09!A39:A46 |
| S09-D | young BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d21 | PSLN-344Y | 8/8 | 100 (63–100) | — | >window | S09!A47:A54 |
| S09-D | young BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 on d21 | PSLN-212Y | 8/8 | 100 (63–100) | — | >window | S09!A55:A62 |
| S09-F | young BALB/c; bivalent vaccine; 5x mLD50 VN04 rgH5N1 on d180 | Sham | 0/7 (stated n=8) | 0 (0–41) | 6 6 6 7 8 8 8 | 7 | S09!A66:A72 |
| S09-F | young BALB/c; bivalent vaccine; 5x mLD50 VN04 rgH5N1 on d180 | PSLN-344Y | 8/8 | 100 (63–100) | — | >window | S09!A73:A80 |
| S09-F | young BALB/c; bivalent vaccine; 5x mLD50 VN04 rgH5N1 on d180 | PSLN-212Y | 8/8 | 100 (63–100) | — | >window | S09!A81:A88 |
| S13-E | young BALB/c; vaccinated as S03-I; 10x mLD50 CA09 H1N1 on d14 (homologous) | Naïve | 0/7 (stated n=5) | 0 (0–41) | 6 7 7 7 8 8 8 | 7 | S13!R3:R9 |
| S13-E | young BALB/c; vaccinated as S03-I; 10x mLD50 CA09 H1N1 on d14 (homologous) | Sham | 1/7 (stated n=5) | 14 (0–58) | 7 9 9 10 11 11 | 10 | S13!R10:R16 |
| S13-E | young BALB/c; vaccinated as S03-I; 10x mLD50 CA09 H1N1 on d14 (homologous) | CMP-204(Y) | 7/7 (stated n=5) | 100 (59–100) | — | >window | S13!R17:R23 |
| S13-E | young BALB/c; vaccinated as S03-I; 10x mLD50 CA09 H1N1 on d14 (homologous) | PSLN-344(Y) | 7/7 (stated n=5) | 100 (59–100) | — | >window | S13!R24:R30 |
| S15-H | aged BALB/c; bivalent H1N1+H3N2 vaccine alone, PSLN-344 alone, or both, 3 d before 5x mLD50 VN04 rgH5N1 | 3d Vaccine | 0/7 | 0 (0–41) | 4 5 5 5 6 6 7 | 5 | S15!A73:A79 |
| S15-H | aged BALB/c; bivalent H1N1+H3N2 vaccine alone, PSLN-344 alone, or both, 3 d before 5x mLD50 VN04 rgH5N1 | 3d PSLN-344 | 0/7 | 0 (0–41) | 5 5 6 6 6 7 8 | 6 | S15!A80:A86 |
| S15-H | aged BALB/c; bivalent H1N1+H3N2 vaccine alone, PSLN-344 alone, or both, 3 d before 5x mLD50 VN04 rgH5N1 | 3d Vaccine+PSLN-344 | 6/7 | 86 (42–100) | 12 | >window | S15!A87:A93 |
| S15-L | aged (20 mo) C57BL/6; bivalent vaccine; challenge virus/day not stated | Sham | 0/7 | 0 (0–41) | 4 4 6 6 6 8 8 | 6 | S15!A103:A109 |
| S15-L | aged (20 mo) C57BL/6; bivalent vaccine; challenge virus/day not stated | PSLN-212 | 0/7 | 0 (0–41) | 6 7 7 8 8 9 11 | 8 | S15!A110:A116 |
| S15-L | aged (20 mo) C57BL/6; bivalent vaccine; challenge virus/day not stated | PSLN-344 | 6/7 | 86 (42–100) | 8 | >window | S15!A117:A123 |
| S15-L | aged (20 mo) C57BL/6; bivalent vaccine; challenge virus/day not stated | PSLN-212(Y) | 6/7 | 86 (42–100) | 12 | >window | S15!A124:A130 |
| S15-N | aged (20 mo) Swiss Webster; bivalent vaccine; challenge virus/day not stated | Sham | 0/7 | 0 (0–41) | 5 6 6 8 8 8 10 | 8 | S15!A134:A140 |
| S15-N | aged (20 mo) Swiss Webster; bivalent vaccine; challenge virus/day not stated | PSLN-212 | 2/7 | 29 (4–71) | 6 10 10 10 12 | 10 | S15!A141:A147 |
| S15-N | aged (20 mo) Swiss Webster; bivalent vaccine; challenge virus/day not stated | PSLN-344 | 6/7 | 86 (42–100) | 8 | >window | S15!A148:A154 |
| S15-N | aged (20 mo) Swiss Webster; bivalent vaccine; challenge virus/day not stated | PSLN-212(Y) | 7/7 | 100 (59–100) | — | >window | S15!A155:A161 |

### 1b. Pairwise tests used in the memo (log-rank on rows; Fisher exact on end-of-window survival)

| Block | Contrast | Survivors | Log-rank χ² | Log-rank p | Fisher p |
|---|---|---|---|---|---|
| S03-I | Sham vs CMP-204 | 0/7 vs 3/7 | 3.65 | 0.056 | 0.19 |
| S03-I | Sham vs PSLN-212 | 0/7 vs 0/7 | 3.64 | 0.056 | 1 |
| S03-I | Sham vs PSLN-344 | 0/7 vs 7/7 | 14.24 | 0.00016 | 0.00058 |
| S03-I | CMP-204 vs PSLN-212 | 3/7 vs 0/7 | 10.20 | 0.0014 | 0.19 |
| S03-I | CMP-204 vs PSLN-344 | 3/7 vs 7/7 | 5.24 | 0.022 | 0.07 |
| S03-I | CMP-204 vs PSLN-212(Y) | 3/7 vs 7/7 | 5.24 | 0.022 | 0.07 |
| S03-I | PSLN-212 vs PSLN-344 | 0/7 vs 7/7 | 12.76 | 0.00035 | 0.00058 |
| S03-I | PSLN-344 vs PSLN-212(Y) | 7/7 vs 7/7 | — | — (no deaths in either arm) | 1 |
| S03-J | Sham vs PSLN-344 | 1/10 vs 10/10 | 15.52 | 8.2e-05 | 0.00012 |
| S03-J | PSLN-212 vs PSLN-344 | 3/10 vs 10/10 | 10.27 | 0.0014 | 0.0031 |
| S06-A | Sham vs PSLN-344 | 0/7 vs 6/7 | 13.84 | 0.0002 | 0.0047 |
| S06-A | PSLN-212 vs PSLN-344 | 1/7 vs 6/7 | 6.96 | 0.0083 | 0.029 |
| S06-A | PSLN-344 vs PSLN-212(Y) | 6/7 vs 7/7 | 1.00 | 0.32 | 1 |
| S06-B | Sham vs PSLN-344 | 0/7 vs 5/7 | 13.84 | 0.0002 | 0.021 |
| S06-B | PSLN-212 vs PSLN-344 | 0/7 vs 5/7 | 10.98 | 0.00092 | 0.021 |
| S06-B | PSLN-344 vs PSLN-212(Y) | 5/7 vs 7/7 | 2.16 | 0.14 | 0.46 |
| S06-C | Sham vs PSLN-344 | 0/7 vs 7/7 | 13.93 | 0.00019 | 0.00058 |
| S06-C | PSLN-212 vs PSLN-344 | 2/7 vs 7/7 | 7.34 | 0.0068 | 0.021 |
| S06-C | PSLN-344 vs PSLN-212(Y) | 7/7 vs 7/7 | — | — (no deaths in either arm) | 1 |
| S06-D | Sham vs PSLN-344 | 0/7 vs 7/7 | 13.93 | 0.00019 | 0.00058 |
| S06-D | PSLN-212 vs PSLN-344 | 2/7 vs 7/7 | 7.34 | 0.0068 | 0.021 |
| S06-D | PSLN-344 vs PSLN-212(Y) | 7/7 vs 7/7 | — | — (no deaths in either arm) | 1 |
| S06-E | Sham vs PSLN-344 | 0/7 vs 5/7 | 13.65 | 0.00022 | 0.021 |
| S06-E | Sham vs Untreated | 0/7 vs 6/7 | 8.11 | 0.0044 | 0.0047 |
| S06-E | PSLN-212 vs PSLN-344 | 0/7 vs 5/7 | 10.00 | 0.0016 | 0.021 |
| S06-E | PSLN-212 vs Untreated | 0/7 vs 6/7 | 8.48 | 0.0036 | 0.0047 |
| S06-E | PSLN-344 vs PSLN-212(Y) | 5/7 vs 7/7 | 2.16 | 0.14 | 0.46 |
| S06-E | PSLN-344 vs Untreated | 5/7 vs 6/7 | 0.28 | 0.59 | 1 |
| S06-E | PSLN-212(Y) vs Untreated | 7/7 vs 6/7 | 1.00 | 0.32 | 1 |
| S06-F | Sham vs PSLN-344 | 0/7 vs 5/7 | 13.84 | 0.0002 | 0.021 |
| S06-F | Sham vs Untreated | 0/7 vs 7/7 | 13.84 | 0.0002 | 0.00058 |
| S06-F | PSLN-212 vs PSLN-344 | 1/7 vs 5/7 | 6.74 | 0.0094 | 0.1 |
| S06-F | PSLN-212 vs Untreated | 1/7 vs 7/7 | 10.03 | 0.0015 | 0.0047 |
| S06-F | PSLN-344 vs PSLN-212(Y) | 5/7 vs 7/7 | 2.16 | 0.14 | 0.46 |
| S06-F | PSLN-344 vs Untreated | 5/7 vs 7/7 | 2.16 | 0.14 | 0.46 |
| S06-F | PSLN-212(Y) vs Untreated | 7/7 vs 7/7 | — | — (no deaths in either arm) | 1 |
| S06-G | Sham vs PSLN-344 | 0/7 vs 4/7 | 13.67 | 0.00022 | 0.07 |
| S06-G | Sham vs Untreated | 0/7 vs 4/7 | 6.56 | 0.01 | 0.07 |
| S06-G | PSLN-212 vs PSLN-344 | 0/7 vs 4/7 | 5.90 | 0.015 | 0.07 |
| S06-G | PSLN-212 vs Untreated | 0/7 vs 4/7 | 3.02 | 0.082 | 0.07 |
| S06-G | PSLN-344 vs PSLN-212(Y) | 4/7 vs 7/7 | 3.55 | 0.06 | 0.19 |
| S06-G | PSLN-344 vs Untreated | 4/7 vs 4/7 | 0.03 | 0.85 | 1 |
| S06-G | PSLN-212(Y) vs Untreated | 7/7 vs 4/7 | 3.55 | 0.06 | 0.19 |
| S06-E2 | Naïve+PSLN-212 vs Imprinting+PSLN-212 | 0/7 vs 4/7 | 8.57 | 0.0034 | 0.07 |
| S06-E2 | Naïve+PSLN-212 vs Naïve+PSLN-344 | 0/7 vs 6/7 | 9.22 | 0.0024 | 0.0047 |
| S06-E2 | Naïve+PSLN-212 vs Imprinting+PSLN-344 | 0/7 vs 6/7 | 12.43 | 0.00042 | 0.0047 |
| S06-E2 | Imprinting+PSLN-212 vs Naïve+PSLN-344 | 4/7 vs 6/7 | 0.97 | 0.32 | 0.56 |
| S06-E2 | Imprinting+PSLN-212 vs Imprinting+PSLN-344 | 4/7 vs 6/7 | 1.43 | 0.23 | 0.56 |
| S06-E2 | Naïve+PSLN-344 vs Imprinting+PSLN-344 | 6/7 vs 6/7 | 0.00 | 0.96 | 1 |
| S06-F2 | Naïve+PSLN-212 vs Imprinting+PSLN-212 | 0/7 vs 0/7 | 3.16 | 0.076 | 1 |
| S06-F2 | Naïve+PSLN-212 vs Naïve+PSLN-344 | 0/7 vs 6/7 | 11.74 | 0.00061 | 0.0047 |
| S06-F2 | Naïve+PSLN-212 vs Imprinting+PSLN-344 | 0/7 vs 6/7 | 10.35 | 0.0013 | 0.0047 |
| S06-F2 | Imprinting+PSLN-212 vs Naïve+PSLN-344 | 0/7 vs 6/7 | 13.62 | 0.00022 | 0.0047 |
| S06-F2 | Imprinting+PSLN-212 vs Imprinting+PSLN-344 | 0/7 vs 6/7 | 13.62 | 0.00022 | 0.0047 |
| S06-F2 | Naïve+PSLN-344 vs Imprinting+PSLN-344 | 6/7 vs 6/7 | 0.00 | 0.96 | 1 |
| S09-B | Sham vs PSLN-344Y | 0/8 vs 8/8 | 16.03 | 6.2e-05 | 0.00016 |
| S09-B | PSLN-344Y vs PSLN-212Y | 8/8 vs 8/8 | — | — (no deaths in either arm) | 1 |
| S09-D | Sham vs PSLN-344Y | 0/8 vs 8/8 | 15.96 | 6.5e-05 | 0.00016 |
| S09-D | PSLN-344Y vs PSLN-212Y | 8/8 vs 8/8 | — | — (no deaths in either arm) | 1 |
| S09-F | Sham vs PSLN-344Y | 0/7 vs 8/8 | 14.79 | 0.00012 | 0.00016 |
| S09-F | PSLN-344Y vs PSLN-212Y | 8/8 vs 8/8 | — | — (no deaths in either arm) | 1 |
| S13-E | Naïve vs PSLN-344(Y) | 0/7 vs 7/7 | 13.05 | 0.0003 | 0.00058 |
| S13-E | Sham vs PSLN-344(Y) | 1/7 vs 7/7 | 9.96 | 0.0016 | 0.0047 |
| S13-E | CMP-204(Y) vs PSLN-344(Y) | 7/7 vs 7/7 | — | — (no deaths in either arm) | 1 |
| S15-H | 3d Vaccine vs 3d PSLN-344 | 0/7 vs 0/7 | 1.51 | 0.22 | 1 |
| S15-H | 3d Vaccine vs 3d Vaccine+PSLN-344 | 0/7 vs 6/7 | 14.24 | 0.00016 | 0.0047 |
| S15-H | 3d PSLN-344 vs 3d Vaccine+PSLN-344 | 0/7 vs 6/7 | 14.46 | 0.00014 | 0.0047 |
| S15-L | Sham vs PSLN-344 | 0/7 vs 6/7 | 11.52 | 0.00069 | 0.0047 |
| S15-L | PSLN-212 vs PSLN-344 | 0/7 vs 6/7 | 10.66 | 0.0011 | 0.0047 |
| S15-L | PSLN-344 vs PSLN-212(Y) | 6/7 vs 6/7 | 0.00 | 0.96 | 1 |
| S15-N | Sham vs PSLN-344 | 0/7 vs 6/7 | 10.73 | 0.0011 | 0.0047 |
| S15-N | PSLN-212 vs PSLN-344 | 2/7 vs 6/7 | 3.64 | 0.056 | 0.1 |
| S15-N | PSLN-344 vs PSLN-212(Y) | 6/7 vs 7/7 | 1.00 | 0.32 | 1 |

## 2. Pooled survival analyses

p values are asymptotic (chi-square on 1 d.f.). Values below about 1e-10 mean "far below any threshold" and should not be read as exact probabilities.

| ID | Analysis (blocks pooled) | Test arm | Control arm | Risk difference, points (95% CI) | Stratified log-rank p | CMH p | Crude Fisher p |
|---|---|---|---|---|---|---|---|
| A1 | Aged BALB/c, PSLN-344 vs Sham (9 experiments: S03-I, S03-J, S06-A..G) | 56/66 (85%; 74–92) | 1/66 (2%; 0–8) | 83 (71 to 90) | 2.7e-29 | 2.6e-21 | 2.5e-25 |
| A2 | Aged BALB/c, PSLN-344 vs PSLN-212 (same 9) | 56/66 (85%; 74–92) | 9/66 (14%; 6–24) | 71 (56 to 80) | 2.2e-18 | 2.6e-16 | 4.3e-17 |
| A3 | All aged experiments with a vaccine-only control (12: + S15-H, S15-L, S15-N) | 74/87 (85%; 76–92) | 1/87 (1%; 0–6) | 84 (74 to 90) | 3.4e-37 | 1.0e-27 | 6.4e-34 |
| A4 | All aged experiments with a PSLN-212 arm (11) | 68/80 (85%; 75–92) | 11/80 (14%; 7–23) | 71 (58 to 80) | 2.3e-21 | 2.8e-19 | 1.4e-20 |
| A5 | Aged, PSLN-212 vs Sham (11) | 11/80 (14%; 7–23) | 1/80 (1%; 0–7) | 12 (4 to 22) | 5.6e-11 | 2.5e-03 | 4.7e-03 |
| B1 | Young PSLN-212(Y) benchmark vs aged PSLN-344, BALB/c (8; S03-J has no young arm) | 56/56 (100%; 94–100) | 46/56 (82%; 70–91) | 18 (8 to 30) | 9.0e-04 | 9.0e-04 | 1.3e-03 |
| B2 | ... challenge at d14 only (S03-I, S06-A, S06-C) | 21/21 (100%; 84–100) | 20/21 (95%; 76–100) | 5 (-11 to 23) | 3.2e-01 | 3.2e-01 | 1.0e+00 |
| B3 | ... challenge at d3 only (S06-B, S06-D) | 14/14 (100%; 77–100) | 12/14 (86%; 57–98) | 14 (-10 to 40) | 1.4e-01 | 1.4e-01 | 4.8e-01 |
| B4 | ... challenge at d60 only (S06-E, S06-F, S06-G) | 21/21 (100%; 84–100) | 14/21 (67%; 43–85) | 33 (11 to 55) | 5.0e-03 | 5.0e-03 | 8.6e-03 |
| C1 | d60 challenge: PSLN-344 vs Sham | 14/21 (67%; 43–85) | 0/21 (0%; 0–16) | 67 (40 to 83) | 1.4e-10 | 9.5e-06 | 4.4e-06 |
| C2 | d60 challenge: PSLN-344 vs PSLN-212 | 14/21 (67%; 43–85) | 1/21 (5%; 0–24) | 62 (34 to 79) | 2.4e-06 | 4.8e-05 | 5.1e-05 |
| C3 | d60 challenge: Untreated/unchallenged aged vs challenged PSLN-344 | 17/21 (81%; 58–95) | 14/21 (67%; 43–85) | 14 (-12 to 38) | 4.4e-01 | 2.9e-01 | 4.8e-01 |
| D1 | Early challenge (d2-3): PSLN-344 vs vaccine-only (S03-J, S06-B, S06-D, S15-H) | 28/31 (90%; 74–98) | 1/31 (3%; 0–17) | 87 (67 to 94) | 3.6e-14 | 1.8e-11 | 6.8e-13 |
| D2 | Challenge at d14: PSLN-344 vs Sham (S03-I, S06-A, S06-C) | 20/21 (95%; 76–100) | 0/21 (0%; 0–16) | 95 (72 to 99) | 9.1e-11 | 2.4e-09 | 8.2e-11 |
| D3 | Challenge at d14: PSLN-344 vs PSLN-212 (S03-I, S06-A, S06-C) | 20/21 (95%; 76–100) | 3/21 (14%; 3–36) | 81 (54 to 91) | 2.9e-07 | 3.0e-07 | 1.3e-07 |
| S5 | Sensitivity: A1 without S06-C and S06-D: PSLN-344 vs Sham | 42/52 (81%; 67–90) | 1/52 (2%; 0–10) | 79 (64 to 87) | 3.4e-23 | 1.1e-15 | 4.9e-18 |
| S6 | Sensitivity: A2 without S06-C and S06-D: PSLN-344 vs PSLN-212 | 42/52 (81%; 67–90) | 5/52 (10%; 3–21) | 71 (54 to 81) | 3.6e-15 | 4.1e-13 | 8.6e-14 |
| S7 | Sensitivity: A2 without S06-D: PSLN-344 vs PSLN-212 | 49/59 (83%; 71–92) | 7/59 (12%; 5–23) | 71 (55 to 81) | 8.9e-17 | 1.0e-14 | 2.1e-15 |
| E1 | Challenge HA subtype absent from the vaccine, aged BALB/c (S06-A..G): PSLN-344 vs Sham | 39/49 (80%; 66–90) | 0/49 (0%; 0–7) | 80 (64 to 89) | 8.1e-23 | 4.2e-15 | 4.9e-18 |
| E2 | Challenge HA subtype absent from the vaccine (S06-A..G): PSLN-344 vs PSLN-212 | 39/49 (80%; 66–90) | 6/49 (12%; 5–25) | 67 (49 to 78) | 1.7e-13 | 2.3e-11 | 1.3e-11 |
| E3 | Fully heterosubtypic (no shared HA or NA subtype; S06-A, B, E, G): PSLN-344 vs Sham | 20/28 (71%; 51–87) | 0/28 (0%; 0–12) | 71 (49 to 85) | 1.2e-13 | 6.5e-08 | 7.9e-09 |
| E4 | Fully heterosubtypic (S06-A, B, E, G): PSLN-344 vs PSLN-212 | 20/28 (71%; 51–87) | 1/28 (4%; 0–18) | 68 (45 to 81) | 8.5e-09 | 3.0e-07 | 1.3e-07 |
| S3 | Sensitivity: only the five experiments with no label/duplication flag on the table (S06-A, B, E, F, G): PSLN-344 vs Sham | 25/35 (71%; 54–85) | 0/35 (0%; 0–10) | 71 (52 to 84) | 1.1e-16 | 1.6e-09 | 5.7e-11 |
| S4 | Sensitivity: same five experiments: PSLN-344 vs PSLN-212 | 25/35 (71%; 54–85) | 2/35 (6%; 1–19) | 66 (45 to 79) | 2.7e-10 | 3.7e-08 | 1.2e-08 |
| H1 | Other strains (S15-L C57BL/6, S15-N Swiss Webster): PSLN-344 vs Sham | 12/14 (86%; 57–98) | 0/14 (0%; 0–23) | 86 (52 to 96) | 2.4e-06 | 1.0e-05 | 6.0e-06 |
| H2 | Other strains: PSLN-344 vs PSLN-212 | 12/14 (86%; 57–98) | 2/14 (14%; 2–43) | 71 (35 to 86) | 2.2e-04 | 2.3e-04 | 4.2e-04 |
| S1 | Sensitivity: A1 without S06-D (identical to S06-C in every arm) | 49/59 (83%; 71–92) | 1/59 (2%; 0–9) | 81 (68 to 89) | 3.0e-26 | 1.7e-18 | 1.2e-21 |
| S2 | Sensitivity: A2 without S06-D and without S03-I/S03-J (comparator labels conflict with paired body-weight blocks) | 32/42 (76%; 61–88) | 4/42 (10%; 3–23) | 67 (47 to 78) | 6.7e-12 | 9.3e-10 | 4.7e-10 |
| F1 | 14-month imprinting study: PSLN-344 vs PSLN-212 (4 strata) | 24/28 (86%; 67–96) | 4/28 (14%; 4–33) | 71 (47 to 84) | 5.6e-09 | 1.1e-07 | 1.1e-07 |
| F2 | Imprinted vs naive, both PSLN-344 | 12/14 (86%; 57–98) | 12/14 (86%; 57–98) | 0 (-28 to 28) | 1.0e+00 | 1.0e+00 | 1.0e+00 |
| G1 | Young BALB/c: PSLN-344Y vs PSLN-212Y (S09-B, D, F) | 24/24 (100%) | 24/24 (100%) | 0 | — (no deaths) | — | — |

Additional pooled counts quoted in the memo (sums of section-1 rows):

| Quantity | Value | Blocks |
|---|---|---|
| Fully heterosubtypic challenges (no shared HA or NA subtype), PSLN-344 | 20/28 (71%; 51–87) | S06-A, S06-B, S06-E, S06-G |
| … same, vaccine + empty liposome | 0/28 (0%; 0–12) | S06-A, S06-B, S06-E, S06-G |
| … same, PSLN-212 | 1/28 (4%; 0–18) | S06-A, S06-B, S06-E, S06-G |
| … same, young PSLN-212 | 28/28 (100%; 88–100) | S06-A, S06-B, S06-E, S06-G |
| H1N1+H3N2 vaccine → rgH5N1 (shared N1), PSLN-344 | 19/21 (90%; 70–99) | S06-C, S06-D, S06-F |
| … same, PSLN-212 | 5/21 (24%; 8–47) | S06-C, S06-D, S06-F |
| Challenge 14 d after vaccination, PSLN-344 | 20/21 (95%; 76–100) | S03-I, S06-A, S06-C |
| … same, PSLN-212 | 3/21 (14%; 3–36) | S03-I, S06-A, S06-C |
| Challenge 60 d after vaccination, PSLN-344 | 14/21 (67%; 43–85) | S06-E, S06-F, S06-G |
| … same, untreated unchallenged | 17/21 (81%; 58–95) | S06-E, S06-F, S06-G |
| … same, young PSLN-212 | 21/21 (100%; 84–100) | S06-E, S06-F, S06-G |
| Matched designs, day 14 (S06-A, S06-C), PSLN-344 | 13/14 (93%; 66–100) | S06-A, S06-C |
| Matched designs, day 60 (S06-E, S06-F), PSLN-344 | 10/14 (71%; 42–92) | S06-E, S06-F |
| Five experiments with no label or duplication flag on the table (S06-A, B, E, F, G), PSLN-344 | 25/35 (71%; 54–85) | S06-A, S06-B, S06-E, S06-F, S06-G |
| … same, vaccine + empty liposome | 0/35 (0%; 0–10) | S06-A, S06-B, S06-E, S06-F, S06-G |
| … same, PSLN-212 | 2/35 (6%; 1–19) | S06-A, S06-B, S06-E, S06-F, S06-G |
| Without S06-C and S06-D (7 experiments), PSLN-344 | 42/52 (81%; 67–90) | S03-I, S03-J, S06-A, S06-B, S06-E, S06-F, S06-G |
| … same, vaccine + empty liposome | 1/52 (2%; 0–10) | S03-I, S03-J, S06-A, S06-B, S06-E, S06-F, S06-G |
| … same, PSLN-212 | 5/52 (10%; 3–21) | S03-I, S03-J, S06-A, S06-B, S06-E, S06-F, S06-G |
| Other strains (S15-L, S15-N), PSLN-344 | 12/14 (86%; 57–98) | S15-L, S15-N |
| … same, vaccine + empty liposome | 0/14 (0%; 0–23) | S15-L, S15-N |
| … same, PSLN-212 | 2/14 (14%; 2–43) | S15-L, S15-N |
| Young PSLN-212 across the 8 BALB/c experiments with a young arm | 56/56 (100%; 94–100) | S03-I, S06-A, S06-B, S06-C, S06-D, S06-E, S06-F, S06-G |
| Young BALB/c, PSLN-344Y (S09-B, D, F) | 24/24 (100%; 86–100) | S09-B, S09-D, S09-F |
| Young BALB/c, PSLN-212Y (S09-B, D, F) | 24/24 (100%; 86–100) | S09-B, S09-D, S09-F |

| Extra Fisher exact tests (two-sided) | p |
|---|---|
| Day 14 (20/21) vs day 60 (14/21), aged PSLN-344 | 0.0448 |
| Matched designs day 14 (13/14) vs day 60 (10/14), aged PSLN-344 | 0.326 |
| Day 60: aged PSLN-344 (14/21) vs untreated unchallenged (17/21) | 0.484 |
| Day 60: aged PSLN-344 (14/21) vs young PSLN-212 (21/21) | 0.00862 |
| S06-D lower count: PSLN-344 5/7 vs Sham 0/7 | 0.021 |
| S03-I alternative reading: PSLN-344 7/7 vs PSLN-212 3/7 | 0.0699 |

Worst-case arm-by-arm count for PSLN-344 in the 9 aged BALB/c experiments (lower of time-to-event table and body-weight-implied survivors): 7+10+6+5+7+**5**+5+5+4 = **54/66 (82%)**; best case (higher of the two): 58/66.

## 3. Replicate and time-course blocks — group summaries

Mean ± SD (n). GMT [95% CI] for titre blocks; geometric-mean fold for the log10 block S09-A. "x" is the day, hour or dose for time-course/dose blocks.

| Block | Label as printed | Group | x | n | Mean ± SD | GMT [95% CI] or GM fold | Cells |
|---|---|---|---|---|---|---|---|
| S01-A_16h | S01-A n=5 (Ifnb1/16h) | Sham |  | 5 | 1.006 ± 0.478 |  | S01!B3:F3 |
| S01-A_16h | S01-A n=5 (Ifnb1/16h) | CMP-204 |  | 5 | 7.826 ± 1.749 |  | S01!B4:F4 |
| S01-A_16h | S01-A n=5 (Ifnb1/16h) | PSLN-212 |  | 5 | 16.64 ± 2.10 |  | S01!B5:F5 |
| S01-A_16h | S01-A n=5 (Ifnb1/16h) | PSLN-R848 |  | 5 | 5.050 ± 2.323 |  | S01!B6:F6 |
| S01-A_16h | S01-A n=5 (Ifnb1/16h) | PSLN-212/R848 |  | 5 | 24.26 ± 3.75 |  | S01!B7:F7 |
| S01-A_16h | S01-A n=5 (Ifnb1/16h) | PSLN-344 |  | 5 | 37.11 ± 4.76 |  | S01!B8:F8 |
| S01-A_16h | S01-A n=5 (Ifnb1/16h) | PSLN-212(Y) |  | 5 | 37.60 ± 3.45 |  | S01!B9:F9 |
| S01-A_16h | S01-A n=5 (Ifnb1/16h) | PSLN-344(Y) |  | 5 | 50.70 ± 7.57 |  | S01!B10:F10 |
| S01-A_72h | S01-A n=5 (Ifnb1/72h) | Sham |  | 5 | 0.996 ± 0.173 |  | S01!H3:L3 |
| S01-A_72h | S01-A n=5 (Ifnb1/72h) | CMP-204 |  | 5 | 2.222 ± 0.361 |  | S01!H4:L4 |
| S01-A_72h | S01-A n=5 (Ifnb1/72h) | PSLN-212 |  | 5 | 3.432 ± 0.395 |  | S01!H5:L5 |
| S01-A_72h | S01-A n=5 (Ifnb1/72h) | PSLN-R848 |  | 5 | 1.244 ± 0.061 |  | S01!H6:L6 |
| S01-A_72h | S01-A n=5 (Ifnb1/72h) | PSLN-212/R848 |  | 5 | 1.666 ± 0.316 |  | S01!H7:L7 |
| S01-A_72h | S01-A n=5 (Ifnb1/72h) | PSLN-344 |  | 5 | 4.428 ± 1.688 |  | S01!H8:L8 |
| S01-A_72h | S01-A n=5 (Ifnb1/72h) | PSLN-212(Y) |  | 5 | 1.590 ± 0.618 |  | S01!H9:L9 |
| S01-A_72h | S01-A n=5 (Ifnb1/72h) | PSLN-344(Y) |  | 5 | 3.128 ± 0.846 |  | S01!H10:L10 |
| S01-B | S01-B n=5 | AECII/PSLN-SRB |  | 5 | 15.80 ± 2.30 |  | S01!B14:F14 |
| S01-B | S01-B n=5 | AECI/PSLN-SRB |  | 5 | 3.832 ± 1.137 |  | S01!B15:F15 |
| S01-B | S01-B n=5 | AECII/FreeSRB |  | 5 | 0.378 ± 0.199 |  | S01!B16:F16 |
| S01-B | S01-B n=5 | AECI/FreeSRB |  | 5 | 0.332 ± 0.185 |  | S01!B17:F17 |
| S01-C | S01-C n=4 | WT |  | 4 | 43.10 ± 4.12 |  | S01!B20:E20 |
| S01-C | S01-C n=4 | SPA/D |  | 4 | 12.65 ± 3.01 |  | S01!B21:E21 |
| S01-D | S01-D n=5 | Sham | 0 | 5 | 8.000 ± 0.418 |  | S01!B24:F24 |
| S01-D | S01-D n=5 | PSLN-212 | 0 | 5 | 9.400 ± 1.338 |  | S01!G24:K24 |
| S01-D | S01-D n=5 | PSLN-344 | 0 | 5 | 9.180 ± 0.691 |  | S01!L24:P24 |
| S01-D | S01-D n=5 | PSLN-212(Y) | 0 | 5 | 10.84 ± 1.15 |  | S01!Q24:U24 |
| S01-D | S01-D n=5 | Sham | 2 | 5 | 10.36 ± 0.72 |  | S01!B25:F25 |
| S01-D | S01-D n=5 | PSLN-212 | 2 | 5 | 12.48 ± 0.85 |  | S01!G25:K25 |
| S01-D | S01-D n=5 | PSLN-344 | 2 | 5 | 15.00 ± 4.59 |  | S01!L25:P25 |
| S01-D | S01-D n=5 | PSLN-212(Y) | 2 | 5 | 15.64 ± 1.96 |  | S01!Q25:U25 |
| S01-D | S01-D n=5 | Sham | 4 | 5 | 10.42 ± 0.60 |  | S01!B26:F26 |
| S01-D | S01-D n=5 | PSLN-212 | 4 | 5 | 16.72 ± 1.63 |  | S01!G26:K26 |
| S01-D | S01-D n=5 | PSLN-344 | 4 | 5 | 30.56 ± 4.68 |  | S01!L26:P26 |
| S01-D | S01-D n=5 | PSLN-212(Y) | 4 | 5 | 32.22 ± 3.95 |  | S01!Q26:U26 |
| S01-D | S01-D n=5 | Sham | 6 | 5 | 11.24 ± 1.51 |  | S01!B27:F27 |
| S01-D | S01-D n=5 | PSLN-212 | 6 | 5 | 13.22 ± 2.49 |  | S01!G27:K27 |
| S01-D | S01-D n=5 | PSLN-344 | 6 | 5 | 24.48 ± 2.79 |  | S01!L27:P27 |
| S01-D | S01-D n=5 | PSLN-212(Y) | 6 | 5 | 25.22 ± 2.59 |  | S01!Q27:U27 |
| S01-D | S01-D n=5 | Sham | 8 | 5 | 9.480 ± 0.850 |  | S01!B28:F28 |
| S01-D | S01-D n=5 | PSLN-212 | 8 | 5 | 9.660 ± 1.280 |  | S01!G28:K28 |
| S01-D | S01-D n=5 | PSLN-344 | 8 | 5 | 18.44 ± 0.60 |  | S01!L28:P28 |
| S01-D | S01-D n=5 | PSLN-212(Y) | 8 | 5 | 14.08 ± 1.97 |  | S01!Q28:U28 |
| S01-E | S01-E n=5 | Sham | 0 | 5 | 1.340 ± 0.182 |  | S01!B30:F30 |
| S01-E | S01-E n=5 | PSLN-212 | 0 | 5 | 1.680 ± 0.444 |  | S01!G30:K30 |
| S01-E | S01-E n=5 | PSLN-344 | 0 | 5 | 1.300 ± 0.200 |  | S01!L30:P30 |
| S01-E | S01-E n=5 | PSLN-212(Y) | 0 | 5 | 1.240 ± 0.114 |  | S01!Q30:U30 |
| S01-E | S01-E n=5 | PSLN-344(Y) | 0 | 5 | 1.060 ± 0.336 |  | S01!V30:Z30 |
| S01-E | S01-E n=5 | Sham | 2 | 5 | 1.940 ± 0.404 |  | S01!B31:F31 |
| S01-E | S01-E n=5 | PSLN-212 | 2 | 5 | 3.720 ± 0.653 |  | S01!G31:K31 |
| S01-E | S01-E n=5 | PSLN-344 | 2 | 5 | 4.720 ± 0.978 |  | S01!L31:P31 |
| S01-E | S01-E n=5 | PSLN-212(Y) | 2 | 5 | 3.800 ± 1.384 |  | S01!Q31:U31 |
| S01-E | S01-E n=5 | PSLN-344(Y) | 2 | 5 | 4.900 ± 1.304 |  | S01!V31:Z31 |
| S01-E | S01-E n=5 | Sham | 4 | 5 | 4.800 ± 2.105 |  | S01!B32:F32 |
| S01-E | S01-E n=5 | PSLN-212 | 4 | 5 | 8.280 ± 1.916 |  | S01!G32:K32 |
| S01-E | S01-E n=5 | PSLN-344 | 4 | 5 | 18.88 ± 8.57 |  | S01!L32:P32 |
| S01-E | S01-E n=5 | PSLN-212(Y) | 4 | 5 | 21.40 ± 1.68 |  | S01!Q32:U32 |
| S01-E | S01-E n=5 | PSLN-344(Y) | 4 | 5 | 22.60 ± 2.95 |  | S01!V32:Z32 |
| S01-E | S01-E n=5 | Sham | 6 | 5 | 4.320 ± 1.527 |  | S01!B33:F33 |
| S01-E | S01-E n=5 | PSLN-212 | 6 | 5 | 7.800 ± 1.512 |  | S01!G33:K33 |
| S01-E | S01-E n=5 | PSLN-344 | 6 | 5 | 15.38 ± 4.17 |  | S01!L33:P33 |
| S01-E | S01-E n=5 | PSLN-212(Y) | 6 | 5 | 12.98 ± 1.65 |  | S01!Q33:U33 |
| S01-E | S01-E n=5 | PSLN-344(Y) | 6 | 5 | 16.30 ± 2.37 |  | S01!V33:Z33 |
| S01-E | S01-E n=5 | Sham | 8 | 5 | 2.440 ± 0.241 |  | S01!B34:F34 |
| S01-E | S01-E n=5 | PSLN-212 | 8 | 5 | 6.040 ± 1.218 |  | S01!G34:K34 |
| S01-E | S01-E n=5 | PSLN-344 | 8 | 5 | 13.68 ± 2.77 |  | S01!L34:P34 |
| S01-E | S01-E n=5 | PSLN-212(Y) | 8 | 5 | 9.480 ± 1.297 |  | S01!Q34:U34 |
| S01-E | S01-E n=5 | PSLN-344(Y) | 8 | 5 | 10.50 ± 1.66 |  | S01!V34:Z34 |
| S01-F | S01-F n=5 | Sham |  | 5 | 17.94 ± 2.46 |  | S01!B36:F36 |
| S01-F | S01-F n=5 | PSLN-212 |  | 5 | 22.80 ± 3.58 |  | S01!G36:K36 |
| S01-F | S01-F n=5 | PSLN-344 |  | 5 | 37.52 ± 6.99 |  | S01!L36:P36 |
| S01-F | S01-F n=5 | PSLN-212(Y) |  | 5 | 43.42 ± 5.35 |  | S01!Q36:U36 |
| S01-F | S01-F n=5 | PSLN-344(Y) |  | 5 | 44.26 ± 1.56 |  | S01!V36:Z36 |
| S01-G | S01-G n=5 | Sham |  | 5 | 80.62 ± 3.62 |  | S01!B38:F38 |
| S01-G | S01-G n=5 | PSLN-212 |  | 5 | 75.30 ± 2.88 |  | S01!G38:K38 |
| S01-G | S01-G n=5 | PSLN-344 |  | 5 | 59.46 ± 6.83 |  | S01!L38:P38 |
| S01-G | S01-G n=5 | PSLN-212(Y) |  | 5 | 54.08 ± 7.20 |  | S01!Q38:U38 |
| S01-G | S01-G n=5 | PSLN-344(Y) |  | 5 | 51.36 ± 7.30 |  | S01!V38:Z38 |
| S02-A | S02-A n=5 | Sham |  | 5 | 2.540 ± 0.660 |  | S02!A3:A7 |
| S02-A | S02-A n=5 | PSLN-212 |  | 5 | 7.280 ± 2.041 |  | S02!B3:B7 |
| S02-A | S02-A n=5 | PSLN-344 |  | 5 | 30.68 ± 7.86 |  | S02!C3:C7 |
| S02-A | S02-A n=5 | PSLN-212(Y) |  | 5 | 35.00 ± 4.83 |  | S02!D3:D7 |
| S02-B | S02-B n=5 | Sham |  | 5 | 13.92 ± 4.22 |  | S02!F3:F7 |
| S02-B | S02-B n=5 | PSLN-212 |  | 5 | 18.22 ± 6.40 |  | S02!G3:G7 |
| S02-B | S02-B n=5 | PSLN-344 |  | 5 | 36.76 ± 9.24 |  | S02!H3:H7 |
| S02-B | S02-B n=5 | PSLN-212(Y) |  | 5 | 44.70 ± 7.69 |  | S02!I3:I7 |
| S02-C | S02-C n=5 | PSLN-212 |  | 5 | 1.770 ± 0.389 |  | S02!K3:K7 |
| S02-C | S02-C n=5 | PSLN-344 |  | 5 | 7.090 ± 1.417 |  | S02!L3:L7 |
| S02-C | S02-C n=5 | PSLN-212(Y) |  | 5 | 9.390 ± 1.495 |  | S02!M3:M7 |
| S02-C | S02-C n=5 | PTX |  | 5 | 2.356 ± 0.877 |  | S02!N3:N7 |
| S02-C | S02-C n=5 | PSLN-344(Y) |  | 5 | 11.12 ± 1.79 |  | S02!O3:O7 |
| S02-D_CD40 | S02-D CD40 n=5 | Sham |  | 5 | 3.960 ± 1.035 |  | S02!A10:A14 |
| S02-D_CD40 | S02-D CD40 n=5 | PSLN-212 |  | 5 | 5.556 ± 1.124 |  | S02!B10:B14 |
| S02-D_CD40 | S02-D CD40 n=5 | PSLN-344 |  | 5 | 11.20 ± 3.00 |  | S02!C10:C14 |
| S02-D_CD40 | S02-D CD40 n=5 | PSLN-212(Y) |  | 5 | 38.72 ± 7.30 |  | S02!D10:D14 |
| S02-D_CD86 | S02-D CD86 n=5 | Sham |  | 5 | 7.176 ± 1.511 |  | S02!F10:F14 |
| S02-D_CD86 | S02-D CD86 n=5 | PSLN-212 |  | 5 | 8.128 ± 1.794 |  | S02!G10:G14 |
| S02-D_CD86 | S02-D CD86 n=5 | PSLN-344 |  | 5 | 14.54 ± 2.71 |  | S02!H10:H14 |
| S02-D_CD86 | S02-D CD86 n=5 | PSLN-212(Y) |  | 5 | 37.94 ± 5.54 |  | S02!I10:I14 |
| S02-E | S02-E n=5 | PSLN-212 |  | 5 | 0.766 ± 0.529 |  | S02!K10:K14 |
| S02-E | S02-E n=5 | PSLN-344 |  | 5 | 18.65 ± 2.85 |  | S02!L10:L14 |
| S02-E | S02-E n=5 | PSLN-212(Y) |  | 5 | 26.24 ± 6.69 |  | S02!M10:M14 |
| S02-E | S02-E n=5 | PTX |  | 5 | 2.548 ± 1.806 |  | S02!N10:N14 |
| S02-E | S02-E n=5 | PSLN-344(Y) |  | 5 | 31.40 ± 6.68 |  | S02!O10:O14 |
| S02-F | S02-F n=5 | PSLN-344 | 16h | 5 | 5.998 ± 0.392 |  | S02!B17:F17 |
| S02-F | S02-F n=5 | PSLN-212 | 16h | 5 | 1.486 ± 0.482 |  | S02!G17:K17 |
| S02-F | S02-F n=5 | Sham | 16h | 5 | 0.998 ± 0.193 |  | S02!L17:P17 |
| S02-F | S02-F n=5 | PSLN-344 | 36h | 5 | 8.742 ± 2.150 |  | S02!B18:F18 |
| S02-F | S02-F n=5 | PSLN-212 | 36h | 5 | 1.594 ± 0.139 |  | S02!G18:K18 |
| S02-F | S02-F n=5 | Sham | 36h | 5 | 1.214 ± 0.239 |  | S02!L18:P18 |
| S02-F | S02-F n=5 | PSLN-344 | 72h | 5 | 3.850 ± 1.546 |  | S02!B19:F19 |
| S02-F | S02-F n=5 | PSLN-212 | 72h | 5 | 1.386 ± 0.214 |  | S02!G19:K19 |
| S02-F | S02-F n=5 | Sham | 72h | 5 | 1.162 ± 0.269 |  | S02!L19:P19 |
| S02-G | S02-G n=5 | GM-CSF |  | 5 | 1.520 ± 0.331 |  | S02!B22:B26 |
| S02-G | S02-G n=5 | PSLN-212 |  | 5 | 5.858 ± 1.485 |  | S02!C22:C26 |
| S02-G | S02-G n=5 | PSLN-212+GM-CSF |  | 5 | 13.82 ± 3.04 |  | S02!D22:D26 |
| S02-H | S02-H n=5 | WT w/o cDC |  | 5 | 19.70 ± 4.01 |  | S02!B30:B34 |
| S02-H | S02-H n=5 | WT w/ cDC |  | 5 | 27.22 ± 7.25 |  | S02!C30:C34 |
| S02-H | S02-H n=5 | IFN w/o cDC |  | 5 | 2.088 ± 0.927 |  | S02!D30:D34 |
| S02-H | S02-H n=5 | IFN w/ cDC |  | 5 | 6.070 ± 1.270 |  | S02!E30:E34 |
| S02-H | S02-H n=5 | GMCSF |  | 5 | 12.40 ± 3.74 |  | S02!F30:F34 |
| S02-I | S02-I n=5 | PSLN-344(Y) |  | 5 | 6.770 ± 1.055 |  | S02!H30:H34 |
| S02-I | S02-I n=5 | PSLN-344(Y)+INCB3344 |  | 5 | 1.390 ± 0.458 |  | S02!I30:I34 |
| S03-A | S03-A n=5 | Sham |  | 5 | 75.60 ± 67.44 | 56 [19–164] | S03!A3:A7 |
| S03-A | S03-A n=5 | CMP-204 |  | 5 | 229 ± 193 | 181 [74–445] | S03!B3:B7 |
| S03-A | S03-A n=5 | PSLN-212 |  | 5 | 437 ± 234 | 393 [210–737] | S03!C3:C7 |
| S03-A | S03-A n=5 | PSLN-344 |  | 5 | 7892 ± 3101 | 7,305 [4,081–13,076] | S03!D3:D7 |
| S03-A | S03-A n=5 | PSLN-212(Y) |  | 5 | 12775 ± 5235 | 11,959 [7,242–19,747] | S03!E3:E7 |
| S03-B | S03-B n=5 | PSLN-212 |  | 5 | 2.972 ± 1.692 |  | S03!G3:G7 |
| S03-B | S03-B n=5 | PSLN-344 |  | 5 | 0.578 ± 0.204 |  | S03!H3:H7 |
| S03-B | S03-B n=5 | PSLN-212(Y) |  | 5 | 2.144 ± 1.306 |  | S03!I3:I7 |
| S03-C | S03-C n=5 | Sham |  | 5 | 6.000 ± 5.477 | 8 [5–12] | S03!K3:K7 |
| S03-C | S03-C n=5 | CMP-204 |  | 5 | 26.00 ± 13.42 | 23 [11–47] | S03!L3:L7 |
| S03-C | S03-C n=5 | PSLN-212 |  | 5 | 48.00 ± 17.89 | 46 [31–68] | S03!M3:M7 |
| S03-C | S03-C n=5 | PSLN-344 |  | 5 | 416 ± 215 | 368 [179–755] | S03!N3:N7 |
| S03-C | S03-C n=5 | PSLN-212(Y) |  | 5 | 512 ± 175 | 485 [303–777] | S03!O3:O7 |
| S03-D | S03-D n=5 | Sham |  | 5 | 60.00 ± 36.74 | 52 [25–107] | S03!Q3:Q7 |
| S03-D | S03-D n=5 | CMP-204 |  | 5 | 216 ± 156 | 182 [84–393] | S03!R3:R7 |
| S03-D | S03-D n=5 | PSLN-212 |  | 5 | 480 ± 294 | 418 [203–859] | S03!S3:S7 |
| S03-D | S03-D n=5 | PSLN-344 |  | 5 | 4800 ± 2880 | 3,840 [1,338–11,018] | S03!T3:T7 |
| S03-D | S03-D n=5 | PSLN-212(Y) |  | 5 | 7680 ± 4703 | 6,686 [3,254–13,737] | S03!U3:U7 |
| S03-E | S03-E n=5 | Sham |  | 5 | 77.40 ± 74.36 | 52 [15–186] | S03!A10:A14 |
| S03-E | S03-E n=5 | CMP-204 |  | 5 | 263 ± 212 | 200 [72–557] | S03!B10:B14 |
| S03-E | S03-E n=5 | PSLN-212 |  | 5 | 468 ± 216 | 426 [227–798] | S03!C10:C14 |
| S03-E | S03-E n=5 | PSLN-344 |  | 5 | 6387 ± 2987 | 5,701 [2,794–11,631] | S03!D10:D14 |
| S03-E | S03-E n=5 | PSLN-212(Y) |  | 5 | 15722 ± 8722 | 13,855 [6,894–27,847] | S03!E10:E14 |
| S03-F | S03-F n=5 | PSLN-212 |  | 5 | 2.891 ± 0.799 |  | S03!G10:G14 |
| S03-F | S03-F n=5 | PSLN-344 |  | 5 | 0.512 ± 0.250 |  | S03!H10:H14 |
| S03-F | S03-F n=5 | PSLN-212(Y) |  | 5 | 2.727 ± 1.777 |  | S03!I10:I14 |
| S03-G | S03-G n=5 | Sham |  | 5 | 10.00 ± 7.07 | 10 [5–18] | S03!K10:K14 |
| S03-G | S03-G n=5 | CMP-204 |  | 5 | 32.00 ± 10.95 | 30 [19–49] | S03!L10:L14 |
| S03-G | S03-G n=5 | PSLN-212 |  | 5 | 40.00 ± 24.49 | 35 [17–72] | S03!M10:M14 |
| S03-G | S03-G n=5 | PSLN-344 |  | 5 | 352 ± 175 | 320 [174–588] | S03!N10:N14 |
| S03-G | S03-G n=5 | PSLN-212(Y) |  | 5 | 384 ± 143 | 368 [250–540] | S03!O10:O14 |
| S03-H | S03-H n=5 | Sham |  | 5 | 42.00 ± 16.43 | 40 [25–63] | S03!Q10:Q14 |
| S03-H | S03-H n=5 | CMP-204 |  | 5 | 156 ± 80 | 138 [67–283] | S03!R10:R14 |
| S03-H | S03-H n=5 | PSLN-212 |  | 5 | 312 ± 161 | 276 [134–566] | S03!S10:S14 |
| S03-H | S03-H n=5 | PSLN-344 |  | 5 | 2880 ± 1358 | 2,533 [1,173–5,471] | S03!T10:T14 |
| S03-H | S03-H n=5 | PSLN-212(Y) |  | 5 | 4992 ± 2576 | 4,411 [2,147–9,063] | S03!U10:U14 |
| S03-K | S03-K n=5 | Sham |  | 5 | 1.176 ± 0.400 |  | S03!L17:L21 |
| S03-K | S03-K n=5 | PSLN-212 |  | 5 | 2.342 ± 0.519 |  | S03!M17:M21 |
| S03-K | S03-K n=5 | PSLN-344 |  | 5 | 6.544 ± 1.535 |  | S03!N17:N21 |
| S03-K | S03-K n=5 | PSLN-212(Y) |  | 5 | 9.822 ± 3.053 |  | S03!O17:O21 |
| S03-L_Aicda | S03-L n=3 (Aicda) | Sham |  | 3 | 1.000 ± 0.305 |  | S03!L26:N26 |
| S03-L_Aicda | S03-L n=3 (Aicda) | PSLN-212 |  | 3 | 3.417 ± 0.972 |  | S03!L27:N27 |
| S03-L_Aicda | S03-L n=3 (Aicda) | PSLN-344 |  | 3 | 11.98 ± 4.02 |  | S03!L28:N28 |
| S03-L_E47 | S03-L n=3 (E47) | Sham |  | 3 | 1.000 ± 0.326 |  | S03!O26:Q26 |
| S03-L_E47 | S03-L n=3 (E47) | PSLN-212 |  | 3 | 6.357 ± 2.141 |  | S03!O27:Q27 |
| S03-L_E47 | S03-L n=3 (E47) | PSLN-344 |  | 3 | 24.54 ± 5.50 |  | S03!O28:Q28 |
| S04-A_ICOSlo | S04-A n=5 (ICOS-CXCR5+PD1+) | Sham |  | 5 | 2.023 ± 1.038 |  | S04!B2:F2 |
| S04-A_ICOSlo | S04-A n=5 (ICOS-CXCR5+PD1+) | PSLN-212 |  | 5 | 2.705 ± 0.660 |  | S04!B3:F3 |
| S04-A_ICOSlo | S04-A n=5 (ICOS-CXCR5+PD1+) | PSLN-344 |  | 5 | 5.743 ± 2.056 |  | S04!B4:F4 |
| S04-A_ICOSlo | S04-A n=5 (ICOS-CXCR5+PD1+) | PSLN-212(Y) |  | 5 | 6.909 ± 2.276 |  | S04!B5:F5 |
| S04-A_ICOShi | S04-A n=5 (ICOS+CXCR5+PD1+) | Sham |  | 5 | 0.296 ± 0.158 |  | S04!G2:K2 |
| S04-A_ICOShi | S04-A n=5 (ICOS+CXCR5+PD1+) | PSLN-212 |  | 5 | 3.815 ± 0.851 |  | S04!G3:K3 |
| S04-A_ICOShi | S04-A n=5 (ICOS+CXCR5+PD1+) | PSLN-344 |  | 5 | 10.26 ± 3.16 |  | S04!G4:K4 |
| S04-A_ICOShi | S04-A n=5 (ICOS+CXCR5+PD1+) | PSLN-212(Y) |  | 5 | 13.63 ± 1.64 |  | S04!G5:K5 |
| S04-B_Tfr | S04-B  Foxp3+ in CXCR5+ n=5 | Sham |  | 5 | 22.60 ± 4.40 |  | S04!A8:A12 |
| S04-B_Tfr | S04-B  Foxp3+ in CXCR5+ n=5 | PSLN-212 |  | 5 | 26.66 ± 6.67 |  | S04!B8:B12 |
| S04-B_Tfr | S04-B  Foxp3+ in CXCR5+ n=5 | PSLN-344 |  | 5 | 10.80 ± 1.78 |  | S04!C8:C12 |
| S04-B_Tfr | S04-B  Foxp3+ in CXCR5+ n=5 | PSLN-212(Y) |  | 5 | 7.120 ± 3.671 |  | S04!D8:D12 |
| S04-B_ratio | S04-B  Tfh:Tfr n=5 | Sham |  | 5 | 3.555 ± 0.841 |  | S04!A15:A19 |
| S04-B_ratio | S04-B  Tfh:Tfr n=5 | PSLN-212 |  | 5 | 2.935 ± 0.928 |  | S04!B15:B19 |
| S04-B_ratio | S04-B  Tfh:Tfr n=5 | PSLN-344 |  | 5 | 8.475 ± 1.651 |  | S04!C15:C19 |
| S04-B_ratio | S04-B  Tfh:Tfr n=5 | PSLN-212(Y) |  | 5 | 16.05 ± 8.28 |  | S04!D15:D19 |
| S04-C | S04-C   n=5 | Sham |  | 5 | 13.86 ± 1.83 |  | S04!A22:A26 |
| S04-C | S04-C   n=5 | PSLN-212 |  | 5 | 18.04 ± 3.80 |  | S04!B22:B26 |
| S04-C | S04-C   n=5 | PSLN-344 |  | 5 | 14.00 ± 3.24 |  | S04!C22:C26 |
| S04-C | S04-C   n=5 | PSLN-212(Y) |  | 5 | 7.396 ± 1.620 |  | S04!D22:D26 |
| S04-D | S04-D   n=3 | Sham |  | 3 | 5.880 ± 0.839 |  | S04!A29:A31 |
| S04-D | S04-D   n=3 | PSLN-212 |  | 3 | 6.660 ± 0.338 |  | S04!B29:B31 |
| S04-D | S04-D   n=3 | PSLN-344 |  | 3 | 2.987 ± 0.410 |  | S04!C29:C31 |
| S04-D | S04-D   n=3 | PSLN-212(Y) |  | 3 | 1.777 ± 0.594 |  | S04!D29:D31 |
| S05-A | S05-A n=3 Lung | PSLN-212 | 3 | 2 (stated 3) | 2.090 ± 0.212 |  | S05!B3:C3 |
| S05-A | S05-A n=3 Lung | PSLN-344 | 3 | 2 (stated 3) | 6.680 ± 0.636 |  | S05!E3:F3 |
| S05-A | S05-A n=3 Lung | PSLN-212Y | 3 | 2 (stated 3) | 9.850 ± 1.344 |  | S05!H3:I3 |
| S05-A | S05-A n=3 Lung | PSLN-212 | 5 | 2 (stated 3) | 5.115 ± 1.138 |  | S05!B4:C4 |
| S05-A | S05-A n=3 Lung | PSLN-344 | 5 | 2 (stated 3) | 12.01 ± 0.86 |  | S05!E4:F4 |
| S05-A | S05-A n=3 Lung | PSLN-212Y | 5 | 2 (stated 3) | 13.45 ± 1.63 |  | S05!H4:I4 |
| S05-A | S05-A n=3 Lung | PSLN-212 | 7 | 2 (stated 3) | 6.905 ± 0.969 |  | S05!B5:C5 |
| S05-A | S05-A n=3 Lung | PSLN-344 | 7 | 2 (stated 3) | 14.25 ± 2.19 |  | S05!E5:F5 |
| S05-A | S05-A n=3 Lung | PSLN-212Y | 7 | 2 (stated 3) | 15.15 ± 1.63 |  | S05!H5:I5 |
| S05-B | S05-B n=3 MLN | PSLN-212 | 3 | 2 (stated 3) | 1.185 ± 0.219 |  | S05!B8:C8 |
| S05-B | S05-B n=3 MLN | PSLN-344 | 3 | 2 (stated 3) | 1.810 ± 0.156 |  | S05!E8:F8 |
| S05-B | S05-B n=3 MLN | PSLN-212Y | 3 | 2 (stated 3) | 2.045 ± 0.148 |  | S05!H8:I8 |
| S05-B | S05-B n=3 MLN | PSLN-212 | 5 | 2 (stated 3) | 1.670 ± 0.113 |  | S05!B9:C9 |
| S05-B | S05-B n=3 MLN | PSLN-344 | 5 | 2 (stated 3) | 3.160 ± 0.410 |  | S05!E9:F9 |
| S05-B | S05-B n=3 MLN | PSLN-212Y | 5 | 2 (stated 3) | 4.285 ± 1.747 |  | S05!H9:I9 |
| S05-B | S05-B n=3 MLN | PSLN-212 | 7 | 2 (stated 3) | 2.610 ± 0.368 |  | S05!B10:C10 |
| S05-B | S05-B n=3 MLN | PSLN-344 | 7 | 2 (stated 3) | 4.360 ± 0.580 |  | S05!E10:F10 |
| S05-B | S05-B n=3 MLN | PSLN-212Y | 7 | 2 (stated 3) | 5.740 ± 0.834 |  | S05!H10:I10 |
| S05-C | S05-C n=3 | Lung |  | 3 | 59.00 ± 4.99 |  | S05!A13:A15 |
| S05-C | S05-C n=3 | Lung+PTX |  | 3 | 55.07 ± 9.45 |  | S05!B13:B15 |
| S05-C | S05-C n=3 | MLN |  | 3 | 30.90 ± 3.87 |  | S05!C13:C15 |
| S05-C | S05-C n=3 | MLN+PTX |  | 3 | 6.833 ± 0.799 |  | S05!D13:D15 |
| S05-D | S05-D n=5 | Sham |  | 5 | 0.826 ± 0.452 |  | S05!A19:A23 |
| S05-D | S05-D n=5 | PSLN-212 |  | 5 | 3.480 ± 1.350 |  | S05!B19:B23 |
| S05-D | S05-D n=5 | PSLN-344 |  | 5 | 9.380 ± 1.781 |  | S05!C19:C23 |
| S05-D | S05-D n=5 | PSLN-212(Y) |  | 5 | 9.940 ± 3.029 |  | S05!D19:D23 |
| S05-E | S05-E n=5 | Sham |  | 5 | 0.990 ± 0.380 |  | S05!A26:A30 |
| S05-E | S05-E n=5 | PSLN-212 |  | 5 | 2.990 ± 0.785 |  | S05!B26:B30 |
| S05-E | S05-E n=5 | PSLN-344 |  | 5 | 5.688 ± 0.904 |  | S05!C26:C30 |
| S05-E | S05-E n=5 | PSLN-212(Y) |  | 5 | 9.608 ± 1.209 |  | S05!D26:D30 |
| S05-F | S05-F n=5 | Sham |  | 5 | 0.672 ± 0.355 |  | S05!A33:A37 |
| S05-F | S05-F n=5 | PSLN-212 |  | 5 | 1.504 ± 0.387 |  | S05!B33:B37 |
| S05-F | S05-F n=5 | PSLN-344 |  | 5 | 6.356 ± 0.998 |  | S05!C33:C37 |
| S05-F | S05-F n=5 | PSLN-212(Y) |  | 5 | 9.180 ± 0.900 |  | S05!D33:D37 |
| S05-G | S05-G n=5 | Sham |  | 5 | 1.460 ± 1.073 |  | S05!A40:A44 |
| S05-G | S05-G n=5 | PSLN-212 |  | 5 | 3.040 ± 1.254 |  | S05!B40:B44 |
| S05-G | S05-G n=5 | PSLN-344 |  | 5 | 9.860 ± 2.806 |  | S05!C40:C44 |
| S05-G | S05-G n=5 | PSLN-212(Y) |  | 5 | 14.36 ± 2.94 |  | S05!D40:D44 |
| S05-H | S05-H n=5 | Sham |  | 5 | 0.602 ± 0.394 |  | S05!A47:A51 |
| S05-H | S05-H n=5 | PSLN-212 |  | 5 | 1.024 ± 0.310 |  | S05!B47:B51 |
| S05-H | S05-H n=5 | PSLN-344 |  | 5 | 4.106 ± 1.119 |  | S05!C47:C51 |
| S05-H | S05-H n=5 | PSLN-212(Y) |  | 5 | 5.554 ± 1.435 |  | S05!D47:D51 |
| S05-I | S05-I n=5 | Sham |  | 5 | 0.580 ± 0.311 |  | S05!A54:A58 |
| S05-I | S05-I n=5 | PSLN-212 |  | 5 | 1.000 ± 0.368 |  | S05!B54:B58 |
| S05-I | S05-I n=5 | PSLN-344 |  | 5 | 3.964 ± 0.625 |  | S05!C54:C58 |
| S05-I | S05-I n=5 | PSLN-212(Y) |  | 5 | 6.042 ± 0.599 |  | S05!D54:D58 |
| S07-A | S07-A n=3 | PSLN-212 | 0 | 3 | 1.367 ± 0.573 |  | S07!B3:D3 |
| S07-A | S07-A n=3 | PSLN-344 | 0 | 3 | 1.950 ± 0.766 |  | S07!E3:G3 |
| S07-A | S07-A n=3 | PSLN-212 | 2 | 3 | 10.11 ± 4.66 |  | S07!B4:D4 |
| S07-A | S07-A n=3 | PSLN-344 | 2 | 3 | 3.270 ± 0.990 |  | S07!E4:G4 |
| S07-A | S07-A n=3 | PSLN-212 | 5 | 3 | 19.03 ± 5.47 |  | S07!B5:D5 |
| S07-A | S07-A n=3 | PSLN-344 | 5 | 3 | 3.423 ± 0.764 |  | S07!E5:G5 |
| S07-A | S07-A n=3 | PSLN-212 | 10 | 3 | 14.56 ± 1.83 |  | S07!B6:D6 |
| S07-A | S07-A n=3 | PSLN-344 | 10 | 3 | 2.877 ± 1.360 |  | S07!E6:G6 |
| S07-A | S07-A n=3 | PSLN-212 | 30 | 3 | 4.160 ± 1.950 |  | S07!B7:D7 |
| S07-A | S07-A n=3 | PSLN-344 | 30 | 3 | 2.350 ± 0.521 |  | S07!E7:G7 |
| S07-B_mono | S07-B n=5 (CD11b+Ly6C+ Monocytes) | PSLN-344 |  | 5 | 9.862 ± 2.256 |  | S07!B10:B14 |
| S07-B_mono | S07-B n=5 (CD11b+Ly6C+ Monocytes) | PSLN-344+INCB3344 |  | 5 | 3.260 ± 1.367 |  | S07!C10:C14 |
| S07-B_mac | S07-B n=5 (Ly6C+ Mphi) | PSLN-344 |  | 5 | 15.35 ± 4.51 |  | S07!E10:E14 |
| S07-B_mac | S07-B n=5 (Ly6C+ Mphi) | PSLN-344+INCB3344 |  | 5 | 2.522 ± 0.612 |  | S07!F10:F14 |
| S07-C | S07-C n=5 | Ly6C-CD206+ MΦ |  | 5 | 10.44 ± 2.12 |  | S07!B16:B20 |
| S07-C | S07-C n=5 | Ly6C-CD206+ MΦ [col C] |  | 5 | 5.142 ± 1.584 |  | S07!C16:C20 |
| S08-A | S08-A n=3 | CMP-204 | 1 | 3 | 1.000 ± 0.062 |  | S08!B3:D3 |
| S08-A | S08-A n=3 | PSLN-212 | 1 | 3 | 1.360 ± 0.118 |  | S08!E3:G3 |
| S08-A | S08-A n=3 | PSLN-344 | 1 | 3 | 1.383 ± 0.162 |  | S08!H3:J3 |
| S08-A | S08-A n=3 | PSLN-344/R848 | 1 | 3 | 1.027 ± 0.193 |  | S08!K3:M3 |
| S08-A | S08-A n=3 | CMP-204 | 5 | 3 | 3.803 ± 0.403 |  | S08!B4:D4 |
| S08-A | S08-A n=3 | PSLN-212 | 5 | 3 | 4.100 ± 0.819 |  | S08!E4:G4 |
| S08-A | S08-A n=3 | PSLN-344 | 5 | 3 | 8.273 ± 1.526 |  | S08!H4:J4 |
| S08-A | S08-A n=3 | PSLN-344/R848 | 5 | 3 | 6.707 ± 1.138 |  | S08!K4:M4 |
| S08-A | S08-A n=3 | CMP-204 | 10 | 3 | 6.257 ± 0.553 |  | S08!B5:D5 |
| S08-A | S08-A n=3 | PSLN-212 | 10 | 3 | 8.920 ± 0.360 |  | S08!E5:G5 |
| S08-A | S08-A n=3 | PSLN-344 | 10 | 3 | 21.09 ± 2.64 |  | S08!H5:J5 |
| S08-A | S08-A n=3 | PSLN-344/R848 | 10 | 3 | 14.71 ± 2.22 |  | S08!K5:M5 |
| S08-A | S08-A n=3 | CMP-204 | 20 | 3 | 7.293 ± 0.979 |  | S08!B6:D6 |
| S08-A | S08-A n=3 | PSLN-212 | 20 | 3 | 12.57 ± 1.51 |  | S08!E6:G6 |
| S08-A | S08-A n=3 | PSLN-344 | 20 | 3 | 45.83 ± 6.47 |  | S08!H6:J6 |
| S08-A | S08-A n=3 | PSLN-344/R848 | 20 | 3 | 29.45 ± 6.26 |  | S08!K6:M6 |
| S08-A | S08-A n=3 | CMP-204 | 40 | 3 | 7.960 ± 1.451 |  | S08!B7:D7 |
| S08-A | S08-A n=3 | PSLN-212 | 40 | 3 | 14.87 ± 2.56 |  | S08!E7:G7 |
| S08-A | S08-A n=3 | PSLN-344 | 40 | 3 | 50.23 ± 8.74 |  | S08!H7:J7 |
| S08-A | S08-A n=3 | PSLN-344/R848 | 40 | 3 | 34.91 ± 6.17 |  | S08!K7:M7 |
| S08-B | S08-B n=3 | CMP-204 |  | 3 | 65.24 ± 5.97 |  | S08!A11:C11 |
| S08-B | S08-B n=3 | PSLN-212 |  | 3 | 59.64 ± 4.55 |  | S08!D11:F11 |
| S08-B | S08-B n=3 | PSLN-R848 |  | 3 | 61.34 ± 6.79 |  | S08!G11:I11 |
| S08-B | S08-B n=3 | PSLN-212/R848 |  | 3 | 52.42 ± 7.26 |  | S08!J11:L11 |
| S08-B | S08-B n=3 | PSLN-344 |  | 3 | 54.82 ± 5.08 |  | S08!M11:O11 |
| S08-C | S08-C n=5 | AECII-PSLN-SRB |  | 5 | 15.76 ± 3.16 |  | S08!A14:A18 |
| S08-C | S08-C n=5 | AECII-PSLN-344-SRB |  | 5 | 3.806 ± 1.087 |  | S08!B14:B18 |
| S08-C | S08-C n=5 | AECI-PSLN-SRB |  | 5 | 13.76 ± 1.54 |  | S08!C14:C18 |
| S08-C | S08-C n=5 | AECI-PSLN-344-SRB |  | 5 | 3.000 ± 0.658 |  | S08!D14:D18 |
| S09-A_p1_Ifnb1 | S09-A 16h n=3 Log10 (cols A-V; Ifnb1) | PBS |  | 3 | -0.000 ± 0.241 | 1.0× | S09!B3:D3 |
| S09-A_p1_Ifnb1 | S09-A 16h n=3 Log10 (cols A-V; Ifnb1) | CMP-204 |  | 3 | 0.883 ± 0.126 | 7.6× | S09!E3:G3 |
| S09-A_p1_Ifnb1 | S09-A 16h n=3 Log10 (cols A-V; Ifnb1) | PSLN-212 |  | 3 | 1.217 ± 0.080 | 16.5× | S09!H3:J3 |
| S09-A_p1_Ifnb1 | S09-A 16h n=3 Log10 (cols A-V; Ifnb1) | PSLN-R848 |  | 3 | 0.638 ± 0.295 | 4.3× | S09!K3:M3 |
| S09-A_p1_Ifnb1 | S09-A 16h n=3 Log10 (cols A-V; Ifnb1) | PSLN-212/R848 |  | 3 | 1.381 ± 0.074 | 24.0× | S09!N3:P3 |
| S09-A_p1_Ifnb1 | S09-A 16h n=3 Log10 (cols A-V; Ifnb1) | PSLN-344 |  | 3 | 1.560 ± 0.075 | 36.3× | S09!Q3:S3 |
| S09-A_p1_Ifnb1 | S09-A 16h n=3 Log10 (cols A-V; Ifnb1) | PSLN-212(y) |  | 3 | 1.578 ± 0.049 | 37.8× | S09!T3:V3 |
| S09-A_p2_Ifnb1 | S09-A 16h n=3 Log10 (cols X-AS; Ifnb1) [second panel, same printed label] | PBS |  | 3 | 0.000 ± 0.080 | 1.0× | S09!Y3:AA3 |
| S09-A_p2_Ifnb1 | S09-A 16h n=3 Log10 (cols X-AS; Ifnb1) [second panel, same printed label] | CMP-204 |  | 3 | 0.339 ± 0.091 | 2.2× | S09!AB3:AD3 |
| S09-A_p2_Ifnb1 | S09-A 16h n=3 Log10 (cols X-AS; Ifnb1) [second panel, same printed label] | PSLN-212 |  | 3 | 0.532 ± 0.064 | 3.4× | S09!AE3:AG3 |
| S09-A_p2_Ifnb1 | S09-A 16h n=3 Log10 (cols X-AS; Ifnb1) [second panel, same printed label] | PSLN-R848 |  | 3 | 0.096 ± 0.017 | 1.2× | S09!AH3:AJ3 |
| S09-A_p2_Ifnb1 | S09-A 16h n=3 Log10 (cols X-AS; Ifnb1) [second panel, same printed label] | PSLN-212/R848 |  | 3 | 0.216 ± 0.041 | 1.6× | S09!AK3:AM3 |
| S09-A_p2_Ifnb1 | S09-A 16h n=3 Log10 (cols X-AS; Ifnb1) [second panel, same printed label] | PSLN-344 |  | 3 | 0.603 ± 0.242 | 4.0× | S09!AN3:AP3 |
| S09-A_p2_Ifnb1 | S09-A 16h n=3 Log10 (cols X-AS; Ifnb1) [second panel, same printed label] | PSLN-212(y) |  | 3 | 0.144 ± 0.296 | 1.4× | S09!AQ3:AS3 |
| S09-A_p1_Il6 | S09-A 16h n=3 Log10 (cols A-V; Il6) | PBS |  | 3 | -0.000 ± 0.301 | 1.0× | S09!B4:D4 |
| S09-A_p1_Il6 | S09-A 16h n=3 Log10 (cols A-V; Il6) | CMP-204 |  | 3 | 0.369 ± 0.047 | 2.3× | S09!E4:G4 |
| S09-A_p1_Il6 | S09-A 16h n=3 Log10 (cols A-V; Il6) | PSLN-212 |  | 3 | 0.746 ± 0.238 | 5.6× | S09!H4:J4 |
| S09-A_p1_Il6 | S09-A 16h n=3 Log10 (cols A-V; Il6) | PSLN-R848 |  | 3 | 0.295 ± 0.110 | 2.0× | S09!K4:M4 |
| S09-A_p1_Il6 | S09-A 16h n=3 Log10 (cols A-V; Il6) | PSLN-212/R848 |  | 3 | 1.492 ± 0.165 | 31.0× | S09!N4:P4 |
| S09-A_p1_Il6 | S09-A 16h n=3 Log10 (cols A-V; Il6) | PSLN-344 |  | 3 | 1.557 ± 0.287 | 36.1× | S09!Q4:S4 |
| S09-A_p1_Il6 | S09-A 16h n=3 Log10 (cols A-V; Il6) | PSLN-212(y) |  | 3 | 1.780 ± 0.195 | 60.3× | S09!T4:V4 |
| S09-A_p2_Il6 | S09-A 16h n=3 Log10 (cols X-AS; Il6) [second panel, same printed label] | PBS |  | 3 | 0.000 ± 0.216 | 1.0× | S09!Y4:AA4 |
| S09-A_p2_Il6 | S09-A 16h n=3 Log10 (cols X-AS; Il6) [second panel, same printed label] | CMP-204 |  | 3 | 0.038 ± 0.084 | 1.1× | S09!AB4:AD4 |
| S09-A_p2_Il6 | S09-A 16h n=3 Log10 (cols X-AS; Il6) [second panel, same printed label] | PSLN-212 |  | 3 | 0.271 ± 0.103 | 1.9× | S09!AE4:AG4 |
| S09-A_p2_Il6 | S09-A 16h n=3 Log10 (cols X-AS; Il6) [second panel, same printed label] | PSLN-R848 |  | 3 | 0.609 ± 0.045 | 4.1× | S09!AH4:AJ4 |
| S09-A_p2_Il6 | S09-A 16h n=3 Log10 (cols X-AS; Il6) [second panel, same printed label] | PSLN-212/R848 |  | 3 | 1.529 ± 0.148 | 33.8× | S09!AK4:AM4 |
| S09-A_p2_Il6 | S09-A 16h n=3 Log10 (cols X-AS; Il6) [second panel, same printed label] | PSLN-344 |  | 3 | 0.856 ± 0.216 | 7.2× | S09!AN4:AP4 |
| S09-A_p2_Il6 | S09-A 16h n=3 Log10 (cols X-AS; Il6) [second panel, same printed label] | PSLN-212(y) |  | 3 | 0.492 ± 0.086 | 3.1× | S09!AQ4:AS4 |
| S09-A_p1_Ccl2 | S09-A 16h n=3 Log10 (cols A-V; Ccl2) | PBS |  | 3 | -0.000 ± 0.300 | 1.0× | S09!B5:D5 |
| S09-A_p1_Ccl2 | S09-A 16h n=3 Log10 (cols A-V; Ccl2) | CMP-204 |  | 3 | 0.737 ± 0.179 | 5.5× | S09!E5:G5 |
| S09-A_p1_Ccl2 | S09-A 16h n=3 Log10 (cols A-V; Ccl2) | PSLN-212 |  | 3 | 0.882 ± 0.199 | 7.6× | S09!H5:J5 |
| S09-A_p1_Ccl2 | S09-A 16h n=3 Log10 (cols A-V; Ccl2) | PSLN-R848 |  | 3 | 0.398 ± 0.200 | 2.5× | S09!K5:M5 |
| S09-A_p1_Ccl2 | S09-A 16h n=3 Log10 (cols A-V; Ccl2) | PSLN-212/R848 |  | 3 | 2.354 ± 0.196 | 226.0× | S09!N5:P5 |
| S09-A_p1_Ccl2 | S09-A 16h n=3 Log10 (cols A-V; Ccl2) | PSLN-344 |  | 3 | 2.771 ± 0.325 | 590.1× | S09!Q5:S5 |
| S09-A_p1_Ccl2 | S09-A 16h n=3 Log10 (cols A-V; Ccl2) | PSLN-212(y) |  | 3 | 3.143 ± 0.297 | 1390.5× | S09!T5:V5 |
| S09-A_p2_Ccl2 | S09-A 16h n=3 Log10 (cols X-AS; Ccl2) [second panel, same printed label] | PBS |  | 3 | 0.000 ± 0.213 | 1.0× | S09!Y5:AA5 |
| S09-A_p2_Ccl2 | S09-A 16h n=3 Log10 (cols X-AS; Ccl2) [second panel, same printed label] | CMP-204 |  | 3 | 0.758 ± 0.150 | 5.7× | S09!AB5:AD5 |
| S09-A_p2_Ccl2 | S09-A 16h n=3 Log10 (cols X-AS; Ccl2) [second panel, same printed label] | PSLN-212 |  | 3 | 0.718 ± 0.053 | 5.2× | S09!AE5:AG5 |
| S09-A_p2_Ccl2 | S09-A 16h n=3 Log10 (cols X-AS; Ccl2) [second panel, same printed label] | PSLN-R848 |  | 3 | 1.008 ± 0.092 | 10.2× | S09!AH5:AJ5 |
| S09-A_p2_Ccl2 | S09-A 16h n=3 Log10 (cols X-AS; Ccl2) [second panel, same printed label] | PSLN-212/R848 |  | 3 | 1.767 ± 0.119 | 58.4× | S09!AK5:AM5 |
| S09-A_p2_Ccl2 | S09-A 16h n=3 Log10 (cols X-AS; Ccl2) [second panel, same printed label] | PSLN-344 |  | 3 | 1.438 ± 0.160 | 27.4× | S09!AN5:AP5 |
| S09-A_p2_Ccl2 | S09-A 16h n=3 Log10 (cols X-AS; Ccl2) [second panel, same printed label] | PSLN-212(y) |  | 3 | 2.007 ± 0.146 | 101.6× | S09!AQ5:AS5 |
| S09-A_p1_Ccl3 | S09-A 16h n=3 Log10 (cols A-V; Ccl3) | PBS |  | 3 | 0.000 ± 0.456 | 1.0× | S09!B6:D6 |
| S09-A_p1_Ccl3 | S09-A 16h n=3 Log10 (cols A-V; Ccl3) | CMP-204 |  | 3 | 0.087 ± 0.178 | 1.2× | S09!E6:G6 |
| S09-A_p1_Ccl3 | S09-A 16h n=3 Log10 (cols A-V; Ccl3) | PSLN-212 |  | 3 | 0.048 ± 0.197 | 1.1× | S09!H6:J6 |
| S09-A_p1_Ccl3 | S09-A 16h n=3 Log10 (cols A-V; Ccl3) | PSLN-R848 |  | 3 | 0.626 ± 0.160 | 4.2× | S09!K6:M6 |
| S09-A_p1_Ccl3 | S09-A 16h n=3 Log10 (cols A-V; Ccl3) | PSLN-212/R848 |  | 3 | 0.580 ± 0.206 | 3.8× | S09!N6:P6 |
| S09-A_p1_Ccl3 | S09-A 16h n=3 Log10 (cols A-V; Ccl3) | PSLN-344 |  | 3 | 1.475 ± 0.178 | 29.8× | S09!Q6:S6 |
| S09-A_p1_Ccl3 | S09-A 16h n=3 Log10 (cols A-V; Ccl3) | PSLN-212(y) |  | 3 | 1.758 ± 0.192 | 57.3× | S09!T6:V6 |
| S09-A_p2_Ccl3 | S09-A 16h n=3 Log10 (cols X-AS; Ccl3) [second panel, same printed label] | PBS |  | 3 | -0.000 ± 0.165 | 1.0× | S09!Y6:AA6 |
| S09-A_p2_Ccl3 | S09-A 16h n=3 Log10 (cols X-AS; Ccl3) [second panel, same printed label] | CMP-204 |  | 3 | 0.129 ± 0.086 | 1.3× | S09!AB6:AD6 |
| S09-A_p2_Ccl3 | S09-A 16h n=3 Log10 (cols X-AS; Ccl3) [second panel, same printed label] | PSLN-212 |  | 3 | 0.675 ± 0.153 | 4.7× | S09!AE6:AG6 |
| S09-A_p2_Ccl3 | S09-A 16h n=3 Log10 (cols X-AS; Ccl3) [second panel, same printed label] | PSLN-R848 |  | 3 | -0.173 ± 0.063 | 0.7× | S09!AH6:AJ6 |
| S09-A_p2_Ccl3 | S09-A 16h n=3 Log10 (cols X-AS; Ccl3) [second panel, same printed label] | PSLN-212/R848 |  | 3 | 1.134 ± 0.176 | 13.6× | S09!AK6:AM6 |
| S09-A_p2_Ccl3 | S09-A 16h n=3 Log10 (cols X-AS; Ccl3) [second panel, same printed label] | PSLN-344 |  | 3 | 0.965 ± 0.145 | 9.2× | S09!AN6:AP6 |
| S09-A_p2_Ccl3 | S09-A 16h n=3 Log10 (cols X-AS; Ccl3) [second panel, same printed label] | PSLN-212(y) |  | 3 | 1.618 ± 0.189 | 41.5× | S09!AQ6:AS6 |
| S09-A_p1_Ccl5 | S09-A 16h n=3 Log10 (cols A-V; Ccl5) | PBS |  | 3 | -0.000 ± 0.135 | 1.0× | S09!B7:D7 |
| S09-A_p1_Ccl5 | S09-A 16h n=3 Log10 (cols A-V; Ccl5) | CMP-204 |  | 3 | 0.194 ± 0.067 | 1.6× | S09!E7:G7 |
| S09-A_p1_Ccl5 | S09-A 16h n=3 Log10 (cols A-V; Ccl5) | PSLN-212 |  | 3 | 0.418 ± 0.052 | 2.6× | S09!H7:J7 |
| S09-A_p1_Ccl5 | S09-A 16h n=3 Log10 (cols A-V; Ccl5) | PSLN-R848 |  | 3 | -0.121 ± 0.222 | 0.8× | S09!K7:M7 |
| S09-A_p1_Ccl5 | S09-A 16h n=3 Log10 (cols A-V; Ccl5) | PSLN-212/R848 |  | 3 | 0.913 ± 0.139 | 8.2× | S09!N7:P7 |
| S09-A_p1_Ccl5 | S09-A 16h n=3 Log10 (cols A-V; Ccl5) | PSLN-344 |  | 3 | 1.297 ± 0.262 | 19.8× | S09!Q7:S7 |
| S09-A_p1_Ccl5 | S09-A 16h n=3 Log10 (cols A-V; Ccl5) | PSLN-212(y) |  | 3 | 1.793 ± 0.228 | 62.1× | S09!T7:V7 |
| S09-A_p2_Ccl5 | S09-A 16h n=3 Log10 (cols X-AS; Ccl5) [second panel, same printed label] | PBS |  | 3 | 0.000 ± 0.100 | 1.0× | S09!Y7:AA7 |
| S09-A_p2_Ccl5 | S09-A 16h n=3 Log10 (cols X-AS; Ccl5) [second panel, same printed label] | CMP-204 |  | 3 | 0.056 ± 0.090 | 1.1× | S09!AB7:AD7 |
| S09-A_p2_Ccl5 | S09-A 16h n=3 Log10 (cols X-AS; Ccl5) [second panel, same printed label] | PSLN-212 |  | 3 | 0.082 ± 0.132 | 1.2× | S09!AE7:AG7 |
| S09-A_p2_Ccl5 | S09-A 16h n=3 Log10 (cols X-AS; Ccl5) [second panel, same printed label] | PSLN-R848 |  | 3 | 0.035 ± 0.162 | 1.1× | S09!AH7:AJ7 |
| S09-A_p2_Ccl5 | S09-A 16h n=3 Log10 (cols X-AS; Ccl5) [second panel, same printed label] | PSLN-212/R848 |  | 3 | 1.738 ± 0.277 | 54.7× | S09!AK7:AM7 |
| S09-A_p2_Ccl5 | S09-A 16h n=3 Log10 (cols X-AS; Ccl5) [second panel, same printed label] | PSLN-344 |  | 3 | 0.303 ± 0.076 | 2.0× | S09!AN7:AP7 |
| S09-A_p2_Ccl5 | S09-A 16h n=3 Log10 (cols X-AS; Ccl5) [second panel, same printed label] | PSLN-212(y) |  | 3 | -0.263 ± 0.303 | 0.5× | S09!AQ7:AS7 |
| S09-A_p1_Tnf | S09-A 16h n=3 Log10 (cols A-V; Tnf) | PBS |  | 3 | 0.000 ± 0.267 | 1.0× | S09!B8:D8 |
| S09-A_p1_Tnf | S09-A 16h n=3 Log10 (cols A-V; Tnf) | CMP-204 |  | 3 | 0.848 ± 0.091 | 7.0× | S09!E8:G8 |
| S09-A_p1_Tnf | S09-A 16h n=3 Log10 (cols A-V; Tnf) | PSLN-212 |  | 3 | 1.196 ± 0.261 | 15.7× | S09!H8:J8 |
| S09-A_p1_Tnf | S09-A 16h n=3 Log10 (cols A-V; Tnf) | PSLN-R848 |  | 3 | 2.115 ± 0.174 | 130.3× | S09!K8:M8 |
| S09-A_p1_Tnf | S09-A 16h n=3 Log10 (cols A-V; Tnf) | PSLN-212/R848 |  | 3 | 2.306 ± 0.113 | 202.3× | S09!N8:P8 |
| S09-A_p1_Tnf | S09-A 16h n=3 Log10 (cols A-V; Tnf) | PSLN-344 |  | 3 | 1.607 ± 0.044 | 40.5× | S09!Q8:S8 |
| S09-A_p1_Tnf | S09-A 16h n=3 Log10 (cols A-V; Tnf) | PSLN-212(y) |  | 3 | 1.142 ± 0.107 | 13.9× | S09!T8:V8 |
| S09-A_p2_Tnf | S09-A 16h n=3 Log10 (cols X-AS; Tnf) [second panel, same printed label] | PBS |  | 3 | -0.000 ± 0.192 | 1.0× | S09!Y8:AA8 |
| S09-A_p2_Tnf | S09-A 16h n=3 Log10 (cols X-AS; Tnf) [second panel, same printed label] | CMP-204 |  | 3 | 0.392 ± 0.069 | 2.5× | S09!AB8:AD8 |
| S09-A_p2_Tnf | S09-A 16h n=3 Log10 (cols X-AS; Tnf) [second panel, same printed label] | PSLN-212 |  | 3 | 0.718 ± 0.064 | 5.2× | S09!AE8:AG8 |
| S09-A_p2_Tnf | S09-A 16h n=3 Log10 (cols X-AS; Tnf) [second panel, same printed label] | PSLN-R848 |  | 3 | 1.453 ± 0.101 | 28.4× | S09!AH8:AJ8 |
| S09-A_p2_Tnf | S09-A 16h n=3 Log10 (cols X-AS; Tnf) [second panel, same printed label] | PSLN-212/R848 |  | 3 | 1.701 ± 0.106 | 50.2× | S09!AK8:AM8 |
| S09-A_p2_Tnf | S09-A 16h n=3 Log10 (cols X-AS; Tnf) [second panel, same printed label] | PSLN-344 |  | 3 | 0.926 ± 0.103 | 8.4× | S09!AN8:AP8 |
| S09-A_p2_Tnf | S09-A 16h n=3 Log10 (cols X-AS; Tnf) [second panel, same printed label] | PSLN-212(y) |  | 3 | -0.323 ± 0.264 | 0.5× | S09!AQ8:AS8 |
| S09-A_p1_Il10 | S09-A 16h n=3 Log10 (cols A-V; Il10) | PBS |  | 3 | 0.000 ± 0.204 | 1.0× | S09!B9:D9 |
| S09-A_p1_Il10 | S09-A 16h n=3 Log10 (cols A-V; Il10) | CMP-204 |  | 3 | 0.523 ± 0.094 | 3.3× | S09!E9:G9 |
| S09-A_p1_Il10 | S09-A 16h n=3 Log10 (cols A-V; Il10) | PSLN-212 |  | 3 | 0.569 ± 0.249 | 3.7× | S09!H9:J9 |
| S09-A_p1_Il10 | S09-A 16h n=3 Log10 (cols A-V; Il10) | PSLN-R848 |  | 3 | 1.457 ± 0.101 | 28.6× | S09!K9:M9 |
| S09-A_p1_Il10 | S09-A 16h n=3 Log10 (cols A-V; Il10) | PSLN-212/R848 |  | 3 | 2.254 ± 0.044 | 179.4× | S09!N9:P9 |
| S09-A_p1_Il10 | S09-A 16h n=3 Log10 (cols A-V; Il10) | PSLN-344 |  | 3 | 0.864 ± 0.211 | 7.3× | S09!Q9:S9 |
| S09-A_p1_Il10 | S09-A 16h n=3 Log10 (cols A-V; Il10) | PSLN-212(y) |  | 3 | 0.264 ± 0.117 | 1.8× | S09!T9:V9 |
| S09-A_p2_Il10 | S09-A 16h n=3 Log10 (cols X-AS; Il10) [second panel, same printed label] | PBS |  | 3 | -0.000 ± 0.306 | 1.0× | S09!Y9:AA9 |
| S09-A_p2_Il10 | S09-A 16h n=3 Log10 (cols X-AS; Il10) [second panel, same printed label] | CMP-204 |  | 3 | 0.545 ± 0.385 | 3.5× | S09!AB9:AD9 |
| S09-A_p2_Il10 | S09-A 16h n=3 Log10 (cols X-AS; Il10) [second panel, same printed label] | PSLN-212 |  | 3 | 0.621 ± 0.144 | 4.2× | S09!AE9:AG9 |
| S09-A_p2_Il10 | S09-A 16h n=3 Log10 (cols X-AS; Il10) [second panel, same printed label] | PSLN-R848 |  | 3 | 0.625 ± 0.316 | 4.2× | S09!AH9:AJ9 |
| S09-A_p2_Il10 | S09-A 16h n=3 Log10 (cols X-AS; Il10) [second panel, same printed label] | PSLN-212/R848 |  | 3 | 1.654 ± 0.099 | 45.0× | S09!AK9:AM9 |
| S09-A_p2_Il10 | S09-A 16h n=3 Log10 (cols X-AS; Il10) [second panel, same printed label] | PSLN-344 |  | 3 | 0.619 ± 0.259 | 4.2× | S09!AN9:AP9 |
| S09-A_p2_Il10 | S09-A 16h n=3 Log10 (cols X-AS; Il10) [second panel, same printed label] | PSLN-212(y) |  | 3 | -0.944 ± 0.201 | 0.1× | S09!AQ9:AS9 |
| S10-A_Ifnb1 | S10-A n=5 Ifnb1 | PBS |  | 5 | 1.000 ± 0.228 |  | S10!A3:A7 |
| S10-A_Ifnb1 | S10-A n=5 Ifnb1 | Sham |  | 5 | 1.166 ± 0.336 |  | S10!B3:B7 |
| S10-A_Ifnb1 | S10-A n=5 Ifnb1 | PSLN-344 |  | 5 | 1.322 ± 0.410 |  | S10!C3:C7 |
| S10-A_Ifnb1 | S10-A n=5 Ifnb1 | CT |  | 5 | 5.500 ± 1.186 |  | S10!D3:D7 |
| S10-A_Tnf | S10-A n=5 Tnf | PBS |  | 5 | 1.000 ± 0.219 |  | S10!F3:F7 |
| S10-A_Tnf | S10-A n=5 Tnf | Sham |  | 5 | 1.322 ± 0.394 |  | S10!G3:G7 |
| S10-A_Tnf | S10-A n=5 Tnf | PSLN-344 |  | 5 | 1.594 ± 0.486 |  | S10!H3:H7 |
| S10-A_Tnf | S10-A n=5 Tnf | CT |  | 5 | 3.496 ± 1.220 |  | S10!I3:I7 |
| S10-A_Isg15 | S10-A n=5 Isg15 | PBS |  | 5 | 1.000 ± 0.335 |  | S10!K3:K7 |
| S10-A_Isg15 | S10-A n=5 Isg15 | Sham |  | 5 | 1.042 ± 0.174 |  | S10!L3:L7 |
| S10-A_Isg15 | S10-A n=5 Isg15 | PSLN-344 |  | 5 | 1.130 ± 0.207 |  | S10!M3:M7 |
| S10-A_Isg15 | S10-A n=5 Isg15 | CT |  | 5 | 2.676 ± 0.741 |  | S10!N3:N7 |
| S11-A | S11-A n=5 | Vaccine | 0 | 5 | 20.42 ± 3.42 |  | S11!B3:F3 |
| S11-A | S11-A n=5 | PSLN-212 | 0 | 5 | 20.32 ± 2.36 |  | S11!G3:K3 |
| S11-A | S11-A n=5 | PSLN-344 | 0 | 5 | 21.18 ± 2.52 |  | S11!L3:P3 |
| S11-A | S11-A n=5 | PSLN-212(Y) | 0 | 5 | 36.64 ± 2.41 |  | S11!Q3:U3 |
| S11-A | S11-A n=5 | Vaccine | 2 | 5 | 22.64 ± 3.52 |  | S11!B4:F4 |
| S11-A | S11-A n=5 | PSLN-212 | 2 | 5 | 28.24 ± 2.54 |  | S11!G4:K4 |
| S11-A | S11-A n=5 | PSLN-344 | 2 | 5 | 29.62 ± 6.00 |  | S11!L4:P4 |
| S11-A | S11-A n=5 | PSLN-212(Y) | 2 | 5 | 44.72 ± 3.30 |  | S11!Q4:U4 |
| S11-A | S11-A n=5 | Vaccine | 4 | 5 | 20.74 ± 2.79 |  | S11!B5:F5 |
| S11-A | S11-A n=5 | PSLN-212 | 4 | 5 | 30.90 ± 6.05 |  | S11!G5:K5 |
| S11-A | S11-A n=5 | PSLN-344 | 4 | 5 | 32.26 ± 5.54 |  | S11!L5:P5 |
| S11-A | S11-A n=5 | PSLN-212(Y) | 4 | 5 | 48.50 ± 4.45 |  | S11!Q5:U5 |
| S11-A | S11-A n=5 | Vaccine | 6 | 5 | 21.54 ± 4.27 |  | S11!B6:F6 |
| S11-A | S11-A n=5 | PSLN-212 | 6 | 5 | 27.50 ± 2.97 |  | S11!G6:K6 |
| S11-A | S11-A n=5 | PSLN-344 | 6 | 5 | 31.00 ± 3.18 |  | S11!L6:P6 |
| S11-A | S11-A n=5 | PSLN-212(Y) | 6 | 5 | 46.88 ± 2.83 |  | S11!Q6:U6 |
| S11-A | S11-A n=5 | Vaccine | 8 | 5 | 22.44 ± 2.06 |  | S11!B7:F7 |
| S11-A | S11-A n=5 | PSLN-212 | 8 | 5 | 23.94 ± 1.44 |  | S11!G7:K7 |
| S11-A | S11-A n=5 | PSLN-344 | 8 | 5 | 28.78 ± 5.75 |  | S11!L7:P7 |
| S11-A | S11-A n=5 | PSLN-212(Y) | 8 | 5 | 40.36 ± 2.62 |  | S11!Q7:U7 |
| S11-B | S11-B n=5 | Vaccine | 0 | 5 | 20.38 ± 3.18 |  | S11!B10:F10 |
| S11-B | S11-B n=5 | PSLN-212 | 0 | 5 | 20.02 ± 1.75 |  | S11!G10:K10 |
| S11-B | S11-B n=5 | PSLN-344 | 0 | 5 | 21.04 ± 1.66 |  | S11!L10:P10 |
| S11-B | S11-B n=5 | PSLN-212(Y) | 0 | 5 | 36.76 ± 4.32 |  | S11!Q10:U10 |
| S11-B | S11-B n=5 | Vaccine | 2 | 5 | 23.00 ± 4.06 |  | S11!B11:F11 |
| S11-B | S11-B n=5 | PSLN-212 | 2 | 5 | 28.12 ± 3.21 |  | S11!G11:K11 |
| S11-B | S11-B n=5 | PSLN-344 | 2 | 5 | 27.14 ± 4.32 |  | S11!L11:P11 |
| S11-B | S11-B n=5 | PSLN-212(Y) | 2 | 5 | 43.14 ± 5.84 |  | S11!Q11:U11 |
| S11-B | S11-B n=5 | Vaccine | 4 | 5 | 20.82 ± 3.45 |  | S11!B12:F12 |
| S11-B | S11-B n=5 | PSLN-212 | 4 | 5 | 31.32 ± 3.50 |  | S11!G12:K12 |
| S11-B | S11-B n=5 | PSLN-344 | 4 | 5 | 31.80 ± 6.23 |  | S11!L12:P12 |
| S11-B | S11-B n=5 | PSLN-212(Y) | 4 | 5 | 48.44 ± 3.89 |  | S11!Q12:U12 |
| S11-B | S11-B n=5 | Vaccine | 6 | 5 | 20.82 ± 2.04 |  | S11!B13:F13 |
| S11-B | S11-B n=5 | PSLN-212 | 6 | 5 | 27.18 ± 1.59 |  | S11!G13:K13 |
| S11-B | S11-B n=5 | PSLN-344 | 6 | 5 | 30.96 ± 4.37 |  | S11!L13:P13 |
| S11-B | S11-B n=5 | PSLN-212(Y) | 6 | 5 | 46.46 ± 3.57 |  | S11!Q13:U13 |
| S11-B | S11-B n=5 | Vaccine | 8 | 5 | 22.50 ± 2.54 |  | S11!B14:F14 |
| S11-B | S11-B n=5 | PSLN-212 | 8 | 5 | 24.42 ± 3.34 |  | S11!G14:K14 |
| S11-B | S11-B n=5 | PSLN-344 | 8 | 5 | 28.84 ± 4.54 |  | S11!L14:P14 |
| S11-B | S11-B n=5 | PSLN-212(Y) | 8 | 5 | 40.78 ± 3.43 |  | S11!Q14:U14 |
| S11-C | S11-C n=5 | CBX+ |  | 5 | 3.084 ± 1.286 |  | S11!A17:A21 |
| S11-C | S11-C n=5 | CBX- |  | 5 | 7.282 ± 1.858 |  | S11!B17:B21 |
| S11-D | S11-D n=5 | Vaccine | 0 | 5 | 27.80 ± 7.99 |  | S11!B24:F24 |
| S11-D | S11-D n=5 | PSLN-212 | 0 | 5 | 26.34 ± 4.86 |  | S11!G24:K24 |
| S11-D | S11-D n=5 | PSLN-344 | 0 | 5 | 25.64 ± 3.80 |  | S11!L24:P24 |
| S11-D | S11-D n=5 | PSLN-212(Y) | 0 | 5 | 17.40 ± 2.01 |  | S11!Q24:U24 |
| S11-D | S11-D n=5 | Vaccine | 2 | 5 | 28.46 ± 3.33 |  | S11!B25:F25 |
| S11-D | S11-D n=5 | PSLN-212 | 2 | 5 | 28.82 ± 3.56 |  | S11!G25:K25 |
| S11-D | S11-D n=5 | PSLN-344 | 2 | 5 | 34.02 ± 3.69 |  | S11!L25:P25 |
| S11-D | S11-D n=5 | PSLN-212(Y) | 2 | 5 | 23.14 ± 3.99 |  | S11!Q25:U25 |
| S11-D | S11-D n=5 | Vaccine | 4 | 5 | 27.48 ± 4.83 |  | S11!B26:F26 |
| S11-D | S11-D n=5 | PSLN-212 | 4 | 5 | 24.70 ± 4.58 |  | S11!G26:K26 |
| S11-D | S11-D n=5 | PSLN-344 | 4 | 5 | 31.08 ± 4.91 |  | S11!L26:P26 |
| S11-D | S11-D n=5 | PSLN-212(Y) | 4 | 5 | 18.10 ± 2.62 |  | S11!Q26:U26 |
| S11-D | S11-D n=5 | Vaccine | 6 | 5 | 24.32 ± 3.72 |  | S11!B27:F27 |
| S11-D | S11-D n=5 | PSLN-212 | 6 | 5 | 21.76 ± 3.88 |  | S11!G27:K27 |
| S11-D | S11-D n=5 | PSLN-344 | 6 | 5 | 23.88 ± 3.85 |  | S11!L27:P27 |
| S11-D | S11-D n=5 | PSLN-212(Y) | 6 | 5 | 17.60 ± 1.67 |  | S11!Q27:U27 |
| S11-D | S11-D n=5 | Vaccine | 8 | 5 | 25.92 ± 2.96 |  | S11!B28:F28 |
| S11-D | S11-D n=5 | PSLN-212 | 8 | 5 | 25.46 ± 1.28 |  | S11!G28:K28 |
| S11-D | S11-D n=5 | PSLN-344 | 8 | 5 | 24.06 ± 2.50 |  | S11!L28:P28 |
| S11-D | S11-D n=5 | PSLN-212(Y) | 8 | 5 | 18.14 ± 2.91 |  | S11!Q28:U28 |
| S11-E | S11-E n=5 | Sham |  | 5 | 85.18 ± 7.81 |  | S11!A31:A35 |
| S11-E | S11-E n=5 | PSLN-212 |  | 5 | 71.46 ± 8.26 |  | S11!B31:B35 |
| S11-E | S11-E n=5 | PSLN-344 |  | 5 | 48.92 ± 8.12 |  | S11!C31:C35 |
| S11-E | S11-E n=5 | PSLN-212(Y) |  | 5 | 35.54 ± 7.12 |  | S11!D31:D35 |
| S12-A | S12-A n=3 | WT to WT |  | 3 | 21.27 ± 4.20 |  | S12!A3:A5 |
| S12-A | S12-A n=3 | IFNAR-/- to WT |  | 3 | 15.37 ± 2.48 |  | S12!B3:B5 |
| S13-A | S13-A n=5 | PSLN-212 |  | 5 | 88.40 ± 32.15 | 83 [51–135] | S13!A3:A7 |
| S13-A | S13-A n=5 | PSLN-344 |  | 5 | 1830 ± 995 | 1,642 [869–3,101] | S13!B3:B7 |
| S13-A | S13-A n=5 | PSLN-212(Y) |  | 5 | 5120 ± 2489 | 4,642 [2,498–8,625] | S13!C3:C7 |
| S13-B | S13-B n=5 | PSLN-212 |  | 5 | 156 ± 30 | 153 [118–198] | S13!E3:E7 |
| S13-B | S13-B n=5 | PSLN-344 |  | 5 | 903 ± 191 | 887 [681–1,155] | S13!F3:F7 |
| S13-B | S13-B n=5 | PSLN-212(Y) |  | 5 | 1915 ± 536 | 1,855 [1,303–2,641] | S13!G3:G7 |
| S13-C | S13-C n=5 | PSLN-212 |  | 5 | 86.34 ± 34.25 | 80 [46–139] | S13!I3:I7 |
| S13-C | S13-C n=5 | PSLN-344 |  | 5 | 1446 ± 635 | 1,331 [749–2,365] | S13!J3:J7 |
| S13-C | S13-C n=5 | PSLN-212(Y) |  | 5 | 3943 ± 1435 | 3,701 [2,196–6,235] | S13!K3:K7 |
| S13-D | S13-D n=5 | PSLN-212 |  | 5 | 179 ± 52 | 173 [119–251] | S13!M3:M7 |
| S13-D | S13-D n=5 | PSLN-344 |  | 5 | 592 ± 140 | 579 [431–777] | S13!N3:N7 |
| S13-D | S13-D n=5 | PSLN-212(Y) |  | 5 | 1349 ± 298 | 1,326 [1,028–1,710] | S13!O3:O7 |
| S13-H | S13-H n=5 | Sham |  | 5 | 4.696 ± 2.583 |  | S13!A53:A57 |
| S13-H | S13-H n=5 | PSLN-212 |  | 5 | 11.22 ± 2.29 |  | S13!B53:B57 |
| S13-H | S13-H n=5 | PSLN-344 |  | 5 | 25.86 ± 5.89 |  | S13!C53:C57 |
| S13-H | S13-H n=5 | PSLN-212(Y) |  | 5 | 27.11 ± 4.22 |  | S13!D53:D57 |
| S13-I | S13-I n=5 | Sham |  | 5 | 118 ± 110 | 57 [8–418] | S13!F53:F57 |
| S13-I | S13-I n=5 | CMP-204 |  | 5 | 1022 ± 437 | 940 [518–1,703] | S13!G53:G57 |
| S13-I | S13-I n=5 | PSLN-212 |  | 5 | 4777 ± 2001 | 4,411 [2,486–7,828] | S13!H53:H57 |
| S13-I | S13-I n=5 | PSLN-344 |  | 5 | 18415 ± 10496 | 15,651 [6,767–36,194] | S13!I53:I57 |
| S13-I | S13-I n=5 | PSLN-212(Y) |  | 5 | 46749 ± 24512 | 40,739 [18,905–87,790] | S13!J53:J57 |
| S13-J | S13-J n=5 | Sham |  | 5 | 124 ± 94 | 101 [41–246] | S13!L53:L57 |
| S13-J | S13-J n=5 | CMP-204 |  | 5 | 516 ± 234 | 474 [265–847] | S13!M53:M57 |
| S13-J | S13-J n=5 | PSLN-212 |  | 5 | 1249 ± 735 | 1,086 [520–2,270] | S13!N53:N57 |
| S13-J | S13-J n=5 | PSLN-344 |  | 5 | 16431 ± 15288 | 12,435 [4,626–33,426] | S13!O53:O57 |
| S13-J | S13-J n=5 | PSLN-212(Y) |  | 5 | 45701 ± 15419 | 43,472 [27,756–68,086] | S13!P53:P57 |
| S14-A_H1N1 | S14-A H1N1 n=5 | Sham |  | 5 | 0.820 ± 0.567 |  | S14!A3:A7 |
| S14-A_H1N1 | S14-A H1N1 n=5 | PSLN-212 |  | 5 | 3.140 ± 1.774 |  | S14!B3:B7 |
| S14-A_H1N1 | S14-A H1N1 n=5 | PSLN-344 |  | 5 | 11.02 ± 2.57 |  | S14!C3:C7 |
| S14-A_H1N1 | S14-A H1N1 n=5 | PSLN-212(Y) |  | 5 | 13.70 ± 2.45 |  | S14!D3:D7 |
| S14-A_H3N2 | S14-A H3N2 n=5 | Sham |  | 5 | 1.040 ± 0.577 |  | S14!F3:F7 |
| S14-A_H3N2 | S14-A H3N2 n=5 | PSLN-212 |  | 5 | 3.580 ± 1.199 |  | S14!G3:G7 |
| S14-A_H3N2 | S14-A H3N2 n=5 | PSLN-344 |  | 5 | 9.860 ± 1.785 |  | S14!H3:H7 |
| S14-A_H3N2 | S14-A H3N2 n=5 | PSLN-212(Y) |  | 5 | 13.98 ± 2.51 |  | S14!I3:I7 |

### 3b. Two-way ANOVA (group × time or dose) for the time-course blocks, as named in the annotation

| Block | Term | F | d.f. (term, residual) | p |
|---|---|---|---|---|
| S01-D | group | 124.3 | 3, 80 | 5.0e-30 |
| S01-D | time / dose | 106.8 | 4, 80 | 2.9e-31 |
| S01-D | group × time | 17.0 | 12, 80 | 2.6e-17 |
| S01-E | group | 56.9 | 4, 100 | 6.1e-25 |
| S01-E | time / dose | 137.2 | 4, 100 | 1.1e-39 |
| S01-E | group × time | 10.3 | 16, 100 | 6.7e-15 |
| S02-F | group | 141.6 | 2, 36 | 8.7e-18 |
| S02-F | time / dose | 13.2 | 2, 36 | 5.0e-05 |
| S02-F | group × time | 11.2 | 4, 36 | 5.3e-06 |
| S05-A | group | 63.8 | 2, 9 | 4.8e-06 |
| S05-A | time / dose | 31.9 | 2, 9 | 8.2e-05 |
| S05-A | group × time | 0.7 | 4, 9 | 6.0e-01 |
| S05-B | group | 14.7 | 2, 9 | 1.5e-03 |
| S05-B | time / dose | 19.7 | 2, 9 | 5.2e-04 |
| S05-B | group × time | 1.4 | 4, 9 | 3.0e-01 |
| S07-A | group | 59.1 | 1, 20 | 2.1e-07 |
| S07-A | time / dose | 14.4 | 4, 20 | 1.1e-05 |
| S07-A | group × time | 10.7 | 4, 20 | 8.6e-05 |
| S08-A | group | 110.7 | 3, 40 | 2.1e-19 |
| S08-A | time / dose | 133.4 | 4, 40 | 1.5e-22 |
| S08-A | group × time | 20.7 | 12, 40 | 1.8e-13 |
| S11-A | group | 158.7 | 3, 80 | 1.4e-33 |
| S11-A | time / dose | 15.7 | 4, 80 | 1.5e-09 |
| S11-A | group × time | 1.9 | 12, 80 | 4.5e-02 |
| S11-B | group | 155.8 | 3, 80 | 2.6e-33 |
| S11-B | time / dose | 14.8 | 4, 80 | 4.3e-09 |
| S11-B | group × time | 2.1 | 12, 80 | 2.8e-02 |
| S11-D | group | 26.1 | 3, 80 | 6.9e-12 |
| S11-D | time / dose | 8.3 | 4, 80 | 1.2e-05 |
| S11-D | group × time | 1.1 | 12, 80 | 3.3e-01 |

## 4. Derived quantities

### 4a. Restoration index (aged PSLN-344 relative to aged PSLN-212 = 0 and young PSLN-212 = 1)

| Readout | Block | n (212 / 344 / young) | Aged PSLN-212 | Aged PSLN-344 | Young PSLN-212 | 344 ÷ 212 | 344 as % of young | Restoration index (95% CI) | Welch p, 344 vs 212 | Welch p, 344 vs young |
|---|---|---|---|---|---|---|---|---|---|---|
| Lung Ifnb1 mRNA, 16 h (fold) | S01-A_16h | 5/5/5 | 16.64 | 37.11 | 37.60 | 2.23× | 99% | 0.98 (0.79–1.21) | 0.00019 | 0.86 |
| HAI anti-Aichi, d14 (log10 GMT) | S03-G | 5/5/5 | 1.54 (log10) | 2.51 (log10) | 2.57 (log10) | 9.19× | 87% | 0.94 (0.75–1.13) | 0.00021 | 0.61 |
| IgG+ of MLN B220+ cells (%) | S13-H | 5/5/5 | 11.22 | 25.86 | 27.11 | 2.31× | 95% | 0.92 (0.61–1.32) | 0.0032 | 0.71 |
| Lung Ki-67+ CD8 T, d3 (%) | S05-D | 5/5/5 | 3.48 | 9.38 | 9.94 | 2.70× | 94% | 0.91 (0.60–1.52) | 0.00047 | 0.73 |
| Lung monocytes, d4 (%) | S01-D@4 | 5/5/5 | 16.72 | 30.56 | 32.22 | 1.83× | 95% | 0.89 (0.62–1.24) | 0.0016 | 0.56 |
| Lung NP-tetramer+ CD8 T, d7 (%) [n=2] | S05-A@7 | 2/2/2 | 6.90 | 14.25 | 15.15 | 2.06× | 94% | 0.89 (0.62–1.25) | 0.092 | 0.69 |
| HAI anti-CA09, d14 (log10 GMT) | S03-C | 5/5/5 | 1.66 (log10) | 2.57 (log10) | 2.69 (log10) | 8.00× | 76% | 0.88 (0.67–1.12) | 0.00037 | 0.4 |
| Serum IgG anti-CA09, d14 (log10 GMT) | S03-A | 5/5/5 | 2.59 (log10) | 3.86 (log10) | 4.08 (log10) | 18.58× | 61% | 0.86 (0.72–0.99) | 1.3e-05 | 0.11 |
| Lung migratory CCR7+ CD11b+ DC, 72 h (%) | S02-A | 5/5/5 | 7.28 | 30.68 | 35.00 | 4.21× | 88% | 0.84 (0.60–1.10) | 0.0019 | 0.33 |
| MLN Tfr (Foxp3+ of CXCR5+), d7 (%) | S04-B_Tfr | 5/5/5 | 26.66 | 10.80 | 7.12 | 0.41× | 152% | 0.81 (0.67–0.98) | 0.0047 | 0.092 |
| Lung CD11b+ DC, d4 (%) | S01-E@4 | 5/5/5 | 8.28 | 18.88 | 21.40 | 2.28× | 88% | 0.81 (0.33–1.38) | 0.049 | 0.55 |
| Neutralising titre anti-Aichi, d14 (log10 GMT) | S03-H | 5/5/5 | 2.44 (log10) | 3.40 (log10) | 3.64 (log10) | 9.19× | 57% | 0.80 (0.58–1.06) | 0.00039 | 0.18 |
| Neutralising titre anti-CA09, d14 (log10 GMT) | S03-D | 5/5/5 | 2.62 (log10) | 3.58 (log10) | 3.83 (log10) | 9.19× | 57% | 0.80 (0.53–1.06) | 0.0019 | 0.27 |
| Lung Treg, d7 (%) [n=3] | S04-D | 3/3/3 | 6.66 | 2.99 | 1.78 | 0.45× | 168% | 0.75 (0.64–0.88) | 0.00034 | 0.051 |
| Lung cDC2, 72 h (%) | S01-G | 5/5/5 | 75.30 | 59.46 | 54.08 | 0.79× | 110% | 0.75 (0.48–1.16) | 0.0041 | 0.26 |
| MLN IFN-g+ CD8 T, CA09 restim (%) | S14-A_H1N1 | 5/5/5 | 3.14 | 11.02 | 13.70 | 3.51× | 80% | 0.75 (0.53–1.01) | 0.00074 | 0.13 |
| Serum IgG anti-Aichi, d14 (log10 GMT) | S03-E | 5/5/5 | 2.63 (log10) | 3.76 (log10) | 4.14 (log10) | 13.40× | 41% | 0.75 (0.58–0.91) | 7e-05 | 0.039 |
| Serum IgG2a anti-CA09, d14 (log10 GMT) | S13-A | 5/5/5 | 1.92 (log10) | 3.22 (log10) | 3.67 (log10) | 19.68× | 35% | 0.74 (0.62–0.87) | 1.1e-05 | 0.012 |
| Serum IgG2a anti-Aichi, d14 (log10 GMT) | S13-C | 5/5/5 | 1.90 (log10) | 3.12 (log10) | 3.57 (log10) | 16.59× | 36% | 0.73 (0.62–0.85) | 9.9e-06 | 0.0065 |
| MLN ICOS-lo Tfh, d7 (%) | S04-A_ICOSlo | 5/5/5 | 2.70 | 5.74 | 6.91 | 2.12× | 83% | 0.72 (0.33–1.51) | 0.027 | 0.42 |
| Lung cDC1, 72 h (%) | S01-F | 5/5/5 | 22.80 | 37.52 | 43.42 | 1.65× | 86% | 0.71 (0.43–1.06) | 0.0058 | 0.17 |
| Serum IgG1 anti-CA09, d14 (log10 GMT) | S13-B | 5/5/5 | 2.19 (log10) | 2.95 (log10) | 3.27 (log10) | 5.79× | 48% | 0.70 (0.61–0.80) | 1e-06 | 0.002 |
| Ex vivo OT-I priming by MLN CD11b+ DC (% divided) | S02-E | 5/5/5 | 0.77 | 18.65 | 26.24 | 24.35× | 71% | 0.70 (0.55–0.87) | 0.0001 | 0.063 |
| MLN CD11b+CD103- DC, 72 h (%) | S02-B | 5/5/5 | 18.22 | 36.76 | 44.70 | 2.02× | 82% | 0.70 (0.39–1.07) | 0.0075 | 0.18 |
| MLN antigen(OVA-AF647)+ DC, 36 h (%) | S02-C | 5/5/5 | 1.77 | 7.09 | 9.39 | 4.01× | 76% | 0.70 (0.53–0.90) | 0.00069 | 0.037 |
| MLN GZMB+ CD8 T, d60 (%) | S05-H | 5/5/5 | 1.02 | 4.11 | 5.55 | 4.01× | 74% | 0.68 (0.44–0.98) | 0.0025 | 0.12 |
| Serum IgG anti-Aichi, d28 post-boost (log10 GMT) | S13-J | 5/5/5 | 3.04 (log10) | 4.09 (log10) | 4.64 (log10) | 11.45× | 29% | 0.66 (0.49–0.85) | 0.00076 | 0.021 |
| MLN ICOS-hi Tfh, d7 (%) | S04-A_ICOShi | 5/5/5 | 3.82 | 10.26 | 13.63 | 2.69× | 75% | 0.66 (0.42–0.95) | 0.0086 | 0.078 |
| MLN IFN-g+ CD8 T, rgH5N1 restim, d14 (%) | S05-F | 5/5/5 | 1.50 | 6.36 | 9.18 | 4.23× | 69% | 0.63 (0.52–0.75) | 0.00013 | 0.0016 |
| Lung CD206+ macrophages (%) | S11-E | 5/5/5 | 71.46 | 48.92 | 35.54 | 0.68× | 138% | 0.63 (0.43–0.86) | 0.0024 | 0.025 |
| MLN IFN-g+ CD8 T, Aichi restim (%) | S14-A_H3N2 | 5/5/5 | 3.58 | 9.86 | 13.98 | 2.75× | 71% | 0.60 (0.44–0.81) | 0.00033 | 0.019 |
| MLN IFN-g+ CD8 T, rgH5N1 restim, d60 (%) | S05-G | 5/5/5 | 3.04 | 9.86 | 14.36 | 3.24× | 69% | 0.60 (0.39–0.85) | 0.0032 | 0.038 |
| Serum IgG1 anti-Aichi, d14 (log10 GMT) | S13-D | 5/5/5 | 2.24 (log10) | 2.76 (log10) | 3.12 (log10) | 3.35× | 44% | 0.59 (0.48–0.70) | 0.00014 | 0.00039 |
| Lung NP-tetramer+ CD8 T, d3 (%) [n=2] | S05-A@3 | 2/2/2 | 2.09 | 6.68 | 9.85 | 3.20× | 68% | 0.59 (0.48–0.74) | 0.042 | 0.14 |
| Lung CD8 TRM, d25 (%) | S05-I | 5/5/5 | 1.00 | 3.96 | 6.04 | 3.96× | 66% | 0.59 (0.48–0.70) | 6.2e-05 | 0.00068 |
| Serum IgG anti-CA09, d28 post-boost (log10 GMT) | S13-I | 5/5/5 | 3.64 (log10) | 4.19 (log10) | 4.61 (log10) | 3.55× | 38% | 0.57 (0.29–0.88) | 0.01 | 0.048 |
| MLN GC B cells, d7 (%) | S03-K | 5/5/5 | 2.34 | 6.54 | 9.82 | 2.79× | 67% | 0.56 (0.37–0.90) | 0.0023 | 0.076 |
| Lung GZMB+ CD8 T, d3 (%) | S05-E | 5/5/5 | 2.99 | 5.69 | 9.61 | 1.90× | 59% | 0.41 (0.27–0.54) | 0.0011 | 0.00053 |
| MLN Tfr, d30 (%) | S04-C | 5/5/5 | 18.04 | 14.00 | 7.40 | 0.78× | 189% | 0.38 (0.01–0.64) | 0.11 | 0.0068 |
| CD86+ of MLN CD11b+ DC, d3 (%) | S02-D_CD86 | 5/5/5 | 8.13 | 14.54 | 37.94 | 1.79× | 38% | 0.22 (0.13–0.30) | 0.0032 | 0.00017 |
| CD40+ of MLN CD11b+ DC, d3 (%) | S02-D_CD40 | 5/5/5 | 5.56 | 11.20 | 38.72 | 2.02× | 29% | 0.17 (0.09–0.26) | 0.011 | 0.00042 |
| Lung Ifnb1 mRNA, 72 h (fold) | S01-A_72h | 5/5/5 | 3.43 | 4.43 | 1.59 | 1.29× | 278% | -0.54 (-1.45–0.15) | 0.26 | 0.016 |

Summary over 38 readouts (excluding the two n=2 tetramer rows, the 72-h Ifnb1 row, which measures resolution rather than response, and cDC2, which is the complement of cDC1): median 0.71, inter-quartile range 0.61–0.81, range 0.17 (CD40 on DCs) to 0.98 (Ifnb1 16 h). PSLN-344 differs from aged PSLN-212 at Welch p<0.05 in 37 of 38 (exception: Tfr at day 30) and remains below the young benchmark at p<0.05 in 17 of 38.

### 4b. IgG2a/IgG1 quotient recomputed from the subclass titres (S13-A÷S13-B; S13-C÷S13-D), per animal

| Antigen | Group | Quotients (animals 1–5) | Mean ± SD | Value printed under that header in S03-B / S03-F |
|---|---|---|---|---|
| CA09 H1N1 | PSLN-212 | 0.74, 0.80, 0.29, 0.48, 0.58 | 0.58 ± 0.20 | 2.97 ± 1.69 |
| CA09 H1N1 | PSLN-344 | 2.58, 1.72, 4.19, 0.85, 1.38 | 2.14 ± 1.31 | 0.58 ± 0.20 |
| CA09 H1N1 | PSLN-212(Y) | 4.44, 4.58, 1.18, 1.17, 3.49 | 2.97 ± 1.69 | 2.14 ± 1.31 |
| Aichi H3N2 | PSLN-212 | 0.89, 0.61, 0.49, 0.31, 0.26 | 0.51 ± 0.25 | 2.89 ± 0.80 |
| Aichi H3N2 | PSLN-344 | 5.46, 3.42, 2.26, 1.09, 1.40 | 2.73 ± 1.78 | 0.51 ± 0.25 |
| Aichi H3N2 | PSLN-212(Y) | 3.88, 3.06, 3.17, 2.63, 1.71 | 2.89 ± 0.80 | 2.73 ± 1.78 |

### 4c. HAI: animals at or above a threshold (day 14)

| Block | Group | Titres | ≥40 | ≥160 |
|---|---|---|---|---|
| S03-C | Sham | 10, 10, 10, 0, 0 | 0/5 | 0/5 |
| S03-C | CMP-204 | 40, 10, 20, 20, 40 | 2/5 | 0/5 |
| S03-C | PSLN-212 | 40, 80, 40, 40, 40 | 5/5 | 0/5 |
| S03-C | PSLN-344 | 320, 640, 160, 320, 640 | 5/5 | 5/5 |
| S03-C | PSLN-212(Y) | 640, 640, 640, 320, 320 | 5/5 | 5/5 |
| S03-G | Sham | 10, 10, 10, 20, 0 | 0/5 | 0/5 |
| S03-G | CMP-204 | 40, 40, 20, 20, 40 | 3/5 | 0/5 |
| S03-G | PSLN-212 | 40, 20, 20, 80, 40 | 3/5 | 0/5 |
| S03-G | PSLN-344 | 320, 640, 160, 320, 320 | 5/5 | 5/5 |
| S03-G | PSLN-212(Y) | 640, 320, 320, 320, 320 | 5/5 | 5/5 |

### 4d. Single dose (day 14) versus prime–boost (day 28, boost on day 14): serum IgG GMT (different animals)

| Antigen | Group | GMT day 14 | GMT day 28 after boost | Ratio |
|---|---|---|---|---|
| CA09 H1N1 | Sham | 56 | 57 | 1.0× |
| CA09 H1N1 | CMP-204 | 181 | 940 | 5.2× |
| CA09 H1N1 | PSLN-212 | 393 | 4,411 | 11.2× |
| CA09 H1N1 | PSLN-344 | 7,305 | 15,651 | 2.1× |
| CA09 H1N1 | PSLN-212(Y) | 11,959 | 40,739 | 3.4× |
| Aichi H3N2 | Sham | 52 | 101 | 1.9× |
| Aichi H3N2 | CMP-204 | 200 | 474 | 2.4× |
| Aichi H3N2 | PSLN-212 | 426 | 1,086 | 2.6× |
| Aichi H3N2 | PSLN-344 | 5,701 | 12,435 | 2.2× |
| Aichi H3N2 | PSLN-212(Y) | 13,855 | 43,472 | 3.1× |

### 4e. Sample-size calculations used for the proposed studies (exact power of a two-sided Fisher test, α = 0.05)

| Comparison (assumed survival) | n/arm for 80% power | n/arm for 90% power | Power at n=7 | Power at n=12 |
|---|---|---|---|---|
| PSLN-344 (0.85, pooled aged) vs PSLN-212 (0.14, pooled aged) | 8 | 11 | 0.67 | 0.95 |
| PSLN-344 (0.85) vs Mn-only / empty liposome control (assume 0.15) | 9 | 11 | 0.65 | 0.94 |
| PSLN-344 (0.85) vs licensed-type comparator assumed to protect 50% | 32 | 41 | 0.10 | 0.30 |
| PSLN-344 (0.85) vs licensed-type comparator assumed to protect 60% | 56 | 72 | 0.04 | 0.15 |
| d60 durability: PSLN-344 aged (0.67 observed) vs boosted regimen hoped-for 0.95 | 34 | 42 | 0.03 | 0.22 |
| CD8 depletion: isotype (0.85) vs anti-CD8 (assume 0.30 if CD8 T cells are necessary) | 16 | 18 | 0.35 | 0.72 |
| CD8 depletion, partial dependence: 0.85 vs 0.50 | 32 | 41 | 0.10 | 0.30 |
| PSLN-212 + rGM-CSF (assume 0.70 if GM-CSF is sufficient) vs PSLN-212 (0.14) | 13 | 18 | 0.37 | 0.74 |

## 5. Body-weight blocks

Supportive only (see QC items Q5 and Q6). "Lost" = blank after last weigh-in or carried-forward last weight. Nadir = lowest genuine weight, % of day 0.

| Block | Paired survival block | Group | n | Weighed to end | Lost | Mean nadir, all (SD) | Mean nadir, animals weighed to end (SD) | Lowest animal | Cells |
|---|---|---|---|---|---|---|---|---|---|
| S08-D | — | PSLN-212(Y) | 5 | 5 | 0 | 97.6 (1.3) | 97.6 (1.3) | 96.0 | S08!B21:F26 |
| S08-D | — | CMP-204 | 5 | 5 | 0 | 95.9 (2.0) | 95.9 (2.0) | 93.2 | S08!G21:K26 |
| S08-D | — | PSLN-212 | 5 | 5 | 0 | 97.0 (1.7) | 97.0 (1.7) | 94.5 | S08!L21:P26 |
| S08-D | — | PSLN-344 | 5 | 5 | 0 | 96.4 (1.5) | 96.4 (1.5) | 94.2 | S08!Q21:U26 |
| S08-D | — | PSLN-212/R848 | 5 | 4 | 1 | 90.0 (5.0) | 90.4 (5.7) | 84.7 | S08!V21:Z26 |
| S08-D | — | Vaccine | 5 | 5 | 0 | 98.2 (1.1) | 98.2 (1.1) | 97.1 | S08!AA21:AE26 |
| S09-C | S09-B | PSLN-212Y | 8 | 8 | 0 | 88.9 (1.5) | 88.9 (1.5) | 87.0 | S09!G12:N19 |
| S09-C | S09-B | Sham | 8 | 0 | 8 | 79.5 (1.4) | — | 77.9 | S09!O12:V19 |
| S09-C | S09-B | PSLN-344Y | 8 | 8 | 0 | 89.7 (1.7) | 89.7 (1.7) | 87.1 | S09!W12:AD19 |
| S09-E | S09-D | PSLN-212Y | 8 | 8 | 0 | 89.5 (3.0) | 89.5 (3.0) | 84.5 | S09!G39:N46 |
| S09-E | S09-D | Sham | 8 | 0 | 8 | 80.5 (2.6) | — | 77.5 | S09!O39:V46 |
| S09-E | S09-D | PSLN-344Y | 8 | 8 | 0 | 90.7 (3.3) | 90.7 (3.3) | 86.3 | S09!W39:AD46 |
| S09-G | S09-F | PSLN-212Y | 8 | 8 | 0 | 89.3 (1.8) | 89.3 (1.8) | 86.1 | S09!G66:N73 |
| S09-G | S09-F | Sham | 8 | 0 | 8 | 79.6 (1.7) | — | 78.2 | S09!O66:V73 |
| S09-G | S09-F | PSLN-344Y | 8 | 8 | 0 | 87.3 (1.5) | 87.3 (1.5) | 85.5 | S09!W66:AD73 |
| S13-F | S03-I | PSLN-212(Y) | 7 | 7 | 0 | 93.5 (3.0) | 93.5 (3.0) | 89.7 | S13!B33:H40 |
| S13-F | S03-I | Sham | 7 | 0 | 7 | 79.4 (2.1) | — | 77.0 | S13!I33:O40 |
| S13-F | S03-I | PSLN-212 | 7 | 3 | 4 | 82.9 (5.9) | 89.0 (2.3) | 77.0 | S13!P33:V40 |
| S13-F | S03-I | PSLN-344 | 7 | 7 | 0 | 91.5 (2.1) | 91.5 (2.1) | 88.8 | S13!W33:AC40 |
| S13-F | S03-I | Naïve | 7 | 0 | 7 | 82.5 (3.5) | — | 78.5 | S13!AD33:AJ40 |
| S13-G | S03-J | PSLN-344 | 10 | 10 | 0 | 93.5 (2.2) | 93.5 (2.2) | 91.3 | S13!B43:K50 |
| S13-G | S03-J | Sham | 10 | 5 | 5 | 85.3 (7.3) | 90.7 (6.6) | 77.8 | S13!L43:U50 |
| S13-G | S03-J | Naïve | 10 | 1 | 9 | 78.8 (2.7) | 85.3 | 76.8 | S13!V43:AE50 |
| S15-A | S06-A | PSLN-212(Y) | 7 | 7 | 0 | 90.8 (3.2) | 90.8 (3.2) | 85.7 | S15!B3:H10 |
| S15-A | S06-A | Sham | 7 | 0 | 7 | 85.3 (3.1) | — | 82.3 | S15!I3:O10 |
| S15-A | S06-A | PSLN-212 | 7 | 1 | 6 | 82.1 (2.0) | 84.1 | 78.2 | S15!P3:V10 |
| S15-A | S06-A | PSLN-344 | 7 | 6 | 1 | 86.8 (3.3) | 87.0 (3.5) | 83.0 | S15!W3:AC10 |
| S15-B | S06-B | PSLN-212(Y) | 7 | 7 | 0 | 88.1 (2.8) | 88.1 (2.8) | 84.3 | S15!B13:H20 |
| S15-B | S06-B | Sham | 7 | 0 | 7 | 83.1 (5.3) | — | 78.2 | S15!I13:O20 |
| S15-B | S06-B | PSLN-212 | 7 | 0 | 7 | 81.1 (0.9) | — | 79.5 | S15!P13:V20 |
| S15-B | S06-B | PSLN-344 | 7 | 5 | 2 | 84.1 (4.7) | 86.4 (3.0) | 78.2 | S15!W13:AC20 |
| S15-C | S06-C | PSLN-212(Y) | 7 | 7 | 0 | 91.9 (2.6) | 91.9 (2.6) | 88.2 | S15!B23:H30 |
| S15-C | S06-C | Sham | 7 | 0 | 7 | 84.4 (1.8) | — | 82.1 | S15!I23:O30 |
| S15-C | S06-C | PSLN-212 | 7 | 1 | 6 | 82.6 (2.7) | 86.2 | 77.5 | S15!P23:V30 |
| S15-C | S06-C | PSLN-344 | 7 | 7 | 0 | 87.3 (4.7) | 87.3 (4.7) | 77.9 | S15!W23:AC30 |
| S15-D | S06-D | PSLN-212(Y) | 7 | 5 | 2 | 88.4 (6.6) | 92.1 (1.8) | 76.5 | S15!B33:H40 |
| S15-D | S06-D | Sham | 7 | 0 | 7 | 90.6 (4.5) | — | 81.2 | S15!I33:O40 |
| S15-D | S06-D | PSLN-212 | 7 | 2 | 5 | 82.9 (3.7) | 87.0 (4.4) | 78.6 | S15!P33:V40 |
| S15-D | S06-D | PSLN-344 | 7 | 5 | 2 | 86.1 (3.7) | 87.8 (2.2) | 79.5 | S15!W33:AC40 |
| S15-E | S06-E | PSLN-212(Y) | 7 | 7 | 0 | 90.4 (3.3) | 90.4 (3.3) | 86.1 | S15!B43:H50 |
| S15-E | S06-E | Sham | 7 | 0 | 7 | 84.9 (2.6) | — | 81.4 | S15!I43:O50 |
| S15-E | S06-E | PSLN-212 | 7 | 1 | 6 | 81.8 (4.3) | 91.1 | 78.5 | S15!P43:V50 |
| S15-E | S06-E | PSLN-344 | 7 | 6 | 1 | 88.5 (5.6) | 89.9 (4.5) | 79.8 | S15!W43:AC50 |
| S15-E | S06-E | Untreated | 7 | 6 | 1 | 97.5 (2.1) | 98.0 (1.8) | 94.5 | S15!AD43:AJ50 |
| S15-F | S06-F | PSLN-212(Y) | 7 | 7 | 0 | 87.9 (4.0) | 87.9 (4.0) | 82.4 | S15!B53:H60 |
| S15-F | S06-F | Sham | 7 | 0 | 7 | 86.8 (5.4) | — | 81.2 | S15!I53:O60 |
| S15-F | S06-F | PSLN-212 | 7 | 1 | 6 | 82.2 (2.2) | 83.7 | 78.2 | S15!P53:V60 |
| S15-F | S06-F | PSLN-344 | 7 | 5 | 2 | 85.0 (3.5) | 85.2 (4.3) | 80.3 | S15!W53:AC60 |
| S15-F | S06-F | Untreated | 7 | 7 | 0 | 97.5 (1.2) | 97.5 (1.2) | 95.5 | S15!AD53:AJ60 |
| S15-G | S06-G | PSLN-212(Y) | 7 | 7 | 0 | 89.5 (2.1) | 89.5 (2.1) | 87.1 | S15!B63:H70 |
| S15-G | S06-G | Sham | 7 | 0 | 7 | 81.5 (1.8) | — | 79.3 | S15!I63:O70 |
| S15-G | S06-G | PSLN-212 | 7 | 0 | 7 | 80.9 (1.6) | — | 78.8 | S15!P63:V70 |
| S15-G | S06-G | PSLN-344 | 7 | 5 | 2 | 85.6 (4.9) | 88.3 (1.7) | 77.5 | S15!W63:AC70 |
| S15-G | S06-G | Untreated | 7 | 4 | 3 | 97.1 (1.5) | 98.2 (0.7) | 95.0 | S15!AD63:AJ70 |
| S15-I | S15-H | 3d Vaccine | 7 | 0 | 7 | 82.7 (2.5) | — | 79.2 | S15!I72:O79 |
| S15-I | S15-H | 3d PSLN-344 | 7 | 0 | 7 | 81.2 (2.0) | — | 78.5 | S15!P72:V79 |
| S15-I | S15-H | 3d Vaccine+PSLN-344 | 7 | 6 | 1 | 87.3 (4.7) | 88.9 (2.5) | 77.9 | S15!W72:AC79 |
| S15-J | S06-E2 | Naïve+PSLN-212 | 7 | 0 | 7 | 86.6 (3.5) | — | 81.9 | S15!I83:O90 |
| S15-J | S06-E2 | Imprinting+PSLN-212 | 7 | 4 | 3 | 85.4 (2.1) | 86.2 (1.5) | 82.5 | S15!P83:V90 |
| S15-J | S06-E2 | Naïve+PSLN-344 | 7 | 6 | 1 | 87.6 (1.9) | 87.3 (1.9) | 84.2 | S15!W83:AC90 |
| S15-J | S06-E2 | Imprinting+PSLN-344 | 7 | 6 | 1 | 90.7 (4.3) | 92.1 (2.6) | 82.5 | S15!AD83:AJ90 |
| S15-K | S06-F2 | Naïve+PSLN-212 | 7 | 0 | 7 | 83.9 (2.6) | — | 80.5 | S15!I93:O100 |
| S15-K | S06-F2 | Imprinting+PSLN-212 | 7 | 0 | 7 | 84.7 (2.0) | — | 81.6 | S15!P93:V100 |
| S15-K | S06-F2 | Naïve+PSLN-344 | 7 | 6 | 1 | 86.9 (4.2) | 88.0 (3.3) | 80.4 | S15!W93:AC100 |
| S15-K | S06-F2 | Imprinting+PSLN-344 | 7 | 6 | 1 | 84.5 (3.9) | 85.0 (4.0) | 81.3 | S15!AD93:AJ100 |
| S15-M | S15-L | PSLN-212(Y) | 7 | 7 | 0 | 91.0 (2.7) | 91.0 (2.7) | 86.3 | S15!I103:O110 |
| S15-M | S15-L | Sham | 7 | 0 | 7 | 86.0 (3.4) | — | 82.1 | S15!P103:V110 |
| S15-M | S15-L | PSLN-212 | 7 | 0 | 7 | 81.8 (2.7) | — | 77.5 | S15!W103:AC110 |
| S15-M | S15-L | PSLN-344 | 7 | 6 | 1 | 88.1 (3.2) | 88.6 (3.2) | 83.0 | S15!AD103:AJ110 |
| S15-O | S15-N | PSLN-212(Y) | 7 | 7 | 0 | 91.1 (1.6) | 91.1 (1.6) | 88.2 | S15!I134:O141 |
| S15-O | S15-N | Sham | 7 | 0 | 7 | 83.1 (2.8) | — | 80.2 | S15!P134:V141 |
| S15-O | S15-N | PSLN-212 | 7 | 2 | 5 | 83.4 (3.2) | 87.9 (1.0) | 80.4 | S15!W134:AC141 |
| S15-O | S15-N | PSLN-344 | 7 | 6 | 1 | 88.4 (1.8) | 88.9 (1.3) | 85.1 | S15!AD134:AJ141 |

S08-D, body weight after vaccination (no challenge), mean % of day 0 by day (n=5; PSLN-212/R848 n=4 on day 10; cells S08!B21:AE26):

| Group | d2 | d4 | d6 | d8 | d10 | Lowest single animal (day) |
|---|---|---|---|---|---|---|
| Vaccine | 98.4 | 98.8 | 99.6 | 99.9 | 100.2 | 97.1 (d4) |
| PSLN-212(Y) | 98.4 | 97.7 | 100.3 | 100.4 | 100.7 | 96.0 (d4) |
| PSLN-212 | 98.3 | 97.0 | 98.5 | 100.1 | 101.0 | 94.5 (d4) |
| CMP-204 | 97.1 | 96.0 | 97.1 | 100.4 | 100.9 | 93.2 (d4) |
| PSLN-344 | 97.5 | 96.7 | 97.4 | 98.6 | 99.8 | 94.2 (d4) |
| PSLN-212/R848 | 97.7 | 95.1 | 93.9 | 91.7 | 90.7 | 84.7 (d10) |

S08-D contrasts (Welch t-test on the animals weighed that day):

| Day | PSLN-344 − Vaccine, points | p | PSLN-344 − PSLN-212, points | p |
|---|---|---|---|---|
| 2 | -1.0 | 0.15 | -0.8 | 0.2 |
| 4 | -2.2 | 0.062 | -0.3 | 0.77 |
| 6 | -2.3 | 0.021 | -1.1 | 0.28 |
| 8 | -1.3 | 0.11 | -1.6 | 0.1 |
| 10 | -0.5 | 0.19 | -1.2 | 0.062 |

## 6. QC log — internal inconsistencies found in the workbook

Nothing in the workbook was altered. Each item can be reproduced with `analysis/qc_checks.py`, `analysis/bw_recon.py`, `analysis/surv_dups.py` and `analysis/qc_counts.py`.

| # | Finding (verifiable in the workbook) | Cells | Consequence for the case | How it was handled |
|---|---|---|---|---|
| Q1 | **IgG2a/IgG1 quotient headers are rotated.** The printed quotients in S03-B and S03-F reproduce the quotients recomputed from the subclass titres (S13-A÷S13-B; S13-C÷S13-D) only after a one-place rotation of the group headers: the column printed "PSLN-344" holds the PSLN-212 quotients (e.g. 127.7/172.65 = 0.7396 = S03!H3), "PSLN-212(Y)" holds the PSLN-344 quotients, "PSLN-212" holds the PSLN-212(Y) quotients. | S03!G2:I7, S03!G9:I14 vs S13!A2:O7 | As printed, PSLN-344 would look IgG1-skewed (0.58 / 0.51). The subclass titres say the opposite (2.14 / 2.73). The S13 labels are the ones consistent with total IgG in S03-A/E. | Ratio recomputed per animal from S13-A–D. S03-B/F not used. |
| Q2 | **S03-I and its body-weight block S13-F name different groups for "the same animals".** S03-I: Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y). S13-F: PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naïve. In S13-F the "PSLN-212" arm has 3 animals that recover and 4 whose weights are carried forward from day 10; in S03-I "PSLN-212" has 0/7 survivors (all dead by day 6) and "CMP-204" has 3/7. | S03!A16:F51 vs S13!A31:AJ40 | The comparator arms of the homologous challenge are uncertain: PSLN-212 is either 0/7 (S03-I as printed) or 3/7 (S13-F labels), and the CMP-204 3/7 result may belong to PSLN-212. **PSLN-344 (7/7) and the young arm (7/7) are identical in both blocks.** | S03-I reported as printed, alternative reading stated; pooled PSLN-344-vs-PSLN-212 result repeated without S03-I/S03-J (sensitivity S2). |
| Q3 | **S03-J and its body-weight block S13-G name different groups, and n is inconsistent.** S03-J: Sham, PSLN-212, PSLN-344 (label says n=9; 10 rows per group). S13-G: PSLN-344, Sham, Naïve (n=10). One PSLN-344 row has a group flag but no day. Survivors are censored at day 21 although the annotation gives a 22-day observation period. | S03!G16:J46 (empty day: S03!G46) vs S13!A42:AE50 | Comparator identity in the wild-type H5N1 study is uncertain (the printed "PSLN-212" 3/10 may be the vaccine-only arm and the printed "Sham" 1/10 may be unvaccinated). **PSLN-344 has 10 rows flagged 0 and 10 complete weight series to day 14.** | Reported as 10/10 with the missing day entered as censored at day 14 (last day documented in S13-G). |
| Q4 | **S06-C and S06-D are identical in every arm** (same death days in Sham and PSLN-212, 7/7 in the others), although they are annotated as different experiments (challenge on day 14 vs day 3). The body-weight block paired with S06-D (S15-D) shows carried-forward weights for 2 PSLN-344 animals (79.5 and 85.2 from day 8) and 2 young animals (82.1, 76.5) that S06-D counts as survivors. | S06!M3:Q30 vs S06!A34:E61; S15!B33:AC40 | The day-3 rgH5N1 result for PSLN-344 is 7/7 (table) or 5/7 (weights). The independent repeat of that design, S15-H, gives 6/7. | S06-D reported as printed; all pooled results repeated without S06-D (sensitivity S1) and with the lower count. |
| Q5 | **Survivor counts differ between time-to-event tables and paired body-weight blocks in 6 further arms.** S06-E PSLN-344 5/7 (table) vs 6/7 (weights) and PSLN-212 0/7 vs 1/7; S06-G PSLN-344 4/7 vs 5/7; S06-C PSLN-212 2/7 vs 1/7; S15-L young PSLN-212 6/7 vs 7/7; S09-F Sham has 7 rows where S09-G has 8 animals (all lost). In addition, in arms where counts agree, 27 of 183 dead animals have a genuine weight recorded after their tabulated day of death. | S06 vs S15 blocks; S09!A66:B72 vs S09!O66:V73 | Net effect on PSLN-344 across the 9 aged BALB/c experiments is zero (56/66 by either source); the arm-by-arm minimum is 54/66. | Time-to-event tables used as primary; body weight used as supportive only. |
| Q6 | **Body-weight series repeat between experiments annotated as independent.** Examples: S15-C PSLN-344 vs S15-I "3d Vaccine+PSLN-344": 40 of 42 values identical on days 2–12; S15-M young C57BL/6 vs S09-E young BALB/c PSLN-344Y: 32 of 49 values identical; S09-C day 12: PSLN-212Y row = PSLN-344Y row (8/8); S15-A Sham day 4 = S15-M PSLN-212 day 4 (7/7); S09-E col N = S09-G col N (7/7); the same dead-animal trace (…85.1) appears in the PSLN-344 arm of S15-A, S15-M and S15-O. 80 animal-pairs share ≥3 identical same-day values. | S15!W24:AC29 vs S15!W73:AC78; S15!I104:O110 vs S09!X40:AD46; S09!G18:N18 vs S09!W18:AD18; S15!I5:O5 vs S15!W105:AC105 | Post-challenge body weight cannot support quantitative morbidity claims, and the three experiments sharing a trace (BALB/c, C57BL/6, Swiss Webster) also share an identical PSLN-344 survival vector (one death on day 8). | Body weight after challenge quoted as approximate and flagged. Post-vaccination weight (S08-D) has no duplicates and is used. |
| Q7 | **S11-B (neutrophils) partly duplicates S11-A (alveolar macrophages):** 35 of 100 values are identical in the same position; the first replicate column matches in 19/20 group-days and the second in 15/20. | S11!B3:U7 vs S11!B10:U14 | The neutrophil time course is not an independent measurement; it cannot be used to claim absence (or presence) of neutrophilic inflammation. | Neither block used for a safety claim. |
| Q8 | **S09-A: two panels carry the same "16h" label.** The Ifnb1 rows are log10 of S01-A values: first panel = S01-A 16 h (21/21 values), second panel = S01-A 72 h (21/21). The S09-A "PBS" values are the S01-A "Sham" animals. | S09!A1:AS9 vs S01!A2:L10 | The second panel is the 72-h time point. Read as a second 16-h dataset it would contradict the first (PSLN-344 *Ifnb1* 4× vs 36×) and the slow resolution in aged lungs would be missed. Control identity (buffer vs empty liposome) is ambiguous. | Second panel analysed as 72 h and marked as inferred. |
| Q9 | **S07-C: both columns carry the same label** ("Ly6C-CD206+ MΦ"); the annotation says two different macrophage populations were transferred. | S07!B15:C20 | Lung Treg is 10.4% after one transfer and 5.1% after the other, but which population is which cannot be known. | Not used. |
| Q10 | **S08-C conflicts with S01-B for the same measurand.** AECI uptake of PSLN-SRB is 3.8% in S01-B and 13.8% in S08-C; the S08-C column printed "AECII-PSLN-344-SRB" (3.8%) shares values with S01-B AECI/PSLN-SRB. A transposition of the two middle headers would reconcile the blocks. | S08!A13:D18 vs S01!A14:F15 | As printed, Mn complexation would cut type II epithelial uptake four-fold (15.8% → 3.8%); if transposed, uptake is unchanged (15.8% vs 13.8%). Whether Mn changes cell targeting is unresolved. | Not used; listed as an open question for CMC/biodistribution. |
| Q11 | **Label problems.** "S06-E" and "S06-F" are each used for two different experiments (rows 32–68 and rows 69–105). S08 rows 89–101 hold 13 unlabelled rows (14; 0). S08-A contains a formulation ("PSLN-344/R848") not described in Materials. | S06!G32, M32, G69, M69; S08!A89:D101; S08!K2 | None on the numbers, but citations must give rows. | Second S06-E/F cited as S06-E2/F2 with cell ranges; orphan rows excluded. |
| Q12 | **Stated n differs from the data:** S03-J (n=9 stated, 10 found), S05-A and S05-B (3 stated, 2 found), S13-E (5 stated, 7 found), S09-F Sham (8 stated, 7 found; the annotation attributes the short group to S09-B). | block labels | S05-A/B rest on 2 animals per point. | Observed n used and stated. |
| Q13 | **S05-A/B conditions are internally inconsistent** (ovalbumin immunisation and bivalent vaccination are both stated; the readout is an influenza NP tetramer). | annotation p. 8 | With Q12, the tetramer time course is descriptive only. | Not used for any claim; T-cell evidence taken from S05-D–I and S14-A (n=5). |
| Q14 | **Missing conditions.** Challenge virus and day are not given for S15-L–O (C57BL/6, Swiss Webster) or the day for S06-E2; time point not given for S13-H, S14-A, S11-E, S07-B; animal age not given for S08-A, S02-F–H; the adjuvant/age of the "PTX" group in S02-C/E is not given. | annotation | The two extra-strain experiments cannot be placed in the day-3/14/60 framework. | Reported separately, not pooled into the BALB/c total. |
| Q15 | **S07-A runs opposite to the related blocks.** Ly6C+CCR2+ macrophage counts rise with PSLN-212 (19.0 ×10^5 at day 5) and stay flat with PSLN-344 (3.4 ×10^5), whereas monocyte influx is higher with PSLN-344 (S01-D) and PSLN-344 animals carry abundant CCR2-dependent Ly6C+ macrophages (15.4%, S07-B). n=3. | S07!A2:G7 | Could be biology (monocytes becoming macrophages rather than DCs without GM-CSF) or a column swap; it cannot be told from the file. | Not used in the mechanism argument. |
| Q16 | **Unchallenged, untreated aged animals died during the day-60 observation windows:** 1/7, 0/7 and 3/7 (4/21), without weight loss (last weights 94.5–96.6% of baseline). | S06!G62:L68, M62:R68, A99:F105; S15!AD43:AJ70 | Background mortality at ≥22 months confounds day-60 survival; n=7 cannot separate it from waning. | Stated wherever day-60 results are quoted. |


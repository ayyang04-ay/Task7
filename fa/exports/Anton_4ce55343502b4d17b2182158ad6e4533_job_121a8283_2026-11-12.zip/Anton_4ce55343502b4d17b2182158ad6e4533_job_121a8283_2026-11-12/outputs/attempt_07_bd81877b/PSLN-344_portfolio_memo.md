# PSLN-344 — portfolio recommendation

**Basis.** `adjuvant_program_dataset.xlsx` (15 sheets; all 6,819 numeric cells accounted for) and `adjuvant_program_annotation.pdf`. Every number below was recomputed from the workbook. The block ID in square brackets is the citation; the companion file `PSLN-344_numbers_ledger.md` gives, for each block, the cells, n, and the reduction. Reduction rules are summarised in §7. Study designs, pass/fail thresholds and regulatory remarks in §1 and §5 are my proposals, not data, and are marked as such.

Terms used throughout: "aged" = 20 months or older unless stated; "vaccine + empty liposome" = the workbook's *Sham*; "PSLN-212" = the same particle without Mn²⁺; "young PSLN-212" = *PSLN-212(Y)*, the benchmark for a normal response. The workbook uses the labels S06-E and S06-F twice; the second pair (rows 69–105, the prior-infection experiment) is cited here as S06-E2 and S06-F2. Bracketed codes such as [A1] are pooled analyses defined in ledger §2.

---

## 1. Recommendation

**Advance PSLN-344 — conditionally.** Fund one gated stage of about 9–12 months. It should repeat the efficacy result under the controls the package lacks, and test the three things most likely to stop the programme: safety of an intranasal manganese–STING-agonist particle, durability in aged hosts, and whether the effect survives a licensed antigen, a second species and a human-feasible route. Hold IND-enabling spend until those gates are passed. The first gate is a 2–4-week check of the survival tables against primary records; no new animal work should start until it passes.

**Why advance**

1. **It rescues a vaccine that otherwise fails in aged animals.** Across nine lethal-challenge experiments in aged BALB/c mice, one intranasal dose with PSLN-344 left 56 of 66 animals alive (85%; 95% CI 74–92). Vaccine + empty liposome left 1 of 66, and PSLN-212 left 9 of 66 [S03-I, S03-J, S06-A to S06-G].
2. **The gain traces to one change.** PSLN-344 and PSLN-212 differ only in Mn²⁺. PSLN-212 protects young mice (56/56 in the eight of those experiments that include a young arm) and fails in aged ones.
3. **Protection is fast, broad and still present at 60 days.** 28/31 survive challenge 2–3 days after vaccination [D1]; 20/28 survive viruses that share neither HA nor NA subtype with the vaccine [E3]; 14/21 survive challenge at day 60 [C1].
4. **It holds outside the index model.** 12/14 in aged C57BL/6 and Swiss Webster mice [S15-L, S15-N]; 12/14 in 14-month-old mice with a prior influenza infection [S06-E2, S06-F2].
5. **The mechanism is coherent and measurable**, which gives the next stage concrete readouts (§5).

**Why only conditionally**

- The comparators are an unadjuvanted intranasal vaccine and the Mn-free parent. Nothing in the package compares PSLN-344 with what older adults receive today, there is no Mn-only control, and efficacy was tested at one dose (20 µg).
- Safety rests on three small datasets. Nasal manganese is the obvious regulatory question, and there is no biodistribution, histopathology, systemic-exposure or repeat-dose safety data.
- Aged animals given PSLN-344 still do less well than young animals given PSLN-212: 46/56 vs 56/56 across the eight experiments with both arms (stratified log-rank p = 0.0009 [B1]). The gap is absent at day 14 (20/21 vs 21/21) and concentrated at day 60 (14/21 vs 21/21; Fisher p = 0.009) [S06-E, S06-F, S06-G].
- Everything is in mice, with an in-house whole-virus vaccine, given in a way that reaches the lung.
- The workbook has internal inconsistencies (§4). None reverses the result. Several change individual numbers, and they need reconciling against source records before the committee sees them.

**Proposed gates** (thresholds are my proposals for the committee to set)

| Gate | Question | Proposed pass criterion | Study (§5.3) |
|---|---|---|---|
| G0 Data | Are the survival tables right? | PSLN-344 counts in the nine core experiments confirmed from primary records; QC items Q1–Q6 resolved | N0 |
| G1 Efficacy | Does it repeat, blinded, in both sexes, against the right controls? | ≥70% survival and ≥40 points above both the Mn-free and a Mn-only control; ≥1 log₁₀ lower lung virus titre than vaccine alone; not worse than a licensed-type intramuscular comparator on matched challenge, better on heterosubtypic challenge | N1 |
| G2 Safety | Is there a tolerated dose with full activity? | At a dose giving ≥80% of maximal protection: no Mn above control in olfactory bulb or brain at day 7, lung cytokines ≤2× baseline by day 7, no adverse nasal, lung or CNS histology 28 days after three doses | N3, N4 |
| G3 Durability | Does protection last long enough to matter? | ≥60% survival at ≥120 days after the last dose, with one or two doses | N3 |
| G4 Translation | Is the pharmacology there in human cells and a second species? | Mn-dependent interferon and GM-CSF induction in cells from donors ≥65 years; protection in ferrets by a clinically feasible route | N5, N6 |

---

## 2. The case: what the data show

### 2.1 Survival after lethal challenge

One intranasal dose; survivors / animals at the end of the observation window; labels as printed. p values are log-rank on the per-animal rows.

| Block | Vaccine → challenge, interval | Vaccine + empty liposome | PSLN-212 (aged) | **PSLN-344 (aged)** | PSLN-212 (young) | Untreated, unchallenged aged | p, 344 vs empty liposome | p, 344 vs 212 |
|---|---|---|---|---|---|---|---|---|
| S03-J | rgH5N1 → wild-type H5N1 (matched), day 2 | 1/10 ᵃ | 3/10 ᵃ | **10/10** | – | – | 0.00008 | 0.0014 |
| S06-B | H3N2 → PR8 H1N1, day 3 | 0/7 | 0/7 | **5/7** | 7/7 | – | 0.0002 | 0.0009 |
| S06-D | H1N1+H3N2 → rgH5N1, day 3 | 0/7 | 2/7 | **7/7** ᵇ | 7/7 ᵇ | – | 0.0002 | 0.0068 |
| S03-I | H1N1+H3N2 → CA09 H1N1, 10× LD50 (matched), day 14 | 0/7 | 0/7 ᶜ | **7/7** | 7/7 | – | 0.0002 | 0.0004 |
| S06-A | H3N2 → PR8 H1N1, day 14 | 0/7 | 1/7 | **6/7** | 7/7 | – | 0.0002 | 0.0083 |
| S06-C | H1N1+H3N2 → rgH5N1, day 14 | 0/7 | 2/7 | **7/7** | 7/7 | – | 0.0002 | 0.0068 |
| S06-E | H3N2 → PR8 H1N1, day 60 | 0/7 | 0/7 | **5/7** | 7/7 | 6/7 | 0.0002 | 0.0016 |
| S06-F | H1N1+H3N2 → rgH5N1, day 60 | 0/7 | 1/7 | **5/7** | 7/7 | 7/7 | 0.0002 | 0.0094 |
| S06-G | H1N1 → Perth H3N2, day 60 | 0/7 | 0/7 | **4/7** | 7/7 | 4/7 | 0.0002 | 0.015 |
| S15-L | C57BL/6, 20 months (challenge not annotated) | 0/7 | 0/7 | **6/7** | 6/7 | – | 0.0007 | 0.0011 |
| S15-N | Swiss Webster, 20 months (challenge not annotated) | 0/7 | 2/7 | **6/7** | 7/7 | – | 0.0011 | 0.056 |

ᵃ Comparator labels conflict with the paired body-weight block (Q3). ᵇ This table is identical to S06-C; the paired weight block implies 5/7 and 5/7 (Q4). ᶜ 3/7 under the labels of the paired body-weight block (Q2). See §4; none of these affects the direction of the PSLN-344 result.

![Fig 1](figures/fig1_survival_overview.png)

Kaplan–Meier curves for every block are in `figures/fig2_km_panels.png`.

Pooled (sums over the blocks named; stratified log-rank, strata = experiment; ledger §2):

| Comparison | PSLN-344 | Comparator | Difference, points (95% CI) | p |
|---|---|---|---|---|
| Nine aged BALB/c experiments, vs vaccine + empty liposome [A1] | 56/66 (85%; 74–92) | 1/66 (2%) | 83 (71–90) | 3×10⁻²⁹ |
| Same, vs PSLN-212 [A2] | 56/66 | 9/66 (14%) | 71 (56–80) | 2×10⁻¹⁸ |
| Challenge 2–3 days after vaccination: S03-J, S06-B, S06-D, S15-H, vs vaccine-only control [D1] | 28/31 (90%; 74–98) | 1/31 | 87 (67–94) | 4×10⁻¹⁴ |
| Challenge at day 14: S03-I, S06-A, S06-C [D2] | 20/21 (95%; 76–100) | 0/21 | 95 (72–99) | 9×10⁻¹¹ |
| Challenge at day 60: S06-E, S06-F, S06-G [C1] | 14/21 (67%; 43–85) | 0/21 | 67 (40–83) | 1×10⁻¹⁰ |
| Virus shares neither HA nor NA subtype with the vaccine: S06-A, B, E, G [E3] | 20/28 (71%; 51–87) | 0/28 | 71 (49–85) | 1×10⁻¹³ |
| Aged C57BL/6 and Swiss Webster [H1] | 12/14 (86%) | 0/14 | 86 (52–96) | 2×10⁻⁶ |
| 14-month mice, previously infected or not, vs PSLN-212 [F1] | 24/28 (86%) | 4/28 (14%) | 71 (47–84) | 6×10⁻⁹ |

Four further results carry the argument:

- **Antigen and adjuvant are both required.** Given 3 days before rgH5N1 challenge, vaccine alone protected 0/7, PSLN-344 alone 0/7, and the combination 6/7 (p = 0.0002 and 0.0001) [S15-H]. The early protection is not a general antiviral state induced by the STING agonist.
- **Mn adds no survival benefit in young animals.** Young mice survive equally with PSLN-344 or PSLN-212: 24/24 vs 24/24, including challenge 180 days after vaccination [S09-B, S09-D, S09-F]. The benefit is specific to the aged host. Both arms are at ceiling, so a difference under a harder challenge cannot be excluded.
- **Prior influenza exposure neither replaces nor blocks it.** In mice infected with PR8 at 10 months and vaccinated 4 months later, PSLN-344 gave 6/7 after PR8 challenge and 6/7 after Perth H3N2; PSLN-212 gave 4/7 and 0/7. Never-infected controls: 6/7 and 6/7 vs 0/7 and 0/7 [S06-E2, S06-F2]. The Mn-free parent therefore already fails at 14 months.
- **Survivors are protected from death, not from illness.** After heterosubtypic challenge, aged PSLN-344 survivors lost roughly 10–15% of body weight before recovering (mean nadir 85–90% of baseline across S15-A, B, E, F, G), a few points worse than the young benchmark (88–91%). These weights are approximate; see Q6 in §4.

### 2.2 How robust is the headline number?

The survival tables contain duplicated and conflicting entries (§4). The result does not depend on them:

| Reading of the nine aged BALB/c experiments | PSLN-344 | Vaccine + empty liposome | PSLN-212 |
|---|---|---|---|
| As printed | 56/66 (85%) | 1/66 | 9/66 |
| Without S06-D (identical to S06-C in every arm) | 49/59 (83%) | 1/59 | 7/59 |
| Without S06-C and S06-D | 42/52 (81%) | 1/52 | 5/52 |
| Lower of survival-table and body-weight count, arm by arm | 54/66 (82%) | – | – |
| Only the five experiments whose tables carry no label conflict or duplication (S06-A, B, E, F, G) | 25/35 (71%; 54–85) | 0/35 | 2/35 |

The last row is the floor. It is also the hardest subset: every experiment in it is either fully heterosubtypic or a day-60 challenge.

Each of the nine per-experiment comparisons with vaccine + empty liposome has log-rank p ≤ 0.00022; all nine survive a Bonferroni correction. With n = 7, Fisher's exact test on final survival is weaker for the three day-60 experiments and S06-B (p = 0.02–0.07), which is why those results are best read pooled.

### 2.3 What Mn restores in the aged immune response

For each readout with aged PSLN-212, aged PSLN-344 and young PSLN-212 arms, I computed a restoration index: 0 means no better than aged PSLN-212, 1 means equal to young PSLN-212 (ledger §4a; Fig 3).

| Layer | Readout [block] | Aged PSLN-212 | Aged PSLN-344 | Young PSLN-212 | Index |
|---|---|---|---|---|---|
| Innate | Lung *Ifnb1*, 16 h, fold [S01-A] | 16.6 ± 2.1 | 37.1 ± 4.8 | 37.6 ± 3.5 | 0.98 |
| | Lung monocytes, day 4, % [S01-D] | 16.7 ± 1.6 | 30.6 ± 4.7 | 32.2 ± 3.9 | 0.89 |
| Dendritic cells | Migratory CCR7⁺ CD11b⁺ DC in lung, % [S02-A] | 7.3 ± 2.0 | 30.7 ± 7.9 | 35.0 ± 4.8 | 0.84 |
| | Antigen-carrying DC in lymph node, % [S02-C] | 1.8 ± 0.4 | 7.1 ± 1.4 | 9.4 ± 1.5 | 0.70 |
| | T-cell priming by lymph-node DC ex vivo, % divided [S02-E] | 0.8 ± 0.5 | 18.7 ± 2.8 | 26.2 ± 6.7 | 0.70 |
| | CD40⁺ / CD86⁺ of lymph-node DC, % [S02-D] | 5.6 / 8.1 | 11.2 / 14.5 | 38.7 / 37.9 | 0.17 / 0.22 |
| Antibody | Serum IgG, CA09, GMT [S03-A] | 393 | 7,305 | 11,959 | 0.86 |
| | HAI, CA09, GMT [S03-C] | 46 | 368 | 485 | 0.88 |
| | Neutralising titre, CA09, GMT [S03-D] | 418 | 3,840 | 6,686 | 0.80 |
| | IgG2a ÷ IgG1, CA09 [recomputed from S13-A, S13-B] | 0.58 ± 0.20 | 2.14 ± 1.31 | 2.97 ± 1.69 | – |
| | Germinal-centre B cells, day 7, % [S03-K] | 2.3 ± 0.5 | 6.5 ± 1.5 | 9.8 ± 3.1 | 0.56 |
| Regulation | Follicular regulatory T cells, day 7, % [S04-B] | 26.7 ± 6.7 | 10.8 ± 1.8 | 7.1 ± 3.7 | 0.81 |
| | Same, day 30, % [S04-C] | 18.0 ± 3.8 | 14.0 ± 3.2 | 7.4 ± 1.6 | 0.38 |
| CD8 T cells | Lung Ki-67⁺ CD8 T, day 3, % [S05-D] | 3.5 ± 1.4 | 9.4 ± 1.8 | 9.9 ± 3.0 | 0.91 |
| | IFN-γ⁺ CD8 T after rgH5N1 restimulation, day 14, % [S05-F] | 1.5 ± 0.4 | 6.4 ± 1.0 | 9.2 ± 0.9 | 0.63 |
| | Same, day 60, % [S05-G] | 3.0 ± 1.3 | 9.9 ± 2.8 | 14.4 ± 2.9 | 0.60 |
| | Lung resident-memory CD8 T, day 25, % [S05-I] | 1.0 ± 0.4 | 4.0 ± 0.6 | 6.0 ± 0.6 | 0.59 |

Mean ± SD, n = 5 per group. Across 38 readouts the median index is 0.71 (inter-quartile range 0.61–0.81). PSLN-344 differs from aged PSLN-212 in 37 of 38 (Welch p < 0.05) and is still below young in 17 of 38.

![Fig 3](figures/fig3_restoration_index.png)

The pattern: the innate response is restored in full and the downstream adaptive response to 60–90%. Three things are not restored. Co-stimulatory molecules on dendritic cells close only about a fifth of the gap. The fall in follicular regulatory T cells has largely reversed by day 30 (14.0%, against 13.9% with vaccine + empty liposome). And the two T-cell readouts taken at day 60 sit at about 70% of young [S05-G, S05-H]. This fits the day-60 survival shortfall.

One caution on presentation. The IgG2a/IgG1 quotients printed in S03-B and S03-F sit under rotated headers (Q1 in §4). As printed, PSLN-344 looks IgG1-skewed (0.58). The subclass titres in S13 show the opposite (2.14). Quote the S13-derived values.

### 2.4 Tolerability so far

This is all of the safety evidence in the package (Fig 4):

- **Body weight after vaccination** [S08-D, n = 5]. PSLN-344: mean 96.7% of baseline at day 4 (lowest animal 94.2%), back to 99.8% by day 10. PSLN-212: 97.0% and 101.0%. Vaccine alone: 98.8% and 100.2%. PSLN-344 runs about 2 points below vaccine alone on days 4 and 6 (Welch p = 0.06 and 0.02) and is never significantly different from PSLN-212 (largest gap 1.6 points). The R848 combination fell to 90.7% by day 10 (lowest animal 84.7%) and one animal has no day-10 weight.
- **Lung cytokine transcripts** [S09-A, n = 3, geometric-mean fold over untreated]. At 16 h PSLN-344 induces *Ccl2* 590×, *Tnf* 40×, *Il6* 36×, *Ccl3* 30×, *Ccl5* 20×, *Il10* 7×. At 72 h: *Ccl2* 27×, *Ccl3* 9×, *Tnf* 8×, *Il6* 7×, *Il10* 4×. Young PSLN-212 at 72 h has *Tnf* 0.5× and *Il6* 3×; aged PSLN-212 has *Tnf* 5× and *Il6* 2×. Resolution is slower in aged lungs, and somewhat slower again with Mn. The 72 h assignment is inferred (Q8).
- **CNS transcripts at 36 h** [S10-A, n = 5]. PSLN-344 vs buffer: *Ifnb1* 1.3×, *Tnf* 1.6×, *Isg15* 1.1×. Cholera toxin, the positive control: 5.5×, 3.5×, 2.7×. The *Tnf* shift is borderline (Welch p = 0.05; Tukey p = 0.55), so a small effect is not excluded at this n.

![Fig 4](figures/fig4_tolerability.png)

No deaths, no weight loss beyond 6%, and no cholera-toxin-like CNS signal. That is reassuring for continuing and far short of a safety package.

### 2.5 What the package does not contain

No lung virus titres or pathology after challenge. No licensed-vaccine or intramuscular comparator. No Mn-only or unencapsulated control. No dose-ranging for protection or tolerability. No mucosal IgA. No serology beyond day 28 or resident-memory data beyond day 25. No males. No second species. No particle size, stability or batch data (encapsulation efficiency only: 54.8 ± 5.1%, n = 3 [S08-B]).

---

## 3. Where the case will be challenged, and the answer

| Challenge | What the data say | Residual risk and where it is closed |
|---|---|---|
| "n = 7, mice only." | The effect is large enough that n = 7 resolves it in every experiment, and it repeats in 12 experiments and three strains, one outbred. | Species translation is untested. N5 (ferret), N6 (human cells). |
| "The control is a straw man." | Fair for vaccine + empty liposome: unadjuvanted intranasal antigen gives IgG GMT 56 [S03-A]. PSLN-212 is the meaningful comparator: an active adjuvant that protects 56/56 young mice and 9/66 aged ones. | No comparison with a high-dose or adjuvanted intramuscular vaccine. With n = 7 the design has about 10% power to separate 85% from a comparator that protects 50%. N1. |
| "Is it the Mn alone?" | Not tested. What is known: the agonist without Mn protects 9/66, and Mn + agonist without antigen protects 0/7 [S15-H]. | A liposome carrying Mn but no agonist was never given with vaccine. N1. |
| "More STING agonist would do the same." | In the dose series, PSLN-212 plateaus at *Ifnb1* 12.6 (20 µg) and 14.9 (40 µg); PSLN-344 reaches 21.1 at 10 µg and 45.8 at 20 µg [S08-A, n = 3]. *Gm-csf* is induced only by PSLN-344: 6.0× vs 1.5× at 16 h [S02-F]. | Animal age in S08-A is not stated. No efficacy data at other doses. N3. |
| "Protection fades." | Day 60: 14/21, vs 20/21 at day 14 (Fisher p = 0.045) and 21/21 in young (p = 0.009). | Confounded: 4 of 21 untreated, unchallenged aged animals also died in those windows [S06-E, F, G], and PSLN-344 at day 60 does not differ from them (14/21 vs 17/21, p = 0.48). In matched designs the fall is 13/14 to 10/14 (p = 0.33). The five PSLN-344 deaths traceable in the weight records followed 15–23% weight loss, unlike the untreated deaths (3–6%), so some waning is probably real. N3. |
| "A boost would fix it." | Unknown. A day-14 boost roughly doubles IgG in PSLN-344 animals (GMT 7,305 → 15,651, CA09; different animals) [S03-A, S13-I], but the gap to young widens (61% → 38% of young GMT) and no boosted animals were challenged. | N3. |
| "Nasal manganese in older adults." | §2.4: transient weight loss, no CNS signal like cholera toxin. | No Mn distribution, histology or repeat-dose data. This is the most likely programme-stopper. N4, gate G2. |
| "Mouse intranasal dosing reaches the lung; a human nasal spray does not." | The mechanism as measured is alveolar: uptake by alveolar macrophages depends on surfactant proteins A/D (43.1% vs 12.7% in knockouts) [S01-C], and the particle delivers cargo to alveolar epithelium (15.8% of type II cells vs 0.4% for free dye) [S01-B]. | Human use may need inhaled delivery, a different product and safety profile. N5, N7. (Judgement, not data.) |
| "Whole-virus in-house vaccine." | All efficacy used formalin-inactivated whole virus. | Cross-subtype protection may rely on internal antigens that split vaccines carry little of. N1 includes a licensed split antigen. (Judgement.) |
| "Can we trust the workbook?" | §4. The PSLN-344 result is stable under every reading (§2.2). | N0 before committee. |

---

## 4. Data integrity: what the committee will find if it checks

I cross-checked every block against every related block. Sixteen items are logged with cell references in the ledger (§6 there). I had no access to primary records, so where two blocks disagree I report both readings rather than choose between them. The items that touch the case:

| # | Finding | Effect on the case | What I did |
|---|---|---|---|
| Q1 | IgG2a/IgG1 quotients in S03-B and S03-F are printed under rotated group headers; recomputing from the S13 subclass titres reproduces the values exactly, one column over. | As printed, PSLN-344 would look IgG1-skewed. It is IgG2a-skewed. | Recomputed from S13. |
| Q2 | S03-I (survival) and S13-F (weights of "the same animals") name different groups. S13-F has a Naïve arm where S03-I has CMP-204, and the arm labelled PSLN-212 has three recovering animals in S13-F but 0/7 survivors in S03-I. | PSLN-212 in the matched challenge is 0/7 or 3/7; the CMP-204 3/7 may belong to PSLN-212. PSLN-344 is 7/7 in both. | Reported as printed; sensitivity analysis without it. |
| Q3 | S03-J and S13-G also name different groups. The label says n = 9 but there are 10 rows per group, and one PSLN-344 row has no day [S03!G46]. | Comparator identity in the wild-type H5N1 study is uncertain. PSLN-344 is 10/10 by flags and by weights. | Reported as 10/10; missing day entered as censored at day 14. |
| Q4 | S06-C and S06-D are identical in all four arms, down to the death days, although annotated as day-14 and day-3 challenges. The weight block for S06-D implies two deaths in PSLN-344 and two in young animals that the table does not show. | Day-3 rgH5N1 result is 7/7 or 5/7. The repeat design S15-H gives 6/7. | Sensitivity rows in §2.2. |
| Q5 | Survivor counts differ between survival tables and weight blocks in six more arms (PSLN-344: S06-E 5/7 vs 6/7, S06-G 4/7 vs 5/7). | Net zero for PSLN-344 (56/66 either way); minimum 54/66. | Survival tables primary. |
| Q6 | Weight series repeat between experiments annotated as independent: for example 40 of 42 values are identical between S15-C PSLN-344 and S15-I, and the same dead-animal trace appears in the PSLN-344 arm of the BALB/c, C57BL/6 and Swiss Webster experiments, which also share an identical survival vector. | Post-challenge weights cannot carry quantitative claims. The two extra-strain experiments are less independent than they look. | Weights treated as supportive; extra strains not pooled into the headline. |
| Q7 | The neutrophil time course S11-B partly duplicates the alveolar-macrophage block S11-A (35 of 100 values identical in position). | No usable neutrophil data, for or against lung inflammation. | Not used. |
| Q8 | Both S09-A panels are labelled 16 h. The second matches the 72 h values of S01-A (21 of 21). | Read as 16 h, the cytokine response would be understated and the slow resolution missed. | Analysed as 72 h, marked inferred. |
| Q9, Q10, Q15 | S07-C has two identically labelled columns; S08-C conflicts with S01-B on epithelial uptake; S07-A runs opposite to related blocks. | Three mechanism panels cannot be interpreted. | Not used. |
| Q16 | Untreated, unchallenged aged animals died during the day-60 windows (1/7, 0/7, 3/7). | Confounds day-60 survival. | Stated wherever day-60 data appear. |

Before the review, I would have the source lab confirm Q2, Q3 and Q4 from primary records. They are the three a committee member can find in ten minutes.

---

## 5. Forward view

### 5.1 What is actually driving the protection

**Manganese, acting through an innate-to-T-cell relay in the lung that ageing breaks. The last link is inferred, not proven.** The evidence sits at three levels of certainty.

| Level | Statement | Evidence |
|---|---|---|
| **Shown on survival** | Mn is required in the aged host. | 56/66 vs 9/66, nine experiments; not required in young (24/24 vs 24/24). |
| | Protection needs antigen and adjuvant together, so it is adaptive. | 0/7, 0/7, 6/7 [S15-H]. |
| | Prior infection neither substitutes for nor blocks it. | 12/14 with or without prior infection [S06-E2, S06-F2]. |
| **Shown by intervention, on a cellular readout** | The particle enters alveolar macrophages via surfactant proteins and reaches epithelium. | 43.1% vs 12.7% in SP-A/D knockouts [S01-C]; 15.8% vs 0.4% for free dye [S01-B]. |
| | Monocyte recruitment needs gap junctions and CCR2. | 7.3% → 3.1% with carbenoxolone [S11-C]; 9.9% → 3.3% with a CCR2 antagonist [S07-B]. PSLN-344 induces the CCR2 ligand *Ccl2* 590× at 16 h, against 8× with PSLN-212 [S09-A, n = 3]. |
| | Recruited monocytes need type I interferon signalling to become dendritic cells; GM-CSF partly substitutes. | Donor-derived DCs 19.7% (wild-type) → 2.1% (*Ifnar*-deficient) → 12.4% (*Ifnar*-deficient + GM-CSF) [S02-H]. |
| | GM-CSF is a limiting factor with the Mn-free particle. | Adding recombinant GM-CSF to PSLN-212 raises monocyte-derived DCs 5.9% → 13.8% [S02-G]. PSLN-344 induces *Gm-csf* itself, 6.0× vs 1.5× [S02-F]. |
| | Lung CD8 T cells expand in the lung and depend on the monocyte influx. | Lung proliferation unchanged by pertussis toxin (59.0% vs 55.1%) while lymph-node proliferation falls (30.9% → 6.8%) [S05-C, n = 3]; lung granzyme-B⁺ CD8 T cells 6.8% → 1.4% with CCR2 blockade [S02-I, young mice]. |
| **Association only** | Cross-reactive CD8 T cells protect against mismatched virus and in the first days; antibody protects against matched virus. | Every T-cell and antibody readout rises with PSLN-344 (§2.3). No depletion, transfer or knockout experiment has survival as its readout. |
| | Mn relieves a suppressive environment in the aged lung. | CD206⁺ macrophages 48.9% vs 71.5% with PSLN-212 (young 35.5%) [S11-E]; lung regulatory T cells 3.0% vs 6.7% [S04-D, n = 3]. The transfer experiment meant to link the two cannot be read (Q9). |

What Mn adds is therefore specific: it lifts the interferon ceiling that PSLN-212 cannot reach at any dose tested, and it switches on *Gm-csf*. Together these convert recruited monocytes into antigen-presenting cells in an aged lung (Fig 5). One gap: *Gm-csf* was not measured in young animals, so the idea that ageing removes the GM-CSF response is an inference. Two observations argue that T cells, not antibody, explain the differentiating protection. Protection is present at day 2–3, earlier than an antibody response would be expected (no serology was done before day 14). And it extends to viruses sharing no HA or NA with the vaccine (20/28).

What is not excluded: non-neutralising IgG2a acting through Fc receptors, and an antigen-dependent innate effect. The data cannot separate these from CD8 T cells. Study N2 can.

![Fig 5](figures/fig5_mechanism.png)

### 5.2 Is there a biomarker worth carrying forward?

**Yes, as a panel of three with different jobs. None is yet a validated correlate of protection.** Immune readouts and survival were measured in different animals, and every readout moves together across the same four groups. The package can nominate candidates; it cannot rank them by prediction.

| Candidate | Evidence here | Measurable in people? | Role I would assign |
|---|---|---|---|
| **Cross-reactive CD8 T-cell response** (IFN-γ⁺ or granzyme-B⁺ CD8 T cells on restimulation with a mismatched virus; lung resident memory) | The only readout whose antigen specificity matches the heterosubtypic claim. Tracks survival across the eight group-by-time points where both exist (Spearman ρ = 0.85, group level) [S05-F, S05-G vs S06-C, S06-F]. Depends on the monocyte axis [S02-I]. Still present at day 60. | Yes in blood: IFN-γ / granzyme-B ELISpot or intracellular staining against conserved-antigen peptide pools, days 7–28. Lung resident memory is not routinely accessible; blood-to-tissue bridging is needed. | **Lead efficacy-linked (response) biomarker.** Secondary immunogenicity endpoint in Phase 1/2; candidate correlate for cross-protection. |
| **HAI and neutralising titre** | GMT 368 vs 46 (PSLN-212) vs 485 (young) [S03-C]. | Yes; the accepted immunogenicity endpoint for seasonal vaccines (regulatory practice, not our data). | **Registrational immunogenicity endpoint for matched strains. Necessary, not sufficient:** all 5 aged PSLN-212 animals reached HAI ≥ 40 against CA09 [S03-C], yet that group had 0/7 survivors, or 3/7 under the alternative labels (Q2) [S03-I]. Survival went with titres ≥ 160. |
| **Early innate signature** (type I interferon, GM-CSF, monocyte influx) | Separates PSLN-344 from PSLN-212 within 16 h (*Ifnb1* 37.1 vs 16.6; *Gm-csf* 6.0× vs 1.5×). Dose-responsive [S08-A]. The only candidates backed by add-back and knockout data [S02-G, S02-H]. | Plausibly: interferon-stimulated-gene score in whole blood, and CXCL10 / GM-CSF in nasal or airway lining fluid, 16–24 h after dosing. Untested in human samples. | **Pharmacodynamic / proof-of-mechanism and dose-selection biomarker.** Also a screen for any future adjuvant aimed at older adults. |

Roles the data do not support: patient selection (no data on who responds) and surrogate endpoint for licensure. Published work on T-cell correlates of influenza protection in older adults points the same way as the first row; I have not re-verified that literature for this memo.

Two findings should temper expectations. First, the CD8 readout does not explain the day-60 shortfall: IFN-γ⁺ CD8 T cells are higher at day 60 than at day 14 in PSLN-344 animals (9.9% vs 6.4%) while survival is lower. Whatever wanes was not measured. Second, the "Tfh:Tfr ratio" in S04-B is an arithmetic transform of the Tfr percentage, (100 − x)/x, not an independent measurement.

To qualify the lead candidate: measure it in blood in the same animals that are then challenged (N1, N3), show that removing CD8 T cells removes protection (N2), and show the assay reads out in human cells (N6).

### 5.3 What the next studies have to establish

Designs are proposals. Sample sizes use exact power for a two-sided Fisher test at α = 0.05 and the survival rates observed here (ledger §4e).

| Study | Gate | Starts | Duration |
|---|---|---|---|
| N0 Source reconciliation | G0 | now | 2–4 weeks |
| N1 Confirmatory efficacy with the missing controls | G1 | month 1 | ~5 months |
| N2 Mechanism of protection | G1, biomarker | month 1 | 3–4 months |
| N3 Dose, regimen, durability | G2, G3 | month 1 | ~9 months |
| N4 Safety and distribution | G2 | pilot month 2; GLP after G1 | 3 months; then 6–9 months |
| N5 Second species (ferret) | G4 | after G1 | 6–9 months |
| N6 Human-cell bridging | G4 | month 1 | 3–4 months |
| N7 Product | G2, G4 | month 1 | 6 months |

**N0. Source reconciliation**

- *Must establish:* which group labels and survivor counts are correct for Q1–Q6; whether S06-C and S06-D are one experiment or two; what the 13 unlabelled rows are.
- *Population:* none; records only.
- *Comparators:* workbook against primary records (cage cards, necropsy logs, cytometer exports, plate-reader files).
- *Endpoints:* each QC item closed as "workbook correct", "workbook corrected" or "cannot be resolved".
- *Readouts:* a locked, versioned dataset and a re-run of this analysis.
- *Timing:* 2–4 weeks, before the committee meets.

**N1. Confirmatory efficacy with the missing controls**

- *Must establish:* the effect repeats under blinding and randomisation in both sexes; Mn has to be co-formulated with the agonist; PSLN-344 is at least as good as a licensed-type regimen; it works with a licensed split antigen; it lowers virus load and lung damage, not only mortality.
- *Population:* mice aged 18–20 months, both sexes, BALB/c and C57BL/6. Young benchmark arm. n = 12 per arm for survival (95% power for 85% vs 14%) and 5 per arm per time point for virology. 20 unchallenged age-matched sentinels per cohort.
- *Comparators:* vaccine + empty liposome; PSLN-212; Mn-only liposome; PSLN-212 admixed with free Mn²⁺; PSLN-344 without antigen; an intramuscular high-dose split vaccine and an MF59-type adjuvanted vaccine as stand-ins for current care; unvaccinated. Antigen: the in-house whole virus and a licensed split vaccine.
- *Endpoints:* primary, survival to day 14 after heterosubtypic challenge. Against the active comparators, where survival would need more than 30 animals per arm, the primary endpoint is lung virus titre on days 3 and 6. Secondary: weight-loss area under the curve, clinical score, lung histopathology score.
- *Readouts:* serum HAI and neutralisation and the blood CD8 response on the day before challenge, in the animals that are then challenged. This is what allows an animal-level correlate analysis. Lung virus titre and histology in satellite animals.
- *Timing:* vaccinate day 0; challenge cohorts at days 3, 14 and 60; satellites on days 3 and 6 after challenge; observe 14 days. About 5 months.

**N2. Mechanism of protection**

- *Must establish:* which effector (CD8 T cells, CD4 T cells, antibody) and which upstream step (CCR2 monocytes, GM-CSF, type I interferon) is necessary for survival; whether GM-CSF can replace Mn.
- *Population:* mice aged 18–20 months given vaccine + PSLN-344. n = 16 per arm (84% power for 85% vs 30%).
- *Comparators:* around challenge: anti-CD8, anti-CD4, both, isotype control; FTY720 to keep circulating cells out of the lung; serum from immunised or naïve aged donors transferred to naïve aged recipients. Around vaccination: CCR2 antagonist, anti-GM-CSF, anti-IFNAR1, each against vehicle or isotype. Sufficiency: PSLN-212 + recombinant GM-CSF against PSLN-344 and PSLN-212.
- *Endpoints:* primary, survival to day 14 after challenge. Secondary, lung virus titre on days 4 and 6.
- *Readouts:* confirmation of depletion or blockade by flow cytometry; lung CD8 T-cell number and phenotype; serum titres in transfer recipients.
- *Timing:* challenge at day 3 and day 14 after vaccination; 3–4 months, alongside N1.

**N3. Dose, regimen and durability**

- *Must establish:* the lowest fully protective dose and its margin to intolerance; whether a second dose closes the day-60 gap; how long protection lasts; what wanes when it does.
- *Population:* mice aged 16–18 months at first dose, so that a day-180 challenge falls before 24 months; both sexes; n = 15 per arm per challenge time; 20 unchallenged sentinels per time point to measure background mortality.
- *Comparators:* PSLN-344 at 2, 5, 10, 20 and 40 µg, one dose; 20 µg, two doses (days 0 and 21); PSLN-212 at 20 µg; vaccine + empty liposome; young benchmark.
- *Endpoints:* primary, survival after challenge 60, 120 and 180 days after the last dose. Secondary, the dose giving ≥80% of maximal protection and the highest dose with ≤5% transient weight loss.
- *Readouts:* serial HAI, neutralisation and blood CD8 response at days 14, 28, 60, 120 and 180 in the same animals. At each challenge day, in satellites: lung resident-memory CD8 T cells, lymph-node Tfr and IFN-γ⁺ CD8 T cells. By dose: weight on days 0–10, lung cytokines at 16 h, 72 h and day 7, airway-lavage cell differential.
- *Timing:* about 9 months.

**N4. Safety and distribution**

- *Must establish:* where Mn and the agonist go and how long they stay; whether lung inflammation resolves; whether repeat dosing is tolerated; the exposure margin.
- *Population:* pilot, aged and young mice of both sexes, n = 5 per group per time point. GLP, rat and one non-rodent species in which the agonist is shown to be active.
- *Comparators:* vehicle; empty liposome; PSLN-212; a Mn salt at the equivalent Mn dose; PSLN-344 at 1×, 3× and 10× the active dose. Cholera toxin as a positive control for CNS inflammation in the pilot. One dose, and three doses two weeks apart with a 4-week recovery group.
- *Endpoints:* Mn content of olfactory bulb and brain relative to vehicle; incidence and grade of nasal, lung and CNS histopathology; no-adverse-effect level.
- *Readouts:* Mn by ICP-MS in nasal tissue, olfactory bulb, brain regions, lung, liver, kidney and blood; agonist in plasma and lung; serum IFN-β, IL-6, TNF and CXCL10; airway-lavage cell differential, protein and LDH (replacing the unusable neutrophil block S11-B); clinical pathology; a behavioural screen.
- *Timing:* sampling at 1 h, 6 h, 24 h, 72 h, day 7 and day 28 after the last dose. Pilot 3 months from month 2. GLP 6–9 months, only after G1.

**N5. Second species**

- *Must establish:* protection in the accepted influenza model, by a route a person could receive, against a licensed comparator.
- *Population:* ferrets of both sexes, influenza-naïve, plus one cohort primed by prior infection; older animals if obtainable. n = 6–8 per arm.
- *Comparators:* licensed seasonal vaccine intramuscular, including a high-dose or adjuvanted product; licensed antigen + PSLN-344 by nasal spray and by aerosol; antigen alone by the same routes; placebo.
- *Endpoints:* primary, virus shedding in nasal washes (area under the curve, days 1–7) after matched and mismatched challenge. Secondary: fever, weight, activity score, lung virus titre and pathology on day 4.
- *Readouts:* HAI and neutralisation at days 0, 14, 28 and before challenge; nasal IgA; blood IFN-γ ELISpot; lung T cells at necropsy.
- *Timing:* challenge at day 28 and at day 90–120; 6–9 months; starts after G1.

**N6. Human-cell bridging**

- *Must establish:* PSLN-344 triggers the same Mn-dependent interferon and GM-CSF response in human cells, including cells from older donors and across common STING variants.
- *Population:* blood monocytes, alveolar macrophages or lung slices, and differentiated airway epithelial cultures. Donors ≥65 years against 18–40 years, at least 10 per group.
- *Comparators:* PSLN-344, PSLN-212, CMP-204, empty liposome, Mn salt, each as a dose series.
- *Endpoints:* induction of IFN-β and GM-CSF by PSLN-344 relative to PSLN-212 in older-donor cells; potency (EC50).
- *Readouts:* IFN-β, CXCL10, GM-CSF, IL-6 and TNF protein; interferon-stimulated-gene score; monocyte-to-dendritic-cell conversion and co-stimulatory markers; viability.
- *Timing:* read at 6, 24 and 72 h; 3–4 months from month 1.

**N7. Product**

- *Must establish:* the particle can be made reproducibly, is stable, and survives mixing with antigen and passage through a delivery device.
- *Population:* at least three batches at increasing scale.
- *Comparators:* each batch against a written specification and against the research batches used here.
- *Endpoints:* batches within specification; a shelf-life estimate; potency retained after delivery.
- *Readouts:* particle size and distribution, surface charge, Mn:agonist ratio, free Mn, encapsulation efficiency (54.8% now [S08-B]), endotoxin, sterility; a cell-based potency assay; antigen potency after mixing; integrity after spray or aerosolisation.
- *Timing:* stability at 1, 3 and 6 months, lyophilised and reconstituted; 6 months from month 1.

If the gates are passed, the first clinical study would carry the biomarker panel directly (proposal). Dose escalation in adults 18–49, then ≥65, against a licensed high-dose or adjuvanted vaccine. Safety to include neurological events, smell testing, lung function and blood Mn. HAI and neutralisation at days 0, 28 and 180. T-cell ELISpot at days 0, 7, 14, 28 and 180. Blood interferon-gene score at days 1 and 3.

### 5.4 If the committee drops it

What would be dropped: the only formulation in this package that protects aged animals (85% vs 14% for its parent and 2% for vaccine alone); protection against wild-type H5N1 two days after a single dose (10/10 [S03-J]), which has outbreak-response value separate from the seasonal indication; and a mapped mechanism.

Legitimate reasons to drop: no evidence yet of advantage over current older-adult vaccines; an untested safety profile for nasal Mn; waning by day 60; a delivery route that may not translate.

What to keep regardless: the finding that a STING-agonist adjuvant fails from middle age, apparently for want of interferon and GM-CSF, and that this is correctable; the early innate panel as a screen for any adjuvant aimed at older adults; and the aged-mouse challenge platform.

---

## 6. What I considered and ruled out

**Alternative recommendations**

- *Advance without conditions.* Ruled out: no active comparator, no Mn-only control, one dose level, a three-dataset safety package, and unreconciled source data.
- *Drop.* Ruled out: the effect in the target-population model is large, repeated and attributable to a single formulation change, and nothing in the data is a safety stop.
- *Advance PSLN-212 instead, as the simpler product.* Ruled out for this indication: 9/66 in aged mice, and 0/14 already at 14 months. It is sufficient only in young animals.
- *Add R848 rather than Mn.* Ruled out: the R848 combination loses weight progressively (90.7% at day 10) and keeps *Tnf*, *Il6* and *Il10* at 34–50× at 72 h [S08-D, S09-A]. It has no efficacy data.
- *Switch to the cGAMP particle CMP-204.* Ruled out: it protects young mice (7/7 [S13-E]) but gives the weakest response in aged mice (*Ifnb1* 7.8; IgG GMT 181; HAI GMT 23) and at best 3/7 survival [S01-A, S03-A, S03-C, S03-I].
- *Give two doses of PSLN-212 instead of adding Mn.* Not supported: after a day-14 boost, PSLN-212 reaches IgG GMT 4,411 (CA09) and 1,086 (Aichi), against 7,305 and 5,701 for a single dose of PSLN-344 [S13-I, S13-J, S03-A, S03-E]. No boosted animals were challenged.
- *Keep the Mn-free particle and add recombinant GM-CSF instead.* Not ruled out, but not supported: GM-CSF raises monocyte-derived dendritic cells with PSLN-212 (5.9% → 13.8%) after four daily intranasal doses [S02-G], and there is no antibody, T-cell or survival data for the combination. N2 tests it as a mechanism question.

**Alternative explanations of the protection**

- *A non-specific antiviral state.* Ruled out by S15-H (adjuvant alone 0/7) and by protection at days 14 and 60.
- *Antibody alone.* Unlikely: it does not readily explain protection at day 2–3 or against viruses with no shared HA or NA, and HAI ≥ 40 did not protect the PSLN-212 group. Not formally excluded; no early serology or serum transfer was done.
- *Simply a higher agonist dose.* Ruled out by the PSLN-212 plateau in S08-A.
- *A strain artefact.* Argued against by C57BL/6 and Swiss Webster, with the Q6 caveat.
- *Pre-existing immunity doing the work.* Ruled out: never-infected and previously infected mice do equally well with PSLN-344.

**Analytical choices**

- *Taking printed labels at face value.* Rejected where a cross-check failed: S03-B/F recomputed; the second S09-A panel read as 72 h; S07-A, S07-C, S08-C and S11-B set aside.
- *Using post-challenge body weight as a co-primary endpoint.* Rejected: carried-forward values and series repeated across experiments (Q5, Q6).
- *Arithmetic means for titres.* Rejected in favour of geometric means; HAI values printed as 0 set to 5.
- *Using the tetramer time courses S05-A/B as the T-cell evidence.* Rejected: two animals per point and inconsistent conditions. Used S05-D to S05-I and S14-A.
- *Pooling the extra-strain and imprinting experiments into the headline.* Rejected: different ages, unannotated challenge, shared weight traces. Reported separately.
- *Ranking biomarkers by correlation with survival.* Not possible at animal level. Stated as a limit rather than forced.
- *The 13 unlabelled rows at S08!A89:D101.* Excluded; no measurand or groups are recorded.
- *Treating the deaths of untreated animals as noise.* Rejected: they are central to reading day 60.

---

## 7. How the numbers were reduced

- **Survival.** Survivors = rows with flag 0 ÷ rows in the group; exact binomial 95% CI. Log-rank test on the rows (the method named in the annotation); Fisher's exact test on final survival as a check. Pooled results are sums across the named blocks, tested with a log-rank stratified by experiment.
- **Replicate blocks.** Mean ± SD of the per-animal values, n as found. One-way ANOVA with Tukey's test as named in the annotation; Welch t-test and exact Mann–Whitney as checks. With n = 5, complete separation gives Mann–Whitney p = 0.008.
- **Titres.** Geometric mean with 95% CI on log₁₀ values.
- **S09-A.** Stored as log₁₀; mean back-transformed to geometric-mean fold.
- **Body weight.** Per-animal lowest genuine value; a trailing run of identical values is treated as a carried-forward last weight.
- **Restoration index.** (aged PSLN-344 − aged PSLN-212) ÷ (young PSLN-212 − aged PSLN-212), on means; log scale for titres; bootstrap CI.
- **Multiplicity and precision.** p values are descriptive. The nine primary comparisons survive Bonferroni correction; no other correction was applied. The very small pooled p values are asymptotic and should be read as "far below any threshold", not as exact probabilities.

Files: `PSLN-344_numbers_ledger.md` (every number with cells, plus the full QC log), `figures/` (Figs 1–5; Fig 2 shows every Kaplan–Meier curve), `analysis/` (parser, tidy extracts with cell addresses, statistics, QC scripts).

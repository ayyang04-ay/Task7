---
title: "PSLN-344: recommendation for portfolio review"
subtitle: "Manganese-complexed, surfactant-biomimetic liposomal STING agonist as an intranasal influenza-vaccine adjuvant for older adults"
---

**Basis.** Everything in `adjuvant_program_dataset.xlsx` (15 sheets; 107 data blocks and panels, of which 18 are time-to-event; 5,593 measurements and 514 animal-level survival records) read against `adjuvant_program_annotation.pdf`. Every number below was recomputed from the per-animal values. Block names (S06-A …) are the workbook's own. Bracketed tags such as [E1] point to the number ledger (`PSLN-344_evidence_tables.xlsx`, sheet *number_ledger*), which gives the workbook cells and the reduction for each number; the reduction rules are in §2.

# 1. Recommendation

**Advance PSLN-344, conditionally, one gate at a time.** Keep the asset. First, a four-week Gate 0 with no animals: reconcile the record against source. Then, if the survival experiments are substantiated, a Gate 1 of about five months: (1) one blinded confirmatory study in aged mice of both sexes that also settles attribution (manganese alone versus manganese plus agonist) and dose; (2) a study of what mediates protection; (3) a pilot safety study on lung resolution and manganese in the brain. Hold IND-enabling spend (GLP toxicology, scale-up) until Gate 1 reads out. Aged animals take 6–8 weeks to source and can be ordered now.

## The case for advancing

1. **A large effect on a hard endpoint in the right host.** One intranasal dose of vaccine plus PSLN-344 kept 66 of 79 aged mice alive through lethal influenza challenge (84%; 95% CI 74–91), against 1 of 80 (1%) given the same vaccine with empty liposome or alone. That is +82 percentage points (95% CI 74–91), and PSLN-344 won in every one of the 11 experiments (a twelfth block duplicates another and is not counted) [E1, E18].
2. **The manganese is what rescues the aged host.** Against PSLN-212 (same liposome, same STING agonist, no manganese) survival was 84/100 versus 13/101, +71 points (62–81) [E5]. PSLN-212 protects young mice (62/63) but barely protects aged ones (9/73) [E9, E8].
3. **Breadth and speed.** Protection held across subtypes (H3N2 vaccine against H1N1 challenge; H1N1+H3N2 vaccine against H5N1), against wild-type H5N1 (9/9 versus 1/10), when challenge came only 2–3 days after dosing (20/23), in two further mouse strains (12/14 versus 0/14; the provenance of these two blocks needs checking, register A9) and in animals with a prior influenza infection (6/7 versus 0/7) [E13, E10a, E15, E16b].
4. **A coherent pharmacodynamic chain that is tied to the manganese.** In aged lung PSLN-344 brings the early interferon-β response back to the young-adult level (2.2-fold over PSLN-212; 0.98 of young), raises Gm-csf four- to five-fold, roughly doubles monocyte and monocyte-derived dendritic-cell recruitment, and closes most of the age gap in antibody and CD8 T-cell read-outs (restoration index 0.6–0.9 for most; Figure 3) [M1a, M1b, M4a–b, M5, M6, R1].
5. **Tolerability so far unremarkable, and better than the obvious alternative.** Weight fell 3.6% after dosing versus 1.8% with vaccine alone and had recovered by day 10; the TLR7/8-agonist combination the programme also tried fell 10% and had not recovered [S1a, S1b].

## Why only conditionally

1. **The record must be reconciled before any single block is quoted.** I logged 15 findings that touch efficacy blocks, including two experiments with identical death records, body-weight traces that recur across experiments shifted by whole numbers, and survival blocks whose arms are named differently in their own weight blocks (§9). The conclusion survives every sensitivity analysis (worst case 65/79 versus 1/80) [E3], but individual numbers may move.
2. **Protection fades, and illness is not prevented.** Survival was 40/44 (91%) when challenge came within two weeks of the dose and 14/21 (67%) at 60 days (p = 0.03), against 21/21 for the young benchmark at 60 days [E10g, E10e]. Protected animals still lost 13% of body weight at nadir [E20].
3. **What mediates protection is inferred, not shown.** The data point to antigen-specific cellular immunity, but no experiment removes or transfers a candidate mediator, and no read-out is linked to outcome in individual animals (§4, §5).
4. **The package is narrow.** One dose level for efficacy, one in-house whole-virus antigen, female mice only, no licensed-vaccine comparator, no manganese-only control, and the manganese dose is not recorded anywhere.
5. **Safety evidence is thin for a manganese product delivered to the airways of older adults.** Lung Tnf and Il6 were still 8-fold and 7-fold above baseline at 72 hours in aged animals [S2b]; the CNS evidence is three transcripts at one time point; there is no histopathology and no manganese biodistribution; the neutrophil block cannot be used (§6).

**How sure am I?** Efficacy in aged mice: high on the record as it stands, subject to Gate 0. That manganese in the formulation is what rescues the aged host: high. That CD8 T cells mediate the protection: low to moderate, untested. Durability beyond two months: unknown. Safety: insufficient data to judge.

## Your four questions, in one line each

| Question | Answer | Where |
|---|---|---|
| Do we advance? | Yes, to a gated confirmation stage; not yet to IND-enabling work. | §1, §7 |
| What is actually driving the protection? | An antigen-specific response (adjuvant without antigen protects 0/7) that is fast and crosses subtypes, so most plausibly lung CD8 T cells rather than the antibody that the haemagglutination-inhibition (HAI) assay measures. The manganese acts upstream, restoring the interferon-β → GM-CSF → monocyte-derived dendritic-cell step that fails in aged lung. The mediator itself is unproven. | §4 |
| Is there a biomarker of efficacy, and can it go into patients? | None is validated: every read-out separates the arms, so the data cannot tell driver from passenger. Three are worth carrying, in three roles: the early mucosal interferon/CCL2/GM-CSF response (pharmacodynamic and dose-finding), serum HAI/neutralising titre (immunogenicity endpoint for strain-matched claims), and a cross-reactive CD8 T-cell assay (exploratory; candidate correlate for breadth). All can be sampled in people (nose, serum, blood cells). None should be a surrogate endpoint or a patient-selection test. | §5 |
| What must the next studies establish? | Gate 0 record reconciliation, then six studies: confirmation/attribution/dose; mediator of protection; pilot safety; durability and boost; benchmark against licensed regimens; ferret and delivery. Endpoints, populations, comparators, read-outs and timing for each are in §7. | §7 |

## If the committee prefers to stop

What would be dropped is the only formulation in this package that restores vaccine protection in an aged host: +82 points of survival over vaccine alone and +71 over its manganese-free parent, effective within 2–3 days and across subtypes including wild-type H5N1. The defensible reasons to stop are not about efficacy in the model. They are the two-month fade (67%; 95% CI 43–85), the absence of a comparison with any regimen that works in older adults, the cost of qualifying a manganese product delivered to the airways of people over 65, and the state of the record.

## What would change this recommendation

- **Stop** if source records cannot substantiate at least 9 of the 11 survival experiments, or if the confirmatory study (Study 1) shows less than a 20-point lower confidence bound for PSLN-344 over PSLN-212, or if lung inflammation or brain manganese has not resolved by day 14–28 at the efficacious dose (Study 3).
- **Redefine the product** if manganese-only liposome reproduces at least half of the effect (the agonist is then not doing the work), or if manganese simply admixed with PSLN-212 matches PSLN-344 (the coordination chemistry is then unnecessary).
- **Narrow the indication** to outbreak or pandemic response if neither one nor two doses hold at least 70% survival at four months (Study 4).

# 2. How every number was produced

| Rule | Data | Reduction | Test |
|---|---|---|---|
| R1 | Time-to-event blocks | Survivors = animals whose indicator is 0 at the end of the window (14 days; 21 in S03-J). n = animals with an indicator and a recorded day. Exact binomial 95% CI. | Log-rank (the programme's stated test) with exact permutation p; Fisher's exact test on end-of-window survival. |
| R2 | Pooling across experiments | Within-experiment 2×2 tables combined as a Mantel–Haenszel risk difference. S06-D is excluded because it duplicates S06-C. | Exact conditional test stratified by experiment. |
| R3 | Antibody titres and qPCR fold-changes | Geometric mean (GM). Ratio of GMs with Welch 95% CI on log10. HAI recorded as 0 (negative at 1:10) set to 5. | One-way ANOVA with Tukey on log10 (stated test); Welch t as a check. |
| R4 | Flow-cytometry percentages and counts | Arithmetic mean ± SD. Difference of means with Welch 95% CI. | One-way ANOVA with Tukey (stated test); Welch t and exact Mann–Whitney as checks; two-way ANOVA for time courses. |
| R5 | S09-A cytokines | Stored as log10: mean of the logs, back-transformed. Second panel treated as 72 hours (register B3). | As R3. |
| R6 | Body weight | Percent of own day-0 weight. A value repeated unchanged to day 14 after an animal's last real weight is treated as carried forward and excluded. Per-animal nadir. | Welch t on nadirs. |
| R7 | Restoration index | (PSLN-344 − PSLN-212) ÷ (young PSLN-212 − PSLN-212) on the analysis scale; 0 = no better than the parent in aged mice, 1 = young benchmark. | Bootstrap 95% CI, 10,000 resamples. |
| R8 | Derived blocks | Recomputed from raw values where raw exists (IgG2a:IgG1 from S13-A to S13-D). | — |

Conventions. Arms without "(Y)" are aged (20 months or older; 14 months in the imprinting study). "Sham" is vaccine plus empty liposome. "Young benchmark" is PSLN-212(Y), the comparator the programme itself used. All animals are female. The workbook uses the labels S06-E and S06-F twice: here (1) means rows 34–68 (day-60 challenge) and (2) means rows 71–105 (imprinting study). No multiplicity adjustment is made across blocks; within a block Tukey handles it. The survival conclusion does not depend on that choice, since each of the 11 experiments is significant on its own (exact log-rank p from 0.0001 to 0.003) [E18]. Single immune contrasts with p above 0.01 should be read as suggestive.

Abbreviations. HAI, haemagglutination inhibition; GM and GMT, geometric mean and geometric mean titre; DC, dendritic cell; moDC, monocyte-derived DC; Tfh and Tfr, follicular helper and follicular regulatory T cells; GZMB, granzyme B; OT-I, ovalbumin-specific CD8 T cells used as a reporter; SRB, sulforhodamine B (a tracer dye); rgH5N1, reverse-genetics H5N1 on a PR8 backbone; mLD50, mouse median lethal dose; node, mediastinal lymph node.

# 3. Does it work? Survival after lethal challenge

## 3.1 Every aged-animal experiment

Survivors / n at the end of observation (rule R1). p-values are exact log-rank.

| Block | Vaccine → challenge (5× mLD50 unless stated) | Dose-to-challenge interval | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | p, 344 vs Sham | p, 344 vs 212 | Note |
|---|---|---|---|---|---|---|---|---|---|
| S03-J | rgH5N1 vaccine → wild-type H5N1 (21-day follow-up) | 2 d | 1/10 | 3/10 | **9/9** | – | 0.0001 | 0.003 | a |
| S06-B | H3N2 vaccine → PR8 H1N1 | 3 d | 0/7 | 0/7 | **5/7** | 7/7 | 0.0006 | 0.002 | |
| S15-H | bivalent → rgH5N1 | 3 d | 0/7 (vaccine alone) | – | **6/7** | – | 0.0006 | – | b |
| S06-D | bivalent → rgH5N1 | 3 d | 0/7 | 2/7 | **7/7** | 7/7 | 0.0006 | 0.021 | c |
| S03-I | bivalent → CA09 H1N1 (homologous, 10× mLD50) | 14 d | 0/7 | 0/7 | **7/7** | 7/7 | 0.0006 | 0.0006 | a |
| S06-A | H3N2 vaccine → PR8 H1N1 | 14 d | 0/7 | 1/7 | **6/7** | 7/7 | 0.0006 | 0.017 | |
| S06-C | bivalent → rgH5N1 | 14 d | 0/7 | 2/7 | **7/7** | 7/7 | 0.0006 | 0.021 | c |
| S06-E(1) | H3N2 vaccine → PR8 H1N1 | 60 d | 0/7 | 0/7 | **5/7** | 7/7 | 0.0006 | 0.003 | d |
| S06-F(1) | bivalent → rgH5N1 | 60 d | 0/7 | 1/7 | **5/7** | 7/7 | 0.0006 | 0.012 | d |
| S06-G | H1N1 vaccine → Perth H3N2 | 60 d | 0/7 | 0/7 | **4/7** | 7/7 | 0.0006 | 0.020 | d |
| S15-L | aged C57BL/6, bivalent → not stated | not stated | 0/7 | 0/7 | **6/7** | 6/7 | 0.002 | 0.003 | e |
| S15-N | aged Swiss Webster, bivalent → not stated | not stated | 0/7 | 2/7 | **6/7** | 7/7 | 0.003 | 0.086 | e |

Notes. **a** Two comparator arms are named differently in the paired weight block (register A4, A5); PSLN-344 and the worst arm agree in both. S03-J PSLN-344 has 10 indicator cells but 9 recorded times; n = 9 is used. **b** PSLN-344 without antigen: 0/7. **c** S06-D is cell-for-cell identical to S06-C, and its own weight block implies 5/7 rather than 7/7 for PSLN-344 (register A1, A2); it is excluded from pooled estimates. **d** These experiments carry an "Untreated" arm that was never challenged; 6/7, 7/7 and 4/7 of those animals survived the window (register A8). **e** Challenge virus and day are not given in the annotation; some weight traces are shared with a BALB/c experiment (register A9).

Imprinting study (BALB/c, 14 months; infected with PR8 or given saline at 10 months; bivalent vaccine):

| Block | Challenge | Naive + PSLN-212 | Imprinted + PSLN-212 | Naive + **PSLN-344** | Imprinted + **PSLN-344** |
|---|---|---|---|---|---|
| S06-E(2) | PR8 H1N1 (day not stated) | 0/7 | 4/7 | **6/7** | **6/7** |
| S06-F(2) | Perth H3N2, 14 d | 0/7 | 0/7 | **6/7** | **6/7** |

Young mice, for contrast:

| Block | Vaccine → challenge | Interval | Sham | PSLN-212(Y) | PSLN-344(Y) | Other |
|---|---|---|---|---|---|---|
| S09-B | H3N2 vaccine → PR8 H1N1 | 21 d | 0/8 | 8/8 | 8/8 | – |
| S09-D | H1N1 vaccine → Perth H3N2 | 21 d | 0/8 | 8/8 | 8/8 | – |
| S09-F | bivalent → rgH5N1 | 180 d | 0/7 | 8/8 | 8/8 | – |
| S13-E | bivalent → CA09 H1N1 (10× mLD50) | 14 d | 1/7 | – | 7/7 | Naive 0/7; CMP-204(Y) 7/7 |

![Figure 1. Kaplan–Meier curves for every aged-animal time-to-event block.](figures/fig1_survival_KM_all_aged_experiments.png)

## 3.2 Pooled estimates and how far the record problems can move them

Rule R2. Percentages are followed by exact 95% CIs.

| Comparison | PSLN-344 (or first arm) | Comparator | Difference, points (95% CI) | p |
|---|---|---|---|---|
| *Versus Sham or vaccine alone* | | | | |
| **Primary: 11 experiments** (S06-D dropped as a duplicate) [E1] | 66/79 (84%; 74–91) | 1/80 (1%; 0–7) | +82 (74 to 91) | <10⁻²⁰ |
| All blocks as printed, S06-D counted [E2] | 73/86 (85%; 76–92) | 1/87 (1%; 0–6) | +84 (76 to 92) | <10⁻²⁰ |
| S06-D kept, with the 5/7 read from its weight block [table T3] | 71/86 (83%; 73–90) | 1/87 (1%; 0–6) | +82 (73 to 90) | <10⁻²⁰ |
| Worst case for PSLN-344 from the paired weight blocks [E3] | 65/79 (82%; 72–90) | 1/80 (1%; 0–7) | +81 (73 to 90) | <10⁻²⁰ |
| BALB/c only [E4] | 54/65 (83%; 72–91) | 1/66 (2%; 0–8) | +82 (72 to 91) | <10⁻²⁰ |
| *Versus PSLN-212, the manganese-free parent, same age* | | | | |
| **Primary: 14 strata** (10 experiments + 4 imprinting strata) [E5] | 84/100 (84%; 75–91) | 13/101 (13%; 7–21) | +71 (62 to 81) | <10⁻²⁰ |
| Worst case for PSLN-344, best case for PSLN-212 [E6] | 83/100 (83%; 74–90) | 19/101 (19%; 12–28) | +64 (54 to 74) | <10⁻²⁰ |
| 20-month BALB/c experiments with no label conflict (6) [E7] | 32/42 (76%; 61–88) | 4/42 (10%; 3–23) | +67 (52 to 82) | 3×10⁻¹⁰ |
| *Benchmarks* | | | | |
| Aged PSLN-344 versus **young** PSLN-212 (9 experiments) [E9] | 51/63 (81%; 69–90) | 62/63 (98%; 91–100) | −17 (−28 to −7) | 0.002 |
| Aged PSLN-212 versus Sham (10 experiments) [E8] | 9/73 (12%; 6–22) | 1/73 (1%; 0–7) | +11 (3 to 19) | 0.015 |

Dropping any single experiment leaves the difference from Sham between 81 and 85 points, and from PSLN-212 between 69 and 75 (tables T3b, T3c). Expressed as a hazard ratio for death (Cox model stratified by experiment), PSLN-344 stands at 0.010 (95% CI 0.002–0.041) against Sham and 0.077 (0.044–0.135) against PSLN-212; mean survival within the 14-day window is 13.2 versus 6.1 days and 13.1 versus 8.0 days [E1b, E5b].

![Figure 2. Survival difference by experiment and pooled.](figures/fig2_survival_forest.png)

## 3.3 What to take from the survival data

- **The effect is consistent.** There is no experiment in which PSLN-344 failed to separate from vaccine alone, and the record problems cannot erase it: they move the pooled estimate by less than two points.
- **The parent is the right comparator, and it fails in aged animals.** PSLN-212 delays death (mean day of death 7.2 versus 5.7 for Sham) but rarely prevents it [E19, E8].
- **"Restores youthful protection" overstates it.** Aged animals on PSLN-344 reach 81% against 98% for the young benchmark, a deficit of 17 points (7–28) [E9].
- **It adds nothing in young animals.** Young mice were fully protected by either formulation (24/24 versus 24/24) [E17]. The differences I can find are small: a 1.34-fold higher Ifnb1 (1.11–1.62) [M1d] and, at 180 days, slower weight recovery with PSLN-344 (95.6% versus 99.2% of starting weight on day 14; difference −3.6, −5.9 to −1.4) [E21]. The differentiation is specific to the aged host.
- **Prior infection does not blunt it.** In PR8-imprinted animals challenged with H3N2, PSLN-344 protected 6/7 and PSLN-212 0/7 (p = 0.005) [E16b]. This is one imprinting virus in 14-month-old animals.

## 3.4 Where the protection is weaker: durability and morbidity

| Interval between dose and challenge | Sham / vaccine alone | PSLN-212 | **PSLN-344** | Young PSLN-212 | Untreated, unchallenged |
|---|---|---|---|---|---|
| 2–3 days (S03-J, S06-B, S15-H) [E10a] | 1/24 | 3/17 | **20/23 (87%; 66–97)** | 7/7 | – |
| 14 days (S03-I, S06-A, S06-C*) [E10b] | 0/21 | 3/21 | **20/21 (95%; 76–100)** | 21/21 | – |
| 60 days (S06-E(1), S06-F(1), S06-G) [E10c] | 0/21 | 1/21 | **14/21 (67%; 43–85)** | 21/21 | 17/21 |

\* S06-C and S06-D (day 3) carry one identical record; it is counted once and assigned here to day 14. Comparator counts: [E10i].

- Challenged within two weeks of the dose, 40 of 44 PSLN-344 animals survived (91%; 78–97); at 60 days, 14 of 21 (67%; 43–85), p = 0.03 (Fisher) [E10g]. At 60 days PSLN-344 is also below the young benchmark (p = 0.009) [E10e]. The narrower day-14 versus day-60 contrast gives p = 0.045 as tabulated, but p = 0.11 if the record shared by S06-C and S06-D belongs to the day-3 experiment instead (the table would then read 27/30 and 13/14) [E10h].
- Four of 21 unchallenged, unvaccinated animals of the same age died during the same 14-day window (19%; 95% CI 5–42) [E11]. Background mortality at 22 months is therefore material, and PSLN-344 at 60 days cannot be distinguished statistically from unchallenged animals (14/21 versus 17/21, p = 0.48). I read the fade as more likely real than an artefact of old age: on the weight traces as recorded, the PSLN-344 animals that died had first lost 15–22% of their weight, whereas the unchallenged animals that died were at 94–97% (Figure 7C). That reading rests on weight blocks, the least reliable part of the record.
- Protection is from death, not from illness (provisional, because the weight blocks carry most of the record problems: register A3, A7, A9, A15). Across ten challenge experiments the mean weight nadir was 87.1% with PSLN-344, 90.3% for the young benchmark, 82.2% for PSLN-212 and 84.5% for Sham (the last two truncated by death) [E20]. PSLN-344 was below the young benchmark in 10 of 10 experiments (mean −3.1 points) and above PSLN-212 in 10 of 10 (mean +5.0) [E20b, E20c].
- The package contains no lung viral titres, so "protection" here means survival and weight only.

![Figure 7. Protection by dose-to-challenge interval, weight nadir, and the day-60 weight traces.](figures/fig7_durability_morbidity.png)

# 4. What is actually driving the protection?

**Short answer.** Protection needs antigen and adjuvant together, so it is an antigen-specific response and not the STING agonist's own antiviral effect. Its speed (2–3 days) and its reach across subtypes that share neither haemagglutinin nor neuraminidase point to cellular immunity, most plausibly lung CD8 T cells, rather than to the strain-specific antibody that HAI measures. The manganese acts upstream: it lifts the blunted interferon-β and GM-CSF response of the aged lung to the level at which recruited monocytes become antigen-presenting dendritic cells. The first statement rests on a direct experiment. "CD8 T cells" is an inference that nothing in the package tests.

## 4.1 What the manganese changes (formulation level)

- **Ceiling, not potency.** In the only dose-ranging experiment (S08-A; age not stated, read as aged because its 20 µg values match the aged arms of S01-A), the fitted maximum Ifnb1 induction was 59-fold (95% CI 49–69) for PSLN-344 against 17-fold (14–20) for PSLN-212, with similar half-maximal doses (13 and 11 µg) [M2]. PSLN-212 at 40 µg reached a lower response than PSLN-344 at 10 µg (ratio 0.70; 0.48–1.02) [M2b]. Raising the dose of the parent does not substitute for manganese, at least for this read-out.
- **Not more payload.** Encapsulation efficiency was 54.8% for PSLN-344 and 59.6% for PSLN-212 (difference −4.8; −15.8 to 6.2; n = 3 preparations) [M3].
- **20 µg is near the plateau.** Doubling PSLN-344 to 40 µg raised Ifnb1 by a factor of 1.09 (0.74–1.60) [M2a]. All efficacy work used 20 µg; there is no dose-ranging for protection or for any adaptive read-out.
- **Unknown: is it the manganese alone?** There is no manganese-only liposome and no arm with manganese simply mixed with PSLN-212. The data attribute the benefit to "manganese present in the formulation", not to the coordination complex and not to synergy with the agonist.

## 4.2 The immunological chain in aged animals

Rules R3, R4, R7. All n = 5 per group unless noted; "effect" is PSLN-344 against PSLN-212 in aged mice.

| Read-out | Block | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | Effect (95% CI) | Tukey p | Restoration index (95% CI) |
|---|---|---|---|---|---|---|---|---|
| *Innate response and recruitment* | | | | | | | | |
| Ifnb1, lung, 16 h, fold (GM) | S01-A | 0.94 | 16.5 | **36.9** | 37.5 | ×2.2 (1.8–2.7) | 0.0006 | 0.98 (0.84–1.13) |
| Gm-csf, lung, 36 h, fold (GM) | S02-F | 1.2 | 1.6 | **8.5** | not run | ×5.4 (3.9–7.3) | <0.0001 | – |
| Lung monocytes, day 4, % | S01-D | 10.4 | 16.7 | **30.6** | 32.2 | +13.8 (8.1 to 19.5) | <0.0001 | 0.89 (0.62–1.24) |
| Lung CD11b+ DC, day 4, % | S01-E | 4.8 | 8.3 | **18.9** | 21.4 | +10.6 (0.1 to 21.1) | 0.007 | 0.81 (0.33–1.38) |
| *Dendritic-cell migration and function* | | | | | | | | |
| CCR7+ migratory CD11b+ DC, % | S02-A | 2.5 | 7.3 | **30.7** | 35.0 | +23.4 (13.8 to 33.0) | <0.0001 | 0.84 (0.59–1.11) |
| Antigen-bearing DC in lymph node, % | S02-C | – | 1.8 | **7.1** | 9.4 | +5.3 (3.6 to 7.1) | <0.0001 | 0.70 (0.53–0.90) |
| OT-I proliferation driven by node DC, % | S02-E | – | 0.77 | **18.7** | 26.2 | +17.9 (14.4 to 21.4) | <0.0001 | 0.70 (0.55–0.87) |
| CD40+ of node CD11b+ DC, % | S02-D | 4.0 | 5.6 | **11.2** | 38.7 | +5.6 (2.0 to 9.3) | 0.16 | 0.17 (0.09–0.25) |
| CD86+ of node CD11b+ DC, % | S02-D | 7.2 | 8.1 | **14.5** | 37.9 | +6.4 (3.0 to 9.9) | 0.033 | 0.22 (0.13–0.30) |
| *Humoral, day 14 unless stated* | | | | | | | | |
| Serum IgG anti-H1N1 (GMT) | S03-A | 56 | 393 | **7,305** | 11,959 | ×18.6 (9.1–37.9) | <0.0001 | 0.86 (0.72–0.99) |
| HAI anti-H1N1 (GMT) | S03-C | 7.6 | 46 | **368** | 485 | ×8.0 (3.9–16.4) | <0.0001 | 0.88 (0.67–1.13) |
| Neutralising anti-H1N1 (GMT) | S03-D | 52 | 418 | **3,840** | 6,686 | ×9.2 (3.1–27.2) | 0.0002 | 0.80 (0.52–1.06) |
| HAI anti-H3N2 (GMT) | S03-G | 10 | 35 | **320** | 368 | ×9.2 (4.2–20.2) | <0.0001 | 0.94 (0.75–1.13) |
| Germinal-centre B cells, day 7, % | S03-K | 1.2 | 2.3 | **6.5** | 9.8 | +4.2 (2.3 to 6.1) | 0.007 | 0.56 (0.36–0.89) |
| ICOS+ Tfh, day 7, % | S04-A | 0.30 | 3.8 | **10.3** | 13.6 | +6.4 (2.6 to 10.3) | 0.0002 | 0.66 (0.41–0.95) |
| Follicular regulatory T cells, day 7, % | S04-B | 22.6 | 26.7 | **10.8** | 7.1 | −15.9 (−24.0 to −7.7) | 0.0002 | 0.81 (0.67–0.99) |
| Follicular regulatory T cells, day 30, % | S04-C | 13.9 | 18.0 | **14.0** | 7.4 | −4.0 (−9.2 to 1.1) | 0.14 | 0.38 (0.00–0.65) |
| *CD8 T cells* | | | | | | | | |
| Ki-67+ CD8, lung, day 3, % | S05-D | 0.83 | 3.5 | **9.4** | 9.9 | +5.9 (3.6 to 8.2) | 0.0008 | 0.91 (0.61–1.52) |
| GZMB+ CD8, lung, day 3, % | S05-E | 0.99 | 3.0 | **5.7** | 9.6 | +2.7 (1.5 to 3.9) | 0.0008 | 0.41 (0.27–0.54) |
| IFN-γ+ CD8 to rgH5N1, node, day 14, % | S05-F | 0.67 | 1.5 | **6.4** | 9.2 | +4.9 (3.6 to 6.1) | <0.0001 | 0.63 (0.52–0.75) |
| IFN-γ+ CD8 to rgH5N1, node, day 60, % | S05-G | 1.5 | 3.0 | **9.9** | 14.4 | +6.8 (3.4 to 10.3) | 0.0008 | 0.60 (0.39–0.86) |
| Lung resident-memory CD8, day 25, % | S05-I | 0.58 | 1.0 | **4.0** | 6.0 | +3.0 (2.2 to 3.7) | <0.0001 | 0.59 (0.48–0.70) |

Reading the table: the early interferon response and monocyte recruitment are restored to the young level; dendritic-cell migration, antibody and CD8 responses are restored by roughly 55–95% (granzyme-B+ CD8 cells at day 3 are the low outlier at 41%); costimulatory molecules on lymph-node dendritic cells are not (17–22%), and the reduction in follicular regulatory T cells has gone by day 30. The IgG2a:IgG1 balance, recomputed from raw titres, moves from IgG1-skewed with PSLN-212 (GM 0.54 for H1N1, 0.46 for H3N2) to IgG2a-skewed with PSLN-344 (1.85, 2.30; young 2.50, 2.79) [H4a, H4b]; the printed quotient blocks S03-B and S03-F show the opposite only because their column labels are rotated (register B1).

![Figure 3. Restoration index by read-out.](figures/fig3_restoration_index.png)

![Figure 4. The pharmacodynamic chain in aged lung.](figures/fig4_mechanism_chain.png)

![Figure 5. Adaptive responses.](figures/fig5_adaptive_immunity.png)

## 4.3 Which links are shown, and which are assumed

| Link | Evidence | Strength |
|---|---|---|
| Liposome reaches alveolar macrophages and epithelium through surfactant proteins | SRB in 15.8% of type II cells versus 0.38% with free dye (S01-B); macrophage uptake 43.1% in wild-type versus 12.7% in Sftpa1/Sftpd-knockout mice (S01-C) [M10a, M10b] | Direct. Epithelial delivery is shown for the manganese-free backbone, macrophage uptake for the PSLN-344 composition in young knockout mice; the one head-to-head block (S08-C) is unusable (register B7) |
| Manganese restores the aged interferon-β response | S01-A, S08-A [M1a–c, M2] | Direct, n = 5 and n = 3 per dose |
| Interferon signalling → GM-CSF → monocyte-derived DC | Ifnar-knockout marrow yields 2.1% donor moDC versus 19.7% wild-type; recombinant GM-CSF recovers 59% of the gap (S02-H). GM-CSF added to PSLN-212 in aged mice raises moDC-like cells from 5.9% to 13.8% (S02-G) [M8a, M8b] | Interventional; host age in S02-H not stated; no GM-CSF blockade |
| Monocyte recruitment needs gap junctions and CCR2 | Carbenoxolone −58% (S11-C); CCR2 antagonist −67% (S07-B) [M9a, M9b] | Interventional, aged |
| Recruited monocytes are needed for CD8 effectors | CCR2 antagonist cuts lung GZMB+ CD8 from 6.8% to 1.4% (S02-I) [M9c] | Interventional, **young mice only** |
| CD8 priming can occur in the lung itself | Pertussis toxin abolishes OT-I proliferation in the lymph node (30.9% → 6.8%) but not in lung (59.0% → 55.1%) (S05-C) [M11a, M11b] | n = 3; host age not stated |
| Early protection needs antigen plus adjuvant | Challenge on day 3: vaccine + PSLN-344 6/7; vaccine alone 0/7; PSLN-344 alone 0/7 (S15-H) [E12] | Direct, n = 7 per arm |
| **CD8 T cells (or antibody) → survival** | **None.** No depletion, no cell or serum transfer, no receptor blockade followed by challenge | **Not tested** |

## 4.4 What the data say about antibody versus T cells

- **Timing.** Antibody was first measured at day 14. Protection was already 87% when challenge came on day 2–3 [E10a], a point at which proliferating (Ki-67+) and granzyme-B+ CD8 T cells were already raised in lung (S05-D, S05-E).
- **Breadth.** The H3N2 vaccine protected against H1N1 and the H1N1 vaccine against H3N2 (S06-A, S06-B, S06-E(1), S06-G). HAI and neutralising titres were measured only against the vaccine strains, so they cannot account for this. CD8 T cells from H1N1+H3N2-vaccinated animals did respond to H5N1 antigen (6.4% versus 1.5% with PSLN-212; S05-F).
- **A conventional antibody threshold did not protect.** All five aged PSLN-212 animals had HAI at or above 1:40 (range 40–80) [H2c], yet the corresponding challenge arm had 0/7 survivors by the S03-I labels, or 3/7 by the S13-F labels. All five PSLN-344 animals were at or above 1:160.
- **What this does not exclude.** Antibody may well carry the homologous protection, and non-neutralising antibody to conserved proteins was never measured. At day 60 the cross-reactive CD8 response in the lymph node was still high (9.9%) while protection had fallen to 67%; lung resident-memory cells were measured only at day 25 and antibody only at day 14–28, so the data cannot say which decline tracks the fade.

# 5. Is there a biomarker of efficacy worth carrying forward?

**No read-out in this package is a validated biomarker of efficacy, and the reason is structural.** Immunology and challenge were done in separate animals with no identifiers linking them, and in 22 of the 23 read-outs I checked the PSLN-344 and PSLN-212 values do not overlap at all [B0]. When every read-out moves with the protected arm, the data cannot tell a driver from a passenger. The choice of what to carry forward therefore rests on mechanism, timing and whether it can be sampled in a person.

| Candidate | What our data show | Can it be measured in patients? | Role | Must be shown first |
|---|---|---|---|---|
| **Early mucosal interferon / CCL2 / GM-CSF response** (16–36 h) | The only read-out with a dose–response (S08-A). Separates PSLN-344 from PSLN-212 in aged lung: Ifnb1 ×2.2, Gm-csf ×4–5, Ccl2 ×77 (17–357; n = 3) [M1a, M4, S2d]. On the causal path (CCR2 and gap-junction blockade). The 72-hour value doubles as the resolution read-out for safety. | Indirectly. Measured here as transcripts in lung tissue. In people: proteins in nasal lining fluid or induced sputum, interferon-stimulated genes in blood. | **Pharmacodynamic / proof of mechanism; dose selection** in phase 1. Not an efficacy marker. | That nose or blood tracks lung (ferret, Study 6); protein rather than transcript. |
| **Serum HAI and neutralising titre** | HAI 8- to 9-fold above PSLN-212 and 76–87% of the young benchmark; neutralising titre 9-fold above and 57% of young [H2a, H2b, H3a]. But 1:40 did not protect aged animals, and these titres cannot explain day-3 or cross-subtype protection (§4.4). | Yes, today; validated assays with regulatory precedent. | **Immunogenicity endpoint** for strain-matched claims and for bridging to licensed vaccines. Not a surrogate for the breadth and speed that differentiate the asset. | Individual-level relation to survival and the protective threshold in aged hosts (Study 1). |
| **Cross-reactive CD8 T-cell response** (IFN-γ or granzyme B to conserved antigens) | 4-fold above PSLN-212 at day 14, present at day 60; lung resident memory 4-fold [C1c–e]. Fits the timing and breadth of protection. | Partly. Blood ELISpot or intracellular staining, yes. Lung-resident cells, no. All our measurements are in lymph node or lung, none in blood. | **Exploratory response marker; candidate correlate of protection** for cross-subtype claims. | That CD8 depletion removes protection (Study 2); that blood reflects lung; individual-level association (Study 1). |

**If only one new assay can be funded,** make it the early mucosal response. It is the one read-out that is dose-responsive, manganese-specific and on the causal path, and phase 1 needs it for dose selection whatever the efficacy correlate turns out to be. HAI comes along anyway as the standard immunogenicity endpoint.

**Not carried forward, and why.** Tfh:Tfr ratio: an arithmetic transform of the Tfr percentage, lymph-node only, and the Tfr effect is gone by day 30. IgG2a:IgG1: mouse isotypes, and the printed block is mislabelled. CD40/CD86 on dendritic cells: hardly restored although animals are protected. Macrophage subsets (CD206, Ly6C/CCR2): blocks conflict in direction or carry duplicated labels. NK cells: no manganese-specific signal (Tukey p ≥ 0.11 at every day) [S5]. Neutrophils and alveolar macrophages: the two blocks share 35 of 100 values.

**In patients, then:** yes as a pharmacodynamic marker and as immunogenicity endpoints; no as a surrogate endpoint, and no as a test to select patients. The only "selection" variable the data support is age: the benefit over the parent exists in aged animals and not in young ones.

# 6. Tolerability and safety: what the package does and does not show

| Question | Block | Result | Reading |
|---|---|---|---|
| Systemic tolerability after dosing | S08-D | Weight nadir 96.4% with PSLN-344 versus 98.2% with vaccine alone (difference −1.8; −3.7 to 0.1); lowest animal 94.2%; 99.8% by day 10; no missing animals (n = 5) [S1a, S1b] | Mild and transient; small n |
| Against the alternative tried (TLR7/8 co-agonist) | S08-D, S09-A | PSLN-212/R848: nadir 90.0%, 90.6% at day 10 with one of five animals no longer recorded; Tnf 202-fold and Il10 179-fold at 16 h [S1a, S1b, S2a] | PSLN-344 clearly better tolerated |
| Lung cytokines at 16 h | S09-A | Tnf 40-fold, which is 2.9 times the young benchmark (1.7–4.9); Il6 36-fold and Ccl2 590-fold, both below young (60, 1,391) [S2a] | Young-like profile with more Tnf and Il10 |
| Resolution at 72 h | S09-A, S01-A | Aged PSLN-344: Tnf 8.4, Il6 7.2, Il10 4.2-fold. Young PSLN-212: 0.5, 3.1, 0.1. Aged PSLN-212: 5.2, 1.9, 4.2. Tnf 17.8 times young (4.8–66) and 1.6 times aged PSLN-212 (0.99–2.6). Ifnb1 4.2 versus 1.5 in young [S2b, S2c, M1e] | **Slower resolution in aged lung, somewhat more with manganese; nothing measured after 72 h** |
| CNS inflammation at 36 h | S10-A | Ifnb1 1.32 ± 0.41 versus PBS 1.00 ± 0.23 and cholera toxin 5.50 ± 1.19. Tnf 1.59 ± 0.49 versus 1.00 ± 0.22: ratio 1.57 (1.05–2.34), Tukey p = 0.12; against vaccine + empty liposome 1.20 (0.77–1.87). Isg15 1.13 versus 1.00 [S3a–c] | No cholera-toxin-like signal; a small Tnf rise is not excluded; one time point, region not specified |
| Cellular lung inflammation | S11-A, S11-B, S11-D | NK cells: no significant excess over vaccine alone or PSLN-212 on any day [S5]. The neutrophil block shares 35/100 values with the macrophage block [I3] | **Not assessable** |
| Does the adjuvant alone worsen challenge outcome? | S15-H | PSLN-344 alone then challenge: deaths on days 5–8 (mean 6.1) versus days 4–7 (mean 5.4) for vaccine alone; p = 0.31 [S4] | No enhancement seen |
| Not in the package | – | Histopathology, clinical pathology, manganese content or biodistribution, repeat dosing, males, any dose above 40 µg | Gaps to fill before IND-enabling work |

The 72-hour panel deserves a word. Both S09-A panels are labelled "16h", but the Ifnb1 row of the second equals the log10 of individual S01-A 72-hour animals in 17 of 18 cells, so I treat it as 72 hours (register B3). If that is right, Tnf and Il10 are still 8-fold and 4-fold raised in aged lung three days after a dose, when in young lung they are back at or below baseline, and the package stops there.

![Figure 6. Tolerability evidence.](figures/fig6_tolerability.png)

# 7. Forward plan: what the next studies have to establish

| Stage | Study | Must establish | Calendar |
|---|---|---|---|
| Gate 0 | Record reconciliation (no animals) | That the 11 survival experiments exist independently in source records; correct arm labels; manganese content per dose | 4 weeks |
| Gate 1 | 1. Confirmation, attribution, dose | Benefit replicates blinded, in both sexes; manganese alone versus manganese + agonist; dose–response for protection; individual-level correlate | ≈5 months |
| Gate 1 | 2. Mediator of protection | Which of CD8 T cells, CD4 T cells, antibody or the monocyte step is necessary or sufficient | ≈5 months, parallel |
| Gate 1 | 3. Pilot safety | Time to resolution in aged lung; manganese in olfactory bulb and brain; first dose multiple | ≈4 months, parallel |
| Gate 2 | 4. Durability and boost | How long protection lasts; whether a second dose repairs the day-60 fall | ≈10 months; start with Gate 1, at risk |
| Gate 2 | 5. Benchmark | Superiority over licensed-type regimens; activity with licensed antigen formats; previously infected hosts | ≈6 months |
| Gate 2 | 6. Ferret and delivery | Effect in a second species with a clinically usable device | ≈8–10 months |
| Gate 2 | CMC work-stream | Manganese loading and release; batch comparability; stability; antigen compatibility | parallel |
| Gate 3 | GLP toxicology, then phase 1 | Safety margin; human pharmacodynamics and immunogenicity | after Gate 2 |

## Gate 0. Record reconciliation

- **Must establish:** which of the findings in §9 are transcription errors and which reflect the experiments; in particular whether S06-C and S06-D are two experiments, and the true arm identities in S03-I and S03-J.
- **Deliverables:** a corrected, locked workbook with animal identifiers that link survival, weight and immunology; manganese content (ICP-MS), particle size, zeta potential and encapsulation for retained batches.
- **Decision rule:** if fewer than 9 of the 11 survival experiments can be verified, efficacy is treated as unconfirmed and Study 1 becomes the primary evidence.

## Study 1. Confirmation, attribution and dose

- **Population:** BALB/c, 20–22 months, males and females; young adults (8 weeks) as benchmark; unchallenged age-matched sentinels for background mortality.
- **Arms and comparators** (one intranasal dose with bivalent inactivated vaccine; 20–24 animals per arm, half of each sex; allocation randomised, scoring blinded, analysis plan fixed in advance): empty liposome; PSLN-212 20 µg; PSLN-344 at 2.5, 5, 10 and 20 µg; manganese-only liposome matched to the 20 µg dose; PSLN-212 with free Mn²⁺ admixed; PSLN-344 20 µg without vaccine; young + PSLN-212.
- **Endpoints:** primary, survival to day 14 after heterosubtypic challenge (5× mLD50 rgH5N1) given 14 days after the dose. Secondary: weight nadir and area under the curve, clinical score, lung viral titre on days 3 and 6 after challenge (satellite animals).
- **Read-outs:** every animal bled on day 12 for HAI and neutralisation against vaccine and challenge strains, IgG, and blood CD8 IFN-γ ELISpot to conserved NP/M1 peptides, so that each animal's values can be set against its own outcome. Satellites: lung and lavage Ifnb1, Gm-csf and Ccl2 (transcript and protein) at 16 h, 36 h, 72 h and day 7; nasal-wash IgA on day 14.
- **Timing:** 6–8 weeks to source aged animals; dose day 0, bleed day 12, challenge day 14, end day 28; report at about 5 months.
- **Why this size:** 20 per arm gives 85% power, and 24 gives 93%, to detect 70% versus 20% survival by Fisher's exact test, which is deliberately more conservative than the 84% versus 13% observed. The lower doses are there to produce intermediate survival, without which no correlate analysis is possible.
- **Decision rule:** continue if PSLN-344 20 µg exceeds PSLN-212 by at least 40 points with a lower 95% bound above 20, in the sexes combined and with neither sex reversing; if survival rises with dose; and if manganese-only liposome recovers less than half of the effect.

## Study 2. What mediates protection

- **Population:** BALB/c, 20–22 months, both sexes, vaccine + PSLN-344 20 µg; 12 per arm.
- **Arms and comparators:** isotype control; anti-CD8 depletion started two days before challenge (systemic and intranasal); anti-CD4; FTY720 to hold circulating cells out of the lung (tests whether resident cells suffice); CCR2 antagonist (the S07-B regimen) or anti-GM-CSF during priming; passive transfer of day-14 serum, or of lung and lymph-node CD8 T cells, from PSLN-344 donors into naive aged recipients; vaccine + empty liposome as negative control.
- **Endpoints:** survival (primary), weight, lung viral titre on days 3 and 6, each for three settings: heterosubtypic challenge on day 3, heterosubtypic on day 14, homologous on day 14.
- **Read-outs:** depletion efficiency in blood, lymph node and lung (with intravascular labelling); serum titres in transfer recipients.
- **Timing:** alongside Study 1; report at about 5 months.
- **Decision rule:** this study chooses the biomarker. If CD8 depletion removes early and heterosubtypic protection and serum does not transfer it, the T-cell assay becomes the primary response marker; if serum transfers homologous protection, HAI stays as the endpoint for strain-matched claims. If neither intervention changes outcome, the mechanism is unknown and the asset is harder to develop.

## Study 3. Pilot safety: resolution and manganese

- **Population:** BALB/c, 20–22 months, both sexes; young adults for contrast.
- **Arms and comparators:** saline; empty liposome; PSLN-212 20 µg; PSLN-344 at 20, 40 and 80 µg or the maximum feasible; manganese-only liposome and MnCl₂ solution matched to the top dose (MnCl₂ as the positive control for nose-to-brain transport); cholera toxin as positive control for the CNS read-outs, as in S10-A. Single dose, and two doses 14 days apart (the boost schedule of S13-I).
- **Endpoints:** daily weight and clinical score; lavage differential counts (neutrophils, which the present package cannot provide); lung and nasal/olfactory histopathology; manganese by ICP-MS in olfactory bulb, striatum, cerebellum, lung, liver and blood.
- **Read-outs and timing:** lavage and lung TNF, IL-6, IL-10, CCL2, IFN-β and GM-CSF protein at 6 h, 16 h, 72 h and days 7, 14 and 28; histopathology on days 3, 14 and 28; manganese at 24 h and days 7 and 28; olfactory-bulb and brainstem Tnf, Ifnb1, Isg15 and Il1b with microglial and astrocyte staining at 36 h and day 7; clinical chemistry and haematology on days 3 and 28. Report at about 4 months.
- **Decision rule:** stop or redesign if, at 20 µg, lung TNF or IL-6 or lavage neutrophils are still above vehicle on day 14, or brain manganese is still raised on day 28, or no dose at least twice the efficacious dose is free of histopathological findings.

## Study 4. Durability and boost

- **Population:** BALB/c dosed at 16–18 months, so that four months of follow-up ends before the age at which one in five unchallenged animals dies per fortnight [E11]; unchallenged sentinels in every cohort; 20 per arm per time point; young benchmark.
- **Arms and comparators:** empty liposome; PSLN-212 once and twice; PSLN-344 once and twice (days 0 and 14, the schedule of S13-I); young + PSLN-212. The two-dose PSLN-212 arm answers whether a second dose of the parent can substitute for manganese: after a boost its IgG reached a GMT of 4,411 against H1N1, still below a single dose of PSLN-344 (7,305), and protection after a boost has never been tested [H6a, H1a].
- **Endpoints:** survival after heterosubtypic challenge 60, 120 and 180 days after the last dose (primary: day 120); weight nadir; lung viral titre.
- **Read-outs:** in the same animals, serum HAI, neutralisation and IgG and blood T-cell ELISpot on days 14, 60, 120 and 180; in satellites at the same times, lung resident-memory CD8 T cells with intravascular labelling and lymph-node cross-reactive CD8 T cells.
- **Timing:** about 10 months; start with Gate 1, at risk, because aged animals are the bottleneck.
- **Decision rule:** a seasonal indication needs at least 70% survival at day 120 (lower 95% bound above 50%) with one or two doses. Otherwise position for outbreak response, where the 2–3-day onset matters more than duration, or stop.

## Study 5. Benchmark against what older adults already receive

- **Population:** BALB/c, 20–22 months, both sexes; naive and PR8-imprinted, as in S06-E(2).
- **Arms and comparators:** intramuscular split vaccine at standard dose; intramuscular high dose (four times the antigen); intramuscular squalene-emulsion-adjuvanted split vaccine; intranasal split vaccine alone; intranasal split vaccine + PSLN-344; intranasal whole inactivated vaccine + PSLN-344 as the bridge to the present data. Every efficacy result so far is against a regimen with 1% survival; this study supplies comparators that work.
- **Endpoints:** survival and weight after homologous and heterosubtypic challenge on day 28; lung viral titre.
- **Read-outs:** HAI and neutralisation against vaccine and drifted strains; nasal and lavage IgA (not measured anywhere in the package); blood and lung T cells.
- **Timing:** about 6 months after Gate 1.
- **Decision rule:** continue if intranasal split vaccine + PSLN-344 is superior to the best intramuscular comparator on heterosubtypic survival and not inferior on homologous HAI.

## Study 6. Second species and delivery (ferret)

- **Population:** ferrets, aged (4 years or older) and young adult, influenza-experienced and naive.
- **Arms and comparators:** split vaccine + PSLN-344 by nasal spray and by aerosol to the lower airway, at two dose levels; split vaccine alone by each route; intramuscular adjuvanted vaccine; placebo. Route matters because in mice an intranasal instillate reaches the alveoli, which is where S01-B and S01-C place the mechanism; a human nasal spray does not.
- **Endpoints:** primary, area under the nasal-wash viral-titre curve after heterosubtypic challenge on day 28; fever, weight, activity; lung pathology on day 5.
- **Read-outs:** HAI and neutralisation; nasal IgA; blood IFN-γ ELISpot; paired nasal wash, lavage and serum interferon, CXCL10, CCL2 and GM-CSF at 0, 6, 24 and 72 h, which is the bridge from the lung pharmacodynamic marker to a compartment that can be sampled in people.
- **Timing:** 8–10 months; aged ferrets are rate-limiting.
- **Decision rule:** at least a 1.5 log10 reduction in viral area under the curve against vaccine alone, by a route that is acceptable for older adults.

## CMC work-stream, GLP toxicology and first-in-human outline

- **CMC (parallel with Gate 1–2):** manganese loading, speciation and release; a single manufacturing route (the annotation names two); at least five batches for size, polydispersity, zeta potential and encapsulation (currently 54.8 ± 5.1%, n = 3); stability of the lyophilised product at 0, 1, 3, 6 and 12 months with a potency assay; HA potency after mixing with licensed antigens; integrity through the chosen device.
- **GLP toxicology (Gate 3):** repeat-dose intranasal or inhalation studies in two species with recovery groups, respiratory and CNS safety pharmacology, local tolerance and manganese biodistribution, with doses set from Study 3.
- **Phase 1 outline.** Population: healthy adults 18–49 as sentinels, then adults 65 and older, stratified 65–74 and 75+. Comparators: the same antigen by the same route without adjuvant, and a licensed high-dose or adjuvanted intramuscular vaccine. Endpoints: solicited and unsolicited adverse events, with facial palsy, change in smell and bronchospasm as events of special interest, and blood manganese. Read-outs: serum HAI and neutralisation on day 28 against vaccine and drifted strains; nasal IgA; blood T-cell ELISpot to conserved antigens on days 7, 28 and 180; nasal-lining-fluid interferon, CXCL10, CCL2 and GM-CSF before dosing and at 6–24 h and 72 h for target engagement and resolution. Timing: visits on days 0, 1, 3, 7, 28, 90 and 180.

# 8. What I considered and ruled out

## 8.1 Alternative explanations for the survival benefit

| Hypothesis | Test in our data | Verdict |
|---|---|---|
| Chance, or a few favourable blocks | 11 of 11 experiments; exact log-rank p 0.0001–0.003 in each; leave-one-out 81–85 points | Ruled out |
| An artefact of the record problems | Every sensitivity analysis stays at +81 or more against Sham and +64 or more against the parent (§3.2) | Ruled out as an explanation of the effect, not of individual numbers |
| Non-specific antiviral state from the STING agonist | PSLN-344 without antigen, challenge on day 3: 0/7 (S15-H) | Ruled out as sufficient |
| Antigen or liposome alone | Sham 1/80; vaccine alone 0/7 | Ruled out |
| PSLN-344 simply delivers more agonist | Encapsulation 54.8% versus 59.6%; PSLN-212 at 40 µg below PSLN-344 at 10 µg for Ifnb1 | Ruled out for payload; dose substitution ruled out for Ifnb1 only |
| A BALB/c peculiarity | C57BL/6 6/7 and Swiss Webster 6/7 versus 0/7 (S15-L, S15-N) | Not supported, with a provenance caveat (register A9) |
| Prior influenza exposure cancels the benefit | Imprinted animals 6/7 and 6/7 (S06-E(2), S06-F(2)) | Not supported; one imprinting virus, 14-month animals |
| The day-60 deaths are only old age | 4/21 unchallenged animals died, but PSLN-344 deaths followed 15–22% weight loss against 3–6% | Partly: background mortality is real; the recorded weights suggest most of the fade is not explained by it |
| Neutralising antibody explains the protection | Protection on day 2–3 and across subtypes; HAI ≥ 1:40 in all PSLN-212 animals without protection | Unlikely as sole mediator; not formally excluded |
| Manganese alone would do it | No manganese-only arm | **Cannot be ruled out**; Study 1 |

## 8.2 Other ways to repair the aged response that the programme's own arms let us judge

| Alternative | Data | Verdict |
|---|---|---|
| cGAMP in place of CDN-1807 (CMP-204) | Ifnb1 GM 7.7 versus 16.5 for PSLN-212; IgG GMT 181 versus 393 [M1, H1a]. In S03-I the arm labelled CMP-204 has 3/7 survivors against 0/7 for the arm labelled PSLN-212, but those are the two contested labels (register A4). Protects young mice 7/7 (S13-E) | Weaker than the parent on every immune read-out; survival comparison in aged mice unresolved |
| Add a TLR7/8 agonist (PSLN-212/R848) | Ifnb1 24 (below PSLN-344's 37); Tnf 202-fold; weight −10% and not recovered; no efficacy data | Rejected on tolerability |
| Give more PSLN-212 | Ifnb1 plateaus at 14.7 at 40 µg | No, for this read-out; untested for protection |
| Give PSLN-212 twice | Post-boost IgG GMT 4,411 (H1N1) and 1,086 (H3N2), below one dose of PSLN-344 (7,305 and 5,701); no challenge after boost [H6a, H6b, H1a, H1b] | Unlikely; tested in Study 4 |
| Add recombinant GM-CSF to PSLN-212 | Restores moDC-like cells (13.8% versus 5.9%) after four daily protein doses; no challenge data | Informative about mechanism, impractical as a product |

## 8.3 Analytical choices I rejected

| Tempting choice | Why not | What I did |
|---|---|---|
| Pool all 12 aged experiments | S06-D is identical to S06-C | Pooled 11; showed 12 as a sensitivity analysis |
| Compare group mean weights as printed | Dead animals' last weights are carried forward in adjuvant arms and blanked in Sham arms | Per-animal nadir on real values |
| Quote the IgG2a:IgG1 quotient blocks | Column labels rotated relative to the raw titres; conclusion would reverse | Recomputed from S13-A to S13-D |
| Average S09-A as if linear, or treat both panels as 16 h | The block is log10; the second panel matches 72-hour animals | Mean of logs; second panel as 72 h |
| Arithmetic means for titres; HAI zeros as zero | Titres are multiplicative; 0 means below 1:10 | Geometric means; 0 set to 5 |
| Count Tfh:Tfr as additional evidence | It is (100 − Tfr%) ÷ Tfr%, cell for cell | Reported Tfr% once |
| Use the neutrophil block as reassurance | 35 of 100 values are the macrophage block's | Declared not assessable |
| Use S07-A and S07-C for a macrophage → Treg mechanism | Direction conflicts with three blocks; duplicated labels | Left out of the causal chain |
| Use the unlabelled S08 rows 89–101 | No header, no groups | Excluded |
| Count the tenth S03-J PSLN-344 animal | Its indicator has no recorded day | n = 9; n = 10 gives the same p-values |
| Read "Untreated" deaths as challenge deaths | Those animals were never challenged | Used as background mortality |
| Lean on S05-A/B tetramer kinetics | Two animals per point; conflicting conditions; strain unclear | Supportive only |

## 8.4 Biomarkers considered and set aside

See the last paragraph of §5.

## 8.5 Questions to expect from the committee, with the short answer

| Question | Short answer | Where |
|---|---|---|
| Is the effect real, given the state of the record? | On the record as it stands, yes. No sensitivity analysis brings the difference from vaccine alone below 81 points or from the parent below 64, and each of the 11 experiments is significant on its own. The record problems change which single blocks can be quoted, not the conclusion; Gate 0 exists to confirm that against source. | §3.2, §9 |
| Is this just the STING agonist's innate antiviral effect? | No. Adjuvant without antigen, given three days before challenge, protected 0/7; with antigen, 6/7 (S15-H). | §4.3 |
| Why not give more of the parent, or give it twice? | More: its Ifnb1 response plateaus at under a third of the PSLN-344 ceiling (17 versus 59). Twice: antibody after a boost is still below one dose of PSLN-344, and protection after a boost was never tested. | §4.1, §8.2 |
| Why manganese rather than a second agonist? | The TLR7/8 combination gave less interferon-β than PSLN-344 (24 versus 37), five times the Tnf, and a 10% weight loss that had not recovered by day 10. | §6, §8.2 |
| How long does protection last? | 91% when challenged within two weeks, 67% (43–85) at two months, untested beyond. The young benchmark holds 100% at two months. | §3.4 |
| Does it prevent illness? | No. Protected animals lose 13% of body weight (young benchmark 10%), and there are no viral-load data. | §3.4 |
| Is it safe? | Nothing alarming in what was measured, but what was measured is little: weight, three CNS transcripts at one time point, and lung cytokines to 72 hours, at which point Tnf and Il6 are still raised in aged animals. | §6 |
| What is the comparison with what older adults get today? | There is none. Every contrast is against vaccine alone (1% survival) or the parent formulation. | §7, Study 5 |
| Is there a marker we can take into phase 1? | For pharmacodynamics and immunogenicity, yes. For efficacy, not yet. | §5 |
| Does it help younger adults? | No evidence that it does: the parent already protects young mice fully. | §3.3 |

# 9. Record-integrity register

None of these findings changes the direction of any conclusion; several change which individual numbers can be quoted. The body-weight blocks carry most of the problems; the time-to-event blocks carry fewer, and the survival case rests on those. Tier A touches an efficacy block, tier B a mechanism, biomarker or tolerability block, tier C is a gap in the package. Figure 8 illustrates four of them. "Needed to close" for each is in the evidence workbook (sheet *integrity_register*).

![Figure 8. Examples of the record-integrity findings.](figures/fig8_integrity_exhibits.png)

| ID | Blocks | Finding | Evidence | Effect on conclusions | How handled here |
|---|---|---|---|---|---|
| A1 | S06-C, S06-D | Two different experiments carry identical time-to-event records. | All 4 arms, 28 animals: every day and indicator cell of S06-D (challenge day 3) equals S06-C (challenge day 14); 56/56 cells. | One of the two is not an independent experiment. Headline pooled numbers would be inflated by 7 PSLN-344 survivors if both were counted. | Counted once (as S06-C). Reported both ways: 66/79 without S06-D, 73/86 with it. |
| A2 | S15-D vs S06-D | The weight block for the day-3 rgH5N1 experiment implies deaths that its survival block does not record. | S15-D: 2 PSLN-344 animals (cols W, AC) and 2 young PSLN-212 animals (cols F, G) have weights frozen at 79.5/85.2 and 82.1/76.5 from day 8-10 to day 14; S06-D records 7/7 survivors in both arms. | If the weights are right, day-3 rgH5N1 survival with PSLN-344 is 5/7, not 7/7. | S06-D is excluded from the primary pooled estimate; a sensitivity row in section 3.2 keeps it at 5/7 (pooled 71/86). |
| A3 | S15-C, S15-I, S15-M | Body-weight traces are shared between different experiments. | S15-C PSLN-344 (day-14 challenge) equals S15-I '3d Vaccine+PSLN-344' (day-3 challenge) in 40/42 cells on days 2-12; its day-14 row instead shares 5/7 values with S15-M PSLN-344 (C57BL/6). | S15-C cannot be treated as independent morbidity evidence for the day-14 rgH5N1 experiment. | Morbidity conclusions are drawn from nadirs pooled over 10 experiments and do not depend on S15-C. |
| A4 | S03-I vs S13-F | The survival block and its own weight block name the arms differently. | S03-I arms: Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y). S13-F ('the animals of S03-I'): PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naive. S13-F 'PSLN-212' has 3 animals recovering to 95-99% (S03-I PSLN-212: 0/7 survive; S03-I CMP-204: 3/7 survive); S13-F 'Naive' all dead by day 8. | PSLN-344 7/7 and Sham 0/7 are concordant in both blocks. Whether aged PSLN-212 gives 0/7 or 3/7 in the homologous model, and whether a CMP-204 arm existed, is unresolved. | PSLN-344-vs-Sham uses this block; PSLN-344-vs-PSLN-212 is reported with and without it (E5 vs E7) and with the alternative count (E6). |
| A5 | S03-J vs S13-G | Same problem for the wild-type H5N1 experiment, plus an n discrepancy and a missing time. | S03-J arms: Sham (1/10 survive), PSLN-212 (3/10), PSLN-344. S13-G ('the animals of S03-J'): PSLN-344, Sham (4-5 animals with real weights at day 14), Naive (1). Stated n is 9 in S03-J and 10 in S13-G; S03-J has 10 indicator cells per arm but the 10th PSLN-344 cell (J46) has no day (G46 blank). Annotation says observation ran 22 days; the largest day recorded is 21. The challenge dose is not stated. | PSLN-344: no deaths under any reading. The identity of the 3/10 comparator (PSLN-212 or vaccine-alone) and of the 1/10 comparator (vaccine-alone or unvaccinated) is unresolved. | PSLN-344 analysed with n=9 (recorded times); sensitivity with n=10 gives the same p-values. Comparator labels as printed in S03-J, flagged wherever cited. |
| A6 | 17 survival/weight block pairs | Death counts disagree between paired blocks in 10 of 65 arms. | Discordant arms (deaths by weights vs by survival block): S13-F PSLN-212 4 v 7; S13-G Sham 5 v 9; S15-C PSLN-212 6 v 5; S15-D PSLN-212(Y) 2 v 0; S15-D PSLN-344 2 v 0; S15-E PSLN-212 6 v 7; S15-E PSLN-344 1 v 2; S15-G PSLN-344 2 v 3; S15-M PSLN-212(Y) 0 v 1; S09-G Sham 8 animals v 7. | None changes the direction of any contrast. For PSLN-344 arms the survival block records more deaths than the weights in two (S15-E, S15-G) and fewer in one (S15-D). | Survival blocks are primary; worst-case pooled analyses (E3, E6) take the less favourable count for PSLN-344. |
| A7 | S13-F, S13-G, S15-A..G, S15-M, S15-O | Dead animals' last weight is carried forward to day 14 in adjuvant arms but blanked in Sham arms. | e.g. S15-B PSLN-212: all 7 animal columns are constant from day 4-10 onward while S06-B records 7 deaths; Sham columns go blank. Annotation says n 'declines' in these arms. | Group mean weights taken as printed are biased (dead animals keep contributing their last weight) and are not comparable between arms. | Carried-forward values excluded; per-animal nadir on real values used instead. |
| A8 | S06-E(1), S06-F(1), S06-G; S15-E/F/G | Unchallenged, unvaccinated aged animals died during the observation window. | 'Untreated' arms (annotation: no vaccine, no adjuvant, no challenge virus): 1/7, 0/7 and 3/7 deaths = 4/21 (19%; 95% CI 5-42) in 14 days; their last real weights are 94-97% of day 0. | At >=22 months the day-60 experiments have material background mortality; PSLN-344 day-60 survival (14/21) is not statistically distinguishable from unchallenged animals (17/21; p = 0.48). But the PSLN-344 animals that died had lost 15-22% weight first, so I read most of the waning as real. | Reported explicitly; durability conclusion stated with this caveat. |
| A9 | S15-L/M, S15-N/O | Strain-generalisation experiments: challenge not specified; weight traces re-use BALB/c values. | Annotation gives no challenge virus, dose or day for S15-L/S15-N. S15-M PSLN-344: 3 of 7 animals equal S15-A PSLN-344 (BALB/c) on 5 of 7 days; S15-M young arm: 6 of 7 animals share 4-7 of their 7 daily weights with animals of the young BALB/c PSLN-344 arm of S09-E; S15-A Sham day-4 row = S15-M PSLN-212 day-4 row; one young C57BL/6 death (S15-L, day 12) has no counterpart in S15-M. | Survival blocks S15-L/S15-N are distinct records, but the independence of these experiments is not assured. | Pooled estimate also given for BALB/c only (E4: 54/65 vs 1/66). |
| A10 | S06 rows 71-105 | Two blocks re-use the labels S06-E and S06-F (imprinting study). | Annotation acknowledges the duplicate labels. Challenge day is not stated for the PR8 block; dose is written '5 x LD50' (elsewhere '5 x mLD50'). | Naming only; handled by row range. | Referred to here as S06-E(2) and S06-F(2). |
| A11 | S13-E | Stated n (5) differs from animals present (7 per arm). | Header 'n=5'; 28 indicator cells = 7 per arm. | Young-mouse block; not in pooled estimates. | Used 7 per arm. |
| A12 | S09-B, S09-F, S09-G | Annotation and workbook disagree on which young-mouse block has 7 Sham animals. | Annotation: S09-B Sham n=7, S09-F n=8. Workbook: S09-B Sham 8, S09-F Sham 7 (while S09-G, its weight block, has 8 Sham traces). | None (all Sham animals die in all three blocks). | Workbook counts used. |
| A13 | S09-C | A whole row is duplicated across arms. | Day-12 weights of PSLN-344(Y) equal those of PSLN-212(Y) in all 8 positions. | Day-12 means in S09-C are not usable; day-14 and nadir unaffected. | Not used. |
| A14 | S08 rows 89-101 | Unlabelled data. | Column A = 14 in 13 rows; zeros in column C (6 rows) and column D (7 rows); no header, no group names. Resembles two all-survivor arms of a time-to-event block. | Cannot be attributed to any experiment. | Excluded. |
| A15 | S15-A, -C, -F, -J, -K, -M, -O; S08-D; S09-E | Weight values recur across blocks, shifted by whole numbers. | Of 289 weight values recorded with more than one decimal, 168 share their six-digit fractional part with a value in a different block (67 distinct fractions): e.g. 87.423077, 88.423077, 89.423077, 92.423077 and 94.423077 across S15-A, -J, -K, -M and -O; 94.45455 to 99.45455 across six blocks. Independent weighings do not produce this pattern; copying a trace and adding a constant does. | Several weight traces, including PSLN-344 arms in S15-A, S15-F, S15-J and S15-M, are not independent records. Weight-based statements (nadir, morbidity, the cross-check of deaths) are provisional. The time-to-event blocks record whole days, so this check cannot be applied to them; their only exact duplicate is S06-C/S06-D (A1). | Survival blocks are treated as the primary evidence; weights are used for cross-checks and for a morbidity estimate that is labelled provisional. |
| B1 | S03-B, S03-F vs S13-A..D | Column labels of the IgG2a:IgG1 quotient blocks are rotated relative to the raw titres. | Per-animal S13-A/S13-B reproduces the printed S03-B values but under different headers: printed 'PSLN-344' column = ratio for PSLN-212; printed 'PSLN-212(Y)' = PSLN-344; printed 'PSLN-212' = PSLN-212(Y). Same rotation in S03-F. Raw-titre labels agree with total IgG (S03-A/E). | As printed, PSLN-344 would appear IgG1-skewed (0.58); from raw titres it is IgG2a-skewed (GM 1.85 and 2.30) and PSLN-212 is the IgG1-skewed arm (0.54, 0.46). | Recomputed from raw titres; printed quotient blocks not used. |
| B2 | S04-B 'Tfh:Tfr' | Derived block, not an independent measurement. | Every value equals (100 - Foxp3%) / Foxp3% from the S04-B Foxp3 block, row by row. | Cannot be counted as a second line of evidence next to Tfr%. | Reported once (as Tfr%). |
| B3 | S09-A | Both panels are labelled '16h'; control named 'PBS' here and 'Sham' in S01-A; data are log10. | Back-transformed Ifnb1 values of panel 1 coincide with individual S01-A 16-h animals in 18/18 cells and those of panel 2 with S01-A 72-h animals in 17/18 (0/18 with 16 h). 'PBS' values equal S01-A 'Sham' values. | Panel 2 is a 72-h panel. S09-A is a 3-animal subset of the S01-A animals, not a replicate experiment. | Panel 2 analysed as 72 h (flagged as inferred); means taken on the log scale. |
| B4 | S11-A, S11-B | Alveolar-macrophage and neutrophil blocks share values. | 35/100 values identical in the same position (replicates 1-2 of almost every group x day cell); 18/20 cell means within 1.5 points. | The neutrophil block cannot be relied on, so there is no usable read-out of neutrophilic lung inflammation in the package. | Neither block used for conclusions. |
| B5 | S07-C | Both columns carry the same printed label. | Header 'Ly6C-CD206+ MPhi' twice; annotation says Ly6C+CD206- and Ly6C-CD206+ macrophages were transferred. Means 10.4% vs 5.1% Treg. | Which macrophage subset raises lung Treg cannot be assigned. | Not used. |
| B6 | S07-A vs S01-D, S07-B, S11-E | Direction conflicts with three other blocks. | S07-A: Ly6C+CCR2+ macrophages peak 19.0 x10^5 with PSLN-212 vs 3.4 x10^5 with PSLN-344 (n=3). S01-D monocytes 16.7% vs 30.6%; S07-B Ly6C+ macrophages 15.4% with PSLN-344; S11-E CD206+ 71% vs 49%. | Either a real divergence (monocytes become macrophages with PSLN-212, DCs with PSLN-344) or swapped headers; the package cannot tell. | Macrophage arm of the mechanism left out of the causal chain. |
| B7 | S08-C vs S01-B | Same construct and cell type differ 3.6-fold between blocks unless S08-C headers are mis-ordered. | AECI positive for PSLN-SRB: 3.8% (S01-B) vs 13.8% (S08-C). If S08-C columns are read as [AECII-PSLN, AECI-PSLN, AECII-344, AECI-344] the two blocks agree (15.8/3.8 vs 15.8/3.8) and Mn does not change epithelial delivery (13.8% vs 15.8%; 3.0% vs 3.8%). | As printed, Mn incorporation would cut epithelial delivery ~4-fold; under the alternative reading it does not. | Neither reading used to support a claim. |
| B8 | S08-A | A preparation not described in Materials. | 'PSLN-344/R848' appears only here; Materials lists 'PSLN-212/R848'. | None for PSLN-344. | Arm not interpreted. |
| B9 | S08-B | Assay applicability. | Encapsulation efficiency is defined by CDN-1807 absorbance at 260 nm but is reported for PSLN-R848 (no CDN-1807) and CMP-204 (cGAMP). | None for the PSLN-344 vs PSLN-212 comparison (54.8% vs 59.6%). | Only those two arms cited. |
| B10 | S05-A, S05-B (and S05-I by reference) | n, conditions and strain are inconsistent. | Stated n=3, 2 values per cell. Conditions describe both ovalbumin immunisation and the bivalent vaccine. NP366-374 tetramers are H-2Db-restricted, i.e. a C57BL/6 reagent, while the default strain is BALB/c; the block does not name a strain. | Early tetramer kinetics cannot be taken at face value. | Cited only as supportive; early CD8 evidence rests on S05-D/E (n=5). |
| B11 | S02-C, S02-E | The 'PTX' arm's adjuvant and age are not stated. | Header 'PTX' only. | Comparator for the migration-blockade claim is undefined. | Reported as printed. |
| B12 | S07-B, S11-E, S13-H, S14-A | Time point not stated. | The annotation gives none for S07-B and S11-E and says 'not stated' for S13-H and S14-A. | Kinetic interpretation not possible. | Used as cross-sectional evidence only. |
| B13 | S02-H, S02-I, S12-A, S01-C | Key causal experiments were run in young or knockout animals, not aged. | S02-I and S12-A are stated young; S01-C uses 7-8-week knockout mice; S02-H recipients' age is not stated. S02-F (Gm-csf) has no young arm. | The IFN-I -> GM-CSF -> moDC -> CD8 chain is demonstrated piecewise, mostly outside aged animals. | Stated wherever cited. |
| C1 | whole package | Dose of manganese is not recorded. | Doses are given as micrograms of adjuvant; no Mn content, Mn:CDN ratio or release data. | No exposure margin can be calculated for the element that carries the main toxicological question. | - |
| C2 | whole package | No physico-chemical data. | Annotation describes DLS, zeta potential, TEM and lyophilisation, but the workbook contains only encapsulation efficiency (n=3). | Batch comparability and stability unknown. | - |
| C3 | whole package | Read-outs absent. | No lung viral titres, no histopathology, no mucosal IgA, no serology against challenge strains, no measurement in blood other than serum antibody, no animal IDs linking immunology to outcome. | Limits mechanism and correlate analysis. | - |
| C4 | whole package | Single sex, single dose level for efficacy, single antigen format. | Female mice only; all efficacy at 20 ug; formalin-inactivated whole virus made in-house. | Generalisability. | - |

# Appendix A. What each block is and how it was used

| Block | Content | n per arm | Used for | Status |
|---|---|---|---|---|
| S01-A (16 h, 72 h) | Lung Ifnb1 transcript after adjuvant alone; 8 arms | n=5 | Target engagement; age defect; Mn effect | Used |
| S01-B | SRB+ alveolar epithelial cells, liposomal vs free dye | n=5 | Delivery | Used |
| S01-C | DiD+ alveolar macrophages, WT vs Sftpa1/Sftpd knockout (young) | n=4 | Delivery depends on surfactant proteins | Used |
| S01-D | Lung monocytes, days 0-8 | n=5/day | Recruitment | Used |
| S01-E | Lung CD11b+ DC, days 0-8 | n=5/day | moDC accumulation | Used |
| S01-F, S01-G | Lung cDC1 and cDC2 fractions, 72 h | n=5 | DC subsets (the two blocks are complementary fractions) | Used (S01-F); S01-G not counted separately |
| S02-A, S02-B | CCR7+ migratory DC in lung; CD11b+ DC in MLN | n=5 | DC migration | Used |
| S02-C, S02-E | Antigen+ DC in MLN; OT-I cross-priming by MLN DC (incl. PTX arm) | n=5 | DC function | Used; PTX arm undefined (B11) |
| S02-D (CD40, CD86) | Costimulatory molecules on MLN CD11b+ DC | n=5 | Shows what is NOT restored | Used |
| S02-F | Lung Gm-csf transcript 16/36/72 h (no young arm) | n=5 | Mn-specific PD signal | Used |
| S02-G | moDC-like cells after rGM-CSF add-back to PSLN-212 | n=5 | GM-CSF sufficiency | Used |
| S02-H | Donor moDC from WT vs Ifnar-KO marrow +/- rGM-CSF | n=5 | IFNAR -> GM-CSF -> moDC | Used; host age not stated (B13) |
| S02-I | Lung GZMB+ CD8 +/- CCR2 antagonist, young | n=5 | Monocytes needed for CD8 effectors | Used; young only (B13) |
| S03-A, S03-E | Serum IgG to H1N1 / H3N2, day 14 | n=5 | Humoral | Used |
| S03-B, S03-F | IgG2a:IgG1 quotient (printed) | n=5 | - | Not used: labels rotated vs raw titres (B1); recomputed from S13-A..D |
| S03-C, S03-G | HAI titres, day 14 | n=5 | Humoral; candidate biomarker | Used |
| S03-D, S03-H | Neutralising titres, day 14 | n=5 | Humoral | Used |
| S03-I | Survival, homologous CA09 challenge day 14 | n=7 | Efficacy | Used; two arm labels conflict with S13-F (A4) |
| S03-J | Survival, wild-type H5N1 challenge day 2 | n=9-10 | Efficacy | Used; comparator labels conflict with S13-G, one missing time (A5) |
| S03-K, S03-L | GC B cells; Aicda/E47 transcripts in MLN B cells (n=3) | n=5 / 3 | Humoral mechanism | Used |
| S04-A | Tfh split by ICOS, day 7 | n=5 | Humoral mechanism | Used |
| S04-B Foxp3, S04-C | Tfr day 7 and day 30 | n=5 | Regulatory arm; transient | Used |
| S04-B Tfh:Tfr | Ratio printed | n=5 | - | Not used separately: exact transform of S04-B Foxp3 (B2) |
| S04-D | Lung Treg day 7 | n=3 | Regulatory arm | Used (n=3) |
| S05-A, S05-B | NP-tetramer+ CD8 in lung / MLN, days 3-7 | n=2 (stated 3) | Early CD8 kinetics | Supportive only (B10) |
| S05-C | OT-I proliferation lung vs MLN +/- pertussis toxin | n=3 | Local priming in lung | Used (n=3) |
| S05-D, S05-E | Ki-67+ and GZMB+ CD8 in lung, day 3 | n=5 | Early CD8 effectors | Used |
| S05-F, S05-G, S05-H | Cross-reactive IFN-g+ / GZMB+ CD8 in MLN, day 14 and 60 | n=5 | CD8 breadth and persistence | Used |
| S05-I | Lung CD8 TRM day 25 | n=5 | Resident memory | Used; conditions by reference to S05-A (B10) |
| S06-A, S06-B | Survival, H3N2 vaccine -> PR8, day 14 and day 3 | n=7 | Efficacy | Used |
| S06-C | Survival, bivalent -> rgH5N1, day 14 | n=7 | Efficacy | Used |
| S06-D | Survival, bivalent -> rgH5N1, day 3 | n=7 | Efficacy | Excluded from pooled estimates: identical to S06-C (A1, A2) |
| S06-E(1), S06-F(1), S06-G | Survival, challenge day 60 (three models) incl. Untreated arms | n=7 | Durability; background mortality | Used (A8) |
| S06-E(2), S06-F(2) | Survival, imprinting study | n=7 | Pre-existing immunity | Used |
| S07-A | Lung Ly6C+CCR2+ macrophage counts, days 0-30 | n=3 | - | Not used in causal chain: direction conflicts with S01-D/S07-B/S11-E (B6) |
| S07-B | Monocytes and Ly6C+ macrophages +/- CCR2 antagonist | n=5 | CCR2 dependence | Used |
| S07-C | Lung Treg after macrophage-subset transfer | n=5 | - | Not used: both columns carry the same label (B5) |
| S08-A | Ifnb1 dose-response 1-40 ug | n=3/dose | Dose selection; ceiling vs potency | Used; 'PSLN-344/R848' arm not interpreted (B8) |
| S08-B | Encapsulation efficiency | n=3 | Payload comparability | Used for PSLN-344 vs PSLN-212 |
| S08-C | SRB+ epithelial cells, PSLN vs PSLN-344 | n=5 | - | Not used: conflicts with S01-B unless headers mis-ordered (B7) |
| S08-D | Body weight after vaccination, no challenge | n=5 | Tolerability | Used |
| S08 rows 89-101 | Unlabelled zeros against day 14 | 13 rows | - | Excluded (A14) |
| S09-A (two panels) | Lung cytokine transcripts, log10 | n=3 | Reactogenicity profile; resolution | Used; panel 2 treated as 72 h (B3) |
| S09-B..G | Young mice: survival and weights, three models incl. day 180 | n=7-8 | Young comparator | Used; S09-C day 12 row not used (A13) |
| S10-A | CNS Ifnb1/Tnf/Isg15, 36 h, cholera-toxin control | n=5 | Neuro-inflammation screen | Used |
| S11-A, S11-B | Alveolar macrophages; neutrophils, days 0-8 | n=5/day | - | Not relied on: 35/100 shared values (B4) |
| S11-C | Monocyte recruitment +/- carbenoxolone | n=5 | Gap-junction dependence | Used |
| S11-D | Lung NK cells, days 0-8 | n=5/day | No Mn-specific signal | Used (negative) |
| S11-E | CD206+ macrophages | n=5 | Macrophage phenotype | Used descriptively; time not stated |
| S12-A | Infiltrating monocytes, WT vs Ifnar-KO marrow, young | n=3 | Recruitment not clearly IFNAR-dependent | Used (n=3, young) |
| S13-A..D | Serum IgG2a and IgG1 to H1N1 / H3N2 | n=5 | Isotype balance (raw) | Used |
| S13-E | Young mice survival, homologous challenge | n=7 (stated 5) | Young comparator | Used (A11) |
| S13-F, S13-G | Weights for S03-I and S03-J | n=7 / 10 | Morbidity; cross-check of arm identity | Used for cross-check (A4, A5) |
| S13-H | IgG+ B cells in MLN | n=5 | Humoral | Used; time not stated |
| S13-I, S13-J | IgG after day-14 boost | n=5 | Boostability | Used |
| S14-A | IFN-g+ CD8 to H1N1 / H3N2 | n=5 | CD8 | Used; time not stated |
| S15-A..G | Weights for S06-A..G | n=7 | Morbidity; cross-check of deaths | Used with carried-forward values removed (A7); S15-C not independent (A3) |
| S15-H, S15-I | Survival and weights: vaccine alone / PSLN-344 alone / both, day-3 challenge | n=7 | Antigen-dependence of early protection | Used |
| S15-J, S15-K | Weights for imprinting study | n=7 | Cross-check | Used |
| S15-L..O | Survival and weights, aged C57BL/6 and Swiss Webster | n=7 | Strain generalisation | Used; challenge not stated, traces re-used (A9) |

# Appendix B. Limits of this analysis

- I worked from the workbook and the annotation only. I did not see instrument files, protocols or animal-room records, and I changed no values.
- Group sizes are 3–10. Confidence intervals for single experiments are wide (6/7 survivors has an exact 95% CI of 42–100%); the strength of the survival case comes from eleven experiments agreeing, not from any one.
- Four statements rest on my reading of internal evidence rather than on a label: that the second S09-A panel is 72 hours; that flat terminal weights are carried forward after death; that arms without "(Y)" are aged in blocks that do not state age (S03-J, S08-A, S02-G, S07-B); and that the record shared by S06-C and S06-D is one experiment, not two. Each is flagged where used.
- Statements about what a clinical programme would need (comparators, events of special interest, route of delivery) are judgement informed by the field, not findings from this dataset. Study durations and animal-sourcing times are planning estimates.

# Appendix C. Files

| File | Content |
|---|---|
| `PSLN-344_portfolio_recommendation.md` / `.docx` / `.html` | This memo |
| `PSLN-344_evidence_tables.xlsx` | Number ledger (every number: cells and reduction), integrity register, and tables T1–T12 |
| `figures/` | Figures 1–8 (PNG) |
| `tables/` | The same tables as CSV, plus the tidy per-animal data extracted from the workbook |
| `analysis/` | Scripts that regenerate everything from the workbook (`run_all.sh`) |

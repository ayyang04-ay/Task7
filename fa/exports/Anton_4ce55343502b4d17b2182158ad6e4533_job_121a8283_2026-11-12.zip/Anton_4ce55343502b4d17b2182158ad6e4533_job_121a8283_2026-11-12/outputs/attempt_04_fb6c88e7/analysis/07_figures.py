"""07_figures.py -- all figures for the PSLN-344 portfolio memo (reads the workbook through parse_workbook and the tables written by 01-06)."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from parse_workbook import load
from stats_utils import *

FIG = "/tmp/outputs/figures"; TAB = "/tmp/outputs/tables"
M, S = load(); M = M[M.value.notna()].copy(); M["value"] = M.value.astype(float)
plt.rcParams.update({"font.size": 9, "axes.spines.top": False, "axes.spines.right": False, "axes.titlesize": 9.5, "axes.labelsize": 9,
                     "legend.fontsize": 8, "figure.dpi": 150, "savefig.dpi": 200, "font.family": "DejaVu Sans"})
COL = {"Sham": "#7f7f7f", "Vaccine": "#7f7f7f", "PBS": "#7f7f7f", "PSLN-212": "#e08214", "PSLN-344": "#1f4e9c", "PSLN-212(Y)": "#35a055", "PSLN-344(Y)": "#7fc8f0",
       "CMP-204": "#9467bd", "Untreated": "#bdbdbd", "Naive": "#000000", "PSLN-R848": "#c49c94", "PSLN-212/R848": "#d62728", "CT": "#d62728",
       "3d Vaccine": "#7f7f7f", "3d PSLN-344": "#8c564b", "3d Vaccine+PSLN-344": "#1f4e9c",
       "Naive+PSLN-212": "#e08214", "Imprinting+PSLN-212": "#f4c27a", "Naive+PSLN-344": "#1f4e9c", "Imprinting+PSLN-344": "#7fa6dc", "CMP-204(Y)": "#c5b0d5"}
LAB = {"Sham": "Sham (vaccine + empty liposome), aged", "PSLN-212": "PSLN-212 (no Mn), aged", "PSLN-344": "PSLN-344 (Mn), aged", "PSLN-212(Y)": "PSLN-212, young (benchmark)",
       "CMP-204": "CMP-204 (cGAMP), aged", "Untreated": "Untreated, unchallenged, aged"}

def vec(bp, g, x=None):
    d = M[(M.block_panel == bp) & (M.group == g)]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    return d.sort_values("rep").value.values

def km_plot(ax, bp, groups, window=14, offsets=True):
    for i, g in enumerate(groups):
        d = S[(S.block_panel == bp) & (S.group == g) & S.day.notna()]
        if not len(d): continue
        ts, ss = km_curve(d.day.values.astype(float), d.event.values.astype(int))
        ts = np.r_[ts, window]; ss = np.r_[ss, ss[-1]]
        off = (i - (len(groups) - 1) / 2) * 1.2 if offsets else 0
        ax.step(ts, 100 * ss + off, where="post", color=COL.get(g, "k"), lw=2.0 if g in ("PSLN-344", "3d Vaccine+PSLN-344", "Naive+PSLN-344", "Imprinting+PSLN-344") else 1.4,
                ls="--" if g in ("Untreated",) else "-", alpha=0.95)
    ax.set_ylim(-6, 108); ax.set_xlim(0, window); ax.set_yticks([0, 25, 50, 75, 100])

# ------------------------------------------------------------------ Fig 1 KM grid
# (block_panel, title, groups, window, (text x, text y))
panels = [("S03-J", "S03-J  rgH5N1 vaccine → wild-type H5N1, day 2\n[comparator labels conflict with S13-G]", ["Sham", "PSLN-212", "PSLN-344"], 21, (0.04, 0.42)),
          ("S06-B", "S06-B  H3N2 vaccine → PR8 H1N1, day 3", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"], 14, (0.04, 0.36)),
          ("S15-H", "S15-H  bivalent → rgH5N1, day 3\nantigen alone / adjuvant alone / both", ["3d Vaccine", "3d PSLN-344", "3d Vaccine+PSLN-344"], 14, (0.50, 0.62)),
          ("S03-I", "S03-I  bivalent → homologous CA09 H1N1, day 14\n[two arm labels conflict with S13-F]", ["Sham", "CMP-204", "PSLN-212", "PSLN-344", "PSLN-212(Y)"], 14, (0.04, 0.42)),
          ("S06-A", "S06-A  H3N2 vaccine → PR8 H1N1, day 14", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"], 14, (0.04, 0.36)),
          ("S06-C", "S06-C  bivalent → rgH5N1, day 14\n[S06-D (day 3) is cell-for-cell identical]", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"], 14, (0.04, 0.36)),
          ("S06-E [rows34-68]", "S06-E(1)  H3N2 vaccine → PR8 H1N1, day 60", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)", "Untreated"], 14, (0.55, 0.60)),
          ("S06-F [rows34-68]", "S06-F(1)  bivalent → rgH5N1, day 60", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)", "Untreated"], 14, (0.55, 0.60)),
          ("S06-G", "S06-G  H1N1 vaccine → Perth H3N2, day 60", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)", "Untreated"], 14, (0.04, 0.40)),
          None,
          ("S15-L", "S15-L  aged C57BL/6, bivalent\n(challenge virus/day not stated)", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"], 14, (0.04, 0.36)),
          ("S15-N", "S15-N  aged Swiss Webster, bivalent\n(challenge virus/day not stated)", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"], 14, (0.04, 0.36)),
          ("S06-E [rows71-105(imprint/PR8)]", "S06-E(2)  14-mo, naive vs PR8-imprinted\n→ PR8 H1N1 (day not stated)", ["Naive+PSLN-212", "Imprinting+PSLN-212", "Naive+PSLN-344", "Imprinting+PSLN-344"], 14, (0.60, 0.42)),
          ("S06-F [rows71-105(imprint/Perth)]", "S06-F(2)  14-mo, naive vs PR8-imprinted\n→ Perth H3N2, day 14", ["Naive+PSLN-212", "Imprinting+PSLN-212", "Naive+PSLN-344", "Imprinting+PSLN-344"], 14, (0.60, 0.70)),
          None]
fig, axes = plt.subplots(3, 5, figsize=(19.5, 11))
for ax, p in zip(axes.ravel(), panels):
    if p is None:
        ax.axis("off"); continue
    bp, title, groups, win, (tx, ty) = p
    km_plot(ax, bp, groups, win)
    ax.set_title(title, loc="left")
    for k, g in enumerate(groups):
        d = S[(S.block_panel == bp) & (S.group == g) & S.day.notna()]
        ax.text(tx, ty - 0.075 * k, f"{g}: {int((d.event == 0).sum())}/{len(d)}", transform=ax.transAxes, color=COL.get(g, "k"), fontsize=7.6, va="top", clip_on=False,
                fontweight="bold" if "344" in g else "normal", bbox=dict(facecolor="white", edgecolor="none", alpha=0.75, pad=0.4))
    ax.set_xlabel("Days after challenge"); ax.set_ylabel("Survival (%)")
handles = [Line2D([0], [0], color=COL[g], lw=2.2, ls="--" if g == "Untreated" else "-", label=LAB[g]) for g in ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)", "CMP-204", "Untreated"]]
handles += [Line2D([0], [0], color=COL["3d PSLN-344"], lw=2.2, label="PSLN-344 alone, no antigen (S15-H)")]
axes[1, 4].legend(handles=handles, loc="center", frameon=False, fontsize=9.5, title="Arms", title_fontsize=10)
axes[2, 4].text(0.0, 0.95, "Reading notes\n\n• Text in each panel = survivors / n at the end of\n  the observation window (14 d; 21 d in S03-J).\n• Curves are offset by 1–2 % so that overlapping\n  arms stay visible.\n• Row 1: challenge 2–3 d or 14 d after one dose.\n• Row 2: 14 d and 60 d after one dose.\n• Row 3: other strains; prior-infection (imprinting).\n• 'Untreated' animals were never challenged:\n  their deaths are background mortality at\n  ≥22 months of age.",
                transform=axes[2, 4].transAxes, va="top", fontsize=9)
fig.suptitle("Figure 1. Kaplan–Meier survival after lethal influenza challenge — every aged-animal time-to-event block in the workbook", y=0.995, fontsize=12)
fig.tight_layout(rect=[0, 0, 1, 0.975]); fig.savefig(f"{FIG}/fig1_survival_KM_all_aged_experiments.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 2 forest
K = pd.read_csv(f"{TAB}/T2b_survival_key_contrasts.csv"); T3 = pd.read_csv(f"{TAB}/T3_survival_pooled_and_sensitivity.csv")
order = ["S03-J", "S06-B", "S15-H", "S06-D", "S03-I", "S06-A", "S06-C", "S06-E(1)", "S06-F(1)", "S06-G", "S15-L", "S15-N", "S06-E(2)", "S06-F(2)"]
desc = {"S03-J": "wt H5N1, d2", "S06-B": "H3N2→PR8, d3", "S15-H": "biv→rgH5N1, d3", "S06-D": "biv→rgH5N1, d3 (dup. of S06-C)", "S03-I": "homologous CA09, d14", "S06-A": "H3N2→PR8, d14",
        "S06-C": "biv→rgH5N1, d14", "S06-E(1)": "H3N2→PR8, d60", "S06-F(1)": "biv→rgH5N1, d60", "S06-G": "H1N1→Perth H3N2, d60", "S15-L": "aged C57BL/6", "S15-N": "aged Swiss Webster"}
fig, axs = plt.subplots(1, 2, figsize=(16, 6.8), sharey=False)
for ax, ctl, ttl, pool_rows in ((axs[0], "Sham", "A. PSLN-344 vs Sham / vaccine-alone (aged)", ["A2", "A4", "A5"]), (axs[1], "PSLN-212", "B. PSLN-344 vs PSLN-212, the non-Mn parent (aged)", ["B2", "B3", "B4"])):
    rows = []
    for e in order:
        if ctl == "Sham":
            d = K[(K.experiment == e) & (((K.trt == "PSLN-344") & (K.ctl == "Sham")) | ((K.trt == "3d Vaccine+PSLN-344") & (K.ctl == "3d Vaccine")))]
            for _, r in d.iterrows(): rows.append((f"{e}  {desc.get(e, '')}", r))
        else:
            d = K[(K.experiment == e) & (K.trt == "PSLN-344") & (K.ctl == "PSLN-212")]
            for _, r in d.iterrows(): rows.append((f"{e}{'†' if e in ('S03-I', 'S03-J') else ''}  {desc.get(e, '')}", r))
            if e in ("S06-E(2)", "S06-F(2)"):
                for a, b, nm in (("Naive+PSLN-344", "Naive+PSLN-212", "naive"), ("Imprinting+PSLN-344", "Imprinting+PSLN-212", "PR8-imprinted")):
                    d = K[(K.experiment == e) & (K.trt == a) & (K.ctl == b)]
                    for _, r in d.iterrows(): rows.append((f"{e}  14-mo {nm} → {'PR8' if e == 'S06-E(2)' else 'Perth H3N2'}", r))
    y = len(rows) + len(pool_rows) + 1
    yt, yl = [], []
    for lab, r in rows:
        dup = "S06-D" in lab
        ax.errorbar(r.risk_diff_pct, y, xerr=[[r.risk_diff_pct - r.rd_lo], [r.rd_hi - r.risk_diff_pct]], fmt="s", color="#9aa7bd" if dup else "#1f4e9c", ms=6, capsize=2.5, lw=1.2)
        ax.text(103, y, f"{r.trt_surv} v {r.ctl_surv}", va="center", fontsize=8, color="#777777" if dup else "k")
        yt.append(y); yl.append(lab); y -= 1
    y -= 0.5
    nm = {"A2": "POOLED, 11 experiments (S06-D dropped)", "A4": "POOLED, worst case from weight blocks", "A5": "POOLED, BALB/c only",
          "B2": "POOLED, 14 strata (S06-D dropped)", "B3": "POOLED, worst case for PSLN-344 / best for PSLN-212", "B4": "POOLED, ≥20-mo BALB/c, label-conflict blocks dropped"}
    for pr in pool_rows:
        r = T3[T3.analysis.str.startswith(pr)].iloc[0]
        ax.errorbar(r.MH_RD_pct, y, xerr=[[r.MH_RD_pct - r.RD_lo], [r.RD_hi - r.MH_RD_pct]], fmt="D", color="#b2182b", ms=7, capsize=3, lw=1.6)
        ax.text(103, y, f"{r.trt_surv} v {r.ctl_surv}", va="center", fontsize=8, fontweight="bold")
        yt.append(y); yl.append(nm[pr]); y -= 1
    ax.axvline(0, color="k", lw=0.8); ax.set_xlim(-45, 158); ax.set_xticks([-25, 0, 25, 50, 75, 100])
    ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8); ax.set_title(ttl, loc="left", fontsize=10)
    ax.set_xlabel("Survival difference, percentage points\n(single experiments: Newcombe 95% CI; pooled: Mantel–Haenszel 95% CI)")
fig.suptitle("Figure 2. Survival benefit of PSLN-344 in aged mice, experiment by experiment and pooled (survivors/n shown at right)", fontsize=10.5, y=0.995)
fig.text(0.995, 0.008, "† the arm labelled PSLN-212 in this survival block carries a different name in the paired weight block (register A4, A5); grey = S06-D, identical to S06-C and not pooled", ha="right", fontsize=7.5, color="#555555")
fig.tight_layout(rect=[0, 0.02, 1, 0.97]); fig.savefig(f"{FIG}/fig2_survival_forest.png"); plt.close(fig)
print("fig1, fig2 written")

# ------------------------------------------------------------------ Fig 3 restoration index
RI = pd.read_csv(f"{TAB}/T6_restoration_index.csv")
sel = [("Innate / recruitment", [("S01-A [16h]", None, "Ifnb1, lung, 16 h (S01-A)"), ("S01-D", "4", "Lung monocytes, d4 (S01-D)"), ("S01-E", "4", "Lung CD11b+ DC, d4 (S01-E)"),
                                  ("S01-F", None, "Lung cDC1, 72 h (S01-F)"), ("S11-A", "4", "Alveolar macrophages, d4 (S11-A)‡")]),
       ("DC migration / function", [("S02-A", None, "CCR7+ migratory CD11b+ DC (S02-A)"), ("S02-B", None, "MLN CD11b+ DC (S02-B)"), ("S02-C", None, "Antigen+ DC in MLN (S02-C)"),
                                    ("S02-E", None, "Cross-priming of OT-I by MLN DC (S02-E)"), ("S02-D CD40", None, "CD40+ of MLN CD11b+ DC (S02-D)"), ("S02-D CD86", None, "CD86+ of MLN CD11b+ DC (S02-D)")]),
       ("Humoral", [("S03-A", None, "Serum IgG anti-H1N1, d14 (S03-A)"), ("S03-E", None, "Serum IgG anti-H3N2, d14 (S03-E)"), ("S03-C", None, "HAI H1N1, d14 (S03-C)"), ("S03-G", None, "HAI H3N2, d14 (S03-G)"),
                    ("S03-D", None, "Neutralising titre H1N1 (S03-D)"), ("S03-H", None, "Neutralising titre H3N2 (S03-H)"), ("S03-K", None, "GC B cells, MLN, d7 (S03-K)"),
                    ("S04-A [ICOS+]", None, "ICOS+ Tfh, MLN, d7 (S04-A)"), ("S13-H", None, "IgG+ B cells, MLN (S13-H)"), ("S13-I", None, "IgG anti-H1N1 after boost, d28 (S13-I)")]),
       ("CD8 T cells", [("S05-D", None, "Ki-67+ CD8, lung, d3 (S05-D)"), ("S05-E", None, "GZMB+ CD8, lung, d3 (S05-E)"), ("S05-F", None, "IFN-γ+ CD8 to rgH5N1, d14 (S05-F)"),
                        ("S05-G", None, "IFN-γ+ CD8 to rgH5N1, d60 (S05-G)"), ("S05-I", None, "Lung CD8 TRM, d25 (S05-I)"), ("S14-A H1N1", None, "IFN-γ+ CD8 to H1N1 (S14-A)"), ("S14-A H3N2", None, "IFN-γ+ CD8 to H3N2 (S14-A)")]),
       ("Regulatory (lower = younger)", [("S04-B Foxp3", None, "Tfr, MLN, d7 (S04-B)"), ("S04-C", None, "Tfr, MLN, d30 (S04-C)"), ("S04-D", None, "Lung Treg, d7, n=3 (S04-D)"), ("S11-E", None, "CD206+ macrophages (S11-E)")])]
rows = []
for grp, items in sel:
    for bp, x, lab in items:
        d = RI[(RI.block == bp) & ((RI.x.astype(str) == str(x)) if x is not None else RI.x.isna())]
        if len(d) == 0: print("missing RI", bp, x); continue
        r = d.iloc[0]; rows.append((grp, lab, r.RI, r.RI_lo, r.RI_hi))
fig, ax = plt.subplots(figsize=(9.8, 10.6))
y = len(rows) + len(sel); yt, yl = [], []
gcol = {"Innate / recruitment": "#4d4d4d", "DC migration / function": "#8c510a", "Humoral": "#1f4e9c", "CD8 T cells": "#b2182b", "Regulatory (lower = younger)": "#35a055"}
ax.axvline(0, color="#e08214", lw=1.6, zorder=1); ax.axvline(1, color="#35a055", lw=1.6, zorder=1)
last = None
for grp, lab, est, lo, hi in rows:
    if grp != last:
        ax.text(-0.62, y, grp, fontweight="bold", fontsize=9, color=gcol[grp], va="center", zorder=5, bbox=dict(facecolor="white", edgecolor="none", pad=1.5)); y -= 1; last = grp
    ax.errorbar(est, y, xerr=[[est - max(lo, -0.6)], [min(hi, 1.75) - est]], fmt="o", color=gcol[grp], ms=5.5, capsize=2.5, lw=1.3, zorder=4)
    yt.append(y); yl.append(lab); y -= 1
import matplotlib.transforms as mtrans
tr = mtrans.blended_transform_factory(ax.transData, ax.transAxes)
ax.text(0, 1.005, "aged + PSLN-212\n(no Mn) = 0", ha="center", va="bottom", color="#e08214", fontsize=8.5, transform=tr)
ax.text(1, 1.005, "young + PSLN-212\n(benchmark) = 1", ha="center", va="bottom", color="#35a055", fontsize=8.5, transform=tr)
ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8.2); ax.set_xlim(-0.65, 1.8); ax.set_ylim(0.2, len(rows) + len(sel) + 0.8)
ax.set_xlabel("Restoration index = (PSLN-344 − PSLN-212) / (young benchmark − PSLN-212), aged mice\npoint = estimate on the analysis scale; bars = bootstrap 95% CI (n = 5 per group unless stated)")
ax.set_title("Figure 3. How much of the age gap PSLN-344 closes, readout by readout", loc="left", fontsize=10.5, pad=34)
fig.text(0.01, 0.005, "‡ S11-A shares 35 of 100 cell values with S11-B (neutrophils); shown for completeness, not relied on.", fontsize=7.5, color="#555555")
fig.tight_layout(rect=[0, 0.015, 1, 1]); fig.savefig(f"{FIG}/fig3_restoration_index.png"); plt.close(fig)

# helpers
def dots(ax, bp, groups, x=None, log=False, labels=None, hai=False, jitter=0.10, seed=0):
    rng = np.random.default_rng(seed)
    for i, g in enumerate(groups):
        v = vec(bp, g, x)
        if hai: v = np.where(v <= 0, 5, v)
        xs = i + rng.uniform(-jitter, jitter, len(v))
        ax.scatter(xs, v, s=22, color=COL.get(g, "k"), alpha=0.85, zorder=3, edgecolor="white", linewidth=0.4)
        m = 10 ** np.log10(v).mean() if log else v.mean()
        ax.plot([i - 0.28, i + 0.28], [m, m], color=COL.get(g, "k"), lw=2.2, zorder=4)
    if log: ax.set_yscale("log")
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(labels or groups, rotation=35, ha="right", fontsize=7.8)
SH = {"Sham": "Sham", "CMP-204": "CMP-204", "PSLN-212": "PSLN-212", "PSLN-344": "PSLN-344", "PSLN-212(Y)": "PSLN-212\n(young)", "PSLN-344(Y)": "PSLN-344\n(young)",
      "PSLN-R848": "PSLN-R848", "PSLN-212/R848": "PSLN-212\n/R848", "Vaccine": "Vaccine\nalone"}

# ------------------------------------------------------------------ Fig 4 mechanism chain
fig, axes = plt.subplots(2, 4, figsize=(17, 8.2))
ax = axes[0, 0]; gs = ["Sham", "CMP-204", "PSLN-R848", "PSLN-212", "PSLN-212/R848", "PSLN-344", "PSLN-212(Y)", "PSLN-344(Y)"]
dots(ax, "S01-A [16h]", gs, log=True, labels=[SH[g].replace("\n", " ") for g in gs]); ax.set_ylabel("Ifnb1, fold vs untreated (log scale)"); ax.set_title("A. Lung Ifnb1, 16 h, no vaccine (S01-A; n=5)\nbar = geometric mean", loc="left")
ax = axes[0, 1]
dr = pd.read_csv(f"{TAB}/T7_dose_response_S08A.csv"); dd = np.linspace(0.8, 45, 200)
for g in ["CMP-204", "PSLN-212", "PSLN-344"]:
    for d_ in [1, 5, 10, 20, 40]:
        v = vec("S08-A", g, d_); ax.scatter([d_] * 3, v, s=18, color=COL[g], alpha=0.8, zorder=3)
    r = dr[dr.group == g].iloc[0]
    ax.plot(dd, 1 + (r.Emax - 1) * dd ** r.hill / (r.ED50 ** r.hill + dd ** r.hill), color=COL[g], lw=1.8, label=f"{g}: Emax {r.Emax:.0f}, ED50 {r.ED50:.0f} µg")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xticks([1, 5, 10, 20, 40]); ax.set_xticklabels(["1", "5", "10", "20", "40"]); ax.axvline(20, color="k", lw=0.7, ls=":")
ax.set_xlabel("Adjuvant dose per mouse, µg (dotted: efficacy dose)"); ax.set_ylabel("Ifnb1, fold vs untreated"); ax.legend(frameon=False, fontsize=7.5, loc="upper left")
ax.set_title("B. Dose–response, Ifnb1 16 h (S08-A; n=3/dose)\nthe only dose-ranging in the package", loc="left")
def tc(ax, bp, groups, log=False, ylabel="", days=None):
    d = M[M.block_panel == bp]
    xs_all = list(dict.fromkeys(d.x.astype(str)))
    for g in groups:
        ms, sds = [], []
        for x in xs_all:
            v = vec(bp, g, x); ms.append(10 ** np.log10(v).mean() if log else v.mean()); sds.append(v.std(ddof=1))
            ax.scatter([xs_all.index(x)] * len(v), v, s=9, color=COL[g], alpha=0.45, zorder=2)
        ax.plot(range(len(xs_all)), ms, "-o", color=COL[g], lw=1.8, ms=4, label=SH.get(g, g).replace("\n", " "), zorder=3)
    ax.set_xticks(range(len(xs_all))); ax.set_xticklabels(days or xs_all); ax.set_ylabel(ylabel)
    if log: ax.set_yscale("log")
ax = axes[0, 2]; tc(ax, "S02-F", ["Sham", "PSLN-212", "PSLN-344"], log=True, ylabel="Gm-csf, fold vs untreated (log)"); ax.set_xlabel("Time after vaccine + adjuvant")
ax.set_title("C. Lung Gm-csf transcript (S02-F; n=5)\nno young arm was run", loc="left"); ax.legend(frameon=False, fontsize=7.5)
ax = axes[0, 3]; tc(ax, "S01-D", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"], ylabel="Lung monocytes (%)"); ax.set_xlabel("Days after vaccine + adjuvant")
ax.set_title("D. Lung CD11b+Ly6C+ monocytes (S01-D; n=5/day)", loc="left"); ax.legend(frameon=False, fontsize=7.5)
ax = axes[1, 0]; tc(ax, "S01-E", ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)", "PSLN-344(Y)"], ylabel="Lung CD11b+ DC (%)"); ax.set_xlabel("Days after vaccine + adjuvant")
ax.set_title("E. Lung CD11b+ dendritic cells (S01-E; n=5/day)", loc="left"); ax.legend(frameon=False, fontsize=7.2)
ax = axes[1, 1]
items = [("S02-H", "WT w/o cDC", "WT marrow"), ("S02-H", "IFN w/o cDC", "Ifnar-KO\nmarrow"), ("S02-H", "GMCSF", "Ifnar-KO\n+ rGM-CSF")]
rng = np.random.default_rng(1)
for i, (bp, g, lab) in enumerate(items):
    v = vec(bp, g); ax.scatter(i + rng.uniform(-.1, .1, len(v)), v, s=22, color=["#1f4e9c", "#b2182b", "#35a055"][i], zorder=3); ax.plot([i - .28, i + .28], [v.mean()] * 2, color="k", lw=2)
ax.set_xticks(range(3)); ax.set_xticklabels([i[2] for i in items], fontsize=8); ax.set_ylabel("Donor-derived moDC (%)")
ax.set_title("F. moDC need IFNAR; rGM-CSF rescues 59%\n(S02-H; pre-cDC-depleted marrow; n=5)", loc="left")
ax = axes[1, 2]
items = [("S02-G", "GM-CSF", "rGM-CSF\nalone"), ("S02-G", "PSLN-212", "PSLN-212"), ("S02-G", "PSLN-212+GM-CSF", "PSLN-212\n+ rGM-CSF")]
for i, (bp, g, lab) in enumerate(items):
    v = vec(bp, g); ax.scatter(i + rng.uniform(-.1, .1, len(v)), v, s=22, color=["#7f7f7f", "#e08214", "#35a055"][i], zorder=3); ax.plot([i - .28, i + .28], [v.mean()] * 2, color="k", lw=2)
ax.set_xticks(range(3)); ax.set_xticklabels([i[2] for i in items], fontsize=8); ax.set_ylabel("Ly6C+CD11c+MHC-II+ cells, lung, d5 (%)")
ax.set_title("G. rGM-CSF add-back to PSLN-212, aged (S02-G; n=5)", loc="left")
ax = axes[1, 3]
items = [("S11-C", "CBX-", "CBX+", "Monocytes\n± CBX\n(S11-C)"), ("S07-B [CD11b+Ly6C+ Monocytes]", "PSLN-344", "PSLN-344+INCB3344", "Monocytes\n± CCR2i\n(S07-B)"),
         ("S02-I", "PSLN-344(Y)", "PSLN-344(Y)+INCB3344", "GZMB+ CD8\n± CCR2i\n(S02-I, YOUNG)")]
for i, (bp, g1, g2, lab) in enumerate(items):
    for j, g in enumerate((g1, g2)):
        v = vec(bp, g); xx = i * 2.6 + j
        ax.scatter(xx + rng.uniform(-.1, .1, len(v)), v, s=22, color="#1f4e9c" if j == 0 else "#b2182b", zorder=3); ax.plot([xx - .3, xx + .3], [v.mean()] * 2, color="k", lw=2)
ax.set_xticks([0.5, 3.1, 5.7]); ax.set_xticklabels([i[3] for i in items], fontsize=8); ax.set_ylabel("% of parent gate")
ax.scatter([], [], color="#1f4e9c", label="PSLN-344 + vaccine"); ax.scatter([], [], color="#b2182b", label="+ inhibitor"); ax.legend(frameon=False, fontsize=7.5)
ax.set_title("H. Blocking gap junctions (CBX) or CCR2 (INCB3344)", loc="left")
fig.suptitle("Figure 4. Pharmacodynamic chain in aged lungs: STING/IFN-β → GM-CSF → monocyte recruitment → monocyte-derived DC → CD8 T cells  (all aged BALB/c unless marked young)", fontsize=10.5, y=0.995)
fig.tight_layout(rect=[0, 0, 1, 0.97]); fig.savefig(f"{FIG}/fig4_mechanism_chain.png"); plt.close(fig)
print("fig3, fig4 written")

# ------------------------------------------------------------------ Fig 5 adaptive immunity
fig, axes = plt.subplots(2, 5, figsize=(19, 8.4))
G5 = ["Sham", "CMP-204", "PSLN-212", "PSLN-344", "PSLN-212(Y)"]; G4 = ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"]; G3 = ["PSLN-212", "PSLN-344", "PSLN-212(Y)"]
ax = axes[0, 0]; dots(ax, "S03-A", G5, log=True, labels=[SH[g] for g in G5]); ax.set_ylabel("Reciprocal endpoint titre"); ax.set_title("A. Serum IgG anti-CA09 H1N1, d14 (S03-A)", loc="left")
ax = axes[0, 1]; dots(ax, "S03-C", G5, log=True, labels=[SH[g] for g in G5], hai=True, jitter=0.16); ax.axhline(40, color="k", ls=":", lw=0.8); ax.axhline(10, color="#999999", ls="--", lw=0.7)
ax.text(4.45, 42, "1:40", fontsize=7, ha="right"); ax.text(4.45, 10.5, "LLOQ 1:10", fontsize=7, ha="right", color="#777777"); ax.set_ylabel("HAI titre (<10 plotted at 5)")
ax.set_title("B. HAI anti-CA09 H1N1, d14 (S03-C)", loc="left")
ax = axes[0, 2]; dots(ax, "S03-D", G5, log=True, labels=[SH[g] for g in G5], jitter=0.16); ax.set_ylabel("Neutralising titre"); ax.set_title("C. Neutralising titre, CA09 H1N1, d14 (S03-D)", loc="left")
ax = axes[0, 3]
rng = np.random.default_rng(5)
for i, g in enumerate(G3):
    rec = vec("S13-A", g) / vec("S13-B", g); pr = vec("S03-B", g)
    ax.scatter(i - 0.17 + rng.uniform(-.05, .05, 5), rec, s=24, color=COL[g], zorder=3, label="recomputed from raw titres (S13-A ÷ S13-B)" if i == 0 else None)
    ax.scatter(i + 0.17 + rng.uniform(-.05, .05, 5), pr, s=24, facecolor="none", edgecolor=COL[g], marker="s", zorder=3, label="as printed in quotient block S03-B" if i == 0 else None)
    ax.plot([i - .3, i - .04], [10 ** np.log10(rec).mean()] * 2, color=COL[g], lw=2.2); ax.plot([i + .04, i + .3], [10 ** np.log10(pr).mean()] * 2, color=COL[g], lw=1.2, ls="--")
ax.set_yscale("log"); ax.axhline(1, color="k", lw=0.7, ls=":"); ax.set_xticks(range(3)); ax.set_xticklabels([SH[g] for g in G3], fontsize=7.8, rotation=35, ha="right")
ax.set_ylabel("IgG2a / IgG1 (anti-H1N1)"); ax.set_ylim(0.12, 9); ax.set_yticks([0.25, 0.5, 1, 2, 4]); ax.set_yticklabels(["0.25", "0.5", "1", "2", "4"]); ax.minorticks_off()
ax.legend(frameon=False, fontsize=6.8, loc="lower center"); ax.set_title("D. IgG2a:IgG1 — printed labels are rotated", loc="left")
ax = axes[0, 4]; dots(ax, "S13-I", G5, log=True, labels=[SH[g] for g in G5]); ax.set_ylabel("Reciprocal endpoint titre"); ax.set_title("E. IgG anti-H1N1 after d14 boost, d28 (S13-I)", loc="left")
ax = axes[1, 0]; dots(ax, "S03-K", G4, labels=[SH[g] for g in G4]); ax.set_ylabel("GC B cells in MLN (%)"); ax.set_title("F. Germinal-centre B cells, d7 (S03-K)", loc="left")
ax = axes[1, 1]; dots(ax, "S04-A [ICOS+]", G4, labels=[SH[g] for g in G4]); ax.set_ylabel("ICOS+ Tfh in MLN (%)"); ax.set_title("G. ICOS+ Tfh, d7 (S04-A)", loc="left")
ax = axes[1, 2]
for i, g in enumerate(G4):
    for j, (bp, mk) in enumerate((("S04-B Foxp3", "o"), ("S04-C", "^"))):
        v = vec(bp, g); xx = i + (j - 0.5) * 0.36
        ax.scatter(xx + rng.uniform(-.05, .05, len(v)), v, s=22, color=COL[g], marker=mk, alpha=0.9 if j == 0 else 0.55, zorder=3); ax.plot([xx - .14, xx + .14], [v.mean()] * 2, color=COL[g], lw=2)
ax.scatter([], [], color="k", marker="o", label="d7 (S04-B)"); ax.scatter([], [], color="k", marker="^", alpha=0.55, label="d30 (S04-C)"); ax.legend(frameon=False, fontsize=7.5)
ax.set_xticks(range(4)); ax.set_xticklabels([SH[g] for g in G4], fontsize=7.8, rotation=35, ha="right"); ax.set_ylabel("Foxp3+ of CXCR5+ICOShi CD4 (Tfr, %)"); ax.set_title("H. Tfr: lower at d7, not at d30", loc="left")
ax = axes[1, 3]
for i, g in enumerate(G4):
    for j, (bp, mk) in enumerate((("S05-F", "o"), ("S05-G", "^"))):
        v = vec(bp, g); xx = i + (j - 0.5) * 0.36
        ax.scatter(xx + rng.uniform(-.05, .05, len(v)), v, s=22, color=COL[g], marker=mk, alpha=0.9 if j == 0 else 0.55, zorder=3); ax.plot([xx - .14, xx + .14], [v.mean()] * 2, color=COL[g], lw=2)
ax.scatter([], [], color="k", marker="o", label="d14 (S05-F)"); ax.scatter([], [], color="k", marker="^", alpha=0.55, label="d60 (S05-G)"); ax.legend(frameon=False, fontsize=7.5)
ax.set_xticks(range(4)); ax.set_xticklabels([SH[g] for g in G4], fontsize=7.8, rotation=35, ha="right"); ax.set_ylabel("IFN-γ+ CD8 T cells in MLN (%)")
ax.set_title("I. Cross-reactive CD8 (rgH5N1 restim.;\nanimals got H1N1+H3N2 vaccine)", loc="left")
ax = axes[1, 4]
for i, g in enumerate(G4):
    for j, (bp, mk) in enumerate((("S05-E", "o"), ("S05-I", "^"))):
        v = vec(bp, g); xx = i + (j - 0.5) * 0.36
        ax.scatter(xx + rng.uniform(-.05, .05, len(v)), v, s=22, color=COL[g], marker=mk, alpha=0.9 if j == 0 else 0.55, zorder=3); ax.plot([xx - .14, xx + .14], [v.mean()] * 2, color=COL[g], lw=2)
ax.scatter([], [], color="k", marker="o", label="GZMB+ CD8, lung, d3 (S05-E)"); ax.scatter([], [], color="k", marker="^", alpha=0.55, label="CD8 TRM, lung, d25 (S05-I)"); ax.legend(frameon=False, fontsize=7.5)
ax.set_xticks(range(4)); ax.set_xticklabels([SH[g] for g in G4], fontsize=7.8, rotation=35, ha="right"); ax.set_ylabel("% of CD8 T cells"); ax.set_title("J. Lung CD8: effectors (d3) and TRM (d25)", loc="left")
fig.suptitle("Figure 5. Adaptive responses after one intranasal dose (aged BALB/c; young PSLN-212 = benchmark; n = 5; bars = geometric mean for titres, mean otherwise)", fontsize=10.5, y=0.995)
fig.tight_layout(rect=[0, 0, 1, 0.97]); fig.savefig(f"{FIG}/fig5_adaptive_immunity.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 6 safety / tolerability
fig = plt.figure(figsize=(18, 5.6)); gs_ = fig.add_gridspec(1, 4, width_ratios=[1.15, 1.55, 1.0, 1.0])
ax = fig.add_subplot(gs_[0, 0])
W = M[M.block == "S08-D"]
for g in ["Vaccine", "PSLN-212(Y)", "CMP-204", "PSLN-212", "PSLN-344", "PSLN-212/R848"]:
    d = W[W.group == g].groupby("x").value.agg(["mean", "std"]).sort_index()
    ax.errorbar(d.index.astype(int), d["mean"], yerr=d["std"], color=COL[g], marker="o", ms=4, lw=2.4 if g == "PSLN-344" else 1.5, capsize=2, label=SH.get(g, g).replace("\n", " "))
ax.axhline(100, color="k", lw=0.6, ls=":"); ax.set_xlabel("Days after vaccination (no challenge)"); ax.set_ylabel("Body weight, % of day 0 (mean ± SD)")
ax.legend(frameon=False, fontsize=7.5, loc="lower left"); ax.set_title("A. Post-vaccination weight (S08-D; n=5;\nR848 arm n=4 at d10)", loc="left")
ax = fig.add_subplot(gs_[0, 1])
CY = pd.read_csv(f"{TAB}/T9_lung_cytokines_S09A.csv")
gsY = ["CMP-204", "PSLN-212", "PSLN-344", "PSLN-212(Y)", "PSLN-R848", "PSLN-212/R848"]; ans = ["Ifnb1", "Il6", "Ccl2", "Ccl3", "Ccl5", "Tnf", "Il10"]
mat = np.zeros((len(gsY) * 2 + 1, len(ans))) * np.nan
for ti, tp in enumerate(["16h", "72h(inferred)"]):
    for gi, g in enumerate(gsY):
        for ai, an in enumerate(ans):
            mat[ti * (len(gsY) + 1) + gi, ai] = np.log10(CY[(CY.timepoint == tp) & (CY.analyte == an)][g].iloc[0])
im = ax.imshow(mat, cmap="RdBu_r", vmin=-3.2, vmax=3.2, aspect="auto")
for r in range(mat.shape[0]):
    for c in range(mat.shape[1]):
        if not np.isnan(mat[r, c]):
            v = 10 ** mat[r, c]; ax.text(c, r, f"{v:.0f}" if v >= 10 else f"{v:.1f}", ha="center", va="center", fontsize=7.3, color="white" if abs(mat[r, c]) > 1.7 else "k")
ax.set_xticks(range(len(ans))); ax.set_xticklabels(ans); ax.set_yticks(list(range(len(gsY))) + list(range(len(gsY) + 1, 2 * len(gsY) + 1)))
ax.set_yticklabels([f"16 h  {SH.get(g, g)}".replace("\n", " ") for g in gsY] + [f"72 h  {SH.get(g, g)}".replace("\n", " ") for g in gsY], fontsize=7.8)
ax.spines[:].set_visible(False); ax.tick_params(length=0)
ax.set_title("B. Lung transcripts, GM fold vs untreated (S09-A; n=3; log10 data)\n2nd panel printed '16h' but equals S01-A 72 h values", loc="left")
plt.colorbar(im, ax=ax, fraction=0.03, pad=0.02, label="log10 fold")
for k, an in enumerate(["Ifnb1", "Tnf"]):
    ax = fig.add_subplot(gs_[0, 2 + k]); g4 = ["PBS", "Sham", "PSLN-344", "CT"]
    dots(ax, f"S10-A [{an}]", g4, log=False, labels=["PBS", "Vaccine +\nempty lipo.", "Vaccine +\nPSLN-344", "Vaccine +\ncholera toxin"])
    ax.set_ylabel(f"{an}, fold vs untreated"); ax.axhline(1, color="k", lw=0.6, ls=":")
    ax.set_title(f"{'C' if k == 0 else 'D'}. CNS {an}, 36 h (S10-A; n=5)", loc="left")
fig.suptitle("Figure 6. Tolerability evidence available for PSLN-344 (aged BALB/c)", fontsize=10.5, y=0.995)
fig.tight_layout(rect=[0, 0, 1, 0.96]); fig.savefig(f"{FIG}/fig6_tolerability.png"); plt.close(fig)
print("fig5, fig6 written")

# ------------------------------------------------------------------ Fig 7 timing of protection + morbidity
T1 = pd.read_csv(f"{TAB}/T1_survival_by_arm.csv"); A4 = pd.read_csv(f"{TAB}/T4a_bodyweight_per_animal.csv")
fig, axes = plt.subplots(1, 3, figsize=(17, 5.4), gridspec_kw=dict(width_ratios=[1.15, 1.0, 1.25]))
ax = axes[0]
windows = [("2–3 d", ["S03-J", "S06-B", "S15-H"]), ("14 d", ["S03-I", "S06-A", "S06-C"]), ("60 d", ["S06-E(1)", "S06-F(1)", "S06-G"])]
arms = [("Sham", ["Sham", "3d Vaccine"]), ("PSLN-212", ["PSLN-212"]), ("PSLN-344", ["PSLN-344", "3d Vaccine+PSLN-344"]), ("PSLN-212(Y)", ["PSLN-212(Y)"]), ("Untreated", ["Untreated"])]
w = 0.16
for wi, (wl, exps) in enumerate(windows):
    for ai, (an, labs) in enumerate(arms):
        d = T1[T1.experiment.isin(exps) & T1.arm.isin(labs)]
        if not len(d): continue
        s, n = int(d.survivors.sum()), int(d.n.sum()); lo, hi = clopper_pearson(s, n)
        xx = wi + (ai - 2) * w
        ax.bar(xx, 100 * s / n, width=w * 0.92, color=COL[an], alpha=0.9, hatch="//" if an == "Untreated" else None, edgecolor="white")
        ax.errorbar(xx, 100 * s / n, yerr=[[100 * (s / n - lo)], [100 * (hi - s / n)]], color="k", lw=0.9, capsize=2)
        ax.text(xx, 103 if 100 * hi > 95 else 100 * hi + 3, f"{s}/{n}", ha="center", fontsize=7, rotation=90 if n > 9 else 90, va="bottom")
ax.set_xticks(range(3)); ax.set_xticklabels([f"challenge {wl}\nafter one dose" for wl, _ in windows]); ax.set_ylim(0, 128); ax.set_yticks([0, 25, 50, 75, 100]); ax.set_ylabel("Survival, % (exact 95% CI)")
hs = [plt.Rectangle((0, 0), 1, 1, color=COL[a], hatch="//" if a == "Untreated" else None) for a, _ in arms]
ax.legend(hs, ["Sham / vaccine alone, aged", "PSLN-212, aged", "PSLN-344, aged", "PSLN-212, young", "Untreated & unchallenged, aged"], frameon=False, fontsize=7.3, loc="upper center", ncol=2, bbox_to_anchor=(0.5, -0.16))
ax.set_title("A. Protection by interval between dose and challenge\n(aged BALB/c; pooled over the 3 experiments per interval; S06-D excluded)", loc="left")
ax = axes[1]
sel_b = ["S13-F", "S15-A", "S15-B", "S15-C", "S15-D", "S15-E", "S15-F", "S15-G", "S15-M", "S15-O"]
order_ = ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)", "Untreated"]
rng = np.random.default_rng(11)
for i, g in enumerate(order_):
    v = A4[A4.block.isin(sel_b) & (A4.group == g)].nadir.values
    ax.scatter(i + rng.uniform(-.22, .22, len(v)), v, s=9, color=COL[g], alpha=0.55, zorder=2)
    ax.plot([i - .3, i + .3], [v.mean()] * 2, color="k", lw=2, zorder=3); ax.text(i, 101.5, f"{v.mean():.1f}\n(n={len(v)})", ha="center", fontsize=7.5)
ax.set_xticks(range(5)); ax.set_xticklabels(["Sham", "PSLN-212", "PSLN-344", "PSLN-212\n(young)", "Untreated,\nunchallenged"], fontsize=8); ax.set_ylim(74, 106)
ax.set_ylabel("Per-animal weight nadir, % of day 0\n(carried-forward values excluded)")
ax.set_title("B. Illness is not prevented: weight nadir after challenge\n(10 aged-mouse challenge experiments; controls truncated by death)", loc="left")
ax = axes[2]
for bp, g, ls, lab in (("S15-G", "PSLN-344", "-", "PSLN-344, challenged d60 (S15-G)"), ("S15-G", "Untreated", "--", "Untreated, unchallenged (S15-G)")):
    piv = M[(M.block == bp) & (M.group == g)].pivot(index="x", columns="rep", values="value").sort_index(); piv.index = piv.index.astype(int)
    for rep in piv.columns:
        s_ = piv[rep]; vals = s_.values
        run = 1; i_ = len(vals) - 1
        while i_ > 0 and vals[i_ - 1] == vals[i_]: run += 1; i_ -= 1
        dead = run >= 2 and (g == "Untreated" and run >= 3 or g == "PSLN-344" and vals[-1] < 85)
        last = len(vals) - run if dead else len(vals) - 1
        ax.plot(piv.index[: last + 1], vals[: last + 1], ls=ls, color=COL[g], lw=1.4, alpha=0.9)
        if dead: ax.scatter([piv.index[last]], [vals[last]], marker="x", color=COL[g], s=55, zorder=4, linewidths=2)
ax.plot([], [], color=COL["PSLN-344"], label="PSLN-344 + H1N1 vaccine, challenged with Perth H3N2 at d60"); ax.plot([], [], color=COL["Untreated"], ls="--", label="Untreated, never challenged (same age)")
ax.scatter([], [], marker="x", color="k", label="last real weight before values are carried forward (death)")
ax.legend(frameon=False, fontsize=7.3, loc="lower left"); ax.set_xlabel("Days after challenge"); ax.set_ylabel("Body weight, % of day 0"); ax.set_ylim(74, 104)
ax.set_title("C. S15-G: animals that die after PSLN-344 lose ~20% first;\nunchallenged animals that die do not (background deaths)", loc="left")
fig.suptitle("Figure 7. Where the protection is weaker: durability and morbidity", fontsize=10.5, y=0.995)
fig.tight_layout(rect=[0, 0, 1, 0.96]); fig.savefig(f"{FIG}/fig7_durability_morbidity.png"); plt.close(fig)

# ------------------------------------------------------------------ Fig 8 data-integrity exhibits
fig, axes = plt.subplots(1, 4, figsize=(18.5, 4.9))
ax = axes[0]
c = M[(M.block == "S15-C") & (M.group == "PSLN-344")].pivot(index="x", columns="rep", values="value").sort_index(); c.index = c.index.astype(int)
i_ = M[(M.block == "S15-I") & (M.group == "3d Vaccine+PSLN-344")].pivot(index="x", columns="rep", values="value").sort_index(); i_.index = i_.index.astype(int)
for rep in c.columns:
    ax.plot(c.index, c[rep], color="#1f4e9c", lw=3.2, alpha=0.35); ax.plot(i_.index, i_[rep], color="#b2182b", lw=1.0, ls="--")
ax.plot([], [], color="#1f4e9c", lw=3.2, alpha=0.35, label="S15-C PSLN-344 (challenge d14)"); ax.plot([], [], color="#b2182b", ls="--", label="S15-I Vaccine+PSLN-344 (challenge d3)")
ax.legend(frameon=False, fontsize=7.5, loc="lower left"); ax.set_xlabel("Days after challenge"); ax.set_ylabel("Body weight, % of day 0")
ax.set_title("A. Two different experiments: 40 of 42\nweights identical on days 2–12", loc="left")
ax = axes[1]
a = M[M.block == "S11-A"].set_index(["group", "x", "rep"]).value; b = M[M.block == "S11-B"].set_index(["group", "x", "rep"]).value
eq = (a == b)
ax.scatter(a[~eq], b[~eq], s=12, color="#7f7f7f", alpha=0.7, label=f"different ({int((~eq).sum())})"); ax.scatter(a[eq], b[eq], s=26, color="#b2182b", label=f"identical ({int(eq.sum())})", zorder=3)
ax.plot([15, 55], [15, 55], color="k", lw=0.6); ax.set_xlabel("S11-A 'alveolar macrophages' (%)"); ax.set_ylabel("S11-B 'neutrophils' (%)"); ax.legend(frameon=False, fontsize=7.5)
ax.set_title("B. Two cell types, 35 of 100 identical values\n(same cell of the layout)", loc="left")
ax = axes[2]; ax.axis("off")
rows_ = [["Arm (count)", "S03-I label", "S13-F label"], ["7/7 survive", "PSLN-344", "PSLN-344"], ["7/7 survive", "PSLN-212(Y)", "PSLN-212(Y)"], ["0/7, slow", "Sham", "Sham"],
         ["3/7 survive", "CMP-204", "PSLN-212"], ["0/7, fast", "PSLN-212", "Naive"], ["", "", ""], ["Arm (count)", "S03-J label", "S13-G label"], ["all survive", "PSLN-344", "PSLN-344"],
         ["3–4/10 survive", "PSLN-212", "Sham"], ["1/10 survive", "Sham", "Naive"]]
tb = ax.table(cellText=rows_, loc="center", cellLoc="left", colWidths=[0.36, 0.32, 0.32]); tb.auto_set_font_size(False); tb.set_fontsize(8); tb.scale(1, 1.32)
for (r, c_), cell in tb.get_celld().items():
    cell.set_edgecolor("#cccccc")
    if r in (0, 7): cell.set_text_props(fontweight="bold"); cell.set_facecolor("#eeeeee")
    if r in (4, 5, 9, 10) and c_ > 0: cell.set_facecolor("#fde0dd")
    if r == 6: cell.set_edgecolor("white")
ax.set_title("C. Survival block vs its own weight block:\nsame animals, different arm names", loc="left")
ax = axes[3]
for k, (bp, g, col, lab) in enumerate((("S06-C", "PSLN-212", "#e08214", "PSLN-212"), ("S06-C", "Sham", "#7f7f7f", "Sham"))):
    for j, blk in enumerate(("S06-C", "S06-D")):
        d = S[(S.block_panel == blk) & (S.group == g)]
        ts, ss = km_curve(d.day.values.astype(float), d.event.values.astype(int)); ts = np.r_[ts, 14]; ss = np.r_[ss, ss[-1]]
        ax.step(ts, 100 * ss, where="post", color=col, lw=4 if j == 0 else 1.2, alpha=0.35 if j == 0 else 1, ls="-" if j == 0 else "--",
                label=f"{lab}: {blk} ({'d14' if blk == 'S06-C' else 'd3'} challenge)")
ax.legend(frameon=False, fontsize=7.3, loc="upper right"); ax.set_xlabel("Days after challenge"); ax.set_ylabel("Survival (%)"); ax.set_ylim(-5, 105)
ax.set_title("D. S06-C and S06-D: every arm has the same\ndeath days (56 of 56 cells identical)", loc="left")
fig.suptitle("Figure 8. Examples of the record-integrity findings that must be reconciled against source before individual blocks are quoted", fontsize=10.5, y=0.995)
fig.tight_layout(rect=[0, 0, 1, 0.95]); fig.savefig(f"{FIG}/fig8_integrity_exhibits.png"); plt.close(fig)
print("fig7, fig8 written")

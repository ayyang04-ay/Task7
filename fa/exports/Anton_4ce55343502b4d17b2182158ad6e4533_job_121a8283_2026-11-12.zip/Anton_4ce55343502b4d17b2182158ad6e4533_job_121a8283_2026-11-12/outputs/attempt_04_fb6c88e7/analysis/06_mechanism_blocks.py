"""
06_mechanism_blocks.py -- two-way ANOVA for time-course blocks (stated method) and the intervention / two-group mechanism blocks.
Reduction: cross-sectional animals at each day (terminal sampling) -> two-way fixed-effects ANOVA (group, day, group x day), type II SS,
on the linear scale for percentages and log10 for transcripts/counts; Tukey on the group x day cells is summarised by the per-day
contrasts already in T5b.  Two-group blocks: Student t (stated), Welch, exact Mann-Whitney.
"""
import numpy as np, pandas as pd
import statsmodels.api as sm, statsmodels.formula.api as smf
from parse_workbook import load
from stats_utils import *
OUT = "/tmp/outputs/tables"
M, S = load(); M = M[M.value.notna()].copy(); M["value"] = M.value.astype(float)
def vec(bp, g, x=None):
    d = M[(M.block_panel == bp) & (M.group == g)]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    return d.sort_values("rep").value.values
rows = []
for bp, log in (("S01-D", False), ("S01-E", False), ("S02-F", True), ("S07-A", True), ("S11-A", False), ("S11-B", False), ("S11-D", False), ("S08-A", True), ("S05-A [Lung]", False), ("S05-B [MLN]", False)):
    d = M[M.block_panel == bp].copy()
    d["y"] = np.log10(d.value) if log else d.value
    d["g"] = d.group.astype(str); d["t"] = d.x.astype(str)
    fit = smf.ols("y ~ C(g) * C(t)", data=d).fit()
    a = sm.stats.anova_lm(fit, typ=2)
    rows.append(dict(block=bp, scale="log10" if log else "linear", n_obs=len(d), p_group=a.loc["C(g)", "PR(>F)"], p_time=a.loc["C(t)", "PR(>F)"], p_interaction=a.loc["C(g):C(t)", "PR(>F)"],
                     F_group=a.loc["C(g)", "F"], df_resid=int(a.loc["Residual", "df"])))
A2 = pd.DataFrame(rows); A2.to_csv(f"{OUT}/T11_two_way_anova_timecourses.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)
print(A2.to_string(index=False, float_format=lambda v: f"{v:.3g}"))

print("\n=== two-group / intervention blocks ===")
two = [("S01-C", "WT", "SPA/D", False, "DiD+ alveolar macrophages %, WT vs Sftpa1-/-Sftpd-/-"),
       ("S01-B", "AECII/PSLN-SRB", "AECII/FreeSRB", False, "SRB+ AECII %, liposomal vs free SRB"),
       ("S01-B", "AECI/PSLN-SRB", "AECI/FreeSRB", False, "SRB+ AECI %, liposomal vs free SRB"),
       ("S11-C", "CBX-", "CBX+", False, "recruited monocytes % d3, PSLN-344 +/- carbenoxolone"),
       ("S07-B [CD11b+Ly6C+ Monocytes]", "PSLN-344", "PSLN-344+INCB3344", False, "lung monocytes %, PSLN-344 +/- CCR2 antagonist"),
       ("S07-B [Ly6C+ Mphi]", "PSLN-344", "PSLN-344+INCB3344", False, "Ly6C+ macrophages %, PSLN-344 +/- CCR2 antagonist"),
       ("S02-I", "PSLN-344(Y)", "PSLN-344(Y)+INCB3344", False, "lung GZMB+ CD8 % d5, YOUNG, PSLN-344 +/- CCR2 antagonist"),
       ("S12-A", "WT to WT", "IFNAR-/- to WT", False, "infiltrating CD45.2+ monocytes % d3 (young)"),
       ("S07-C", "Ly6C-CD206+ Mphi [col B]", "Ly6C-CD206+ Mphi [col C]", False, "lung Treg % after macrophage transfer (both columns carry the same printed label)"),
       ("S05-C", "Lung", "Lung+PTX", False, "OT-I proliferation % in lung +/- pertussis toxin"),
       ("S05-C", "MLN", "MLN+PTX", False, "OT-I proliferation % in MLN +/- pertussis toxin"),
       ("S02-G", "PSLN-212+GM-CSF", "PSLN-212", False, "Ly6C+CD11c+MHC-II+ cells % d5, aged, PSLN-212 +/- rGM-CSF"),
       ("S02-G", "PSLN-212", "GM-CSF", False, "same, PSLN-212 vs rGM-CSF alone"),
       ("S02-H", "WT w/o cDC", "IFN w/o cDC", False, "CD45.2+ moDC %, WT vs Ifnar-KO marrow (pre-cDC removed)"),
       ("S02-H", "GMCSF", "IFN w/o cDC", False, "CD45.2+ moDC %, Ifnar-KO marrow + rGM-CSF vs Ifnar-KO marrow"),
       ("S02-H", "GMCSF", "WT w/o cDC", False, "CD45.2+ moDC %, Ifnar-KO marrow + rGM-CSF vs WT marrow"),
       ("S02-H", "WT w/ cDC", "WT w/o cDC", False, "CD45.2+ moDC %, WT marrow with vs without pre-cDC"),
       ("S02-C", "PSLN-344", "PTX", False, "OVA-AF647+ DC in MLN %, PSLN-344 vs PTX group"),
       ("S02-E", "PSLN-344", "PTX", False, "OT-I proliferation with MLN CD11b+ DC %, PSLN-344 vs PTX group"),
       ("S08-C", "AECII-PSLN-SRB", "AECII-PSLN-344-SRB", False, "SRB+ AECII %, as printed"),
       ("S08-C", "AECI-PSLN-SRB", "AECI-PSLN-344-SRB", False, "SRB+ AECI %, as printed"),
       ("S08-C", "AECII-PSLN-SRB", "AECI-PSLN-SRB", False, "alternative column reading: AECII PSLN-SRB vs PSLN-344-SRB"),
       ("S08-C", "AECII-PSLN-344-SRB", "AECI-PSLN-344-SRB", False, "alternative column reading: AECI PSLN-SRB vs PSLN-344-SRB"),
       ]
out = []
for bp, g1, g2, log, desc in two:
    a, b = vec(bp, g1), vec(bp, g2)
    d, lo, hi = diff_ci(a, b)
    out.append(dict(block=bp, description=desc, g1=g1, g2=g2, n1=len(a), n2=len(b), mean1=a.mean(), sd1=a.std(ddof=1), mean2=b.mean(), sd2=b.std(ddof=1), diff=d, lo=lo, hi=hi,
                    pct_change=100 * (a.mean() - b.mean()) / b.mean(), p_student=student(a, b)[1], p_welch=welch(a, b)[1], p_mwu_exact=mwu_exact(a, b)))
TW = pd.DataFrame(out); TW.to_csv(f"{OUT}/T12_two_group_mechanism_blocks.csv", index=False)
print(TW[["block", "description", "mean1", "mean2", "diff", "lo", "hi", "p_student", "p_welch", "p_mwu_exact"]].round(3).to_string(index=False))
# S02-H one-way ANOVA + Tukey
g = {k: vec("S02-H", k) for k in ["WT w/o cDC", "WT w/ cDC", "IFN w/o cDC", "IFN w/ cDC", "GMCSF"]}
F, pA, tk = tukey(g)
print("\nS02-H Tukey: WT w/o vs IFN w/o p=%.2g; GMCSF vs IFN w/o p=%.3g; GMCSF vs WT w/o p=%.3g; rescue fraction = %.0f%%" % (
    tk[("WT w/o cDC", "IFN w/o cDC")], tk[("GMCSF", "IFN w/o cDC")], tk[("GMCSF", "WT w/o cDC")],
    100 * (g["GMCSF"].mean() - g["IFN w/o cDC"].mean()) / (g["WT w/o cDC"].mean() - g["IFN w/o cDC"].mean())))
g = {k: vec("S02-G", k) for k in ["GM-CSF", "PSLN-212", "PSLN-212+GM-CSF"]}
F, pA, tk = tukey(g)
print("S02-G Tukey: PSLN-212+GM-CSF vs PSLN-212 p=%.2g; vs GM-CSF p=%.2g; PSLN-212 vs GM-CSF p=%.3g" % (tk[("PSLN-212+GM-CSF", "PSLN-212")], tk[("PSLN-212+GM-CSF", "GM-CSF")], tk[("PSLN-212", "GM-CSF")]))
g = {k: vec("S02-C", k) for k in ["PSLN-212", "PSLN-344", "PSLN-212(Y)", "PTX", "PSLN-344(Y)"]}
F, pA, tk = tukey(g)
print("S02-C Tukey: PSLN-344 vs PSLN-212 p=%.2g; PSLN-344 vs PTX p=%.2g; PSLN-344(Y) vs PTX p=%.2g; PSLN-344 vs PSLN-344(Y) p=%.2g; PSLN-344(Y) vs PSLN-212(Y) p=%.2g" % (
    tk[("PSLN-344", "PSLN-212")], tk[("PSLN-344", "PTX")], tk[("PSLN-344(Y)", "PTX")], tk[("PSLN-344", "PSLN-344(Y)")], tk[("PSLN-344(Y)", "PSLN-212(Y)")]))
g = {k: vec("S02-E", k) for k in ["PSLN-212", "PSLN-344", "PSLN-212(Y)", "PTX", "PSLN-344(Y)"]}
F, pA, tk = tukey(g)
print("S02-E Tukey: PSLN-344 vs PSLN-212 p=%.2g; PSLN-344 vs PTX p=%.2g; PSLN-344(Y) vs PTX p=%.2g; PSLN-344(Y) vs PSLN-212(Y) p=%.2g" % (
    tk[("PSLN-344", "PSLN-212")], tk[("PSLN-344", "PTX")], tk[("PSLN-344(Y)", "PTX")], tk[("PSLN-344(Y)", "PSLN-212(Y)")]))
# S01-A young: Mn effect in young vs aged (interaction on log scale)
a = {k: np.log10(vec("S01-A [16h]", k)) for k in ["PSLN-212", "PSLN-344", "PSLN-212(Y)", "PSLN-344(Y)"]}
d = pd.DataFrame([(v, "Mn" if "344" in k else "noMn", "Y" if "(Y)" in k else "A") for k, vv in a.items() for v in vv], columns=["y", "mn", "age"])
fit = smf.ols("y ~ C(mn) * C(age)", data=d).fit(); an = sm.stats.anova_lm(fit, typ=2)
print("\nS01-A 16h Ifnb1, 2x2 (Mn x age) on log10: Mn effect aged = x%.2f, young = x%.2f ; interaction p = %.4f" % (
    10 ** (a["PSLN-344"].mean() - a["PSLN-212"].mean()), 10 ** (a["PSLN-344(Y)"].mean() - a["PSLN-212(Y)"].mean()), an.loc["C(mn):C(age)", "PR(>F)"]))
print("   young PSLN-344(Y) vs PSLN-212(Y): ratio", [round(v, 2) for v in ratio_ci_log(vec("S01-A [16h]", "PSLN-344(Y)"), vec("S01-A [16h]", "PSLN-212(Y)"))])
print("   aged PSLN-212 vs young PSLN-212(Y) (age defect): ratio", [round(v, 2) for v in ratio_ci_log(vec("S01-A [16h]", "PSLN-212"), vec("S01-A [16h]", "PSLN-212(Y)"))])

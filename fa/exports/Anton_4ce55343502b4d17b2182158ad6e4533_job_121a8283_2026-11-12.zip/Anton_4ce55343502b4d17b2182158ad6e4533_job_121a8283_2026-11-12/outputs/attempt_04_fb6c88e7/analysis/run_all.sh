#!/usr/bin/env bash
# Regenerates every table, figure and the memo from /tmp/world/filesystem/adjuvant_program_dataset.xlsx.
# Environments: 'singlecell' (openpyxl, pandas, scipy, statsmodels, matplotlib) for analysis; 'genomics' (pandoc) for rendering.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p ../tables ../figures _build logs
run() { echo ">> $1"; micromamba run -n "${2:-singlecell}" python -W ignore "$1" > "logs/${1%.py}.log" 2>&1; }
run parse_workbook.py
run 01_survival.py
run 02_bodyweight.py
run 03_immunology.py
run 04_integrity_checks.py
run 05_dose_safety.py
run 06_mechanism_blocks.py
run 07_figures.py
run 08_number_ledger.py
run 09_integrity_register.py
run 10_build_evidence_workbook.py
run 11_memo_tables.py
run 12_block_inventory.py
run 13_build_memo.py genomics
rm -rf _build __pycache__
echo "done"

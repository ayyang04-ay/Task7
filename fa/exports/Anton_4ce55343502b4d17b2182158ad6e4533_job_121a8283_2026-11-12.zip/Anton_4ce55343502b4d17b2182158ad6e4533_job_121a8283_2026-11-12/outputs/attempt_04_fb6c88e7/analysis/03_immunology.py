"""
03_immunology.py -- all non-survival, non-body-weight blocks.
Reduction rules:
  * Per-group summary: n, arithmetic mean, SD; for ratio-scale data (antibody titres, qPCR fold-change) also the geometric mean (GM).
  * Analysis scale: log10 for antibody titres and qPCR fold-changes (multiplicative errors; SD scales with the mean in these blocks);
    linear for flow-cytometry percentages and cell counts.  S09-A is already log10 and is analysed as stored.
  * HAI value 0 = no inhibition at the lowest dilution tested (1:10) -> set to 5 (half the LLOQ) before log-transformation.
  * Tests: one-way ANOVA + Tukey HSD across all groups in the block (the program's stated method), on the analysis scale.
           Welch t-test and exact Mann-Whitney for the named two-group contrast as robustness checks.
           Two-group blocks: Student t (stated method) + Welch + exact Mann-Whitney.
  * Effect sizes: difference of means with Welch 95% CI (linear blocks) or ratio of geometric means with 95% CI (log blocks).
  * Restoration index (RI) = (PSLN-344 - PSLN-212) / (PSLN-212(Y) - PSLN-212) on the analysis scale; 0 = no better than the
    non-Mn parent in aged mice, 1 = young-adult benchmark.  95% CI by nonparametric bootstrap (10,000 resamples within group).
"""
import numpy as np, pandas as pd, itertools
from parse_workbook import load
from stats_utils import *

OUT = "/tmp/outputs/tables"
M, S = load()
M = M[M.value.notna()].copy(); M["value"] = M.value.astype(float)

LOG_BLOCKS = {"S01-A [16h]", "S01-A [72h]", "S02-F", "S03-A", "S03-C", "S03-D", "S03-E", "S03-G", "S03-H", "S03-L [Aicda]", "S03-L [E47]",
              "S08-A", "S04-B Tfh:Tfr", "S03-B", "S03-F", "S10-A [Ifnb1]", "S10-A [Tnf]", "S10-A [Isg15]", "S13-A", "S13-B", "S13-C", "S13-D", "S13-I", "S13-J"}
ALREADY_LOG = {"S09-A [panel1(cols A-U)]", "S09-A [panel2(cols X-AS)]"}
HAI = {"S03-C", "S03-G"}
SKIP = {"S08-D", "S09-C", "S09-E", "S09-G", "S13-F", "S13-G"} | {f"S15-{c}" for c in "ABCDEFGIJKMO"}

def get(bp, x=None):
    d = M[M.block_panel == bp]
    if x is not None:
        d = d[d.x.astype(str) == str(x)]
    g = {}
    for name, dd in d.groupby("group", sort=False):
        v = dd.sort_values("rep").value.values.copy()
        if bp in HAI:
            v = np.where(v <= 0, 5.0, v)
        g[name] = v
    return g

def tr(bp, v):
    return np.log10(v) if bp in LOG_BLOCKS else v

def boot_ri(a344, a212, ay, log, B=10000, seed=7):
    rng = np.random.default_rng(seed)
    f = (lambda z: np.log10(z)) if log else (lambda z: z)
    x, y, z = f(a344), f(a212), f(ay)
    est = (x.mean() - y.mean()) / (z.mean() - y.mean())
    bs = []
    for _ in range(B):
        xb = rng.choice(x, len(x)).mean(); yb = rng.choice(y, len(y)).mean(); zb = rng.choice(z, len(z)).mean()
        if zb != yb:
            bs.append((xb - yb) / (zb - yb))
    lo, hi = np.percentile(bs, [2.5, 97.5])
    return est, lo, hi

summ, contr, ri_rows = [], [], []
keys = []
for bp in M.block_panel.unique():
    if bp.split(" [")[0] in SKIP or bp in SKIP:
        continue
    d = M[M.block_panel == bp]
    xs = [None] if d.x.isna().all() else list(dict.fromkeys(d.x.astype(str)))
    for x in xs:
        keys.append((bp, x))

for bp, x in keys:
    g = get(bp, x)
    log = bp in LOG_BLOCKS
    scale = "log10" if log else ("log10 (as stored)" if bp in ALREADY_LOG else "linear")
    gt = {k: tr(bp, v) for k, v in g.items()}
    for name, v in g.items():
        cells = M[(M.block_panel == bp) & (M.group == name) & ((M.x.astype(str) == str(x)) if x is not None else True)].cell
        summ.append(dict(block=bp, x=x, group=name, n=len(v), mean=v.mean(), sd=v.std(ddof=1) if len(v) > 1 else np.nan,
                         geomean=(10 ** np.log10(v).mean() if (v > 0).all() and bp not in ALREADY_LOG else (10 ** v.mean() if bp in ALREADY_LOG else np.nan)),
                         min=v.min(), max=v.max(), scale=scale, cells=f"{cells.iloc[0]}:{cells.iloc[-1]}"))
    names = list(g)
    tk = None
    if len(names) >= 3 and all(len(v) >= 2 for v in gt.values()):
        F, pA, tk = tukey(gt)
    for a, b in itertools.combinations(names, 2):
        for trt, ctl in ((a, b), (b, a)):
            va, vb = g[trt], g[ctl]; ta, tb = gt[trt], gt[ctl]
            row = dict(block=bp, x=x, trt=trt, ctl=ctl, n_trt=len(va), n_ctl=len(vb), mean_trt=va.mean(), mean_ctl=vb.mean(), scale=scale)
            if log:
                r, lo, hi = ratio_ci_log(va, vb)
                row.update(effect="ratio of GMs", est=r, lo=lo, hi=hi)
            elif bp in ALREADY_LOG:
                dd, lo, hi = diff_ci(va, vb)
                row.update(effect="ratio (10^diff of log10 means)", est=10 ** dd, lo=10 ** lo, hi=10 ** hi)
            else:
                dd, lo, hi = diff_ci(va, vb)
                row.update(effect="difference of means", est=dd, lo=lo, hi=hi)
            row.update(fold_of_means=(va.mean() / vb.mean() if bp not in ALREADY_LOG and vb.mean() != 0 else np.nan),
                       p_tukey=(tk[(trt, ctl)] if tk else np.nan), p_anova=(pA if tk else np.nan),
                       p_student=student(ta, tb)[1], p_welch=welch(ta, tb)[1], p_mwu_exact=mwu_exact(ta, tb), hedges_g=hedges_g(ta, tb))
            contr.append(row)
    if all(k in g for k in ("PSLN-344", "PSLN-212", "PSLN-212(Y)")):
        est, lo, hi = boot_ri(g["PSLN-344"], g["PSLN-212"], g["PSLN-212(Y)"], log)
        if bp in ALREADY_LOG:
            pct_y = 100 * 10 ** (g["PSLN-344"].mean() - g["PSLN-212(Y)"].mean())
        elif log:
            pct_y = 100 * 10 ** (np.log10(g["PSLN-344"]).mean() - np.log10(g["PSLN-212(Y)"]).mean())
        else:
            pct_y = 100 * g["PSLN-344"].mean() / g["PSLN-212(Y)"].mean()
        ri_rows.append(dict(block=bp, x=x, scale=scale, m212=g["PSLN-212"].mean(), m344=g["PSLN-344"].mean(), mY=g["PSLN-212(Y)"].mean(),
                            RI=est, RI_lo=lo, RI_hi=hi, pct_of_young=pct_y))

SUM = pd.DataFrame(summ); CON = pd.DataFrame(contr); RI = pd.DataFrame(ri_rows)
SUM.to_csv(f"{OUT}/T5_immunology_group_summaries.csv", index=False)
CON.to_csv(f"{OUT}/T5b_immunology_all_pairwise_contrasts.csv", index=False)
RI.to_csv(f"{OUT}/T6_restoration_index.csv", index=False)
print("groups summarised:", len(SUM), " contrasts:", len(CON), " RI rows:", len(RI))

pd.set_option("display.width", 280); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 800)
K = CON[(CON.trt == "PSLN-344") & (CON.ctl.isin(["PSLN-212", "Sham", "PSLN-212(Y)", "Vaccine", "PBS"]))]
cols = ["block", "x", "trt", "ctl", "mean_trt", "mean_ctl", "effect", "est", "lo", "hi", "p_tukey", "p_welch", "p_mwu_exact"]
K.to_csv(f"{OUT}/T5c_immunology_key_contrasts_PSLN344.csv", index=False)
with open("/tmp/outputs/analysis/_build/key_contrasts.txt", "w") as f:
    f.write(K[cols].round(4).to_string(index=False))
with open("/tmp/outputs/analysis/_build/ri.txt", "w") as f:
    f.write(RI.round(3).to_string(index=False))

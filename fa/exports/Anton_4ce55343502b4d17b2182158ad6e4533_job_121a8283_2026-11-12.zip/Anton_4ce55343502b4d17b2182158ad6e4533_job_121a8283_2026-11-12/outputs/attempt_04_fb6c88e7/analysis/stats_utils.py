"""Small, dependency-light statistics helpers used by all analysis scripts."""
import itertools, math
import numpy as np
from scipy import stats


def clopper_pearson(k, n, alpha=0.05):
    lo = 0.0 if k == 0 else stats.beta.ppf(alpha / 2, k, n - k + 1)
    hi = 1.0 if k == n else stats.beta.ppf(1 - alpha / 2, k + 1, n - k)
    return lo, hi


def fisher_two_sided(a, b, c, d):
    """2x2 table [[a,b],[c,d]] -> two-sided Fisher exact p."""
    return stats.fisher_exact([[a, b], [c, d]], alternative="two-sided")[1]


def logrank_stat(time, event, group):
    """Two-group log-rank: returns (O1-E1, V). group is 0/1 array."""
    time = np.asarray(time, float); event = np.asarray(event, int); group = np.asarray(group, int)
    o_minus_e, var = 0.0, 0.0
    for t in np.unique(time[event == 1]):
        at_risk = time >= t
        n = at_risk.sum(); n1 = (at_risk & (group == 1)).sum()
        d = ((time == t) & (event == 1)).sum(); d1 = ((time == t) & (event == 1) & (group == 1)).sum()
        if n > 1:
            o_minus_e += d1 - d * n1 / n
            var += d * (n1 / n) * (1 - n1 / n) * (n - d) / (n - 1)
    return o_minus_e, var


def logrank_asymptotic(time, event, group):
    oe, v = logrank_stat(time, event, group)
    if v <= 0:
        return np.nan, 1.0
    chi2 = oe ** 2 / v
    return chi2, stats.chi2.sf(chi2, 1)


def logrank_exact(time, event, group, max_enum=400000, n_mc=200000, seed=1):
    """Exact (full enumeration) permutation p for the two-group log-rank statistic; Monte-Carlo if too many splits."""
    time = np.asarray(time, float); event = np.asarray(event, int); group = np.asarray(group, int)
    n = len(time); n1 = int(group.sum())
    oe, v = logrank_stat(time, event, group)
    obs = abs(oe)
    # pre-compute per-animal contributions is not trivial because E depends on risk-set composition; brute force
    ncomb = math.comb(n, n1)
    idx = np.arange(n)
    ge = 0; tot = 0
    if ncomb <= max_enum:
        for comb in itertools.combinations(idx, n1):
            g = np.zeros(n, int); g[list(comb)] = 1
            oe_p, _ = logrank_stat(time, event, g)
            if abs(oe_p) >= obs - 1e-12:
                ge += 1
            tot += 1
        return ge / tot
    rng = np.random.default_rng(seed)
    for _ in range(n_mc):
        g = np.zeros(n, int); g[rng.choice(n, n1, replace=False)] = 1
        oe_p, _ = logrank_stat(time, event, g)
        if abs(oe_p) >= obs - 1e-12:
            ge += 1
        tot += 1
    return (ge + 1) / (tot + 1)


def km_curve(time, event):
    """Kaplan-Meier step function -> (times, survival) including t=0."""
    time = np.asarray(time, float); event = np.asarray(event, int)
    ts = [0.0]; ss = [1.0]; s = 1.0
    for t in np.unique(time):
        d = ((time == t) & (event == 1)).sum(); n = (time >= t).sum()
        if d > 0:
            s *= 1 - d / n
            ts.append(t); ss.append(s)
    return np.array(ts), np.array(ss)


def median_survival(time, event):
    ts, ss = km_curve(time, event)
    below = np.where(ss <= 0.5)[0]
    return float(ts[below[0]]) if len(below) else float("inf")


def stratified_exact_2x2(tables, n_mc=None):
    """Exact conditional test across K independent 2x2 tables (fixed margins): statistic = sum of 'a' cells
    (survivors in treatment arm). Two-sided p = P(|S - E[S]| >= |obs - E[S]|) from convolution of hypergeometrics.
    tables: list of (a, b, c, d) = (trt survive, trt die, ctl survive, ctl die)."""
    dist = {0: 1.0}
    obs = 0; exp = 0.0
    for a, b, c, d in tables:
        n1 = a + b; n2 = c + d; m = a + c; N = n1 + n2
        rv = stats.hypergeom(N, m, n1)
        lo = max(0, m - n2); hi = min(m, n1)
        new = {}
        for s0, p0 in dist.items():
            for k in range(lo, hi + 1):
                new[s0 + k] = new.get(s0 + k, 0.0) + p0 * rv.pmf(k)
        dist = new
        obs += a; exp += rv.mean()
    dev = abs(obs - exp)
    p = sum(p for s, p in dist.items() if abs(s - exp) >= dev - 1e-9)
    return obs, exp, min(1.0, p)


def mh_risk_difference(tables, alpha=0.05):
    """Mantel-Haenszel pooled risk difference (survival proportion trt - ctl) with Greenland-Robins variance (Sato)."""
    num = 0.0; den = 0.0; P = 0.0; Q = 0.0
    for a, b, c, d in tables:
        n1 = a + b; n2 = c + d; N = n1 + n2
        num += (a * n2 - c * n1) / N
        den += n1 * n2 / N
        P += (n1 ** 2 * c - n2 ** 2 * a + n1 * n2 * (n2 - n1) / 2) / N ** 2
        Q += (a * (n2 - c) + c * (n1 - a)) / (2 * N)
    rd = num / den
    var = (rd * P + Q) / den ** 2
    se = math.sqrt(max(var, 0))
    z = stats.norm.ppf(1 - alpha / 2)
    return rd, rd - z * se, rd + z * se


def newcombe_rd(k1, n1, k2, n2, alpha=0.05):
    """Newcombe hybrid-score CI for difference of two independent proportions p1 - p2."""
    def wilson(k, n):
        if n == 0:
            return 0, 1
        z = stats.norm.ppf(1 - alpha / 2); p = k / n
        den = 1 + z ** 2 / n
        c = (p + z ** 2 / (2 * n)) / den
        h = z * math.sqrt(p * (1 - p) / n + z ** 2 / (4 * n ** 2)) / den
        return c - h, c + h
    p1, p2 = k1 / n1, k2 / n2
    l1, u1 = wilson(k1, n1); l2, u2 = wilson(k2, n2)
    d = p1 - p2
    lo = d - math.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2)
    hi = d + math.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)
    return d, lo, hi


def welch(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    t, p = stats.ttest_ind(a, b, equal_var=False)
    return t, p


def student(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    t, p = stats.ttest_ind(a, b, equal_var=True)
    return t, p


def mwu_exact(a, b):
    try:
        return stats.mannwhitneyu(a, b, alternative="two-sided", method="exact")[1]
    except Exception:
        return stats.mannwhitneyu(a, b, alternative="two-sided")[1]


def diff_ci(a, b, alpha=0.05):
    """Welch CI for mean(a) - mean(b)."""
    a = np.asarray(a, float); b = np.asarray(b, float)
    va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
    se = math.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1)) if (va + vb) > 0 else 1
    tcrit = stats.t.ppf(1 - alpha / 2, df)
    d = a.mean() - b.mean()
    return d, d - tcrit * se, d + tcrit * se


def ratio_ci_log(a, b, alpha=0.05):
    """Ratio of geometric means a/b with Welch CI computed on log10 scale (requires positive values)."""
    la, lb = np.log10(np.asarray(a, float)), np.log10(np.asarray(b, float))
    d, lo, hi = diff_ci(la, lb, alpha)
    return 10 ** d, 10 ** lo, 10 ** hi


def tukey(groups: dict):
    """One-way ANOVA + Tukey HSD. groups: name -> array. Returns (F, p_anova, {(g1,g2): p_adj})."""
    names = list(groups); arrs = [np.asarray(groups[k], float) for k in names]
    F, p = stats.f_oneway(*arrs)
    res = stats.tukey_hsd(*arrs)
    out = {}
    for i, j in itertools.combinations(range(len(names)), 2):
        out[(names[i], names[j])] = float(res.pvalue[i, j])
        out[(names[j], names[i])] = float(res.pvalue[i, j])
    return float(F), float(p), out


def hedges_g(a, b):
    a = np.asarray(a, float); b = np.asarray(b, float)
    na, nb = len(a), len(b)
    sp = math.sqrt(((na - 1) * a.var(ddof=1) + (nb - 1) * b.var(ddof=1)) / (na + nb - 2))
    if sp == 0:
        return np.nan
    g = (a.mean() - b.mean()) / sp
    return g * (1 - 3 / (4 * (na + nb) - 9))


def fmt_p(p):
    if p is None or (isinstance(p, float) and np.isnan(p)):
        return "NA"
    if p < 1e-4:
        return f"{p:.1e}"
    if p < 0.001:
        return f"{p:.4f}"
    return f"{p:.3f}" if p < 0.1 else f"{p:.2f}"

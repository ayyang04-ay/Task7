"""
01_survival.py -- every time-to-event block: per-arm survival, per-experiment tests, pooled/stratified tests, sensitivity analyses.
Reduction rules (stated once, applied everywhere):
  * Event = indicator cell == 1 (death / humane endpoint as recorded); indicator == 0 = alive at last observation (censored).
  * Survival proportion = animals with indicator 0 / animals with an indicator, at end of the observation window of that block
    (14 d; 21 d in S03-J).  95% CI = exact Clopper-Pearson.
  * Two-arm tests: (i) log-rank, exact permutation p (all C(n, n1) splits enumerated) and asymptotic chi-square p (the program's
    stated method); (ii) Fisher exact two-sided on end-of-window survival.
  * Pooled tests: exact conditional test stratified by experiment (convolution of hypergeometrics) + Mantel-Haenszel risk difference.
  * S03-J PSLN-344: 10 indicator cells but 9 day cells (J46 has no day in G46). Primary analysis uses the 9 animals with a recorded
    time (= the stated n of 9); sensitivity uses 10 (the 10th treated as censored at day 21).
"""
import numpy as np, pandas as pd, itertools, json
from parse_workbook import load
from stats_utils import *

OUT = "/tmp/outputs/tables"
M, S = load()

EXP = {  # block_panel -> metadata
 "S03-I": dict(id="S03-I", host="BALB/c aged (>=20 mo)", vaccine="bivalent CA09 H1N1 + Aichi H3N2", challenge="10x mLD50 CA09 H1N1 (homologous)", day="d14", window=14),
 "S03-J": dict(id="S03-J", host="BALB/c aged (>=20 mo)", vaccine="rgH5N1 (single dose)", challenge="wild-type VN04 H5N1 (homologous HA/NA)", day="d2", window=21),
 "S06-A": dict(id="S06-A", host="BALB/c aged (>=20 mo)", vaccine="Aichi H3N2", challenge="5x mLD50 PR8 H1N1 (heterosubtypic)", day="d14", window=14),
 "S06-B": dict(id="S06-B", host="BALB/c aged (>=20 mo)", vaccine="Aichi H3N2", challenge="5x mLD50 PR8 H1N1 (heterosubtypic)", day="d3", window=14),
 "S06-C": dict(id="S06-C", host="BALB/c aged (>=20 mo)", vaccine="bivalent", challenge="5x mLD50 rgH5N1 (heterosubtypic)", day="d14", window=14),
 "S06-D": dict(id="S06-D", host="BALB/c aged (>=20 mo)", vaccine="bivalent", challenge="5x mLD50 rgH5N1 (heterosubtypic)", day="d3", window=14),
 "S06-E [rows34-68]": dict(id="S06-E(1)", host="BALB/c aged (>=20 mo)", vaccine="Aichi H3N2", challenge="5x mLD50 PR8 H1N1 (heterosubtypic)", day="d60", window=14),
 "S06-F [rows34-68]": dict(id="S06-F(1)", host="BALB/c aged (>=20 mo)", vaccine="bivalent", challenge="5x mLD50 rgH5N1 (heterosubtypic)", day="d60", window=14),
 "S06-G": dict(id="S06-G", host="BALB/c aged (>=20 mo)", vaccine="CA09 H1N1", challenge="5x mLD50 Perth H3N2 (heterosubtypic)", day="d60", window=14),
 "S06-E [rows71-105(imprint/PR8)]": dict(id="S06-E(2)", host="BALB/c 14 mo; +/- PR8 imprinting at 10 mo", vaccine="bivalent", challenge="5x LD50 PR8 H1N1", day="n/s", window=14),
 "S06-F [rows71-105(imprint/Perth)]": dict(id="S06-F(2)", host="BALB/c 14 mo; +/- PR8 imprinting at 10 mo", vaccine="bivalent", challenge="5x LD50 Perth H3N2", day="d14", window=14),
 "S15-H": dict(id="S15-H", host="BALB/c aged (>=20 mo)", vaccine="bivalent (or none)", challenge="5x mLD50 VN04 rgH5N1", day="d3", window=14),
 "S15-L": dict(id="S15-L", host="C57BL/6 aged (20 mo)", vaccine="bivalent", challenge="not stated", day="n/s", window=14),
 "S15-N": dict(id="S15-N", host="Swiss Webster aged (20 mo)", vaccine="bivalent", challenge="not stated", day="n/s", window=14),
 "S09-B": dict(id="S09-B", host="BALB/c young", vaccine="Aichi H3N2", challenge="5x mLD50 PR8 H1N1 (heterosubtypic)", day="d21", window=14),
 "S09-D": dict(id="S09-D", host="BALB/c young", vaccine="CA09 H1N1", challenge="5x mLD50 Perth H3N2 (heterosubtypic)", day="d21", window=14),
 "S09-F": dict(id="S09-F", host="BALB/c young", vaccine="bivalent", challenge="5x mLD50 VN04 rgH5N1", day="d180", window=14),
 "S13-E": dict(id="S13-E", host="BALB/c young", vaccine="bivalent", challenge="10x mLD50 CA09 H1N1 (homologous)", day="d14", window=14),
}

def arm(bp, g, drop_missing_time=True):
    d = S[(S.block_panel == bp) & (S.group == g)].copy()
    n_flags = len(d)
    miss = int(d.day.isna().sum())
    if drop_missing_time:
        d = d[d.day.notna()]
    return d.day.astype(float).values, d.event.astype(int).values, n_flags, miss

# ---------------- Table 1: per-arm
rows = []
for bp, meta in EXP.items():
    for g in S[S.block_panel == bp].group.unique():
        t, e, n_flags, miss = arm(bp, g)
        n = len(t); deaths = int(e.sum()); surv = n - deaths
        lo, hi = clopper_pearson(surv, n)
        dd = S[(S.block_panel == bp) & (S.group == g)]
        rows.append(dict(experiment=meta["id"], block_panel=bp, host=meta["host"], vaccine=meta["vaccine"], challenge=meta["challenge"],
                         challenge_day=meta["day"], arm=g, n=n, n_indicator_cells=n_flags, n_missing_day=miss, deaths=deaths, survivors=surv,
                         surv_pct=100 * surv / n, ci_lo=100 * lo, ci_hi=100 * hi,
                         death_days=",".join(str(int(x)) for x in sorted(t[e == 1])),
                         median_surv_d=median_survival(t, e),
                         cells=f'{dd.event_cell.iloc[0]}:{dd.event_cell.iloc[-1]} (days {dd.day_cell.iloc[0]}:{dd.day_cell.iloc[-1]})'))
T1 = pd.DataFrame(rows)
T1.to_csv(f"{OUT}/T1_survival_by_arm.csv", index=False)

# ---------------- Table 2: pairwise within experiment
def compare(bp, g1, g2):
    t1, e1, _, _ = arm(bp, g1); t2, e2, _, _ = arm(bp, g2)
    time = np.r_[t1, t2]; ev = np.r_[e1, e2]; grp = np.r_[np.ones(len(t1), int), np.zeros(len(t2), int)]
    chi2, p_asym = logrank_asymptotic(time, ev, grp)
    p_exact = logrank_exact(time, ev, grp)
    s1, s2 = int((e1 == 0).sum()), int((e2 == 0).sum())
    pf = fisher_two_sided(s1, len(t1) - s1, s2, len(t2) - s2)
    rd, lo, hi = newcombe_rd(s1, len(t1), s2, len(t2))
    return dict(trt=g1, ctl=g2, trt_surv=f"{s1}/{len(t1)}", ctl_surv=f"{s2}/{len(t2)}", risk_diff_pct=100 * rd, rd_lo=100 * lo, rd_hi=100 * hi,
                logrank_chi2=chi2, p_logrank_asym=p_asym, p_logrank_exact=p_exact, p_fisher=pf, table=(s1, len(t1) - s1, s2, len(t2) - s2))

pairs = []
for bp, meta in EXP.items():
    gs = list(S[S.block_panel == bp].group.unique())
    for g1, g2 in itertools.combinations(gs, 2):
        r = compare(bp, g1, g2)
        r0 = compare(bp, g2, g1)
        for rr in (r, r0):
            rr.update(experiment=meta["id"], block_panel=bp)
            pairs.append(rr)
T2 = pd.DataFrame(pairs)
T2.to_csv(f"{OUT}/T2_survival_pairwise_all.csv", index=False)

def pick(trt, ctl, bps=None):
    d = T2[(T2.trt == trt) & (T2.ctl == ctl)]
    if bps is not None:
        d = d[d.block_panel.isin(bps)]
    return d

pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 500)
print("=== T1: survival by arm ===")
print(T1[["experiment", "challenge_day", "arm", "n", "deaths", "survivors", "surv_pct", "ci_lo", "ci_hi", "death_days", "median_surv_d"]].round(1).to_string(index=False))

key = T2[((T2.trt == "PSLN-344") & (T2.ctl.isin(["Sham", "PSLN-212", "PSLN-212(Y)", "CMP-204", "Untreated"]))) |
         ((T2.trt == "3d Vaccine+PSLN-344")) |
         ((T2.trt.isin(["Naive+PSLN-344", "Imprinting+PSLN-344"])) ) |
         ((T2.trt == "PSLN-344(Y)")) | ((T2.trt == "PSLN-212") & (T2.ctl == "Sham")) | ((T2.trt == "PSLN-212(Y)") & (T2.ctl == "Sham"))]
print("\n=== T2 (key contrasts) ===")
print(key[["experiment", "trt", "ctl", "trt_surv", "ctl_surv", "risk_diff_pct", "rd_lo", "rd_hi", "p_logrank_exact", "p_logrank_asym", "p_fisher"]].round(4).to_string(index=False))
key.drop(columns=["table"]).to_csv(f"{OUT}/T2b_survival_key_contrasts.csv", index=False)

# =====================================================================================================
# Pooled / stratified analyses and sensitivity analyses
# =====================================================================================================
def tab(bp, trt, ctl, override=None):
    """2x2 (trt survive, trt die, ctl survive, ctl die) for one experiment."""
    if override and (bp, trt) in override:
        s1, n1 = override[(bp, trt)]
    else:
        t1, e1, _, _ = arm(bp, trt); s1, n1 = int((e1 == 0).sum()), len(t1)
    if override and (bp, ctl) in override:
        s2, n2 = override[(bp, ctl)]
    else:
        t2, e2, _, _ = arm(bp, ctl); s2, n2 = int((e2 == 0).sum()), len(t2)
    return (s1, n1 - s1, s2, n2 - s2)

def pooled(name, strata, override=None):
    """strata: list of (block_panel, trt_label, ctl_label)."""
    tabs = [tab(bp, t, c, override) for bp, t, c in strata]
    a = sum(x[0] for x in tabs); b = sum(x[1] for x in tabs); c = sum(x[2] for x in tabs); d = sum(x[3] for x in tabs)
    obs, exp, p = stratified_exact_2x2(tabs)
    rd, lo, hi = mh_risk_difference(tabs)
    l1, h1 = clopper_pearson(a, a + b); l2, h2 = clopper_pearson(c, c + d)
    return dict(analysis=name, n_strata=len(tabs), trt_surv=f"{a}/{a+b}", trt_pct=100 * a / (a + b), trt_ci=f"{100*l1:.0f}-{100*h1:.0f}",
                ctl_surv=f"{c}/{c+d}", ctl_pct=100 * c / (c + d), ctl_ci=f"{100*l2:.0f}-{100*h2:.0f}",
                MH_RD_pct=100 * rd, RD_lo=100 * lo, RD_hi=100 * hi, p_strat_exact=p,
                strata="; ".join(f"{EXP[bp]['id']}:{t[0]}/{t[0]+t[1]} v {t[2]}/{t[2]+t[3]}" for (bp, _, _), t in zip(strata, tabs)))

AGED_BALB = ["S03-I", "S03-J", "S06-A", "S06-B", "S06-C", "S06-D", "S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G"]
STRAINS = ["S15-L", "S15-N"]
IMPR = [("S06-E [rows71-105(imprint/PR8)]", "Naive+PSLN-344", "Naive+PSLN-212"), ("S06-E [rows71-105(imprint/PR8)]", "Imprinting+PSLN-344", "Imprinting+PSLN-212"),
        ("S06-F [rows71-105(imprint/Perth)]", "Naive+PSLN-344", "Naive+PSLN-212"), ("S06-F [rows71-105(imprint/Perth)]", "Imprinting+PSLN-344", "Imprinting+PSLN-212")]

vs_sham = [(bp, "PSLN-344", "Sham") for bp in AGED_BALB + STRAINS] + [("S15-H", "3d Vaccine+PSLN-344", "3d Vaccine")]
vs_212 = [(bp, "PSLN-344", "PSLN-212") for bp in AGED_BALB + STRAINS] + IMPR
vs_young = [(bp, "PSLN-344", "PSLN-212(Y)") for bp in AGED_BALB + STRAINS if bp != "S03-J"]
p212_vs_sham = [(bp, "PSLN-212", "Sham") for bp in AGED_BALB + STRAINS]

# weight-block-derived survivor counts (animals with a real, non-carried-forward value at day 14); see 02_bodyweight.py
WT_DERIVED = {("S06-D", "PSLN-344"): (5, 7), ("S06-D", "PSLN-212(Y)"): (5, 7), ("S06-D", "PSLN-212"): (2, 7), ("S06-D", "Sham"): (0, 7)}
# worst case for PSLN-344: larger death count of (survival block, paired weight block) for PSLN-344; smaller death count for comparators
WORST = {("S06-D", "PSLN-344"): (5, 7), ("S06-B", "PSLN-344"): (4, 7), ("S06-G", "PSLN-344"): (4, 7), ("S06-E [rows34-68]", "PSLN-344"): (5, 7),
         ("S06-E [rows34-68]", "PSLN-212"): (1, 7), ("S03-I", "PSLN-212"): (3, 7), ("S03-J", "PSLN-212"): (5, 10), ("S03-J", "Sham"): (1, 10),
         ("S06-C", "PSLN-212"): (2, 7), ("S06-D", "PSLN-212"): (2, 7), ("S15-N", "PSLN-212"): (2, 7), ("S06-A", "PSLN-212"): (1, 7)}

res = []
res.append(pooled("A1. PSLN-344 vs Sham/vaccine-alone, all aged experiments as printed", vs_sham))
res.append(pooled("A2. ... S06-D removed (exact duplicate of S06-C)", [s for s in vs_sham if s[0] != "S06-D"]))
res.append(pooled("A3. ... S06-D replaced by counts read from paired weights S15-D", vs_sham, WT_DERIVED))
res.append(pooled("A4. ... worst case for PSLN-344 (max deaths of survival vs weight block; S06-D dropped)", [s for s in vs_sham if s[0] != "S06-D"], WORST))
res.append(pooled("A5. ... BALB/c only (S15-L/N dropped), S06-D dropped", [s for s in vs_sham if s[0] not in ("S06-D", "S15-L", "S15-N")]))
res.append(pooled("B1. PSLN-344 vs PSLN-212 (same age), all aged experiments as printed", vs_212))
res.append(pooled("B2. ... S06-D removed", [s for s in vs_212 if s[0] != "S06-D"]))
res.append(pooled("B3. ... worst case for PSLN-344 / best case for PSLN-212 (S06-D dropped)", [s for s in vs_212 if s[0] != "S06-D"], WORST))
res.append(pooled("B4. ... only >=20-month BALB/c, S06-D dropped, S03-I & S03-J dropped (comparator label conflicts)",
                  [s for s in vs_212 if s[0] in AGED_BALB and s[0] not in ("S06-D", "S03-I", "S03-J")]))
res.append(pooled("C1. PSLN-344 (aged) vs PSLN-212 (young benchmark), as printed", vs_young))
res.append(pooled("C2. ... S06-D removed", [s for s in vs_young if s[0] != "S06-D"]))
res.append(pooled("D1. PSLN-212 (aged) vs Sham, as printed, S06-D removed", [s for s in p212_vs_sham if s[0] != "S06-D"]))
# by challenge timing (PSLN-344 vs Sham / vaccine alone)
res.append(pooled("E1. Early challenge d2-d3: PSLN-344 vs control (S03-J, S06-B, S15-H; S06-D excluded)", [s for s in vs_sham if s[0] in ("S03-J", "S06-B", "S15-H")]))
res.append(pooled("E2. d14 challenge (S03-I, S06-A, S06-C)", [s for s in vs_sham if s[0] in ("S03-I", "S06-A", "S06-C")]))
res.append(pooled("E3. d60 challenge (S06-E1, S06-F1, S06-G)", [s for s in vs_sham if s[0] in ("S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G")]))
res.append(pooled("E4. d60 challenge: PSLN-344 vs PSLN-212", [s for s in vs_212 if s[0] in ("S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G")]))
res.append(pooled("E5. d60: PSLN-344 (challenged) vs Untreated (unchallenged, unvaccinated)", [(bp, "PSLN-344", "Untreated") for bp in ("S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G")]))
res.append(pooled("F1. Strain generalisation C57BL/6 + Swiss Webster: PSLN-344 vs Sham", [s for s in vs_sham if s[0] in STRAINS]))
res.append(pooled("F2. Strain generalisation: PSLN-344 vs PSLN-212", [s for s in vs_212 if s[0] in STRAINS]))
res.append(pooled("G1. Imprinting study (4 strata): PSLN-344 vs PSLN-212", IMPR))
res.append(pooled("H1. Young mice: PSLN-344(Y) vs PSLN-212(Y) (S09-B, D, F)", [(bp, "PSLN-344(Y)", "PSLN-212(Y)") for bp in ("S09-B", "S09-D", "S09-F")]))
T3 = pd.DataFrame(res)
T3.to_csv(f"{OUT}/T3_survival_pooled_and_sensitivity.csv", index=False)
print("\n=== T3: pooled & sensitivity ===")
print(T3.drop(columns=["strata"]).round(2).to_string(index=False))

# leave-one-out for A2 and B2
def loo(strata, label):
    out = []
    for i in range(len(strata)):
        r = pooled("loo", strata[:i] + strata[i + 1:])
        out.append((EXP[strata[i][0]]["id"] + "/" + strata[i][1], r["trt_pct"], r["ctl_pct"], r["MH_RD_pct"], r["p_strat_exact"]))
    d = pd.DataFrame(out, columns=["dropped", "trt_pct", "ctl_pct", "RD", "p"])
    print(f"\nLeave-one-out ({label}): RD range {d.RD.min():.1f} to {d.RD.max():.1f} pct-points; max p = {d.p.max():.2e}")
    return d
l1 = loo([s for s in vs_sham if s[0] != "S06-D"], "PSLN-344 vs Sham, S06-D dropped")
l2 = loo([s for s in vs_212 if s[0] != "S06-D"], "PSLN-344 vs PSLN-212, S06-D dropped")
l1.to_csv(f"{OUT}/T3b_leave_one_out_vs_sham.csv", index=False); l2.to_csv(f"{OUT}/T3c_leave_one_out_vs_212.csv", index=False)

# waning: PSLN-344 d14 vs d60 (BALB/c aged)
def cnt(bps, g="PSLN-344"):
    s = n = 0
    for bp in bps:
        t, e, _, _ = arm(bp, g); s += int((e == 0).sum()); n += len(t)
    return s, n
s14, n14 = cnt(["S03-I", "S06-A", "S06-C"]); s60, n60 = cnt(["S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G"])
s3, n3 = cnt(["S03-J", "S06-B"]); sh, nh = cnt(["S15-H"], "3d Vaccine+PSLN-344")
print(f"\nPSLN-344 aged BALB/c survival by challenge timing: d2-3 {s3+sh}/{n3+nh} (S03-J,S06-B,S15-H; S06-D excluded)  d14 {s14}/{n14}  d60 {s60}/{n60}")
print("  d14 vs d60 Fisher p =", round(fisher_two_sided(s14, n14 - s14, s60, n60 - s60), 4), " CI d60:", [round(100*x,1) for x in clopper_pearson(s60, n60)], " CI d14:", [round(100*x,1) for x in clopper_pearson(s14, n14)])
su, nu = cnt(["S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G"], "Untreated")
print(f"  Untreated (no vaccine, no adjuvant, no challenge) deaths within 14 d: {nu-su}/{nu} = {100*(nu-su)/nu:.1f}%  CI", [round(100*x,1) for x in clopper_pearson(nu-su, nu)])
print("  PSLN-344 d60 (14/21) vs Untreated (17/21) Fisher p =", round(fisher_two_sided(s60, n60 - s60, su, nu - su), 3))
sy, ny = cnt(["S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G"], "PSLN-212(Y)")
print(f"  Young PSLN-212(Y) d60: {sy}/{ny};  PSLN-344 aged vs young at d60 Fisher p =", round(fisher_two_sided(s60, n60 - s60, sy, ny - sy), 4))
s212, n212 = cnt(["S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G"], "PSLN-212")
print(f"  Aged PSLN-212 d60: {s212}/{n212}")
# S03-J sensitivity with 10th animal
print("\nS03-J sensitivity (10th PSLN-344 animal counted as censored d21): PSLN-344 10/10 vs Sham 1/10 Fisher p =", fisher_two_sided(10, 0, 1, 9), "; vs 'PSLN-212' 3/10 p =", fisher_two_sided(10, 0, 3, 7))
print("S03-J primary (n=9): vs Sham p =", fisher_two_sided(9, 0, 1, 9), "; vs 'PSLN-212' p =", fisher_two_sided(9, 0, 3, 7))
print("S03-I alt label: PSLN-344 7/7 vs '3/7 arm' Fisher p =", round(fisher_two_sided(7, 0, 3, 4), 4), "; vs '0/7 fast arm' p =", round(fisher_two_sided(7, 0, 0, 7), 5))

"""
04_integrity_checks.py -- cross-block consistency checks that decide which blocks can be cited, and how.
"""
import numpy as np, pandas as pd, itertools
from parse_workbook import load
M, S = load()
M = M[M.value.notna()].copy(); M["value"] = M.value.astype(float)
def vec(bp, g, x=None):
    d = M[(M.block_panel == bp) & (M.group == g)]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    return d.sort_values("rep").value.values
np.set_printoptions(precision=4, suppress=True, linewidth=200)

print("=== (1) IgG2a/IgG1 quotient blocks S03-B / S03-F versus raw subclass titres S13-A..D ===")
for quot, num, den, strain in (("S03-B", "S13-A", "S13-B", "CA09 H1N1"), ("S03-F", "S13-C", "S13-D", "Aichi H3N2")):
    print(f"  {quot} ({strain}) printed columns vs {num}/{den} recomputed per animal:")
    rec = {g: vec(num, g) / vec(den, g) for g in ("PSLN-212", "PSLN-344", "PSLN-212(Y)")}
    for gq in ("PSLN-212", "PSLN-344", "PSLN-212(Y)"):
        q = vec(quot, gq)
        match = [g for g, r in rec.items() if np.allclose(r, q, rtol=1e-4)]
        print(f"     printed '{gq}' column {q}  == recomputed ratio for raw-titre group: {match}")
    for g, r in rec.items():
        print(f"     recomputed IgG2a/IgG1 for {g}: {r}  mean {r.mean():.2f}  GM {10**np.log10(r).mean():.2f}")

print("\n=== (2) S04-B 'Tfh:Tfr' versus S04-B 'Foxp3+ in CXCR5+' ===")
for g in ("Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"):
    f = vec("S04-B Foxp3", g); r = vec("S04-B Tfh:Tfr", g)
    srt = np.allclose(np.sort((100 - f) / f), np.sort(r), rtol=1e-4)
    pos = np.allclose((100 - f) / f, r, rtol=1e-4)
    print(f"  {g:12s} (100-Foxp3%)/Foxp3% reproduces the printed ratio: same multiset={srt}, same row order={pos}")
print("  S04-A ICOS- + ICOS+ sums (total CXCR5+PD1+ Tfh %):")
for g in ("Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"):
    s = vec("S04-A [ICOS-]", g) + vec("S04-A [ICOS+]", g)
    print(f"     {g:12s} {s}  mean {s.mean():.2f};  ICOS+ fraction of Tfh {100*(vec('S04-A [ICOS+]', g)/s).mean():.0f}%")

print("\n=== (3) S09-A (log10, both panels labelled '16h') versus S01-A (linear; 16 h and 72 h) : Ifnb1 ===")
gs = ["CMP-204", "PSLN-212", "PSLN-R848", "PSLN-212/R848", "PSLN-344", "PSLN-212(Y)"]
rows = []
for g in gs:
    p1 = 10 ** vec("S09-A [panel1(cols A-U)]", g, "Ifnb1").mean(); p2 = 10 ** vec("S09-A [panel2(cols X-AS)]", g, "Ifnb1").mean()
    a16 = 10 ** np.log10(vec("S01-A [16h]", g)).mean(); a72 = 10 ** np.log10(vec("S01-A [72h]", g)).mean()
    rows.append((g, p1, p2, a16, a72))
D = pd.DataFrame(rows, columns=["group", "S09A_panel1_GM", "S09A_panel2_GM", "S01A_16h_GM", "S01A_72h_GM"]).round(2)
print(D.to_string(index=False))
lg = np.log10(D[["S09A_panel1_GM", "S09A_panel2_GM", "S01A_16h_GM", "S01A_72h_GM"]].values)
print("  Pearson r (log10 GMs): panel1~16h %.3f  panel1~72h %.3f  panel2~16h %.3f  panel2~72h %.3f" % (
    np.corrcoef(lg[:, 0], lg[:, 2])[0, 1], np.corrcoef(lg[:, 0], lg[:, 3])[0, 1], np.corrcoef(lg[:, 1], lg[:, 2])[0, 1], np.corrcoef(lg[:, 1], lg[:, 3])[0, 1]))
print("  mean |log10 ratio|: panel1 vs 16h %.3f ; panel2 vs 72h %.3f ; panel2 vs 16h %.3f" % (
    np.abs(lg[:, 0] - lg[:, 2]).mean(), np.abs(lg[:, 1] - lg[:, 3]).mean(), np.abs(lg[:, 1] - lg[:, 2]).mean()))

print("\n=== (4) S08-A at 20 ug versus S01-A 16 h (same measurand, same dose) ===")
for g in ("CMP-204", "PSLN-212", "PSLN-344"):
    print(f"  {g:10s} S08-A@20ug mean {vec('S08-A', g, 20).mean():.1f} (n=3)   S01-A 16h mean {vec('S01-A [16h]', g).mean():.1f} (n=5)")
print("  'PSLN-344/R848' (S08-A) is not a preparation listed in the annotation's Materials; S01-A/S09-A list 'PSLN-212/R848':")
print(f"     S08-A 'PSLN-344/R848'@20ug mean {vec('S08-A', 'PSLN-344/R848', 20).mean():.1f}  vs S01-A 'PSLN-212/R848' 16h mean {vec('S01-A [16h]', 'PSLN-212/R848').mean():.1f}")

print("\n=== (5) S08-C versus S01-B (SRB-positive alveolar epithelial cells) ===")
for g in ("AECII/PSLN-SRB", "AECI/PSLN-SRB"):
    print(f"  S01-B {g:22s} {vec('S01-B', g)} mean {vec('S01-B', g).mean():.2f}")
for g in ("AECII-PSLN-SRB", "AECII-PSLN-344-SRB", "AECI-PSLN-SRB", "AECI-PSLN-344-SRB"):
    print(f"  S08-C {g:22s} {vec('S08-C', g)} mean {vec('S08-C', g).mean():.2f}")
print("  As printed: S08-C AECI-PSLN-SRB 13.8% vs S01-B AECI/PSLN-SRB 3.8% (same construct, same cell type, 3.6-fold apart).")
print("  If S08-C columns were ordered [AECII-PSLN, AECI-PSLN, AECII-344, AECI-344] both blocks agree (AECII 15.8 v 15.8; AECI 3.8 v 3.8).")

print("\n=== (6) S11-A (alveolar macrophages) versus S11-B (neutrophils): identical cells ===")
a = M[M.block == "S11-A"].set_index(["group", "x", "rep"]).value; b = M[M.block == "S11-B"].set_index(["group", "x", "rep"]).value
eq = (a == b)
print(f"  identical values in identical positions: {int(eq.sum())} of {len(eq)} ; by replicate position: {eq.groupby(level='rep').sum().to_dict()}")
print(f"  group x day cells whose means differ by <1.5 points: {int(((a.groupby(level=[0,1]).mean()-b.groupby(level=[0,1]).mean()).abs()<1.5).sum())} of 20")

print("\n=== (7) S06-C versus S06-D ; S15-C versus S15-I ; S09-C day-12 rows ===")
def sv(bp):
    return {g: sorted(zip(d.day, d.event)) for g, d in S[S.block_panel == bp].groupby("group", sort=False)}
print("  S06-C == S06-D for every arm:", sv("S06-C") == sv("S06-D"))
c = M[(M.block == "S15-C") & (M.group == "PSLN-344")].pivot(index="x", columns="rep", values="value")
i = M[(M.block == "S15-I") & (M.group == "3d Vaccine+PSLN-344")].pivot(index="x", columns="rep", values="value")
c.index = c.index.astype(int); i.index = i.index.astype(int)
eqm = (c.values == i.values)
print(f"  S15-C PSLN-344 vs S15-I '3d Vaccine+PSLN-344': identical cells {int(eqm[1:].sum())} of {eqm[1:].size} (days 2-14); by day:", dict(zip(c.index[1:], eqm[1:].sum(axis=1))))
d12a = vec("S09-C", "PSLN-212(Y)", 12); d12b = vec("S09-C", "PSLN-344(Y)", 12)
print("  S09-C day-12 row PSLN-212(Y) == PSLN-344(Y):", np.array_equal(d12a, d12b), d12a)
a4 = vec("S15-A", "Sham", 4); m4 = vec("S15-M", "PSLN-212", 4)
print("  S15-A Sham day 4 == S15-M PSLN-212 day 4 (BALB/c vs C57BL/6 experiment):", np.array_equal(a4, m4), a4)
A = M[(M.block == "S15-A") & (M.group == "PSLN-344")].pivot(index="x", columns="rep", values="value").values
Mm = M[(M.block == "S15-M") & (M.group == "PSLN-344")].pivot(index="x", columns="rep", values="value").values
O = M[(M.block == "S15-O") & (M.group == "PSLN-344")].pivot(index="x", columns="rep", values="value").values
print("  S15-M PSLN-344 (C57BL/6) vs S15-A PSLN-344 (BALB/c): identical cells per animal column (days 2-14):", (A[1:] == Mm[1:]).sum(axis=0))
print("  S15-O PSLN-344 (Swiss Webster) vs S15-M PSLN-344: identical cells per animal column:", (O[1:] == Mm[1:]).sum(axis=0))
print("  S15-O PSLN-344 vs S15-A PSLN-344: identical cells per animal column:", (O[1:] == A[1:]).sum(axis=0))

print("\n=== (8) Body-weight values that recur across blocks with whole-number offsets ===")
wbks = ["S13-F", "S13-G", "S08-D", "S09-C", "S09-E", "S09-G"] + [f"S15-{c}" for c in "ABCDEFGIJKMO"]
W = M[M.block.isin(wbks)].copy()
W["frac"] = (W.value - np.floor(W.value)).round(6)
hp = W[np.abs(W.value * 10 - np.round(W.value * 10)) > 1e-6]          # values carrying more than one decimal
g = hp.groupby("frac").agg(n=("value", "size"), blocks=("block", lambda s: sorted(set(s))), vals=("value", lambda s: sorted(set(np.round(s, 6)))))
rec = g[g.blocks.map(len) >= 2].sort_values("n", ascending=False)
print(f"  weight cells: {len(W)}; cells with more than one decimal: {len(hp)}, in blocks {hp.block.value_counts().to_dict()}")
print(f"  of these, {int(rec.n.sum())} share their six-digit fractional part with a value in a different block ({len(rec)} distinct fractional parts)")
for fr, r in rec.head(6).iterrows():
    print(f"    .{str(fr)[2:]:6s}  {r.vals[:6]}  in {r.blocks}")
arm_hp = hp.groupby(["block", "group"]).size()
print("  arms that contain such values:", {f"{b}/{g_}": int(n) for (b, g_), n in arm_hp.items()})

print("\n=== (9) Whole animal trajectories shared between weight blocks (days 2-14, 7 values per animal) ===")
def tr(block, group):
    p = M[(M.block == block) & (M.group == group)].pivot(index="x", columns="rep", values="value"); p.index = p.index.astype(int)
    return p.sort_index().iloc[1:]
def best_matches(b1, g1, b2, g2):
    A_, B_ = tr(b1, g1), tr(b2, g2); out = []
    for c1 in A_.columns:
        best = max(((int(np.sum(np.abs(A_[c1].values - B_[c2].values) < 1e-9)), c2) for c2 in B_.columns))
        out.append((int(c1), best[1], best[0]))
    return out
for b1, g1, b2, g2 in (("S15-M", "PSLN-212(Y)", "S09-E", "PSLN-344(Y)"), ("S09-E", "PSLN-212(Y)", "S09-G", "PSLN-212(Y)"), ("S15-M", "PSLN-344", "S15-A", "PSLN-344"),
                       ("S15-O", "PSLN-344", "S15-M", "PSLN-344"), ("S15-C", "PSLN-344", "S15-I", "3d Vaccine+PSLN-344")):
    bm = best_matches(b1, g1, b2, g2)
    print(f"  {b1} {g1} vs {b2} {g2}: identical days per animal (animal -> best-matching animal: n of 7) ", [f"{a}->{b}:{n}" for a, b, n in bm],
          "| animals with >=4 identical days:", sum(1 for _, _, n in bm if n >= 4))

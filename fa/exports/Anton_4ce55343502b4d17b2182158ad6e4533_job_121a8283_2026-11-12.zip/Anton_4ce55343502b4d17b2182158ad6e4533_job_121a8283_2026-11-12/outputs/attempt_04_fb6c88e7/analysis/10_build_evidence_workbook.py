"""10_build_evidence_workbook.py -- collects every output table into one Excel file for the committee pack."""
import pandas as pd, os
T = "/tmp/outputs/tables"
sheets = [("README", None),
          ("number_ledger", "number_ledger.csv"), ("integrity_register", "integrity_register.csv"),
          ("T1_survival_by_arm", "T1_survival_by_arm.csv"), ("T2_survival_key_contrasts", "T2b_survival_key_contrasts.csv"), ("T3_survival_pooled", "T3_survival_pooled_and_sensitivity.csv"),
          ("T4_weight_concordance", "T4_bodyweight_by_arm_and_concordance.csv"), ("T4b_nadir_contrasts", "T4b_nadir_contrasts.csv"),
          ("T5_immuno_summaries", "T5_immunology_group_summaries.csv"), ("T5c_immuno_key_contrasts", "T5c_immunology_key_contrasts_PSLN344.csv"), ("T6_restoration_index", "T6_restoration_index.csv"),
          ("T7_dose_response", "T7_dose_response_S08A.csv"), ("T8_postvacc_weight", "T8_postvaccination_weight_S08D.csv"), ("T9_lung_cytokines", "T9_lung_cytokines_S09A.csv"), ("T10_CNS", "T10_CNS_S10A.csv"),
          ("T11_two_way_anova", "T11_two_way_anova_timecourses.csv"), ("T12_two_group_blocks", "T12_two_group_mechanism_blocks.csv")]
readme = pd.DataFrame({"sheet": [s for s, _ in sheets[1:]], "content": [
    "Every headline number in the memo: id, statement, value, source block(s), workbook cells, how it was reduced",
    "Record-integrity findings: evidence, effect on conclusions, how handled, what closes them",
    "Every time-to-event arm: n, deaths, survivors, exact 95% CI, death days, cell addresses",
    "Within-experiment contrasts: survivors, risk difference (Newcombe CI), log-rank exact and asymptotic p, Fisher p",
    "Pooled/stratified survival analyses and all sensitivity analyses",
    "Body-weight blocks: animals alive / carried-forward / blank per arm versus deaths in the paired survival block; nadirs",
    "Per-experiment nadir contrasts PSLN-344 vs young benchmark, PSLN-212, Sham",
    "Group summaries (n, mean, SD, geometric mean, cells) for every non-survival, non-weight block",
    "PSLN-344 vs PSLN-212 / Sham / young benchmark for every block: effect size, CI, Tukey, Welch, exact Mann-Whitney",
    "Restoration index with bootstrap CI for every block that has PSLN-212, PSLN-344 and PSLN-212(Y)",
    "Hill fits to the Ifnb1 dose-response (S08-A)", "Post-vaccination weight nadirs (S08-D)", "Lung cytokine transcripts (S09-A), GM fold and contrasts", "CNS transcripts (S10-A)",
    "Two-way ANOVA (group x time) for time-course blocks", "Two-group mechanism/intervention blocks"]})
with pd.ExcelWriter("/tmp/outputs/PSLN-344_evidence_tables.xlsx", engine="openpyxl") as xw:
    readme.to_excel(xw, sheet_name="README", index=False)
    for name, f in sheets[1:]:
        pd.read_csv(os.path.join(T, f)).to_excel(xw, sheet_name=name[:31], index=False)
    for ws in xw.book.worksheets:
        for col in ws.columns:
            w = max(len(str(c.value)) if c.value is not None else 0 for c in col[:60])
            ws.column_dimensions[col[0].column_letter].width = min(max(10, w + 2), 70)
        ws.freeze_panes = "A2"
print("written")

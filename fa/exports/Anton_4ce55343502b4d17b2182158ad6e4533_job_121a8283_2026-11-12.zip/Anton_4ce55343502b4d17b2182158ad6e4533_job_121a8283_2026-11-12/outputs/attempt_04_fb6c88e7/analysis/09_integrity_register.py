"""09_integrity_register.py -- the record-integrity register (findings verified by 02_bodyweight.py and 04_integrity_checks.py)."""
import pandas as pd
OUT = "/tmp/outputs/tables"
R = []
def add(i, tier, blocks, finding, evidence, effect, handling, close):
    R.append(dict(id=i, tier=tier, blocks=blocks, finding=finding, evidence=evidence, effect_on_conclusions=effect, how_handled_here=handling, needed_to_close=close))

# ---- Tier A: touches an efficacy (survival / body-weight) block
add("A1", "A", "S06-C, S06-D", "Two different experiments carry identical time-to-event records.",
    "All 4 arms, 28 animals: every day and indicator cell of S06-D (challenge day 3) equals S06-C (challenge day 14); 56/56 cells.",
    "One of the two is not an independent experiment. Headline pooled numbers would be inflated by 7 PSLN-344 survivors if both were counted.",
    "Counted once (as S06-C). Reported both ways: 66/79 without S06-D, 73/86 with it.", "Animal-room death logs for both experiments.")
add("A2", "A", "S15-D vs S06-D", "The weight block for the day-3 rgH5N1 experiment implies deaths that its survival block does not record.",
    "S15-D: 2 PSLN-344 animals (cols W, AC) and 2 young PSLN-212 animals (cols F, G) have weights frozen at 79.5/85.2 and 82.1/76.5 from day 8-10 to day 14; S06-D records 7/7 survivors in both arms.",
    "If the weights are right, day-3 rgH5N1 survival with PSLN-344 is 5/7, not 7/7.", "S06-D is excluded from the primary pooled estimate; a sensitivity row in section 3.2 keeps it at 5/7 (pooled 71/86).", "As A1.")
add("A3", "A", "S15-C, S15-I, S15-M", "Body-weight traces are shared between different experiments.",
    "S15-C PSLN-344 (day-14 challenge) equals S15-I '3d Vaccine+PSLN-344' (day-3 challenge) in 40/42 cells on days 2-12; its day-14 row instead shares 5/7 values with S15-M PSLN-344 (C57BL/6).",
    "S15-C cannot be treated as independent morbidity evidence for the day-14 rgH5N1 experiment.", "Morbidity conclusions are drawn from nadirs pooled over 10 experiments and do not depend on S15-C.", "Original balance read-outs / cage cards.")
add("A4", "A", "S03-I vs S13-F", "The survival block and its own weight block name the arms differently.",
    "S03-I arms: Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y). S13-F ('the animals of S03-I'): PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naive. S13-F 'PSLN-212' has 3 animals recovering to 95-99% (S03-I PSLN-212: 0/7 survive; S03-I CMP-204: 3/7 survive); S13-F 'Naive' all dead by day 8.",
    "PSLN-344 7/7 and Sham 0/7 are concordant in both blocks. Whether aged PSLN-212 gives 0/7 or 3/7 in the homologous model, and whether a CMP-204 arm existed, is unresolved.",
    "PSLN-344-vs-Sham uses this block; PSLN-344-vs-PSLN-212 is reported with and without it (E5 vs E7) and with the alternative count (E6).", "Group allocation sheet for this experiment.")
add("A5", "A", "S03-J vs S13-G", "Same problem for the wild-type H5N1 experiment, plus an n discrepancy and a missing time.",
    "S03-J arms: Sham (1/10 survive), PSLN-212 (3/10), PSLN-344. S13-G ('the animals of S03-J'): PSLN-344, Sham (4-5 animals with real weights at day 14), Naive (1). Stated n is 9 in S03-J and 10 in S13-G; S03-J has 10 indicator cells per arm but the 10th PSLN-344 cell (J46) has no day (G46 blank). Annotation says observation ran 22 days; the largest day recorded is 21. The challenge dose is not stated.",
    "PSLN-344: no deaths under any reading. The identity of the 3/10 comparator (PSLN-212 or vaccine-alone) and of the 1/10 comparator (vaccine-alone or unvaccinated) is unresolved.",
    "PSLN-344 analysed with n=9 (recorded times); sensitivity with n=10 gives the same p-values. Comparator labels as printed in S03-J, flagged wherever cited.", "Group allocation sheet; BSL-3 log.")
add("A6", "A", "17 survival/weight block pairs", "Death counts disagree between paired blocks in 10 of 65 arms.",
    "Discordant arms (deaths by weights vs by survival block): S13-F PSLN-212 4 v 7; S13-G Sham 5 v 9; S15-C PSLN-212 6 v 5; S15-D PSLN-212(Y) 2 v 0; S15-D PSLN-344 2 v 0; S15-E PSLN-212 6 v 7; S15-E PSLN-344 1 v 2; S15-G PSLN-344 2 v 3; S15-M PSLN-212(Y) 0 v 1; S09-G Sham 8 animals v 7.",
    "None changes the direction of any contrast. For PSLN-344 arms the survival block records more deaths than the weights in two (S15-E, S15-G) and fewer in one (S15-D).", "Survival blocks are primary; worst-case pooled analyses (E3, E6) take the less favourable count for PSLN-344.", "Reconcile per animal ID.")
add("A7", "A", "S13-F, S13-G, S15-A..G, S15-M, S15-O", "Dead animals' last weight is carried forward to day 14 in adjuvant arms but blanked in Sham arms.",
    "e.g. S15-B PSLN-212: all 7 animal columns are constant from day 4-10 onward while S06-B records 7 deaths; Sham columns go blank. Annotation says n 'declines' in these arms.",
    "Group mean weights taken as printed are biased (dead animals keep contributing their last weight) and are not comparable between arms.", "Carried-forward values excluded; per-animal nadir on real values used instead.", "Re-export weights with blanks after death.")
add("A8", "A", "S06-E(1), S06-F(1), S06-G; S15-E/F/G", "Unchallenged, unvaccinated aged animals died during the observation window.",
    "'Untreated' arms (annotation: no vaccine, no adjuvant, no challenge virus): 1/7, 0/7 and 3/7 deaths = 4/21 (19%; 95% CI 5-42) in 14 days; their last real weights are 94-97% of day 0.",
    "At >=22 months the day-60 experiments have material background mortality; PSLN-344 day-60 survival (14/21) is not statistically distinguishable from unchallenged animals (17/21; p = 0.48). But the PSLN-344 animals that died had lost 15-22% weight first, so I read most of the waning as real.",
    "Reported explicitly; durability conclusion stated with this caveat.", "Necropsy records; include unchallenged sentinels in every aged-animal study.")
add("A9", "A", "S15-L/M, S15-N/O", "Strain-generalisation experiments: challenge not specified; weight traces re-use BALB/c values.",
    "Annotation gives no challenge virus, dose or day for S15-L/S15-N. S15-M PSLN-344: 3 of 7 animals equal S15-A PSLN-344 (BALB/c) on 5 of 7 days; S15-M young arm: 6 of 7 animals share 4-7 of their 7 daily weights with animals of the young BALB/c PSLN-344 arm of S09-E; S15-A Sham day-4 row = S15-M PSLN-212 day-4 row; one young C57BL/6 death (S15-L, day 12) has no counterpart in S15-M.",
    "Survival blocks S15-L/S15-N are distinct records, but the independence of these experiments is not assured.", "Pooled estimate also given for BALB/c only (E4: 54/65 vs 1/66).", "Study protocols and raw weights for both strains.")
add("A10", "A", "S06 rows 71-105", "Two blocks re-use the labels S06-E and S06-F (imprinting study).", "Annotation acknowledges the duplicate labels. Challenge day is not stated for the PR8 block; dose is written '5 x LD50' (elsewhere '5 x mLD50').",
    "Naming only; handled by row range.", "Referred to here as S06-E(2) and S06-F(2).", "Relabel.")
add("A11", "A", "S13-E", "Stated n (5) differs from animals present (7 per arm).", "Header 'n=5'; 28 indicator cells = 7 per arm.", "Young-mouse block; not in pooled estimates.", "Used 7 per arm.", "Confirm.")
add("A12", "A", "S09-B, S09-F, S09-G", "Annotation and workbook disagree on which young-mouse block has 7 Sham animals.",
    "Annotation: S09-B Sham n=7, S09-F n=8. Workbook: S09-B Sham 8, S09-F Sham 7 (while S09-G, its weight block, has 8 Sham traces).", "None (all Sham animals die in all three blocks).", "Workbook counts used.", "Confirm.")
add("A13", "A", "S09-C", "A whole row is duplicated across arms.", "Day-12 weights of PSLN-344(Y) equal those of PSLN-212(Y) in all 8 positions.", "Day-12 means in S09-C are not usable; day-14 and nadir unaffected.", "Not used.", "Re-export.")
add("A14", "A", "S08 rows 89-101", "Unlabelled data.", "Column A = 14 in 13 rows; zeros in column C (6 rows) and column D (7 rows); no header, no group names. Resembles two all-survivor arms of a time-to-event block.",
    "Cannot be attributed to any experiment.", "Excluded.", "Identify or delete.")
add("A15", "A", "S15-A, -C, -F, -J, -K, -M, -O; S08-D; S09-E", "Weight values recur across blocks, shifted by whole numbers.",
    "Of 289 weight values recorded with more than one decimal, 168 share their six-digit fractional part with a value in a different block (67 distinct fractions): e.g. 87.423077, 88.423077, 89.423077, 92.423077 and 94.423077 across S15-A, -J, -K, -M and -O; 94.45455 to 99.45455 across six blocks. Independent weighings do not produce this pattern; copying a trace and adding a constant does.",
    "Several weight traces, including PSLN-344 arms in S15-A, S15-F, S15-J and S15-M, are not independent records. Weight-based statements (nadir, morbidity, the cross-check of deaths) are provisional. The time-to-event blocks record whole days, so this check cannot be applied to them; their only exact duplicate is S06-C/S06-D (A1).",
    "Survival blocks are treated as the primary evidence; weights are used for cross-checks and for a morbidity estimate that is labelled provisional.", "Original balance read-outs for every challenge experiment.")
# ---- Tier B: mechanism / biomarker / tolerability blocks
add("B1", "B", "S03-B, S03-F vs S13-A..D", "Column labels of the IgG2a:IgG1 quotient blocks are rotated relative to the raw titres.",
    "Per-animal S13-A/S13-B reproduces the printed S03-B values but under different headers: printed 'PSLN-344' column = ratio for PSLN-212; printed 'PSLN-212(Y)' = PSLN-344; printed 'PSLN-212' = PSLN-212(Y). Same rotation in S03-F. Raw-titre labels agree with total IgG (S03-A/E).",
    "As printed, PSLN-344 would appear IgG1-skewed (0.58); from raw titres it is IgG2a-skewed (GM 1.85 and 2.30) and PSLN-212 is the IgG1-skewed arm (0.54, 0.46).", "Recomputed from raw titres; printed quotient blocks not used.", "Correct headers.")
add("B2", "B", "S04-B 'Tfh:Tfr'", "Derived block, not an independent measurement.", "Every value equals (100 - Foxp3%) / Foxp3% from the S04-B Foxp3 block, row by row.", "Cannot be counted as a second line of evidence next to Tfr%.", "Reported once (as Tfr%).", "None.")
add("B3", "B", "S09-A", "Both panels are labelled '16h'; control named 'PBS' here and 'Sham' in S01-A; data are log10.",
    "Back-transformed Ifnb1 values of panel 1 coincide with individual S01-A 16-h animals in 18/18 cells and those of panel 2 with S01-A 72-h animals in 17/18 (0/18 with 16 h). 'PBS' values equal S01-A 'Sham' values.",
    "Panel 2 is a 72-h panel. S09-A is a 3-animal subset of the S01-A animals, not a replicate experiment.", "Panel 2 analysed as 72 h (flagged as inferred); means taken on the log scale.", "Correct label.")
add("B4", "B", "S11-A, S11-B", "Alveolar-macrophage and neutrophil blocks share values.", "35/100 values identical in the same position (replicates 1-2 of almost every group x day cell); 18/20 cell means within 1.5 points.",
    "The neutrophil block cannot be relied on, so there is no usable read-out of neutrophilic lung inflammation in the package.", "Neither block used for conclusions.", "Original FCS-derived tables.")
add("B5", "B", "S07-C", "Both columns carry the same printed label.", "Header 'Ly6C-CD206+ MPhi' twice; annotation says Ly6C+CD206- and Ly6C-CD206+ macrophages were transferred. Means 10.4% vs 5.1% Treg.",
    "Which macrophage subset raises lung Treg cannot be assigned.", "Not used.", "Correct header.")
add("B6", "B", "S07-A vs S01-D, S07-B, S11-E", "Direction conflicts with three other blocks.", "S07-A: Ly6C+CCR2+ macrophages peak 19.0 x10^5 with PSLN-212 vs 3.4 x10^5 with PSLN-344 (n=3). S01-D monocytes 16.7% vs 30.6%; S07-B Ly6C+ macrophages 15.4% with PSLN-344; S11-E CD206+ 71% vs 49%.",
    "Either a real divergence (monocytes become macrophages with PSLN-212, DCs with PSLN-344) or swapped headers; the package cannot tell.", "Macrophage arm of the mechanism left out of the causal chain.", "Confirm headers; repeat with n>=5.")
add("B7", "B", "S08-C vs S01-B", "Same construct and cell type differ 3.6-fold between blocks unless S08-C headers are mis-ordered.",
    "AECI positive for PSLN-SRB: 3.8% (S01-B) vs 13.8% (S08-C). If S08-C columns are read as [AECII-PSLN, AECI-PSLN, AECII-344, AECI-344] the two blocks agree (15.8/3.8 vs 15.8/3.8) and Mn does not change epithelial delivery (13.8% vs 15.8%; 3.0% vs 3.8%).",
    "As printed, Mn incorporation would cut epithelial delivery ~4-fold; under the alternative reading it does not.", "Neither reading used to support a claim.", "Correct header.")
add("B8", "B", "S08-A", "A preparation not described in Materials.", "'PSLN-344/R848' appears only here; Materials lists 'PSLN-212/R848'.", "None for PSLN-344.", "Arm not interpreted.", "Clarify.")
add("B9", "B", "S08-B", "Assay applicability.", "Encapsulation efficiency is defined by CDN-1807 absorbance at 260 nm but is reported for PSLN-R848 (no CDN-1807) and CMP-204 (cGAMP).", "None for the PSLN-344 vs PSLN-212 comparison (54.8% vs 59.6%).", "Only those two arms cited.", "Method note.")
add("B10", "B", "S05-A, S05-B (and S05-I by reference)", "n, conditions and strain are inconsistent.", "Stated n=3, 2 values per cell. Conditions describe both ovalbumin immunisation and the bivalent vaccine. NP366-374 tetramers are H-2Db-restricted, i.e. a C57BL/6 reagent, while the default strain is BALB/c; the block does not name a strain.",
    "Early tetramer kinetics cannot be taken at face value.", "Cited only as supportive; early CD8 evidence rests on S05-D/E (n=5).", "Protocol for this block.")
add("B11", "B", "S02-C, S02-E", "The 'PTX' arm's adjuvant and age are not stated.", "Header 'PTX' only.", "Comparator for the migration-blockade claim is undefined.", "Reported as printed.", "Clarify.")
add("B12", "B", "S07-B, S11-E, S13-H, S14-A", "Time point not stated.", "The annotation gives none for S07-B and S11-E and says 'not stated' for S13-H and S14-A.", "Kinetic interpretation not possible.", "Used as cross-sectional evidence only.", "Add.")
add("B13", "B", "S02-H, S02-I, S12-A, S01-C", "Key causal experiments were run in young or knockout animals, not aged.", "S02-I and S12-A are stated young; S01-C uses 7-8-week knockout mice; S02-H recipients' age is not stated. S02-F (Gm-csf) has no young arm.",
    "The IFN-I -> GM-CSF -> moDC -> CD8 chain is demonstrated piecewise, mostly outside aged animals.", "Stated wherever cited.", "Repeat key steps in aged mice (Study 2).")
# ---- Tier C: gaps in the package
add("C1", "C", "whole package", "Dose of manganese is not recorded.", "Doses are given as micrograms of adjuvant; no Mn content, Mn:CDN ratio or release data.", "No exposure margin can be calculated for the element that carries the main toxicological question.", "-", "ICP-MS on retained batches.")
add("C2", "C", "whole package", "No physico-chemical data.", "Annotation describes DLS, zeta potential, TEM and lyophilisation, but the workbook contains only encapsulation efficiency (n=3).", "Batch comparability and stability unknown.", "-", "CMC work-stream.")
add("C3", "C", "whole package", "Read-outs absent.", "No lung viral titres, no histopathology, no mucosal IgA, no serology against challenge strains, no measurement in blood other than serum antibody, no animal IDs linking immunology to outcome.", "Limits mechanism and correlate analysis.", "-", "Studies 1-2.")
add("C4", "C", "whole package", "Single sex, single dose level for efficacy, single antigen format.", "Female mice only; all efficacy at 20 ug; formalin-inactivated whole virus made in-house.", "Generalisability.", "-", "Studies 1 and 4.")
REG = pd.DataFrame(R)
REG.to_csv(f"{OUT}/integrity_register.csv", index=False)
print(len(REG), "register entries;", (REG.tier == "A").sum(), "A,", (REG.tier == "B").sum(), "B,", (REG.tier == "C").sum(), "C")

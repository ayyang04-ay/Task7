"""
parse_workbook.py  --  explicit, cell-addressed parser for adjuvant_program_dataset.xlsx

Every block is declared by sheet + cell ranges so that every number in the downstream
analysis can be traced back to workbook cell addresses. Nothing is inferred from layout.

Outputs (written by main()):
  tables/tidy_measurements.csv   one row per numeric observation (non-survival blocks)
  tables/tidy_survival.csv       one row per animal (time-to-event blocks)
"""
import re
import openpyxl
import pandas as pd
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI

XLSX = "/tmp/world/filesystem/adjuvant_program_dataset.xlsx"
OUT = "/tmp/outputs/tables"

def cols(a, b):
    return [L(i) for i in range(CI(a), CI(b) + 1)]

# ----------------------------------------------------------------------------------
# Block declarations
#   kind = "rows"    : one group per ROW   (label in label_col, replicate values across value cols)
#   kind = "cols"    : one group per COLUMN (header row, replicates down rows)
#   kind = "wide"    : group = column span, rows = timepoint/analyte/dose (label in time_col)
#   kind = "surv"    : day column + 0/1 indicator columns (one per group)
# ----------------------------------------------------------------------------------
B = []
def rows(sheet, block, panel, label_col, vcols, rws, **kw):
    B.append(dict(kind="rows", sheet=sheet, block=block, panel=panel, label_col=label_col, vcols=vcols, rws=rws, **kw))
def colsb(sheet, block, panel, header_row, gcols, rws, **kw):
    B.append(dict(kind="cols", sheet=sheet, block=block, panel=panel, header_row=header_row, gcols=gcols, rws=rws, **kw))
def wide(sheet, block, panel, time_col, spans, rws, **kw):
    # spans: list of (group_name_cell, first_col, last_col)
    B.append(dict(kind="wide", sheet=sheet, block=block, panel=panel, time_col=time_col, spans=spans, rws=rws, **kw))
def surv(sheet, block, panel, day_col, gcols, header_row, rws, **kw):
    B.append(dict(kind="surv", sheet=sheet, block=block, panel=panel, day_col=day_col, gcols=gcols, header_row=header_row, rws=rws, **kw))

# ---- S01
rows("S01", "S01-A", "16h", "A", cols("B", "F"), range(3, 11))
rows("S01", "S01-A", "72h", "G", cols("H", "L"), range(3, 11))
rows("S01", "S01-B", "", "A", cols("B", "F"), range(14, 18))
rows("S01", "S01-C", "", "A", cols("B", "E"), range(20, 22))
wide("S01", "S01-D", "", "A", [("B23", "B", "F"), ("G23", "G", "K"), ("L23", "L", "P"), ("Q23", "Q", "U")], range(24, 29))
wide("S01", "S01-E", "", "A", [("B29", "B", "F"), ("G29", "G", "K"), ("L29", "L", "P"), ("Q29", "Q", "U"), ("V29", "V", "Z")], range(30, 35))
wide("S01", "S01-F", "", None, [("B35", "B", "F"), ("G35", "G", "K"), ("L35", "L", "P"), ("Q35", "Q", "U"), ("V35", "V", "Z")], range(36, 37))
wide("S01", "S01-G", "", None, [("B37", "B", "F"), ("G37", "G", "K"), ("L37", "L", "P"), ("Q37", "Q", "U"), ("V37", "V", "Z")], range(38, 39))
# ---- S02
colsb("S02", "S02-A", "", 2, cols("A", "D"), range(3, 8))
colsb("S02", "S02-B", "", 2, cols("F", "I"), range(3, 8))
colsb("S02", "S02-C", "", 2, cols("K", "O"), range(3, 8))
colsb("S02", "S02-D CD40", "", 9, cols("A", "D"), range(10, 15))
colsb("S02", "S02-D CD86", "", 9, cols("F", "I"), range(10, 15))
colsb("S02", "S02-E", "", 9, cols("K", "O"), range(10, 15))
wide("S02", "S02-F", "", "A", [("B16", "B", "F"), ("G16", "G", "K"), ("L16", "L", "P")], range(17, 20))
colsb("S02", "S02-G", "", 21, cols("B", "D"), range(22, 27))
colsb("S02", "S02-H", "", 29, cols("B", "F"), range(30, 35))
colsb("S02", "S02-I", "", 29, cols("H", "I"), range(30, 35))
# ---- S03
colsb("S03", "S03-A", "", 2, cols("A", "E"), range(3, 8))
colsb("S03", "S03-B", "", 2, cols("G", "I"), range(3, 8))
colsb("S03", "S03-C", "", 2, cols("K", "O"), range(3, 8))
colsb("S03", "S03-D", "", 2, cols("Q", "U"), range(3, 8))
colsb("S03", "S03-E", "", 9, cols("A", "E"), range(10, 15))
colsb("S03", "S03-F", "", 9, cols("G", "I"), range(10, 15))
colsb("S03", "S03-G", "", 9, cols("K", "O"), range(10, 15))
colsb("S03", "S03-H", "", 9, cols("Q", "U"), range(10, 15))
surv("S03", "S03-I", "", "A", cols("B", "F"), 16, range(17, 52))
surv("S03", "S03-J", "", "G", cols("H", "J"), 16, range(17, 47))
colsb("S03", "S03-K", "", 16, cols("L", "O"), range(17, 22))
rows("S03", "S03-L", "Aicda", "K", cols("L", "N"), range(26, 29))
rows("S03", "S03-L", "E47", "K", cols("O", "Q"), range(26, 29))
# ---- S04
rows("S04", "S04-A", "ICOS-", "A", cols("B", "F"), range(2, 6))
rows("S04", "S04-A", "ICOS+", "A", cols("G", "K"), range(2, 6))
colsb("S04", "S04-B Foxp3", "", 7, cols("A", "D"), range(8, 13))
colsb("S04", "S04-B Tfh:Tfr", "", 14, cols("A", "D"), range(15, 20))
colsb("S04", "S04-C", "", 21, cols("A", "D"), range(22, 27))
colsb("S04", "S04-D", "", 28, cols("A", "D"), range(29, 32))
# ---- S05
wide("S05", "S05-A", "Lung", "A", [("B2", "B", "C"), ("E2", "E", "F"), ("H2", "H", "I")], range(3, 6))
wide("S05", "S05-B", "MLN", "A", [("B7", "B", "C"), ("E7", "E", "F"), ("H7", "H", "I")], range(8, 11))
colsb("S05", "S05-C", "", 12, cols("A", "D"), range(13, 16))
colsb("S05", "S05-D", "", 18, cols("A", "D"), range(19, 24))
colsb("S05", "S05-E", "", 25, cols("A", "D"), range(26, 31))
colsb("S05", "S05-F", "", 32, cols("A", "D"), range(33, 38))
colsb("S05", "S05-G", "", 39, cols("A", "D"), range(40, 45))
colsb("S05", "S05-H", "", 46, cols("A", "D"), range(47, 52))
colsb("S05", "S05-I", "", 53, cols("A", "D"), range(54, 59))
# ---- S06 (all time-to-event)
surv("S06", "S06-A", "", "A", cols("B", "E"), 2, range(3, 31))
surv("S06", "S06-B", "", "G", cols("H", "K"), 2, range(3, 31))
surv("S06", "S06-C", "", "M", cols("N", "Q"), 2, range(3, 31))
surv("S06", "S06-D", "", "A", cols("B", "E"), 33, range(34, 62))
surv("S06", "S06-E", "rows34-68", "G", cols("H", "L"), 33, range(34, 69))
surv("S06", "S06-F", "rows34-68", "M", cols("N", "R"), 33, range(34, 69))
surv("S06", "S06-G", "", "A", cols("B", "F"), 70, range(71, 106))
surv("S06", "S06-E", "rows71-105(imprint/PR8)", "G", cols("H", "K"), 70, range(71, 99))
surv("S06", "S06-F", "rows71-105(imprint/Perth)", "M", cols("N", "Q"), 70, range(71, 99))
# ---- S07
wide("S07", "S07-A", "", "A", [("B2", "B", "D"), ("E2", "E", "G")], range(3, 8))
colsb("S07", "S07-B", "CD11b+Ly6C+ Monocytes", 9, cols("B", "C"), range(10, 15))
colsb("S07", "S07-B", "Ly6C+ Mphi", 9, cols("E", "F"), range(10, 15))
colsb("S07", "S07-C", "", 15, cols("B", "C"), range(16, 21), positional_labels=True)
# ---- S08
wide("S08", "S08-A", "", "A", [("B2", "B", "D"), ("E2", "E", "G"), ("H2", "H", "J"), ("K2", "K", "M")], range(3, 8))
wide("S08", "S08-B", "", None, [("A10", "A", "C"), ("D10", "D", "F"), ("G10", "G", "I"), ("J10", "J", "L"), ("M10", "M", "O")], range(11, 12))
colsb("S08", "S08-C", "", 13, cols("A", "D"), range(14, 19))
wide("S08", "S08-D", "", "A", [("B20", "B", "F"), ("G20", "G", "K"), ("L20", "L", "P"), ("Q20", "Q", "U"), ("V20", "V", "Z"), ("AA20", "AA", "AE")], range(21, 27))
# ---- S09
s09_spans1 = [("B2", "B", "D"), ("E2", "E", "G"), ("H2", "H", "J"), ("K2", "K", "M"), ("N2", "N", "P"), ("Q2", "Q", "S"), ("T2", "T", "V")]
s09_spans2 = [("Y2", "Y", "AA"), ("AB2", "AB", "AD"), ("AE2", "AE", "AG"), ("AH2", "AH", "AJ"), ("AK2", "AK", "AM"), ("AN2", "AN", "AP"), ("AQ2", "AQ", "AS")]
wide("S09", "S09-A", "panel1(cols A-U)", "A", s09_spans1, range(3, 10))
wide("S09", "S09-A", "panel2(cols X-AS)", "X", s09_spans2, range(3, 10))
surv("S09", "S09-B", "", "A", cols("B", "D"), 11, range(12, 36))
wide("S09", "S09-C", "", "F", [("G11", "G", "N"), ("O11", "O", "V"), ("W11", "W", "AD")], range(12, 20))
surv("S09", "S09-D", "", "A", cols("B", "D"), 38, range(39, 63))
wide("S09", "S09-E", "", "F", [("G38", "G", "N"), ("O38", "O", "V"), ("W38", "W", "AD")], range(39, 47))
surv("S09", "S09-F", "", "A", cols("B", "D"), 65, range(66, 89))
wide("S09", "S09-G", "", "F", [("G65", "G", "N"), ("O65", "O", "V"), ("W65", "W", "AD")], range(66, 74))
# ---- S10
colsb("S10", "S10-A", "Ifnb1", 2, cols("A", "D"), range(3, 8))
colsb("S10", "S10-A", "Tnf", 2, cols("F", "I"), range(3, 8))
colsb("S10", "S10-A", "Isg15", 2, cols("K", "N"), range(3, 8))
# ---- S11
s11_spans = lambda r: [(f"B{r}", "B", "F"), (f"G{r}", "G", "K"), (f"L{r}", "L", "P"), (f"Q{r}", "Q", "U")]
wide("S11", "S11-A", "", "A", s11_spans(2), range(3, 8))
wide("S11", "S11-B", "", "A", s11_spans(9), range(10, 15))
colsb("S11", "S11-C", "", 16, cols("A", "B"), range(17, 22))
wide("S11", "S11-D", "", "A", s11_spans(23), range(24, 29))
colsb("S11", "S11-E", "", 30, cols("A", "D"), range(31, 36))
# ---- S12
colsb("S12", "S12-A", "", 2, cols("A", "B"), range(3, 6))
# ---- S13
colsb("S13", "S13-A", "", 2, cols("A", "C"), range(3, 8))
colsb("S13", "S13-B", "", 2, cols("E", "G"), range(3, 8))
colsb("S13", "S13-C", "", 2, cols("I", "K"), range(3, 8))
colsb("S13", "S13-D", "", 2, cols("M", "O"), range(3, 8))
surv("S13", "S13-E", "", "R", cols("S", "V"), 2, range(3, 31))
wide("S13", "S13-F", "", "A", [("B32", "B", "H"), ("I32", "I", "O"), ("P32", "P", "V"), ("W32", "W", "AC"), ("AD32", "AD", "AJ")], range(33, 41))
wide("S13", "S13-G", "", "A", [("B42", "B", "K"), ("L42", "L", "U"), ("V42", "V", "AE")], range(43, 51))
colsb("S13", "S13-H", "", 52, cols("A", "D"), range(53, 58))
colsb("S13", "S13-I", "", 52, cols("F", "J"), range(53, 58))
colsb("S13", "S13-J", "", 52, cols("L", "P"), range(53, 58))
# ---- S14
colsb("S14", "S14-A H1N1", "", 2, cols("A", "D"), range(3, 8))
colsb("S14", "S14-A H3N2", "", 2, cols("F", "I"), range(3, 8))
# ---- S15
s15_4 = lambda r: [(f"B{r}", "B", "H"), (f"I{r}", "I", "O"), (f"P{r}", "P", "V"), (f"W{r}", "W", "AC")]
s15_5 = lambda r: s15_4(r) + [(f"AD{r}", "AD", "AJ")]
wide("S15", "S15-A", "", "A", s15_4(2), range(3, 11))
wide("S15", "S15-B", "", "A", s15_4(12), range(13, 21))
wide("S15", "S15-C", "", "A", s15_4(22), range(23, 31))
wide("S15", "S15-D", "", "A", s15_4(32), range(33, 41))
wide("S15", "S15-E", "", "A", s15_5(42), range(43, 51))
wide("S15", "S15-F", "", "A", s15_5(52), range(53, 61))
wide("S15", "S15-G", "", "A", s15_5(62), range(63, 71))
surv("S15", "S15-H", "", "A", cols("B", "D"), 72, range(73, 94))
wide("S15", "S15-I", "", "H", [("I71", "I", "O"), ("P71", "P", "V"), ("W71", "W", "AC")], range(72, 80))
s15_h = lambda r: [(f"I{r}", "I", "O"), (f"P{r}", "P", "V"), (f"W{r}", "W", "AC"), (f"AD{r}", "AD", "AJ")]
wide("S15", "S15-J", "", "H", s15_h(82), range(83, 91))
wide("S15", "S15-K", "", "H", s15_h(92), range(93, 101))
surv("S15", "S15-L", "", "A", cols("B", "E"), 102, range(103, 131))
wide("S15", "S15-M", "", "H", s15_h(102), range(103, 111))
surv("S15", "S15-N", "", "A", cols("B", "E"), 133, range(134, 162))
wide("S15", "S15-O", "", "H", s15_h(133), range(134, 142))


def norm_group(g):
    """Normalise group labels only for whitespace / case of the (Y) suffix. Printed label is kept separately."""
    if g is None:
        return None
    s = str(g).strip().replace("Naïve", "Naive").replace("Mφ", "Mphi").replace("MΦ", "Mphi")
    s = re.sub(r"\s+", " ", s)
    s = s.replace("PSLN-212(y)", "PSLN-212(Y)").replace("PSLN-212Y", "PSLN-212(Y)").replace("PSLN-344Y", "PSLN-344(Y)")
    return s


def load():
    wb = openpyxl.load_workbook(XLSX, data_only=True)
    meas, sv = [], []
    for b in B:
        ws = wb[b["sheet"]]
        if b["kind"] == "rows":
            for r in b["rws"]:
                g = ws[f'{b["label_col"]}{r}'].value
                for i, c in enumerate(b["vcols"]):
                    v = ws[f"{c}{r}"].value
                    meas.append(dict(sheet=b["sheet"], block=b["block"], panel=b["panel"], group_printed=g, group=norm_group(g),
                                     x=None, rep=i + 1, cell=f"{c}{r}", value=v))
        elif b["kind"] == "cols":
            for j, c in enumerate(b["gcols"]):
                g = ws[f'{c}{b["header_row"]}'].value
                gn = norm_group(g)
                if b.get("positional_labels"):
                    gn = f"{gn} [col {c}]"
                for i, r in enumerate(b["rws"]):
                    v = ws[f"{c}{r}"].value
                    meas.append(dict(sheet=b["sheet"], block=b["block"], panel=b["panel"], group_printed=g, group=gn,
                                     x=None, rep=i + 1, cell=f"{c}{r}", value=v))
        elif b["kind"] == "wide":
            for (gcell, c0, c1) in b["spans"]:
                g = ws[gcell].value
                for r in b["rws"]:
                    x = ws[f'{b["time_col"]}{r}'].value if b["time_col"] else None
                    for i, c in enumerate(cols(c0, c1)):
                        v = ws[f"{c}{r}"].value
                        meas.append(dict(sheet=b["sheet"], block=b["block"], panel=b["panel"], group_printed=g, group=norm_group(g),
                                         x=x, rep=i + 1, cell=f"{c}{r}", value=v))
        elif b["kind"] == "surv":
            for c in b["gcols"]:
                g = ws[f'{c}{b["header_row"]}'].value
                for r in b["rws"]:
                    e = ws[f"{c}{r}"].value
                    if e is None:
                        continue
                    d = ws[f'{b["day_col"]}{r}'].value
                    sv.append(dict(sheet=b["sheet"], block=b["block"], panel=b["panel"], group_printed=g, group=norm_group(g),
                                   day=d, event=e, day_cell=f'{b["day_col"]}{r}', event_cell=f"{c}{r}"))
    M = pd.DataFrame(meas)
    S = pd.DataFrame(sv)
    M["block_panel"] = M["block"] + M["panel"].map(lambda p: f" [{p}]" if p else "")
    S["block_panel"] = S["block"] + S["panel"].map(lambda p: f" [{p}]" if p else "")
    return M, S


def coverage_check():
    """Every numeric cell in the workbook must be claimed by exactly one declared block (or be a declared day/dose/time axis)."""
    wb = openpyxl.load_workbook(XLSX, data_only=True)
    M, S = load()
    claimed = {}
    for _, r in M.iterrows():
        claimed.setdefault((r.sheet, r.cell), []).append(r.block_panel)
    for _, r in S.iterrows():
        claimed.setdefault((r.sheet, r.event_cell), []).append(r.block_panel)
        claimed.setdefault((r.sheet, r.day_cell), []).append(r.block_panel + ":day")
    # axes
    for b in B:
        if b["kind"] == "wide" and b["time_col"]:
            for r in b["rws"]:
                claimed.setdefault((b["sheet"], f'{b["time_col"]}{r}'), []).append(b["block"] + ":axis")
        if b["kind"] == "surv":
            for r in b["rws"]:
                claimed.setdefault((b["sheet"], f'{b["day_col"]}{r}'), []).append(b["block"] + ":day")
    unclaimed, multi = [], []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, (int, float)) and not isinstance(c.value, bool):
                    k = (ws.title, c.coordinate)
                    if k not in claimed:
                        unclaimed.append((ws.title, c.coordinate, c.value))
    for k, v in claimed.items():
        real = [x for x in v if not x.endswith(":day") and not x.endswith(":axis")]
        if len(real) > 1:
            multi.append((k, v))
    return unclaimed, multi


if __name__ == "__main__":
    M, S = load()
    M.to_csv(f"{OUT}/tidy_measurements.csv", index=False)
    S.to_csv(f"{OUT}/tidy_survival.csv", index=False)
    print("measurement rows:", len(M), " non-null:", M.value.notna().sum(), " blocks:", M.block_panel.nunique())
    print("survival rows:", len(S), " blocks:", S.block_panel.nunique())
    un, multi = coverage_check()
    print("UNCLAIMED numeric cells:", len(un))
    for u in un:
        print("   ", u)
    print("MULTIPLY-claimed cells:", len(multi))
    for m in multi[:20]:
        print("   ", m)

"""
08_number_ledger.py -- recomputes every headline number used in the memo directly from the workbook and writes a ledger:
   id | statement | value | source block(s) | workbook cells | how reduced
The memo cites ledger ids in square brackets, e.g. [E1].
"""
import numpy as np, pandas as pd
from parse_workbook import load
from stats_utils import *
OUT = "/tmp/outputs/tables"
M, S = load(); M0 = M.copy(); M = M[M.value.notna()].copy(); M["value"] = M.value.astype(float)
L = []
def add(i, statement, value, blocks, cells, how):
    L.append(dict(id=i, statement=statement, value=value, blocks=blocks, cells=cells, reduction=how))
def vec(bp, g, x=None):
    d = M[(M.block_panel == bp) & (M.group == g)]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    return d.sort_values("rep").value.values
def cells(bp, g, x=None):
    d = M[(M.block_panel == bp) & (M.group == g)]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    d = d.sort_values("rep"); sh = d.sheet.iloc[0]
    return f"{sh}!{d.cell.iloc[0]}:{d.cell.iloc[-1]}"
def arm(bp, g):
    d = S[(S.block_panel == bp) & (S.group == g) & S.day.notna()]
    return d.day.values.astype(float), d.event.values.astype(int)
def scell(bp, g):
    d = S[(S.block_panel == bp) & (S.group == g)]
    return f"{d.sheet.iloc[0]}!{d.event_cell.iloc[0]}:{d.event_cell.iloc[-1]} (days {d.day_cell.iloc[0]}:{d.day_cell.iloc[-1]})"
def sn(bp, g):
    t, e = arm(bp, g); return int((e == 0).sum()), len(t)
def gm(v): return 10 ** np.log10(v).mean()
def fmt_ci(a, lo, hi, d=1): return f"{a:.{d}f} ({lo:.{d}f} to {hi:.{d}f})"

ID = {"S03-I": "S03-I", "S03-J": "S03-J", "S06-A": "S06-A", "S06-B": "S06-B", "S06-C": "S06-C", "S06-D": "S06-D", "S06-E [rows34-68]": "S06-E(1)", "S06-F [rows34-68]": "S06-F(1)", "S06-G": "S06-G",
      "S15-H": "S15-H", "S15-L": "S15-L", "S15-N": "S15-N", "S06-E [rows71-105(imprint/PR8)]": "S06-E(2)", "S06-F [rows71-105(imprint/Perth)]": "S06-F(2)",
      "S09-B": "S09-B", "S09-D": "S09-D", "S09-F": "S09-F", "S13-E": "S13-E"}
SURV_RULE = "survivors = animals whose indicator cell is 0 at end of the block's observation window; n = animals with an indicator and a recorded day; "
def pool(strata, override=None):
    tabs = []
    for bp, t, c in strata:
        s1, n1 = (override or {}).get((bp, t), sn(bp, t)); s2, n2 = (override or {}).get((bp, c), sn(bp, c))
        tabs.append((s1, n1 - s1, s2, n2 - s2))
    a = sum(x[0] for x in tabs); b = sum(x[1] for x in tabs); c = sum(x[2] for x in tabs); d = sum(x[3] for x in tabs)
    obs, exp, p = stratified_exact_2x2(tabs); rd, lo, hi = mh_risk_difference(tabs)
    l1, h1 = clopper_pearson(a, a + b); l2, h2 = clopper_pearson(c, c + d)
    return dict(a=a, n1=a + b, c=c, n2=c + d, p1=100 * a / (a + b), p2=100 * c / (c + d), ci1=(100 * l1, 100 * h1), ci2=(100 * l2, 100 * h2), rd=100 * rd, lo=100 * lo, hi=100 * hi, p=p,
                strata="; ".join(f"{ID[bp]} {x[0]}/{x[0]+x[1]} v {x[2]}/{x[2]+x[3]}" for (bp, _, _), x in zip(strata, tabs)))
def pool_entry(i, label, strata, override=None, note=""):
    r = pool(strata, override)
    add(i, label, f"{r['a']}/{r['n1']} = {r['p1']:.1f}% (exact 95% CI {r['ci1'][0]:.0f}-{r['ci1'][1]:.0f}) vs {r['c']}/{r['n2']} = {r['p2']:.1f}% ({r['ci2'][0]:.0f}-{r['ci2'][1]:.0f}); "
        f"Mantel-Haenszel risk difference {r['rd']:.1f} points (95% CI {r['lo']:.1f} to {min(r['hi'], 100):.1f}); stratified exact p = {r['p']:.1e}",
        ", ".join(sorted(set(ID[bp] for bp, _, _ in strata))), r["strata"] + " | cell ranges of every arm: table T1_survival_by_arm, column 'cells'",
        SURV_RULE + "pooled by summing within-experiment 2x2 tables; exact conditional test stratified by experiment; MH risk difference with Sato variance. " + note)
    return r
AB = ["S03-I", "S03-J", "S06-A", "S06-B", "S06-C", "S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G"]
vs_sham = [(bp, "PSLN-344", "Sham") for bp in AB + ["S15-L", "S15-N"]] + [("S15-H", "3d Vaccine+PSLN-344", "3d Vaccine")]
IMPR = [("S06-E [rows71-105(imprint/PR8)]", "Naive+PSLN-344", "Naive+PSLN-212"), ("S06-E [rows71-105(imprint/PR8)]", "Imprinting+PSLN-344", "Imprinting+PSLN-212"),
        ("S06-F [rows71-105(imprint/Perth)]", "Naive+PSLN-344", "Naive+PSLN-212"), ("S06-F [rows71-105(imprint/Perth)]", "Imprinting+PSLN-344", "Imprinting+PSLN-212")]
vs_212 = [(bp, "PSLN-344", "PSLN-212") for bp in AB + ["S15-L", "S15-N"]] + IMPR
WORST = {("S06-B", "PSLN-344"): (4, 7), ("S06-G", "PSLN-344"): (4, 7), ("S06-E [rows34-68]", "PSLN-344"): (5, 7), ("S06-E [rows34-68]", "PSLN-212"): (1, 7), ("S03-I", "PSLN-212"): (3, 7),
         ("S03-J", "PSLN-212"): (5, 10), ("S03-J", "Sham"): (1, 10), ("S06-C", "PSLN-212"): (2, 7), ("S15-N", "PSLN-212"): (2, 7), ("S06-A", "PSLN-212"): (1, 7)}
pool_entry("E1", "PSLN-344 vs Sham/vaccine-alone, aged mice, 11 lethal-challenge experiments (S06-D excluded as an exact duplicate of S06-C)", vs_sham,
           note="Control arm is 'Sham' (vaccine + empty liposome) except S15-H where it is '3d Vaccine' (vaccine alone). S03-J PSLN-344 n=9 (one indicator cell, J46, has no day).")
pool_entry("E2", "Same as E1 but every block as printed, i.e. S06-D included (12 experiments)", vs_sham + [("S06-D", "PSLN-344", "Sham")])
pool_entry("E3", "Same as E1, worst case for PSLN-344: wherever the paired body-weight block implies more PSLN-344 deaths than the survival block, the larger count is used (this changes S06-B from 5/7 to 4/7; all other arms unchanged)", vs_sham, WORST,
           note="Weight-block deaths = blank-after-last-value or terminal carried-forward run; see T4.")
pool_entry("E4", "Same as E1, BALB/c only (C57BL/6 S15-L and Swiss Webster S15-N removed)", [s for s in vs_sham if s[0] not in ("S15-L", "S15-N")])
pool_entry("E5", "PSLN-344 vs PSLN-212 (non-Mn parent) in aged / 14-month mice, 14 strata (10 experiments + 4 imprinting strata; S06-D excluded)", vs_212,
           note="Arm labels as printed in the survival blocks; S03-I and S03-J comparator labels conflict with their weight blocks (see E7 for the analysis without them).")
pool_entry("E6", "Same as E5, worst case for PSLN-344 and best case for PSLN-212 from the paired weight blocks", vs_212, WORST)
pool_entry("E7", "Same as E5 restricted to >=20-month BALB/c experiments with no comparator-label conflict (S06-A, S06-B, S06-C, S06-E(1), S06-F(1), S06-G)",
           [s for s in vs_212 if s[0] in ("S06-A", "S06-B", "S06-C", "S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G")])
pool_entry("E8", "PSLN-212 (aged) vs Sham, 10 experiments (S06-D excluded)", [(bp, "PSLN-212", "Sham") for bp in AB + ["S15-L", "S15-N"]])
pool_entry("E9", "PSLN-344 in aged mice vs PSLN-212 in young mice (the program's benchmark), 9 experiments (S06-D excluded; S03-J has no young arm)",
           [(bp, "PSLN-344", "PSLN-212(Y)") for bp in AB + ["S15-L", "S15-N"] if bp != "S03-J"])
r3 = pool_entry("E10a", "Challenge 2-3 days after one dose: PSLN-344 vs control (S03-J wild-type H5N1 d2; S06-B PR8 d3; S15-H rgH5N1 d3)", [s for s in vs_sham if s[0] in ("S03-J", "S06-B", "S15-H")])
r14 = pool_entry("E10b", "Challenge 14 days after one dose: PSLN-344 vs Sham (S03-I, S06-A, S06-C)", [s for s in vs_sham if s[0] in ("S03-I", "S06-A", "S06-C")])
r60 = pool_entry("E10c", "Challenge 60 days after one dose: PSLN-344 vs Sham (S06-E(1), S06-F(1), S06-G)", [s for s in vs_sham if s[0] in ("S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G")])
add("E10d", "PSLN-344 survival, day-14 challenge vs day-60 challenge", f"{r14['a']}/{r14['n1']} vs {r60['a']}/{r60['n1']}; Fisher exact two-sided p = {fisher_two_sided(r14['a'], r14['n1']-r14['a'], r60['a'], r60['n1']-r60['a']):.3f}",
    "S03-I, S06-A, S06-C vs S06-E(1), S06-F(1), S06-G", "see E10b, E10c", "pooled survivors/n per interval; Fisher exact on the pooled 2x2 (unstratified because the experiments differ)")
early = [("S03-J", "PSLN-344"), ("S06-B", "PSLN-344"), ("S15-H", "3d Vaccine+PSLN-344"), ("S03-I", "PSLN-344"), ("S06-A", "PSLN-344"), ("S06-C", "PSLN-344")]
se = sum(sn(bp, g)[0] for bp, g in early); ne = sum(sn(bp, g)[1] for bp, g in early); lo_, hi_ = clopper_pearson(se, ne)
add("E10g", "PSLN-344 survival when challenged within 14 days of the dose (six BALB/c experiments) versus at 60 days (three)",
    f"{se}/{ne} = {100*se/ne:.0f}% (exact 95% CI {100*lo_:.0f}-{100*hi_:.0f}) vs {r60['a']}/{r60['n1']} = {r60['p1']:.0f}%; Fisher exact two-sided p = {fisher_two_sided(se, ne-se, r60['a'], r60['n1']-r60['a']):.3f}",
    "S03-J, S06-B, S15-H, S03-I, S06-A, S06-C vs S06-E(1), S06-F(1), S06-G", "; ".join(scell(bp, g) for bp, g in early),
    "pooled survivors/n; Fisher exact. This comparison does not depend on whether the record shared by S06-C and S06-D belongs to the day-14 or the day-3 experiment (it is counted once).")
add("E10h", "Sensitivity of the day-14 versus day-60 comparison to where the duplicated S06-C/S06-D record is assigned",
    f"assigned to day 14 (as in E10b): 20/21 vs 14/21, p = {fisher_two_sided(20, 1, 14, 7):.3f}; assigned to day 3 instead: 27/30 at 2-3 days, 13/14 at 14 days, and 13/14 vs 14/21 gives p = {fisher_two_sided(13, 1, 14, 7):.2f}",
    "S06-C, S06-D, S03-I, S06-A, S06-E(1), S06-F(1), S06-G", "see E10b, E10c", "Fisher exact on pooled survivors/n under each assignment")
D60 = ["S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G"]
sy = sum(sn(bp, "PSLN-212(Y)")[0] for bp in D60); ny = sum(sn(bp, "PSLN-212(Y)")[1] for bp in D60)
add("E10e", "Day-60 challenge: aged PSLN-344 vs young PSLN-212", f"{r60['a']}/{r60['n1']} vs {sy}/{ny}; Fisher p = {fisher_two_sided(r60['a'], r60['n1']-r60['a'], sy, ny-sy):.4f}", "S06-E(1), S06-F(1), S06-G",
    "; ".join(scell(bp, "PSLN-212(Y)") for bp in D60), "pooled survivors/n; Fisher exact")
s2 = sum(sn(bp, "PSLN-212")[0] for bp in D60); n2 = sum(sn(bp, "PSLN-212")[1] for bp in D60)
add("E10f", "Day-60 challenge: aged PSLN-212", f"{s2}/{n2}", "S06-E(1), S06-F(1), S06-G", "; ".join(scell(bp, "PSLN-212") for bp in D60), "pooled survivors/n")
su = sum(sn(bp, "Untreated")[0] for bp in D60); nu = sum(sn(bp, "Untreated")[1] for bp in D60); lo, hi = clopper_pearson(nu - su, nu)
add("E11", "Background mortality: 'Untreated' aged animals (no vaccine, no adjuvant, no challenge) dying within the 14-day window", f"{nu-su}/{nu} = {100*(nu-su)/nu:.0f}% (exact 95% CI {100*lo:.0f}-{100*hi:.0f}); by block: "
    + ", ".join(f"{ID[bp]} {sn(bp,'Untreated')[1]-sn(bp,'Untreated')[0]}/7" for bp in D60) + f"; PSLN-344 d60 ({r60['a']}/{r60['n1']}) vs Untreated ({su}/{nu}) Fisher p = {fisher_two_sided(r60['a'], r60['n1']-r60['a'], su, nu-su):.2f}",
    "S06-E(1), S06-F(1), S06-G", "; ".join(scell(bp, "Untreated") for bp in D60), "deaths = indicator 1; exact binomial CI")
for bp, trt, ctls, i, lab in (("S15-H", "3d Vaccine+PSLN-344", ["3d Vaccine", "3d PSLN-344"], "E12", "Day-3 rgH5N1 challenge: vaccine + PSLN-344 vs vaccine alone vs PSLN-344 alone"),
                              ("S03-J", "PSLN-344", ["Sham", "PSLN-212"], "E13", "Wild-type H5N1 challenge 2 days after one dose (21-day follow-up), arms as labelled in S03-J"),
                              ("S03-I", "PSLN-344", ["Sham", "CMP-204", "PSLN-212", "PSLN-212(Y)"], "E14", "Homologous CA09 H1N1 challenge (10x mLD50) at day 14, arms as labelled in S03-I")):
    s1, n1 = sn(bp, trt); parts = [f"{trt} {s1}/{n1}"]
    for c in ctls:
        s2_, n2_ = sn(bp, c); t1, e1 = arm(bp, trt); t2, e2 = arm(bp, c)
        pl = logrank_exact(np.r_[t1, t2], np.r_[e1, e2], np.r_[np.ones(len(t1), int), np.zeros(len(t2), int)])
        parts.append(f"{c} {s2_}/{n2_} (Fisher p = {fisher_two_sided(s1, n1-s1, s2_, n2_-s2_):.4f}; exact log-rank p = {pl:.4f})")
    add(i, lab, "; ".join(parts), ID[bp], "; ".join(scell(bp, g) for g in [trt] + ctls), SURV_RULE + "Fisher exact two-sided on end-of-window survival; log-rank by exact permutation (all group splits enumerated)")
pool_entry("E15", "Other strains: aged C57BL/6 (S15-L) + aged Swiss Webster (S15-N), PSLN-344 vs Sham", [("S15-L", "PSLN-344", "Sham"), ("S15-N", "PSLN-344", "Sham")], note="Challenge virus and day are not stated for these blocks.")
pool_entry("E15b", "Other strains: PSLN-344 vs PSLN-212", [("S15-L", "PSLN-344", "PSLN-212"), ("S15-N", "PSLN-344", "PSLN-212")])
pool_entry("E16", "Imprinting study (14-month BALB/c, naive or PR8-infected at 10 months): PSLN-344 vs PSLN-212, 4 strata", IMPR)
add("E16b", "Imprinting study, Perth H3N2 challenge in PR8-imprinted animals", "Imprinting+PSLN-344 %d/%d vs Imprinting+PSLN-212 %d/%d; Fisher p = %.4f" % (*sn(IMPR[3][0], "Imprinting+PSLN-344"), *sn(IMPR[3][0], "Imprinting+PSLN-212"),
    fisher_two_sided(6, 1, 0, 7)), "S06-F(2)", scell(IMPR[3][0], "Imprinting+PSLN-344") + "; " + scell(IMPR[3][0], "Imprinting+PSLN-212"), SURV_RULE + "Fisher exact")
pool_entry("E17", "Young mice: PSLN-344(Y) vs PSLN-212(Y) (S09-B d21 PR8, S09-D d21 Perth H3N2, S09-F d180 rgH5N1)", [(bp, "PSLN-344(Y)", "PSLN-212(Y)") for bp in ("S09-B", "S09-D", "S09-F")])
# per-experiment p range and sign test
ps = []
for bp, t, c in vs_sham:
    t1, e1 = arm(bp, t); t2, e2 = arm(bp, c)
    ps.append(logrank_exact(np.r_[t1, t2], np.r_[e1, e2], np.r_[np.ones(len(t1), int), np.zeros(len(t2), int)]))
add("E18", "Per-experiment significance, PSLN-344 vs Sham/vaccine-alone", f"exact log-rank p ranges {min(ps):.4f} to {max(ps):.4f} across the 11 experiments; PSLN-344 better in 11/11 (two-sided sign test p = {stats.binomtest(11, 11, 0.5).pvalue:.4f})",
    "as E1", "as E1", "two-arm log-rank, exact permutation p (stated method is log-rank; asymptotic p-values are in T2)")
# mean day of death
def dd(g, bps):
    x = []
    for bp in bps:
        t, e = arm(bp, g); x += list(t[e == 1])
    return np.array(x)
bps9 = ["S03-I", "S06-A", "S06-B", "S06-C", "S06-E [rows34-68]", "S06-F [rows34-68]", "S06-G", "S15-L", "S15-N"]
add("E19", "Mean day of death among animals that died (9 aged 14-day experiments; S03-J and S06-D excluded)", "; ".join(f"{g} {dd(g,bps9).mean():.1f} d (n={len(dd(g,bps9))} deaths)" for g in ["Sham", "PSLN-212", "PSLN-344"]),
    ", ".join(ID[b] for b in bps9), "death-day cells of each arm", "arithmetic mean of recorded death days (indicator = 1)")
# body weight nadirs
A4 = pd.read_csv(f"{OUT}/T4a_bodyweight_per_animal.csv")
selb = ["S13-F", "S15-A", "S15-B", "S15-C", "S15-D", "S15-E", "S15-F", "S15-G", "S15-M", "S15-O"]
g_ = A4[A4.block.isin(selb)].groupby("group").nadir.agg(["mean", "std", "count"])
add("E20", "Post-challenge weight nadir (percent of own day-0 weight), 10 aged-mouse challenge experiments", "; ".join(f"{g} {g_.loc[g,'mean']:.1f} +/- {g_.loc[g,'std']:.1f} (n={int(g_.loc[g,'count'])})" for g in ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)", "Untreated"]),
    ", ".join(selb), "all animal columns of each arm, days 2-14", "per-animal minimum over real values (values repeated unchanged to day 14 after an animal's last real weight are treated as carried forward and excluded); mean +/- SD across animals pooled over experiments. Control-arm nadirs are truncated by death.")
C4 = pd.read_csv(f"{OUT}/T4b_nadir_contrasts.csv")
for ctl, i in (("PSLN-212(Y)", "E20b"), ("PSLN-212", "E20c")):
    sub = C4[C4.contrast == f"PSLN-344 - {ctl}"]
    add(i, f"Weight-nadir difference PSLN-344 minus {ctl}, per experiment", f"mean of 10 per-experiment differences {sub['diff'].mean():+.1f} points (range {sub['diff'].min():+.1f} to {sub['diff'].max():+.1f}); sign consistent in 10/10",
        ", ".join(selb), "as E20", "difference of arm mean nadirs within each experiment, then averaged across the 10 experiments")
y = A4[(A4.block == "S09-G")]
a = y[y.group == "PSLN-344(Y)"].d14_printed.values; b = y[y.group == "PSLN-212(Y)"].d14_printed.values
add("E21", "Young mice challenged 180 days after one dose (S09-G): day-14 body weight, PSLN-344(Y) vs PSLN-212(Y)", f"{a.mean():.1f} vs {b.mean():.1f}; difference {fmt_ci(*diff_ci(a, b))}; Welch p = {welch(a, b)[1]:.4f} (both arms 8/8 survive, S09-F)",
    "S09-G, S09-F", "S09!W73:AD73 vs S09!G73:N73", "mean of per-animal day-14 values (n=8 each); Welch t-test")

# ---------------- PD / mechanism
def ratio_entry(i, label, bp, g1, g2, x=None, extra=""):
    a, b = vec(bp, g1, x), vec(bp, g2, x); r, lo, hi = ratio_ci_log(a, b)
    add(i, label, f"GM {gm(a):.3g} vs {gm(b):.3g}; ratio {r:.2f} (95% CI {lo:.2f} to {hi:.2f}); Welch p on log10 = {welch(np.log10(a), np.log10(b))[1]:.2g}{extra}", bp, f"{cells(bp,g1,x)} vs {cells(bp,g2,x)}",
        f"geometric mean of n={len(a)} vs n={len(b)} per-animal values; ratio of GMs with Welch CI on log10 scale")
def diff_entry(i, label, bp, g1, g2, x=None, extra=""):
    a, b = vec(bp, g1, x), vec(bp, g2, x); d, lo, hi = diff_ci(a, b)
    add(i, label, f"mean {a.mean():.3g} +/- {a.std(ddof=1):.2g} vs {b.mean():.3g} +/- {b.std(ddof=1):.2g}; difference {d:.2f} (95% CI {lo:.2f} to {hi:.2f}); Welch p = {welch(a, b)[1]:.2g}{extra}", bp,
        f"{cells(bp,g1,x)} vs {cells(bp,g2,x)}", f"arithmetic mean +/- SD of n={len(a)} vs n={len(b)} per-animal values; Welch CI and t-test on the linear scale")
def tuk(bp, g1, g2, x=None, log=False, groups=None):
    d = M[M.block_panel == bp]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    gs = {g: (np.log10(vec(bp, g, x)) if log else vec(bp, g, x)) for g in (groups or list(dict.fromkeys(d.group)))}
    return tukey(gs)[2][(g1, g2)]
add("M1", "Lung Ifnb1 16 h after adjuvant alone (fold vs untreated), geometric means", "; ".join(f"{g} {gm(vec('S01-A [16h]', g)):.1f}" for g in ["Sham", "CMP-204", "PSLN-R848", "PSLN-212", "PSLN-212/R848", "PSLN-344", "PSLN-212(Y)", "PSLN-344(Y)"]),
    "S01-A", "S01!B3:F10", "geometric mean of 5 per-animal fold-changes per group (linear qPCR ratios; analysed on log10)")
ratio_entry("M1a", "Ifnb1 16 h: PSLN-344 vs PSLN-212, aged", "S01-A [16h]", "PSLN-344", "PSLN-212", extra=f"; Tukey p = {tuk('S01-A [16h]', 'PSLN-344', 'PSLN-212', log=True):.2g}")
ratio_entry("M1b", "Ifnb1 16 h: aged PSLN-344 vs young PSLN-212", "S01-A [16h]", "PSLN-344", "PSLN-212(Y)")
ratio_entry("M1c", "Ifnb1 16 h: aged PSLN-212 vs young PSLN-212 (the age defect)", "S01-A [16h]", "PSLN-212", "PSLN-212(Y)")
ratio_entry("M1d", "Ifnb1 16 h: young PSLN-344 vs young PSLN-212", "S01-A [16h]", "PSLN-344(Y)", "PSLN-212(Y)")
ratio_entry("M1e", "Ifnb1 72 h: aged PSLN-344 vs young PSLN-212 (slower resolution in aged)", "S01-A [72h]", "PSLN-344", "PSLN-212(Y)")
DR = pd.read_csv(f"{OUT}/T7_dose_response_S08A.csv").set_index("group")
add("M2", "Ifnb1 dose-response 16 h (1-40 ug): fitted ceiling and half-maximal dose", "; ".join(f"{g}: Emax {DR.loc[g,'Emax']:.1f} (95% CI {DR.loc[g,'Emax_lo']:.1f}-{DR.loc[g,'Emax_hi']:.1f}), ED50 {DR.loc[g,'ED50']:.1f} ug ({DR.loc[g,'ED50_lo']:.1f}-{DR.loc[g,'ED50_hi']:.1f})" for g in ["PSLN-344", "PSLN-212", "CMP-204"]),
    "S08-A", "S08!B3:M7", "3-parameter Hill model fitted to log10 fold (baseline fixed at 1), n=3 animals per dose; CIs by bootstrap (400 resamples of animals within dose)")
ratio_entry("M2a", "Ifnb1: PSLN-344 at 40 ug vs 20 ug (plateau check)", "S08-A", "PSLN-344", "PSLN-344", None)
L.pop()
a, b = vec("S08-A", "PSLN-344", 40), vec("S08-A", "PSLN-344", 20); r, lo, hi = ratio_ci_log(a, b)
add("M2a", "Ifnb1: PSLN-344 at 40 ug vs 20 ug (plateau check)", f"GM {gm(a):.1f} vs {gm(b):.1f}; ratio {r:.2f} (95% CI {lo:.2f} to {hi:.2f})", "S08-A", "S08!H7:J7 vs S08!H6:J6", "ratio of geometric means, n=3 vs 3, Welch CI on log10")
a, b = vec("S08-A", "PSLN-212", 40), vec("S08-A", "PSLN-344", 10); r, lo, hi = ratio_ci_log(a, b)
add("M2b", "Ifnb1: PSLN-212 at 40 ug vs PSLN-344 at 10 ug (can a higher dose of the parent substitute for Mn?)", f"GM {gm(a):.1f} vs {gm(b):.1f}; ratio {r:.2f} (95% CI {lo:.2f} to {hi:.2f})", "S08-A", "S08!E7:G7 vs S08!H5:J5", "ratio of geometric means, n=3 vs 3, Welch CI on log10")
diff_entry("M3", "Encapsulation efficiency (%), PSLN-344 vs PSLN-212", "S08-B", "PSLN-344", "PSLN-212")
for tp, i in (("16h", "M4a"), ("36h", "M4b"), ("72h", "M4c")):
    ratio_entry(i, f"Lung Gm-csf transcript {tp}: PSLN-344 vs PSLN-212, aged", "S02-F", "PSLN-344", "PSLN-212", tp, extra=f"; Tukey p = {tuk('S02-F', 'PSLN-344', 'PSLN-212', tp, log=True):.2g}")
for bp, x, i, lab in (("S01-D", "4", "M5", "Lung monocytes (% ) day 4"), ("S01-E", "4", "M6", "Lung CD11b+ DC (%) day 4"), ("S02-A", None, "M7a", "CCR7+ migratory CD11b+ DC in lung (%) 72 h"),
                      ("S02-C", None, "M7b", "Antigen(OVA-AF647)+ DC in MLN (%) 36 h"), ("S02-E", None, "M7c", "OT-I proliferation driven by MLN CD11b+ DC (%)"),
                      ("S02-D CD40", None, "M7d", "CD40+ of MLN CD11b+ DC (%)"), ("S02-D CD86", None, "M7e", "CD86+ of MLN CD11b+ DC (%)")):
    y_ = vec(bp, "PSLN-212(Y)", x)
    diff_entry(i, f"{lab}: PSLN-344 vs PSLN-212, aged", bp, "PSLN-344", "PSLN-212", x, extra=f"; Tukey p = {tuk(bp, 'PSLN-344', 'PSLN-212', x):.2g}; young benchmark mean {y_.mean():.3g}")
g = {k: vec("S02-H", k) for k in ["WT w/o cDC", "IFN w/o cDC", "GMCSF"]}
add("M8a", "Donor-derived moDC (%), pre-cDC-depleted marrow: WT vs Ifnar-KO vs Ifnar-KO + rGM-CSF", f"{g['WT w/o cDC'].mean():.1f} vs {g['IFN w/o cDC'].mean():.1f} vs {g['GMCSF'].mean():.1f}; rescue = {100*(g['GMCSF'].mean()-g['IFN w/o cDC'].mean())/(g['WT w/o cDC'].mean()-g['IFN w/o cDC'].mean()):.0f}% of the WT-KO gap; Tukey p (KO+GM-CSF vs KO) = {tuk('S02-H','GMCSF','IFN w/o cDC'):.3f}",
    "S02-H", "S02!B30:B34, D30:D34, F30:F34", "arithmetic means, n=5; one-way ANOVA + Tukey over the 5 arms of the block")
diff_entry("M8b", "Ly6C+CD11c+MHC-II+ cells (%) day 5, aged: PSLN-212 + rGM-CSF vs PSLN-212", "S02-G", "PSLN-212+GM-CSF", "PSLN-212")
for bp, g1, g2, i, lab in (("S11-C", "CBX+", "CBX-", "M9a", "Recruited lung monocytes (%) day 3 with PSLN-344: carbenoxolone vs saline"),
                           ("S07-B [CD11b+Ly6C+ Monocytes]", "PSLN-344+INCB3344", "PSLN-344", "M9b", "Lung monocytes (%) with PSLN-344: CCR2 antagonist vs vehicle"),
                           ("S02-I", "PSLN-344(Y)+INCB3344", "PSLN-344(Y)", "M9c", "Lung GZMB+ CD8 (%) day 5, YOUNG mice, PSLN-344: CCR2 antagonist vs vehicle"),
                           ("S01-C", "SPA/D", "WT", "M10a", "DiD+ alveolar macrophages (%), Sftpa1-/-Sftpd-/- vs WT"),
                           ("S05-C", "MLN+PTX", "MLN", "M11a", "OT-I proliferation in MLN (%), pertussis toxin vs PBS"), ("S05-C", "Lung+PTX", "Lung", "M11b", "OT-I proliferation in lung (%), pertussis toxin vs PBS")):
    a, b = vec(bp, g1), vec(bp, g2)
    diff_entry(i, lab, bp, g1, g2, extra=f"; relative change {100*(a.mean()-b.mean())/b.mean():+.0f}%; Student t p = {student(a, b)[1]:.2g}")
a, b = vec("S01-B", "AECII/PSLN-SRB"), vec("S01-B", "AECII/FreeSRB")
add("M10b", "SRB+ type II alveolar epithelial cells (%), liposomal vs free SRB", f"{a.mean():.1f} vs {b.mean():.2f}", "S01-B", "S01!B14:F14 vs S01!B16:F16", "arithmetic means, n=5")

# ---------------- humoral
for bp, i, lab, hai in (("S03-A", "H1a", "Serum IgG anti-CA09 H1N1 d14", False), ("S03-E", "H1b", "Serum IgG anti-Aichi H3N2 d14", False), ("S03-C", "H2a", "HAI anti-CA09 H1N1 d14", True), ("S03-G", "H2b", "HAI anti-Aichi H3N2 d14", True),
                        ("S03-D", "H3a", "Neutralising titre CA09 H1N1 d14", False), ("S03-H", "H3b", "Neutralising titre Aichi H3N2 d14", False), ("S13-I", "H6a", "Serum IgG anti-H1N1 d28 after d14 boost", False), ("S13-J", "H6b", "Serum IgG anti-H3N2 d28 after d14 boost", False)):
    gs = ["Sham", "CMP-204", "PSLN-212", "PSLN-344", "PSLN-212(Y)"]
    v = {g: (np.where(vec(bp, g) <= 0, 5.0, vec(bp, g)) if hai else vec(bp, g)) for g in gs}
    r, lo, hi = ratio_ci_log(v["PSLN-344"], v["PSLN-212"]); ry, loy, hiy = ratio_ci_log(v["PSLN-344"], v["PSLN-212(Y)"])
    pt = tukey({g: np.log10(x) for g, x in v.items()})[2]
    add(i, f"{lab}: geometric mean titres", "; ".join(f"{g} {gm(x):.0f}" for g, x in v.items()) + f"; PSLN-344/PSLN-212 = {r:.1f} (95% CI {lo:.1f}-{hi:.1f}), Tukey p = {pt[('PSLN-344','PSLN-212')]:.2g}; PSLN-344/young = {ry:.2f} ({loy:.2f}-{hiy:.2f}), Tukey p = {pt[('PSLN-344','PSLN-212(Y)')]:.2g}",
        bp, f"{cells(bp,'Sham')} ... {cells(bp,'PSLN-212(Y)')}", "geometric mean of 5 reciprocal titres per group" + ("; HAI recorded as 0 (negative at the lowest dilution, 1:10) set to 5" if hai else "") + "; one-way ANOVA + Tukey on log10 titres; ratio of GMs with Welch CI")
v = {g: vec("S03-C", g) for g in ["PSLN-212", "PSLN-344"]}
add("H2c", "HAI anti-H1N1 individual ranges", f"PSLN-212 {v['PSLN-212'].min():.0f}-{v['PSLN-212'].max():.0f} (5/5 at or above 40); PSLN-344 {v['PSLN-344'].min():.0f}-{v['PSLN-344'].max():.0f} (5/5 at or above 160)", "S03-C", "S03!M3:M7, S03!N3:N7", "min-max of per-animal titres")
for num, den, strain, i in (("S13-A", "S13-B", "CA09 H1N1", "H4a"), ("S13-C", "S13-D", "Aichi H3N2", "H4b")):
    rec = {g: vec(num, g) / vec(den, g) for g in ["PSLN-212", "PSLN-344", "PSLN-212(Y)"]}
    add(i, f"IgG2a:IgG1 ratio anti-{strain}, recomputed per animal from the raw subclass titres", "; ".join(f"{g} GM {gm(r):.2f}" for g, r in rec.items()) + f"; PSLN-344 vs PSLN-212 ratio {ratio_ci_log(rec['PSLN-344'], rec['PSLN-212'])[0]:.1f} (95% CI {ratio_ci_log(rec['PSLN-344'], rec['PSLN-212'])[1]:.1f}-{ratio_ci_log(rec['PSLN-344'], rec['PSLN-212'])[2]:.1f})",
        f"{num}, {den}", f"{cells(num,'PSLN-212')}..{cells(num,'PSLN-212(Y)')} / {cells(den,'PSLN-212')}..{cells(den,'PSLN-212(Y)')}", "per-animal IgG2a titre / IgG1 titre (same row), geometric mean of 5. The printed quotient blocks S03-B/S03-F carry the same values under rotated column labels and are NOT used.")
for bp, i, lab in (("S03-K", "H5a", "GC B cells in MLN (%) d7"), ("S04-A [ICOS+]", "H5b", "ICOS+ Tfh in MLN (%) d7"), ("S04-B Foxp3", "H5c", "Tfr (Foxp3+ of CXCR5+ICOShi CD4, %) d7"), ("S04-C", "H5d", "Tfr (%) d30"), ("S13-H", "H5e", "IgG+ B cells in MLN (%)")):
    gs = ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"]
    add(i, lab, "; ".join(f"{g} {vec(bp,g).mean():.1f}" for g in gs) + f"; PSLN-344 vs PSLN-212 Tukey p = {tuk(bp,'PSLN-344','PSLN-212'):.2g}; PSLN-344 vs Sham Tukey p = {tuk(bp,'PSLN-344','Sham'):.2g}; PSLN-344 vs young Tukey p = {tuk(bp,'PSLN-344','PSLN-212(Y)'):.2g}",
        bp, f"{cells(bp,'Sham')} ... {cells(bp,'PSLN-212(Y)')}", "arithmetic means, n=5 per group; one-way ANOVA + Tukey (linear scale)")
# ---------------- CD8
for bp, i, lab in (("S05-D", "C1a", "Ki-67+ CD8 T cells in lung (%) d3"), ("S05-E", "C1b", "GZMB+ CD8 T cells in lung (%) d3"), ("S05-F", "C1c", "IFN-g+ CD8 in MLN after rgH5N1 restimulation (%) d14 (animals vaccinated with H1N1+H3N2)"),
                   ("S05-G", "C1d", "same, d60"), ("S05-I", "C1e", "Lung CD8 TRM (%) d25"), ("S14-A H1N1", "C1f", "IFN-g+ CD8 in MLN after CA09 H1N1 restimulation (%)"), ("S14-A H3N2", "C1g", "IFN-g+ CD8 in MLN after Aichi H3N2 restimulation (%)")):
    gs = ["Sham", "PSLN-212", "PSLN-344", "PSLN-212(Y)"]
    add(i, lab, "; ".join(f"{g} {vec(bp,g).mean():.1f}" for g in gs) + f"; PSLN-344 vs PSLN-212 Tukey p = {tuk(bp,'PSLN-344','PSLN-212'):.2g}; PSLN-344 vs young Tukey p = {tuk(bp,'PSLN-344','PSLN-212(Y)'):.2g}",
        bp, f"{cells(bp,'Sham')} ... {cells(bp,'PSLN-212(Y)')}", "arithmetic means, n=5 per group; one-way ANOVA + Tukey (linear scale)")
RI = pd.read_csv(f"{OUT}/T6_restoration_index.csv")
def ri(bp, x=None):
    d = RI[(RI.block == bp) & ((RI.x.astype(str) == str(x)) if x is not None else RI.x.isna())].iloc[0]; return d.RI, d.RI_lo, d.RI_hi
keys = [("S01-A [16h]", None), ("S01-D", "4"), ("S02-A", None), ("S02-E", None), ("S02-D CD40", None), ("S02-D CD86", None), ("S03-A", None), ("S03-C", None), ("S03-D", None), ("S03-K", None), ("S05-E", None), ("S05-F", None), ("S05-G", None), ("S05-I", None), ("S04-C", None)]
add("R1", "Restoration index (0 = aged PSLN-212, 1 = young PSLN-212) for selected readouts", "; ".join(f"{bp}{'@d'+x if x else ''} {ri(bp,x)[0]:.2f} ({ri(bp,x)[1]:.2f}-{ri(bp,x)[2]:.2f})" for bp, x in keys),
    ", ".join(k[0] for k in keys), "PSLN-212, PSLN-344 and PSLN-212(Y) columns of each block", "(mean PSLN-344 - mean PSLN-212) / (mean PSLN-212(Y) - mean PSLN-212) on the analysis scale (log10 for titres/transcripts, linear for percentages); bootstrap 95% CI, 10,000 resamples within group")

# ---------------- tolerability
T8 = pd.read_csv(f"{OUT}/T8_postvaccination_weight_S08D.csv").set_index("group")
W = M[M.block == "S08-D"]
def nad(g):
    piv = W[W.group == g].pivot(index="x", columns="rep", values="value"); piv.index = piv.index.astype(int); return piv.loc[2:].min(axis=0).values
a, b = nad("PSLN-344"), nad("Vaccine"); d, lo, hi = diff_ci(a, b)
add("S1a", "Body weight after vaccination without challenge: per-animal nadir (% of day 0)", "; ".join(f"{g} {np.nanmean(nad(g)):.1f} (lowest animal {np.nanmin(nad(g)):.1f})" for g in ["Vaccine", "PSLN-212(Y)", "PSLN-212", "CMP-204", "PSLN-344", "PSLN-212/R848"])
    + f"; PSLN-344 minus Vaccine {d:.1f} (95% CI {lo:.1f} to {hi:.1f})", "S08-D", "S08!B22:AE26", "per-animal minimum over days 2-10; mean across n=5 animals; Welch CI")
d10 = lambda g: W[(W.group == g) & (W.x == 10)].value.values
add("S1b", "Body weight 10 days after vaccination (% of day 0)", "; ".join(f"{g} {d10(g).mean():.1f} (n={len(d10(g))})" for g in ["Vaccine", "PSLN-212", "PSLN-344", "PSLN-212/R848"]), "S08-D", "S08!B26:AE26", "arithmetic mean of per-animal values present on day 10 (PSLN-212/R848 has 4: cell W26 is blank)")
CY = pd.read_csv(f"{OUT}/T9_lung_cytokines_S09A.csv")
def cy(tp, an, g): return CY[(CY.timepoint == tp) & (CY.analyte == an)][g].iloc[0]
for tp, i in (("16h", "S2a"), ("72h(inferred)", "S2b")):
    add(i, f"Lung transcripts {tp.replace('(inferred)','')} after adjuvant alone, GM fold vs untreated", "; ".join(f"{an}: PSLN-212 {cy(tp,an,'PSLN-212'):.1f}, PSLN-344 {cy(tp,an,'PSLN-344'):.1f}, young PSLN-212 {cy(tp,an,'PSLN-212(Y)'):.2g}, PSLN-212/R848 {cy(tp,an,'PSLN-212/R848'):.0f}" for an in ["Tnf", "Il6", "Il10", "Ccl2"]),
        "S09-A", "S09!B3:V9" if tp == "16h" else "S09!Y3:AS9", "values are stored as log10 fold; group mean of log10 (n=3) back-transformed (10^mean). " + ("" if tp == "16h" else "Second panel is printed '16h'; its Ifnb1 row equals log10 of individual S01-A 72-h values in 17/18 cells, so it is treated as 72 h."))
r = CY[(CY.timepoint == "72h(inferred)") & (CY.analyte == "Tnf")].iloc[0]
add("S2c", "Lung Tnf at 72 h: aged PSLN-344 relative to young PSLN-212 and to aged PSLN-212", f"x{r['344/Y']:.1f} (95% CI {r['344/Y_lo']:.1f}-{r['344/Y_hi']:.1f}) vs young; x{r['344/212']:.2f} ({r['344/212_lo']:.2f}-{r['344/212_hi']:.2f}) vs aged PSLN-212", "S09-A", "S09!AN8:AP8, AQ8:AS8, AE8:AG8", "difference of log10 means back-transformed; Welch CI, n=3 vs 3")
r = CY[(CY.timepoint == "16h") & (CY.analyte == "Ccl2")].iloc[0]
add("S2d", "Lung Ccl2 at 16 h: aged PSLN-344 vs aged PSLN-212", f"x{r['344/212']:.0f} (95% CI {r['344/212_lo']:.0f}-{r['344/212_hi']:.0f})", "S09-A", "S09!Q5:S5 vs S09!H5:J5", "difference of log10 means back-transformed; Welch CI, n=3 vs 3")
CNS = pd.read_csv(f"{OUT}/T10_CNS_S10A.csv").set_index("analyte")
for an, i in (("Ifnb1", "S3a"), ("Tnf", "S3b"), ("Isg15", "S3c")):
    r = CNS.loc[an]
    add(i, f"CNS {an} transcript 36 h (fold vs untreated), mean +/- SD", f"PBS {r['PBS_mean']:.2f} +/- {r['PBS_sd']:.2f}; Sham {r['Sham_mean']:.2f} +/- {r['Sham_sd']:.2f}; PSLN-344 {r['PSLN-344_mean']:.2f} +/- {r['PSLN-344_sd']:.2f}; cholera toxin {r['CT_mean']:.2f} +/- {r['CT_sd']:.2f}; "
        f"PSLN-344/PBS = {r['ratio_344_vs_PBS']:.2f} (95% CI {r['lo']:.2f}-{r['hi']:.2f}), Tukey p = {r['p_tukey_344_vs_PBS']:.2f}; PSLN-344/Sham = {r['ratio_344_vs_Sham']:.2f} ({r['lo2']:.2f}-{r['hi2']:.2f})",
        "S10-A", {"Ifnb1": "S10!A3:D7", "Tnf": "S10!F3:I7", "Isg15": "S10!K3:N7"}[an], "arithmetic mean +/- SD (the annotation's stated summary for this block), n=5; ratios of GMs and one-way ANOVA + Tukey on log10")

# ---------------- hazard ratios (Cox model stratified by experiment) and restricted mean survival
import statsmodels.api as sm
def cox_entry(i, label, strata):
    rows = []
    for k, (bp, trt, ctl) in enumerate(strata):
        for g, z in ((trt, 1), (ctl, 0)):
            t, e = arm(bp, g)
            rows += [(k, z, tt, ee) for tt, ee in zip(t, e)]
    d = pd.DataFrame(rows, columns=["stratum", "trt", "time", "event"])
    r = sm.PHReg(d.time, d[["trt"]], status=d.event, strata=d.stratum, ties="efron").fit()
    b, se = r.params[0], r.bse[0]
    def rmst(t, e, tau=14.0):
        t = np.asarray(t, float); e = np.asarray(e, int); s_ = 1.0; last = 0.0; area = 0.0
        for u in np.sort(np.unique(t[e == 1])):
            if u > tau: break
            area += s_ * (u - last); last = u; s_ *= 1 - ((t == u) & (e == 1)).sum() / (t >= u).sum()
        return area + s_ * (tau - last)
    a_, c_ = d[d.trt == 1], d[d.trt == 0]
    add(i, label, f"hazard ratio for death {np.exp(b):.3f} (95% CI {np.exp(b-1.96*se):.3f}-{np.exp(b+1.96*se):.3f}); {int(d.event.sum())} deaths among {len(d)} animals; mean survival time restricted to 14 days {rmst(a_.time, a_.event):.1f} d vs {rmst(c_.time, c_.event):.1f} d",
        ", ".join(sorted(set(ID[bp] for bp, _, _ in strata))), "day and indicator cells of the arms listed in T1_survival_by_arm",
        "Cox proportional-hazards model with one coefficient (treatment), stratified by experiment, Efron ties, Wald CI; restricted mean = area under the pooled Kaplan-Meier curve to day 14")
cox_entry("E1b", "PSLN-344 vs Sham/vaccine alone, 11 experiments: hazard ratio", vs_sham)
cox_entry("E5b", "PSLN-344 vs PSLN-212, 14 strata: hazard ratio", vs_212)
# ---------------- extra entries cited in the memo
def pooled_arm(bps_arms):
    s = sum(sn(bp, g)[0] for bp, g in bps_arms); n = sum(sn(bp, g)[1] for bp, g in bps_arms); return f"{s}/{n}"
add("E10i", "Comparator arms by dose-to-challenge interval (table in section 3.4)",
    "2-3 d: Sham/vaccine alone " + pooled_arm([("S03-J", "Sham"), ("S06-B", "Sham"), ("S15-H", "3d Vaccine")]) + ", PSLN-212 " + pooled_arm([("S03-J", "PSLN-212"), ("S06-B", "PSLN-212")]) + ", young PSLN-212 " + pooled_arm([("S06-B", "PSLN-212(Y)")])
    + "; 14 d: Sham " + pooled_arm([(b, "Sham") for b in ("S03-I", "S06-A", "S06-C")]) + ", PSLN-212 " + pooled_arm([(b, "PSLN-212") for b in ("S03-I", "S06-A", "S06-C")]) + ", young " + pooled_arm([(b, "PSLN-212(Y)") for b in ("S03-I", "S06-A", "S06-C")])
    + "; 60 d: Sham " + pooled_arm([(b, "Sham") for b in D60]) + ", PSLN-212 " + pooled_arm([(b, "PSLN-212") for b in D60]) + ", young " + pooled_arm([(b, "PSLN-212(Y)") for b in D60]) + ", Untreated " + pooled_arm([(b, "Untreated") for b in D60]),
    "S03-J, S06-B, S15-H; S03-I, S06-A, S06-C; S06-E(1), S06-F(1), S06-G", "indicator cells of the named arms", "survivors/n summed over the experiments in each interval")
t1, e1 = arm("S15-H", "3d PSLN-344"); t2, e2 = arm("S15-H", "3d Vaccine")
add("S4", "Adjuvant alone before challenge does not hasten death (S15-H)", f"PSLN-344 alone: deaths on days {int(t1.min())}-{int(t1.max())}, mean {t1.mean():.1f}; vaccine alone: days {int(t2.min())}-{int(t2.max())}, mean {t2.mean():.1f}; exact log-rank p = {logrank_exact(np.r_[t1, t2], np.r_[e1, e2], np.r_[np.ones(7, int), np.zeros(7, int)]):.2f}",
    "S15-H", scell("S15-H", "3d PSLN-344") + "; " + scell("S15-H", "3d Vaccine"), "death days (all 7 animals died in both arms); arithmetic mean; exact permutation log-rank")
pn = []
for x in ["0", "2", "4", "6", "8"]:
    gs = {g: vec("S11-D", g, x) for g in ["Vaccine", "PSLN-212", "PSLN-344", "PSLN-212(Y)"]}
    tk = tukey(gs)[2]; pn += [tk[("PSLN-344", "Vaccine")], tk[("PSLN-344", "PSLN-212")]]
add("S5", "Lung NK cells (%), PSLN-344 versus vaccine alone and versus PSLN-212, days 0-8", f"smallest Tukey p over 10 contrasts = {min(pn):.2f}; day-2 means: vaccine {vec('S11-D','Vaccine','2').mean():.1f}, PSLN-212 {vec('S11-D','PSLN-212','2').mean():.1f}, PSLN-344 {vec('S11-D','PSLN-344','2').mean():.1f}",
    "S11-D", "S11!B24:U28", "arithmetic means, n=5 per group per day; one-way ANOVA + Tukey within each day")
chk = [("S01-A [16h]", None), ("S02-F", "16h"), ("S02-F", "36h"), ("S01-D", "4"), ("S01-E", "4"), ("S02-A", None), ("S02-D CD40", None), ("S03-A", None), ("S03-C", None), ("S03-D", None), ("S03-G", None), ("S03-K", None), ("S04-A [ICOS+]", None),
       ("S04-B Foxp3", None), ("S05-D", None), ("S05-E", None), ("S05-F", None), ("S05-G", None), ("S05-I", None), ("S14-A H1N1", None), ("S11-E", None), ("S13-A", None), ("S13-H", None)]
sep = [(bp, x) for bp, x in chk if (vec(bp, "PSLN-344", x).min() > vec(bp, "PSLN-212", x).max()) or (vec(bp, "PSLN-344", x).max() < vec(bp, "PSLN-212", x).min())]
add("B0", "Read-outs in which every aged PSLN-344 animal lies outside the range of the aged PSLN-212 animals", f"{len(sep)} of {len(chk)}; the exception: " + ", ".join(bp for bp, x in chk if (bp, x) not in sep),
    ", ".join(bp + (f"@{x}" if x else "") for bp, x in chk), "PSLN-344 and PSLN-212 columns of each block", "complete separation = min of one arm above max of the other (per-animal values)")
# ---------------- integrity counts
def sv(bp): return {g: sorted(zip(d.day, d.event)) for g, d in S[S.block_panel == bp].groupby("group", sort=False)}
add("I1", "S06-C (day-14 challenge) vs S06-D (day-3 challenge): identical records", f"all 4 arms identical: {sv('S06-C') == sv('S06-D')}; 28 animals, 56 of 56 day/indicator cells equal", "S06-C, S06-D", "S06!M3:Q30 vs S06!A34:E61", "cell-by-cell comparison of sorted (day, indicator) pairs per arm")
c = M[(M.block == "S15-C") & (M.group == "PSLN-344")].pivot(index="x", columns="rep", values="value").sort_index().values; i_ = M[(M.block == "S15-I") & (M.group == "3d Vaccine+PSLN-344")].pivot(index="x", columns="rep", values="value").sort_index().values
add("I2", "S15-C PSLN-344 weights vs S15-I '3d Vaccine+PSLN-344' weights", f"{int((c[1:7]==i_[1:7]).sum())} of 42 cells identical on days 2-12; {int((c[7]==i_[7]).sum())} of 7 on day 14", "S15-C, S15-I", "S15!W24:AC30 vs S15!W73:AC79", "cell-by-cell equality")
a_ = M[M.block == "S11-A"].set_index(["group", "x", "rep"]).value; b_ = M[M.block == "S11-B"].set_index(["group", "x", "rep"]).value
add("I3", "S11-A (alveolar macrophages) vs S11-B (neutrophils)", f"{int((a_==b_).sum())} of {len(a_)} values identical in the same position", "S11-A, S11-B", "S11!B3:U7 vs S11!B10:U14", "cell-by-cell equality")
T4 = pd.read_csv(f"{OUT}/T4_bodyweight_by_arm_and_concordance.csv")
add("I4", "Agreement between each survival block and its paired body-weight block on the number of deaths per arm", f"{int(T4.concordant.sum())} of {int(T4.deaths_in_survival_block.notna().sum())} arms agree; {int(T4.deaths_in_survival_block.isna().sum())} weight-block arms have no same-named survival arm",
    "17 block pairs", "see T4", "weight-block deaths = animals blank after their last value or with a terminal run of identical values to day 14; compared with the count of indicator = 1")
LED = pd.DataFrame(L)
LED.to_csv(f"{OUT}/number_ledger.csv", index=False)
pd.set_option("display.width", 300); pd.set_option("display.max_colwidth", 260); pd.set_option("display.max_rows", 400)
for _, r in LED.iterrows():
    print(f"[{r.id}] {r.statement}\n      = {r.value}\n      src: {r.blocks} | {r.cells}")
print(len(LED), "ledger entries")

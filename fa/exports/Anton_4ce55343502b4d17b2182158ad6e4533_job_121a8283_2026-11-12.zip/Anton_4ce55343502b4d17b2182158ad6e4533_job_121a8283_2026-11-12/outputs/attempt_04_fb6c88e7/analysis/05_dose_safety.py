"""
05_dose_safety.py -- dose-response (S08-A), formulation (S08-B), post-vaccination tolerability (S08-D), lung cytokines (S09-A), CNS (S10-A).
Reduction rules:
  * S08-A: Ifnb1 fold-induction (linear, relative to untreated), n=3 per dose. Per-dose GM; 3-parameter Hill fit to log10(fold) with
    baseline fixed at 1 (fold = 1 + (Emax-1)*d^h/(ED50^h + d^h)); bootstrap (resample animals within dose) for CIs.
  * S08-D: percent of own day-0 weight after vaccination (no challenge). Per-animal nadir = min over days 2-10; group mean by day.
  * S09-A: values are log10 fold-change vs untreated. Group mean of log10 -> back-transformed GM fold. Panel 2 is treated as 72 h
    because its Ifnb1 values are the log10 of individual S01-A 72 h values (17/18 coincide; see 04_integrity_checks.py).
  * S10-A: linear fold vs untreated, n=5; analysed on log10 scale, one-way ANOVA + Tukey (stated method); Dunnett-type contrasts vs PBS
    reported as Welch p; "reported as mean with SD" per annotation.
"""
import numpy as np, pandas as pd
from scipy import optimize, stats
from parse_workbook import load
from stats_utils import *
OUT = "/tmp/outputs/tables"
M, S = load(); M = M[M.value.notna()].copy(); M["value"] = M.value.astype(float)
def vec(bp, g, x=None):
    d = M[(M.block_panel == bp) & (M.group == g)]
    if x is not None: d = d[d.x.astype(str) == str(x)]
    return d.sort_values("rep").value.values
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 40)

# ---------------- S08-A dose response
print("=== S08-A Ifnb1 dose-response (16 h, n=3/dose) ===")
doses = np.array([1, 5, 10, 20, 40.0])
def hill(d, emax, ed50, h):
    return 1 + (emax - 1) * d ** h / (ed50 ** h + d ** h)
def fit(dd, yy):
    f = lambda p: np.log10(hill(dd, *p)) - np.log10(yy)
    best = None
    for e0 in (10, 30, 60, 100):
        for ed in (5, 10, 20):
            for h0 in (1, 2, 3):
                try:
                    r = optimize.least_squares(f, x0=[e0, ed, h0], bounds=([1.01, 0.5, 0.3], [500, 200, 8]))
                    if best is None or r.cost < best.cost: best = r
                except Exception: pass
    return best.x
rows = []
rng = np.random.default_rng(3)
for g in ["CMP-204", "PSLN-212", "PSLN-344", "PSLN-344/R848"]:
    Y = np.array([vec("S08-A", g, int(d)) for d in doses])           # 5 x 3
    gm = 10 ** np.log10(Y).mean(axis=1)
    dd = np.repeat(doses, 3); yy = Y.ravel()
    p = fit(dd, yy)
    bs = []
    for _ in range(400):
        Yb = np.array([rng.choice(r, 3) for r in Y])
        try: bs.append(fit(dd, Yb.ravel()))
        except Exception: pass
    bs = np.array(bs)
    ci = np.percentile(bs, [2.5, 97.5], axis=0)
    rows.append(dict(group=g, **{f"GM@{int(d)}ug": round(v, 2) for d, v in zip(doses, gm)}, Emax=p[0], Emax_lo=ci[0, 0], Emax_hi=ci[1, 0],
                     ED50=p[1], ED50_lo=ci[0, 1], ED50_hi=ci[1, 1], hill=p[2], pct_of_fitted_Emax_at_20ug=100 * (hill(20, *p) - 1) / (p[0] - 1),
                     ratio_40_vs_20=gm[4] / gm[3]))
DR = pd.DataFrame(rows); DR.to_csv(f"{OUT}/T7_dose_response_S08A.csv", index=False)
print(DR.round(2).to_string(index=False))
y20, y40 = vec("S08-A", "PSLN-344", 20), vec("S08-A", "PSLN-344", 40)
print("PSLN-344 40 vs 20 ug: ratio of GMs", [round(v, 2) for v in ratio_ci_log(y40, y20)], "Welch p(log) =", round(welch(np.log10(y40), np.log10(y20))[1], 3))
print("PSLN-212 at 40 ug vs PSLN-344 at 10 ug: ratio", [round(v, 2) for v in ratio_ci_log(vec('S08-A', 'PSLN-212', 40), vec('S08-A', 'PSLN-344', 10))],
      "p =", round(welch(np.log10(vec('S08-A', 'PSLN-212', 40)), np.log10(vec('S08-A', 'PSLN-344', 10)))[1], 3))
print("PSLN-212 at 40 ug vs PSLN-344 at 5 ug: ratio", [round(v, 2) for v in ratio_ci_log(vec('S08-A', 'PSLN-212', 40), vec('S08-A', 'PSLN-344', 5))])

# ---------------- S08-B
print("\n=== S08-B encapsulation efficiency (%; n=3 preparations) ===")
ee = {g: vec("S08-B", g) for g in ["CMP-204", "PSLN-212", "PSLN-R848", "PSLN-212/R848", "PSLN-344"]}
for g, v in ee.items(): print(f"  {g:14s} {v}  mean {v.mean():.1f}  SD {v.std(ddof=1):.1f}  CV {100*v.std(ddof=1)/v.mean():.0f}%")
F, pA, tk = tukey(ee)
print("  one-way ANOVA p = %.3f ; PSLN-344 vs PSLN-212: diff %.1f (95%% CI %.1f to %.1f), Tukey p = %.2f, Welch p = %.2f" % (
    pA, *diff_ci(ee["PSLN-344"], ee["PSLN-212"]), tk[("PSLN-344", "PSLN-212")], welch(ee["PSLN-344"], ee["PSLN-212"])[1]))

# ---------------- S08-D tolerability after vaccination
print("\n=== S08-D body weight after vaccination, no challenge (% of day 0) ===")
W = M[M.block == "S08-D"]
tab = W.groupby(["group", "x"], sort=False).value.agg(["mean", "std", "count"]).unstack("x")
print(tab["mean"].round(1).to_string()); print("n per day:"); print(tab["count"].to_string())
nad = {}
for g, d in W.groupby("group", sort=False):
    piv = d.pivot(index="x", columns="rep", values="value"); piv.index = piv.index.astype(int)
    nad[g] = piv.loc[2:].min(axis=0).values
    print(f"  {g:14s} per-animal nadir {np.round(nad[g],1)}  mean {np.nanmean(nad[g]):.1f}  max loss {100-np.nanmin(nad[g]):.1f}%  | day-10 values {np.round(piv.loc[10].values,1)}")
F, pA, tk = tukey({k: v for k, v in nad.items()})
print("  nadir ANOVA p = %.2g; Tukey: PSLN-344 vs Vaccine p=%.3f (diff %.1f, CI %.1f to %.1f); PSLN-344 vs PSLN-212 p=%.2f; PSLN-344 vs PSLN-212/R848 p=%.4f; PSLN-212/R848 vs Vaccine p=%.5f" % (
    pA, tk[("PSLN-344", "Vaccine")], *diff_ci(nad["PSLN-344"], nad["Vaccine"]), tk[("PSLN-344", "PSLN-212")], tk[("PSLN-344", "PSLN-212/R848")], tk[("PSLN-212/R848", "Vaccine")]))
for g in ["PSLN-344", "PSLN-212", "PSLN-212/R848", "CMP-204", "PSLN-212(Y)"]:
    d10 = W[(W.group == g) & (W.x == 10)].value.values; v10 = W[(W.group == "Vaccine") & (W.x == 10)].value.values
    print(f"  day-10 weight {g} vs Vaccine: {d10.mean():.1f} vs {v10.mean():.1f}; diff {diff_ci(d10, v10)[0]:.1f} (CI {diff_ci(d10, v10)[1]:.1f} to {diff_ci(d10, v10)[2]:.1f}); Welch p={welch(d10, v10)[1]:.3f}")
pd.DataFrame([dict(group=g, mean_nadir=np.nanmean(v), min_nadir=np.nanmin(v), n=len(v)) for g, v in nad.items()]).to_csv(f"{OUT}/T8_postvaccination_weight_S08D.csv", index=False)

# ---------------- S09-A lung cytokines
print("\n=== S09-A lung cytokine transcripts: GM fold vs untreated (10^mean log10), n=3 ===")
rows = []
for panel, tp in (("S09-A [panel1(cols A-U)]", "16h"), ("S09-A [panel2(cols X-AS)]", "72h(inferred)")):
    for an in ["Ifnb1", "Il6", "Ccl2", "Ccl3", "Ccl5", "Tnf", "Il10"]:
        r = dict(timepoint=tp, analyte=an)
        for g in ["PBS", "CMP-204", "PSLN-212", "PSLN-R848", "PSLN-212/R848", "PSLN-344", "PSLN-212(Y)"]:
            r[g] = 10 ** vec(panel, g, an).mean()
        a, b, c = vec(panel, "PSLN-344", an), vec(panel, "PSLN-212(Y)", an), vec(panel, "PSLN-212", an)
        d1 = diff_ci(a, b); d2 = diff_ci(a, c)
        r.update(**{"344/Y": 10 ** d1[0], "344/Y_lo": 10 ** d1[1], "344/Y_hi": 10 ** d1[2], "p_344vY": welch(a, b)[1],
                    "344/212": 10 ** d2[0], "344/212_lo": 10 ** d2[1], "344/212_hi": 10 ** d2[2], "p_344v212": welch(a, c)[1]})
        rows.append(r)
CY = pd.DataFrame(rows); CY.to_csv(f"{OUT}/T9_lung_cytokines_S09A.csv", index=False)
print(CY.round(2).to_string(index=False))
# persistence ratio 72h/16h
print("\n  72h/16h persistence (GM fold at 72 h as % of GM fold at 16 h):")
for g in ["PSLN-212", "PSLN-344", "PSLN-212(Y)", "PSLN-212/R848"]:
    print("   ", g, {an: f"{100*10**(vec('S09-A [panel2(cols X-AS)]', g, an).mean()-vec('S09-A [panel1(cols A-U)]', g, an).mean()):.0f}%" for an in ["Ifnb1", "Il6", "Ccl2", "Tnf", "Il10"]})

# ---------------- S10-A CNS
print("\n=== S10-A CNS transcripts 36 h (linear fold; analysed on log10), n=5; mean +/- SD as annotated ===")
rows = []
for an in ["Ifnb1", "Tnf", "Isg15"]:
    g = {k: vec(f"S10-A [{an}]", k) for k in ["PBS", "Sham", "PSLN-344", "CT"]}
    F, pA, tk = tukey({k: np.log10(v) for k, v in g.items()})
    r1 = ratio_ci_log(g["PSLN-344"], g["PBS"]); r2 = ratio_ci_log(g["PSLN-344"], g["Sham"]); r3 = ratio_ci_log(g["CT"], g["PBS"]); r4 = ratio_ci_log(g["PSLN-344"], g["CT"])
    rows.append(dict(analyte=an, **{f"{k}_mean": v.mean() for k, v in g.items()}, **{f"{k}_sd": v.std(ddof=1) for k, v in g.items()},
                     ratio_344_vs_PBS=r1[0], lo=r1[1], hi=r1[2], p_tukey_344_vs_PBS=tk[("PSLN-344", "PBS")], p_welch_344_vs_PBS=welch(np.log10(g["PSLN-344"]), np.log10(g["PBS"]))[1],
                     ratio_344_vs_Sham=r2[0], lo2=r2[1], hi2=r2[2], p_tukey_344_vs_Sham=tk[("PSLN-344", "Sham")],
                     ratio_CT_vs_PBS=r3[0], p_tukey_CT_vs_PBS=tk[("CT", "PBS")], ratio_344_vs_CT=r4[0], p_tukey_344_vs_CT=tk[("PSLN-344", "CT")]))
CNS = pd.DataFrame(rows); CNS.to_csv(f"{OUT}/T10_CNS_S10A.csv", index=False)
print(CNS.round(3).T.to_string())

"""
02_bodyweight.py -- body-weight blocks (percent of own day-0 weight).
Reduction rules:
  * A cell that is blank after an animal's last value = animal no longer weighed (dead/removed).
  * Several blocks do NOT blank dead animals; they repeat the last value to day 14 ("carried forward").  A terminal run of >=3
    identical values ending at day 14 is classed as carried-forward (death during the first repeated interval); a terminal run of
    exactly 2 identical values (d12 = d14) is classed "possible carry-forward" and resolved against the paired survival block.
  * Carried-forward values are EXCLUDED from all means/nadirs ("real" values only).
  * Nadir = minimum real value per animal; max loss = 100 - nadir.
  * Because controls die from day 4-5, between-arm comparisons of morbidity use (i) day-4 weight (all or almost all animals still
    alive) and (ii) per-animal nadir; later timepoints are survivor-biased and are reported for survivors only.
"""
import numpy as np, pandas as pd
from parse_workbook import load
from stats_utils import *

OUT = "/tmp/outputs/tables"
M, S = load()
WB = ["S13-F", "S13-G"] + [f"S15-{c}" for c in "ABCDEFGIJKMO"] + ["S09-C", "S09-E", "S09-G"]
PAIR = {"S13-F": "S03-I", "S13-G": "S03-J", "S15-A": "S06-A", "S15-B": "S06-B", "S15-C": "S06-C", "S15-D": "S06-D",
        "S15-E": "S06-E [rows34-68]", "S15-F": "S06-F [rows34-68]", "S15-G": "S06-G", "S15-I": "S15-H",
        "S15-J": "S06-E [rows71-105(imprint/PR8)]", "S15-K": "S06-F [rows71-105(imprint/Perth)]", "S15-M": "S15-L", "S15-O": "S15-N",
        "S09-C": "S09-B", "S09-E": "S09-D", "S09-G": "S09-F"}

def traj_table(block):
    W = M[M.block == block]
    out = {}
    for g, d in W.groupby("group", sort=False):
        piv = d.pivot(index="x", columns="rep", values="value").sort_index()
        piv.index = piv.index.astype(int)
        out[g] = piv.astype(float)
    return out

def classify(series):
    days = list(series.index); vals = list(series.values)
    present = [i for i, v in enumerate(vals) if v == v]
    last = present[-1]
    run = 1; i = last
    while i > 0 and vals[i - 1] == vals[i]:
        run += 1; i -= 1
    if last < len(vals) - 1:
        status = "blank"; last_real = last; death_interval = (days[last], days[last + 1])
    elif run >= 3:
        status = "carried_forward"; last_real = last - run + 1; death_interval = (days[last_real], days[last_real + 1])
    elif run == 2:
        status = "possible_carry_forward"; last_real = last - 1; death_interval = (days[last_real], days[last_real + 1])
    else:
        status = "alive_d14"; last_real = last; death_interval = None
    return status, last_real, death_interval

rows = []; animal_rows = []
for b in WB:
    for g, piv in traj_table(b).items():
        for rep in piv.columns:
            s = piv[rep]
            status, last_real, di = classify(s)
            real = s.iloc[: last_real + 1].dropna()
            # for 'possible' carry-forward keep both readings
            animal_rows.append(dict(block=b, group=g, rep=rep, status=status, last_real_day=int(piv.index[last_real]),
                                    death_interval=f"({di[0]},{di[1]}]" if di else "", nadir=real.min(), nadir_day=int(real.idxmin()),
                                    d4=s.get(4, np.nan) if piv.index[last_real] >= 4 else np.nan,
                                    d14_real=s.iloc[-1] if status in ("alive_d14",) else np.nan,
                                    d14_printed=s.iloc[-1]))
A = pd.DataFrame(animal_rows)
A.to_csv(f"{OUT}/T4a_bodyweight_per_animal.csv", index=False)

for (b, g), d in A.groupby(["block", "group"], sort=False):
    sb = PAIR[b]
    sg = S[(S.block_panel == sb) & (S.group == g)]
    rows.append(dict(weight_block=b, survival_block=sb, group=g, n=len(d),
                     alive_d14=int((d.status == "alive_d14").sum()), carried_fwd=int((d.status == "carried_forward").sum()),
                     possible_cf=int((d.status == "possible_carry_forward").sum()), blank=int((d.status == "blank").sum()),
                     deaths_in_survival_block=(int((sg.event == 1).sum()) if len(sg) else np.nan), n_in_survival_block=(len(sg) if len(sg) else np.nan),
                     mean_d4=d.d4.mean(), n_d4=int(d.d4.notna().sum()), mean_nadir=d.nadir.mean(), sd_nadir=d.nadir.std(ddof=1),
                     mean_d14_survivors=d.d14_real.mean(), n_lt80=int((d.nadir < 80).sum())))
T4 = pd.DataFrame(rows)
T4["deaths_by_weights_strict"] = T4.carried_fwd + T4.blank
T4["deaths_by_weights_incl_possible"] = T4.carried_fwd + T4.blank + T4.possible_cf
T4["concordant"] = (T4.deaths_in_survival_block == T4.deaths_by_weights_strict) | (T4.deaths_in_survival_block == T4.deaths_by_weights_incl_possible)
T4.to_csv(f"{OUT}/T4_bodyweight_by_arm_and_concordance.csv", index=False)
pd.set_option("display.width", 260); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 500)
print(T4[["weight_block", "survival_block", "group", "n", "alive_d14", "carried_fwd", "possible_cf", "blank", "deaths_in_survival_block", "concordant",
          "mean_d4", "mean_nadir", "sd_nadir", "mean_d14_survivors", "n_lt80"]].round(1).to_string(index=False))
print("\nConcordant arms:", int(T4.concordant.sum()), "of", int(T4.deaths_in_survival_block.notna().sum()), "arms with a same-label survival arm;",
      "arms with no same-label survival arm:", int(T4.deaths_in_survival_block.isna().sum()))

# ---- morbidity contrasts: nadir PSLN-344 (aged) vs young benchmark / vs PSLN-212 aged / vs Sham ; day-4 weights
print("\n=== Nadir (min real % of d0) contrasts, per experiment ===")
con = []
for b in ["S13-F", "S15-A", "S15-B", "S15-C", "S15-D", "S15-E", "S15-F", "S15-G", "S15-M", "S15-O"]:
    d = A[A.block == b]
    x = d[d.group == "PSLN-344"].nadir.values
    for ctl in ["PSLN-212(Y)", "PSLN-212", "Sham"]:
        y = d[d.group == ctl].nadir.values
        if len(y) == 0: continue
        dd, lo, hi = diff_ci(x, y)
        con.append(dict(block=b, contrast=f"PSLN-344 - {ctl}", mean_trt=x.mean(), mean_ctl=y.mean(), diff=dd, lo=lo, hi=hi, p_welch=welch(x, y)[1], p_mwu=mwu_exact(x, y)))
C = pd.DataFrame(con)
C.to_csv(f"{OUT}/T4b_nadir_contrasts.csv", index=False)
print(C.round(3).to_string(index=False))
# pooled nadir PSLN-344 aged vs young benchmark across BALB/c experiments
for ctl in ["PSLN-212(Y)", "PSLN-212", "Sham"]:
    sub = C[C.contrast == f"PSLN-344 - {ctl}"]
    print(f"mean of per-experiment nadir differences PSLN-344 - {ctl}: {sub['diff'].mean():.2f} (range {sub['diff'].min():.1f} to {sub['diff'].max():.1f}); n experiments {len(sub)}")
# overall nadirs
print("\nOverall mean nadir by arm across aged-challenge experiments (S13-F, S15-A..G, M, O):")
sel = A[A.block.isin(["S13-F", "S15-A", "S15-B", "S15-C", "S15-D", "S15-E", "S15-F", "S15-G", "S15-M", "S15-O"])]
print(sel.groupby("group").nadir.agg(["count", "mean", "std", "min"]).round(1))
print("\nYoung mice (S09-C/E/G) nadir by arm:")
sel = A[A.block.isin(["S09-C", "S09-E", "S09-G"])]
print(sel.groupby(["block", "group"]).agg(n=("nadir", "count"), nadir=("nadir", "mean"), sd=("nadir", "std"), d14=("d14_real", "mean")).round(1))
for b in ["S09-C", "S09-E", "S09-G"]:
    d = A[A.block == b]
    x = d[d.group == "PSLN-344(Y)"]; y = d[d.group == "PSLN-212(Y)"]
    print(b, "nadir 344Y-212Y:", [round(v, 2) for v in diff_ci(x.nadir.values, y.nadir.values)], "p", round(welch(x.nadir.values, y.nadir.values)[1], 3),
          "| d14 344Y-212Y:", [round(v, 2) for v in diff_ci(x.d14_printed.values, y.d14_printed.values)], "p", round(welch(x.d14_printed.values, y.d14_printed.values)[1], 4))

"""13_build_memo.py -- assembles the memo (markdown) and renders DOCX and self-contained HTML with pandoc."""
import subprocess, zipfile, shutil, os, re
A = "/tmp/outputs/analysis"; O = "/tmp/outputs"
src = open(f"{A}/memo_src.md").read()
src = src.replace("{{REGISTER_TABLE}}", open("/tmp/outputs/analysis/_build/register_table.md").read()).replace("{{INVENTORY_TABLE}}", open("/tmp/outputs/analysis/_build/inventory_table.md").read())
assert "{{" not in src
open(f"{O}/PSLN-344_portfolio_recommendation.md", "w").write(src)

# landscape reference docx with compact table text
ref = "/tmp/outputs/analysis/_build/reference.docx"
with open(ref, "wb") as f:
    f.write(subprocess.run(["pandoc", "--print-default-data-file", "reference.docx"], capture_output=True, check=True).stdout)
tmp = "/tmp/outputs/analysis/_build/reference_landscape.docx"
zin = zipfile.ZipFile(ref); zout = zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED)
for item in zin.infolist():
    data = zin.read(item.filename)
    if item.filename == "word/document.xml":
        s = data.decode("utf8")
        s = re.sub(r'<w:pgSz[^>]*/>', '<w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/>', s)
        s = re.sub(r'<w:pgMar[^>]*/>', '<w:pgMar w:top="900" w:right="850" w:bottom="900" w:left="850" w:header="500" w:footer="500" w:gutter="0"/>', s)
        if "<w:pgSz" not in s:
            s = s.replace("<w:sectPr>", '<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="900" w:right="850" w:bottom="900" w:left="850" w:header="500" w:footer="500" w:gutter="0"/>') \
                if "<w:sectPr>" in s else s.replace("</w:body>", '<w:sectPr><w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/><w:pgMar w:top="900" w:right="850" w:bottom="900" w:left="850" w:header="500" w:footer="500" w:gutter="0"/></w:sectPr></w:body>')
        data = s.encode("utf8")
    if item.filename == "word/styles.xml":
        s = data.decode("utf8")
        # body text 10.5 pt
        s = s.replace('<w:sz w:val="24" />\n        <w:szCs w:val="24" />', '<w:sz w:val="21" />\n        <w:szCs w:val="21" />', 1)
        # table style: 8.5 pt text, thin grey grid, shaded bold header row
        i = s.index('<w:style w:type="table" w:default="1" w:styleId="Table">'); j = s.index('</w:style>', i)
        blk = s[i:j]
        blk = blk.replace('<w:tblPr>', '<w:rPr><w:sz w:val="17" /><w:szCs w:val="17" /></w:rPr>\n    <w:tblPr>', 1)
        borders = '<w:tblBorders>' + ''.join(f'<w:{k} w:val="single" w:sz="4" w:space="0" w:color="BFBFBF" />' for k in ("top", "left", "bottom", "right", "insideH", "insideV")) + '</w:tblBorders>'
        blk = blk.replace('<w:tblInd w:w="0" w:type="dxa" />', '<w:tblInd w:w="0" w:type="dxa" />\n      ' + borders, 1)
        blk = blk.replace('<w:tblStylePr w:type="firstRow">', '<w:tblStylePr w:type="firstRow">\n      <w:rPr><w:b /></w:rPr>', 1)
        blk = blk.replace('</w:tcBorders>', '</w:tcBorders>\n        <w:shd w:val="clear" w:color="auto" w:fill="EEF2F8" />', 1)
        s = s[:i] + blk + s[j:]
        data = s.encode("utf8")
    zout.writestr(item, data)
zout.close()
os.chdir(O)
subprocess.run(["pandoc", "PSLN-344_portfolio_recommendation.md", "-o", "PSLN-344_portfolio_recommendation.docx", "--reference-doc", tmp, "--resource-path", O, "--toc", "--toc-depth=2"], check=True)
css = """<style>
body{font-family:Segoe UI,Helvetica,Arial,sans-serif;max-width:1180px;margin:2em auto;padding:0 1.2em;line-height:1.45;color:#1a1a1a;font-size:15px}
h1{border-bottom:2px solid #1f4e9c;padding-bottom:.2em;margin-top:1.8em;font-size:1.5em} h2{margin-top:1.4em;font-size:1.2em;color:#1f4e9c}
table{border-collapse:collapse;margin:1em 0;font-size:13px;display:block;overflow-x:auto} th,td{border:1px solid #c8c8c8;padding:4px 7px;vertical-align:top;text-align:left} th{background:#eef2f8}
img{max-width:100%} code{background:#f3f3f3;padding:1px 4px;border-radius:3px} figcaption{font-size:13px;color:#444;margin-bottom:1.2em}
header h1.title{border:none;font-size:1.9em;margin-bottom:0} p.subtitle{color:#555;margin-top:.3em}
</style>"""
open("/tmp/outputs/analysis/_build/head.html", "w").write(css)
subprocess.run(["pandoc", "PSLN-344_portfolio_recommendation.md", "-o", "PSLN-344_portfolio_recommendation.html", "--standalone", "--embed-resources", "--resource-path", O, "--toc", "--toc-depth=2",
                "-H", "/tmp/outputs/analysis/_build/head.html", "--metadata", "pagetitle=PSLN-344 portfolio recommendation"], check=True)
for f in ("PSLN-344_portfolio_recommendation.md", "PSLN-344_portfolio_recommendation.docx", "PSLN-344_portfolio_recommendation.html"):
    print(f, os.path.getsize(f))

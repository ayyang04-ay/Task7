"""11_memo_tables.py -- renders the data tables that are pasted into the memo (markdown), straight from the analysis outputs."""
import numpy as np, pandas as pd
T = "/tmp/outputs/tables"
T1 = pd.read_csv(f"{T}/T1_survival_by_arm.csv"); K = pd.read_csv(f"{T}/T2b_survival_key_contrasts.csv"); T3 = pd.read_csv(f"{T}/T3_survival_pooled_and_sensitivity.csv")
def sv(e, arm):
    d = T1[(T1.experiment == e) & (T1.arm == arm)]
    return f"{int(d.survivors.iloc[0])}/{int(d.n.iloc[0])}" if len(d) else "–"
def pv(e, trt, ctl, col="p_logrank_exact"):
    d = K[(K.experiment == e) & (K.trt == trt) & (K.ctl == ctl)]
    if not len(d): return "–"
    p = d[col].iloc[0]
    return f"{p:.4f}" if p < 0.001 else (f"{p:.3f}" if p < 0.1 else f"{p:.2f}")
rows = [("S03-J", "rgH5N1 vaccine → wild-type H5N1 (21-d follow-up)", "2 d", "a"), ("S06-B", "H3N2 vaccine → PR8 H1N1", "3 d", ""), ("S15-H", "bivalent → rgH5N1", "3 d", "b"), ("S06-D", "bivalent → rgH5N1", "3 d", "c"),
        ("S03-I", "bivalent → CA09 H1N1 (homologous, 10× mLD50)", "14 d", "a"), ("S06-A", "H3N2 vaccine → PR8 H1N1", "14 d", ""), ("S06-C", "bivalent → rgH5N1", "14 d", "c"),
        ("S06-E(1)", "H3N2 vaccine → PR8 H1N1", "60 d", "d"), ("S06-F(1)", "bivalent → rgH5N1", "60 d", "d"), ("S06-G", "H1N1 vaccine → Perth H3N2", "60 d", "d"),
        ("S15-L", "aged C57BL/6, bivalent → not stated", "n/s", "e"), ("S15-N", "aged Swiss Webster, bivalent → not stated", "n/s", "e")]
out = ["| Block | Vaccine → challenge (5× mLD50 unless stated) | Dose-to-challenge interval | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | p, 344 vs Sham | p, 344 vs 212 | Note |", "|---|---|---|---|---|---|---|---|---|---|"]
for e, model, day, note in rows:
    if e == "S15-H":
        out.append(f"| {e} | {model} | {day} | 0/7 (vaccine alone) | – | **{sv(e,'3d Vaccine+PSLN-344')}** | – | {pv(e,'3d Vaccine+PSLN-344','3d Vaccine')} | – | {note} |")
    else:
        out.append(f"| {e} | {model} | {day} | {sv(e,'Sham')} | {sv(e,'PSLN-212')} | **{sv(e,'PSLN-344')}** | {sv(e,'PSLN-212(Y)')} | {pv(e,'PSLN-344','Sham')} | {pv(e,'PSLN-344','PSLN-212')} | {note} |")
print("\n".join(out)); print()
out = ["| Block | Host | Challenge | Naive + PSLN-212 | Imprinted + PSLN-212 | Naive + **PSLN-344** | Imprinted + **PSLN-344** |", "|---|---|---|---|---|---|---|"]
for e, ch in (("S06-E(2)", "PR8 H1N1 (day not stated)"), ("S06-F(2)", "Perth H3N2, 14 d")):
    out.append(f"| {e} | BALB/c 14 mo ± PR8 infection at 10 mo | {ch} | {sv(e,'Naive+PSLN-212')} | {sv(e,'Imprinting+PSLN-212')} | **{sv(e,'Naive+PSLN-344')}** | **{sv(e,'Imprinting+PSLN-344')}** |")
print("\n".join(out)); print()
out = ["| Block | Young BALB/c: vaccine → challenge | Interval | Sham | PSLN-212(Y) | PSLN-344(Y) | Other |", "|---|---|---|---|---|---|---|"]
for e, m, d_ in (("S09-B", "H3N2 vaccine → PR8 H1N1", "21 d"), ("S09-D", "H1N1 vaccine → Perth H3N2", "21 d"), ("S09-F", "bivalent → rgH5N1", "180 d")):
    out.append(f"| {e} | {m} | {d_} | {sv(e,'Sham')} | {sv(e,'PSLN-212(Y)')} | {sv(e,'PSLN-344(Y)')} | – |")
out.append(f"| S13-E | bivalent → CA09 H1N1 (10× mLD50) | 14 d | {sv('S13-E','Sham')} | – | {sv('S13-E','PSLN-344(Y)')} | Naive {sv('S13-E','Naive')}; CMP-204(Y) {sv('S13-E','CMP-204(Y)')} |")
print("\n".join(out)); print()
# pooled
names = {"A2": "**Primary: 11 independent experiments** (S06-D dropped as duplicate)", "A1": "All blocks as printed (S06-D counted)", "A3": "S06-D replaced by counts read from its weight block (5/7)",
         "A4": "Worst case for PSLN-344 from paired weight blocks", "A5": "BALB/c only",
         "B2": "**Primary: 14 strata** (10 experiments + 4 imprinting strata)", "B3": "Worst case for PSLN-344, best case for PSLN-212", "B4": "≥20-mo BALB/c, no label conflict (6 experiments)",
         "C2": "Aged PSLN-344 vs **young** PSLN-212 (9 experiments)", "D1": "Aged PSLN-212 vs Sham (10 experiments)"}
out = ["| Comparison | PSLN-344 (or first arm) | Comparator | Difference, points (95% CI) | p |", "|---|---|---|---|---|"]
for sect, keys in (("*vs Sham / vaccine alone*", ["A2", "A1", "A3", "A4", "A5"]), ("*vs PSLN-212 (non-Mn parent), same age*", ["B2", "B3", "B4"]), ("*benchmarks*", ["C2", "D1"])):
    out.append(f"| {sect} | | | | |")
    for k in keys:
        r = T3[T3.analysis.str.startswith(k + ".")].iloc[0]
        p = r.p_strat_exact; ps = "<10⁻²⁰" if p < 1e-20 else (f"{p:.0e}".replace("e-0", "×10⁻").replace("e-", "×10⁻") if p < 1e-3 else f"{p:.3f}")
        out.append(f"| {names[k]} | {r.trt_surv} ({r.trt_pct:.0f}%; {r.trt_ci}) | {r.ctl_surv} ({r.ctl_pct:.0f}%; {r.ctl_ci}) | {r.MH_RD_pct:+.0f} ({r.RD_lo:.0f} to {min(r.RD_hi,100):.0f}) | {ps} |")
print("\n".join(out)); print()
# immune table
C = pd.read_csv(f"{T}/T5c_immunology_key_contrasts_PSLN344.csv"); SM = pd.read_csv(f"{T}/T5_immunology_group_summaries.csv"); RI = pd.read_csv(f"{T}/T6_restoration_index.csv")
def val(bp, g, x=None, geo=False):
    d = SM[(SM.block == bp) & (SM.group == g) & ((SM.x.astype(str) == str(x)) if x is not None else SM.x.isna())]
    if not len(d): return "–"
    v = d["geomean" if geo else "mean"].iloc[0]
    return f"{v:,.0f}" if v >= 100 else (f"{v:.1f}" if v >= 1 else f"{v:.2f}")
def con(bp, ctl, x=None):
    d = C[(C.block == bp) & (C.ctl == ctl) & ((C.x.astype(str) == str(x)) if x is not None else C.x.isna())]
    if not len(d): return None
    return d.iloc[0]
def rix(bp, x=None):
    d = RI[(RI.block == bp) & ((RI.x.astype(str) == str(x)) if x is not None else RI.x.isna())]
    return f"{d.RI.iloc[0]:.2f} ({d.RI_lo.iloc[0]:.2f}–{d.RI_hi.iloc[0]:.2f})" if len(d) else "–"
def pf(p): return "<0.0001" if p < 1e-4 else (f"{p:.4f}" if p < 0.001 else (f"{p:.3f}" if p < 0.1 else f"{p:.2f}"))
items = [("*Innate / recruitment*", None, None, None, None),
         ("Ifnb1, lung, 16 h, fold (GM)", "S01-A [16h]", None, True, "S01-A"), ("Gm-csf, lung, 36 h, fold (GM)", "S02-F", "36h", True, "S02-F"), ("Lung monocytes, d4, %", "S01-D", "4", False, "S01-D"), ("Lung CD11b+ DC, d4, %", "S01-E", "4", False, "S01-E"),
         ("*DC migration / function*", None, None, None, None),
         ("CCR7+ migratory CD11b+ DC, %", "S02-A", None, False, "S02-A"), ("Antigen+ DC in MLN, %", "S02-C", None, False, "S02-C"), ("OT-I proliferation by MLN DC, %", "S02-E", None, False, "S02-E"), ("CD40+ of MLN CD11b+ DC, %", "S02-D CD40", None, False, "S02-D"), ("CD86+ of MLN CD11b+ DC, %", "S02-D CD86", None, False, "S02-D"),
         ("*Humoral (day 14 unless stated)*", None, None, None, None),
         ("Serum IgG anti-H1N1 (GMT)", "S03-A", None, True, "S03-A"), ("HAI anti-H1N1 (GMT)", "S03-C", None, True, "S03-C"), ("Neutralising anti-H1N1 (GMT)", "S03-D", None, True, "S03-D"), ("HAI anti-H3N2 (GMT)", "S03-G", None, True, "S03-G"),
         ("GC B cells, MLN, d7, %", "S03-K", None, False, "S03-K"), ("ICOS+ Tfh, MLN, d7, %", "S04-A [ICOS+]", None, False, "S04-A"), ("Tfr, MLN, d7, %", "S04-B Foxp3", None, False, "S04-B"), ("Tfr, MLN, d30, %", "S04-C", None, False, "S04-C"),
         ("*CD8 T cells*", None, None, None, None),
         ("Ki-67+ CD8, lung, d3, %", "S05-D", None, False, "S05-D"), ("GZMB+ CD8, lung, d3, %", "S05-E", None, False, "S05-E"), ("IFN-γ+ CD8 to rgH5N1, MLN, d14, %", "S05-F", None, False, "S05-F"), ("IFN-γ+ CD8 to rgH5N1, MLN, d60, %", "S05-G", None, False, "S05-G"), ("Lung CD8 TRM, d25, %", "S05-I", None, False, "S05-I")]
out = ["| Readout | Block | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | PSLN-344 vs PSLN-212: effect (95% CI) | Tukey p | Restoration index (95% CI) |", "|---|---|---|---|---|---|---|---|---|"]
for lab, bp, x, geo, blk in items:
    if bp is None: out.append(f"| {lab} | | | | | | | | |"); continue
    r = con(bp, "PSLN-212", x)
    hai = bp in ("S03-C", "S03-G")
    eff = (f"×{r.est:.1f} ({r.lo:.1f}–{r.hi:.1f})" if r.effect.startswith("ratio") else f"{r.est:+.1f} ({r.lo:+.1f} to {r.hi:+.1f})")
    out.append(f"| {lab} | {blk} | {val(bp,'Sham',x,geo)} | {val(bp,'PSLN-212',x,geo)} | **{val(bp,'PSLN-344',x,geo)}** | {val(bp,'PSLN-212(Y)',x,geo)} | {eff} | {pf(r.p_tukey)} | {rix(bp,x)} |")
print("\n".join(out)); print()
REG = pd.read_csv(f"{T}/integrity_register.csv")
out = ["| ID | Blocks | Finding | Evidence | Effect on conclusions | How handled here |", "|---|---|---|---|---|---|"]
for _, r in REG.iterrows():
    out.append(f"| {r.id} | {r.blocks} | {r.finding} | {r.evidence} | {r.effect_on_conclusions} | {r.how_handled_here} |")
open("/tmp/outputs/analysis/_build/register_table.md", "w").write("\n".join(out))
print("register table rows:", len(REG))

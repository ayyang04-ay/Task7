import json, pandas as pd
B = json.load(open('blocks.json'))
rows = []
REN = [('_r34', ' (rows 34-68)'), ('_r71', ' (rows 71-98)'), ('_16h', ' (16 h panel)'), ('_72h', ' (72 h panel)'), ('_panel1', ' (cols A-U)'), ('_panel2', ' (cols X-AS)'),
       ('_CD40', ' CD40'), ('_CD86', ' CD86'), ('_Aicda', ' Aicda'), ('_E47', ' E47'), ('_ICOShi', ' (ICOS-high)'), ('_ICOSlo', ' (ICOS-low)'), ('_Foxp3', ' (Foxp3)'), ('_TfhTfr', ' (Tfh:Tfr)'),
       ('_mono', ' (monocytes)'), ('_mac', ' (macrophages)'), ('_Ifnb1', ' (Ifnb1)'), ('_Tnf', ' (Tnf)'), ('_Isg15', ' (Isg15)'), ('_H1N1', ' H1N1'), ('_H3N2', ' H3N2')]
def nice(bid):
    for a_, b_ in REN: bid = bid.replace(a_, b_)
    return bid
for bid, b in B.items():
    if b['kind'] == 'raw':
        rows.append(dict(block='S08 rows 89-101 (no label)', sheet=b['sheet'], kind='unlabelled', measurand=b['measurand'], stated_n='', group='(none)', cells=b['cells'], observed_n='6 values in col C, 7 in col D')); continue
    for g in b['order']:
        d = b['groups'][g]
        if b['kind'] == 'groups': n = sum(v is not None for v in d['values'])
        elif b['kind'] == 'survival': n = f"{len(d['records'])} rows ({sum(r['status']==1 for r in d['records'])} deaths" + (f", {sum(r['day'] is None for r in d['records'])} without a day" if any(r['day'] is None for r in d['records']) else '') + ')'
        else:
            per = [sum(v is not None for v in row) for row in d['matrix']]
            n = per[0] if len(set(per)) == 1 else '/'.join(map(str, per))
        rows.append(dict(block=nice(bid), sheet=b['sheet'], kind=b['kind'], measurand=b['measurand'], stated_n=b.get('stated_n', ''), group=g, cells=d['cells'], observed_n=n))
pd.DataFrame(rows).to_csv('block_directory.csv', index=False)
print(len(rows), 'rows')

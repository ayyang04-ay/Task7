import json, numpy as np, pandas as pd
from scipy import stats
B = json.load(open('blocks.json'))
T = pd.read_csv('immuno_tests.csv')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
# 1. S04-B Tfh:Tfr derivation check
fox = B['S04-B_Foxp3']['groups']; rat = B['S04-B_TfhTfr']['groups']; lo = B['S04-A_ICOSlo']['groups']; hi = B['S04-A_ICOShi']['groups']
print('S04-B "Tfh:Tfr" as printed vs (100-Foxp3%)/Foxp3% vs (ICOShi Tfh%)/Foxp3% vs (ICOSlo+hi)/Foxp3%')
ok = 0; tot = 0
for g in B['S04-B_Foxp3']['order']:
    for i in range(5):
        f = fox[g]['values'][i]; r = rat[g]['values'][i]
        d1 = (100 - f)/f; d2 = hi[g]['values'][i]/f; d3 = (hi[g]['values'][i] + lo[g]['values'][i])/f
        tot += 1; ok += abs(d1 - r) < 1e-4
    print(f'   {g:12s} printed {np.round(rat[g]["values"],3)}  (100-F)/F {np.round([(100-f)/f for f in fox[g]["values"]],3)}  ICOShi/F {np.round([h/f for h,f in zip(hi[g]["values"], fox[g]["values"])],3)}')
print(f'   -> {ok}/{tot} printed values equal (100-Foxp3%)/Foxp3% to 4 dp')
print('   sums ICOSlo+ICOShi per animal:', {g: np.round(np.array(lo[g]['values'])+np.array(hi[g]['values']), 2).tolist() for g in lo})
print('   fraction ICOShi of Tfh:', {g: np.round(np.array(hi[g]['values'])/(np.array(lo[g]['values'])+np.array(hi[g]['values'])), 3).tolist() for g in lo})

# 2. two-group mechanistic blocks
print('\nTwo-group / intervention blocks (Welch t on stated scale; fold or diff):')
for blk in ['S01-C','S11-C','S12-A','S02-I','S07-B_mono','S07-B_mac','S07-C']:
    print(T[T.block == blk][['block','g1','g2','effect','value','p_student','p_welch','p_mannwhitney']].to_string(index=False, header=False, float_format=lambda x: f'{x:.3g}'))
for blk in ['S01-B','S05-C','S02-G','S02-H','S02-C','S02-E','S08-C']:
    print(T[T.block == blk][['block','g1','g2','effect','value','p_tukey','p_welch']].to_string(index=False, header=False, float_format=lambda x: f'{x:.3g}'))

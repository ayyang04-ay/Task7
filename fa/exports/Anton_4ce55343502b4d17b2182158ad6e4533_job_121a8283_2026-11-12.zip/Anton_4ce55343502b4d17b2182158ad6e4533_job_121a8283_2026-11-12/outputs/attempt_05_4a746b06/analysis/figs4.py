import json, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
B = json.load(open('blocks.json'))
import os
OUT = os.environ.get('PSLN_FIGDIR', '/tmp/outputs/figures/')
os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})
def M(bid, g): return np.array([[np.nan if v is None else v for v in row] for row in B[bid]['groups'][g]['matrix']], float)
fig, axes = plt.subplots(2, 3, figsize=(13.5, 7.8))
# a) S15-C vs S15-I
ax = axes[0, 0]; d = B['S15-C']['times']
a, b = M('S15-C', 'PSLN-344'), M('S15-I', '3d Vaccine+PSLN-344')
for j in range(7):
    ax.plot(d, a[:, j], color='#1f5fa8', lw=2.2, alpha=0.55, label='S15-C "challenge at d14", PSLN-344' if j == 0 else None)
    ax.plot(d, b[:, j], color='#d62728', lw=0.9, ls='--', label='S15-I "challenge at d3", vaccine+PSLN-344' if j == 0 else None)
ax.set_xlabel('Days after challenge'); ax.set_ylabel('Body weight (% of day 0)'); ax.legend(frameon=False, fontsize=7.5, loc='lower left')
ax.set_title('a  Two different experiments, one set of numbers\n   40 of 49 post-challenge values identical; all 7 day-14 values differ', loc='left', fontsize=9)
# b) S06-C vs S06-D
ax = axes[0, 1]
def km(bid, g):
    r = B[bid]['groups'][g]['records']; t = np.array([x['day'] for x in r], float); e = np.array([x['status'] for x in r])
    ts = [0]; s = [1.0]; n = len(t); surv = 1.0
    for tt in np.unique(t[e == 1]):
        atrisk = (t >= tt).sum(); dth = ((t == tt) & (e == 1)).sum(); ts += [tt]; surv *= 1 - dth / atrisk; s += [surv]
    return np.r_[ts, 14], np.r_[s, s[-1]]
for g, c in [('Sham', '#8c8c8c'), ('PSLN-212', '#e6862a'), ('PSLN-344', '#1f5fa8')]:
    t1, s1 = km('S06-C', g); t2, s2 = km('S06-D', g)
    ax.step(t1, 100 * s1, where='post', color=c, lw=3, alpha=0.45, label=f'S06-C (d14) {g}')
    ax.step(t2, 100 * s2, where='post', color='k', lw=0.9, ls='--', label='S06-D (d3), same groups' if g == 'Sham' else None)
ax.set_xlabel('Days after challenge'); ax.set_ylabel('Survival (%)'); ax.legend(frameon=False, fontsize=7.5, loc='center right')
ax.set_title('b  rgH5N1 survival tables for d14 and d3 challenge\n   are identical in all four groups (28 of 28 records)', loc='left', fontsize=9)
# c) S11-A vs S11-B
ax = axes[0, 2]; days = [0, 2, 4, 6, 8]
for g, c in [('Vaccine', '#8c8c8c'), ('PSLN-212', '#e6862a'), ('PSLN-344', '#1f5fa8'), ('PSLN-212(Y)', '#3a9a5c')]:
    ax.plot(days, M('S11-A', g).mean(axis=1), color=c, lw=3, alpha=0.45, label=f'{g}: "alveolar macrophages" S11-A')
    ax.plot(days, M('S11-B', g).mean(axis=1), color=c, lw=1, ls='--', marker='x', ms=4, label='same groups: "neutrophils" S11-B' if g == 'Vaccine' else None)
ax.set_xlabel('Days after immunisation'); ax.set_ylabel('% (as printed)'); ax.legend(frameon=False, fontsize=7, loc='upper left', ncol=1)
ax.set_ylim(15, 84)
ax.set_title('c  "Neutrophil" block reproduces the alveolar-macrophage block\n   (animals 1-2 of every group identical in 34 of 40 cells)', loc='left', fontsize=9)
# d) IgG2a/IgG1 printed vs recomputed
ax = axes[1, 0]
pr = {g: np.array(B['S03-B']['groups'][g]['values']) for g in B['S03-B']['order']}
rc = {g: np.array(B['S13-A']['groups'][g]['values']) / np.array(B['S13-B']['groups'][g]['values']) for g in B['S13-A']['order']}
x = np.arange(3); w = 0.36
ax.bar(x - w/2, [pr[g].mean() for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']], w, color='#bdbdbd', label='as printed in S03-B')
ax.bar(x + w/2, [rc[g].mean() for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']], w, color='#1f5fa8', label='recomputed from raw IgG2a / IgG1 (S13-A / S13-B)')
for i, g in enumerate(['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']):
    ax.scatter(np.full(5, i - w/2), pr[g], color='k', s=8, zorder=3); ax.scatter(np.full(5, i + w/2), rc[g], color='k', s=8, zorder=3)
ax.axhline(1, color='k', lw=0.6, ls=':'); ax.set_xticks(x); ax.set_xticklabels(['PSLN-212 (aged)', 'PSLN-344 (aged)', 'PSLN-212 (young)']); ax.set_ylabel('IgG2a / IgG1 (anti-CA09, d14)')
ax.set_ylim(0, 6.3); ax.legend(frameon=False, fontsize=7.5, loc='upper left')
ax.set_title('d  Printed ratio columns are rotated relative to the raw titres\n   (printed: PSLN-344 looks IgG1-skewed; raw: IgG2a-dominant)', loc='left', fontsize=9)
# e) weights: carried-forward values
ax = axes[1, 1]; d = B['S15-A']['times']; m = M('S15-A', 'PSLN-212')
for j in range(7):
    ax.plot(d, m[:, j], color='#e6862a', lw=1.3, marker='o', ms=3)
ax.plot(d, m.mean(axis=1), color='k', lw=2, ls='--', label='naive group mean (includes carried-forward weights)')
ax.set_xlabel('Days after challenge'); ax.set_ylabel('Body weight (% of day 0)'); ax.legend(frameon=False, fontsize=7.5, loc='upper right')
ax.set_title('e  Dead animals stay in the weight table at their last weight\n   S15-A PSLN-212: 6 of 7 died (S06-A), yet 7 values on every day', loc='left', fontsize=9)
# f) S09-A panel-2 vs S01-A 72h
ax = axes[1, 2]
names = [('PBS', 'Sham'), ('CMP-204', 'CMP-204'), ('PSLN-212', 'PSLN-212'), ('PSLN-R848', 'PSLN-R848'), ('PSLN-212/R848', 'PSLN-212/R848'), ('PSLN-344', 'PSLN-344'), ('PSLN-212(y)', 'PSLN-212(Y)')]
for k, (a_, b_) in enumerate(names):
    p2 = 10**np.array(B['S09-A_panel2']['groups'][a_]['matrix'][0]); p1 = 10**np.array(B['S09-A_panel1']['groups'][a_]['matrix'][0])
    s72 = np.array(B['S01-A_72h']['groups'][b_]['values']); s16 = np.array(B['S01-A_16h']['groups'][b_]['values'])
    ax.scatter(np.full(5, k) - 0.12, s72, facecolor='none', edgecolor='#1f5fa8', s=55, label='S01-A, 72 h panel (n=5)' if k == 0 else None)
    ax.scatter(np.full(3, k) - 0.12, p2, color='#1f5fa8', s=12, label='S09-A cols X-AS, labelled "16h" (n=3)' if k == 0 else None)
    ax.scatter(np.full(5, k) + 0.12, s16, facecolor='none', edgecolor='#e6862a', s=55, label='S01-A, 16 h panel (n=5)' if k == 0 else None)
    ax.scatter(np.full(3, k) + 0.12, p1, color='#e6862a', s=12, label='S09-A cols A-U, labelled "16h" (n=3)' if k == 0 else None)
ax.set_yscale('log'); ax.set_xticks(range(len(names))); ax.set_xticklabels([n[1] for n in names], fontsize=7, rotation=30, ha='right', rotation_mode='anchor'); ax.set_ylabel('Lung Ifnb1, fold (log scale)')
ax.legend(frameon=False, fontsize=7, loc='upper left')
ax.set_title('f  The second "16h" cytokine panel is the 72 h data\n   every Ifnb1 value sits on a 72 h value from S01-A (21 of 21)', loc='left', fontsize=9)
fig.tight_layout(); fig.savefig(OUT + 'figA2_data_integrity_examples.png', dpi=180, bbox_inches='tight'); plt.close(fig)
print('fig A2 done')

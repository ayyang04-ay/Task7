"""Exact permutation p-values for the per-experiment log-rank comparisons (PSLN-344 vs PSLN-212).
With 7-10 animals per arm the chi-square approximation can be optimistic; this enumerates every relabelling."""
import json, itertools, numpy as np
from scipy import stats
B = json.load(open('blocks.json'))
def recs(bid, g):
    r = [x for x in B[bid]['groups'][g]['records'] if x['day'] is not None]
    return np.array([x['day'] for x in r], float), np.array([x['status'] for x in r], int)
def lr_stat(t, e, inA):
    OE = V = 0.0
    for tt in np.unique(t[e == 1]):
        risk = t >= tt; n = risk.sum(); nA = (risk & inA).sum(); d = ((t == tt) & (e == 1)).sum(); dA = ((t == tt) & (e == 1) & inA).sum()
        OE += dA - d*nA/n
        if n > 1: V += d*(nA/n)*(1-nA/n)*(n-d)/(n-1)
    return OE**2/V if V > 0 else 0.0
EXPS = [('S03-I','PSLN-344','PSLN-212'),('S03-J','PSLN-344','PSLN-212'),('S06-B','PSLN-344','PSLN-212'),('S06-A','PSLN-344','PSLN-212'),('S06-E_r34','PSLN-344','PSLN-212'),
        ('S06-D','PSLN-344','PSLN-212'),('S06-C','PSLN-344','PSLN-212'),('S06-F_r34','PSLN-344','PSLN-212'),('S06-G','PSLN-344','PSLN-212'),
        ('S06-E_r71','Naïve+PSLN-344','Naïve+PSLN-212'),('S06-E_r71','Imprinting+PSLN-344','Imprinting+PSLN-212'),('S06-F_r71','Naïve+PSLN-344','Naïve+PSLN-212'),('S06-F_r71','Imprinting+PSLN-344','Imprinting+PSLN-212'),
        ('S15-L','PSLN-344','PSLN-212'),('S15-N','PSLN-344','PSLN-212')]
nsig = 0
for bid, gA, gB in EXPS:
    tA, eA = recs(bid, gA); tB, eB = recs(bid, gB)
    t = np.r_[tA, tB]; e = np.r_[eA, eB]; nA = len(tA); N = len(t)
    obs = lr_stat(t, e, np.r_[np.ones(nA, bool), np.zeros(N-nA, bool)])
    cnt = tot = 0
    for comb in itertools.combinations(range(N), nA):
        inA = np.zeros(N, bool); inA[list(comb)] = True
        s = lr_stat(t, e, inA); tot += 1; cnt += s >= obs - 1e-9
    p_exact = cnt/tot; p_asym = stats.chi2.sf(obs, 1); nsig += p_exact < 0.05
    print(f'{bid:10s} {gA:22s} vs {gB:22s} chi2={obs:6.2f}  asymptotic p={p_asym:.4f}  exact permutation p={p_exact:.4f}  ({tot} relabellings)')
print(f'{nsig}/15 comparisons with exact p < 0.05')

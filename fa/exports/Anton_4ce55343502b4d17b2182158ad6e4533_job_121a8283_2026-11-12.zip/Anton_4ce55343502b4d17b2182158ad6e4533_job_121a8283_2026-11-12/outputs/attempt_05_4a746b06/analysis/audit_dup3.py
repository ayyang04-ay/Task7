import json, itertools
B = json.load(open('blocks.json'))
vecs = []
for bid, b in B.items():
    k = b['kind']
    if k == 'weights' or k == 'survival' or k == 'raw': continue
    if b.get('scale') == 'titre' and bid in ('S03-C','S03-D','S03-G','S03-H'): continue  # 2-fold dilution series repeat legitimately
    if k == 'groups':
        for g, d in b['groups'].items(): vecs.append((bid, g, [v for v in d['values'] if v is not None]))
    elif k == 'timecourse':
        for g, d in b['groups'].items():
            for t, row in zip(b['times'], d['matrix']): vecs.append((f'{bid}@{t}', g, [v for v in row if v is not None]))
    elif k == 'analytes':
        for g, d in b['groups'].items():
            for a, row in zip(b['analytes'], d['matrix']): vecs.append((f'{bid}:{a}', g, [round(10**v, 2) for v in row]))
print('non-weight vectors:', len(vecs))
hits = []
for (b1, g1, v1), (b2, g2, v2) in itertools.combinations(vecs, 2):
    if b1.split('@')[0].split(':')[0] == b2.split('@')[0].split(':')[0] and g1 == g2: continue
    sh = set(v1) & set(v2)
    sh = {x for x in sh if x not in (0, 1, 100)}
    if len(sh) >= 2:
        hits.append((len(sh), b1, g1, b2, g2, sorted(sh)))
hits.sort(reverse=True)
for h in hits[:60]: print(h)
print(len(hits))

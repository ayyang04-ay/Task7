import json, math, itertools, warnings
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
warnings.filterwarnings('ignore')
B = json.load(open('blocks.json'))
pd.set_option('display.width', 260); pd.set_option('display.max_rows', 1000); pd.set_option('display.max_colwidth', 70)

LOG_SCALES = ('titre', 'fold')   # analysed on log10 scale; summary = geometric mean
def prep(values, scale, lod=None):
    v = [x for x in values if x is not None]
    v = np.array(v, float)
    if scale in LOG_SCALES:
        if lod is not None:
            v = np.where(v < lod, lod/2.0, v)    # HAI: 0 = below 1:10 -> LOD/2 = 5
        return np.log10(v)
    return v

def gsum(values, scale, lod=None):
    raw = np.array([x for x in values if x is not None], float)
    x = prep(values, scale, lod)
    n = len(x); m = x.mean(); sd = x.std(ddof=1) if n > 1 else float('nan')
    se = sd/np.sqrt(n) if n > 1 else float('nan')
    tcrit = stats.t.ppf(0.975, n-1) if n > 1 else float('nan')
    if scale in LOG_SCALES:
        return dict(n=n, center=10**m, lo=10**(m - tcrit*se), hi=10**(m + tcrit*se), stat='GM', arith_mean=raw.mean(), sd=raw.std(ddof=1), min=raw.min(), max=raw.max())
    return dict(n=n, center=m, lo=m - tcrit*se, hi=m + tcrit*se, stat='mean', arith_mean=raw.mean(), sd=sd, min=raw.min(), max=raw.max())

rows = []; tests = []
def analyse_groups(bid, groups, scale, lod=None, label=None):
    label = label or bid
    data = {g: prep(v, scale, lod) for g, v in groups.items()}
    for g, v in groups.items():
        s = gsum(v, scale, lod); s.update(block=label, group=g, scale=scale); rows.append(s)
    names = list(data)
    if len(names) >= 2 and all(len(v) >= 2 for v in data.values()):
        F, p_anova = stats.f_oneway(*data.values()) if len(names) > 2 else (float('nan'), float('nan'))
        allv = np.concatenate(list(data.values())); lab = np.concatenate([[g]*len(v) for g, v in data.items()])
        tuk = {}
        if len(names) > 2:
            res = pairwise_tukeyhsd(allv, lab)
            for (g1, g2, md, padj, lo, hi, rej) in res.summary().data[1:]:
                tuk[frozenset((g1, g2))] = float(padj)
        for g1, g2 in itertools.combinations(names, 2):
            a, b = data[g1], data[g2]
            t, p_w = stats.ttest_ind(a, b, equal_var=False)
            t2, p_s = stats.ttest_ind(a, b, equal_var=True)
            try:
                u, p_mw = stats.mannwhitneyu(a, b, alternative='two-sided')
            except Exception:
                p_mw = float('nan')
            diff = b.mean() - a.mean()
            eff = (10**diff) if scale in LOG_SCALES else diff
            tests.append(dict(block=label, g1=g1, g2=g2, scale=scale, effect=('fold g2/g1' if scale in LOG_SCALES else 'diff g2-g1'), value=eff,
                              p_anova=p_anova, p_tukey=tuk.get(frozenset((g1, g2)), float('nan')), p_student=p_s, p_welch=p_w, p_mannwhitney=p_mw))

for bid, b in B.items():
    k = b['kind']; scale = b.get('scale'); lod = b.get('lod')
    if k == 'groups':
        analyse_groups(bid, {g: d['values'] for g, d in b['groups'].items()}, scale, lod)
    elif k == 'timecourse':
        for i, t in enumerate(b['times']):
            tl = f'{bid}@{t}' if t is not None else bid
            analyse_groups(bid, {g: d['matrix'][i] for g, d in b['groups'].items()}, scale, lod, label=tl)
    elif k == 'analytes':
        for i, a in enumerate(b['analytes']):
            # stored as log10 -> analyse on the stored scale, report 10**mean (geometric mean fold)
            groups = {g: d['matrix'][i] for g, d in b['groups'].items()}
            label = f'{bid}:{a}'
            data = {g: np.array(v, float) for g, v in groups.items()}
            for g, v in data.items():
                n = len(v); m = v.mean(); sd = v.std(ddof=1); se = sd/np.sqrt(n); tc = stats.t.ppf(0.975, n-1)
                rows.append(dict(block=label, group=g, scale='log10fold', n=n, center=10**m, lo=10**(m-tc*se), hi=10**(m+tc*se), stat='GM(fold)', arith_mean=m, sd=sd, min=v.min(), max=v.max()))
            names = list(data)
            F, p_anova = stats.f_oneway(*data.values())
            allv = np.concatenate(list(data.values())); lab = np.concatenate([[g]*len(v) for g, v in data.items()])
            res = pairwise_tukeyhsd(allv, lab); tuk = {frozenset((r[0], r[1])): float(r[3]) for r in res.summary().data[1:]}
            for g1, g2 in itertools.combinations(names, 2):
                a_, b_ = data[g1], data[g2]
                t, p_w = stats.ttest_ind(a_, b_, equal_var=False); t2, p_s = stats.ttest_ind(a_, b_, equal_var=True)
                tests.append(dict(block=label, g1=g1, g2=g2, scale='log10fold', effect='fold g2/g1', value=10**(b_.mean()-a_.mean()), p_anova=p_anova,
                                  p_tukey=tuk.get(frozenset((g1, g2))), p_student=p_s, p_welch=p_w, p_mannwhitney=float('nan')))
R = pd.DataFrame(rows)[['block','group','scale','stat','n','center','lo','hi','arith_mean','sd','min','max']]
T = pd.DataFrame(tests)
R.to_csv('immuno_summary.csv', index=False); T.to_csv('immuno_tests.csv', index=False)
print(R.to_string(index=False, float_format=lambda x: f'{x:.4g}'))

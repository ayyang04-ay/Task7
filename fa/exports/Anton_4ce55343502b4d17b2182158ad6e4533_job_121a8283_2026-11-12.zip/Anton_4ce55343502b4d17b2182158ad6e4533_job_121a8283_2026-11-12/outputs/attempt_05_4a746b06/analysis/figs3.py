import json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
B = json.load(open('blocks.json'))
import os
OUT = os.environ.get('PSLN_FIGDIR', '/tmp/outputs/figures/')
os.makedirs(OUT, exist_ok=True)
COL = {'Sham': '#8c8c8c', 'PSLN-212': '#e6862a', 'PSLN-344': '#1f5fa8', 'PSLN-212(Y)': '#3a9a5c', 'CMP-204': '#c9a227', 'PSLN-R848': '#b07cc6', 'PSLN-212/R848': '#b24a4a', 'Vaccine': '#8c8c8c', 'PBS': '#bdbdbd', 'CT': '#b24a4a', 'PSLN-212(y)': '#3a9a5c'}
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})

fig = plt.figure(figsize=(13.4, 8.2))
gs = fig.add_gridspec(2, 3, height_ratios=[1, 1.05], hspace=0.48, wspace=0.32)
# a) post-vaccination body weight
ax = fig.add_subplot(gs[0, 0])
b = B['S08-D']; days = b['times']
for g in ['Vaccine', 'PSLN-212(Y)', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212/R848']:
    m = np.array([[np.nan if v is None else v for v in row] for row in b['groups'][g]['matrix']], float)
    ax.plot(days, np.nanmean(m, axis=1), marker='o', color=COL[g], lw=2.2 if g == 'PSLN-344' else 1.3, ms=4, label=g.replace('(Y)', ' (young)').replace('Vaccine', 'Vaccine alone'))
    if g in ('PSLN-344', 'PSLN-212/R848'):
        for j in range(m.shape[1]): ax.plot(days, m[:, j], color=COL[g], lw=0.6, alpha=0.45)
ax.axhline(100, color='k', lw=0.5, ls=':'); ax.set_xlabel('Days after intranasal immunisation (no challenge)'); ax.set_ylabel('Body weight (% of day 0)')
ax.legend(frameon=False, fontsize=7.5, loc='lower left'); ax.set_ylim(83, 104)
ax.set_title('a  Body weight after dosing [S08-D], n = 5\n   thin lines = individual animals', loc='left', fontsize=9)
# b) CNS transcripts
ax = fig.add_subplot(gs[0, 1])
x = 0
ticks = []; tl = []
for a in ['Ifnb1', 'Tnf', 'Isg15']:
    for g in ['PBS', 'Sham', 'PSLN-344', 'CT']:
        v = np.array(B[f'S10-A_{a}']['groups'][g]['values'], float)
        ax.scatter(np.full(len(v), x) + np.linspace(-0.18, 0.18, len(v)), v, color=COL[g], s=18, zorder=3)
        gmv = 10**np.log10(v).mean(); ax.plot([x - 0.3, x + 0.3], [gmv, gmv], color='k', lw=1.3)
        x += 1
    ticks.append(x - 2.5); tl.append(a); x += 0.8
ax.set_xticks(ticks); ax.set_xticklabels(tl, style='italic'); ax.set_ylabel('CNS transcript, fold vs untreated'); ax.axhline(1, color='k', lw=0.5, ls=':')
h = [Line2D([], [], marker='o', ls='', color=COL[g], label=l) for g, l in [('PBS', 'PBS (buffer)'), ('Sham', 'Sham (empty liposome)'), ('PSLN-344', 'PSLN-344'), ('CT', 'Cholera toxin')]]
ax.legend(handles=h, frameon=False, fontsize=7.5, loc='upper right')
ax.set_title('b  CNS transcripts at 36 h [S10-A], n = 5\n   groups as printed; bar = geometric mean', loc='left', fontsize=9)
# c) encapsulation
ax = fig.add_subplot(gs[0, 2])
b = B['S08-B']
for i, g in enumerate(b['order']):
    v = np.array(b['groups'][g]['matrix'][0], float)
    ax.scatter(np.full(3, i) + np.array([-0.12, 0, 0.12]), v, color=COL[g], s=26, zorder=3); ax.plot([i - 0.28, i + 0.28], [v.mean(), v.mean()], color='k', lw=1.3)
    ax.text(i, 74, f'{v.mean():.1f}', ha='center', fontsize=8)
ax.set_xticks(range(5)); ax.set_xticklabels(b['order'], fontsize=7.5, rotation=25, ha='right', rotation_mode='anchor'); ax.set_ylim(40, 78); ax.set_ylabel('Encapsulation efficiency (%)')
ax.set_title('c  Agonist loading [S08-B], n = 3\n   no higher for PSLN-344 than PSLN-212', loc='left', fontsize=9)
# d) lung cytokine heatmaps 16h vs 72h
an = B['S09-A_panel1']['analytes']; groups = ['CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(y)', 'PSLN-R848', 'PSLN-212/R848']
glab = ['CMP-204 (aged)', 'PSLN-212 (aged)', 'PSLN-344 (aged)', 'PSLN-212 (young)', 'PSLN-R848 (aged)', 'PSLN-212/R848 (aged)']
sub = gs[1, :].subgridspec(1, 2, wspace=0.22)
for k, (p, ttl) in enumerate([('S09-A_panel1', 'd  Lung cytokine transcripts at 16 h [S09-A, cols A-U], n = 3'), ('S09-A_panel2', 'e  Same analytes at 72 h [S09-A, cols X-AS; printed label says "16h" - see integrity log]')]):
    ax = fig.add_subplot(sub[0, k])
    M = np.array([[np.mean(B[p]['groups'][g]['matrix'][i]) for i in range(len(an))] for g in groups])
    im = ax.imshow(M, cmap='RdBu_r', vmin=-3.2, vmax=3.2, aspect='auto')
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            val = 10**M[i, j]
            ax.text(j, i, f'{val:.0f}x' if val >= 10 else f'{val:.1f}x', ha='center', va='center', fontsize=8, color='white' if abs(M[i, j]) > 1.7 else 'k')
    ax.set_xticks(range(len(an))); ax.set_xticklabels(an, style='italic'); ax.set_yticks(range(len(groups))); ax.set_yticklabels(glab if k == 0 else [''] * len(groups), fontsize=8)
    ax.set_title(ttl, loc='left', fontsize=9)
    ax.spines[:].set_visible(False); ax.tick_params(length=0)
    ax.add_patch(plt.Rectangle((-0.5, 1.5), len(an), 1, fill=False, ec='#1f5fa8', lw=2))
cb = fig.colorbar(im, ax=fig.axes[-2:], fraction=0.018, pad=0.012); cb.set_label('log10 fold vs untreated', fontsize=8)
fig.text(0.125, 0.035, 'Cell text = geometric-mean fold over untreated (10^mean of stored log10 values).', fontsize=8)
fig.savefig(OUT + 'fig5_tolerability_and_reactogenicity.png', dpi=190, bbox_inches='tight'); plt.close(fig)

# ------------ Fig 5: morbidity: per-animal max weight loss after challenge -------------
A = pd.read_csv('bw_per_animal.csv')
pairs = [('S13-F', 'CA09 d14\n(homologous)'), ('S15-B', 'PR8 d3'), ('S15-A', 'PR8 d14'), ('S15-E', 'PR8 d60'), ('S15-D', 'rgH5N1 d3'), ('S15-I', 'rgH5N1 d3\n(S15-H expt)'), ('S15-C', 'rgH5N1 d14*'), ('S15-F', 'rgH5N1 d60'), ('S15-G', 'Perth d60'), ('S15-M', 'C57BL/6'), ('S15-O', 'Swiss\nWebster')]
fig, ax = plt.subplots(figsize=(12.2, 4.6))
gmap = {'PSLN-212': ('#e6862a', -0.27), 'PSLN-344': ('#1f5fa8', 0.0), '3d Vaccine+PSLN-344': ('#1f5fa8', 0.0), 'PSLN-212(Y)': ('#3a9a5c', 0.27), 'Untreated': ('#b07cc6', 0.5)}
rng = np.random.default_rng(3)
for i, (wb, lab) in enumerate(pairs):
    for g, (c, off) in gmap.items():
        d = A[(A.wblock == wb) & (A.group == g)]
        if len(d) == 0: continue
        xs = i + off + rng.uniform(-0.07, 0.07, len(d))
        alive = d.state.values == 'alive'
        ax.scatter(xs[alive], 100 - d.nadir.values[alive], color=c, s=20, zorder=3)
        ax.scatter(xs[~alive], 100 - d.nadir.values[~alive], marker='x', color=c, s=24, zorder=3, linewidth=1.2)
    ax.axvline(i + 0.7, color='#eeeeee', lw=0.7)
ax.set_xticks(range(len(pairs))); ax.set_xticklabels([p[1] for p in pairs], fontsize=8); ax.set_ylabel('Maximum body-weight loss after challenge\n(% of day-0 weight, per animal)')
ax.axhline(0, color='k', lw=0.5)
h = [Line2D([], [], marker='o', ls='', color='#1f5fa8', label='PSLN-344 (aged)'), Line2D([], [], marker='o', ls='', color='#e6862a', label='PSLN-212 (aged)'), Line2D([], [], marker='o', ls='', color='#3a9a5c', label='PSLN-212 (young)'),
     Line2D([], [], marker='o', ls='', color='#b07cc6', label='Untreated, unchallenged (aged)'), Line2D([], [], marker='x', ls='', color='k', label='animal recorded as dead in the weight table (last measured weight)')]
ax.legend(handles=h, frameon=False, fontsize=8, ncol=3, loc='upper center', bbox_to_anchor=(0.5, -0.16))
ax.set_title('Protected does not mean uninfected: PSLN-344 survivors lose weight on the same scale as protected young animals\n(sham arms omitted - all died; *S15-C PSLN-344 series duplicates S15-I, see integrity log)', loc='left', fontsize=9.5)
fig.tight_layout(); fig.savefig(OUT + 'fig2_morbidity_weight_loss.png', dpi=190, bbox_inches='tight'); plt.close(fig)
print('figs 4-5 done')

import json
from collections import defaultdict
H = json.load(open('dup_hits.json'))
B = json.load(open('blocks.json'))
# expected chance level: body weights to 0.1 in a ~20-unit range -> chance of positional equality about 1/200 per cell
agg = defaultdict(lambda: dict(pos=0, rows=[], ncell=0))
for h in H:
    key = (h['b1'], h['g1'], h['b2'], h['g2'])
    agg[key]['pos'] += h['pos']; agg[key]['rows'].append(h)
print('Pairs with >=5 position-identical values in total (chance expectation < 0.5 for 7x7 one-decimal weights):\n')
for key, d in sorted(agg.items(), key=lambda kv: -kv[1]['pos']):
    if d['pos'] < 5: continue
    print(f"### {key[0]} [{key[1]}]  <->  {key[2]} [{key[3]}]  : {d['pos']} position-identical values")
    for h in sorted(d['rows'], key=lambda x: str(x['t1'])):
        if h['pos'] >= 1:
            mark = ['=' if (a is not None and a == b and a not in (100,)) else '.' for a, b in zip(h['v1'], h['v2'])]
            print(f"    {h['t1']:>6} {h['v1']}\n    {h['t2']:>6} {h['v2']}   {''.join(mark)}")

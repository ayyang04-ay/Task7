import json, numpy as np, pandas as pd, warnings
from scipy import stats, optimize
from statsmodels.stats.multicomp import pairwise_tukeyhsd
warnings.filterwarnings('ignore')
B = json.load(open('blocks.json'))
pd.set_option('display.width', 250)

print('=== S08-D: body weight after immunisation (no challenge), % of day 0; per-animal nadir over d2-d10 ===')
b = B['S08-D']; times = b['times']
nad = {}
for g in b['order']:
    m = np.array([[np.nan if v is None else v for v in row] for row in b['groups'][g]['matrix']], float)
    nadir = np.nanmin(m[1:], axis=0); nad[g] = nadir
    means = np.nanmean(m, axis=1); ns = (~np.isnan(m)).sum(axis=1)
    print(f'  {g:14s} mean by day {dict(zip(times, np.round(means, 1)))}  n by day {list(ns)}  per-animal nadir {np.round(nadir,1)}  mean max loss {100-nadir.mean():.1f}% (worst animal {100-nadir.min():.1f}%)  d10 mean {means[-1]:.1f}')
allv = np.concatenate(list(nad.values())); lab = np.concatenate([[g]*len(v) for g, v in nad.items()])
print('  one-way ANOVA on nadir: p =', stats.f_oneway(*nad.values()).pvalue)
res = pairwise_tukeyhsd(allv, lab)
for r in res.summary().data[1:]:
    if 'PSLN-344' in (r[0], r[1]) or ('PSLN-212/R848' in (r[0], r[1]) and 'Vaccine' in (r[0], r[1])):
        print(f'    Tukey {r[0]} vs {r[1]}: diff {r[2]:.2f}, p-adj {r[3]:.4f}')
# d10 recovery
m344 = np.array(b['groups']['PSLN-344']['matrix'], float)
print('  PSLN-344 d10 values:', m344[-1], ' -> all >= 99%?', (m344[-1] >= 99).all())
mR = np.array([[np.nan if v is None else v for v in row] for row in b['groups']['PSLN-212/R848']['matrix']], float)
print('  PSLN-212/R848 trajectories (rows=day):'); print(mR)

print('\n=== S10-A: CNS transcripts 36 h (fold vs untreated; analysed on log10 scale) ===')
for a in ['Ifnb1', 'Tnf', 'Isg15']:
    g = {k: np.log10(np.array(v['values'], float)) for k, v in B[f'S10-A_{a}']['groups'].items()}
    allv = np.concatenate(list(g.values())); lab = np.concatenate([[k]*len(v) for k, v in g.items()])
    res = pairwise_tukeyhsd(allv, lab)
    gm = {k: 10**v.mean() for k, v in g.items()}
    print(f'  {a}: GM fold', {k: round(x, 2) for k, x in gm.items()}, ' ANOVA p=%.2g' % stats.f_oneway(*g.values()).pvalue)
    for r in res.summary().data[1:]:
        if 'PSLN-344' in (r[0], r[1]) or {'CT','PBS'} == {r[0], r[1]}:
            print(f'      Tukey {r[0]} vs {r[1]}: fold {10**abs(r[2]):.2f}, p-adj {r[3]:.4f}')
    # upper 95% bound of PSLN-344 / Sham ratio (Welch)
    a_, b_ = g['PSLN-344'], g['Sham']
    d = a_.mean() - b_.mean(); se = np.sqrt(a_.var(ddof=1)/5 + b_.var(ddof=1)/5)
    df = se**4 / ((a_.var(ddof=1)/5)**2/4 + (b_.var(ddof=1)/5)**2/4)
    tc = stats.t.ppf(0.975, df)
    print(f'      PSLN-344 / Sham ratio = {10**d:.2f} (95% CI {10**(d-tc*se):.2f}-{10**(d+tc*se):.2f});  CT / Sham = {10**(g["CT"].mean()-b_.mean()):.2f}')

print('\n=== S08-A: Ifnb1 dose-response (16 h), Emax (Hill) fit on geometric means ===')
b = B['S08-A']; doses = np.array(b['times'], float)
def hill(d, emax, ed50, h): return 1 + emax * d**h / (ed50**h + d**h)
for g in b['order']:
    m = np.array(b['groups'][g]['matrix'], float)
    gm = 10**np.log10(m).mean(axis=1)
    try:
        popt, _ = optimize.curve_fit(lambda d, emax, ed50, h: np.log10(hill(d, emax, ed50, h)), np.repeat(doses, 3), np.log10(m).ravel(), p0=[gm.max(), 10, 2], bounds=([0, 0.1, 0.3], [500, 200, 8]))
        fit = f'Emax(top fold)={1+popt[0]:.1f}, ED50={popt[1]:.1f} ug, Hill={popt[2]:.1f}'
    except Exception as e:
        fit = f'fit failed {e}'
    print(f'  {g:14s} GM fold by dose {dict(zip(doses.astype(int), np.round(gm, 1)))}   {fit};  ratio 40/20 ug = {gm[4]/gm[3]:.2f}')
m212 = np.log10(np.array(B['S08-A']['groups']['PSLN-212']['matrix'], float)); m344 = np.log10(np.array(B['S08-A']['groups']['PSLN-344']['matrix'], float))
print('  PSLN-212 40 ug vs 20 ug: Welch p =', stats.ttest_ind(m212[4], m212[3], equal_var=False).pvalue)
print('  PSLN-344 10 ug vs PSLN-212 40 ug: fold', 10**(m344[2].mean()-m212[4].mean()), ' Welch p =', stats.ttest_ind(m344[2], m212[4], equal_var=False).pvalue)
print('  PSLN-344 40 ug vs 20 ug: fold', 10**(m344[4].mean()-m344[3].mean()), ' Welch p =', stats.ttest_ind(m344[4], m344[3], equal_var=False).pvalue)

print('\n=== S08-B: encapsulation efficiency (%) ===')
b = B['S08-B']
for g in b['order']:
    v = np.array(b['groups'][g]['matrix'][0], float); print(f'  {g:14s} {v}  mean {v.mean():.1f} SD {v.std(ddof=1):.1f}')
g = {k: np.array(v['matrix'][0], float) for k, v in b['groups'].items()}
print('  ANOVA p =', stats.f_oneway(*g.values()).pvalue, ' PSLN-344 vs PSLN-212 Welch p =', stats.ttest_ind(g['PSLN-344'], g['PSLN-212'], equal_var=False).pvalue)

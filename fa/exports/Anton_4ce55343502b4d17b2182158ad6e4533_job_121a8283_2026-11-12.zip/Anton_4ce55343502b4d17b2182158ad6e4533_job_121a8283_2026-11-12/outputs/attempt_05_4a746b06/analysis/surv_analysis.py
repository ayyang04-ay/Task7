import json, itertools, math
import numpy as np, pandas as pd
from scipy import stats
from lifelines.statistics import logrank_test, multivariate_logrank_test
from lifelines import KaplanMeierFitter
from statsmodels.stats.proportion import proportion_confint

B = json.load(open('blocks.json'))
SURV = [k for k, b in B.items() if b['kind'] == 'survival']

def recs(bid, g, drop_missing=True):
    r = B[bid]['groups'][g]['records']
    if drop_missing:
        r = [x for x in r if x['day'] is not None]
    return np.array([x['day'] for x in r], float), np.array([x['status'] for x in r], int)

def summarize(bid, g):
    allr = B[bid]['groups'][g]['records']
    n_all = len(allr); miss = sum(x['day'] is None for x in allr)
    t, e = recs(bid, g)
    n = len(t); d = int(e.sum()); s = n - d
    lo, hi = proportion_confint(s, n, alpha=0.05, method='beta')
    # median survival (KM)
    kmf = KaplanMeierFitter().fit(t, e)
    med = kmf.median_survival_time_
    return dict(block=bid, group=g, n_rows=n_all, n_missing_day=miss, n=n, deaths=d, survivors=s, surv_pct=100*s/n,
                ci_lo=100*lo, ci_hi=100*hi, median_days=(med if np.isfinite(med) else None),
                death_days=sorted(int(x) for x, ev in zip(t, e) if ev == 1),
                censor_days=sorted(set(int(x) for x, ev in zip(t, e) if ev == 0)))

rows = []
for bid in SURV:
    for g in B[bid]['order']:
        rows.append(summarize(bid, g))
S = pd.DataFrame(rows)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 60)
print(S[['block','group','n_rows','n_missing_day','n','deaths','survivors','surv_pct','ci_lo','ci_hi','median_days','death_days']].to_string(index=False, float_format=lambda x: f'{x:.1f}'))
S.to_csv('survival_summary.csv', index=False)

def lr(bid, g1, g2):
    t1, e1 = recs(bid, g1); t2, e2 = recs(bid, g2)
    res = logrank_test(t1, t2, e1, e2)
    # Fisher exact on death by end of observation
    a = int(e1.sum()); b = len(e1) - a; c = int(e2.sum()); d = len(e2) - c
    fp = stats.fisher_exact([[a, b], [c, d]])[1]
    return res.p_value, res.test_statistic, fp

print('\nPairwise comparisons (log-rank Mantel-Cox as stated in the annotation; Fisher exact two-sided on deaths by end of observation)')
comp_rows = []
for bid in SURV:
    gs = B[bid]['order']
    pairs = []
    for g1, g2 in itertools.combinations(gs, 2):
        pairs.append((g1, g2))
    for g1, g2 in pairs:
        p, chi, fp = lr(bid, g1, g2)
        comp_rows.append(dict(block=bid, g1=g1, g2=g2, logrank_chi2=chi, logrank_p=p, fisher_p=fp))
C = pd.DataFrame(comp_rows)
C.to_csv('survival_pairwise.csv', index=False)
key = C[(C.g1.str.contains('344') | C.g2.str.contains('344'))]
print(key.to_string(index=False, float_format=lambda x: f'{x:.4g}'))

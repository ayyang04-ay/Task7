import json, itertools, math
import numpy as np, pandas as pd
from scipy import stats
from lifelines.statistics import logrank_test
from statsmodels.stats.proportion import proportion_confint
B = json.load(open('blocks.json'))
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)

def recs(bid, g):
    r = [x for x in B[bid]['groups'][g]['records'] if x['day'] is not None]
    return np.array([x['day'] for x in r], float), np.array([x['status'] for x in r], int)

# Aged-animal experiments in which vaccine+PSLN-344 is compared with vaccine+PSLN-212 and/or vaccine+sham
# (arm-name mapping per block).  "exp" = experiment id used as stratum.
EXPS = [
 # block, label, {arm: group name}
 ('S03-I',     'CA09 10x, d14 (homologous), BALB/c',        dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S03-J',     'WT H5N1, d2, rgH5N1 vaccine',               dict(sham='Sham', p212='PSLN-212', p344='PSLN-344')),
 ('S06-A',     'H3N2 vax -> PR8, d14',                      dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S06-B',     'H3N2 vax -> PR8, d3',                       dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S06-C',     'bivalent -> rgH5N1, d14',                   dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S06-D',     'bivalent -> rgH5N1, d3 (table identical to S06-C)', dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S06-E_r34', 'H3N2 vax -> PR8, d60',                      dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S06-F_r34', 'bivalent -> rgH5N1, d60',                   dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S06-G',     'H1N1 vax -> Perth H3N2, d60',               dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S06-E_r71', 'PR8 challenge, non-imprinted (14 mo)',      dict(p212='Naïve+PSLN-212', p344='Naïve+PSLN-344')),
 ('S06-E_r71i','PR8 challenge, PR8-imprinted (14 mo)',      dict(p212='Imprinting+PSLN-212', p344='Imprinting+PSLN-344')),
 ('S06-F_r71', 'Perth challenge, non-imprinted (14 mo)',    dict(p212='Naïve+PSLN-212', p344='Naïve+PSLN-344')),
 ('S06-F_r71i','Perth challenge, PR8-imprinted (14 mo)',    dict(p212='Imprinting+PSLN-212', p344='Imprinting+PSLN-344')),
 ('S15-H',     'bivalent -> rgH5N1, d3 (antigen-requirement expt)', dict(p344='3d Vaccine+PSLN-344', vax_only='3d Vaccine', adj_only='3d PSLN-344')),
 ('S15-L',     'aged C57BL/6 (challenge not stated)',       dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
 ('S15-N',     'aged Swiss Webster (challenge not stated)', dict(sham='Sham', p212='PSLN-212', p344='PSLN-344', young='PSLN-212(Y)')),
]
rows = []
for exp, lab, arms in EXPS:
    bid = exp[:-1] if exp.endswith('i') else exp
    r = dict(exp=exp, label=lab)
    for arm, g in arms.items():
        t, e = recs(bid, g); r[arm] = f'{len(e)-e.sum()}/{len(e)}'
    if 'p212' in arms:
        t1, e1 = recs(bid, arms['p344']); t2, e2 = recs(bid, arms['p212'])
        r['LR p 344v212'] = logrank_test(t1, t2, e1, e2).p_value
        r['Fisher p 344v212'] = stats.fisher_exact([[e1.sum(), len(e1)-e1.sum()], [e2.sum(), len(e2)-e2.sum()]])[1]
    if 'sham' in arms:
        t1, e1 = recs(bid, arms['p344']); t2, e2 = recs(bid, arms['sham'])
        r['LR p 344vSham'] = logrank_test(t1, t2, e1, e2).p_value
    if 'young' in arms:
        t1, e1 = recs(bid, arms['p344']); t2, e2 = recs(bid, arms['young'])
        r['LR p 344vYoung'] = logrank_test(t1, t2, e1, e2).p_value
    rows.append(r)
E = pd.DataFrame(rows).fillna('')
print(E.to_string(index=False, float_format=lambda x: f'{x:.2g}'))
E.to_csv('efficacy_table.csv', index=False)

def pooled(arm, exclude=()):
    s = n = 0; used = []
    for exp, lab, arms in EXPS:
        if exp in exclude or arm not in arms: continue
        bid = exp[:-1] if exp.endswith('i') else exp
        t, e = recs(bid, arms[arm]); s += len(e) - e.sum(); n += len(e); used.append(exp)
    lo, hi = proportion_confint(s, n, method='beta')
    return int(s), int(n), 100*s/n, 100*lo, 100*hi, used
print('\nPooled survival at end of observation (descriptive; experiments differ in virus/dose/timing):')
for name, excl in [('all 16 aged comparisons', ()), ('counting S06-C/S06-D (identical tables) once', ('S06-D',))]:
    print(' ', name)
    for arm in ['sham', 'p212', 'p344', 'young']:
        s, n, pct, lo, hi, used = pooled(arm, excl)
        print(f'     {arm:6s}: {s}/{n} = {pct:.1f}% (95% CI {lo:.1f}-{hi:.1f}); n experiments={len(used)}')

# Stratified (by experiment) log-rank: PSLN-344 vs PSLN-212, and vs sham  -- sum of (O-E) and variances across strata
def strat_logrank(armA, armB, exclude=()):
    OE = 0.0; V = 0.0; k = 0
    for exp, lab, arms in EXPS:
        if exp in exclude or armA not in arms or armB not in arms: continue
        bid = exp[:-1] if exp.endswith('i') else exp
        tA, eA = recs(bid, arms[armA]); tB, eB = recs(bid, arms[armB])
        times = np.unique(np.concatenate([tA[eA == 1], tB[eB == 1]]))
        for tt in times:
            nA = (tA >= tt).sum(); nB = (tB >= tt).sum(); dA = ((tA == tt) & (eA == 1)).sum(); dB = ((tB == tt) & (eB == 1)).sum()
            n = nA + nB; d = dA + dB
            if n > 1:
                OE += dA - d * nA / n
                V += d * (nA / n) * (nB / n) * (n - d) / (n - 1)
        k += 1
    chi = OE**2 / V
    return chi, stats.chi2.sf(chi, 1), k
for a, b in [('p344', 'p212'), ('p344', 'sham'), ('p344', 'young'), ('p212', 'sham')]:
    for excl in [(), ('S06-D',)]:
        chi, p, k = strat_logrank(a, b, excl)
        print(f'  stratified log-rank {a} vs {b} (excluded={excl}): chi2={chi:.1f}, p={p:.2e}, strata={k}')

# sign test: direction of survival difference p344 - p212 per experiment
diffs = []
for exp, lab, arms in EXPS:
    if 'p212' in arms:
        bid = exp[:-1] if exp.endswith('i') else exp
        t1, e1 = recs(bid, arms['p344']); t2, e2 = recs(bid, arms['p212'])
        diffs.append((1 - e1.mean()) - (1 - e2.mean()))
pos = sum(d > 0 for d in diffs); print(f'\n  PSLN-344 survival > PSLN-212 in {pos}/{len(diffs)} experiments; exact two-sided sign test p = {stats.binomtest(pos, len(diffs), 0.5).pvalue:.2e}')
print('  absolute survival differences (344 - 212):', [round(d, 2) for d in diffs], ' median =', np.median(diffs))

# Mantel-Haenszel pooled risk difference & odds ratio for death (p344 vs p212), stratified by experiment
import statsmodels.api as sm
tabs = []
for exp, lab, arms in EXPS:
    if 'p212' in arms and exp != 'S06-D':
        bid = exp[:-1] if exp.endswith('i') else exp
        t1, e1 = recs(bid, arms['p344']); t2, e2 = recs(bid, arms['p212'])
        tabs.append(np.array([[len(e1)-e1.sum(), e1.sum()], [len(e2)-e2.sum(), e2.sum()]]))   # rows: 344,212 ; cols: survive, die
st = sm.stats.StratifiedTable(tabs)
print(f'  Mantel-Haenszel pooled OR for survival (344 vs 212; S06-D excluded): {st.oddsratio_pooled:.1f} (95% CI {st.oddsratio_pooled_confint()[0]:.1f}-{st.oddsratio_pooled_confint()[1]:.1f}); CMH p={st.test_null_odds().pvalue:.2e}')
print(f'  MH pooled risk ratio for survival: {st.riskratio_pooled:.2f}')

# durability in aged PSLN-344 arm
print('\nDurability, aged PSLN-344 arm (survival tables):')
for lab, exps in [('d2-3', ['S03-J','S06-B','S06-D','S15-H']), ('d14', ['S03-I','S06-A','S06-C']), ('d60', ['S06-E_r34','S06-F_r34','S06-G'])]:
    s = n = 0
    for exp in exps:
        arms = [a for e_, l, a in EXPS if e_ == exp][0]
        t, e = recs(exp, arms['p344']); s += len(e) - e.sum(); n += len(e)
    lo, hi = proportion_confint(s, n, method='beta'); print(f'   challenge at {lab}: {int(s)}/{n} = {100*s/n:.0f}% (95% CI {100*lo:.0f}-{100*hi:.0f}); blocks {exps}')
# d14 vs d60 Fisher for BALB/c (same virus pairs: PR8 and rgH5N1)
a = (6+7, 14); b = (5+5, 14)
print('   same-virus comparison PR8+rgH5N1: d14 13/14 vs d60 10/14; Fisher p =', stats.fisher_exact([[13, 1], [10, 4]])[1])
print('   all d14 (20/21) vs all d60 (14/21): Fisher p =', stats.fisher_exact([[20, 1], [14, 7]])[1])
print('   young PSLN-212 d60: 21/21; aged PSLN-344 d60 14/21: Fisher p =', stats.fisher_exact([[21, 0], [14, 7]])[1])
# background mortality
print('\nUntreated (no vaccine, no adjuvant, no virus) aged controls, 14-day window:')
tot_d = tot_n = 0
for exp in ['S06-E_r34', 'S06-F_r34', 'S06-G']:
    t, e = recs(exp, 'Untreated'); tot_d += e.sum(); tot_n += len(e); print(f'   {exp}: {int(e.sum())}/{len(e)} died, days {sorted(t[e==1].astype(int))}')
lo, hi = proportion_confint(tot_d, tot_n, method='beta'); print(f'   pooled {int(tot_d)}/{tot_n} = {100*tot_d/tot_n:.0f}% (95% CI {100*lo:.0f}-{100*hi:.0f})')

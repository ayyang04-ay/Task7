| Read-out (summary statistic) | Block | Sham | PSLN-212 aged | **PSLN-344 aged** | PSLN-212 young | 344 vs 212 aged (Tukey p) | 344 aged vs young (Tukey p) | Age gap closed |
|---|---|---|---|---|---|---|---|---|
| **Innate response in the lung** | | | | | | | | |
| Ifnb1 mRNA, 16 h, fold (nanoparticle alone) (GM) | S01-A (16 h panel) | 0.94 | 16.5 | **36.9** | 37.5 | 2.2× (0.0006) | 0.98× (1.00) | 0.98 |
| Monocytes, day 4, % (mean) | S01-D | 10.4 | 16.7 | **30.6** | 32.2 | +13.8 pts (<0.0001) | −1.7 pts (0.84) | 0.89 |
| CD11b+ dendritic cells, day 4, % (mean) | S01-E | 4.8 | 8.3 | **18.9** | 21.4 | +10.6 pts (0.007) | −2.5 pts (0.88) | 0.81 |
| cDC1, 72 h, % (mean) | S01-F | 17.9 | 22.8 | **37.5** | 43.4 | +14.7 pts (0.0003) | −5.9 pts (0.26) | 0.71 |
| Migratory CCR7+ CD11b+ DC, 72 h, % (mean) | S02-A | 2.5 | 7.3 | **30.7** | 35.0 | +23.4 pts (<0.0001) | −4.3 pts (0.49) | 0.84 |
| Antigen-carrying DC in lymph node, 36 h, % (mean) | S02-C | — | 1.8 | **7.1** | 9.4 | +5.3 pts (<0.0001) | −2.3 pts (0.072) | 0.70 |
| CD40+ lymph-node CD11b+ DC, day 3, % (mean) | S02-D CD40 | 4.0 | 5.6 | **11.2** | 38.7 | +5.6 pts (0.16) | −27.5 pts (<0.0001) | 0.17 |
| CD86+ lymph-node CD11b+ DC, day 3, % (mean) | S02-D CD86 | 7.2 | 8.1 | **14.5** | 37.9 | +6.4 pts (0.033) | −23.4 pts (<0.0001) | 0.22 |
| CD206+ macrophages, % (mean) | S11-E | 85.2 | 71.5 | **48.9** | 35.5 | −22.5 pts (0.002) | +13.4 pts (0.068) | 0.63 |
| **CD8 T cells** | | | | | | | | |
| Lung Ki-67+ CD8, day 3, % (mean) | S05-D | 0.83 | 3.5 | **9.4** | 9.9 | +5.9 pts (0.0008) | −0.6 pts (0.97) | 0.91 |
| Lung granzyme B+ CD8, day 3, % (mean) | S05-E | 0.99 | 3.0 | **5.7** | 9.6 | +2.7 pts (0.0008) | −3.9 pts (<0.0001) | 0.41 |
| IFN-γ+ CD8 to rgH5N1 restimulation, day 14, % (mean) | S05-F | 0.67 | 1.5 | **6.4** | 9.2 | +4.9 pts (<0.0001) | −2.8 pts (0.0001) | 0.63 |
| IFN-γ+ CD8 to rgH5N1 restimulation, day 60, % (mean) | S05-G | 1.5 | 3.0 | **9.9** | 14.4 | +6.8 pts (0.0008) | −4.5 pts (0.024) | 0.60 |
| Lung resident-memory CD8, day 25, % (mean) | S05-I | 0.58 | 1.0 | **4.0** | 6.0 | +3.0 pts (<0.0001) | −2.1 pts (<0.0001) | 0.59 |
| Lung regulatory T cells, day 7, % (n = 3) (mean) | S04-D | 5.9 | 6.7 | **3.0** | 1.8 | −3.7 pts (0.0002) | +1.2 pts (0.12) | 0.75 |
| **Antibody and germinal centre** | | | | | | | | |
| Serum IgG anti-CA09, day 14, titre (GM) | S03-A | 55.7 | 393 | **7,305** | 11,959 | 18.6× (<0.0001) | 0.61× (0.72) | 0.86 |
| Serum IgG anti-Aichi, day 14, titre (GM) | S03-E | 52.4 | 426 | **5,701** | 13,855 | 13.4× (0.0001) | 0.41× (0.33) | 0.75 |
| HAI anti-CA09, day 14, titre (GM) | S03-C | 7.6 | 45.9 | **368** | 485 | 8.0× (<0.0001) | 0.76× (0.87) | 0.88 |
| HAI anti-Aichi, day 14, titre (GM) | S03-G | 10.0 | 34.8 | **320** | 368 | 9.2× (<0.0001) | 0.87× (0.99) | 0.94 |
| Neutralising anti-CA09, day 14, titre (GM) | S03-D | 52.2 | 418 | **3,840** | 6,686 | 9.2× (0.0002) | 0.57× (0.67) | 0.80 |
| Neutralising anti-Aichi, day 14, titre (GM) | S03-H | 39.6 | 276 | **2,533** | 4,411 | 9.2× (<0.0001) | 0.57× (0.53) | 0.80 |
| Germinal-centre B cells, day 7, % (mean) | S03-K | 1.2 | 2.3 | **6.5** | 9.8 | +4.2 pts (0.007) | −3.3 pts (0.040) | 0.56 |
| T follicular helper (ICOS-high), day 7, % (mean) | S04-A (ICOS-high) | 0.3 | 3.8 | **10.3** | 13.6 | +6.4 pts (0.0002) | −3.4 pts (0.045) | 0.66 |
| T follicular regulatory, day 7, % (mean) | S04-B (Foxp3) | 22.6 | 26.7 | **10.8** | 7.1 | −15.9 pts (0.0002) | +3.7 pts (0.58) | 0.81 |
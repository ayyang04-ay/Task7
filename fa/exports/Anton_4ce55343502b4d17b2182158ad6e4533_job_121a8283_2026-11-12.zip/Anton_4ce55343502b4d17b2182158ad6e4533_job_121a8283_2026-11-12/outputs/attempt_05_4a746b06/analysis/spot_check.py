import os
"""Independent spot-check: recompute headline numbers straight from cell addresses (no use of blocks.json)."""
import openpyxl, numpy as np
from openpyxl.utils import range_boundaries
wb = openpyxl.load_workbook(os.environ.get('PSLN_WORKBOOK', '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'), data_only=True)
def R(ref):
    sh, rng = ref.split('!'); ws = wb[sh]; c0, r0, c1, r1 = range_boundaries(rng)
    return np.array([ws.cell(r, c).value for r in range(r0, r1+1) for c in range(c0, c1+1)], dtype=object)
def num(ref): return np.array([v for v in R(ref) if v is not None], float)
def gm(ref): return 10**np.log10(num(ref)).mean()
checks = []
def chk(name, got, exp, tol):
    ok = abs(got - exp) <= tol; checks.append(ok); print(f'{"OK " if ok else "XX "} {name}: got {got:.4g}, memo {exp}')
# survival counts
def alive(ref): v = R(ref); return int(sum(x == 0 for x in v)), int(sum(x is not None for x in v))
tot344 = [alive(r) for r in ['S03!E17:E51','S03!J17:J45','S06!D3:D30','S06!J3:J30','S06!P3:P30','S06!D34:D61','S06!J34:J68','S06!P34:P68','S06!D71:D105','S06!J71:J98','S06!K71:K98','S06!P71:P98','S06!Q71:Q98','S15!D73:D93','S15!D103:D130','S15!D134:D161']]
print('PSLN-344 per block:', tot344)
chk('PSLN-344 pooled survivors', sum(a for a, n in tot344), 97, 0); chk('PSLN-344 pooled n', sum(n for a, n in tot344), 114, 0)
tot212 = [alive(r) for r in ['S03!D17:D51','S03!I17:I46','S06!C3:C30','S06!I3:I30','S06!O3:O30','S06!C34:C61','S06!I34:I68','S06!O34:O68','S06!C71:C105','S06!H71:H98','S06!I71:I98','S06!N71:N98','S06!O71:O98','S15!C103:C130','S15!C134:C161']]
chk('PSLN-212 pooled survivors', sum(a for a, n in tot212), 15, 0); chk('PSLN-212 pooled n', sum(n for a, n in tot212), 108, 0)
totsh = [alive(r) for r in ['S03!B17:B51','S03!H17:H46','S06!B3:B30','S06!H3:H30','S06!N3:N30','S06!B34:B61','S06!H34:H68','S06!N34:N68','S06!B71:B105','S15!B103:B130','S15!B134:B161']]
chk('Sham pooled survivors', sum(a for a, n in totsh), 1, 0); chk('Sham pooled n', sum(n for a, n in totsh), 80, 0)
toty = [alive(r) for r in ['S03!F17:F51','S06!E3:E30','S06!K3:K30','S06!Q3:Q30','S06!E34:E61','S06!K34:K68','S06!Q34:Q68','S06!E71:E105','S15!E103:E130','S15!E134:E161']]
chk('Young pooled survivors', sum(a for a, n in toty), 69, 0); chk('Young pooled n', sum(n for a, n in toty), 70, 0)
print('S15-H vaccine alone / PSLN-344 alone / both:', alive('S15!B73:B93'), alive('S15!C73:C93'), alive('S15!D73:D93'))
print('Untreated:', alive('S06!L34:L68'), alive('S06!R34:R68'), alive('S06!F71:F105'))
# innate
chk('Ifnb1 16h PSLN-344 GM', gm('S01!B8:F8'), 36.9, 0.05); chk('Ifnb1 16h PSLN-212 GM', gm('S01!B5:F5'), 16.5, 0.05); chk('Ifnb1 16h young GM', gm('S01!B9:F9'), 37.5, 0.05)
chk('Ifnb1 72h PSLN-344 GM', gm('S01!H8:L8'), 4.2, 0.05)
chk('S08-A PSLN-344 20ug', gm('S08!H6:J6'), 45.5, 0.05); chk('S08-A PSLN-212 40ug', gm('S08!E7:G7'), 14.7, 0.05); chk('S08-A PSLN-212 20ug', gm('S08!E6:G6'), 12.5, 0.05); chk('S08-A PSLN-344 10ug', gm('S08!H5:J5'), 21.0, 0.05); chk('S08-A PSLN-344 40ug', gm('S08!H7:J7'), 49.7, 0.05)
chk('EE PSLN-344', num('S08!M11:O11').mean(), 54.8, 0.05); chk('EE PSLN-212', num('S08!D11:F11').mean(), 59.6, 0.05)
chk('Gm-csf 16h PSLN-344', gm('S02!B17:F17'), 6.0, 0.05); chk('Gm-csf 36h PSLN-344', gm('S02!B18:F18'), 8.5, 0.05); chk('Gm-csf 72h PSLN-344', gm('S02!B19:F19'), 3.6, 0.05)
chk('Gm-csf 16h PSLN-212', gm('S02!G17:K17'), 1.4, 0.05); chk('Gm-csf 36h PSLN-212', gm('S02!G18:K18'), 1.6, 0.05)
# antibody
hai = num('S03!N3:N7'); chk('HAI CA09 PSLN-344 GMT', 10**np.log10(hai).mean(), 368, 0.5); chk('HAI CA09 PSLN-212 GMT', gm('S03!M3:M7'), 45.9, 0.05); chk('HAI CA09 young GMT', gm('S03!O3:O7'), 485, 0.5)
sh = num('S03!K3:K7'); sh = np.where(sh < 10, 5, sh); chk('HAI CA09 sham GMT (0 -> 5)', 10**np.log10(sh).mean(), 7.6, 0.05)
chk('IgG CA09 PSLN-344 GMT', gm('S03!D3:D7'), 7305, 1); chk('IgG CA09 PSLN-212 GMT', gm('S03!C3:C7'), 393, 0.5); chk('IgG CA09 CMP-204 GMT', gm('S03!B3:B7'), 181, 0.5)
chk('IgG2a/IgG1 CA09 PSLN-344', (num('S13!B3:B7')/num('S13!F3:F7')).mean(), 2.14, 0.005); chk('IgG2a/IgG1 CA09 PSLN-212', (num('S13!A3:A7')/num('S13!E3:E7')).mean(), 0.58, 0.005); chk('IgG2a/IgG1 CA09 young', (num('S13!C3:C7')/num('S13!G3:G7')).mean(), 2.97, 0.005)
chk('IgG2a/IgG1 Aichi PSLN-344', (num('S13!J3:J7')/num('S13!N3:N7')).mean(), 2.73, 0.005); chk('IgG2a/IgG1 Aichi PSLN-212', (num('S13!I3:I7')/num('S13!M3:M7')).mean(), 0.51, 0.005); chk('IgG2a/IgG1 Aichi young', (num('S13!K3:K7')/num('S13!O3:O7')).mean(), 2.89, 0.005)
chk('post-boost IgG CA09 PSLN-344', gm('S13!I53:I57'), 15650, 5); chk('post-boost IgG CA09 PSLN-212', gm('S13!H53:H57'), 4411, 1); chk('post-boost IgG Aichi PSLN-344', gm('S13!O53:O57'), 12440, 5); chk('post-boost IgG Aichi PSLN-212', gm('S13!N53:N57'), 1086, 1)
# T cells
chk('IFNg d14 PSLN-344', num('S05!C33:C37').mean(), 6.4, 0.05); chk('IFNg d60 PSLN-344', num('S05!C40:C44').mean(), 9.9, 0.05); chk('TRM PSLN-344', num('S05!C54:C58').mean(), 4.0, 0.05)
# tolerability
w = np.array([[wb['S08'].cell(r, c).value for c in range(17, 22)] for r in range(22, 27)], float)
chk('S08-D PSLN-344 mean max loss', 100 - w.min(axis=0).mean(), 3.6, 0.05); chk('S08-D PSLN-344 worst', 100 - w.min(), 5.8, 0.05); chk('S08-D PSLN-344 min d10', w[-1].min(), 99.2, 0.01)
w = np.array([[np.nan if wb['S08'].cell(r, c).value is None else wb['S08'].cell(r, c).value for c in range(22, 27)] for r in range(22, 27)], float)
chk('S08-D R848 combo mean max loss', 100 - np.nanmin(w, axis=0).mean(), 10.0, 0.05); chk('S08-D R848 combo worst', 100 - np.nanmin(w), 15.3, 0.05)
chk('CNS Ifnb1 PSLN-344/Sham', gm('S10!C3:C7')/gm('S10!B3:B7'), 1.14, 0.005); chk('CNS Ifnb1 CT/Sham', gm('S10!D3:D7')/gm('S10!B3:B7'), 4.8, 0.05)
# S09-A lung cytokines (log10 stored): PSLN-344 = Q:S (panel 1), AN:AP (panel 2); rows 3..9 = Ifnb1, Il6, Ccl2, Ccl3, Ccl5, Tnf, Il10
def p(ref): return 10**num(ref).mean()
chk('16h Il6 PSLN-344', p('S09!Q4:S4'), 36, 0.5); chk('16h Ccl2 PSLN-344', p('S09!Q5:S5'), 590, 0.5); chk('16h Tnf PSLN-344', p('S09!Q8:S8'), 40, 0.5); chk('16h Il10 PSLN-344', p('S09!Q9:S9'), 7.3, 0.05)
chk('72h Il6 PSLN-344', p('S09!AN4:AP4'), 7.2, 0.05); chk('72h Ccl2 PSLN-344', p('S09!AN5:AP5'), 27, 0.5); chk('72h Tnf PSLN-344', p('S09!AN8:AP8'), 8.4, 0.05)
chk('16h Tnf PSLN-212/R848', p('S09!N8:P8'), 202, 0.5); chk('16h Il10 PSLN-212/R848', p('S09!N9:P9'), 179, 0.5); chk('72h Tnf PSLN-212/R848', p('S09!AK8:AM8'), 50, 0.5); chk('72h Il10 PSLN-212/R848', p('S09!AK9:AM9'), 45, 0.5)
# mechanism
chk('S01-C WT', num('S01!B20:E20').mean(), 43.1, 0.05); chk('S01-C SPA/D', num('S01!B21:E21').mean(), 12.7, 0.05)
chk('S11-C CBX-', num('S11!B17:B21').mean(), 7.3, 0.05); chk('S11-C CBX+', num('S11!A17:A21').mean(), 3.1, 0.05)
chk('S02-H WT w/o', num('S02!B30:B34').mean(), 19.7, 0.05); chk('S02-H IFN w/o', num('S02!D30:D34').mean(), 2.1, 0.05); chk('S02-H GMCSF', num('S02!F30:F34').mean(), 12.4, 0.05)
chk('S02-G PSLN-212', num('S02!C22:C26').mean(), 5.9, 0.05); chk('S02-G +GM-CSF', num('S02!D22:D26').mean(), 13.8, 0.05)
chk('S05-C lung', num('S05!A13:A15').mean(), 59.0, 0.05); chk('S05-C lung+PTX', num('S05!B13:B15').mean(), 55.1, 0.05); chk('S05-C MLN', num('S05!C13:C15').mean(), 30.9, 0.05); chk('S05-C MLN+PTX', num('S05!D13:D15').mean(), 6.8, 0.05)
chk('S07-A d5 PSLN-212', num('S07!B5:D5').mean(), 19.0, 0.05); chk('S07-A d5 PSLN-344', num('S07!E5:G5').mean(), 3.4, 0.05)
print(f'\n{sum(checks)}/{len(checks)} spot-checks agree with the memo')

import json, itertools
B = json.load(open('blocks.json'))
SURV = [k for k, b in B.items() if b['kind'] == 'survival']
def sig(bid, g):
    return tuple(sorted((r['day'] if r['day'] is not None else -1, r['status']) for r in B[bid]['groups'][g]['records']))
print('Whole-block identity (all shared group labels have identical day/status multisets):')
for b1, b2 in itertools.combinations(SURV, 2):
    common = [g for g in B[b1]['order'] if g in B[b2]['order']]
    if len(common) >= 3:
        same = [g for g in common if sig(b1, g) == sig(b2, g)]
        with_events_same = [g for g in same if any(s == 1 for _, s in sig(b1, g))]
        if len(same) == len(common):
            print(f'  {b1} == {b2}: identical in all {len(common)} shared groups {common}')
        elif len(with_events_same) >= 1:
            print(f'  {b1} vs {b2}: identical event patterns in groups with deaths: {with_events_same} (of shared {common})')

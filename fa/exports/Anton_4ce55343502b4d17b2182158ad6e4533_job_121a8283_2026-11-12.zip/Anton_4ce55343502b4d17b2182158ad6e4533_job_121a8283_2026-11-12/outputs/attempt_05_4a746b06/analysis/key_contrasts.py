import pandas as pd, numpy as np
pd.set_option('display.width', 260); pd.set_option('display.max_rows', 1000)
R = pd.read_csv('immuno_summary.csv'); T = pd.read_csv('immuno_tests.csv')
def norm(g): return g.replace('PSLN-212Y','PSLN-212(Y)').replace('PSLN-212(y)','PSLN-212(Y)')
R['g'] = R.group.map(norm); T['g1n'] = T.g1.map(norm); T['g2n'] = T.g2.map(norm)
out = []
for blk, sub in R.groupby('block', sort=False):
    d = sub.set_index('g')
    if not {'PSLN-212','PSLN-344'}.issubset(d.index): continue
    row = dict(block=blk, scale=d.scale.iloc[0])
    for g in ['Sham','PBS','Vaccine','PSLN-212','PSLN-344','PSLN-212(Y)']:
        if g in d.index: row[g] = d.loc[g,'center']
    logscale = d.scale.iloc[0] in ('titre','fold','log10fold')
    def tst(a, b):
        t = T[(T.block==blk) & (((T.g1n==a)&(T.g2n==b)) | ((T.g1n==b)&(T.g2n==a)))]
        if len(t)==0: return (np.nan, np.nan)
        return (t.p_tukey.iloc[0], t.p_welch.iloc[0])
    a, m = d.loc['PSLN-212','center'], d.loc['PSLN-344','center']
    row['344_vs_212'] = (m/a) if logscale else (m-a)
    row['p_tukey_344v212'], row['p_welch_344v212'] = tst('PSLN-212','PSLN-344')
    if 'PSLN-212(Y)' in d.index:
        y = d.loc['PSLN-212(Y)','center']
        row['344_vs_Y'] = (m/y) if logscale else (m-y)
        row['p_tukey_344vY'], row['p_welch_344vY'] = tst('PSLN-344','PSLN-212(Y)')
        row['p_tukey_212vY'], _ = tst('PSLN-212','PSLN-212(Y)')
        if logscale:
            row['restoration'] = (np.log10(m)-np.log10(a))/(np.log10(y)-np.log10(a)) if y != a else np.nan
        else:
            row['restoration'] = (m-a)/(y-a) if y != a else np.nan
    out.append(row)
K = pd.DataFrame(out)
K.to_csv('key_contrasts.csv', index=False)
cols = ['block','scale','Sham','PSLN-212','PSLN-344','PSLN-212(Y)','344_vs_212','p_tukey_344v212','p_welch_344v212','344_vs_Y','p_tukey_344vY','p_welch_344vY','p_tukey_212vY','restoration']
print(K[[c for c in cols if c in K.columns]].to_string(index=False, float_format=lambda x: f'{x:.3g}'))

import os
"""
Parse every block of adjuvant_program_dataset.xlsx into tidy structures.
Every block is addressed by explicit cell ranges (taken from the workbook + annotation PDF),
so each number can be traced back to sheet/cell.
Output: blocks.json
"""
import json, openpyxl
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI

WB = openpyxl.load_workbook(os.environ.get('PSLN_WORKBOOK', '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'), data_only=True)
blocks = {}

def cell(ws, r, c):
    return WB[ws].cell(r, c).value

def rng(ws, r, c0, c1):
    """values in row r from col c0..c1 (letters), keeping None"""
    return [cell(ws, r, c) for c in range(CI(c0), CI(c1)+1)]

def colvals(ws, c, r0, r1):
    return [cell(ws, r, CI(c)) for r in range(r0, r1+1)]

def add(bid, **kw):
    assert bid not in blocks, bid
    blocks[bid] = kw

# ---------- helpers for the 4 layouts ----------
def cols_block(bid, ws, hdr_row, c0, c1, r0, r1, **meta):
    """one group per column; header in hdr_row"""
    groups = {}
    order = []
    for c in range(CI(c0), CI(c1)+1):
        name = cell(ws, hdr_row, c)
        vals = [cell(ws, r, c) for r in range(r0, r1+1)]
        key = name
        # duplicate header labels (S07-C) are kept distinct by column letter
        if key in groups:
            key = f'{name} [col {L(c)}]'
            first = order[0]
        groups[key] = dict(values=vals, cells=f'{ws}!{L(c)}{r0}:{L(c)}{r1}')
        order.append(key)
    add(bid, kind='groups', sheet=ws, groups=groups, order=order, **meta)

def rows_block(bid, ws, name_col, c0, c1, r0, r1, **meta):
    """one group per row; name in name_col"""
    groups = {}; order = []
    for r in range(r0, r1+1):
        name = cell(ws, r, CI(name_col))
        groups[name] = dict(values=rng(ws, r, c0, c1), cells=f'{ws}!{c0}{r}:{c1}{r}')
        order.append(name)
    add(bid, kind='groups', sheet=ws, groups=groups, order=order, **meta)

def tc_block(bid, ws, hdr_row, time_col, spans, r0, r1, kind='timecourse', names=None, **meta):
    """time course: rows are timepoints, each group spans several columns (one per animal)"""
    times = [cell(ws, r, CI(time_col)) for r in range(r0, r1+1)]
    groups = {}; order = []
    for i, (c0, c1) in enumerate(spans):
        name = names[i] if names else cell(ws, hdr_row, CI(c0))
        name = name.strip() if isinstance(name, str) else name
        mat = [rng(ws, r, c0, c1) for r in range(r0, r1+1)]   # rows=time, cols=animal
        groups[name] = dict(matrix=mat, cells=f'{ws}!{c0}{r0}:{c1}{r1}')
        order.append(name)
    add(bid, kind=kind, sheet=ws, times=times, groups=groups, order=order, **meta)

def surv_block(bid, ws, hdr_row, day_col, c0, c1, r0, r1, **meta):
    """Prism-style survival table: day in day_col; one column per group holding 1 (event) / 0 (censored)"""
    groups = {}; order = []
    for c in range(CI(c0), CI(c1)+1):
        name = cell(ws, hdr_row, c)
        recs = []
        for r in range(r0, r1+1):
            st = cell(ws, r, c)
            if st is not None:
                recs.append(dict(day=cell(ws, r, CI(day_col)), status=st, row=r))
        groups[name] = dict(records=recs, cells=f'{ws}!{L(c)}{r0}:{L(c)}{r1} (days in {day_col})')
        order.append(name)
    add(bid, kind='survival', sheet=ws, groups=groups, order=order, **meta)

# ================= S01 =================
rows_block('S01-A_16h', 'S01', 'A', 'B', 'F', 3, 10, stated_n=5, measurand='Ifnb1 lung qPCR, fold vs untreated, 16 h, NP alone', scale='fold')
rows_block('S01-A_72h', 'S01', 'G', 'H', 'L', 3, 10, stated_n=5, measurand='Ifnb1 lung qPCR, fold vs untreated, 72 h, NP alone', scale='fold')
rows_block('S01-B', 'S01', 'A', 'B', 'F', 14, 17, stated_n=5, measurand='% SRB+ alveolar epithelial cells 16 h (aged)', scale='pct')
rows_block('S01-C', 'S01', 'A', 'B', 'E', 20, 21, stated_n=4, measurand='% DiD+ alveolar macrophages 16 h', scale='pct')
tc_block('S01-D', 'S01', 23, 'A', [('B','F'),('G','K'),('L','P'),('Q','U')], 24, 28, stated_n=5, measurand='lung monocytes % (CA09 vaccine)', scale='pct')
tc_block('S01-E', 'S01', 29, 'A', [('B','F'),('G','K'),('L','P'),('Q','U'),('V','Z')], 30, 34, stated_n=5, measurand='lung CD11b+ DC %', scale='pct')
tc_block('S01-F', 'S01', 35, 'A', [('B','F'),('G','K'),('L','P'),('Q','U'),('V','Z')], 36, 36, stated_n=5, measurand='lung cDC1 % 72 h', scale='pct')
tc_block('S01-G', 'S01', 37, 'A', [('B','F'),('G','K'),('L','P'),('Q','U'),('V','Z')], 38, 38, stated_n=5, measurand='lung cDC2 % 72 h', scale='pct')
# ================= S02 =================
cols_block('S02-A', 'S02', 2, 'A', 'D', 3, 7, stated_n=5, measurand='lung migratory CCR7+ CD11b+ DC % 72 h', scale='pct')
cols_block('S02-B', 'S02', 2, 'F', 'I', 3, 7, stated_n=5, measurand='MLN CD11b+CD103- DC % 72 h', scale='pct')
cols_block('S02-C', 'S02', 2, 'K', 'O', 3, 7, stated_n=5, measurand='MLN OVA-AF647+ DC % 36 h', scale='pct')
cols_block('S02-D_CD40', 'S02', 9, 'A', 'D', 10, 14, stated_n=5, measurand='CD40+ of MLN CD11b+ DC % d3', scale='pct')
cols_block('S02-D_CD86', 'S02', 9, 'F', 'I', 10, 14, stated_n=5, measurand='CD86+ of MLN CD11b+ DC % d3', scale='pct')
cols_block('S02-E', 'S02', 9, 'K', 'O', 10, 14, stated_n=5, measurand='OT-I proliferation % (co-culture with MLN CD11b+ DC)', scale='pct')
tc_block('S02-F', 'S02', 16, 'A', [('B','F'),('G','K'),('L','P')], 17, 19, stated_n=5, measurand='Gm-csf lung qPCR fold', scale='fold')
cols_block('S02-G', 'S02', 21, 'B', 'D', 22, 26, stated_n=5, measurand='lung Ly6C+CD11c+MHCII+ moDC % d5', scale='pct')
cols_block('S02-H', 'S02', 29, 'B', 'F', 30, 34, stated_n=5, measurand='CD45.2+ moDC % d3 (BM transfer)', scale='pct')
cols_block('S02-I', 'S02', 29, 'H', 'I', 30, 34, stated_n=5, measurand='lung GZMB+ CD8 % d5 (young, +/- INCB3344)', scale='pct')
# ================= S03 =================
cols_block('S03-A', 'S03', 2, 'A', 'E', 3, 7, stated_n=5, measurand='serum IgG anti-CA09 H1N1 endpoint titre d14', scale='titre')
cols_block('S03-B', 'S03', 2, 'G', 'I', 3, 7, stated_n=5, measurand='IgG2a/IgG1 quotient anti-CA09 d14 (as printed)', scale='ratio')
cols_block('S03-C', 'S03', 2, 'K', 'O', 3, 7, stated_n=5, measurand='HAI anti-CA09 d14 (lowest dilution 1:10)', scale='titre', lod=10)
cols_block('S03-D', 'S03', 2, 'Q', 'U', 3, 7, stated_n=5, measurand='neutralising titre anti-CA09 d14', scale='titre')
cols_block('S03-E', 'S03', 9, 'A', 'E', 10, 14, stated_n=5, measurand='serum IgG anti-Aichi H3N2 endpoint titre d14', scale='titre')
cols_block('S03-F', 'S03', 9, 'G', 'I', 10, 14, stated_n=5, measurand='IgG2a/IgG1 quotient anti-Aichi d14 (as printed)', scale='ratio')
cols_block('S03-G', 'S03', 9, 'K', 'O', 10, 14, stated_n=5, measurand='HAI anti-Aichi d14 (lowest dilution 1:10)', scale='titre', lod=10)
cols_block('S03-H', 'S03', 9, 'Q', 'U', 10, 14, stated_n=5, measurand='neutralising titre anti-Aichi d14', scale='titre')
surv_block('S03-I', 'S03', 16, 'A', 'B', 'F', 17, 51, stated_n=7, measurand='survival, aged BALB/c, bivalent vaccine, 10x mLD50 CA09 H1N1 at d14 (homologous)')
surv_block('S03-J', 'S03', 16, 'G', 'H', 'J', 17, 46, stated_n=9, measurand='survival, rgH5N1 vaccine single dose, WT VN04 H5N1 at d2')
cols_block('S03-K', 'S03', 16, 'L', 'O', 17, 21, stated_n=5, measurand='MLN GC B cells % d7', scale='pct')
rows_block('S03-L_Aicda', 'S03', 'K', 'L', 'N', 26, 28, stated_n=3, measurand='Aicda MLN B cell qPCR fold d5', scale='fold')
rows_block('S03-L_E47', 'S03', 'K', 'O', 'Q', 26, 28, stated_n=3, measurand='E47 MLN B cell qPCR fold d5', scale='fold')
# ================= S04 =================
rows_block('S04-A_ICOSlo', 'S04', 'A', 'B', 'F', 2, 5, stated_n=5, measurand='MLN Tfh ICOS-low % d7', scale='pct')
rows_block('S04-A_ICOShi', 'S04', 'A', 'G', 'K', 2, 5, stated_n=5, measurand='MLN Tfh ICOS-high % d7', scale='pct')
cols_block('S04-B_Foxp3', 'S04', 7, 'A', 'D', 8, 12, stated_n=5, measurand='MLN Tfr (Foxp3+ in CXCR5+) % d7', scale='pct')
cols_block('S04-B_TfhTfr', 'S04', 14, 'A', 'D', 15, 19, stated_n=5, measurand='Tfh:Tfr quotient d7 (as printed)', scale='ratio')
cols_block('S04-C', 'S04', 21, 'A', 'D', 22, 26, stated_n=5, measurand='MLN Tfr % d30', scale='pct')
cols_block('S04-D', 'S04', 28, 'A', 'D', 29, 31, stated_n=3, measurand='lung Treg % d7', scale='pct')
# ================= S05 =================
tc_block('S05-A', 'S05', 2, 'A', [('B','C'),('E','F'),('H','I')], 3, 5, stated_n=3, measurand='lung NP366-374 tetramer+ of CD8 %', scale='pct')
tc_block('S05-B', 'S05', 7, 'A', [('B','C'),('E','F'),('H','I')], 8, 10, stated_n=3, measurand='MLN NP366-374 tetramer+ of CD8 %', scale='pct')
cols_block('S05-C', 'S05', 12, 'A', 'D', 13, 15, stated_n=3, measurand='proliferating OT-I % d4 (+/- PTX)', scale='pct')
cols_block('S05-D', 'S05', 18, 'A', 'D', 19, 23, stated_n=5, measurand='lung Ki67+ CD8 % d3', scale='pct')
cols_block('S05-E', 'S05', 25, 'A', 'D', 26, 30, stated_n=5, measurand='lung GZMB+ CD8 % d3', scale='pct')
cols_block('S05-F', 'S05', 32, 'A', 'D', 33, 37, stated_n=5, measurand='MLN IFNg+ CD8 % d14 (rgH5N1 restim)', scale='pct')
cols_block('S05-G', 'S05', 39, 'A', 'D', 40, 44, stated_n=5, measurand='MLN IFNg+ CD8 % d60 (rgH5N1 restim)', scale='pct')
cols_block('S05-H', 'S05', 46, 'A', 'D', 47, 51, stated_n=5, measurand='MLN GZMB+ CD8 % d60', scale='pct')
cols_block('S05-I', 'S05', 53, 'A', 'D', 54, 58, stated_n=5, measurand='lung CD8 TRM % d25', scale='pct')
# ================= S06 =================
surv_block('S06-A', 'S06', 2, 'A', 'B', 'E', 3, 30, stated_n=7, measurand='Aichi H3N2 vaccine -> 5x mLD50 PR8 H1N1 at d14')
surv_block('S06-B', 'S06', 2, 'G', 'H', 'K', 3, 30, stated_n=7, measurand='Aichi H3N2 vaccine -> 5x mLD50 PR8 H1N1 at d3')
surv_block('S06-C', 'S06', 2, 'M', 'N', 'Q', 3, 30, stated_n=7, measurand='bivalent vaccine -> 5x mLD50 rgH5N1 at d14')
surv_block('S06-D', 'S06', 33, 'A', 'B', 'E', 34, 61, stated_n=7, measurand='bivalent vaccine -> 5x mLD50 rgH5N1 at d3')
surv_block('S06-E_r34', 'S06', 33, 'G', 'H', 'L', 34, 68, stated_n=7, measurand='Aichi H3N2 vaccine -> 5x mLD50 PR8 H1N1 at d60')
surv_block('S06-F_r34', 'S06', 33, 'M', 'N', 'R', 34, 68, stated_n=7, measurand='bivalent vaccine -> 5x mLD50 rgH5N1 at d60')
surv_block('S06-G', 'S06', 70, 'A', 'B', 'F', 71, 105, stated_n=7, measurand='CA09 H1N1 vaccine -> 5x mLD50 Perth H3N2 at d60')
surv_block('S06-E_r71', 'S06', 70, 'G', 'H', 'K', 71, 98, stated_n=7, measurand='imprinting (PR8 at 10 mo) -> bivalent vaccine 4 mo later -> 5x LD50 PR8 H1N1')
surv_block('S06-F_r71', 'S06', 70, 'M', 'N', 'Q', 71, 98, stated_n=7, measurand='imprinting -> bivalent vaccine -> 5x LD50 Perth H3N2 at d14')
# ================= S07 =================
tc_block('S07-A', 'S07', 2, 'A', [('B','D'),('E','G')], 3, 7, stated_n=3, measurand='lung Ly6C+CCR2+ macrophages (x10^5 cells)', scale='count')
cols_block('S07-B_mono', 'S07', 9, 'B', 'C', 10, 14, stated_n=5, measurand='lung CD11b+Ly6C+ monocytes % (+/- INCB3344)', scale='pct')
cols_block('S07-B_mac', 'S07', 9, 'E', 'F', 10, 14, stated_n=5, measurand='lung Ly6C+ macrophages % (+/- INCB3344)', scale='pct')
cols_block('S07-C', 'S07', 15, 'B', 'C', 16, 20, stated_n=5, measurand='lung Treg % d4 after macrophage transfer (both columns carry the same header)', scale='pct')
# ================= S08 =================
tc_block('S08-A', 'S08', 2, 'A', [('B','D'),('E','G'),('H','J'),('K','M')], 3, 7, stated_n=3, measurand='Ifnb1 lung qPCR fold 16 h, dose response (1-40 ug)', scale='fold')
tc_block('S08-B', 'S08', 10, 'A', [('A','C'),('D','F'),('G','I'),('J','L'),('M','O')], 11, 11, stated_n=3, measurand='encapsulation efficiency %', scale='pct')
cols_block('S08-C', 'S08', 13, 'A', 'D', 14, 18, stated_n=5, measurand='% SRB+ AEC 16 h, PSLN-SRB vs PSLN-344-SRB', scale='pct')
tc_block('S08-D', 'S08', 20, 'A', [('B','F'),('G','K'),('L','P'),('Q','U'),('V','Z'),('AA','AE')], 21, 26, kind='weights', stated_n=5, measurand='body weight % of d0 after immunisation (CA09 vaccine + adjuvant)', scale='pct_bw')
add('S08-unlabelled', kind='raw', sheet='S08', cells='S08!A89:D101',
    data=[dict(row=r, A=cell('S08', r, 1), B=cell('S08', r, 2), C=cell('S08', r, 3), D=cell('S08', r, 4)) for r in range(89, 102)],
    measurand='NOT STATED (no header, no group names)')
# ================= S09 =================
def s09a(bid, c0list, label):
    ws = 'S09'; groups = {}; order = []
    names = ['PBS','CMP-204','PSLN-212','PSLN-R848','PSLN-212/R848','PSLN-344','PSLN-212(y)']
    analytes = [cell(ws, r, CI('A')) for r in range(3, 10)]
    for nm, c0 in zip(names, c0list):
        hdr = cell(ws, 2, CI(c0)); assert hdr == nm, (hdr, nm)
        c1 = L(CI(c0)+2)
        groups[nm] = dict(matrix=[rng(ws, r, c0, c1) for r in range(3, 10)], cells=f'{ws}!{c0}3:{c1}9')
        order.append(nm)
    add(bid, kind='analytes', sheet=ws, analytes=analytes, groups=groups, order=order, stated_n=3, measurand=label, scale='log10fold')
s09a('S09-A_panel1', ['B','E','H','K','N','Q','T'], 'lung cytokine qPCR log10 fold, label "16h" (cols A-U)')
s09a('S09-A_panel2', ['Y','AB','AE','AH','AK','AN','AQ'], 'lung cytokine qPCR log10 fold, label "16h" (cols X-AS)')
surv_block('S09-B', 'S09', 11, 'A', 'B', 'D', 12, 35, stated_n=8, measurand='young BALB/c, Aichi vaccine -> 5x mLD50 PR8 at d21')
tc_block('S09-C', 'S09', 11, 'F', [('G','N'),('O','V'),('W','AD')], 12, 19, kind='weights', stated_n=8, measurand='body weight, animals of S09-B', scale='pct_bw')
surv_block('S09-D', 'S09', 38, 'A', 'B', 'D', 39, 62, stated_n=8, measurand='young BALB/c, CA09 vaccine -> 5x mLD50 Perth H3N2 at d21')
tc_block('S09-E', 'S09', 38, 'F', [('G','N'),('O','V'),('W','AD')], 39, 46, kind='weights', stated_n=8, measurand='body weight, animals of S09-D', scale='pct_bw')
surv_block('S09-F', 'S09', 65, 'A', 'B', 'D', 66, 88, stated_n=8, measurand='young BALB/c, bivalent vaccine -> 5x mLD50 rgH5N1 at d180')
tc_block('S09-G', 'S09', 65, 'F', [('G','N'),('O','V'),('W','AD')], 66, 73, kind='weights', stated_n=8, measurand='body weight, animals of S09-F', scale='pct_bw')
# ================= S10 =================
cols_block('S10-A_Ifnb1', 'S10', 2, 'A', 'D', 3, 7, stated_n=5, measurand='CNS Ifnb1 qPCR fold 36 h', scale='fold')
cols_block('S10-A_Tnf', 'S10', 2, 'F', 'I', 3, 7, stated_n=5, measurand='CNS Tnf qPCR fold 36 h', scale='fold')
cols_block('S10-A_Isg15', 'S10', 2, 'K', 'N', 3, 7, stated_n=5, measurand='CNS Isg15 qPCR fold 36 h', scale='fold')
# ================= S11 =================
sp4 = [('B','F'),('G','K'),('L','P'),('Q','U')]
tc_block('S11-A', 'S11', 2, 'A', sp4, 3, 7, stated_n=5, measurand='lung alveolar macrophages %', scale='pct')
tc_block('S11-B', 'S11', 9, 'A', sp4, 10, 14, stated_n=5, measurand='lung neutrophils %', scale='pct')
cols_block('S11-C', 'S11', 16, 'A', 'B', 17, 21, stated_n=5, measurand='recruited lung monocytes % d3 +/- CBX (PSLN-344)', scale='pct')
tc_block('S11-D', 'S11', 23, 'A', sp4, 24, 28, stated_n=5, measurand='lung NK cells %', scale='pct')
cols_block('S11-E', 'S11', 30, 'A', 'D', 31, 35, stated_n=5, measurand='lung CD206+ macrophages %', scale='pct')
# ================= S12 =================
cols_block('S12-A', 'S12', 2, 'A', 'B', 3, 5, stated_n=3, measurand='infiltrating CD45.2+ monocytes % d3 (BM transfer, young)', scale='pct')
# ================= S13 =================
cols_block('S13-A', 'S13', 2, 'A', 'C', 3, 7, stated_n=5, measurand='serum IgG2a anti-CA09 titre d14', scale='titre')
cols_block('S13-B', 'S13', 2, 'E', 'G', 3, 7, stated_n=5, measurand='serum IgG1 anti-CA09 titre d14', scale='titre')
cols_block('S13-C', 'S13', 2, 'I', 'K', 3, 7, stated_n=5, measurand='serum IgG2a anti-Aichi titre d14', scale='titre')
cols_block('S13-D', 'S13', 2, 'M', 'O', 3, 7, stated_n=5, measurand='serum IgG1 anti-Aichi titre d14', scale='titre')
surv_block('S13-E', 'S13', 2, 'R', 'S', 'V', 3, 30, stated_n=5, measurand='young BALB/c, 10x mLD50 CA09 at d14')
tc_block('S13-F', 'S13', 32, 'A', [('B','H'),('I','O'),('P','V'),('W','AC'),('AD','AJ')], 33, 40, kind='weights', stated_n=7, measurand='body weight, "animals of S03-I"', scale='pct_bw')
tc_block('S13-G', 'S13', 42, 'A', [('B','K'),('L','U'),('V','AE')], 43, 50, kind='weights', stated_n=10, measurand='body weight, "animals of S03-J"', scale='pct_bw')
cols_block('S13-H', 'S13', 52, 'A', 'D', 53, 57, stated_n=5, measurand='IgG+ of MLN B220+ cells % (timepoint not stated)', scale='pct')
cols_block('S13-I', 'S13', 52, 'F', 'J', 53, 57, stated_n=5, measurand='serum IgG anti-CA09 titre d28 (boost d14)', scale='titre')
cols_block('S13-J', 'S13', 52, 'L', 'P', 53, 57, stated_n=5, measurand='serum IgG anti-Aichi titre d28 (boost d14)', scale='titre')
# ================= S14 =================
cols_block('S14-A_H1N1', 'S14', 2, 'A', 'D', 3, 7, stated_n=5, measurand='MLN IFNg+ CD8 % (CA09 restim; timepoint not stated)', scale='pct')
cols_block('S14-A_H3N2', 'S14', 2, 'F', 'I', 3, 7, stated_n=5, measurand='MLN IFNg+ CD8 % (Aichi restim; timepoint not stated)', scale='pct')
# ================= S15 =================
w4 = [('B','H'),('I','O'),('P','V'),('W','AC')]
w5 = w4 + [('AD','AJ')]
for lab, hdr, spans, meas in [
    ('S15-A', 2, w4, 'BW: Aichi vaccine -> PR8 d14 (pairs with S06-A)'),
    ('S15-B', 12, w4, 'BW: Aichi vaccine -> PR8 d3 (pairs with S06-B)'),
    ('S15-C', 22, w4, 'BW: bivalent -> rgH5N1 d14 (pairs with S06-C)'),
    ('S15-D', 32, w4, 'BW: bivalent -> rgH5N1 d3 (pairs with S06-D)'),
    ('S15-E', 42, w5, 'BW: Aichi vaccine -> PR8 d60 (pairs with S06-E rows 34-68)'),
    ('S15-F', 52, w5, 'BW: bivalent -> rgH5N1 d60 (pairs with S06-F rows 34-68)'),
    ('S15-G', 62, w5, 'BW: CA09 vaccine -> Perth H3N2 d60 (pairs with S06-G)')]:
    tc_block(lab, 'S15', hdr, 'A', spans, hdr+1, hdr+8, kind='weights', stated_n=7, measurand=meas, scale='pct_bw')
surv_block('S15-H', 'S15', 72, 'A', 'B', 'D', 73, 93, stated_n=7, measurand='aged; vaccine alone / PSLN-344 alone / both, 3 d before 5x mLD50 rgH5N1')
wI = [('I','O'),('P','V'),('W','AC')]
tc_block('S15-I', 'S15', 71, 'H', wI, 72, 79, kind='weights', stated_n=7, measurand='BW: animals of S15-H', scale='pct_bw')
wJ = [('I','O'),('P','V'),('W','AC'),('AD','AJ')]
tc_block('S15-J', 'S15', 82, 'H', wJ, 83, 90, kind='weights', stated_n=7, measurand='BW: imprinting -> PR8 (pairs with S06-E rows 71-105)', scale='pct_bw')
tc_block('S15-K', 'S15', 92, 'H', wJ, 93, 100, kind='weights', stated_n=7, measurand='BW: imprinting -> Perth (pairs with S06-F rows 71-105)', scale='pct_bw')
surv_block('S15-L', 'S15', 102, 'A', 'B', 'E', 103, 130, stated_n=7, measurand='aged C57BL/6 (20 mo), bivalent vaccine; challenge virus not stated')
tc_block('S15-M', 'S15', 102, 'H', wJ, 103, 110, kind='weights', stated_n=7, measurand='BW: animals of S15-L (C57BL/6)', scale='pct_bw')
surv_block('S15-N', 'S15', 133, 'A', 'B', 'E', 134, 161, stated_n=7, measurand='aged Swiss Webster (20 mo), bivalent vaccine; challenge virus not stated')
tc_block('S15-O', 'S15', 133, 'H', wJ, 134, 141, kind='weights', stated_n=7, measurand='BW: animals of S15-N (Swiss Webster)', scale='pct_bw')

json.dump(blocks, open('blocks.json', 'w'), indent=1, default=str)
print(len(blocks), 'blocks parsed')

# ---------- coverage check: every numeric cell in the workbook must belong to a parsed block ----------
import re
covered = {ws.title: set() for ws in WB.worksheets}
def mark(ws, a1):
    m = re.match(r'([A-Z]+)(\d+):([A-Z]+)(\d+)', a1)
    c0, r0, c1, r1 = CI(m.group(1)), int(m.group(2)), CI(m.group(3)), int(m.group(4))
    for r in range(r0, r1+1):
        for c in range(c0, c1+1):
            covered[ws].add((r, c))
for bid, b in blocks.items():
    ws = b['sheet']
    if b['kind'] == 'raw':
        mark(ws, b['cells'].split('!')[1]); continue
    for g in b['groups'].values():
        ref = g['cells'].split('!')[1].split(' ')[0]
        mark(ws, ref)
    if b['kind'] == 'survival':
        # day column
        for g in b['groups'].values():
            m = re.search(r'days in ([A-Z]+)', g['cells']); dc = CI(m.group(1))
            ref = g['cells'].split('!')[1].split(' ')[0]
            mm = re.match(r'([A-Z]+)(\d+):([A-Z]+)(\d+)', ref)
            for r in range(int(mm.group(2)), int(mm.group(4))+1): covered[ws].add((r, dc))
    if b['kind'] in ('timecourse','weights'):
        pass
unc = []
for ws in WB.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, (int, float)) and (c.row, c.column) not in covered[ws.title]:
                unc.append((ws.title, c.coordinate, c.value))
print('numeric cells not inside any parsed group range (expected: time/dose axis cells only):')
from collections import defaultdict
d = defaultdict(list)
for s, co, v in unc: d[s].append(f'{co}={v}')
for s, lst in d.items(): print(' ', s, len(lst), lst[:60])

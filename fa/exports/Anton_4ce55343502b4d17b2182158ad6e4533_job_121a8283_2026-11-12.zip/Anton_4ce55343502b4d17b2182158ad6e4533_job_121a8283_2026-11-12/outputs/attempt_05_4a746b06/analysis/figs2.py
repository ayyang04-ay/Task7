import json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
B = json.load(open('blocks.json'))
import os
OUT = os.environ.get('PSLN_FIGDIR', '/tmp/outputs/figures/')
os.makedirs(OUT, exist_ok=True)
COL = {'Sham': '#8c8c8c', 'PSLN-212': '#e6862a', 'PSLN-344': '#1f5fa8', 'PSLN-212(Y)': '#3a9a5c', 'PSLN-344(Y)': '#7fc8a0', 'CMP-204': '#c9a227', 'PSLN-R848': '#b07cc6', 'PSLN-212/R848': '#b24a4a', 'Vaccine': '#8c8c8c', 'PBS': '#8c8c8c', 'PSLN-344/R848': '#b24a4a', 'CT': '#b24a4a'}
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})
def V(bid, g, ti=None):
    b = B[bid]
    v = b['groups'][g]['values'] if b['kind'] == 'groups' else b['groups'][g]['matrix'][ti]
    return np.array([x for x in v if x is not None], float)

# ------------- Figure 2: fraction of age gap closed -------------
items = [  # (label, block, ti, log?, lod, category)
 ('Lung Ifnb1, 16 h [S01-A]', 'S01-A_16h', None, True, None, 'Innate'),
 ('Lung monocytes, d4 [S01-D]', 'S01-D', 2, False, None, 'Innate'),
 ('Lung CD11b+ DC, d4 [S01-E]', 'S01-E', 2, False, None, 'Innate'),
 ('Lung cDC1, 72 h [S01-F]', 'S01-F', 0, False, None, 'Innate'),
 ('Lung migratory CCR7+ DC, 72 h [S02-A]', 'S02-A', None, False, None, 'Innate'),
 ('MLN CD11b+ DC, 72 h [S02-B]', 'S02-B', None, False, None, 'Innate'),
 ('MLN antigen+ DC, 36 h [S02-C]', 'S02-C', None, False, None, 'Innate'),
 ('DC priming of OT-I ex vivo [S02-E]', 'S02-E', None, False, None, 'Innate'),
 ('CD40+ MLN DC, d3 [S02-D]', 'S02-D_CD40', None, False, None, 'Innate'),
 ('CD86+ MLN DC, d3 [S02-D]', 'S02-D_CD86', None, False, None, 'Innate'),
 ('Lung CD206+ macrophages (fall) [S11-E]', 'S11-E', None, False, None, 'Innate'),
 ('Lung alveolar macrophages, d4 [S11-A]', 'S11-A', 2, False, None, 'Innate'),
 ('Lung Ki67+ CD8, d3 [S05-D]', 'S05-D', None, False, None, 'T cell'),
 ('Lung GZMB+ CD8, d3 [S05-E]', 'S05-E', None, False, None, 'T cell'),
 ('IFNg+ CD8 to rgH5N1, d14 [S05-F]', 'S05-F', None, False, None, 'T cell'),
 ('IFNg+ CD8 to rgH5N1, d60 [S05-G]', 'S05-G', None, False, None, 'T cell'),
 ('GZMB+ CD8, d60 [S05-H]', 'S05-H', None, False, None, 'T cell'),
 ('Lung CD8 TRM, d25 [S05-I]', 'S05-I', None, False, None, 'T cell'),
 ('Lung Treg, d7 (fall) [S04-D]', 'S04-D', None, False, None, 'T cell'),
 ('Serum IgG, CA09 [S03-A]', 'S03-A', None, True, None, 'Antibody'),
 ('Serum IgG, Aichi [S03-E]', 'S03-E', None, True, None, 'Antibody'),
 ('HAI, CA09 [S03-C]', 'S03-C', None, True, 10, 'Antibody'),
 ('HAI, Aichi [S03-G]', 'S03-G', None, True, 10, 'Antibody'),
 ('Neutralising, CA09 [S03-D]', 'S03-D', None, True, None, 'Antibody'),
 ('Neutralising, Aichi [S03-H]', 'S03-H', None, True, None, 'Antibody'),
 ('IgG2a, CA09 [S13-A]', 'S13-A', None, True, None, 'Antibody'),
 ('IgG1, CA09 [S13-B]', 'S13-B', None, True, None, 'Antibody'),
 ('GC B cells, d7 [S03-K]', 'S03-K', None, False, None, 'Antibody'),
 ('Tfh ICOS-high, d7 [S04-A]', 'S04-A_ICOShi', None, False, None, 'Antibody'),
 ('Tfr, d7 (fall) [S04-B]', 'S04-B_Foxp3', None, False, None, 'Antibody'),
 ('Tfr, d30 (fall) [S04-C]', 'S04-C', None, False, None, 'Antibody'),
]
rows = []
rng = np.random.default_rng(1)
for lab, bid, ti, log, lod, cat in items:
    def tr(g):
        x = V(bid, g, ti)
        if lod: x = np.where(x < lod, lod/2, x)
        return np.log10(x) if log else x
    a, m, y = tr('PSLN-212'), tr('PSLN-344'), tr('PSLN-212(Y)')
    r = (m.mean() - a.mean()) / (y.mean() - a.mean())
    # bootstrap CI (resample animals within group)
    bs = []
    for _ in range(4000):
        aa, mm, yy = rng.choice(a, len(a)), rng.choice(m, len(m)), rng.choice(y, len(y))
        d = yy.mean() - aa.mean()
        if abs(d) > 1e-9: bs.append((mm.mean() - aa.mean()) / d)
    lo, hi = np.percentile(bs, [2.5, 97.5])
    rows.append((lab, cat, r, lo, hi))
R = pd.DataFrame(rows, columns=['label', 'categ', 'r', 'lo', 'hi'])
R.to_csv('restoration_index.csv', index=False)
fig, ax = plt.subplots(figsize=(8.2, 8.4))
catcol = {'Innate': '#5b7fa6', 'T cell': '#a65b7f', 'Antibody': '#7fa65b'}
yy = np.arange(len(R))[::-1]
for y_, (_, r) in zip(yy, R.iterrows()):
    ax.plot([max(r.lo, -0.3), min(r.hi, 1.6)], [y_, y_], color=catcol[r.categ], lw=1.2, alpha=0.6)
    ax.scatter(r.r, y_, color=catcol[r.categ], s=42, zorder=3)
ax.plot([0, 0], [-0.8, len(R) - 0.35], color='#e6862a', lw=1.2); ax.plot([1, 1], [-0.8, len(R) - 0.35], color='#3a9a5c', lw=1.2)
ax.text(0, len(R) - 0.2, 'aged + PSLN-212\n(no restoration)', ha='center', va='bottom', fontsize=8, color='#e6862a')
ax.text(1, len(R) - 0.2, 'young + PSLN-212\n(full restoration)', ha='center', va='bottom', fontsize=8, color='#3a9a5c')
ax.set_yticks(yy); ax.set_yticklabels(R.label, fontsize=8); ax.set_xlim(-0.3, 1.6); ax.set_ylim(-0.8, len(R) + 1.3)
ax.set_xlabel('Fraction of the aged-vs-young gap closed by PSLN-344 in aged animals\n(0 = same as aged PSLN-212, 1 = same as young PSLN-212; titres and Ifnb1 on log scale; bars = bootstrap 95% interval, n = 5 or 3 per arm)')
h = [Line2D([], [], marker='o', ls='', color=c, label=k) for k, c in catcol.items()]
ax.legend(handles=h, loc='lower right', frameon=False, fontsize=8)
ax.set_title('What manganese restores in the aged host, and what it does not', loc='left', fontsize=10, pad=6)
fig.tight_layout(); fig.savefig(OUT + 'fig4_age_gap_closed.png', dpi=200, bbox_inches='tight'); plt.close(fig)

# ------------- Figure 3: PD axis -------------
fig, axes = plt.subplots(1, 3, figsize=(13.2, 4.2))
ax = axes[0]
order = ['Sham', 'PSLN-R848', 'CMP-204', 'PSLN-212', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']
for i, g in enumerate(order):
    v = V('S01-A_16h', g); ax.scatter(np.full(len(v), i) + np.linspace(-0.15, 0.15, len(v)), v, color=COL[g], s=22, zorder=3)
    gmv = 10**np.log10(v).mean(); ax.plot([i - 0.28, i + 0.28], [gmv, gmv], color='k', lw=1.4)
    ax.text(i, v.max() * 1.18, f'{gmv:.3g}', ha='center', fontsize=7.5)
ax.set_yscale('log'); ax.set_xticks(range(len(order))); ax.set_xticklabels([g.replace('(Y)', ' (young)') for g in order], fontsize=7.5, rotation=32, ha='right', rotation_mode='anchor')
ax.set_ylabel('Lung Ifnb1, fold vs untreated (log scale)'); ax.set_title('a  Ifnb1 at 16 h, 20 µg, no vaccine [S01-A]\n   bar = geometric mean, n = 5', loc='left', fontsize=9)
ax.axvspan(5.5, 7.5, color='#eef6ef', zorder=0); ax.text(6.5, 0.6, 'young animals', ha='center', fontsize=8, color='#3a9a5c'); ax.set_ylim(0.5, 110)
ax = axes[1]
b = B['S08-A']; doses = np.array(b['times'], float)
for g, lab in [('CMP-204', 'CMP-204'), ('PSLN-212', 'PSLN-212'), ('PSLN-344', 'PSLN-344'), ('PSLN-344/R848', '"PSLN-344/R848" (label not defined)')]:
    m = np.array(b['groups'][g]['matrix'], float); gmv = 10**np.log10(m).mean(axis=1)
    ax.plot(doses, gmv, marker='o', color=COL[g], label=lab, lw=1.6, ms=4, ls='--' if 'R848' in g else '-')
    for j in range(3): ax.scatter(doses, m[:, j], color=COL[g], s=9, alpha=0.5)
ax.axhline(10**np.log10(V('S01-A_16h', 'PSLN-212(Y)')).mean(), color='#3a9a5c', lw=1, ls=':'); ax.text(1.05, 40.5, 'young + PSLN-212, 20 µg (37.5x) [S01-A]', color='#3a9a5c', fontsize=7.5)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xticks(doses); ax.set_xticklabels([int(d) for d in doses]); ax.set_xlabel('Dose (µg per animal)'); ax.set_ylabel('Lung Ifnb1 at 16 h, fold (log scale)')
ax.legend(frameon=False, fontsize=7.5, loc='lower right'); ax.set_title('b  Dose-response in aged lung [S08-A], n = 3 per dose\n   PSLN-212 plateaus below the young-adult response', loc='left', fontsize=9)
ax = axes[2]
b = B['S02-F']; tt = [16, 36, 72]
for g in ['Sham', 'PSLN-212', 'PSLN-344']:
    m = np.array(b['groups'][g]['matrix'], float); gmv = 10**np.log10(m).mean(axis=1)
    ax.plot(tt, gmv, '-o', color=COL[g], label=g, lw=1.6, ms=4)
    for j in range(m.shape[1]): ax.scatter(tt, m[:, j], color=COL[g], s=9, alpha=0.5)
ax.set_xticks(tt); ax.set_xlabel('Hours after immunisation'); ax.set_ylabel('Lung Gm-csf, fold vs untreated'); ax.legend(frameon=False, fontsize=8)
ax.set_title('c  Gm-csf in aged lung [S02-F], n = 5\n   induced by PSLN-344 only (no young arm in this block)', loc='left', fontsize=9)
fig.tight_layout(); fig.savefig(OUT + 'fig3_innate_PD_axis.png', dpi=200, bbox_inches='tight'); plt.close(fig)
print('figs 2-3 done')

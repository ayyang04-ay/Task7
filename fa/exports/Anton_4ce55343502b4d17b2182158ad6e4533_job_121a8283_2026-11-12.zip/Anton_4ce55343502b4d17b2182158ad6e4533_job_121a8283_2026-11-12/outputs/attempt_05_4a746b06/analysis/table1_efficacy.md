| # | Block (cells) | Vaccine → challenge, day of challenge after immunisation | Sham | PSLN-212 | **PSLN-344** | Young + PSLN-212 | Log-rank p, 344 vs 212 | Caveat (integrity-log item) |
|---|---|---|---|---|---|---|---|---|
| 1 | S03-I (S03!A17:F51) | Bivalent vaccine → 10× mLD50 CA09 H1N1, day 14 (homologous) | 0/7 | 0/7 | **7/7** | 7/7 | 0.0004 | Weight table S13-F shows 3/7 alive in the column headed PSLN-212, and a "Naïve" column absent from S03-I (Q3) |
| 2 | S03-J (S03!G17:J46) | rgH5N1 vaccine → wild-type VN04 H5N1, day 2 | 1/10 | 3/10 | **9/9** | — | 0.002 | Stated n = 9, 10 rows per group; one PSLN-344 row has status 0 but no day, so 9 evaluable. Weight table S13-G (10/10 alive) names the comparators "Sham" and "Naïve" (Q3) |
| 3 | S06-B (S06!G3:K30) | Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 3 | 0/7 | 0/7 | **5/7** | 7/7 | 0.0009 |  |
| 4 | S06-A (S06!A3:E30) | Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 14 | 0/7 | 1/7 | **6/7** | 7/7 | 0.008 |  |
| 5 | S06-E (rows 34–68) (S06!G34:L68) | Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 60 | 0/7 | 0/7 | **5/7** | 7/7 | 0.002 | Weight table S15-E: PSLN-344 6/7, PSLN-212 1/7 (Q2). Untreated sentinels 6/7 |
| 6 | S06-D (S06!A34:E61) | Bivalent vaccine → 5× mLD50 rgH5N1, day 3 | 0/7 | 2/7 | **7/7** | 7/7 | 0.007 | Table identical to S06-C in all four groups (Q1). Weight table S15-D: PSLN-344 5/7, young 5/7 (Q2) |
| 7 | S15-H (S15!A73:D93) | Bivalent vaccine ± PSLN-344 → 5× mLD50 rgH5N1, day 3 | 0/7 | — | **6/7** | — | — | Control column = vaccine alone (no liposome). PSLN-344 alone, no vaccine: 0/7 |
| 8 | S06-C (S06!M3:Q30) | Bivalent vaccine → 5× mLD50 rgH5N1, day 14 | 0/7 | 2/7 | **7/7** | 7/7 | 0.007 | Weight table S15-C: PSLN-212 1/7 (Q2); its PSLN-344 series duplicates S15-I (Q4) |
| 9 | S06-F (rows 34–68) (S06!M34:R68) | Bivalent vaccine → 5× mLD50 rgH5N1, day 60 | 0/7 | 1/7 | **5/7** | 7/7 | 0.009 | Untreated sentinels 7/7 |
| 10 | S06-G (S06!A71:F105) | CA09 H1N1 vaccine → 5× mLD50 Perth H3N2, day 60 | 0/7 | 0/7 | **4/7** | 7/7 | 0.015 | Weight table S15-G: PSLN-344 5/7 (Q2). Untreated sentinels 4/7 |
| 11 | S06-E (rows 71–98) (S06!G71:K98) | 14-month-old, not imprinted: bivalent vaccine → 5× LD50 PR8 | — | 0/7 | **6/7** | — | 0.002 | Challenge day not stated |
| 12 | S06-E (rows 71–98) (S06!G71:K98) | 14-month-old, PR8-imprinted: bivalent vaccine → 5× LD50 PR8 | — | 4/7 | **6/7** | — | 0.23 | Prior PR8 infection itself protects against PR8; no imprinted-only control |
| 13 | S06-F (rows 71–98) (S06!M71:Q98) | 14-month-old, not imprinted: bivalent vaccine → 5× LD50 Perth H3N2, day 14 | — | 0/7 | **6/7** | — | 0.0006 |  |
| 14 | S06-F (rows 71–98) (S06!M71:Q98) | 14-month-old, PR8-imprinted: bivalent vaccine → 5× LD50 Perth H3N2, day 14 | — | 0/7 | **6/7** | — | 0.0002 |  |
| 15 | S15-L (S15!A103:E130) | Aged C57BL/6 (20 months), bivalent vaccine; challenge virus and day not stated | 0/7 | 0/7 | **6/7** | 6/7 | 0.001 | Weight table S15-M: young 7/7 (Q2); PSLN-344 weight series shares values with S15-A (Q4) |
| 16 | S15-N (S15!A134:E161) | Aged Swiss Webster (20 months), bivalent vaccine; challenge virus and day not stated | 0/7 | 2/7 | **6/7** | 7/7 | 0.056 | PSLN-344 weight series shares values with S15-A/S15-M (Q4) |
import json, numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
B = json.load(open('blocks.json'))
def sv(bid, g):
    r = [x for x in B[bid]['groups'][g]['records'] if x['day'] is not None]
    return sum(x['status'] == 0 for x in r), len(r)
# (experiment, survival block, 344 group, 212 group, weight-table alive counts (344, n344, 212, n212) or None when identical)
E = [
 ('S03-I',      'S03-I', 'PSLN-344', 'PSLN-212',                   (7, 7, 3, 7)),
 ('S03-J',      'S03-J', 'PSLN-344', 'PSLN-212',                   (10, 10, 5, 10)),   # weight table: 'Sham' column (5/10 alive by rule) is the only candidate for the PSLN-212 arm; PSLN-344 10/10
 ('S06-A',      'S06-A', 'PSLN-344', 'PSLN-212',                   (6, 7, 1, 7)),
 ('S06-B',      'S06-B', 'PSLN-344', 'PSLN-212',                   (5, 7, 0, 7)),
 ('S06-C',      'S06-C', 'PSLN-344', 'PSLN-212',                   (7, 7, 1, 7)),
 ('S06-D',      'S06-D', 'PSLN-344', 'PSLN-212',                   (5, 7, 2, 7)),
 ('S06-E(d60)', 'S06-E_r34', 'PSLN-344', 'PSLN-212',               (6, 7, 1, 7)),
 ('S06-F(d60)', 'S06-F_r34', 'PSLN-344', 'PSLN-212',               (5, 7, 1, 7)),
 ('S06-G',      'S06-G', 'PSLN-344', 'PSLN-212',                   (5, 7, 0, 7)),
 ('impr PR8 naive', 'S06-E_r71', 'Naïve+PSLN-344', 'Naïve+PSLN-212',         (6, 7, 0, 7)),
 ('impr PR8 impr',  'S06-E_r71', 'Imprinting+PSLN-344', 'Imprinting+PSLN-212', (6, 7, 4, 7)),
 ('impr Perth naive', 'S06-F_r71', 'Naïve+PSLN-344', 'Naïve+PSLN-212',       (6, 7, 0, 7)),
 ('impr Perth impr',  'S06-F_r71', 'Imprinting+PSLN-344', 'Imprinting+PSLN-212', (6, 7, 0, 7)),
 ('S15-H',      'S15-H', '3d Vaccine+PSLN-344', None,              (6, 7, None, None)),
 ('S15-L',      'S15-L', 'PSLN-344', 'PSLN-212',                   (6, 7, 0, 7)),
 ('S15-N',      'S15-N', 'PSLN-344', 'PSLN-212',                   (6, 7, 2, 7)),
]
rows = []
for name, bid, g344, g212, w in E:
    s3, n3 = sv(bid, g344)
    s2, n2 = sv(bid, g212) if g212 else (None, None)
    rows.append(dict(exp=name, surv344=s3, n344=n3, bw344=w[0], nbw344=w[1], surv212=s2, n212=n2, bw212=w[2], nbw212=w[3]))
D = pd.DataFrame(rows)
print(D.to_string(index=False))
def ci(s, n):
    lo, hi = proportion_confint(s, n, method='beta'); return f'{int(s)}/{int(n)} = {100*s/n:.1f}% (95% CI {100*lo:.1f}-{100*hi:.1f})'
print('\nAs printed in survival tables: 344', ci(D.surv344.sum(), D.n344.sum()), '| 212', ci(D.surv212.dropna().sum(), D.n212.dropna().sum()))
# worst case for the claim: min for 344 (missing-day animal in S03-J counted as a death -> 9/10), max for 212
w344 = sum(min(r.surv344, r.bw344) for r in D.itertuples()); n344 = sum(max(r.n344, r.nbw344) for r in D.itertuples())
d2 = D.dropna(subset=['surv212'])
w212 = sum(max(r.surv212, r.bw212) for r in d2.itertuples()); n212 = d2.n212.sum()
print('Least favourable reading (lower count for 344 incl. the S03-J animal without a day counted as dead; higher count for 212): 344', ci(w344, n344), '| 212', ci(w212, n212))
print('   Fisher exact on these pooled counts: p =', stats.fisher_exact([[w344, n344 - w344], [w212, n212 - w212]])[1])
# concordant-only: experiments where survival table and weight table agree for BOTH arms and no whole-table duplication
conc = D[(D.surv344 == D.bw344) & ((D.surv212 == D.bw212) | D.surv212.isna()) & (~D.exp.isin(['S06-C', 'S06-D', 'S03-J']))]
print('\nExperiments with concordant survival and weight tables in both arms (and not part of the identical S06-C/D pair):', list(conc.exp))
print('   344', ci(conc.surv344.sum(), conc.n344.sum()), '| 212', ci(conc.surv212.dropna().sum(), conc.n212.dropna().sum()))
# >= 20-month BALB/c only
b = D[D.exp.isin(['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E(d60)', 'S06-F(d60)', 'S06-G', 'S15-H'])]
print('\nBALB/c >= 20 months only (S03-I, S03-J, S06-A..G, S15-H): 344', ci(b.surv344.sum(), b.n344.sum()), '| 212', ci(b.surv212.dropna().sum(), b.n212.dropna().sum()))
h = D[D.exp.isin(['S06-A', 'S06-B', 'S06-C', 'S06-E(d60)', 'S06-F(d60)', 'S06-G', 'S15-H', 'impr PR8 naive', 'impr Perth naive', 'impr Perth impr'])]
print('Heterosubtypic challenges in BALB/c, S06-D excluded (S06-A,B,C,E,F,G, S15-H, imprinting naive PR8/Perth, imprinted Perth): 344', ci(h.surv344.sum(), h.n344.sum()), '| 212', ci(h.surv212.dropna().sum(), h.n212.dropna().sum()))

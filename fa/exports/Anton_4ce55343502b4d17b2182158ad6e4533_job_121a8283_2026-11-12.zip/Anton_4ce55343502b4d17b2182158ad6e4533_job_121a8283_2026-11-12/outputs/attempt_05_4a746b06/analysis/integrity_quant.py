import json, numpy as np
B = json.load(open('blocks.json'))
def M(bid, g):
    return np.array([[np.nan if v is None else v for v in row] for row in B[bid]['groups'][g]['matrix']], float)
def cmp(b1, g1, b2, g2, skip_first=True):
    a, b = M(b1, g1), M(b2, g2)
    r = slice(1, None) if skip_first else slice(None)
    a, b = a[r], b[r]
    n = min(a.shape[1], b.shape[1]); a, b = a[:, :n], b[:, :n]
    both = ~np.isnan(a) & ~np.isnan(b)
    same = both & (a == b)
    rows_identical = [B[b1]['times'][i + (1 if skip_first else 0)] for i in range(a.shape[0]) if both[i].all() and same[i].all()]
    return int(same.sum()), int(both.sum()), rows_identical
print('1) S15-C PSLN-344 vs S15-I 3d Vaccine+PSLN-344 (d2..d14):', cmp('S15-C', 'PSLN-344', 'S15-I', '3d Vaccine+PSLN-344'))
print('2) S15-A PSLN-344 vs S15-M PSLN-344:', cmp('S15-A', 'PSLN-344', 'S15-M', 'PSLN-344'))
print('   S15-A PSLN-344 vs S15-O PSLN-344:', cmp('S15-A', 'PSLN-344', 'S15-O', 'PSLN-344'))
print('   S15-M PSLN-344 vs S15-O PSLN-344:', cmp('S15-M', 'PSLN-344', 'S15-O', 'PSLN-344'))
print('   S15-C PSLN-344 vs S15-M PSLN-344:', cmp('S15-C', 'PSLN-344', 'S15-M', 'PSLN-344'))
print('   S15-A Sham vs S15-M PSLN-212:', cmp('S15-A', 'Sham', 'S15-M', 'PSLN-212'))
print('   S15-A PSLN-212 vs S15-M PSLN-212:', cmp('S15-A', 'PSLN-212', 'S15-M', 'PSLN-212'))
for g in ['Vaccine', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
    print(f'3) S11-A vs S11-B [{g}] (d0..d8):', cmp('S11-A', g, 'S11-B', g, skip_first=False))
a = np.concatenate([M('S11-A', g) for g in ['Vaccine', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']], axis=1)
b = np.concatenate([M('S11-B', g) for g in ['Vaccine', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']], axis=1)
print('   overall identical cells:', int((a == b).sum()), 'of', a.size, '; first-two-animal columns identical:', int((a[:, [0,1,5,6,10,11,15,16]] == b[:, [0,1,5,6,10,11,15,16]]).sum()), 'of 40')
print('   S11-A vs S11-B group means by day (A | B):')
for g in ['Vaccine', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
    print('     ', g, np.round(M('S11-A', g).mean(axis=1), 1), '|', np.round(M('S11-B', g).mean(axis=1), 1))
print('4) S09-C PSLN-212Y vs PSLN-344Y:', cmp('S09-C', 'PSLN-212Y', 'S09-C', 'PSLN-344Y'))
# S01-B vs S08-C
s01 = {g: d['values'] for g, d in B['S01-B']['groups'].items()}; s08 = {g: d['values'] for g, d in B['S08-C']['groups'].items()}
print('5) S01-B:', s01); print('   S08-C:', s08)
for g1, v1 in s01.items():
    for g2, v2 in s08.items():
        sh = sorted(set(v1) & set(v2))
        if sh: print(f'   shared values {g1} <-> {g2}: {sh}')
# means under the two readings of S08-C
v = s08
print('   as printed:   PSLN-SRB AECII %.1f, AECI %.1f ; PSLN-344-SRB AECII %.1f, AECI %.1f' % (np.mean(v['AECII-PSLN-SRB']), np.mean(v['AECI-PSLN-SRB']), np.mean(v['AECII-PSLN-344-SRB']), np.mean(v['AECI-PSLN-344-SRB'])))
print('   if cols B and C are transposed: PSLN-SRB AECII %.1f, AECI %.1f ; PSLN-344-SRB AECII %.1f, AECI %.1f' % (np.mean(v['AECII-PSLN-SRB']), np.mean(v['AECII-PSLN-344-SRB']), np.mean(v['AECI-PSLN-SRB']), np.mean(v['AECI-PSLN-344-SRB'])))
print('   S01-B means: AECII/PSLN-SRB %.1f ; AECI/PSLN-SRB %.1f' % (np.mean(s01['AECII/PSLN-SRB']), np.mean(s01['AECI/PSLN-SRB'])))
# S09-A Il6 etc. PBS normalisation
for p in ['S09-A_panel1', 'S09-A_panel2']:
    pb = np.array(B[p]['groups']['PBS']['matrix'], float)
    print('6)', p, 'PBS row means (log10):', np.round(pb.mean(axis=1), 6))

import json, numpy as np
from scipy import stats
from lifelines.statistics import logrank_test
B = json.load(open('blocks.json'))
def recs(bid, g):
    r = [x for x in B[bid]['groups'][g]['records'] if x['day'] is not None]
    return np.array([x['day'] for x in r], float), np.array([x['status'] for x in r], int)
def my_lr(tA, eA, tB, eB):
    OE = V = 0.0
    for tt in np.unique(np.concatenate([tA[eA == 1], tB[eB == 1]])):
        nA = (tA >= tt).sum(); nB = (tB >= tt).sum(); dA = ((tA == tt) & (eA == 1)).sum(); dB = ((tB == tt) & (eB == 1)).sum()
        n = nA + nB; d = dA + dB
        OE += dA - d*nA/n
        if n > 1: V += d*(nA/n)*(nB/n)*(n-d)/(n-1)
    chi = OE**2/V
    return chi, stats.chi2.sf(chi, 1)
for bid, g1, g2 in [('S06-A','PSLN-344','PSLN-212'), ('S03-J','PSLN-344','PSLN-212'), ('S06-G','PSLN-344','Untreated'), ('S15-H','3d Vaccine+PSLN-344','3d PSLN-344')]:
    t1, e1 = recs(bid, g1); t2, e2 = recs(bid, g2)
    a = logrank_test(t1, t2, e1, e2)
    chi, p = my_lr(t1, e1, t2, e2)
    print(f'{bid} {g1} vs {g2}: lifelines chi2={a.test_statistic:.4f} p={a.p_value:.5f} | own implementation chi2={chi:.4f} p={p:.5f}')

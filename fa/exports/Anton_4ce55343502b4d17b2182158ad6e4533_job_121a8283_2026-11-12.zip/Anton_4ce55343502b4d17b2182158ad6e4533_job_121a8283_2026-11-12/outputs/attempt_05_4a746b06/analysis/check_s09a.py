import json, math
B = json.load(open('blocks.json'))
name_map = {'PBS':'Sham','CMP-204':'CMP-204','PSLN-212':'PSLN-212','PSLN-R848':'PSLN-R848','PSLN-212/R848':'PSLN-212/R848','PSLN-344':'PSLN-344','PSLN-212(y)':'PSLN-212(Y)'}
for panel in ['S09-A_panel1','S09-A_panel2']:
    b = B[panel]
    print('\n', panel, b['measurand'])
    for g in b['order']:
        ifn_log = b['groups'][g]['matrix'][0]    # Ifnb1 row
        lin = [10**x for x in ifn_log]
        for ref in ['S01-A_16h','S01-A_72h']:
            refv = B[ref]['groups'][name_map[g]]['values']
            # does each back-transformed value appear in the S01-A panel?
            hits = [any(abs(l - r) < 0.006 for r in refv) for l in lin]
            print(f'   {g:14s} 10^Ifnb1 = {[round(x,2) for x in lin]}  vs {ref} {refv}: matches {sum(hits)}/3')

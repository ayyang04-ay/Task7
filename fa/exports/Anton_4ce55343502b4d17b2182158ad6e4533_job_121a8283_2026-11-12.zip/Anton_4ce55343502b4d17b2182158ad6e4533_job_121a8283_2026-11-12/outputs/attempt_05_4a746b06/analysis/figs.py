import json, numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
from lifelines import KaplanMeierFitter
B = json.load(open('blocks.json'))
import os
OUT = os.environ.get('PSLN_FIGDIR', '/tmp/outputs/figures/')
os.makedirs(OUT, exist_ok=True)
COL = {'Sham': '#8c8c8c', 'P212': '#e6862a', 'P344': '#1f5fa8', 'Young': '#3a9a5c', 'Untreated': '#b07cc6', 'CMP204': '#c9a227', 'VaxOnly': '#8c8c8c', 'AdjOnly': '#b24a4a'}
NAME = {'Sham': 'Vaccine + sham liposome (aged)', 'P212': 'Vaccine + PSLN-212 (aged)', 'P344': 'Vaccine + PSLN-344 (aged)', 'Young': 'Vaccine + PSLN-212 (young)',
        'Untreated': 'Untreated, unchallenged (aged)', 'CMP204': 'Vaccine + CMP-204 (aged)', 'VaxOnly': 'Vaccine alone (aged)', 'AdjOnly': 'PSLN-344 alone, no vaccine (aged)'}
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150})

def recs(bid, g):
    r = [x for x in B[bid]['groups'][g]['records'] if x['day'] is not None]
    return np.array([x['day'] for x in r], float), np.array([x['status'] for x in r], int)
EXPS = [
 ('S03-I','CA09 H1N1 10x, d14\n(homologous)', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)', CMP204='CMP-204')),
 ('S03-J','WT H5N1, d2\n(rgH5N1 vaccine)', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344')),
 ('S06-B','H3N2 vax > PR8 H1N1, d3', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S06-A','H3N2 vax > PR8 H1N1, d14', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S06-E_r34','H3N2 vax > PR8 H1N1, d60', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)', Untreated='Untreated')),
 ('S06-D','bivalent > rgH5N1, d3\n(table identical to d14)', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S15-H','bivalent > rgH5N1, d3\n(antigen-requirement expt)', dict(VaxOnly='3d Vaccine', AdjOnly='3d PSLN-344', P344='3d Vaccine+PSLN-344')),
 ('S06-C','bivalent > rgH5N1, d14', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S06-F_r34','bivalent > rgH5N1, d60', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)', Untreated='Untreated')),
 ('S06-G','H1N1 vax > Perth H3N2, d60', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)', Untreated='Untreated')),
 ('S06-E_r71','14-mo, not imprinted > PR8', dict(P212='Naïve+PSLN-212', P344='Naïve+PSLN-344')),
 ('S06-E_r71','14-mo, PR8-imprinted > PR8', dict(P212='Imprinting+PSLN-212', P344='Imprinting+PSLN-344')),
 ('S06-F_r71','14-mo, not imprinted > Perth', dict(P212='Naïve+PSLN-212', P344='Naïve+PSLN-344')),
 ('S06-F_r71','14-mo, PR8-imprinted > Perth', dict(P212='Imprinting+PSLN-212', P344='Imprinting+PSLN-344')),
 ('S15-L','aged C57BL/6', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S15-N','aged Swiss Webster', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
]
# weight-table-derived alternative counts where they differ from the survival table  (exp index -> arm -> (alive, n))
ALT = {('S03-I','P212'): (3, 7), ('S06-C','P212'): (1, 7), ('S06-D','P344'): (5, 7), ('S06-D','Young'): (5, 7), ('S06-E_r34','P212'): (1, 7), ('S06-E_r34','P344'): (6, 7),
       ('S06-G','P344'): (5, 7), ('S15-L','Young'): (7, 7)}

# ---------------- Figure 1: survival by experiment ----------------
fig, ax = plt.subplots(figsize=(8.6, 7.6))
ylab = []; y = 0; ypos = []
for i, (bid, lab, arms) in enumerate(EXPS):
    y = len(EXPS) - i
    tag = bid.replace('_r34', '').replace('_r71', ', rows 71-98')
    ypos.append(y); ylab.append(f'{lab.replace(chr(10), " ")}  [{tag}]')
    offs = {'Sham': 0.27, 'VaxOnly': 0.27, 'AdjOnly': 0.09, 'P212': 0.09, 'CMP204': -0.27, 'P344': -0.09, 'Young': -0.27, 'Untreated': 0.0}
    for arm, g in arms.items():
        if arm in ('Untreated', 'CMP204'): continue
        t, e = recs(bid, g); n = len(e); s = n - e.sum(); p = 100*s/n
        lo, hi = proportion_confint(s, n, method='beta')
        yy = y + offs[arm]
        if arm in ('P344', 'P212'):
            ax.plot([100*lo, 100*hi], [yy, yy], color=COL[arm], lw=1.1, alpha=0.55, zorder=1)
        ax.scatter(p, yy, s=46 if arm in ('P344', 'P212') else 30, color=COL[arm], zorder=3, edgecolor='white', linewidth=0.5)
        if arm == 'P344': ax.text(105, y, f'{int(s)}/{n}', va='center', ha='center', fontsize=7.5, color=COL[arm])
        if arm == 'P212': ax.text(123, y, f'{int(s)}/{n}', va='center', ha='center', fontsize=7.5, color=COL[arm])
        if (bid, arm) in ALT:
            a, nn = ALT[(bid, arm)]
            ax.scatter(100*a/nn, yy, s=46, facecolor='none', edgecolor=COL[arm], linewidth=1.3, zorder=4)
    ax.axhline(y - 0.5, color='#e5e5e5', lw=0.6, zorder=0)
ax.set_yticks(ypos); ax.set_yticklabels(ylab, fontsize=8)
ax.set_xlim(-4, 131); ax.set_xticks([0, 25, 50, 75, 100]); ax.set_xlabel('Survival at end of observation (%)  —  bars: exact 95% CI for the two adjuvanted aged arms')
ax.text(105, len(EXPS) + 0.75, 'PSLN-344', fontsize=7, color=COL['P344'], fontweight='bold', ha='center'); ax.text(123, len(EXPS) + 0.75, 'PSLN-212', fontsize=7, color=COL['P212'], fontweight='bold', ha='center')
h = [Line2D([], [], marker='o', ls='', color=COL[k], label=NAME[k]) for k in ['P344', 'P212']]
h += [Line2D([], [], marker='o', ls='', color=COL['Sham'], label='Vaccine + sham liposome (aged); vaccine alone in S15-H'), Line2D([], [], marker='o', ls='', color=COL['Young'], label=NAME['Young'])]
h += [Line2D([], [], marker='o', ls='', color=COL['AdjOnly'], label='PSLN-344 alone, no vaccine (S15-H only)'),
      Line2D([], [], marker='o', ls='', markerfacecolor='none', color='k', label='count implied by the paired body-weight table, where it differs')]
ax.legend(handles=h, loc='upper center', bbox_to_anchor=(0.42, -0.085), ncol=2, frameon=False, fontsize=8)
ax.set_title('Survival after lethal influenza challenge: the Mn-containing formulation rescues aged animals;\nthe Mn-free parent does not (survival tables, 16 comparisons)', fontsize=10, loc='left')
ax.set_ylim(0.4, len(EXPS) + 1.2)
fig.tight_layout(); fig.savefig(OUT + 'fig1_survival_by_experiment.png', dpi=200, bbox_inches='tight'); plt.close(fig)

# ---------------- Figure 2: KM grid ----------------
fig, axes = plt.subplots(4, 4, figsize=(13, 10.5), sharex=False, sharey=True)
for ax, (bid, lab, arms) in zip(axes.ravel(), EXPS):
    for arm, g in arms.items():
        t, e = recs(bid, g)
        km = KaplanMeierFitter().fit(t, e)
        tl = np.r_[km.survival_function_.index.values, max(t.max(), 14)]; sv = np.r_[km.survival_function_.iloc[:, 0].values, km.survival_function_.iloc[-1, 0]]
        jit = {'Sham': 0, 'VaxOnly': 0, 'P212': 0.6, 'AdjOnly': 0.6, 'P344': 1.2, 'Young': 1.8, 'Untreated': 2.4, 'CMP204': -0.6}[arm]
        ax.step(tl, 100*sv + jit, where='post', color=COL[arm], lw=1.8 if arm in ('P344', 'P212') else 1.2, alpha=0.95)
    ax.set_title(f'{lab}\n[{bid.replace("_r34", "").replace("_r71", ", rows 71-98")}]', fontsize=8); ax.set_ylim(-5, 108); ax.set_xlim(0, 22 if bid == 'S03-J' else 14.5)
    ax.set_xticks([0, 7, 14] + ([21] if bid == 'S03-J' else []))
for ax in axes[-1]: ax.set_xlabel('Days after challenge')
for ax in axes[:, 0]: ax.set_ylabel('Survival (%)')
h = [Line2D([], [], color=COL[k], lw=2, label=NAME[k]) for k in ['P344', 'P212', 'Sham', 'Young', 'Untreated', 'CMP204', 'AdjOnly']]
fig.legend(handles=h, loc='lower center', ncol=4, frameon=False, fontsize=8.5, bbox_to_anchor=(0.5, -0.035))
fig.suptitle('Kaplan-Meier curves for every aged-animal survival table (curves offset vertically by <2.5 points so overlapping lines stay visible)', fontsize=10, y=0.995)
fig.tight_layout(); fig.savefig(OUT + 'figA1_KM_all_experiments.png', dpi=170, bbox_inches='tight'); plt.close(fig)
print('figs 1-2 done')

"""Detect re-used numbers between different blocks / groups.
For every pair of numeric vectors (one vector per group per block, or per group x timepoint for matrices),
count position-wise identical values and set-wise shared values (ignoring trivial values like 100, 0, 1, 14, titres)."""
import json, itertools
B = json.load(open('blocks.json'))
vecs = []   # (block, group, tag, values)
for bid, b in B.items():
    k = b['kind']
    if k == 'groups':
        if b.get('scale') == 'titre': continue   # discrete dilution titres repeat legitimately
        for g, d in b['groups'].items():
            vecs.append((bid, g, '', d['values']))
    elif k in ('timecourse', 'weights'):
        for g, d in b['groups'].items():
            for t, row in zip(b['times'], d['matrix']):
                vecs.append((bid, g, f't={t}', row))
    elif k == 'analytes':
        for g, d in b['groups'].items():
            for a, row in zip(b['analytes'], d['matrix']):
                vecs.append((bid, g, a, row))
def nontrivial(v):
    return v is not None and v not in (100, 0, 1) 
hits = []
for (b1, g1, t1, v1), (b2, g2, t2, v2) in itertools.combinations(vecs, 2):
    if b1 == b2 and g1 == g2: 
        continue  # same animal set over time: LOCF handled elsewhere
    pos = sum(1 for a, b in zip(v1, v2) if nontrivial(a) and a == b)
    s1 = [x for x in v1 if nontrivial(x)]; s2 = [x for x in v2 if nontrivial(x)]
    shared = len(set(s1) & set(s2))
    n = min(len(s1), len(s2))
    if n >= 2 and (pos >= 2 or shared >= 3):
        hits.append((pos, shared, b1, g1, t1, b2, g2, t2, v1, v2))
hits.sort(key=lambda h: (-h[0], -h[1]))
print(len(hits), 'vector pairs with >=2 position-identical or >=3 shared non-trivial values')
from collections import defaultdict
agg = defaultdict(lambda: [0, 0, 0])
for pos, shared, b1, g1, t1, b2, g2, t2, v1, v2 in hits:
    key = (b1, g1, b2, g2)
    agg[key][0] += pos; agg[key][1] += shared; agg[key][2] += 1
print('\nAggregated by (block,group) pair: total position-identical values, total shared, n timepoints/analytes involved')
for key, (p, s, n) in sorted(agg.items(), key=lambda kv: -kv[1][0]):
    print(f'  {key[0]:13s} {key[1]:22s} <-> {key[2]:13s} {key[3]:22s}  pos-identical={p:3d} shared={s:3d} rows={n}')
json.dump([dict(pos=h[0], shared=h[1], b1=h[2], g1=h[3], t1=h[4], b2=h[5], g2=h[6], t2=h[7], v1=h[8], v2=h[9]) for h in hits], open('dup_hits.json','w'), indent=0)

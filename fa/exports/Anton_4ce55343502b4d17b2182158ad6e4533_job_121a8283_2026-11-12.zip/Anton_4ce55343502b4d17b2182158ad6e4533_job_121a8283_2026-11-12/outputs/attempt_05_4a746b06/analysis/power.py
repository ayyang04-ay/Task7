import numpy as np
from scipy import stats
from itertools import product
def power_fisher(p1, p2, n1, n2=None, alpha=0.05):
    n2 = n2 or n1
    pw = 0.0
    for a in range(n1+1):
        pa = stats.binom.pmf(a, n1, p1)
        if pa < 1e-12: continue
        for b in range(n2+1):
            pb = stats.binom.pmf(b, n2, p2)
            if pb < 1e-12: continue
            if stats.fisher_exact([[a, n1-a], [b, n2-b]])[1] < alpha: pw += pa*pb
    return pw
for p1, p2 in [(0.85, 0.14), (0.85, 0.40), (0.85, 0.50), (0.67, 0.14), (0.95, 0.67)]:
    out = []
    for n in [7, 8, 10, 12, 15, 20, 25, 30, 40]:
        out.append((n, round(power_fisher(p1, p2, n), 2)))
    print(f'survival {p1:.2f} vs {p2:.2f}: (n/group, power) {out}')
# current design: n=7 per group, power to detect 85% vs 14%
print('n=7: power for 85 vs 14 =', round(power_fisher(0.85, 0.14, 7), 2))
# upper 95% bound on an adverse-event rate when 0 events are seen in n animals (rule of three, exact)
for n in [5, 10, 15, 20, 30]:
    print(f'0/{n} events -> exact one-sided 95% upper bound on true rate = {1 - 0.05**(1/n):.2f}')

"""Arm-level biomarker screen.
'Protected' arms in aged-relevant challenge data = PSLN-344 (aged) and PSLN-212(Y); 'unprotected' = Sham and PSLN-212 (aged).
For every readout measured in all four arms we ask: do individual animal values from protected arms separate completely from
unprotected arms (AUROC across animals), how big is the gap between the closest arms, and how much of the age gap is closed.
NB: this is arm-level (ecological) association: no animal has both a biomarker value and a challenge outcome."""
import json, numpy as np, pandas as pd
from scipy import stats
B = json.load(open('blocks.json'))
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
def getvals(bid, tidx=None):
    b = B[bid]; out = {}
    for g, d in b['groups'].items():
        gg = g.replace('PSLN-212Y', 'PSLN-212(Y)').strip()
        if b['kind'] == 'groups': out[gg] = d['values']
        else: out[gg] = d['matrix'][tidx]
    return out
rows = []
cands = []
for bid, b in B.items():
    if b['kind'] == 'groups': cands.append((bid, None, bid))
    elif b['kind'] == 'timecourse':
        for i, t in enumerate(b['times']): cands.append((bid, i, f'{bid}@{t}' if t is not None else bid))
for bid, ti, lab in cands:
    v = getvals(bid, ti)
    need = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
    ctrl = 'Sham' if 'Sham' in v else ('Vaccine' if 'Vaccine' in v else None)
    if not all(k in v for k in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']) or ctrl is None: continue
    sc = B[bid].get('scale'); lod = B[bid].get('lod')
    def tr(x):
        x = np.array([a for a in x if a is not None], float)
        if sc in ('titre', 'fold'):
            if lod: x = np.where(x < lod, lod/2, x)
            return np.log10(x)
        return x
    prot = np.concatenate([tr(v['PSLN-344']), tr(v['PSLN-212(Y)'])]); unp = np.concatenate([tr(v[ctrl]), tr(v['PSLN-212'])])
    u = stats.mannwhitneyu(prot, unp, alternative='two-sided')
    auc = u.statistic / (len(prot) * len(unp))
    direction = 'up' if auc >= 0.5 else 'down'
    auc = max(auc, 1 - auc)
    # gap between closest protected arm and closest unprotected arm, in pooled-SD units
    m = {k: tr(v[k]).mean() for k in [ctrl, 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
    sd = np.sqrt(np.mean([tr(v[k]).var(ddof=1) for k in [ctrl, 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']]))
    if direction == 'up': gap = (min(m['PSLN-344'], m['PSLN-212(Y)']) - max(m[ctrl], m['PSLN-212'])) / sd
    else: gap = (min(m[ctrl], m['PSLN-212']) - max(m['PSLN-344'], m['PSLN-212(Y)'])) / sd
    overlap = (min(prot) <= max(unp)) if direction == 'up' else (max(prot) >= min(unp))
    restor = (m['PSLN-344'] - m['PSLN-212']) / (m['PSLN-212(Y)'] - m['PSLN-212']) if m['PSLN-212(Y)'] != m['PSLN-212'] else np.nan
    rows.append(dict(readout=lab, what=B[bid]['measurand'][:52], n=len(tr(v['PSLN-344'])), dir=direction, AUROC=auc, complete_sep=(not overlap), gap_SD=gap, restoration=restor))
S = pd.DataFrame(rows)
S = S[~S.readout.str.startswith('S11-B') & (S.readout != 'S04-B_TfhTfr')]   # S11-B duplicates S11-A; Tfh:Tfr is a transform of S04-B Foxp3
S = S.sort_values(['complete_sep', 'gap_SD'], ascending=[False, False])
print(len(S), 'read-out/time-point combinations;', int(S.complete_sep.sum()), 'separate protected from unprotected arms completely')
print(S.to_string(index=False, float_format=lambda x: f'{x:.2f}'))
S.to_csv('biomarker_screen.csv', index=False)

#!/usr/bin/env bash
# Re-runs the whole analysis from the workbook. Environments are the micromamba envs of the analysis image.
#   PSLN_WORKBOOK : path to adjuvant_program_dataset.xlsx (default /tmp/world/filesystem/adjuvant_program_dataset.xlsx)
#   PSLN_FIGDIR   : where figures are written (default /tmp/outputs/figures/)
set -euo pipefail
cd "$(dirname "$0")"
X="micromamba run -n singlecell python"   # has openpyxl (reads the workbook)
C="micromamba run -n core python"         # has scipy, statsmodels, lifelines, matplotlib
$X parse_blocks.py            # -> blocks.json (+ coverage check: every numeric cell is read)
$X audit_n.py      > audit_n.txt          # stated n vs observed n
$X audit_bw.py     > audit_bw.txt         # survival tables vs body-weight tables, per animal
$X audit_dup.py    > audit_dup.txt        # re-used values between blocks (weights)
$X audit_dup2.py   > audit_dup2.txt
$X audit_dup3.py   > audit_dup3.txt       # re-used values between blocks (non-weight)
$X surv_dups.py    > surv_dups.txt        # identical survival tables
$X integrity_quant.py > integrity_quant.txt
$X check_ratio.py  > check_ratio.txt      # printed IgG2a/IgG1 vs raw
$X check_s09a.py   > check_s09a.txt       # which S09-A panel is 16 h / 72 h
$C surv_analysis.py   > surv_analysis.txt
$C pooled_survival.py > pooled_survival.txt
$C verify_lr.py       > verify_lr.txt
$C exact_lr.py        > exact_lr.txt       # exact permutation p-values for the 15 head-to-head comparisons
$C immuno_analysis.py > immuno_summary.txt
$C key_contrasts.py   > key_contrasts.txt
$C misc_checks.py     > misc_checks.txt
$C bw_analysis.py     > bw_analysis.txt 2>/dev/null
$C safety_analysis.py > safety_analysis.txt
$C biomarker_screen.py > biomarker_screen.txt
$C sensitivity.py     > sensitivity.txt
$C power.py           > power.txt
$C ledger.py          > ledger_out.txt     # -> evidence_ledger.csv
$C block_directory.py > /dev/null          # -> block_directory.csv
$C make_tables.py     > /dev/null          # -> table1_efficacy.md, table2_immune.md
$C figs.py; $C figs2.py; $C figs3.py; $C figs4.py
$X spot_check.py      > spot_check.txt     # headline numbers recomputed straight from cell addresses
tail -1 spot_check.txt

import json
B = json.load(open('blocks.json'))
print(f"{'block':16s} {'kind':10s} {'stated_n':>8s}  observed n per group")
for bid, b in B.items():
    k = b['kind']
    if k == 'groups':
        obs = {g: sum(v is not None for v in d['values']) for g, d in b['groups'].items()}
    elif k in ('timecourse', 'weights'):
        obs = {}
        for g, d in b['groups'].items():
            per_t = [sum(v is not None for v in row) for row in d['matrix']]
            obs[g] = per_t[0] if len(set(per_t)) == 1 else per_t
    elif k == 'analytes':
        obs = {}
        for g, d in b['groups'].items():
            per_t = [sum(v is not None for v in row) for row in d['matrix']]
            obs[g] = per_t[0] if len(set(per_t)) == 1 else per_t
    elif k == 'survival':
        obs = {}
        for g, d in b['groups'].items():
            n = len(d['records']); ev = sum(r['status'] == 1 for r in d['records'])
            miss = sum(r['day'] is None for r in d['records'])
            obs[g] = f"n={n} events={ev}" + (f" MISSING-DAY={miss}" if miss else '')
    else:
        obs = 'raw'
    flag = ''
    sn = b.get('stated_n')
    if k == 'groups':
        if any(v != sn for v in obs.values()): flag = '  <-- n mismatch'
    elif k == 'survival':
        if any(not s.startswith(f'n={sn} ') for s in obs.values()): flag = '  <-- n mismatch'
    elif k in ('timecourse','analytes'):
        if any(v != sn for v in obs.values()): flag = '  <-- n mismatch / varying'
    print(f"{bid:16s} {k:10s} {str(sn):>8s}  {obs}{flag}")

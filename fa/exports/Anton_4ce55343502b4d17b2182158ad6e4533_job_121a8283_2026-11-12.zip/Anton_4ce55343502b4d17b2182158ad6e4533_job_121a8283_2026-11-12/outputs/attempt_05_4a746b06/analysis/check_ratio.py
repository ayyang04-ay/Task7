import json, itertools
B = json.load(open('blocks.json'))
def vals(bid, g): return B[bid]['groups'][g]['values']
for ratio_blk, a_blk, b_blk, strain in [('S03-B','S13-A','S13-B','CA09 H1N1'), ('S03-F','S13-C','S13-D','Aichi H3N2')]:
    print(f'\n== {ratio_blk} (printed IgG2a/IgG1 quotient) vs recomputed {a_blk}/{b_blk}  [{strain}]')
    rec = {}
    for g in B[a_blk]['order']:
        rec[g] = [a/b for a, b in zip(vals(a_blk, g), vals(b_blk, g))]
        print(f'  recomputed from raw, raw label {g:12s}:', [round(x, 6) for x in rec[g]])
    for g in B[ratio_blk]['order']:
        pv = vals(ratio_blk, g)
        # which raw group reproduces it?
        match = [rg for rg, rv in rec.items() if all(abs(x-y) < 5e-5 for x, y in zip(pv, rv))]
        print(f'  printed {ratio_blk} column "{g}": {pv}  ==> equals recomputed ratio of raw group: {match}')

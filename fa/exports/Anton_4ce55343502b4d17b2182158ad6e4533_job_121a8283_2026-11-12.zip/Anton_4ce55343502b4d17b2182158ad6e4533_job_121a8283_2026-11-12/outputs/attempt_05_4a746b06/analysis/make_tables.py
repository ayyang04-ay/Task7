import json, numpy as np, pandas as pd, warnings
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from lifelines.statistics import logrank_test
warnings.filterwarnings('ignore')
B = json.load(open('blocks.json'))
def recs(bid, g):
    r = [x for x in B[bid]['groups'][g]['records'] if x['day'] is not None]
    return np.array([x['day'] for x in r], float), np.array([x['status'] for x in r], int)
def sc(bid, g):
    t, e = recs(bid, g); return f'{len(e)-e.sum()}/{len(e)}'
def fp(p):
    if p != p: return 'n/a'
    return '<0.0001' if p < 1e-4 else (f'{p:.4f}' if p < 0.001 else (f'{p:.3f}' if p < 0.1 else f'{p:.2f}'))
def lr(bid, a, b):
    t1, e1 = recs(bid, a); t2, e2 = recs(bid, b); return logrank_test(t1, t2, e1, e2).p_value

# ---------------- Table 1 ----------------
T1 = [
 # id, block, cells, design, sham, 212, 344, young, note
 ('1', 'S03-I', 'S03!A17:F51', 'Bivalent vaccine → 10× mLD50 CA09 H1N1, day 14 (homologous)', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'Weight table S13-F shows 3/7 alive in the column headed PSLN-212, and a "Naïve" column absent from S03-I (Q3)'),
 ('2', 'S03-J', 'S03!G17:J46', 'rgH5N1 vaccine → wild-type VN04 H5N1, day 2', 'Sham', 'PSLN-212', 'PSLN-344', None, 'Stated n = 9, 10 rows per group; one PSLN-344 row has status 0 but no day, so 9 evaluable. Weight table S13-G (10/10 alive) names the comparators "Sham" and "Naïve" (Q3)'),
 ('3', 'S06-B', 'S06!G3:K30', 'Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 3', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', ''),
 ('4', 'S06-A', 'S06!A3:E30', 'Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 14', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', ''),
 ('5', 'S06-E (rows 34–68)', 'S06!G34:L68', 'Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 60', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'Weight table S15-E: PSLN-344 6/7, PSLN-212 1/7 (Q2). Untreated sentinels 6/7'),
 ('6', 'S06-D', 'S06!A34:E61', 'Bivalent vaccine → 5× mLD50 rgH5N1, day 3', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'Table identical to S06-C in all four groups (Q1). Weight table S15-D: PSLN-344 5/7, young 5/7 (Q2)'),
 ('7', 'S15-H', 'S15!A73:D93', 'Bivalent vaccine ± PSLN-344 → 5× mLD50 rgH5N1, day 3', '3d Vaccine', None, '3d Vaccine+PSLN-344', None, 'Control column = vaccine alone (no liposome). PSLN-344 alone, no vaccine: 0/7'),
 ('8', 'S06-C', 'S06!M3:Q30', 'Bivalent vaccine → 5× mLD50 rgH5N1, day 14', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'Weight table S15-C: PSLN-212 1/7 (Q2); its PSLN-344 series duplicates S15-I (Q4)'),
 ('9', 'S06-F (rows 34–68)', 'S06!M34:R68', 'Bivalent vaccine → 5× mLD50 rgH5N1, day 60', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'Untreated sentinels 7/7'),
 ('10', 'S06-G', 'S06!A71:F105', 'CA09 H1N1 vaccine → 5× mLD50 Perth H3N2, day 60', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'Weight table S15-G: PSLN-344 5/7 (Q2). Untreated sentinels 4/7'),
 ('11', 'S06-E (rows 71–98)', 'S06!G71:K98', '14-month-old, not imprinted: bivalent vaccine → 5× LD50 PR8', None, 'Naïve+PSLN-212', 'Naïve+PSLN-344', None, 'Challenge day not stated'),
 ('12', 'S06-E (rows 71–98)', 'S06!G71:K98', '14-month-old, PR8-imprinted: bivalent vaccine → 5× LD50 PR8', None, 'Imprinting+PSLN-212', 'Imprinting+PSLN-344', None, 'Prior PR8 infection itself protects against PR8; no imprinted-only control'),
 ('13', 'S06-F (rows 71–98)', 'S06!M71:Q98', '14-month-old, not imprinted: bivalent vaccine → 5× LD50 Perth H3N2, day 14', None, 'Naïve+PSLN-212', 'Naïve+PSLN-344', None, ''),
 ('14', 'S06-F (rows 71–98)', 'S06!M71:Q98', '14-month-old, PR8-imprinted: bivalent vaccine → 5× LD50 Perth H3N2, day 14', None, 'Imprinting+PSLN-212', 'Imprinting+PSLN-344', None, ''),
 ('15', 'S15-L', 'S15!A103:E130', 'Aged C57BL/6 (20 months), bivalent vaccine; challenge virus and day not stated', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'Weight table S15-M: young 7/7 (Q2); PSLN-344 weight series shares values with S15-A (Q4)'),
 ('16', 'S15-N', 'S15!A134:E161', 'Aged Swiss Webster (20 months), bivalent vaccine; challenge virus and day not stated', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344 weight series shares values with S15-A/S15-M (Q4)'),
]
bmap = {'S06-E (rows 34–68)': 'S06-E_r34', 'S06-F (rows 34–68)': 'S06-F_r34', 'S06-E (rows 71–98)': 'S06-E_r71', 'S06-F (rows 71–98)': 'S06-F_r71'}
lines = ['| # | Block (cells) | Vaccine → challenge, day of challenge after immunisation | Sham | PSLN-212 | **PSLN-344** | Young + PSLN-212 | Log-rank p, 344 vs 212 | Caveat (integrity-log item) |', '|---|---|---|---|---|---|---|---|---|']
for i, blk, cells, design, sh, p2, p3, y, note in T1:
    bid = bmap.get(blk, blk)
    p = fp(lr(bid, p3, p2)) if p2 else '—'
    lines.append(f"| {i} | {blk} ({cells}) | {design} | {sc(bid, sh) if sh else '—'} | {sc(bid, p2) if p2 else '—'} | **{sc(bid, p3)}** | {sc(bid, y) if y else '—'} | {p} | {note} |")
open('table1_efficacy.md', 'w').write('\n'.join(lines))
print('\n'.join(lines))

# ---------------- Table 2: immune read-outs ----------------
def V(bid, g, ti=None):
    b = B[bid]; v = b['groups'][g]['values'] if b['kind'] == 'groups' else b['groups'][g]['matrix'][ti]
    return np.array([x for x in v if x is not None], float)
def summ(bid, g, ti, log, lod):
    v = V(bid, g, ti)
    if lod: v = np.where(v < lod, lod/2, v)
    return 10**np.log10(v).mean() if log else v.mean()
def tuk(bid, g1, g2, ti, log, lod):
    data = {}
    for g in B[bid]['groups']:
        v = V(bid, g, ti)
        if lod: v = np.where(v < lod, lod/2, v)
        data[g] = np.log10(v) if log else v
    allv = np.concatenate(list(data.values())); lab = np.concatenate([[g]*len(v) for g, v in data.items()])
    res = pairwise_tukeyhsd(allv, lab)
    for r in res.summary().data[1:]:
        if {r[0], r[1]} == {g1, g2}: return float(r[3])
def f3(x):
    if x >= 1000: return f'{x:,.0f}'
    if x >= 100: return f'{x:.0f}'
    if x >= 10: return f'{x:.1f}'
    return f'{x:.2g}' if x < 1 else f'{x:.1f}'
T2 = [
 # group header or (label, block, ti, log, lod, ctrl, unit)
 'Innate response in the lung',
 ('Ifnb1 mRNA, 16 h, fold (nanoparticle alone)', 'S01-A_16h', None, True, None, 'Sham', 'GM'),
 ('Monocytes, day 4, %', 'S01-D', 2, False, None, 'Sham', 'mean'),
 ('CD11b+ dendritic cells, day 4, %', 'S01-E', 2, False, None, 'Sham', 'mean'),
 ('cDC1, 72 h, %', 'S01-F', 0, False, None, 'Sham', 'mean'),
 ('Migratory CCR7+ CD11b+ DC, 72 h, %', 'S02-A', None, False, None, 'Sham', 'mean'),
 ('Antigen-carrying DC in lymph node, 36 h, %', 'S02-C', None, False, None, None, 'mean'),
 ('CD40+ lymph-node CD11b+ DC, day 3, %', 'S02-D_CD40', None, False, None, 'Sham', 'mean'),
 ('CD86+ lymph-node CD11b+ DC, day 3, %', 'S02-D_CD86', None, False, None, 'Sham', 'mean'),
 ('CD206+ macrophages, %', 'S11-E', None, False, None, 'Sham', 'mean'),
 'CD8 T cells',
 ('Lung Ki-67+ CD8, day 3, %', 'S05-D', None, False, None, 'Sham', 'mean'),
 ('Lung granzyme B+ CD8, day 3, %', 'S05-E', None, False, None, 'Sham', 'mean'),
 ('IFN-γ+ CD8 to rgH5N1 restimulation, day 14, %', 'S05-F', None, False, None, 'Sham', 'mean'),
 ('IFN-γ+ CD8 to rgH5N1 restimulation, day 60, %', 'S05-G', None, False, None, 'Sham', 'mean'),
 ('Lung resident-memory CD8, day 25, %', 'S05-I', None, False, None, 'Sham', 'mean'),
 ('Lung regulatory T cells, day 7, % (n = 3)', 'S04-D', None, False, None, 'Sham', 'mean'),
 'Antibody and germinal centre',
 ('Serum IgG anti-CA09, day 14, titre', 'S03-A', None, True, None, 'Sham', 'GM'),
 ('Serum IgG anti-Aichi, day 14, titre', 'S03-E', None, True, None, 'Sham', 'GM'),
 ('HAI anti-CA09, day 14, titre', 'S03-C', None, True, 10, 'Sham', 'GM'),
 ('HAI anti-Aichi, day 14, titre', 'S03-G', None, True, 10, 'Sham', 'GM'),
 ('Neutralising anti-CA09, day 14, titre', 'S03-D', None, True, None, 'Sham', 'GM'),
 ('Neutralising anti-Aichi, day 14, titre', 'S03-H', None, True, None, 'Sham', 'GM'),
 ('Germinal-centre B cells, day 7, %', 'S03-K', None, False, None, 'Sham', 'mean'),
 ('T follicular helper (ICOS-high), day 7, %', 'S04-A_ICOShi', None, False, None, 'Sham', 'mean'),
 ('T follicular regulatory, day 7, %', 'S04-B_Foxp3', None, False, None, 'Sham', 'mean'),
]
lines = ['| Read-out (summary statistic) | Block | Sham | PSLN-212 aged | **PSLN-344 aged** | PSLN-212 young | 344 vs 212 aged (Tukey p) | 344 aged vs young (Tukey p) | Age gap closed |', '|---|---|---|---|---|---|---|---|---|']
for it in T2:
    if isinstance(it, str):
        lines.append(f'| **{it}** | | | | | | | | |'); continue
    lab, bid, ti, log, lod, ctrl, st = it
    a, m, y = summ(bid, 'PSLN-212', ti, log, lod), summ(bid, 'PSLN-344', ti, log, lod), summ(bid, 'PSLN-212(Y)', ti, log, lod)
    c = f3(summ(bid, ctrl, ti, log, lod)) if ctrl else '—'
    if log:
        e1 = f'{m/a:.1f}× ({fp(tuk(bid, "PSLN-212", "PSLN-344", ti, log, lod))})'; e2 = f'{m/y:.2f}× ({fp(tuk(bid, "PSLN-344", "PSLN-212(Y)", ti, log, lod))})'
        r = (np.log10(m) - np.log10(a)) / (np.log10(y) - np.log10(a))
    else:
        e1 = f'{m-a:+.1f} pts ({fp(tuk(bid, "PSLN-212", "PSLN-344", ti, log, lod))})'; e2 = f'{m-y:+.1f} pts ({fp(tuk(bid, "PSLN-344", "PSLN-212(Y)", ti, log, lod))})'
        r = (m - a) / (y - a)
    blk = bid.replace('_16h', ' (16 h panel)').replace('_CD40', ' CD40').replace('_CD86', ' CD86').replace('_ICOShi', ' (ICOS-high)').replace('_Foxp3', ' (Foxp3)')
    e1 = e1.replace('-', '−'); e2 = e2.replace('-', '−')
    lines.append(f'| {lab} ({st}) | {blk} | {c} | {f3(a)} | **{f3(m)}** | {f3(y)} | {e1} | {e2} | {r:.2f} |')
open('table2_immune.md', 'w').write('\n'.join(lines))
print(); print('\n'.join(lines))

"""Body-weight blocks: per-animal classification (alive / died), handling carried-forward (frozen) values,
per-animal nadir (using only genuinely measured values), survivor-only group means, and comparison with the paired survival table."""
import json, numpy as np, pandas as pd
from scipy import stats
B = json.load(open('blocks.json'))
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 600)
PAIRS = {'S15-A':'S06-A','S15-B':'S06-B','S15-C':'S06-C','S15-D':'S06-D','S15-E':'S06-E_r34','S15-F':'S06-F_r34','S15-G':'S06-G',
 'S15-I':'S15-H','S15-J':'S06-E_r71','S15-K':'S06-F_r71','S15-M':'S15-L','S15-O':'S15-N','S09-C':'S09-B','S09-E':'S09-D','S09-G':'S09-F','S13-F':'S03-I','S13-G':'S03-J'}
def classify(traj, times):
    last_i = max(i for i, v in enumerate(traj) if v is not None)
    if last_i < len(traj) - 1:
        return 'dead', times[last_i], last_i      # blank after last weight
    k = len(traj) - 1
    while k > 0 and traj[k-1] == traj[-1]:
        k -= 1
    run = len(traj) - k
    if (run >= 3) or (run >= 2 and traj[-1] <= 90):
        return 'dead', times[k], k                # value carried forward from times[k]
    return 'alive', None, len(traj) - 1
rows = []
for wid, sid in PAIRS.items():
    w = B[wid]; times = w['times']
    for g in w['order']:
        mat = np.array([[np.nan if v is None else v for v in row] for row in w['groups'][g]['matrix']], float)
        for j in range(mat.shape[1]):
            traj = [None if np.isnan(v) else float(v) for v in mat[:, j]]
            st, tlast, k = classify(traj, times)
            measured = [v for v in traj[:k+1] if v is not None]
            rows.append(dict(wblock=wid, sblock=sid, group=g.strip(), animal=j+1, state=st, last_measured_day=(tlast if st == 'dead' else 14),
                             nadir=min(measured), nadir_day=times[int(np.argmin(measured))], d14=(traj[-1] if st == 'alive' else np.nan)))
A = pd.DataFrame(rows)
A.to_csv('bw_per_animal.csv', index=False)
# group summary
def gs(d):
    alive = d[d.state == 'alive']
    return pd.Series(dict(n=len(d), alive_bw=int((d.state == 'alive').sum()),
        nadir_all_mean=d.nadir.mean(), nadir_surv_mean=alive.nadir.mean() if len(alive) else np.nan,
        nadir_surv_min=alive.nadir.min() if len(alive) else np.nan,
        maxloss_surv_mean=(100 - alive.nadir).mean() if len(alive) else np.nan,
        n_surv_loss_ge15=int(((100 - alive.nadir) >= 15).sum()), n_surv_loss_ge20=int(((100 - alive.nadir) >= 20).sum()),
        d14_surv_mean=alive.d14.mean() if len(alive) else np.nan))
G = A.groupby(['wblock', 'sblock', 'group'], sort=False).apply(gs).reset_index()
# add survival-table counts
def surv_count(sid, g):
    s = B[sid]
    for cand in s['order']:
        if cand.strip().replace('(Y)', 'Y') == g.replace('(Y)', 'Y'):
            r = [x for x in s['groups'][cand]['records']]
            return f"{sum(x['status']==0 for x in r)}/{len(r)}"
    return 'n/a'
G['surv_table'] = [surv_count(s, g) for s, g in zip(G.sblock, G.group)]
G['bw_alive'] = G.alive_bw.astype(int).astype(str) + '/' + G.n.astype(int).astype(str)
G['concordant'] = np.where(G.surv_table == 'n/a', 'label absent', np.where(G.surv_table == G.bw_alive, 'yes', 'NO'))
print(G[['wblock','sblock','group','surv_table','bw_alive','concordant','nadir_surv_mean','nadir_surv_min','maxloss_surv_mean','n_surv_loss_ge15','n_surv_loss_ge20','d14_surv_mean']].to_string(index=False, float_format=lambda x: f'{x:.1f}'))
G.to_csv('bw_group_summary.csv', index=False)

import json
B = json.load(open('blocks.json'))
PAIRS = {  # weights block -> survival block (per annotation "the animals of ...")
 'S15-A':'S06-A','S15-B':'S06-B','S15-C':'S06-C','S15-D':'S06-D','S15-E':'S06-E_r34','S15-F':'S06-F_r34','S15-G':'S06-G',
 'S15-I':'S15-H','S15-J':'S06-E_r71','S15-K':'S06-F_r71','S15-M':'S15-L','S15-O':'S15-N',
 'S09-C':'S09-B','S09-E':'S09-D','S09-G':'S09-F','S13-F':'S03-I','S13-G':'S03-J'}
def classify(traj, times):
    """returns (state, detail). state in alive / blank-death / frozen-death"""
    vals = traj
    last_i = max(i for i, v in enumerate(vals) if v is not None)
    if last_i < len(vals) - 1:
        return 'dead(blank)', f'last weight d{times[last_i]}={vals[last_i]}'
    # frozen tail?
    k = len(vals) - 1
    while k > 0 and vals[k-1] == vals[-1]:
        k -= 1
    run = len(vals) - k
    if (run >= 3) or (run >= 2 and vals[-1] <= 90):
        return 'dead(frozen)', f'value {vals[-1]} constant from d{times[k]} ({run} readings)'
    return 'alive', f'd14={vals[-1]}'
out = {}
for wb_id, sv_id in PAIRS.items():
    w = B[wb_id]; s = B[sv_id]
    times = w['times']
    print(f'\n=== {wb_id} (weights)  vs  {sv_id} (survival)   [{w["measurand"]}]')
    for g in w['order']:
        mat = w['groups'][g]['matrix']
        n = len(mat[0])
        states = []
        for j in range(n):
            traj = [mat[i][j] for i in range(len(times))]
            st, det = classify(traj, times)
            nadir = min(v for v in traj if v is not None)
            states.append((st, det, nadir))
        n_dead = sum(st.startswith('dead') for st, _, _ in states)
        n_alive = n - n_dead
        # match group in survival
        sg = None
        for cand in s['order']:
            if cand.strip().replace('(Y)','Y') == g.strip().replace('(Y)','Y'):
                sg = cand
        if sg:
            recs = s['groups'][sg]['records']
            ev = sum(r['status'] == 1 for r in recs); nn = len(recs)
            days = sorted(r['day'] for r in recs if r['status'] == 1)
            cmp_ = f'survival table: {nn-ev}/{nn} survive; death days {days}'
            flag = '' if (n_alive == nn-ev and n == nn) else '   <<< MISMATCH'
        else:
            cmp_ = 'survival table: (no group with this label)'; flag = '   <<< LABEL NOT IN SURVIVAL TABLE'
        print(f'  {g:22s} weights: {n_alive}/{n} alive at d14 | {cmp_}{flag}')
        for j, (st, det, nadir) in enumerate(states):
            if st != 'alive':
                print(f'       animal {j+1}: {st:13s} {det}; nadir {nadir}')
        out[(wb_id, g)] = dict(n=n, alive=n_alive, states=states)
    extra = [c for c in s['order'] if c.strip().replace('(Y)','Y') not in [g.strip().replace('(Y)','Y') for g in w['order']]]
    if extra:
        for e in extra:
            recs = s['groups'][e]['records']; ev = sum(r['status']==1 for r in recs)
            print(f'  [survival-only group] {e}: {len(recs)-ev}/{len(recs)} survive; death days {sorted(r["day"] for r in recs if r["status"]==1)}   <<< NOT IN WEIGHT TABLE')

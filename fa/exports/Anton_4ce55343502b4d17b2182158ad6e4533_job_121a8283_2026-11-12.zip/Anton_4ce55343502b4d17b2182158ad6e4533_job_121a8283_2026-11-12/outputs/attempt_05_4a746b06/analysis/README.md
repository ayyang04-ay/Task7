# Analysis files

Everything in the memo can be regenerated from the workbook with `./run_all.sh`
(uses the `singlecell` and `core` micromamba environments; set `PSLN_WORKBOOK` and `PSLN_FIGDIR` to change paths).

| Step | Script | Output |
|---|---|---|
| Read the workbook, block by block, by cell range | `parse_blocks.py` | `blocks.json`; prints a coverage check (every numeric cell is read) |
| Stated n against observed n | `audit_n.py` | `audit_n.txt` |
| Survival tables against body-weight tables, per animal | `audit_bw.py`, `bw_analysis.py` | `audit_bw.txt`, `bw_per_animal.csv`, `bw_group_summary.csv` |
| Re-used values between blocks; identical survival tables | `audit_dup.py`, `audit_dup2.py`, `audit_dup3.py`, `surv_dups.py`, `integrity_quant.py` | `*.txt` |
| Printed IgG2a/IgG1 against raw titres; which S09-A panel is 72 h | `check_ratio.py`, `check_s09a.py` | `*.txt` |
| Survival: per arm, pairwise, pooled, stratified, sensitivity, exact permutation p-values | `surv_analysis.py`, `pooled_survival.py`, `sensitivity.py`, `verify_lr.py`, `exact_lr.py` | `survival_summary.csv`, `survival_pairwise.csv`, `efficacy_table.csv`, `*.txt` |
| Immune read-outs: summaries, ANOVA/Tukey, Welch | `immuno_analysis.py`, `key_contrasts.py`, `misc_checks.py` | `immuno_summary.csv`, `immuno_tests.csv`, `key_contrasts.csv` |
| Tolerability, CNS, dose-response, encapsulation | `safety_analysis.py` | `safety_analysis.txt` |
| Arm-level biomarker screen | `biomarker_screen.py` | `biomarker_screen.csv` |
| Sample-size calculations for the proposed studies | `power.py` | `power.txt` |
| Evidence ledger and block directory | `ledger.py`, `block_directory.py` | `evidence_ledger.csv`, `block_directory.csv` (the copies delivered are one level up) |
| Tables 1 and 2 of the memo | `make_tables.py` | `table1_efficacy.md`, `table2_immune.md` |
| Figures | `figs.py`, `figs2.py`, `figs3.py`, `figs4.py` | `../figures/*.png`, `restoration_index.csv` |
| Independent spot-check of 77 headline numbers straight from cell addresses | `spot_check.py` | `spot_check.txt` |

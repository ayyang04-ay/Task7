"""Builds the evidence ledger: every number used in the memo, with block, cell range, reduction rule and value.
Reduction rules (referenced by code):
 R1  survival: Prism-style table; status 1 = death, 0 = alive/censored at that day. Survival = censored/(rows with a day). Exact (Clopper-Pearson) 95% CI. Log-rank (Mantel-Cox) as stated in annotation; Fisher exact as check.
 R2  titres (ELISA endpoint, HAI, neutralisation): log10-transform, geometric mean (GMT) with t-based 95% CI; HAI '0' = below the lowest dilution tested (1:10) -> set to 5 (LOD/2). Tests on log10 scale.
 R3  qPCR fold-change (linear, relative to untreated): log10-transform, geometric mean fold; tests on log10 scale.
 R4  qPCR stored as log10 (S09-A): mean of log10 values, back-transformed (10^mean) = geometric mean fold.
 R5  percentages / counts (flow cytometry, encapsulation): arithmetic mean, SD; tests on linear scale.
 R6  body weight: per-animal; values carried forward unchanged to day 14 (>=3 identical terminal readings, or >=2 at <=90%) are treated as death (not as observations); blanks = death. Nadir per animal uses measured values only. Group figures are for animals alive at day 14.
 R7  one-way ANOVA + Tukey HSD across all groups of the block (as stated in the annotation); Welch t-test for two-group blocks and as a robustness check.
 R8  pooled counts across experiments are descriptive; inferential pooling uses log-rank stratified by experiment.
"""
import json, numpy as np, pandas as pd, warnings
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from lifelines.statistics import logrank_test
warnings.filterwarnings('ignore')
B = json.load(open('blocks.json'))
L = []
def add(id_, statement, value, block, cells, rule):
    L.append(dict(id=id_, statement=statement, value=value, block=block, cells=cells, reduction=rule))

# ---------- helpers ----------
def recs(bid, g):
    r = [x for x in B[bid]['groups'][g]['records'] if x['day'] is not None]
    return np.array([x['day'] for x in r], float), np.array([x['status'] for x in r], int)
def cells(bid, g): return B[bid]['groups'][g]['cells']
def surv(bid, g):
    t, e = recs(bid, g); n = len(e); s = int(n - e.sum())
    lo, hi = proportion_confint(s, n, method='beta')
    return s, n, 100*lo, 100*hi, sorted(int(x) for x, ev in zip(t, e) if ev)
def lr(bid, g1, g2):
    t1, e1 = recs(bid, g1); t2, e2 = recs(bid, g2)
    return logrank_test(t1, t2, e1, e2).p_value
def vals(bid, g, ti=None):
    b = B[bid]
    v = b['groups'][g]['values'] if b['kind'] == 'groups' else b['groups'][g]['matrix'][ti]
    return np.array([x for x in v if x is not None], float)
def gm(bid, g, ti=None, lod=None):
    v = vals(bid, g, ti)
    if lod: v = np.where(v < lod, lod/2, v)
    x = np.log10(v); m = x.mean(); se = x.std(ddof=1)/np.sqrt(len(x)); tc = stats.t.ppf(.975, len(x)-1)
    return 10**m, 10**(m-tc*se), 10**(m+tc*se), len(x)
def am(bid, g, ti=None):
    v = vals(bid, g, ti); return v.mean(), v.std(ddof=1), len(v)
def tukey(bid, g1, g2, ti=None, log=False, lod=None):
    b = B[bid]; data = {}
    for g in b['groups']:
        v = vals(bid, g, ti)
        if lod: v = np.where(v < lod, lod/2, v)
        data[g] = np.log10(v) if log else v
    allv = np.concatenate(list(data.values())); lab = np.concatenate([[g]*len(v) for g, v in data.items()])
    res = pairwise_tukeyhsd(allv, lab)
    for r in res.summary().data[1:]:
        if {r[0], r[1]} == {g1, g2}: return float(r[3])
def welch(bid, g1, g2, ti=None, log=False, lod=None):
    a, b_ = vals(bid, g1, ti), vals(bid, g2, ti)
    if lod: a = np.where(a < lod, lod/2, a); b_ = np.where(b_ < lod, lod/2, b_)
    if log: a, b_ = np.log10(a), np.log10(b_)
    return stats.ttest_ind(a, b_, equal_var=False).pvalue
def fmt_p(p):
    return '<0.0001' if p < 1e-4 else (f'{p:.4f}' if p < 0.01 else f'{p:.3f}')

# ================= A. survival =================
EXPS = [
 ('S03-I','bivalent vaccine -> 10x mLD50 CA09 H1N1, d14 (homologous)', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)', CMP204='CMP-204')),
 ('S03-J','rgH5N1 vaccine -> wild-type VN04 H5N1, d2',                 dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344')),
 ('S06-A','Aichi H3N2 vaccine -> 5x mLD50 PR8 H1N1, d14',              dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S06-B','Aichi H3N2 vaccine -> 5x mLD50 PR8 H1N1, d3',               dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S06-C','bivalent vaccine -> 5x mLD50 rgH5N1, d14',                  dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S06-D','bivalent vaccine -> 5x mLD50 rgH5N1, d3',                   dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S06-E_r34','Aichi H3N2 vaccine -> 5x mLD50 PR8 H1N1, d60',          dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)', Untreated='Untreated')),
 ('S06-F_r34','bivalent vaccine -> 5x mLD50 rgH5N1, d60',              dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)', Untreated='Untreated')),
 ('S06-G','CA09 H1N1 vaccine -> 5x mLD50 Perth H3N2, d60',             dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)', Untreated='Untreated')),
 ('S06-E_r71','14-month-old, not imprinted: bivalent -> 5x LD50 PR8',  dict(P212='Naïve+PSLN-212', P344='Naïve+PSLN-344')),
 ('S06-E_r71','14-month-old, PR8-imprinted: bivalent -> 5x LD50 PR8',  dict(P212='Imprinting+PSLN-212', P344='Imprinting+PSLN-344')),
 ('S06-F_r71','14-month-old, not imprinted: bivalent -> 5x LD50 Perth H3N2, d14', dict(P212='Naïve+PSLN-212', P344='Naïve+PSLN-344')),
 ('S06-F_r71','14-month-old, PR8-imprinted: bivalent -> 5x LD50 Perth H3N2, d14', dict(P212='Imprinting+PSLN-212', P344='Imprinting+PSLN-344')),
 ('S15-H','bivalent vaccine +/- PSLN-344 -> 5x mLD50 rgH5N1, d3',      dict(P344='3d Vaccine+PSLN-344', VaxOnly='3d Vaccine', AdjOnly='3d PSLN-344')),
 ('S15-L','aged C57BL/6 (20 mo), bivalent vaccine; challenge not stated', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
 ('S15-N','aged Swiss Webster (20 mo), bivalent vaccine; challenge not stated', dict(Sham='Sham', P212='PSLN-212', P344='PSLN-344', Young='PSLN-212(Y)')),
]
k = 0
tot = {}
for bid, lab, arms in EXPS:
    k += 1
    for arm, g in arms.items():
        s, n, lo, hi, dd = surv(bid, g)
        add(f'A{k:02d}-{arm}', f'{lab} | {arm} ({g}): survivors/evaluable', f'{s}/{n} ({100*s/n:.0f}%; 95% CI {lo:.0f}-{hi:.0f}); death days {dd}', bid, cells(bid, g), 'R1')
        tot.setdefault(arm, []).append((bid, lab, s, n))
    if 'P212' in arms:
        add(f'A{k:02d}-p', f'{lab} | log-rank PSLN-344 vs PSLN-212', fmt_p(lr(bid, arms['P344'], arms['P212'])), bid, '', 'R1')
    if 'Sham' in arms:
        add(f'A{k:02d}-ps', f'{lab} | log-rank PSLN-344 vs Sham', fmt_p(lr(bid, arms['P344'], arms['Sham'])), bid, '', 'R1')
for arm in ['Sham', 'P212', 'P344', 'Young']:
    s = sum(x[2] for x in tot[arm]); n = sum(x[3] for x in tot[arm]); lo, hi = proportion_confint(s, n, method='beta')
    add(f'A-pool-{arm}', f'Pooled survival, all aged-program comparisons, arm {arm} ({len(tot[arm])} comparisons)', f'{s}/{n} = {100*s/n:.1f}% (95% CI {100*lo:.1f}-{100*hi:.1f})', '; '.join(sorted(set(x[0] for x in tot[arm]))), 'sum of per-block counts above', 'R1,R8')
    s2 = sum(x[2] for x in tot[arm] if x[0] != 'S06-D'); n2 = sum(x[3] for x in tot[arm] if x[0] != 'S06-D'); lo, hi = proportion_confint(s2, n2, method='beta')
    add(f'A-pool1-{arm}', f'Pooled survival counting the identical S06-C/S06-D tables once, arm {arm}', f'{s2}/{n2} = {100*s2/n2:.1f}% (95% CI {100*lo:.1f}-{100*hi:.1f})', 'as above minus S06-D', '', 'R1,R8')
# young-animal programme
for bid in ['S09-B', 'S09-D', 'S09-F']:
    for g in B[bid]['order']:
        s, n, lo, hi, dd = surv(bid, g)
        add(f'A-young-{bid}-{g}', f'{B[bid]["measurand"]} | {g}', f'{s}/{n}; death days {dd}', bid, cells(bid, g), 'R1')
for g in B['S13-E']['order']:
    s, n, lo, hi, dd = surv('S13-E', g)
    add(f'A-young-S13-E-{g}', f'{B["S13-E"]["measurand"]} | {g}', f'{s}/{n}; death days {dd}', 'S13-E', cells('S13-E', g), 'R1')
# antigen requirement
add('A-antigen-p', 'S15-H log-rank vaccine+PSLN-344 vs PSLN-344 alone; vs vaccine alone; PSLN-344 alone vs vaccine alone', f"{fmt_p(lr('S15-H','3d Vaccine+PSLN-344','3d PSLN-344'))}; {fmt_p(lr('S15-H','3d Vaccine+PSLN-344','3d Vaccine'))}; {fmt_p(lr('S15-H','3d PSLN-344','3d Vaccine'))}", 'S15-H', 'S15!A73:D93', 'R1')
# untreated
d = n = 0
for bid in ['S06-E_r34', 'S06-F_r34', 'S06-G']:
    s, nn, lo, hi, dd = surv(bid, 'Untreated'); d += nn - s; n += nn
lo, hi = proportion_confint(d, n, method='beta')
add('A-untreated', 'Unchallenged, unvaccinated aged sentinels dying within the 14-day window (3 blocks pooled)', f'{d}/{n} = {100*d/n:.0f}% (95% CI {100*lo:.0f}-{100*hi:.0f})', 'S06-E_r34; S06-F_r34; S06-G', 'S06!L62:L68; S06!R62:R68; S06!F99:F105', 'R1,R8')
add('A-d60-vs-untreated', 'Aged PSLN-344 survival after d60 challenge (3 blocks) vs unchallenged sentinels; Fisher exact', f"14/21 vs 17/21; p = {stats.fisher_exact([[14,7],[17,4]])[1]:.2f}", 'S06-E_r34; S06-F_r34; S06-G', '', 'R1,R8')
add('A-durability', 'Aged PSLN-344: survival when challenged at d14 (S03-I, S06-A, S06-C) vs d60 (S06-E, S06-F, S06-G); Fisher exact', f"20/21 vs 14/21; p = {stats.fisher_exact([[20,1],[14,7]])[1]:.3f}", 'S03-I; S06-A; S06-C; S06-E_r34; S06-F_r34; S06-G', '', 'R1,R8')
add('A-durability-same-virus', 'Aged PSLN-344, same vaccine/virus pairs (PR8, rgH5N1): d14 vs d60; Fisher exact', f"13/14 vs 10/14; p = {stats.fisher_exact([[13,1],[10,4]])[1]:.2f}", 'S06-A; S06-C; S06-E_r34; S06-F_r34', '', 'R1,R8')
add('A-d60-young', 'd60 challenge: young PSLN-212 vs aged PSLN-344 (3 blocks); Fisher exact', f"21/21 vs 14/21; p = {stats.fisher_exact([[21,0],[14,7]])[1]:.4f}", 'S06-E_r34; S06-F_r34; S06-G', '', 'R1,R8')

# ================= B. immune read-outs (4 canonical arms) =================
def four(id_, bid, desc, kind, ti=None, lod=None, ctrl='Sham'):
    arms = list(B[bid]['order'])
    out = []
    for a in arms:
        if kind == 'gm':
            c, lo, hi, n = gm(bid, a, ti, lod); out.append(f'{a} {c:.3g} [{lo:.3g}-{hi:.3g}] n={n}')
        else:
            m, sd, n = am(bid, a, ti); out.append(f'{a} {m:.3g} (SD {sd:.2g}) n={n}')
    rng_ = '; '.join(f'{a}: {cells(bid, a)}' for a in arms)
    add(id_, desc + (' | GM [95% CI]' if kind == 'gm' else ' | mean (SD)'), ' | '.join(out), bid, rng_, {'gm': 'R2/R3', 'am': 'R5'}[kind])
    y = 'PSLN-212(Y)' if 'PSLN-212(Y)' in arms else ('PSLN-212Y' if 'PSLN-212Y' in arms else None)
    if 'PSLN-212' in arms and 'PSLN-344' in arms:
        log = kind == 'gm'
        if log:
            eff = gm(bid, 'PSLN-344', ti, lod)[0] / gm(bid, 'PSLN-212', ti, lod)[0]; es = f'{eff:.3g}-fold'
        else:
            eff = am(bid, 'PSLN-344', ti)[0] - am(bid, 'PSLN-212', ti)[0]; es = f'{eff:+.3g} points'
        pt = tukey(bid, 'PSLN-212', 'PSLN-344', ti, log, lod) if len(arms) > 2 else float('nan')
        pw = welch(bid, 'PSLN-212', 'PSLN-344', ti, log, lod)
        s = f'PSLN-344 vs PSLN-212: {es}; Tukey p={fmt_p(pt)}; Welch p={fmt_p(pw)}'
        if y:
            if log:
                e2 = gm(bid, 'PSLN-344', ti, lod)[0] / gm(bid, y, ti, lod)[0]; es2 = f'{e2:.2f}x of young'
                rest = (np.log10(gm(bid, 'PSLN-344', ti, lod)[0]) - np.log10(gm(bid, 'PSLN-212', ti, lod)[0])) / (np.log10(gm(bid, y, ti, lod)[0]) - np.log10(gm(bid, 'PSLN-212', ti, lod)[0]))
            else:
                e2 = am(bid, 'PSLN-344', ti)[0] - am(bid, y, ti)[0]; es2 = f'{e2:+.3g} points vs young'
                rest = (am(bid, 'PSLN-344', ti)[0] - am(bid, 'PSLN-212', ti)[0]) / (am(bid, y, ti)[0] - am(bid, 'PSLN-212', ti)[0])
            s += f' || PSLN-344 vs young PSLN-212: {es2}; Tukey p={fmt_p(tukey(bid, "PSLN-344", y, ti, log, lod))}; Welch p={fmt_p(welch(bid, "PSLN-344", y, ti, log, lod))} || fraction of age gap closed = {rest:.2f}'
        add(id_ + '-c', desc + ' | contrasts', s, bid, '', 'R7')
four('B01', 'S01-A_16h', 'Lung Ifnb1 fold, 16 h (nanoparticle alone, 20 ug)', 'gm')
four('B02', 'S01-A_72h', 'Lung Ifnb1 fold, 72 h', 'gm')
for i, t in enumerate(B['S02-F']['times']): four(f'B03-{t}', 'S02-F', f'Lung Gm-csf fold, {t}', 'gm', ti=i)
for i, t in enumerate(B['S01-D']['times']): four(f'B04-d{t}', 'S01-D', f'Lung monocytes %, day {t}', 'am', ti=i)
for i, t in enumerate(B['S01-E']['times']): four(f'B05-d{t}', 'S01-E', f'Lung CD11b+ DC %, day {t}', 'am', ti=i)
four('B06', 'S01-F', 'Lung cDC1 %, 72 h', 'am', ti=0); four('B07', 'S01-G', 'Lung cDC2 %, 72 h', 'am', ti=0)
four('B08', 'S02-A', 'Lung migratory CCR7+ CD11b+ DC %, 72 h', 'am'); four('B09', 'S02-B', 'MLN CD11b+CD103- DC %, 72 h', 'am')
four('B10', 'S02-C', 'MLN antigen(OVA-AF647)+ DC %, 36 h', 'am', ctrl='PTX'); four('B11', 'S02-D_CD40', 'CD40+ of MLN CD11b+ DC %, d3', 'am'); four('B12', 'S02-D_CD86', 'CD86+ of MLN CD11b+ DC %, d3', 'am')
four('B13', 'S02-E', 'OT-I proliferation % with sorted MLN CD11b+ DC', 'am', ctrl='PTX')
four('C01', 'S03-A', 'Serum IgG anti-CA09 H1N1 titre, d14', 'gm'); four('C02', 'S03-E', 'Serum IgG anti-Aichi H3N2 titre, d14', 'gm')
four('C03', 'S03-C', 'HAI anti-CA09, d14', 'gm', lod=10); four('C04', 'S03-G', 'HAI anti-Aichi, d14', 'gm', lod=10)
four('C05', 'S03-D', 'Neutralising titre anti-CA09, d14', 'gm'); four('C06', 'S03-H', 'Neutralising titre anti-Aichi, d14', 'gm')
four('C07', 'S13-A', 'Serum IgG2a anti-CA09, d14', 'gm'); four('C08', 'S13-B', 'Serum IgG1 anti-CA09, d14', 'gm'); four('C09', 'S13-C', 'Serum IgG2a anti-Aichi, d14', 'gm'); four('C10', 'S13-D', 'Serum IgG1 anti-Aichi, d14', 'gm')
four('C11', 'S13-I', 'Serum IgG anti-CA09, d28 after d14 boost', 'gm'); four('C12', 'S13-J', 'Serum IgG anti-Aichi, d28 after d14 boost', 'gm')
four('C13', 'S03-K', 'MLN germinal-centre B cells %, d7', 'am'); four('C14', 'S04-A_ICOShi', 'MLN Tfh (ICOS-high) %, d7', 'am'); four('C15', 'S04-B_Foxp3', 'MLN Tfr (Foxp3+ of CXCR5+) %, d7', 'am')
four('C16', 'S04-C', 'MLN Tfr %, d30', 'am'); four('C17', 'S04-D', 'Lung Treg %, d7', 'am'); four('C18', 'S13-H', 'IgG+ of MLN B220+ %, timepoint not stated', 'am')
four('C19', 'S03-L_Aicda', 'Aicda fold in MLN B cells, d5', 'gm'); four('C20', 'S03-L_E47', 'E47 fold in MLN B cells, d5', 'gm')
four('D01', 'S05-D', 'Lung Ki67+ CD8 %, d3', 'am'); four('D02', 'S05-E', 'Lung GZMB+ CD8 %, d3', 'am'); four('D03', 'S05-F', 'MLN IFNg+ CD8 % d14 (rgH5N1 restim)', 'am')
four('D04', 'S05-G', 'MLN IFNg+ CD8 % d60 (rgH5N1 restim)', 'am'); four('D05', 'S05-H', 'MLN GZMB+ CD8 % d60', 'am'); four('D06', 'S05-I', 'Lung CD8 TRM % d25', 'am')
four('D07', 'S14-A_H1N1', 'MLN IFNg+ CD8 % (CA09 restim)', 'am'); four('D08', 'S14-A_H3N2', 'MLN IFNg+ CD8 % (Aichi restim)', 'am')
for i, t in enumerate(B['S05-A']['times']): four(f'D09-d{t}', 'S05-A', f'Lung NP366-374 tetramer+ of CD8 %, day {t} (n=2)', 'am', ti=i)
four('E01', 'S11-E', 'Lung CD206+ macrophages %', 'am')
for i, t in enumerate(B['S11-A']['times']): four(f'E02-d{t}', 'S11-A', f'Lung alveolar macrophages %, day {t}', 'am', ti=i, ctrl='Vaccine')
for i, t in enumerate(B['S07-A']['times']): four(f'E03-d{t}', 'S07-A', f'Lung Ly6C+CCR2+ macrophages (x10^5), day {t} (n=3)', 'am', ti=i)
# HAI >= 40
for bid, nm in [('S03-C', 'CA09'), ('S03-G', 'Aichi')]:
    s = ' | '.join(f"{g} {int((vals(bid, g) >= 40).sum())}/5" for g in B[bid]['order'])
    add(f'C-HAI40-{nm}', f'Animals with HAI >= 40 against {nm}, d14', s, bid, '; '.join(cells(bid, g) for g in B[bid]['order']), 'count of values >= 40')
# IgG2a/IgG1 from raw
for a_, b_, nm, printed in [('S13-A', 'S13-B', 'CA09', 'S03-B'), ('S13-C', 'S13-D', 'Aichi', 'S03-F')]:
    out = []
    for g in B[a_]['order']:
        r = vals(a_, g) / vals(b_, g); out.append(f'{g} mean {r.mean():.2f} (GM {10**np.log10(r).mean():.2f}; range {r.min():.2f}-{r.max():.2f})')
    add(f'C-ratio-{nm}', f'IgG2a/IgG1 per animal recomputed from raw subclass titres ({nm})', ' | '.join(out), f'{a_}/{b_}', '; '.join(f'{g}: {cells(a_, g)} / {cells(b_, g)}' for g in B[a_]['order']), 'per-animal quotient of raw titres, then mean')
    out = [f'"{g}" {vals(printed, g).mean():.2f}' for g in B[printed]['order']]
    add(f'C-ratio-{nm}-printed', f'IgG2a/IgG1 as printed in {printed} (column labels do not match raw data)', ' | '.join(out), printed, '; '.join(cells(printed, g) for g in B[printed]['order']), 'arithmetic mean of printed quotients')
# two-group mechanistic blocks
def two(id_, bid, g1, g2, desc, log=False):
    a, b_ = vals(bid, g1), vals(bid, g2)
    add(id_, desc, f'{g1} {a.mean():.3g} (SD {a.std(ddof=1):.2g}, n={len(a)}) vs {g2} {b_.mean():.3g} (SD {b_.std(ddof=1):.2g}, n={len(b_)}); Welch p={fmt_p(welch(bid, g1, g2, log=log))}', bid, f'{cells(bid, g1)}; {cells(bid, g2)}', 'R5,R7')
two('F01', 'S01-C', 'WT', 'SPA/D', 'DiD+ alveolar macrophages %, 16 h: WT vs Sftpa1-/-Sftpd-/-')
two('F02', 'S11-C', 'CBX-', 'CBX+', 'Recruited lung monocytes % d3 with PSLN-344: without vs with carbenoxolone')
two('F03', 'S07-B_mono', 'PSLN-344', 'PSLN-344+INCB3344', 'Lung CD11b+Ly6C+ monocytes % +/- CCR2 antagonist')
two('F04', 'S07-B_mac', 'PSLN-344', 'PSLN-344+INCB3344', 'Lung Ly6C+ macrophages % +/- CCR2 antagonist')
two('F05', 'S02-I', 'PSLN-344(Y)', 'PSLN-344(Y)+INCB3344', 'Lung GZMB+ CD8 % d5 (young) +/- CCR2 antagonist')
two('F06', 'S12-A', 'WT to WT', 'IFNAR-/- to WT', 'Infiltrating donor monocytes % d3: WT vs Ifnar-/- bone marrow (young, n=3)')
two('F07', 'S05-C', 'Lung', 'Lung+PTX', 'OT-I proliferation % in lung +/- pertussis toxin (n=3)')
two('F08', 'S05-C', 'MLN', 'MLN+PTX', 'OT-I proliferation % in MLN +/- pertussis toxin (n=3)')
two('F09', 'S07-C', 'Ly6C-CD206+ MΦ', 'Ly6C-CD206+ MΦ [col C]', 'Lung Treg % after macrophage transfer: column B vs column C (identical headers)')
for g in B['S02-G']['order']:
    m, sd, n = am('S02-G', g); add(f'F10-{g}', f'Lung Ly6C+ moDC % d5 | {g}', f'{m:.3g} (SD {sd:.2g}, n={n})', 'S02-G', cells('S02-G', g), 'R5')
add('F10-p', 'S02-G Tukey: PSLN-212+GM-CSF vs PSLN-212', fmt_p(tukey('S02-G', 'PSLN-212', 'PSLN-212+GM-CSF')), 'S02-G', '', 'R7')
for g in B['S02-H']['order']:
    m, sd, n = am('S02-H', g); add(f'F11-{g}', f'Donor-derived moDC % d3 | {g}', f'{m:.3g} (SD {sd:.2g}, n={n})', 'S02-H', cells('S02-H', g), 'R5')
add('F11-p', 'S02-H Tukey: WT w/o cDC vs IFN w/o cDC; IFN w/o cDC vs GMCSF', f"{fmt_p(tukey('S02-H', 'WT w/o cDC', 'IFN w/o cDC'))}; {fmt_p(tukey('S02-H', 'IFN w/o cDC', 'GMCSF'))}", 'S02-H', '', 'R7')
for bid in ['S01-B', 'S08-C']:
    for g in B[bid]['order']:
        m, sd, n = am(bid, g); add(f'F12-{bid}-{g}', f'SRB+ alveolar epithelial cells %, 16 h | {g}', f'{m:.3g} (SD {sd:.2g}, n={n})', bid, cells(bid, g), 'R5')
# dose response
b = B['S08-A']
for g in b['order']:
    out = []
    for i, d in enumerate(b['times']):
        c, lo, hi, n = gm('S08-A', g, i); out.append(f'{d} ug: {c:.3g}')
    add(f'G01-{g}', f'Lung Ifnb1 fold 16 h by dose (n=3/dose) | {g} | GM', ' ; '.join(out), 'S08-A', cells('S08-A', g), 'R3')
add('G01-p', 'S08-A: PSLN-212 40 vs 20 ug (Welch, log10); PSLN-344 10 ug vs PSLN-212 40 ug', f"{fmt_p(welch('S08-A','PSLN-212','PSLN-212',log=True) if False else stats.ttest_ind(np.log10(vals('S08-A','PSLN-212',4)), np.log10(vals('S08-A','PSLN-212',3)), equal_var=False).pvalue)}; fold {gm('S08-A','PSLN-344',2)[0]/gm('S08-A','PSLN-212',4)[0]:.2f}, p={fmt_p(stats.ttest_ind(np.log10(vals('S08-A','PSLN-344',2)), np.log10(vals('S08-A','PSLN-212',4)), equal_var=False).pvalue)}", 'S08-A', '', 'R3,R7')
for g in B['S08-B']['order']:
    m, sd, n = am('S08-B', g, 0); add(f'G02-{g}', f'Encapsulation efficiency % | {g}', f'{m:.1f} (SD {sd:.1f}, n={n})', 'S08-B', cells('S08-B', g), 'R5')
# safety
b = B['S08-D']
for g in b['order']:
    m = np.array([[np.nan if v is None else v for v in row] for row in b['groups'][g]['matrix']], float)
    nad = np.nanmin(m[1:], axis=0)
    add(f'H01-{g}', f'Body weight after immunisation (no challenge): mean of per-animal maximum loss; worst animal; day-10 mean; n at day 10 | {g}', f'{100-nad.mean():.1f}% ; {100-nad.min():.1f}% ; {np.nanmean(m[-1]):.1f}% of d0 ; n={int((~np.isnan(m[-1])).sum())}', 'S08-D', cells('S08-D', g), 'per-animal minimum over d2-d10, then mean')
for a in ['Ifnb1', 'Tnf', 'Isg15']:
    bid = f'S10-A_{a}'; out = [f'{g} {gm(bid, g)[0]:.2f}' for g in B[bid]['order']]
    add(f'H02-{a}', f'CNS {a} fold, 36 h | GM', ' | '.join(out) + f" ; Tukey PSLN-344 vs Sham p={fmt_p(tukey(bid, 'PSLN-344', 'Sham', log=True))}; CT vs Sham p={fmt_p(tukey(bid, 'CT', 'Sham', log=True))}", bid, '; '.join(cells(bid, g) for g in B[bid]['order']), 'R3,R7')
for p, tlabel in [('S09-A_panel1', '16 h (cols A-U)'), ('S09-A_panel2', 'labelled 16 h, identified as 72 h (cols X-AS)')]:
    b = B[p]
    for i, a in enumerate(b['analytes']):
        out = [f"{g} {10**np.mean(b['groups'][g]['matrix'][i]):.3g}" for g in b['order']]
        add(f'H03-{p[-6:]}-{a}', f'Lung {a} fold, {tlabel} | GM (n=3)', ' | '.join(out), p, f"rows {i+3}; " + '; '.join(b['groups'][g]['cells'] for g in b['order']), 'R4')

# ================= extra: pooled inference, sensitivity, morbidity, integrity quantities =================
def strat_lr(pairs):
    OE = V = 0.0
    for bid, gA, gB in pairs:
        tA, eA = recs(bid, gA); tB, eB = recs(bid, gB)
        for tt in np.unique(np.concatenate([tA[eA == 1], tB[eB == 1]])):
            nA = (tA >= tt).sum(); nB = (tB >= tt).sum(); dA = ((tA == tt) & (eA == 1)).sum(); dB = ((tB == tt) & (eB == 1)).sum()
            n = nA + nB; d = dA + dB
            if n > 1:
                OE += dA - d*nA/n; V += d*(nA/n)*(nB/n)*(n-d)/(n-1)
    chi = OE**2/V; return chi, stats.chi2.sf(chi, 1)
pairs = [(bid, arms['P344'], arms['P212']) for bid, lab, arms in EXPS if 'P212' in arms]
chi, p = strat_lr(pairs); add('A-strat-all', 'Log-rank stratified by experiment, PSLN-344 vs PSLN-212, all 15 head-to-head comparisons', f'chi2 = {chi:.1f}, p = {p:.1e}', 'all blocks with both arms', '', 'R1,R8')
pairs1 = [x for x in pairs if x[0] != 'S06-D']
chi, p = strat_lr(pairs1); add('A-strat-14', 'Same, counting the identical S06-C/S06-D tables once (14 comparisons)', f'chi2 = {chi:.1f}, p = {p:.1e}', 'as above minus S06-D', '', 'R1,R8')
pairs_s = [(bid, arms['P212'], arms['Sham']) for bid, lab, arms in EXPS if 'P212' in arms and 'Sham' in arms]
chi, p = strat_lr(pairs_s); add('A-strat-212-sham', 'Log-rank stratified by experiment, PSLN-212 vs Sham in aged animals (11 comparisons)', f'chi2 = {chi:.1f}, p = {p:.1e}', 'blocks with both arms', '', 'R1,R8')
pairs_y = [(bid, arms['P344'], arms['Young']) for bid, lab, arms in EXPS if 'Young' in arms]
chi, p = strat_lr(pairs_y); add('A-strat-344-young', 'Log-rank stratified by experiment, aged PSLN-344 vs young PSLN-212 (10 comparisons)', f'chi2 = {chi:.1f}, p = {p:.1e}', 'blocks with both arms', '', 'R1,R8')
wins = sum((surv(b_, a['P344'])[0]/surv(b_, a['P344'])[1]) > (surv(b_, a['P212'])[0]/surv(b_, a['P212'])[1]) for b_, l_, a in EXPS if 'P212' in a)
add('A-sign', 'Head-to-head comparisons in which PSLN-344 survival exceeds PSLN-212; exact two-sided sign test', f'{wins}/15; p = {stats.binomtest(wins, 15, 0.5).pvalue:.1e}', 'all blocks with both arms', '', 'count; binomial test')
# medians
meds = []
from lifelines import KaplanMeierFitter
for bid, lab, arms in EXPS:
    if 'Sham' in arms and 'P212' in arms:
        ms = []
        for a in ['Sham', 'P212']:
            t, e = recs(bid, arms[a]); ms.append(KaplanMeierFitter().fit(t, e).median_survival_time_)
        meds.append(f'{bid}: {ms[0]:.0f} vs {ms[1]:.0f}')
add('A-median-212', 'Median survival time (days), Sham vs PSLN-212, aged animals (Kaplan-Meier)', '; '.join(meds), 'blocks with both arms', '', 'R1')
# sensitivity numbers (weight-table-derived counts are in bw_group_summary.csv)
add('A-sens-least', 'Least-favourable reading: per experiment the lower of (survival table, weight table) for PSLN-344 and the higher for PSLN-212; the S03-J PSLN-344 animal without a day counted as a death', 'PSLN-344 95/115 = 82.6% (95% CI 74.4-89.0); PSLN-212 21/108 = 19.4% (12.5-28.2)', 'all survival blocks + paired weight blocks', 'see bw_group_summary.csv', 'R1,R6,R8')
add('A-sens-concordant', 'Only experiments whose survival and weight tables agree for both arms and that are not the identical S06-C/D pair (S06-A, S06-B, S06-F d60, S15-H, 4 imprinting comparisons, S15-L, S15-N)', 'PSLN-344 58/70 = 82.9% (72.0-90.8); PSLN-212 8/63 = 12.7% (5.6-23.5)', 'as listed', '', 'R1,R6,R8')
add('A-sens-balbc20', 'BALB/c >= 20 months only (S03-I, S03-J, S06-A..G, S15-H)', 'PSLN-344 61/72 = 84.7% (74.3-92.1); PSLN-212 9/66 = 13.6% (6.4-24.3)', 'as listed', '', 'R1,R8')
add('A-sens-hetero', 'Mismatched-subtype challenges in BALB/c, S06-D excluded (S06-A, -B, -C, -E, -F, -G, S15-H, non-imprinted PR8 and Perth, imprinted Perth)', 'PSLN-344 56/70 = 80.0% (68.7-88.6); PSLN-212 4/63 = 6.3% (1.8-15.5)', 'as listed', '', 'R1,R8')
# morbidity from bw tables
G = pd.read_csv('bw_group_summary.csv')
g3 = G[G.group.isin(['PSLN-344', '3d Vaccine+PSLN-344', 'Naïve+PSLN-344', 'Imprinting+PSLN-344'])]
gy = G[G.group.isin(['PSLN-212(Y)'])]
add('M-344', 'Mean of per-animal maximum weight loss among PSLN-344 animals alive at day 14, by weight block (aged/14-month animals)', '; '.join(f'{r.wblock} {r.group}: {r.maxloss_surv_mean:.1f}%' for r in g3.itertuples()) + f' | range {g3.maxloss_surv_mean.min():.1f}-{g3.maxloss_surv_mean.max():.1f}%', 'S13-F, S13-G, S15-A..G, S15-I..K, S15-M, S15-O', 'PSLN-344 columns of each block', 'R6')
add('M-young', 'Same for young PSLN-212 animals (aged-programme blocks)', '; '.join(f'{r.wblock}: {r.maxloss_surv_mean:.1f}%' for r in gy.itertuples()) + f' | range {gy.maxloss_surv_mean.min():.1f}-{gy.maxloss_surv_mean.max():.1f}%', 'S13-F, S15-A..G, S15-M, S15-O', 'PSLN-212(Y) columns', 'R6')
A_ = pd.read_csv('bw_per_animal.csv')
d60 = A_[(A_.wblock.isin(['S15-E', 'S15-F', 'S15-G'])) & (A_.state == 'dead')]
add('M-d60-deaths', 'Last measured weight (% of day 0) of animals recorded as dead in the day-60 weight tables: PSLN-344 vs Untreated sentinels', 'PSLN-344: ' + ', '.join(f'{v:.1f}' for v in sorted(d60[d60.group == 'PSLN-344'].nadir)) + ' | Untreated: ' + ', '.join(f'{v:.1f}' for v in sorted(d60[d60.group == 'Untreated'].nadir)), 'S15-E, S15-F, S15-G', 'S15!W43:AJ50; S15!W53:AJ60; S15!W63:AJ70', 'R6')
# survival vs weight discordances
disc = G[(G.concordant == 'NO')]
add('Q2', 'Groups in which the survival table and the paired weight table give different numbers alive', '; '.join(f'{r.sblock}/{r.wblock} {r.group}: {r.surv_table} vs {r.bw_alive}' for r in disc.itertuples()), 'paired blocks', '', 'R1 vs R6')
# R848 safety numbers
for p, tl in [('S09-A_panel1', '16 h'), ('S09-A_panel2', '72 h')]:
    b = B[p]
    for a in ['Il6', 'Ccl2', 'Tnf', 'Il10']:
        i = b['analytes'].index(a)
        x = {g: np.array(b['groups'][g]['matrix'][i], float) for g in b['order']}
        allv = np.concatenate(list(x.values())); lab = np.concatenate([[g]*3 for g in x])
        res = pairwise_tukeyhsd(allv, lab); tk = {frozenset((r[0], r[1])): float(r[3]) for r in res.summary().data[1:]}
        add(f'H04-{tl[:2]}-{a}', f'Lung {a}, {tl}: PSLN-344 aged vs PSLN-212 aged; vs PSLN-212 young (ratio of GM folds; Tukey p on log10)', f"{10**(x['PSLN-344'].mean()-x['PSLN-212'].mean()):.2f}x (p={fmt_p(tk[frozenset(('PSLN-344','PSLN-212'))])}); {10**(x['PSLN-344'].mean()-x['PSLN-212(y)'].mean()):.2f}x (p={fmt_p(tk[frozenset(('PSLN-344','PSLN-212(y)'))])})", p, f'row {i+3}', 'R4,R7')
# young Mn effect
add('B01-young', 'Lung Ifnb1 16 h: PSLN-344(Y) vs PSLN-212(Y); PSLN-344 aged vs PSLN-344(Y)', f"{gm('S01-A_16h','PSLN-344(Y)')[0]/gm('S01-A_16h','PSLN-212(Y)')[0]:.2f}x (Tukey p={fmt_p(tukey('S01-A_16h','PSLN-344(Y)','PSLN-212(Y)',log=True))}; Welch p={fmt_p(welch('S01-A_16h','PSLN-344(Y)','PSLN-212(Y)',log=True))}); {gm('S01-A_16h','PSLN-344')[0]/gm('S01-A_16h','PSLN-344(Y)')[0]:.2f}x (Welch p={fmt_p(welch('S01-A_16h','PSLN-344','PSLN-344(Y)',log=True))})", 'S01-A_16h', 'S01!B9:F10; S01!B8:F8', 'R3,R7')
add('S07A-p', 'Lung Ly6C+CCR2+ macrophages (x10^5), PSLN-212 vs PSLN-344: day 5; day 10 (Welch, n=3)', f"{am('S07-A','PSLN-212',2)[0]:.1f} vs {am('S07-A','PSLN-344',2)[0]:.1f} (p={fmt_p(welch('S07-A','PSLN-212','PSLN-344',2))}); {am('S07-A','PSLN-212',3)[0]:.1f} vs {am('S07-A','PSLN-344',3)[0]:.1f} (p={fmt_p(welch('S07-A','PSLN-212','PSLN-344',3))})", 'S07-A', 'S07!B5:G6', 'R5,R7')

for a_, b_, nm in [('S13-A', 'S13-B', 'CA09'), ('S13-C', 'S13-D', 'Aichi')]:
    r = {g: vals(a_, g) / vals(b_, g) for g in B[a_]['order']}
    add(f'C-ratio-{nm}-test', f'IgG2a/IgG1 ({nm}), PSLN-344 vs PSLN-212 aged: Welch t on log10 ratio; complete separation of animals?', f"p = {fmt_p(stats.ttest_ind(np.log10(r['PSLN-344']), np.log10(r['PSLN-212']), equal_var=False).pvalue)}; lowest PSLN-344 value {r['PSLN-344'].min():.2f} vs highest PSLN-212 value {r['PSLN-212'].max():.2f}", f'{a_}/{b_}', '', 'per-animal quotient; R7')

# ---------- further rows so that every number quoted in the memo has a ledger entry ----------
for i, t in enumerate(B['S11-D']['times']): four(f'E04-d{t}', 'S11-D', f'Lung NK cells %, day {t}', 'am', ti=i, ctrl='Vaccine')
for a in ['Ifnb1', 'Tnf', 'Isg15']:
    bid = f'S10-A_{a}'; x = np.log10(vals(bid, 'PSLN-344')); y = np.log10(vals(bid, 'Sham')); c = np.log10(vals(bid, 'CT'))
    d = x.mean() - y.mean(); se = np.sqrt(x.var(ddof=1)/len(x) + y.var(ddof=1)/len(y))
    df = se**4 / ((x.var(ddof=1)/len(x))**2/(len(x)-1) + (y.var(ddof=1)/len(y))**2/(len(y)-1)); tc = stats.t.ppf(0.975, df)
    add(f'H02-{a}-ratio', f'CNS {a}: PSLN-344 / Sham ratio of geometric means with Welch 95% CI; CT / Sham ratio', f'{10**d:.2f} ({10**(d-tc*se):.2f}-{10**(d+tc*se):.2f}); {10**(c.mean()-y.mean()):.1f}', bid, f"{cells(bid, 'PSLN-344')}; {cells(bid, 'Sham')}; {cells(bid, 'CT')}", 'R3; Welch interval on log10')
b = B['S08-D']; nad = {}
for g in b['order']:
    m_ = np.array([[np.nan if v is None else v for v in row] for row in b['groups'][g]['matrix']], float); nad[g] = np.nanmin(m_[1:], axis=0)
res = pairwise_tukeyhsd(np.concatenate(list(nad.values())), np.concatenate([[g]*len(v) for g, v in nad.items()]))
tk = {frozenset((r[0], r[1])): float(r[3]) for r in res.summary().data[1:]}
add('H01-tukey', 'S08-D per-animal nadir: Tukey p, PSLN-344 vs Vaccine alone; PSLN-212/R848 vs Vaccine alone', f"{fmt_p(tk[frozenset(('PSLN-344','Vaccine'))])}; {fmt_p(tk[frozenset(('PSLN-212/R848','Vaccine'))])}", 'S08-D', 'S08!B21:AE26', 'R6,R7')
sig = sum(lr(b_, a['P344'], a['P212']) < 0.05 for b_, l_, a in EXPS if 'P212' in a)
add('A-n-signif', 'Head-to-head comparisons with log-rank p < 0.05 (PSLN-344 vs PSLN-212)', f'{sig}/15', 'all blocks with both arms', '', 'R1')
e23 = [surv('S03-J', 'PSLN-344'), surv('S06-B', 'PSLN-344'), surv('S06-D', 'PSLN-344'), surv('S15-H', '3d Vaccine+PSLN-344')]
add('A-early', 'PSLN-344 survival with challenge 2-3 days after dosing (S03-J, S06-B, S06-D, S15-H); same with the S15-D weight-table count (5/7) for S06-D', f"{sum(x[0] for x in e23)}/{sum(x[1] for x in e23)}; {sum(x[0] for x in e23) - 2}/{sum(x[1] for x in e23)}", 'S03-J; S06-B; S06-D; S15-H (S15-D)', '', 'R1,R6,R8')
G_ = pd.read_csv('bw_group_summary.csv')
pairs_disc = sorted(set(G_[G_.concordant != 'yes'].wblock))
add('Q2-count', 'Paired survival / weight tables that disagree in at least one group (count or group label)', f"{len(pairs_disc)}/{G_.wblock.nunique()}: {', '.join(pairs_disc)}", 'all paired blocks', 'bw_group_summary.csv', 'R1 vs R6')
S_ = pd.read_csv('biomarker_screen.csv')
add('BM-screen', 'Arm-level biomarker screen: read-out/time-point combinations (4 core arms) with complete separation of protected from unprotected arms; largest gap', f"{int(S_.complete_sep.sum())}/{len(S_)}; {S_.sort_values('gap_SD').iloc[-1].readout} gap {S_.gap_SD.max():.1f} pooled SD", 'all blocks with Sham/Vaccine, PSLN-212, PSLN-344, PSLN-212(Y)', 'biomarker_screen.csv', 'see Appendix A')
def Mx(bid, g): return np.array([[np.nan if v is None else v for v in row] for row in B[bid]['groups'][g]['matrix']], float)
def same(b1, g1, b2, g2, skip=1):
    a_, b_ = Mx(b1, g1)[skip:], Mx(b2, g2)[skip:]; both = ~np.isnan(a_) & ~np.isnan(b_); return int((both & (a_ == b_)).sum()), int(both.sum())
add('Q4-a', 'Identical values, S15-C PSLN-344 vs S15-I vaccine+PSLN-344 (days 2-14)', '%d/%d' % same('S15-C', 'PSLN-344', 'S15-I', '3d Vaccine+PSLN-344'), 'S15-C; S15-I', 'S15!W24:AC30; S15!W73:AC79', 'position-wise equality')
add('Q4-b', 'Identical values between PSLN-344 weight series: S15-A vs S15-M; S15-M vs S15-O; S15-A vs S15-O', '%d/%d; %d/%d; %d/%d' % (same('S15-A', 'PSLN-344', 'S15-M', 'PSLN-344') + same('S15-M', 'PSLN-344', 'S15-O', 'PSLN-344') + same('S15-A', 'PSLN-344', 'S15-O', 'PSLN-344')), 'S15-A; S15-M; S15-O', 'S15!W4:AC10; S15!AD104:AJ110; S15!AD135:AJ141', 'position-wise equality')
a_ = np.concatenate([Mx('S11-A', g) for g in B['S11-A']['order']], axis=1); b_ = np.concatenate([Mx('S11-B', g) for g in B['S11-B']['order']], axis=1)
first2 = [0, 1, 5, 6, 10, 11, 15, 16]
dm = max(abs(Mx('S11-A', g).mean(axis=1) - Mx('S11-B', g).mean(axis=1)).max() for g in B['S11-A']['order'])
add('Q8', 'S11-A vs S11-B: identical cells among animals 1-2 of each group; identical cells overall; largest difference between group means', f'{int((a_[:, first2] == b_[:, first2]).sum())}/40; {int((a_ == b_).sum())}/100; {dm:.1f} points', 'S11-A; S11-B', 'S11!B3:U7; S11!B10:U14', 'position-wise equality')
fx = B['S04-B_Foxp3']['groups']; rt = B['S04-B_TfhTfr']['groups']
add('Q18', 'S04-B Tfh:Tfr equals (100 - Foxp3%)/Foxp3% (animals matching to 4 decimals)', f"{sum(abs((100-f)/f - r) < 1e-4 for g in fx for f, r in zip(fx[g]['values'], rt[g]['values']))}/20", 'S04-B', 'S04!A8:D12; S04!A15:D19', 'recomputation')
def sig_(bid, g): return tuple(sorted((r['day'] if r['day'] is not None else -1, r['status']) for r in B[bid]['groups'][g]['records']))
add('Q1', 'S06-C vs S06-D: groups with identical (day, status) records; records involved', f"{sum(sig_('S06-C', g) == sig_('S06-D', g) for g in B['S06-C']['order'])}/4 groups; {sum(len(B['S06-C']['groups'][g]['records']) for g in B['S06-C']['order'])} records", 'S06-C; S06-D', 'S06!M3:Q30; S06!A34:E61', 'multiset equality per group')
nm = {'PBS': 'Sham', 'CMP-204': 'CMP-204', 'PSLN-212': 'PSLN-212', 'PSLN-R848': 'PSLN-R848', 'PSLN-212/R848': 'PSLN-212/R848', 'PSLN-344': 'PSLN-344', 'PSLN-212(y)': 'PSLN-212(Y)'}
def match(panel, ref): return sum(any(abs(10**v - r) < 0.006 for r in B[ref]['groups'][nm[g]]['values']) for g in B[panel]['order'] for v in B[panel]['groups'][g]['matrix'][0])
add('Q7', 'S09-A Ifnb1 values (back-transformed) found in S01-A: panel 2 in 72 h panel / in 16 h panel; panel 1 in 16 h panel', f"{match('S09-A_panel2', 'S01-A_72h')}/21 / {match('S09-A_panel2', 'S01-A_16h')}/21; {match('S09-A_panel1', 'S01-A_16h')}/21", 'S09-A; S01-A', 'S09!Y3:AS3; S09!B3:V3; S01!B3:L10', '10^x compared to 2 decimals')
add('A-exact', 'Exact permutation log-rank p-values, PSLN-344 vs PSLN-212, 15 comparisons: number below 0.05; range among those; the two others', '13/15; 0.0006-0.021; 0.44 (imprinted PR8) and 0.086 (Swiss Webster)', 'all blocks with both arms', 'analysis/exact_lr.py', 'full enumeration of group relabellings')
add('POWER', 'Power of Fisher exact test (two-sided alpha 0.05): n=7 for 85% vs 14%; n=15 for 85% vs 14%; n=15 for 85% vs 40%; n=20 for 85% vs 40%', '0.67; 0.98; 0.59; 0.80', 'n/a (design calculation)', 'analysis/power.py', 'exact enumeration')

Ldf = pd.DataFrame(L)
# readable block names (the parser's internal suffixes -> the wording used in the memo)
REN = [('S06-E_r34', 'S06-E (rows 34-68)'), ('S06-F_r34', 'S06-F (rows 34-68)'), ('S06-E_r71', 'S06-E (rows 71-98)'), ('S06-F_r71', 'S06-F (rows 71-98)'),
       ('S01-A_16h', 'S01-A (16 h panel)'), ('S01-A_72h', 'S01-A (72 h panel)'), ('S09-A_panel1', 'S09-A (cols A-U)'), ('S09-A_panel2', 'S09-A (cols X-AS)'),
       ('S02-D_CD40', 'S02-D CD40'), ('S02-D_CD86', 'S02-D CD86'), ('S03-L_Aicda', 'S03-L Aicda'), ('S03-L_E47', 'S03-L E47'), ('S04-A_ICOShi', 'S04-A (ICOS-high)'), ('S04-A_ICOSlo', 'S04-A (ICOS-low)'),
       ('S04-B_Foxp3', 'S04-B (Foxp3)'), ('S04-B_TfhTfr', 'S04-B (Tfh:Tfr)'), ('S07-B_mono', 'S07-B (monocytes)'), ('S07-B_mac', 'S07-B (macrophages)'),
       ('S10-A_Ifnb1', 'S10-A (Ifnb1)'), ('S10-A_Tnf', 'S10-A (Tnf)'), ('S10-A_Isg15', 'S10-A (Isg15)'), ('S14-A_H1N1', 'S14-A H1N1'), ('S14-A_H3N2', 'S14-A H3N2')]
for col in ['statement', 'value', 'block']:
    for a_, b_ in REN: Ldf[col] = Ldf[col].astype(str).str.replace(a_, b_, regex=False)
Ldf.to_csv('evidence_ledger.csv', index=False)
print(len(Ldf), 'ledger rows')
pd.set_option('display.width', 300); pd.set_option('display.max_colwidth', 200); pd.set_option('display.max_rows', 1000)
print(Ldf[['id', 'statement', 'value']].to_string(index=False))

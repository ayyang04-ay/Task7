# PSLN-344 portfolio review: recommendation, evidence and forward plan

**Evidence base.** `adjuvant_program_dataset.xlsx` (15 sheets; 107 data panels as I parsed them, plus one unlabelled region) and `adjuvant_program_annotation.pdf` (19 pages). Nothing else was used as evidence. Where I use general knowledge to frame a risk or design a study, the sentence is tagged *[outside the dataset]*. Citations are written [block; rule]; the rules and the files that let the committee check each number are listed straight after the recommendation.

---

## 1. Recommendation

**Advance PSLN-344, conditionally.** Approve one gated confirmation-and-translation package (about 9–12 months; my planning estimate, driven by aged-animal supply and a day-180 durability arm). Hold IND-enabling spend (GLP toxicology, GMP manufacture) until its gates are passed. The first gate uses no animals: reconcile the source records, because the dataset contradicts itself in places (Section 4).

**Why advance**

1. **In aged animals PSLN-344 does what its manganese-free parent cannot.** After lethal influenza challenge, 97 of 114 aged animals given vaccine + PSLN-344 survived (85%; 95% CI 77–91; 28 of the 114 were 14 months old, the rest 20 months or older), against 15 of 108 given vaccine + PSLN-212 (14%; 8–22) and 1 of 80 given vaccine + empty liposome (1%). PSLN-344 survival was higher in all 15 head-to-head comparisons (stratified log-rank p < 10⁻²⁶). It holds for matched-strain, mismatched-subtype and H5N1 challenge; for challenge 2–3, 14 and 60 days after a single dose; in three mouse strains; and in animals with a prior influenza infection [Table 1; R1, R8]. Under the least favourable reading of every contradictory block it is still 83% against 19% [Section 4].
2. **The difference is the manganese, and the mechanism is coherent.** The two particles carry the same agonist load (encapsulation 54.8% vs 59.6%) [S08-B; R5]. More PSLN-212 does not close the gap: lung *Ifnb1* induction plateaus at 14.7-fold at 40 µg, against 45.5-fold for PSLN-344 at 20 µg [S08-A; R3]. In aged lung PSLN-344 brings *Ifnb1* back to the young-adult level (36.9-fold, against 37.5-fold in young animals given PSLN-212 and 16.5-fold in aged animals given PSLN-212) [S01-A; R3] and switches on *Gm-csf* (6.0–8.5-fold at 16–36 h, against 1.4–1.6-fold) [S02-F; R3]. Downstream, monocyte and dendritic-cell recruitment, lung CD8 T-cell responses and antibody titres recover most of the gap between aged and young animals [Table 2].
3. **Nothing measured so far disqualifies it on tolerability.** Weight loss after dosing was transient (mean 3.6%, recovered by day 10) [S08-D; R6], and three inflammatory transcripts in the CNS were not induced at 36 hours while the cholera-toxin control was positive [S10-A; R3]. But the safety data are thin, and manganese in the brain was not measured at all.

**Conditions (gates; detail in Section 6)**

| Gate | Must be shown before IND-enabling spend |
|---|---|
| 0 | The contradictions in Section 4 are resolved against primary records and the aged-animal survival advantage stands. |
| 1 | Blinded replication in both sexes, with a dose–response and a manganese-only control: survival ≥70% at a dose that is tolerated, and the manganese-only particle is inferior. |
| 2 | What mediates protection is identified (T-cell depletion, serum transfer), so the right efficacy marker and clinical endpoints can be chosen. |
| 3 | Safety margin of at least 3-fold; lung inflammation resolves; no manganese accumulation in olfactory bulb or brain. |
| 4 | Manganese-dependent enhancement is seen in human cells from older donors. |

**What would reverse the recommendation.** (a) The survival advantage is not confirmed in the primary records or in blinded replication. (b) A manganese-only particle performs as well as PSLN-344; the asset would then be a different, simpler product. (c) Manganese accumulates in brain, or lung inflammation fails to resolve, at three times the effective dose or less. (d) Manganese adds nothing in human cells.

**Confidence.** High that the effect in this dataset is large and always in the same direction. Moderate on its exact size: arms are 7–10 animals, and 8 of the 17 paired survival and body-weight tables disagree in at least one group. Low on safety, on what mediates protection, and on human translation; the dataset was not built to answer those.

**The forward view in brief**

- **What drives protection (Section 3).** Manganese restores the early innate signal the aged lung no longer makes, interferon-β and GM-CSF. That turns recruited monocytes into antigen-presenting cells and restores most of the lung CD8 T-cell and antibody response. Antigen is required: PSLN-344 alone protects 0 of 7 [S15-H]. Which immune arm does the protecting has not been tested.
- **Biomarker (Section 5).** None is validated, and this dataset cannot validate one. Carry two: the early airway interferon response as a target-engagement and dose-selection marker, and the cross-reactive CD8 T-cell response as the candidate efficacy marker. In patients both would be exploratory, not surrogate endpoints.
- **Next studies (Section 6).** Record reconciliation; blinded replication with dose–response and a manganese-only control; a depletion and transfer study to find what protects; safety and manganese distribution; human cells and a second species.
- **If dropped (Section 7).** We drop the only formulation in the programme that protects the aged host. PSLN-212 is not a fallback for that population.

---

## How to check a number

Every number is cited as [block; rule]. The block ID is the one printed in the workbook and annotation. The rule (R1–R8, below) says how the raw cells were reduced. Cell ranges for every block are in `block_directory.csv`; every number in this memo, with its cells and rule, is in `evidence_ledger.csv`; the scripts that produced them are in `analysis/`.

| Rule | Reduction |
|---|---|
| R1 | Survival tables are in Prism layout: one row per animal, day in the first column, 1 = died, 0 = alive when observation ended. Survival = animals with 0 ÷ animals with a recorded day. Exact (Clopper–Pearson) 95% intervals. Groups compared by log-rank test, the method stated in the annotation. |
| R2 | Titres (ELISA endpoint, HAI, neutralisation): geometric mean on the log10 scale. An HAI of 0 means "below the lowest dilution tested, 1:10" and is set to 5. |
| R3 | qPCR fold-change stored on a linear scale: geometric mean; tests on the log10 scale. |
| R4 | qPCR stored as log10 (S09-A): mean of the stored values, back-transformed. |
| R5 | Percentages, cell counts, encapsulation: arithmetic mean and SD. |
| R6 | Body weight: analysed per animal. A weight repeated unchanged to day 14 (three or more identical final readings, or two at ≤90%) is a dead animal's last weight carried forward, not an observation. Blank cells are also deaths. Group figures are for animals alive at day 14. |
| R7 | Multi-group blocks: one-way ANOVA with Tukey's test across all groups in the block (the stated method), on the scale given by R2–R5. Two-group blocks: Welch t-test. |
| R8 | Counts pooled across experiments are descriptive, because viruses and timings differ. The pooled test is a log-rank test stratified by experiment. |

Group names: **PSLN-344** = the manganese-containing particle. **PSLN-212** = the same liposome and agonist without manganese. **Sham** = vaccine plus empty liposome. **Aged** = 20 months or older unless stated; **young** = 7–8 weeks. The **young reference** is young animals given vaccine + PSLN-212.

---

## 2. The case for advancing

### 2.1 Survival

![Figure 1](figures/fig1_survival_by_experiment.png)

*Figure 1. Survival in every aged-animal comparison. Filled circles: survival tables. Open circles: count implied by the paired body-weight table where it differs.*

**Table 1. Every aged-animal survival comparison (survivors / evaluable animals).** [R1]

| # | Block (cells) | Vaccine → challenge, day of challenge after immunisation | Sham | PSLN-212 | **PSLN-344** | Young + PSLN-212 | Log-rank p, 344 vs 212 | Caveat (integrity-log item) |
|---|---|---|---|---|---|---|---|---|
| 1 | S03-I (S03!A17:F51) | Bivalent vaccine → 10× mLD50 CA09 H1N1, day 14 (homologous) | 0/7 | 0/7 | **7/7** | 7/7 | 0.0004 | Weight table S13-F shows 3/7 alive in the column headed PSLN-212, and a "Naïve" column absent from S03-I (Q3) |
| 2 | S03-J (S03!G17:J46) | rgH5N1 vaccine → wild-type VN04 H5N1, day 2 | 1/10 | 3/10 | **9/9** | — | 0.002 | Stated n = 9, 10 rows per group; one PSLN-344 row has status 0 but no day, so 9 evaluable. Weight table S13-G (10/10 alive) names the comparators "Sham" and "Naïve" (Q3) |
| 3 | S06-B (S06!G3:K30) | Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 3 | 0/7 | 0/7 | **5/7** | 7/7 | 0.0009 |  |
| 4 | S06-A (S06!A3:E30) | Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 14 | 0/7 | 1/7 | **6/7** | 7/7 | 0.008 |  |
| 5 | S06-E (rows 34–68) (S06!G34:L68) | Aichi H3N2 vaccine → 5× mLD50 PR8 H1N1, day 60 | 0/7 | 0/7 | **5/7** | 7/7 | 0.002 | Weight table S15-E: PSLN-344 6/7, PSLN-212 1/7 (Q2). Untreated sentinels 6/7 |
| 6 | S06-D (S06!A34:E61) | Bivalent vaccine → 5× mLD50 rgH5N1, day 3 | 0/7 | 2/7 | **7/7** | 7/7 | 0.007 | Table identical to S06-C in all four groups (Q1). Weight table S15-D: PSLN-344 5/7, young 5/7 (Q2) |
| 7 | S15-H (S15!A73:D93) | Bivalent vaccine ± PSLN-344 → 5× mLD50 rgH5N1, day 3 | 0/7 | — | **6/7** | — | — | Control column = vaccine alone (no liposome). PSLN-344 alone, no vaccine: 0/7 |
| 8 | S06-C (S06!M3:Q30) | Bivalent vaccine → 5× mLD50 rgH5N1, day 14 | 0/7 | 2/7 | **7/7** | 7/7 | 0.007 | Weight table S15-C: PSLN-212 1/7 (Q2); its PSLN-344 series duplicates S15-I (Q4) |
| 9 | S06-F (rows 34–68) (S06!M34:R68) | Bivalent vaccine → 5× mLD50 rgH5N1, day 60 | 0/7 | 1/7 | **5/7** | 7/7 | 0.009 | Untreated sentinels 7/7 |
| 10 | S06-G (S06!A71:F105) | CA09 H1N1 vaccine → 5× mLD50 Perth H3N2, day 60 | 0/7 | 0/7 | **4/7** | 7/7 | 0.015 | Weight table S15-G: PSLN-344 5/7 (Q2). Untreated sentinels 4/7 |
| 11 | S06-E (rows 71–98) (S06!G71:K98) | 14-month-old, not imprinted: bivalent vaccine → 5× LD50 PR8 | — | 0/7 | **6/7** | — | 0.002 | Challenge day not stated |
| 12 | S06-E (rows 71–98) (S06!G71:K98) | 14-month-old, PR8-imprinted: bivalent vaccine → 5× LD50 PR8 | — | 4/7 | **6/7** | — | 0.23 | Prior PR8 infection itself protects against PR8; no imprinted-only control |
| 13 | S06-F (rows 71–98) (S06!M71:Q98) | 14-month-old, not imprinted: bivalent vaccine → 5× LD50 Perth H3N2, day 14 | — | 0/7 | **6/7** | — | 0.0006 |  |
| 14 | S06-F (rows 71–98) (S06!M71:Q98) | 14-month-old, PR8-imprinted: bivalent vaccine → 5× LD50 Perth H3N2, day 14 | — | 0/7 | **6/7** | — | 0.0002 |  |
| 15 | S15-L (S15!A103:E130) | Aged C57BL/6 (20 months), bivalent vaccine; challenge virus and day not stated | 0/7 | 0/7 | **6/7** | 6/7 | 0.001 | Weight table S15-M: young 7/7 (Q2); PSLN-344 weight series shares values with S15-A (Q4) |
| 16 | S15-N (S15!A134:E161) | Aged Swiss Webster (20 months), bivalent vaccine; challenge virus and day not stated | 0/7 | 2/7 | **6/7** | 7/7 | 0.056 | PSLN-344 weight series shares values with S15-A/S15-M (Q4) |

Pooled [R8]: Sham 1/80 (1.2%); PSLN-212 15/108 (13.9%; 95% CI 8.0–21.9); **PSLN-344 97/114 (85.1%; 77.2–91.1)**; young reference 69/70 (98.6%). Kaplan–Meier curves for all 16 are in Figure A1.

What the table shows:

- **Consistency.** PSLN-344 beat PSLN-212 in 15 of 15 comparisons (sign test p = 6 × 10⁻⁵) and the difference was individually significant in 13. The two exceptions are row 12, where the prior infection itself protected the PSLN-212 animals against the same virus, and row 16 (p = 0.056). Restricted to BALB/c animals of 20 months or more the pooled result is 61/72 (85%) against 9/66 (14%) [A-sens-balbc20 in the ledger].
- **PSLN-212 is not inert in aged animals; it is insufficient.** It delays death (median 6–12 days against 5–9 for sham; stratified log-rank p = 6 × 10⁻¹¹) but rarely prevents it [A-median-212, A-strat-212-sham in the ledger].
- **Antigen is required.** Given 3 days before challenge, vaccine alone protected 0/7, PSLN-344 alone 0/7, and the two together 6/7 (log-rank p = 0.0001 against PSLN-344 alone) [S15-H; R1]. PSLN-344 is an adjuvant, not a stand-alone antiviral.
- **Speed.** With challenge only 2–3 days after the single dose, 27 of 30 PSLN-344 animals survived (rows 2, 3, 6, 7); 25 of 30 if the body-weight table is used for row 6.
- **Breadth.** Restricted to mismatched-subtype challenges in BALB/c, with the duplicated table counted once: 56/70 (80%) against 4/63 (6%) [A-sens-hetero].
- **The benefit is specific to the aged host.** In young animals PSLN-344 and PSLN-212 both gave 8/8 survival in three experiments, including challenge at day 180 [S09-B, S09-D, S09-F; R1], and even the cGAMP particle protected 7/7 [S13-E; R1]. Manganese adds no measurable survival benefit where the parent already works.
- **Restoration is large but not complete.** Aged PSLN-344 animals still did worse than the young reference (stratified log-rank p = 0.001). At day 60 survival was 14/21 (67%; 43–85) against 20/21 at day 14 (Fisher p = 0.045) and 21/21 in the young reference (p = 0.009). On the two virus pairs tested at both times the fall is 13/14 to 10/14 (p = 0.33), so waning is suggested, not shown.
- **Day-60 deaths in the PSLN-344 arm were influenza deaths, not old age.** The five animals recorded as dead in the weight tables had fallen to 77.5–85.3% of starting weight. The four untreated, unchallenged sentinels that died in the same window (4 of 21) were at 94.5–96.6% [S15-E, S15-F, S15-G; R6]. Background mortality in 22-month-old animals is real and must be controlled for, but it does not explain these failures.
- **Protection is from death, not from infection.** PSLN-344 survivors lost on average 6.5–15.0% of body weight at the worst point, depending on the experiment; the young reference lost 6.5–12.1% [Figure 2; R6]. The dataset contains no virus titres and no lung pathology.

![Figure 2](figures/fig2_morbidity_weight_loss.png)

*Figure 2. Maximum weight loss per animal after challenge.*

### 2.2 Why the benefit is attributed to manganese

- Same cargo: encapsulation efficiency 54.8% (SD 5.1) for PSLN-344 and 59.6% (SD 4.6) for PSLN-212, n = 3 [S08-B; R5].
- Not reachable by dose: PSLN-212 gives 12.5-fold *Ifnb1* at 20 µg and 14.7-fold at 40 µg. PSLN-344 gives 21.0-fold at 10 µg and 45.5-fold at 20 µg, then flattens (49.7-fold at 40 µg) [S08-A; R3; n = 3 per dose].
- Not explained by better uptake into epithelium: under either reading of the conflicting uptake block, PSLN-344 uptake is no higher than the manganese-free particle's [S08-C against S01-B; Section 4, item Q9].
- Not matched by the alternatives tested: the cGAMP particle CMP-204 (7.7-fold *Ifnb1*; IgG 181 against 7,305) and the R848 combinations, which were poorly tolerated (Section 2.4).

![Figure 3](figures/fig3_innate_PD_axis.png)

*Figure 3. The early innate signal: (a) Ifnb1 by formulation, (b) dose-response, (c) Gm-csf.*

### 2.3 What is restored in the aged host

**Table 2. Immune read-outs in the four core arms.** "Age gap closed" = (PSLN-344 aged − PSLN-212 aged) ÷ (young reference − PSLN-212 aged), on the log scale for titres and *Ifnb1*. n = 5 per arm unless stated. [R2, R3, R5, R7]

| Read-out (summary statistic) | Block | Sham | PSLN-212 aged | **PSLN-344 aged** | PSLN-212 young | 344 vs 212 aged (Tukey p) | 344 aged vs young (Tukey p) | Age gap closed |
|---|---|---|---|---|---|---|---|---|
| **Innate response in the lung** | | | | | | | | |
| Ifnb1 mRNA, 16 h, fold (nanoparticle alone) (GM) | S01-A (16 h panel) | 0.94 | 16.5 | **36.9** | 37.5 | 2.2× (0.0006) | 0.98× (1.00) | 0.98 |
| Monocytes, day 4, % (mean) | S01-D | 10.4 | 16.7 | **30.6** | 32.2 | +13.8 pts (<0.0001) | −1.7 pts (0.84) | 0.89 |
| CD11b+ dendritic cells, day 4, % (mean) | S01-E | 4.8 | 8.3 | **18.9** | 21.4 | +10.6 pts (0.007) | −2.5 pts (0.88) | 0.81 |
| cDC1, 72 h, % (mean) | S01-F | 17.9 | 22.8 | **37.5** | 43.4 | +14.7 pts (0.0003) | −5.9 pts (0.26) | 0.71 |
| Migratory CCR7+ CD11b+ DC, 72 h, % (mean) | S02-A | 2.5 | 7.3 | **30.7** | 35.0 | +23.4 pts (<0.0001) | −4.3 pts (0.49) | 0.84 |
| Antigen-carrying DC in lymph node, 36 h, % (mean) | S02-C | — | 1.8 | **7.1** | 9.4 | +5.3 pts (<0.0001) | −2.3 pts (0.072) | 0.70 |
| CD40+ lymph-node CD11b+ DC, day 3, % (mean) | S02-D CD40 | 4.0 | 5.6 | **11.2** | 38.7 | +5.6 pts (0.16) | −27.5 pts (<0.0001) | 0.17 |
| CD86+ lymph-node CD11b+ DC, day 3, % (mean) | S02-D CD86 | 7.2 | 8.1 | **14.5** | 37.9 | +6.4 pts (0.033) | −23.4 pts (<0.0001) | 0.22 |
| CD206+ macrophages, % (mean) | S11-E | 85.2 | 71.5 | **48.9** | 35.5 | −22.5 pts (0.002) | +13.4 pts (0.068) | 0.63 |
| **CD8 T cells** | | | | | | | | |
| Lung Ki-67+ CD8, day 3, % (mean) | S05-D | 0.83 | 3.5 | **9.4** | 9.9 | +5.9 pts (0.0008) | −0.6 pts (0.97) | 0.91 |
| Lung granzyme B+ CD8, day 3, % (mean) | S05-E | 0.99 | 3.0 | **5.7** | 9.6 | +2.7 pts (0.0008) | −3.9 pts (<0.0001) | 0.41 |
| IFN-γ+ CD8 to rgH5N1 restimulation, day 14, % (mean) | S05-F | 0.67 | 1.5 | **6.4** | 9.2 | +4.9 pts (<0.0001) | −2.8 pts (0.0001) | 0.63 |
| IFN-γ+ CD8 to rgH5N1 restimulation, day 60, % (mean) | S05-G | 1.5 | 3.0 | **9.9** | 14.4 | +6.8 pts (0.0008) | −4.5 pts (0.024) | 0.60 |
| Lung resident-memory CD8, day 25, % (mean) | S05-I | 0.58 | 1.0 | **4.0** | 6.0 | +3.0 pts (<0.0001) | −2.1 pts (<0.0001) | 0.59 |
| Lung regulatory T cells, day 7, % (n = 3) (mean) | S04-D | 5.9 | 6.7 | **3.0** | 1.8 | −3.7 pts (0.0002) | +1.2 pts (0.12) | 0.75 |
| **Antibody and germinal centre** | | | | | | | | |
| Serum IgG anti-CA09, day 14, titre (GM) | S03-A | 55.7 | 393 | **7,305** | 11,959 | 18.6× (<0.0001) | 0.61× (0.72) | 0.86 |
| Serum IgG anti-Aichi, day 14, titre (GM) | S03-E | 52.4 | 426 | **5,701** | 13,855 | 13.4× (0.0001) | 0.41× (0.33) | 0.75 |
| HAI anti-CA09, day 14, titre (GM) | S03-C | 7.6 | 45.9 | **368** | 485 | 8.0× (<0.0001) | 0.76× (0.87) | 0.88 |
| HAI anti-Aichi, day 14, titre (GM) | S03-G | 10.0 | 34.8 | **320** | 368 | 9.2× (<0.0001) | 0.87× (0.99) | 0.94 |
| Neutralising anti-CA09, day 14, titre (GM) | S03-D | 52.2 | 418 | **3,840** | 6,686 | 9.2× (0.0002) | 0.57× (0.67) | 0.80 |
| Neutralising anti-Aichi, day 14, titre (GM) | S03-H | 39.6 | 276 | **2,533** | 4,411 | 9.2× (<0.0001) | 0.57× (0.53) | 0.80 |
| Germinal-centre B cells, day 7, % (mean) | S03-K | 1.2 | 2.3 | **6.5** | 9.8 | +4.2 pts (0.007) | −3.3 pts (0.040) | 0.56 |
| T follicular helper (ICOS-high), day 7, % (mean) | S04-A (ICOS-high) | 0.3 | 3.8 | **10.3** | 13.6 | +6.4 pts (0.0002) | −3.4 pts (0.045) | 0.66 |
| T follicular regulatory, day 7, % (mean) | S04-B (Foxp3) | 22.6 | 26.7 | **10.8** | 7.1 | −15.9 pts (0.0002) | +3.7 pts (0.58) | 0.81 |

![Figure 4](figures/fig4_age_gap_closed.png)

*Figure 4. Fraction of the aged-to-young gap closed by PSLN-344, by read-out.*

Three points the committee should hear:

- Most read-outs recover 55–100% of the gap. Two do not: co-stimulatory markers on lymph-node dendritic cells (17–22%) and early granzyme B in lung CD8 T cells (41%). Alveolar macrophage numbers, lower in aged lungs, are not restored at all [S11-A; Figure 4]. That survival is restored while the lymph-node markers are not fits T-cell priming in the lung rather than the node (Section 3).
- The antibody response is IgG2a-dominant, as in young animals. Recomputed from the raw subclass titres, IgG2a/IgG1 is 2.14 for PSLN-344, 2.97 for the young reference and 0.58 for PSLN-212 in aged animals (CA09; 2.73, 2.89 and 0.51 for Aichi) [S13-A to S13-D]. The printed ratio blocks S03-B and S03-F show the opposite because their column headers are rotated (item Q6). Do not quote them.
- After a boost the antibody gap to PSLN-212 narrows for one strain (CA09 IgG 15,650 against 4,411; Tukey p = 0.19) but not the other (Aichi 12,440 against 1,086; p < 0.0001) [S13-I, S13-J; R2]. No challenge was done after a boost, so "two doses of PSLN-212" is untested as an alternative.

### 2.4 Tolerability so far

![Figure 5](figures/fig5_tolerability_and_reactogenicity.png)

*Figure 5. Tolerability and reactogenicity data available so far.*

- **Body weight after dosing** [S08-D; R6; n = 5]. PSLN-344: mean maximum loss 3.6%, worst animal 5.8%, all five at 99.2% or more by day 10. Vaccine alone: 1.8%. The difference is not significant (Tukey p = 0.86) but five animals cannot exclude a modest effect. The R848 combination lost 10.0% on average (worst 15.3%), had not recovered by day 10, and one animal has no day-10 value.
- **CNS** [S10-A; R3; n = 5]. PSLN-344 against sham: *Ifnb1* 1.14-fold (95% CI 0.69–1.86), *Tnf* 1.20 (0.77–1.87), *Isg15* 1.08 (0.84–1.41). Cholera toxin against sham: 4.8, 2.6 and 2.5-fold. One time point (36 h), three transcripts, whole CNS.
- **Lung cytokine transcripts** [S09-A; R4; n = 3]. At 16 h aged lungs given PSLN-344 are at or below young lungs given PSLN-212 for *Il6* (36 against 60-fold) and *Ccl2* (590 against 1,391-fold), and above them for *Tnf* (40 against 14-fold) and *Il10* (7.3 against 1.8-fold). At 72 h they have not returned to baseline: *Il6* 7.2-fold, *Ccl2* 27-fold, *Tnf* 8.4-fold. Slow resolution of *Tnf* and *Il10* is an age effect (PSLN-212 in aged lung is similar), but *Il6* and *Ccl2* are 3.9 and 5.2 times higher with PSLN-344 than with PSLN-212 (Tukey p = 0.003 and 0.0003). The 72 h panel is mislabelled "16h" in the workbook (item Q7).
- **Cell infiltrate.** Lung monocytes and CD11b+ dendritic cells are still above the young reference at day 8, the last time point (18.4% against 14.1%, p = 0.0003; 13.7% against 9.5%, p = 0.005) [S01-D, S01-E; R5, R7].
- **Not available:** histopathology, BAL, protein-level cytokines, anything beyond day 10, repeat dosing, manganese in any tissue. The neutrophil block cannot be used (item Q8).

---

## 3. What is actually driving the protection

**Short answer.** Manganese restores, in the aged lung, an early innate signal that the agonist alone no longer produces: interferon-β back to the young-adult level and GM-CSF switched on. That signal brings in CCR2-dependent monocytes and turns them into antigen-presenting dendritic cells rather than macrophages. CD8 T cells are then primed in the lung itself, and the animal ends up with cross-reactive and lung-resident CD8 memory plus a largely restored antibody response. Protection needs the antigen. The last step, which arm of immunity actually protects, is inferred and has not been tested.

| Link in the chain | Evidence | Kind of evidence | Animals |
|---|---|---|---|
| Aged lung under-responds to the agonist; manganese corrects it | *Ifnb1* 16.5-fold (aged) against 37.5 (young) with PSLN-212; 36.9 with PSLN-344 [S01-A]. Dose cannot substitute [S08-A] | Comparison | Aged and young |
| Manganese switches on GM-CSF | *Gm-csf* 6.0, 8.5, 3.6-fold at 16, 36, 72 h against 1.4–1.6 for PSLN-212 [S02-F] | Comparison; no young arm | Aged |
| Monocytes are recruited, via CCR2 and gap junctions | Monocytes 30.6% against 16.7% at day 4 [S01-D]. CCR2 antagonist: 9.9% to 3.3% [S07-B]. Carbenoxolone: 7.3% to 3.1% [S11-C] | Intervention | Aged (S07-B by naming convention; age not stated) |
| Monocytes become dendritic cells only with interferon signalling, and GM-CSF is limiting | Donor-derived dendritic cells 19.7% from wild-type marrow against 2.1% from interferon-receptor-deficient marrow; GM-CSF restores 12.4% [S02-H]. GM-CSF added to PSLN-212 raises them from 5.9% to 13.8% [S02-G]. Monocyte entry itself was not clearly receptor-dependent: 21.3% against 15.4%, p = 0.12, n = 3 [S12-A] | Intervention | S02-G aged; S12-A young; S02-H age not stated |
| Without manganese, aged monocytes accumulate as macrophages | Ly6C+CCR2+ macrophages 19.0 against 3.4 × 10⁵ at day 5 [S07-A, n = 3]; CD206+ macrophages 71.5% against 48.9% [S11-E]; lung regulatory T cells 6.7% against 3.0% [S04-D, n = 3] | Comparison | Aged |
| Dendritic cells carry antigen to the lymph node | Antigen-positive cells 7.1% against 1.8%; pertussis toxin blocks (2.4%) [S02-C]. Their ability to prime T cells ex vivo: 18.7% against 0.8% [S02-E] | Comparison plus intervention | Aged and young |
| CD8 T cells are primed in the lung as well | Pertussis toxin removes proliferation in the node (30.9% to 6.8%) but not in lung (59.0% against 55.1%) [S05-C, n = 3]. CCR2 blockade cuts lung granzyme B+ CD8 from 6.8% to 1.4% [S02-I] | Intervention | Young, or age not stated |
| Result: cross-reactive and resident CD8 memory, and antibody | Table 2 [S05-F, S05-G, S05-I, S03-A to S03-H] | Comparison | Aged and young |
| Antigen is required | 0/7, 0/7, 6/7 [S15-H] | Intervention, survival | Aged |

**What the data do not establish**

1. **Which effector protects.** No experiment removes CD8 T cells, B cells or antibody and then challenges. CD8 T cells are the leading candidate for mismatched-subtype protection because the only cross-reactive read-out in the dataset is a T-cell one (S05-F, S05-G respond to a virus that was not in the vaccine). But antibody was measured only against the vaccine strains, never against a challenge strain, so cross-reactive antibody is unmeasured, not excluded.
2. **Whether the agonist is needed at all in aged animals.** There is no manganese-only particle and no "PSLN-212 plus free manganese" arm. The data show manganese is necessary; they cannot show the agonist is.
3. **Whether the chain holds in aged animals through to survival.** The interferon-receptor, CCR2-to-CD8 and pertussis-toxin experiments were run in young animals or the age is not stated, and none has survival as its read-out.
4. **Whether less virus grows.** No virus titres, no pathology.

---

## 4. Weak points the committee will probe

### 4.1 The dataset contradicts itself

I checked every survival table against its body-weight table, every derived column against its raw data, and every block against every other for re-used values. Full log with cells: Appendix C and `data_integrity_log.csv`. Examples are drawn in Figure A2. The items that change, or could change, a claim:

| Item | Finding | What it changes |
|---|---|---|
| Q1 | The rgH5N1 survival tables for challenge at day 14 (S06-C) and day 3 (S06-D) are identical in all four groups, 28 of 28 records. | They cannot both be independent records. Counted once, the pooled result is 90/107 (84%) against 13/101 (13%). |
| Q2 | 8 of 17 paired survival and weight tables disagree in at least one group (for example S06-D says PSLN-344 7/7, its weight table S15-D shows 5/7; S06-E says 5/7, S15-E shows 6/7). Four of the eight pairs are named as the same animals by the annotation; four are paired by identical design (Appendix A). | Plus or minus 1–3 animals per arm. Least favourable reading overall: 95/115 (83%) against 21/108 (19%). Using only the ten comparisons where both tables agree: 58/70 (83%) against 8/63 (13%). |
| Q3 | For the matched-strain challenge (S03-I) and the wild-type H5N1 challenge (S03-J), the weight tables said to be "the animals of" those blocks carry different group names (S13-F has "Naïve" and no CMP-204; S13-G has "Sham" and "Naïve" and no PSLN-212). | The PSLN-344 arm is unaffected (7/7; 9/9 or 10/10). Which comparator is which is not: PSLN-212 in the matched-strain challenge is either 0/7 or 3/7, and it is uncertain whether a PSLN-212 arm was run against wild-type H5N1. |
| Q4 | Body-weight series are re-used between experiments: S15-C PSLN-344 (day-14 challenge) equals S15-I (day-3 challenge) in 40 of 49 values; the PSLN-344 series of S15-A, S15-M (C57BL/6) and S15-O (Swiss Webster) share 7–16 of 49 values. | Those weight series are not independent evidence. The cross-strain claim is supportive only until verified. |
| Q5 | Dead animals stay in the weight tables at their last weight. | Naive group means are wrong wherever an arm had deaths. I used per-animal analysis (R6). |
| Q6 | The printed IgG2a/IgG1 blocks (S03-B, S03-F) have rotated column headers relative to the raw titres (S13-A to S13-D). | As printed, PSLN-344 looks IgG1-skewed (0.58). Recomputed, it is IgG2a-dominant (2.14), like young animals. |
| Q7 | The second S09-A cytokine panel is labelled "16h" but is the 72 h data: all 21 of its *Ifnb1* values are 72 h values from S01-A. | Read as a 16 h replicate, it would hide that inflammatory transcripts are still raised at 72 h. |
| Q8 | The "neutrophil" block S11-B reproduces the alveolar-macrophage block S11-A (34 of 40 cells identical for the first two animals of each group; group means within 2.5 points). | There is no usable neutrophil read-out. |
| Q9 | The uptake block S08-C conflicts with S01-B for the same particle and cell type (13.8% against 3.8%); transposing two column headers reconciles them. | Cannot say whether manganese lowers epithelial uptake four-fold or leaves it unchanged. Either way it is not higher. |

None of these reverses the headline. Together they mean the package is not yet decision-grade for IND-enabling spend, which is why Gate 0 comes first.

### 4.2 Gaps in the design

- No manganese-only control, no free-manganese admixture (Section 3).
- No depletion or transfer experiment; no antibody against challenge strains.
- Survival and weight only: no virus titre, no lung pathology.
- One efficacy dose (20 µg). The dose–response exists for *Ifnb1* only. The annotation does not say whether 20 µg refers to agonist or to whole particle.
- The BALB/c animals are all female; sex is not given for the other strains [annotation, "Animals"].
- Seven animals per arm gives 67% power even for a difference as large as 85% against 14%. Smaller differences, such as PSLN-344 against the young reference or day 14 against day 60, could not be detected reliably [`analysis/power.py`].
- All efficacy is with formalin-inactivated whole virus given into the airway, compared only with in-house particles. There is no licensed-type comparator, no split or subunit antigen, no intramuscular arm.
- Challenge virus and day are not stated for the C57BL/6 and Swiss Webster experiments (S15-L, S15-N).
- Key T-cell blocks are thin or ambiguous: the tetramer blocks have two animals per time point and contradictory condition text; the resident-memory block inherits that ambiguity (item Q15).

### 4.3 Safety unknowns

The safety evidence is Section 2.4 and no more. Not addressed: manganese in olfactory bulb or brain; lung histology; resolution beyond 72 h for cytokines and day 8 for cells; repeat dosing; a dose above 20 µg; any second species. *[outside the dataset]* Manganese is a known neurotoxicant with a nose-to-brain route, and an intranasal toxin-adjuvanted influenza vaccine was withdrawn for facial palsy. Regulators will ask about both.

### 4.4 Translation

- Uptake by alveolar macrophages depends on surfactant proteins A and D (43.1% against 12.7% in knockout mice, p < 0.0001) [S01-C; R5, R7], and the downstream biology is pulmonary. *[outside the dataset]* Mouse "intranasal" instillation reaches the lung; a human nasal spray does not. The human product is likely to need aerosol delivery to the deep lung.
- No human cells, no second species. *[outside the dataset]* STING agonists have failed on species differences before.
- CMC data are one block: encapsulation efficiency. No particle size, manganese content, release or stability data are in the workbook.

### 4.5 Challenges to expect, and the answer the data support

| Challenge | Answer from the data | Still owed |
|---|---|---|
| "Seven mice per arm proves nothing." | Sixteen comparisons, all in one direction; 97/114 against 15/108; stratified log-rank p < 10⁻²⁶. Sham arms survive 0–10%, so the challenges were lethal [Table 1] | Study 1 at 15–20 per arm, blinded |
| "You could get there with more PSLN-212." | The interferon response to PSLN-212 is flat between 20 and 40 µg (12.5 to 14.7-fold); PSLN-344 at 10 µg already exceeds it [S08-A] | Survival at 40 µg PSLN-212 and after two doses (Study 1) |
| "A stronger adjuvant is just a more toxic one." | PSLN-344 lost 3.6% body weight and recovered; the R848 combination lost 10.0% and did not, so the assay can detect a poorly tolerated particle [S08-D]. At 16 h lung *Il6* and *Ccl2* are no higher than in young animals given PSLN-212 [S09-A] | Histology, BAL, manganese distribution, repeat dose (Study 3) |
| "Old mice die anyway." | Unchallenged sentinels that died (4/21) had not lost weight; PSLN-344 animals that died had lost 15–22% [S15-E, -F, -G]. Sham arms: 1/80 | Sentinels in every future cohort |
| "The data are inconsistent." | Yes, and the inconsistencies are listed here before anyone else finds them. The result is 83–85% against 13–19% under every reading [Section 4.1] | Gate 0 |
| "Titres are still below young." | True: HAI 76–87% and neutralisation 57% of the young reference; survival 85% against 99% [Tables 1, 2] | Dose–response (Study 1) |
| "Is it better than the enhanced vaccines older adults already get?" | The dataset has no such comparator | Benchmark arm in Study 1 |

---

## 5. Is there a biomarker of efficacy worth carrying forward?

**Not a validated one, and this dataset cannot produce one.** Every immune read-out is terminal and comes from a separate cohort, so no animal has both a biomarker value and a challenge outcome. At the level of arms, 32 of the 52 read-out/time-point combinations measured in all four core arms separate the two protected arms from the two unprotected arms completely (the duplicated S11-B block and the Tfh:Tfr transform left out) [`biomarker_screen.csv`]. When almost everything "predicts", nothing has been shown to.

Two observations do discriminate between candidates:

- **Interferon-β induction is not sufficient.** The *Ifnb1* data were generated with particle alone, no vaccine [S01-A], and particle alone protects 0 of 7 [S15-H]. Early interferon is a marker that the adjuvant has engaged its target, not a marker of protection.
- **HAI does not explain protection here.** All five aged PSLN-212 animals reached HAI ≥ 40 against CA09, the conventional human threshold *[outside the dataset]*, yet that arm was 0/7 (or 3/7, item Q3) against CA09 itself [S03-C, S03-I]. And HAI against the vaccine strain cannot account for protection against a different subtype.

A third point sets up the sharpest available test. Arms that protected had *Ifnb1* of about 37-fold or more; arms that did not had 17-fold or less. PSLN-344 at 10 µg gives 21.0-fold [S08-A] and was never challenged. Whether that dose protects will show if the size of the interferon response is what matters, or the GM-CSF switch that only manganese provides. It is an arm in Study 1.

**Candidates and the role each could play**

| Candidate | What our data show | What they do not show | Role to carry forward |
|---|---|---|---|
| **Early airway interferon response** (lung *Ifnb1* at 16 h) — lead pharmacodynamic marker | Dose–response from 1.4 to 49.7-fold over 1–40 µg [S08-A]. Age gap and its closure [S01-A]. Back to 4.2-fold by 72 h [S01-A]. Interferon receptor needed for the dendritic-cell step [S02-H] | Not sufficient for protection [S15-H]. Measured in lung tissue, without vaccine. No same-animal link to outcome | **Target engagement and dose selection.** In a first human study it answers "did we close the age gap?" by comparing older with younger adults |
| **GM-CSF** (lung *Gm-csf* at 16–36 h) — companion marker | The one read-out that is on/off between PSLN-344 and PSLN-212 [S02-F]. Supplementing GM-CSF raises dendritic cells [S02-G] | No dose–response, no young arm, no link to outcome | Marker specific to the manganese effect; distinguishes "more interferon" from "the right signal" |
| **Cross-reactive interferon-γ+ CD8 T cells** (day 14 and day 60) — candidate response marker | Largest separation between protected and unprotected arms (6.7 SD). Persists to day 60 (9.9%). Responds to a virus not in the vaccine [S05-F, S05-G] | Measured in lymph node, not blood. No depletion experiment. Rises from day 14 to day 60 while survival falls, so it does not track the apparent waning | **Exploratory immunogenicity endpoint.** Promote to key secondary only if Study 2 shows CD8 dependence |
| Serum IgG2a/IgG1 ratio (day 14) | The only blood read-out that flips rather than scales: 0.58 (IgG1-dominant) in aged PSLN-212 animals, 2.14 (IgG2a-dominant) with PSLN-344, 2.97 in the young reference; no overlap between the two aged arms for either strain (Welch p = 0.007 and 0.003) [S13-A to S13-D, recomputed] | No link to outcome; the mouse subclasses have no direct human equivalent | **Mouse-stage bridging marker.** Can be measured before challenge in the same animal in Study 1 |
| Lung resident-memory CD8 (day 25) | 4.0% against 1.0%; young 6.0% [S05-I] | Tissue only; ambiguous conditions (Q15) | Preclinical mechanism read-out |
| HAI and neutralising titre | 8–9 times PSLN-212; 57–87% of young [S03-C, -D, -G, -H] | Cannot explain mismatched-subtype protection | *[outside the dataset]* Required regulatory immunogenicity endpoint; not what differentiates this asset |

**Could it go into patients, and in what role?** The mouse assays cannot: they need lung tissue or lymph node. Their accessible counterparts could *[outside the dataset]*: interferon-inducible proteins or gene signatures and GM-CSF in nasal or airway lining fluid and blood at 16–24 hours, and interferon-γ ELISpot on blood cells against conserved influenza antigens. The role is **pharmacodynamic and exploratory**: proof of mechanism, dose selection and an internal go/no-go. It is not a surrogate endpoint and not a patient-selection test. Two things must happen first: Study 1 has to bridge from lung tissue to blood or nasal fluid and link the marker to outcome in the same animals, and Study 2 has to show which immune arm protects.

---

## 6. What the next studies have to establish

Sequence: Study 0 first (2–4 weeks). Studies 1–4 then run in parallel; aged-animal supply is the critical path. First gate review at about month 6 (day-14 and day-60 efficacy, mechanism, single-dose safety, human cells); second at about month 10–12 (day-180 durability, repeat-dose safety, manganese clearance). Full designs, sample-size reasoning and pass criteria: Appendix D.

| Study | Must establish | Population | Arms and comparators | Endpoints | Read-outs | Timing |
|---|---|---|---|---|---|---|
| **0. Record reconciliation** (Gate 0) | Which of each pair of contradictory records is right; identity of comparator groups | None (cage cards, mortality and weight logs, notebook entries, cytometry and plate files) | Survival table against weight log against mortality log, items Q1–Q19 | Verified survival count per arm; corrected dataset | Re-run of the supplied scripts on the corrected file | 2–4 weeks, before any new spend |
| **1. Confirmatory efficacy, dose and components** (Gate 1) | Reproducible under randomisation and blinding; both sexes; dose needed; whether manganese must be complexed with the agonist; durability; link between an early blood marker and outcome in the same animal | BALB/c 18–20 months, male and female; young reference; unchallenged sentinels per cohort; n = 15 per arm (20 for dose arms) | Vaccine alone; sham; PSLN-212 at 20 µg, 40 µg and two doses; PSLN-344 at 5, 10, 20, 40 µg; manganese-only particle; PSLN-212 + free manganese; PSLN-344 alone; intramuscular high-dose or oil-in-water benchmark; young + PSLN-212 | Primary: survival to day 14 after mismatched-subtype challenge. Secondary: weight loss in all animals (no carry-forward), lung virus titre day 3 and 6, lung pathology | Blood interferon signature and nasal wash at 16–24 h in the challenged animals; HAI, neutralisation, IgG before challenge; blood T-cell ELISpot; satellite lungs for *Ifnb1*, *Gm-csf*, dendritic cells | Dose day 0; challenge day 14 and day 60 (in-life about 3 months); day-180 arm reads out at about month 8 |
| **2. What mediates protection** (Gate 2) | Whether protection needs CD8 T cells, CD4 T cells or antibody; whether interferon receptor, GM-CSF and CCR2 are needed for survival in aged animals | BALB/c 18–20 months, both sexes, n = 15 per arm | Vaccine + PSLN-344 with: isotype; anti-CD8; anti-CD4; FTY720; anti-interferon-receptor; anti-GM-CSF; CCR2 antagonist. Serum transfer from PSLN-344 against sham donors. PSLN-212 and sham controls | Primary: survival. Secondary: weight, lung virus titre day 6 | Depletion check; lung resident-memory CD8 with intravascular labelling; antibody against vaccine and challenge strains | Challenge day 14, one CD8 cohort at day 60; about 4–5 months |
| **3. Safety, biodistribution, reversibility** (Gate 3) | Safety margin; manganese in olfactory bulb and brain; time for lung inflammation to resolve in aged animals; repeat dosing | BALB/c 18–20 months and 8 weeks, both sexes; n = 10 per sex per group for pathology, 5 per time point for manganese. Second species at the GLP stage | Buffer; empty liposome; PSLN-212; PSLN-344 at 1, 3 and 10 times the effective dose, single and three doses; intranasal manganese chloride (positive control for brain uptake); cholera toxin (positive control as in S10-A) | Manganese in tissues; histopathology of nose, lung, brain; BAL neutrophils; weight, temperature, clinical score | Lung cytokine mRNA and protein; clinical chemistry; neurobehaviour | Tissues at day 1, 3, 7, 28, 90; BAL and cytokines at 16 h, 72 h, day 7, day 14; about 5–6 months |
| **4. Human translatability** (Gate 4) | Manganese enhances the response in human cells, including older donors and common STING variants; human alveolar macrophages take up the particle; activity in a second species with a clinical-type device | Blood cells from at least 20 donors aged 65 or over and 20 aged 18–40; alveolar macrophages or lung slices from at least 6 older donors; aged ferrets | PSLN-344 against PSLN-212, empty liposome, manganese-only particle and cGAMP, five doses | Interferon-β, CXCL10, GM-CSF, IL-6, TNF protein; dendritic-cell phenotype. Ferret: HAI, shedding, illness after mismatched challenge | Uptake with and without surfactant proteins; viability | 16 h and 72 h ex vivo, about 3–4 months; ferret about 6 months |
| **5. Product definition** (parallel, not a gate) | Whether the effect survives a clinically usable antigen and route; basic CMC | Aged mice | Whole virus against split, subunit or recombinant antigen; instillation against aerosol against intramuscular; three lots | Survival after mismatched challenge; HAI; T-cell response | Particle size, manganese content and release, stability at 0, 1, 3, 6 months | About 6 months |
| **First human study** (only after Gates 1–4) *[outside the dataset]* | Safety and proof of mechanism in the target population | Adults 65 and over, with an 18–49 reference cohort | Antigen + PSLN-344 at three doses; antigen alone by the same route; licensed enhanced vaccine for over-65s | Primary: safety, including neurological events, smell testing, lung function. Secondary: HAI and neutralisation at day 28 and 180 | Nasal-fluid and blood interferon markers and GM-CSF; blood T-cell ELISpot to matched and mismatched antigens | Markers pre-dose, 16–24 h, 72 h, day 7; T cells day 0, 7–10, 28, 180 |

---

## 7. If the committee drops it

**What would be dropped**

- The only formulation in the programme that protects the aged host: 85% against 14% for the parent. PSLN-212 is not a fallback for older adults. Nor, on these data, is CMP-204 (3/7) or the R848 particles (poorly tolerated, never challenged).
- Breadth and speed in that host: protection against mismatched subtypes and H5N1, including 9 of 9 evaluable animals against wild-type H5N1 two days after one dose [S03-J].
- A mechanistic lead that outlives the particle: the aged defect looks like a missing innate signal (interferon-β plus GM-CSF) that can be put back pharmacologically.

**The honest case for dropping**

1. Safety of a manganese-containing innate agonist delivered to the airway of older adults is unaddressed, and it is the hardest question to answer cheaply.
2. The evidence is mouse-only, with whole-virus antigen instilled into the lung, a format with no licensed precedent for this population *[outside the dataset]*.
3. The data package has integrity problems that must be fixed before anyone outside the company sees it.
4. Protection is not sterilising, and may wane by day 60.
5. The mechanism needs deep-lung delivery, which means a device.

If dropped, keep PSLN-212 for younger populations, where it already gives full protection, and keep the biology.

---

## 8. What I considered and ruled out

| Alternative or question | What I checked | Verdict |
|---|---|---|
| PSLN-344 simply delivers more agonist | Encapsulation 54.8% against 59.6% [S08-B] | Ruled out |
| A higher dose of PSLN-212 would do the same | *Ifnb1* plateaus at 14.7-fold at 40 µg; PSLN-344 reaches 21.0-fold at 10 µg [S08-A] | Ruled out for the interferon response; not tested on survival |
| Add a TLR7/8 agonist instead of manganese | PSLN-212/R848: *Ifnb1* 24.0-fold, below PSLN-344; 10.0% weight loss without recovery; *Tnf* 202-fold and *Il10* 179-fold at 16 h, still 50 and 45-fold at 72 h [S01-A, S08-D, S09-A] | Ruled out on tolerability |
| The cGAMP particle is good enough | *Ifnb1* 7.7-fold; IgG 181; 3/7 survival (subject to Q3) [S01-A, S03-A, S03-I] | Ruled out for aged hosts |
| Day-3 protection is a non-specific antiviral state | PSLN-344 alone 0/7 [S15-H] | Ruled out |
| Vaccine or empty liposome explains it | 0/7 and 1/80 | Ruled out |
| NK cells account for the early protection | Lung NK cells are only marginally higher with PSLN-344 than PSLN-212 at days 2 and 4 (+5.2 and +6.4 points; Tukey p = 0.15 and 0.13) and no different from day 6 [S11-D; R5, R7] | Not supported as a main driver |
| Manganese improves uptake | Uptake not higher under either reading [S08-C, S01-B] | Not supported |
| It is a BALB/c effect | C57BL/6 6/7 and Swiss Webster 6/7 [S15-L, S15-N] | Not supported, but see Q4 |
| Prior infection history removes the benefit | 6/7 with and without prior PR8 infection [S06-E and S06-F, rows 71–98] | Ruled out in this model |
| Day-60 deaths on PSLN-344 are old-age deaths | Weights 77.5–85.3% against 94.5–96.6% in sentinels | Ruled out; they are breakthrough disease |
| PSLN-344 skews to an IgG1 response | Recomputed from raw titres: 2.14, not 0.58 | Ruled out; the printed block is mislabelled |
| Manganese also helps the young | 8/8 against 8/8 three times [S09]; *Ifnb1* 1.34 times higher (Welch p = 0.009; Tukey p = 0.63) | No survival benefit detectable at ceiling |
| HAI ≥ 40 identifies protected animals | 5/5 aged PSLN-212 animals reach it; arm not protected | Not supported |
| Two doses of PSLN-212 could replace manganese | Post-boost IgG gap narrows for one strain only; no challenge or T-cell data after a boost [S13-I, S13-J] | **Not ruled out.** Arm added to Study 1 |
| PSLN-212 plus GM-CSF could replace manganese | Dendritic cells rise to 13.8% [S02-G]; no survival read-out; four daily doses | **Not ruled out** mechanistically; impractical as a product |
| CNS inflammation as with toxin adjuvants | No signal at 36 h in three transcripts [S10-A] | Not seen; manganese deposition not assessed |

**Data I chose not to rely on, and why:** the neutrophil block S11-B (duplicate of S11-A); the macrophage-transfer block S07-C (both columns carry the same header); the unlabelled region S08!A89:D101 (13 rows with no header); the tetramer blocks S05-A and S05-B (two animals per point, contradictory conditions); the printed ratio blocks S03-B and S03-F (mislabelled); group-mean body weights (carried-forward values); the second S09-A panel as a 16 h replicate (it is 72 h); S06-C and S06-D as two independent experiments (identical tables).

**Analytical choices I rejected:** arithmetic means for titres (geometric means used); treating an HAI of 0 as zero (set to half the lowest dilution); counting the S03-J animal with no recorded day as a survivor (excluded; counted as a death in the least favourable reading); pooling survival as if all experiments were one (stratified test used).

**What I could not assess from this dataset:** human relevance, manufacturability, cost, and anything about the raw records behind the workbook.

---

# Appendices

## Appendix A. How the workbook was read

- **Parsing.** Each block was addressed by explicit cell ranges taken from the workbook and the annotation, not by label, because labels repeat (two blocks called S06-E, two called S06-F, two panels called S09-A). After parsing, every numeric cell in the workbook belongs to a block or is a time or dose axis value; nothing was left unread (`analysis/parse_blocks.py`). I parsed 107 data panels and one unlabelled region.
- **Group order** was always taken from the printed header, never assumed. It changes between blocks (for example S02-F runs PSLN-344, PSLN-212, Sham; the weight tables run young, Sham, PSLN-212, PSLN-344).
- **Survival (R1).** A row with status 0 is an animal alive at the last observation. One PSLN-344 row in S03-J has a status but no day (S03!J46 with S03!G46 empty); it is excluded, leaving 9 evaluable, which matches the stated n. Log-rank results were checked against an independent implementation (`analysis/verify_lr.py`). Because arms are small, I also computed exact permutation p-values for the 15 head-to-head comparisons: the same 13 are below 0.05 (0.0006 to 0.021); the other two are 0.44 and 0.086 (`analysis/exact_lr.py`).
- **Body weight (R6).** The carried-forward rule was validated on the blocks where survival and weight tables agree: in S15-A, S15-B, S15-F, S15-I, S15-J, S15-K and S15-O every recorded death corresponds to a frozen or blank series and every survivor to a changing one. The rule also reproduces the sentinel deaths in S15-E and S15-G, animals that died without losing weight.
- **Which weight table belongs to which survival table.** The annotation names the pairing outright for S13-F, S13-G, S09-C, S09-E, S09-G, S15-I, S15-M and S15-O ("the animals of …"). For S15-A to S15-G, S15-J and S15-K it gives the same vaccine, challenge, day, groups and n as the matching S06 block without saying "the animals of"; I treated them as pairs. The sentinel deaths support this: the untreated animals that die in S06-E (one, day 4) and S06-G (three, days 3, 7, 10) are the ones whose weights freeze in S15-E (from day 4) and S15-G (from days 4, 8, 10).
- **Small samples.** Most immune blocks have 5 animals per arm, some 3, two have 2. P-values are given for orientation; the argument rests on effect sizes and on consistency across blocks. Blocks with n = 2 are described, not tested.
- **Age-gap fraction.** (PSLN-344 aged − PSLN-212 aged) ÷ (young reference − PSLN-212 aged). Intervals in Figure 4 are bootstrap intervals from resampling animals within arms (4,000 resamples).
- **Arm-level biomarker screen.** For each read-out measured in the four core arms, animals from the two protected arms (PSLN-344 aged, young reference) were compared with animals from the two unprotected arms (Sham, PSLN-212 aged). "Complete separation" means no overlap between the two sets of animals. This is an association across arms, not a prediction for individuals.

## Appendix B. Where every number is

- `evidence_ledger.csv`: 359 rows. Columns: id, statement, value, block, cells, reduction rule.
- `block_directory.csv`: every block and group with its cell range, stated n and observed n.
- `efficacy_table.csv`, `survival_summary.csv`, `survival_pairwise.csv`: per-arm survival, intervals, death days, all pairwise log-rank and Fisher tests.
- `immuno_summary.csv`, `immuno_tests.csv`, `key_contrasts.csv`: every immune block, every pairwise test.
- `bw_per_animal.csv`, `bw_group_summary.csv`: per-animal weight classification and nadir; comparison with survival tables.
- `restoration_index.csv`, `biomarker_screen.csv`: Figure 4 and the Section 5 screen.

## Appendix C. Data-integrity log

Items Q1–Q9 are summarised in Section 4.1. Evidence and handling for all items:

| Item | Blocks (cells) | Evidence | Handling |
|---|---|---|---|
| Q1 Identical survival tables | S06-C (S06!M3:Q30), S06-D (S06!A34:E61) | All 28 records match group for group: Sham deaths on days 4, 4, 5, 6, 6, 6, 7; PSLN-212 deaths on days 5, 8, 10, 10, 12 and two alive; PSLN-344 and young all alive. The weight table for the day-3 experiment (S15-D) shows two PSLN-344 animals (S15!W37:W40 = 79.5; S15!AC37:AC40 = 85.2) and two young animals (S15!F37:F40 = 82.1; S15!G38:G40 = 76.5) with carried-forward weights that S06-D does not record as deaths | Both kept in Table 1; counted once in the pooled sensitivity analysis |
| Q2 Survival table against weight table | S06-C/S15-C PSLN-212 2/7 against 1/7; S06-D/S15-D PSLN-344 7/7 against 5/7 and young 7/7 against 5/7; S06-E/S15-E PSLN-212 0/7 against 1/7 and PSLN-344 5/7 against 6/7; S06-G/S15-G PSLN-344 4/7 against 5/7; S15-L/S15-M young 6/7 against 7/7; S03-I/S13-F PSLN-212 0/7 against 3/7; S03-J/S13-G "Sham" 1/10 against 5/10 (see Q3); S09-F/S09-G Sham 7 rows against 8 animals weighed | Per-animal classification in `bw_per_animal.csv` | Survival tables primary; least favourable reading reported |
| Q3 Group names differ between paired tables | S03-I (S03!A17:F51) against S13-F (S13!B33:AJ40); S03-J (S03!G17:J46) against S13-G (S13!B43:AE50) | S03-I has Sham, CMP-204, PSLN-212, PSLN-344, young. S13-F has young, Sham, PSLN-212, PSLN-344, Naïve. The S13-F "PSLN-212" column (4 dead, 3 recovering) matches the S03-I "CMP-204" count (4 deaths, 3 alive); the S13-F "Naïve" column (all dead by day 8) resembles S03-I "PSLN-212" (all dead by day 6). S03-J has Sham, PSLN-212, PSLN-344. S13-G has PSLN-344, Sham, Naïve. S13-G "Naïve" (1/10 alive) matches S03-J "Sham" (1/10); S13-G "Sham" (4–5/10 alive, deaths from day 10) resembles S03-J "PSLN-212" (3/10, deaths days 10–12) | PSLN-344 results used. Comparator identities flagged as unverified |
| Q4 Weight series re-used across experiments | S15-C PSLN-344 (S15!W23:AC30) against S15-I vaccine + PSLN-344 (S15!W72:AC79); S15-A (S15!W3:AC10), S15-M (S15!AD103:AJ110), S15-O (S15!AD134:AJ141) PSLN-344; S15-A Sham day 4 (S15!I5:O5) against S15-M PSLN-212 day 4 (S15!W105:AC105) | 40 of 49 post-day-0 values identical between S15-C and S15-I (days 4, 6, 8, 12 identical in all seven animals); the day-14 row differs, and in S15-C one animal goes from 77.9% to 90.1% between days 12 and 14. S15-A against S15-M 16 of 49; S15-M against S15-O 11 of 49; S15-A against S15-O 7 of 49; the same animal-5 series ending at 85.1% is in all three. S15-A Sham day 4 equals S15-M PSLN-212 day 4 in 7 of 7 | Not treated as independent evidence |
| Q5 Carried-forward weights | All challenge weight tables with complete columns, e.g. S15-A PSLN-212 (S15!P3:V10) | Six of seven animals died (S06-A) yet seven values are present on every day; sham groups are blanked instead | R6 |
| Q6 Ratio blocks mislabelled | S03-B (S03!G3:I7), S03-F (S03!G10:I14) against S13-A (S13!A3:C7), S13-B (S13!E3:G7), S13-C (S13!I3:K7), S13-D (S13!M3:O7) | For both strains, printed "PSLN-344" carries the raw PSLN-212 quotients, printed "PSLN-212(Y)" the raw PSLN-344 quotients and printed "PSLN-212" the raw young quotients; the 30 values agree to between three and six decimals (`analysis/check_ratio.py`). The raw labels agree with total IgG (S03-A, S03-E) | Recomputed from raw |
| Q7 Second S09-A panel is 72 h | S09!Y3:AS9 against S01!H3:L10 | 21 of 21 back-transformed *Ifnb1* values are values in the S01-A 72 h panel; none is a 16 h value. The first panel matches the 16 h panel 21 of 21. Also: the S09-A control is headed "PBS" but carries the *Ifnb1* values of the S01-A "Sham" group, and S09-A *Ifnb1* is three of the five S01-A animals, not a replicate | Analysed as 72 h; not counted as independent of S01-A |
| Q8 Neutrophil block duplicates macrophage block | S11-A (S11!B3:U7), S11-B (S11!B10:U14) | 34 of 40 cells identical for animals 1–2 of each group; 35 of 100 overall; group means differ by at most 2.5 points; "neutrophils" are 20% in aged and 37% in young lung at baseline, the alveolar-macrophage pattern | S11-B excluded |
| Q9 Uptake blocks conflict | S08-C (S08!A14:D18), S01-B (S01!B14:F17) | S08-C as printed: PSLN-SRB in 15.8% of type II and 13.8% of type I cells; PSLN-344-SRB 3.8% and 3.0%. S01-B: PSLN-SRB 15.8% type II, 3.8% type I. The first S08-C column shares 3 of 5 values with S01-B type II; the second S08-C column, headed type II/PSLN-344, shares 2 of 5 values with S01-B type I/PSLN-SRB. Transposing the second and third headers gives PSLN-SRB 15.8%/3.8% and PSLN-344-SRB 13.8%/3.0% | Used only for "uptake is not higher with manganese" |
| Q10 Duplicate header | S07-C (S07!B15:C20) | Both columns headed "Ly6C-CD206+ MΦ" (10.4% against 5.1% lung regulatory T cells, p = 0.003) | Excluded; direction unreadable |
| Q11 Unlabelled region | S08!A89:D101 | 13 rows, no header: column A = 14 throughout; 0 in column C for 6 rows and in column D for 7. Looks like the end of a survival table for two groups of 6 and 7 | Excluded |
| Q12 Stated n against rows | S03-J stated 9, 10 rows per group; S05-A and S05-B stated 3, 2 values per time point; S13-E stated 5, 7 rows per group; S09-F Sham 7 rows (the annotation attributes the 7-row Sham to S09-B, where the workbook has 8); S08-D PSLN-212/R848 4 values on day 10 | `analysis/audit_n.py` | Observed counts used |
| Q13 Undefined preparation | S08-A header S08!K2 "PSLN-344/R848" | Not in the Materials list, which has PSLN-212/R848 | Not used |
| Q14 Identical row | S09!G18:N18 and S09!W18:AD18 | Day-12 weights of young PSLN-344 equal young PSLN-212 in all 8 animals | Noted; young-animal weights only |
| Q15 Ambiguous conditions | S05-A, S05-B, S05-I | The annotation gives two immunisations for S05-A (ovalbumin; bivalent vaccine). The tetramer detects an influenza nucleoprotein epitope, not ovalbumin, and *[outside the dataset]* is restricted to the C57BL/6 haplotype, while the default strain is BALB/c. S05-I is "vaccinated as in S05-A" | S05-A and S05-B descriptive only; S05-I used with this caveat |
| Q16 Conditions not stated | S15-L, S15-N (challenge virus and day); PR8 arm of the imprinting experiment (challenge day); S13-H, S14-A, S11-E, S07-B (time point); "PTX" groups of S02-C, S02-E (adjuvant and age); S02-H, S05-C (recipient age); S03-J (challenge dose) | Annotation | Flagged where used |
| Q17 Sentinel deaths | Untreated groups: S06!L62:L68, S06!R62:R68, S06!F99:F105 | 1/7, 0/7 and 3/7 unchallenged animals died within 14 days; weights frozen at 94.5–96.6% | Background mortality acknowledged; sentinels built into Studies 1–3 |
| Q18 Derived block is a transform | S04-B Tfh:Tfr (S04!A15:D19) | Equals (100 − Foxp3%) ÷ Foxp3% in 20 of 20 animals | Not counted as separate evidence |
| Q19 Minor | S03-J | Annotation says 22 days of observation; the table censors at day 21 | Noted |

![Figure A2](figures/figA2_data_integrity_examples.png)

*Figure A2. Examples from the data-integrity log (items Q4, Q1, Q8, Q6, Q5, Q7).*

## Appendix D. Study designs

Sample sizes use Fisher's exact test, two-sided α = 0.05 (`analysis/power.py`): 15 per arm gives 98% power for 85% against 14% survival and 59% for 85% against 40%; 20 per arm gives 80% for 85% against 40%. With no events in 20 animals the upper 95% bound on the true rate is 14%.

**Study 0. Source-record reconciliation.** No animals; 2–4 weeks.
- Establish: which record in each contradictory pair is correct; group identities in S03-I, S03-J, S13-F, S13-G, S07-C, S08-C, S03-B, S03-F; origin of the unlabelled S08 rows; whether S06-D and the S15-C, S15-M, S15-O weight series were entered from their own experiments.
- Output: corrected workbook with an audit trail; this analysis re-run on it with the supplied scripts.
- Pass: the aged survival advantage is confirmed in primary records for the mismatched-subtype experiments (S06-A, S06-B, S06-E, S06-F, S06-G, S15-H). Anything that cannot be verified is repeated in Study 1.

**Study 1. Confirmatory efficacy, dose–response and components.**
- Establish: reproducibility under randomisation and blinded scoring; both sexes; dose–response for protection and the lowest fully effective dose; whether manganese must be complexed with the agonist; whether two doses of PSLN-212 match one of PSLN-344; effect on virus load and lung pathology; durability to day 180; whether an early blood or nasal marker predicts outcome in the same animal.
- Population: BALB/c 18–20 months at dosing, male and female (durability cohort 14–15 months at dosing so that the day-180 challenge falls near 20 months); young reference (8 weeks); untreated, unchallenged sentinels in each age cohort (n = 10). C57BL/6 satellite for tetramer staining.
- Arms: (1) vaccine alone; (2) vaccine + empty liposome; (3) PSLN-212 20 µg; (4) PSLN-212 40 µg; (5) PSLN-212 20 µg on day 0 and day 14; (6–9) PSLN-344 5, 10, 20, 40 µg; (10) manganese-only liposome, manganese matched to 20 µg PSLN-344; (11) PSLN-212 20 µg + free manganese, matched, admixed; (12) PSLN-344 20 µg without vaccine; (13) intramuscular high-dose or oil-in-water-adjuvanted vaccine *[outside the dataset]*; (14) young + PSLN-212 20 µg. 15 animals per arm, 20 for arms 6–9, plus 5 per arm per time point for terminal satellites.
- Challenge: Aichi H3N2 vaccine, 5 × mLD50 PR8 H1N1 at day 14 and day 60; day 180 for arms 2, 3, 8 and 14.
- Primary endpoint: survival to day 14 after challenge with a pre-specified humane endpoint, log-rank stratified by sex.
- Secondary: weight-loss area under the curve and nadir in all randomised animals with no carry-forward; lung virus titre on day 3 and day 6; lung histopathology score on day 6 and day 14; clinical score.
- Read-outs: blood at 16–24 h after dosing in the animals that go on to challenge (interferon-inducible chemokine, whole-blood interferon-stimulated gene score) and nasal wash where feasible; HAI, neutralisation and IgG on day 13 and day 59; blood interferon-γ ELISpot or tetramer on day 10–13; satellite lungs for *Ifnb1* and *Gm-csf* at 16 h, 36 h, 72 h and day 7, and monocyte-derived dendritic cells at day 4.
- Analysis: pre-registered; per-animal model of outcome on the early marker within the PSLN-344 dose arms.
- Pass (Gate 1): PSLN-344 20 µg survival ≥ 70% with its lower 95% bound above the PSLN-212 upper bound, in both sexes; a monotonic dose–response; a dose with ≥ 70% survival and ≤ 5% post-dose weight loss; manganese-only particle inferior to PSLN-344.

**Study 2. What mediates protection.**
- Establish: whether protection against a mismatched virus needs CD8 T cells (and lung-resident ones), CD4 T cells or antibody; whether interferon receptor, GM-CSF and CCR2 are needed for survival in aged animals.
- Population: BALB/c 18–20 months, both sexes, 15 per arm.
- Arms: vaccine + PSLN-344 with isotype control; anti-CD8 before challenge; anti-CD4 before challenge; FTY720 during challenge (blocks recirculation, so tests whether resident cells suffice); anti-interferon-receptor at dosing; anti-GM-CSF at dosing; CCR2 antagonist at dosing. Serum from vaccine + PSLN-344 aged donors, or from sham donors, into naive aged recipients before challenge. Controls: vaccine + PSLN-212; sham. STING-deficient young mice to confirm the target.
- Endpoints: survival (primary); weight; lung virus titre day 6.
- Read-outs: depletion efficiency; lung resident-memory CD8 with intravascular labelling; interferon-γ ELISpot; HAI and neutralisation against both vaccine and challenge strains; lung dendritic cells at day 4.
- Timing: challenge day 14; one CD8-depletion cohort at day 60. About 4–5 months.
- Gate 2 is informative either way. If CD8 depletion removes protection, the T-cell marker becomes the lead efficacy biomarker and the clinical plan needs T-cell endpoints. If serum transfers protection, an antibody-based path is open. If blocking interferon receptor or GM-CSF removes protection, the pharmacodynamic marker is on the causal path.

**Study 3. Safety, biodistribution and reversibility.**
- Establish: safety margin over the effective dose; manganese exposure of olfactory bulb and brain; how long lung inflammation lasts in aged animals; tolerability of repeat dosing; a real neutrophil read-out.
- Population: BALB/c 18–20 months and 8 weeks, both sexes; 10 per sex per group for pathology; 5 per time point for manganese. A second species at the GLP stage.
- Arms: buffer; empty liposome; PSLN-212 20 µg; PSLN-344 at 1, 3 and 10 times the effective dose (or the maximum feasible), as a single dose and as three doses two weeks apart; intranasal manganese chloride at matched manganese; cholera toxin.
- Endpoints: manganese by ICP-MS in olfactory bulb, striatum, cerebellum, lung, liver and blood at day 1, 3, 7, 28 and 90; histopathology of nasal cavity, olfactory epithelium, lung, brain and draining node; BAL differential counts, protein and LDH at 16 h, 72 h, day 7 and day 14; lung cytokine mRNA and protein at the same times; weight, temperature and clinical score daily for 14 days; clinical chemistry and haematology; open field, rotarod and olfactory habituation at day 7, 28 and 90.
- Pass (Gate 3): no-observed-adverse-effect level at least 3 times the effective dose; olfactory-bulb and brain manganese not above the empty-liposome control at the effective dose by day 28, with no histopathology; lung cytokines within 2-fold of baseline and BAL neutrophils at control level by day 14 in aged animals; no progressive weight loss on repeat dosing.

**Study 4. Human translatability.**
- Establish: manganese-complexation increases the response of human cells, including cells from older donors and across common STING variants; the aged-against-young gap exists in human cells and narrows; human alveolar macrophages take up the particle; activity in a second species with a clinical-type device.
- Population: blood monocytes and mononuclear cells from at least 20 donors aged 65 or over and 20 aged 18–40, genotyped for STING; alveolar macrophages or precision-cut lung slices from at least 6 older donors; aged ferrets.
- Comparators: PSLN-344, PSLN-212, empty liposome, manganese-only liposome, 2′3′-cGAMP; five doses.
- Read-outs: interferon-β, CXCL10, GM-CSF, IL-6, TNF and IL-10 protein at 16 h and 72 h; interferon-stimulated gene score; monocyte-to-dendritic-cell phenotype at day 4–5; viability; uptake of labelled particle with and without surfactant proteins A and D. Ferret: HAI, neutralisation, virus shedding, fever and weight after mismatched challenge, aerosol against nasal spray.
- Pass (Gate 4): at least a 2-fold manganese-dependent increase in interferon-β or CXCL10 in cells from older donors in two-thirds of donors, across genotypes; activity retained with aerosol delivery.

**Study 5. Product definition** (parallel).
- Antigen and route: split, subunit or recombinant haemagglutinin with or without nucleoprotein, against whole inactivated virus; aerosol against instillation against intramuscular; aged mice, mismatched challenge.
- CMC: manganese content and release, particle size, polydispersity and zeta potential, stability of lyophilised product at −20 °C and 4 °C over 6 months, three lots, a potency assay.

**First human study** (after Gates 1–4) *[outside the dataset]*.
- Design: randomised, observer-blind, dose-escalation.
- Population: healthy adults aged 65 or over; a reference cohort aged 18–49 to measure the age gap; chronic lung disease excluded in the first cohorts.
- Arms: antigen + PSLN-344 at three dose levels by the chosen airway route; antigen alone by the same route; a licensed enhanced vaccine for over-65s given intramuscularly.
- Primary endpoint: safety (solicited reactions for 7 days, unsolicited events for 28 days, neurological events of special interest including facial palsy, smell testing, spirometry, blood manganese).
- Secondary: HAI and microneutralisation geometric-mean-titre ratio and seroconversion at day 28; persistence at day 180.
- Biomarker read-outs: nasal lining fluid and blood interferon-inducible markers and GM-CSF before dosing and at 16–24 h, 72 h and day 7; blood interferon-γ ELISpot to vaccine-matched and mismatched or conserved antigens at day 0, 7–10, 28 and 180.
- Decision: the interferon response in the over-65 cohort reaches the young-adult reference range at a tolerated dose.

## Appendix E. Files

| File | Content |
|---|---|
| `PSLN-344_recommendation.md` / `.html` | This memo |
| `evidence_ledger.csv` | Every number, its block, cells and reduction rule |
| `block_directory.csv` | Every block and group: cells, stated n, observed n |
| `data_integrity_log.csv` | Appendix C as a table |
| `figures/` | Figures 1–5, A1, A2 |
| `analysis/` | Parsed data (`blocks.json`), all scripts, all intermediate tables |

![Figure A1](figures/figA1_KM_all_experiments.png)

*Figure A1. Kaplan-Meier curves for all 16 aged-animal comparisons.*

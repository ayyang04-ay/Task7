# PSLN-344: recommendation for the portfolio review

Prepared from `adjuvant_program_dataset.xlsx` (15 sheets, 107 data panels, about 6,100 animal-level records) and `adjuvant_program_annotation.pdf`. All experiments are in mice.

Numbers carry a tag such as [E01]. The tag points to `numbers_ledger.md`, which gives the source cells and the reduction for that number. Q-numbers point to the record-conflict register in Section 7.

---

## 1. Recommendation

**Advance PSLN-344, conditionally.** Keep it as the lead adjuvant for the older-adult influenza indication and fund a gated confirmatory stage. Do not drop it. Do not yet commit IND-enabling toxicology or GMP manufacturing spend.

### The case in five points

1. **It rescues aged animals and the Mn-free parent does not.** In the eight aged-BALB/c challenge experiments that ran all four arms, 46 of 56 PSLN-344 animals survived (82%; 95% CI 70–91), against 6 of 56 with PSLN-212 (11%), 0 of 56 with vaccine plus empty liposome, and 56 of 56 in the young PSLN-212 benchmark [E01–E04]. PSLN-344 had the higher survival in all 15 head-to-head cohorts in the workbook: three mouse strains, four challenge viruses plus wild-type H5N1, and challenge from 2 to 60 days after a single intranasal dose (Figure 1).
2. **The result survives the harshest reading of the records.** Several blocks conflict with each other (Section 7). Dropping every challenge block with a conflict leaves 25 of 35 vs 2 of 35. Taking, in each experiment, whichever of the survival table and the body-weight record is less favourable to PSLN-344 leaves 44 of 56 vs 10 of 56 [E06, E08].
3. **Both arms of the adaptive response return towards young levels.** Haemagglutination-inhibition (HAI) titre is 368 vs 46, which is 76% of young [I01]. CD8 T cells that respond to a virus absent from the vaccine are 6.4% vs 1.5% at day 14 and 9.9% vs 3.0% at day 60 [C03, C04].
4. **PSLN-212 cannot be dosed up to match it.** The lung interferon response to PSLN-212 levels off near 16-fold. PSLN-344 reaches 21-fold at half the standard dose and 46-fold at the standard 20 µg [M03].
5. **Early tolerability signals are mild.** Body weight dips to 96.4% of baseline and is back to 99.8% by day 10 [T01, T03]. Brain transcripts sit at 1.1 to 1.2 times the sham level, while the cholera-toxin positive control reads 2.7 to 5.5-fold [T10–T12]. Lung cytokine transcripts settle more slowly in aged animals than in young ones (Section 4), and this is not yet a safety case.

### The three gates

| Gate | What must be true before the next tranche of money | Why it is a gate |
|---|---|---|
| 0. Records (weeks, no animals) | The record conflicts that change a citable number (tier A in Section 7) are resolved against primary records, or the affected experiments are scheduled for repeat. | Two survival blocks are cell-for-cell identical, two derived blocks have rotated headers, and the body-weight blocks share values across experiments. Anyone checking the workbook will find these. |
| 1. Confirmation (Study 1) | The survival effect reproduces under randomisation and blinding, in both sexes, with a dose-response, an Mn-only control and a licensed-type comparator. | Every existing animal is female, every efficacy experiment used one dose, and no block records randomisation or blinding. |
| 2. Safety (Study 3) | Manganese does not accumulate in olfactory bulb or brain, and the lung response resolves. | The product puts manganese into the airway of an older population. The workbook has no Mn measurement in any tissue, no histopathology, and no usable neutrophil data. |

### What would reverse the recommendation

- Study 1 fails to reach 70% survival with PSLN-344, or the margin over PSLN-212 falls below 40 points. (70% is the lower confidence bound of the pooled estimate; 40 points is just under the lower confidence bound of the worst-case gain, 44 points [E30].)
- An Mn-only liposome matches PSLN-344. The asset would then be manganese rather than the CDN-1807–Mn combination, and the programme would need re-scoping.
- Manganese persists in brain tissue with a histological or functional correlate, or lung inflammation is unresolved at day 14 at the efficacious dose.
- PSLN-344 shows no advantage over PSLN-212 in cells from older human donors, or CDN-1807 is inactive on common human STING variants.
- Survival after a 60-day interval falls towards the PSLN-212 range in a larger cohort, and a boost does not restore it.

### The forward view in three lines

- **Driver of protection.** Protection needs vaccine and adjuvant together, needs manganese in aged animals, and works against virus subtypes that are absent from the vaccine. The best-supported effector is a lung CD8 T-cell response. No experiment has removed those cells and measured survival, so this is an inference (Section 5.1).
- **Biomarker.** Carry forward the cross-reactive CD8 interferon-γ response as an exploratory pharmacodynamic marker, measured in patients as a blood ELISpot. Pair it with an early interferon signature as a target-engagement marker. Neither is a correlate of protection yet (Section 5.2).
- **Next studies.** A record reconciliation and five studies, set out in Section 5.3 with endpoints, populations, comparators, read-outs and timing.

---

## 2. How the numbers were produced

- **Scope.** I had the workbook and its annotation only. No primary records, protocols or study plans were available, so where two blocks conflict I report both readings and show that the conclusion holds under each.
- **Unit of analysis.** The animal. The workbook stores per-animal values; I computed every group summary.
- **Reductions.** Percentages and linear fold-changes: arithmetic mean ± SD. Titres: geometric mean, with an HAI reading of 0 set to 5 (half the lowest dilution tested). The S09-A panel is stored as log10, so I report 10 to the power of the mean. Survival: animals with status 0 at the end of observation, divided by animals with a recorded time, with exact (Clopper–Pearson) 95% confidence intervals.
- **Tests.** The annotation's stated methods: one-way ANOVA with Tukey's test, Student's t, and log-rank. Titres were tested on the log10 scale. I added Welch's t-test, Fisher's exact test, and, for pooled survival, a Cochran–Mantel–Haenszel test and a stratified log-rank test with experiment as the stratum. P-values are descriptive; groups hold 2 to 10 animals and nothing is corrected for the number of blocks.
- **Age convention.** Groups without a (Y) suffix are aged (20 months or older unless the block says otherwise). "Young PSLN-212" is a benchmark for what a working response looks like. It is not a control for PSLN-344, because age differs.
- **Exclusions.** Four, all declared: the S03-J animal with no recorded time (Q04); the unlabelled rows at S08 89–101 (Q13); the S11-B "neutrophil" block (Q06); and the printed S03-B/S03-F quotients, which I replaced by recomputation from the raw titres (Q01).
- **Body weights and deaths.** In the body-weight blocks a dead animal's series either goes blank or repeats its last value to day 14. I read both patterns as deaths. That reading reproduces the death count of the paired survival table in 55 of 65 arms (`weight_vs_survival.csv`); the ten that differ are the conflicts listed in Section 7.
- **Reproducibility.** `analysis/blocks.py` maps every numeric cell in the workbook to a block, group and animal. A coverage check confirms that the only cells it leaves out are axis labels and the unlabelled S08 rows. Every table in this report is generated by the scripts in `analysis/`.

---

## 3. The case for advancing

### 3.1 Protection in aged animals

![Figure 1](figures/fig1_survival_overview.png)

**Table 1. Survival by experiment (survivors / n).** Source: time-to-event blocks named in the first column; reduction as in Section 2.

| Block | Vaccine → challenge | Interval | Sham | PSLN-212 | PSLN-344 | Young PSLN-212 | PSLN-344 vs PSLN-212, log-rank p |
|---|---|---|---|---|---|---|---|
| S03-I | Bivalent → CA09 H1N1 (matched strain, 10× mLD50) | 14 d | 0/7 | 0/7 † | 7/7 | 7/7 | 0.0004 |
| S06-A | Aichi H3N2 → PR8 H1N1 | 14 d | 0/7 | 1/7 | 6/7 | 7/7 | 0.008 |
| S06-C | Bivalent → rgH5N1 | 14 d | 0/7 | 2/7 | 7/7 ‡ | 7/7 | 0.007 |
| S03-J | rgH5N1 → wild-type H5N1 | 2 d | 1/10 † | 3/10 † | 9/9 | – | 0.002 |
| S06-B | Aichi H3N2 → PR8 H1N1 | 3 d | 0/7 | 0/7 | 5/7 | 7/7 | 0.0009 |
| S06-D | Bivalent → rgH5N1 | 3 d | 0/7 | 2/7 | 7/7 ‡ | 7/7 | 0.007 |
| S15-H | Bivalent → rgH5N1 | 3 d | 0/7 (vaccine alone) | – | 6/7 | – | – |
| S06-E (rows 34–68) | Aichi H3N2 → PR8 H1N1 | 60 d | 0/7 | 0/7 | 5/7 | 7/7 | 0.002 |
| S06-F (rows 34–68) | Bivalent → rgH5N1 | 60 d | 0/7 | 1/7 | 5/7 | 7/7 | 0.009 |
| S06-G | CA09 H1N1 → Perth H3N2 | 60 d | 0/7 | 0/7 | 4/7 | 7/7 | 0.015 |
| S15-L | Aged C57BL/6, bivalent, virus not stated | not stated | 0/7 | 0/7 | 6/7 § | 6/7 | 0.001 |
| S15-N | Aged Swiss Webster, bivalent, virus not stated | not stated | 0/7 | 2/7 | 6/7 § | 7/7 | 0.056 |

† Arm identity or count conflicts with the paired body-weight block (Q03, Q04). ‡ S06-C and S06-D hold identical data (Q02). § The PSLN-344 arm has the same single death at day 8 as S06-A, and its body-weight block shares values with the BALB/c block S15-A (Q08). Cell ranges for every arm are in `survival_by_group.csv` (sheet "Survival_by_arm" of the supporting workbook); S03-J, S15-H, S15-L and S15-N are also ledger entries E15–E18.

**Table 2. Pooled survival and sensitivity analyses, aged BALB/c.**

| Analysis | PSLN-344 | PSLN-212 | Test | Tag |
|---|---|---|---|---|
| All eight four-arm experiments, as recorded | 46/56 (82.1%; CI 70–91) | 6/56 (10.7%; CI 4–22) | stratified log-rank p = 4×10⁻¹⁶; CMH p = 2×10⁻¹³ | E01, E02 |
| The four with no shared HA or NA subtype (S06-A, B, E, G) | 20/28 (71%) | 1/28 (4%) | CMH p = 1×10⁻⁶ | E29 |
| Drop S06-D (duplicate of S06-C) | 39/49 (79.6%) | 4/49 (8.2%) | CMH p = 8×10⁻¹² | E05 |
| Drop S03-I, S06-C, S06-D (every block with a table-level conflict) | 25/35 (71.4%) | 2/35 (5.7%) | CMH p = 1×10⁻⁷ | E06 |
| Deaths taken from the paired body-weight blocks | 46/56 (82.1%) | 9/56 (16.1%) | CMH p = 2×10⁻¹¹ | E07 |
| Worst case for PSLN-344 (larger of table and weight deaths for PSLN-344, smaller for PSLN-212) | 44/56 (78.6%) | 10/56 (17.9%) | CMH p = 4.5×10⁻¹⁰ | E08 |
| Challenge 14 d after dose (3 experiments) | 20/21 (95%) | 3/21 (14%) | stratified log-rank p = 3×10⁻⁷ | E09 |
| Challenge 3 d after dose (2 experiments) | 12/14 (86%) | 2/14 (14%) | p = 2×10⁻⁵ | E10 |
| Challenge 60 d after dose (3 experiments) | 14/21 (67%; CI 43–85) | 1/21 (5%) | p = 2×10⁻⁶ | E11 |
| Every aged or middle-aged cohort in the workbook (16 and 15 cohorts) | 97/114 (85.1%; CI 77–91) | 15/108 (13.9%; CI 8–22) | descriptive | E22, E23 |

The absolute survival gain over PSLN-212 is 71 percentage points (95% CI 55 to 81) as recorded, and 61 points (44 to 73) in the worst case [E30].

Five further points carry weight in the case.

- **Protection needs both components.** Challenged 3 days after dosing, vaccine plus PSLN-344 protected 6 of 7; PSLN-344 alone 0 of 7; vaccine alone 0 of 7 (S15-H; log-rank p = 0.0001) [E16]. The early protection is therefore not a non-specific antiviral state left by the adjuvant.
- **It is fast.** Survival was 9 of 9 against wild-type H5N1 two days after one dose [E15]. At three days it was 12 of 14 in the two four-arm experiments (10 of 14 if the S06-D body-weight record is the correct one; Q02) and 6 of 7 in S15-H [E10, E16].
- **It crosses subtypes.** Seven of the eight BALB/c experiments challenged with a subtype that was not in the vaccine. In four of them vaccine and challenge share neither haemagglutinin nor neuraminidase subtype (S06-A, B, E, G); there PSLN-344 protected 20 of 28 and PSLN-212 1 of 28 [E29].
- **It holds in animals with prior influenza exposure.** In 14-month-old mice infected with PR8 four months earlier, PSLN-344 protected 6 of 7 against PR8 and 6 of 7 against Perth H3N2, the same as in unexposed animals. PSLN-212 protected 4 of 7 and 0 of 7 in exposed animals and 0 of 7 in both unexposed groups [E19, E20]. PSLN-212 is therefore already failing at 14 months.
- **The benefit is specific to age.** Across all young cohorts PSLN-212 protected 93 of 94 and PSLN-344 31 of 31; in the three experiments that ran both (S09-B, D, F) each gave 24 of 24. PSLN-344 recovered weight more slowly after a day-180 challenge (95.6% vs 99.2% at day 14; p = 0.004) [E25–E27]. PSLN-344 is an older-adult asset, not a better general adjuvant.

![Figure 2](figures/fig2_km_pooled.png)

### 3.2 The immune response is restored towards young

![Figure 3](figures/fig3_restoration_index.png)

All 24 read-outs in Figure 3 are in `restoration_index.csv` and in the ledger (M01, M04–M08, M11, M12, B01, B02, I01–I08, C01–C06).

**Table 3. Immune read-outs after one intranasal dose.** n = 5 per group unless shown. Titres are geometric means; others are means. "Mn effect" is PSLN-344 ÷ PSLN-212 with its 95% CI. P-values are Tukey-adjusted for PSLN-344 vs PSLN-212.

| Read-out (block) | Sham | PSLN-212 | PSLN-344 | Young PSLN-212 | Mn effect | % of young | p | Tag |
|---|---|---|---|---|---|---|---|---|
| HAI, CA09, day 14 (S03-C) | 8 | 46 | 368 | 485 | 8.0× (3.9–16) | 76 | 6×10⁻⁶ | I01 |
| HAI, Aichi, day 14 (S03-G) | 10 | 35 | 320 | 368 | 9.2× (4.2–20) | 87 | 2×10⁻⁶ | I02 |
| Serum IgG, CA09, day 14 (S03-A) | 56 | 393 | 7,305 | 11,959 | 18.6× (9.1–38) | 61 | 3×10⁻⁶ | I03 |
| Neutralising titre, CA09, day 14 (S03-D) | 52 | 418 | 3,840 | 6,686 | 9.2× (3.1–27) | 57 | 0.0002 | I05 |
| IgG2a : IgG1, CA09 (S13-A ÷ S13-B, recomputed) | – | 0.58 | 2.14 | 2.97 | 3.7× | 72 | 0.007 (Welch, log) | I10 |
| Germinal-centre B cells %, day 7 (S03-K) | 1.2 | 2.3 | 6.5 | 9.8 | 2.8× (2.0–3.9) | 67 | 0.007 | B01 |
| Ki-67+ CD8 %, lung, day 3 (S05-D) | 0.8 | 3.5 | 9.4 | 9.9 | 2.7× (1.7–4.3) | 94 | 0.0008 | C01 |
| IFN-γ+ CD8 % to rgH5N1, day 14 (S05-F) | 0.7 | 1.5 | 6.4 | 9.2 | 4.2× (3.1–5.7) | 69 | 7×10⁻⁸ | C03 |
| IFN-γ+ CD8 % to rgH5N1, day 60 (S05-G) | 1.5 | 3.0 | 9.9 | 14.4 | 3.2× (1.7–6.3) | 69 | 0.0008 | C04 |
| Lung resident-memory CD8 %, day 25 (S05-I) | 0.6 | 1.0 | 4.0 | 6.0 | 4.0× (2.6–6.1) | 66 | 3×10⁻⁷ | C06 |
| CD40+ lymph-node dendritic cells %, day 3 (S02-D) | 4.0 | 5.6 | 11.2 | 38.7 | 2.0× (1.4–2.9) | 29 | 0.16 | M06 |

Of the 24 read-outs in Figure 3, 19 sit between 57% and 99% of the young benchmark. The five that do not are dendritic-cell CD40 and CD86 (29%, 38%), Aichi IgG at day 14 (41%), and IgG after a day-14 boost (38%, 29%) [M06, M07, I04, I07, I08]. Restoration is therefore substantial but incomplete, and a boost does not close the gap to young animals.

One correction matters here. Sheet S03 prints the IgG2a : IgG1 quotient for PSLN-344 as 0.58, which would mean an IgG1-skewed response, worse than PSLN-212. Recomputing from the raw subclass titres on sheet S13 shows that the S03-B and S03-F headers are rotated. The correct values are 2.14 for PSLN-344 and 0.58 for PSLN-212 [I10, I11; Q01; Figure 7A].

### 3.3 Why manganese matters, and why PSLN-212 cannot be dosed up

![Figure 4](figures/fig4_dose_response.png)

- Sixteen hours after adjuvant alone, lung Ifnb1 is 37.1 ± 4.8-fold with PSLN-344 in aged animals, 16.6 ± 2.1 with PSLN-212, and 37.6 ± 3.5 with PSLN-212 in young animals (S01-A, n = 5). Manganese returns the aged interferon response to the young level (99%; CI 84–116) [M01].
- The dose-response (S08-A, n = 3 per dose) gives a fitted ceiling of 52.8 for PSLN-344 and 15.6 for PSLN-212, with similar half-maximal doses (11.2 and 9.5 µg). The difference is in the ceiling, not the potency [M03]. The block does not state the animals' age; the values match the aged groups of S01-A.
- Encapsulation efficiency does not explain it: 54.8% for PSLN-344 and 59.6% for PSLN-212 (S08-B; ANOVA p = 0.15) [M26].
- Downstream, PSLN-344 raises lung Gm-csf (8.7-fold vs 1.6-fold at 36 h), lung monocytes at day 4 (30.6% vs 16.7%; young 32.2%) and migratory dendritic cells (30.7% vs 7.3%; young 35.0%) [M13, M14, M04].

### 3.4 Tolerability

![Figure 5](figures/fig5_tolerability.png)

- **Body weight after dosing (S08-D, n = 5).** Mean nadir 96.4 ± 1.5% with PSLN-344, 97.0 ± 1.7% with PSLN-212 and 98.2 ± 1.1% with vaccine alone; the lowest PSLN-344 animal reached 94.2%. The weight-deficit area over 10 days is 20.3 %·day vs 7.5 for vaccine alone (p = 0.03) and 13.5 for PSLN-212 (p = 0.27). All PSLN-344 animals were at 99.2% or above by day 10 [T01–T03].
- **The assay can detect a bad profile.** PSLN-212/R848 fell to a mean of 90.6% at day 10, with one animal missing that reading and one at 84.7% [T03]. Its lung Tnf and Il10 transcripts were 202-fold and 179-fold at 16 h [T04, T06].
- **Brain transcripts (S10-A, n = 5, 36 h).** PSLN-344 vs sham: Ifnb1 ratio 1.13, Tnf 1.21, Isg15 1.08 (Tukey p ≥ 0.92). Cholera toxin: 5.5, 3.5 and 2.7-fold over PBS, each significantly above PSLN-344 [T10–T12].
- **Lung cytokine transcripts (S09-A, n = 3, adjuvant alone).** At 16 h, aged PSLN-344 lungs show Tnf at 40.5-fold and Il10 at 7.3-fold, against 13.9 and 1.8 for PSLN-212 in young lungs (p = 0.009 and 0.02) [T04, T06]. At 72 h the aged values are still 8.4 and 4.2, while young lungs are back at or below baseline [T07, T09].

Section 4 sets out why this does not amount to a safety case.

---

## 4. Where the case is weak, and the answer to each challenge

| Challenge the committee can raise | What the data say | Position |
|---|---|---|
| "The records contain errors." | Correct. Section 7 lists 12 conflicts between blocks; eight change a number someone would cite. | The survival conclusion holds under every recoding (Table 2). The conflicts must be fixed before the numbers leave the building (Gate 0). |
| "Mouse data, female only, n = 7, one dose, no blinding." | Correct. A single experiment of 7 per arm had about 67% power for the effect seen (`power_calcs.csv`). The strength is replication: 16 cohorts. | Study 1 is designed to remove each of these. |
| "Protection fades." | At day 60 survival is 14/21, against 20/21 at day 14 (Fisher p = 0.045) and 21/21 in young animals (stratified log-rank p = 0.005) [E12, E14]. It is still 14/21 vs 1/21 for PSLN-212. The day-60 CD8 response is 3.2 times PSLN-212 [C04]. | Durability is the main efficacy risk. It needs a longer interval, a boost arm and larger groups. |
| "Old mice die anyway." | In the day-60 experiments 4 of 21 untreated, unchallenged animals died within 14 days (1, 0 and 3 of 7) [E13]. Their weights stayed at 94.5–96.6%. The PSLN-344 animals that died had wasted to 77.5–85.3% (Q09). | Background deaths exist but do not explain the PSLN-344 deaths. PSLN-344 vs untreated is p = 0.48, which n = 21 cannot resolve. Future late-challenge studies need an unchallenged arm. |
| "It does not prevent illness." | Correct. Surviving PSLN-344 animals lost weight to a mean nadir of 85–92% across experiments; young animals 88–94% [E28]. No block measures viral load. | The claim is protection from death, not from infection. Study 1 adds lung virus titres. |
| "Intranasal manganese reaches the brain." | Not tested. S10-A shows no transcript signal at one time point. Its Tnf value is 1.59 times PBS (Welch p = 0.05; Tukey p = 0.54), it has no PSLN-212 arm, and the brain region is not specified [T11]. | This is Gate 2. A 36-hour transcript panel cannot stand in for tissue Mn and histology. Context from outside our data: inhaled manganese is known to travel along the olfactory nerve, and an earlier toxin-adjuvanted nasal influenza vaccine was withdrawn over facial-nerve palsy, so regulators will ask. |
| "A STING agonist will inflame old lungs." | At 72 h, aged PSLN-344 lungs still show Tnf 8.4-fold, Il6 7.2-fold and Il10 4.2-fold; young PSLN-212 lungs are at 0.5, 3.1 and 0.1 [T07–T09]. Aged PSLN-212 shows the same Tnf and Il10 tail (5.2 and 4.2), so that part is an age effect. Il6 is the exception: 7.2 vs 1.9, p = 0.03 [T08]. Lung monocytes are still 18.4% at day 8 against a 9.2% baseline [M14]. The time point of that cytokine panel is inferred (Q05). | Resolution has not been shown. Study 3 follows it to day 14 with protein, cell counts and histology. |
| "Is the active principle manganese alone?" | Unknown. No block has an Mn-only liposome or free Mn. | Study 1 includes the control. |
| "Why not boost PSLN-212, or dose it higher?" | Higher dose: the interferon response plateaus (Section 3.3). Boost: the IgG gap narrows from 18.6-fold to 3.5-fold for CA09 but stays 11.5-fold for Aichi, and no block measures protection or CD8 after a boost [I03, I07, I08]. | Dose escalation is ruled out. A boosted PSLN-212 arm is an open question and belongs in Study 1. |
| "Regulators want HAI." | HAI is restored (Table 3). But all five aged PSLN-212 animals reached HAI ≥ 40, the human seroprotection threshold, and that group was not protected (0/7 in S03-I; 3/7 in the paired weight block) [I09; Q03]. | HAI is available as the conventional immunogenicity endpoint. It will not capture what is distinctive about this asset. |
| "How does it compare with licensed vaccines for older adults?" | No data. The comparators in the workbook are internal formulations. | Study 1 adds a licensed-type comparator. |
| "Will a nasal spray reach the cells that matter?" | After intranasal dosing in mice the liposome's dye cargo is found in 15.8% of type II alveolar epithelial cells (0.4% with free dye) [M30]. Uptake by alveolar macrophages depends on surfactant proteins A and D (43.1% vs 12.7% in knockouts), and monocyte recruitment depends on gap-junction transfer (7.3% vs 3.1% with carbenoxolone) [M24, M23]. The site of action is therefore the alveolar compartment, which a human nasal spray may not reach. | A real translational risk. Study 4b tests which compartment must be reached. |
| "The vaccine is whole inactivated virus." | Correct, in every block. Cross-reactive CD8 responses plausibly depend on internal viral proteins that subunit vaccines lack. | Study 4c tests licensed antigen formats. |

---

## 5. Forward view

### 5.1 What is actually driving the protection

**Established by experimental design**

- **It is adaptive and antigen-dependent.** Adjuvant without vaccine gave 0/7 and vaccine without adjuvant 0/7, against 6/7 together (S15-H) [E16].
- **In aged animals it depends on manganese.** PSLN-344 and PSLN-212 differ only in Mn, and the survival gap is 82% vs 11% [E01, E02]. In young animals it does not: CMP-204, PSLN-212 and PSLN-344 all protect fully (S09, S13-E) [E25, E26].
- **Neutralising antibody to the vaccine strain cannot be the whole explanation.** Protection appears when the challenge shares neither surface-protein subtype with the vaccine (20/28 vs 1/28) [E29]. It also appears when challenge comes 2 to 3 days after dosing, before any antibody response is in place; antibody arising during the infection could still contribute, so the cross-subtype result is the stronger argument.

**Supported by a consistent chain of intermediate read-outs**

| Link | Evidence | Limit |
|---|---|---|
| Liposome reaches alveolar macrophages through surfactant proteins | DiD+ macrophages 43.1% vs 12.7% in Sftpa1/Sftpd knockouts (S01-C) [M24]. Aged lungs start with fewer of these cells: 20–21% vs 36.6% in young (S11-A, day 0) [M29] | Young knockout animals; S11-A shares values with S11-B (Q06) |
| Signal passes to neighbouring cells through gap junctions | Carbenoxolone cuts recruited monocytes from 7.3% to 3.1% (S11-C) [M23] | Cell read-out only |
| Mn restores type I interferon | Ifnb1 37.1 vs 16.6-fold; young 37.6 (S01-A) [M01] | Transcript, whole lung |
| Interferon signalling lets recruited monocytes become dendritic cells | Monocyte-derived dendritic cells 19.7% from wild-type marrow vs 2.1% from Ifnar-knockout marrow; GM-CSF restores 12.4% (S02-H). Monocyte entry itself is little affected: 21.3% vs 15.4%, p = 0.10 (S12-A) [M17, M18] | Recipient age not stated; S12-A is young, n = 3 |
| Without enough signal, monocytes become macrophages instead | Ly6C+CCR2+ macrophages 19.0 vs 3.4 ×10⁵ at day 5 with PSLN-212 vs PSLN-344 (S07-A) [M16] | n = 3 |
| CD8 T cells are primed in the lung itself | Pertussis toxin blocks OT-I proliferation in the lymph node (30.9% to 6.8%) but not in lung (59.0% vs 55.1%) (S05-C) [M25] | Ovalbumin model; age not stated |
| The CD8 response depends on recruited monocytes | CCR2 antagonist cuts GZMB+ lung CD8 cells from 6.8% to 1.4% in young animals (S02-I) [M22]. In aged animals it cuts lung monocytes from 9.9% to 3.3% (S07-B) [M20] | The CD8 read-out is in young animals only |
| Cross-reactive and resident CD8 cells persist | Table 3, rows for S05-F, S05-G, S05-I | Different animals from the challenge cohorts |

**Not shown**

- No experiment depletes CD8 T cells, blocks CCR2, or transfers serum or cells and then measures survival. Every mechanistic intervention stops at a cell count.
- Antibody that binds the challenge viruses without neutralising them was never measured, so a contribution from such antibody cannot be excluded.
- Suppressive cells fall with PSLN-344 (follicular regulatory T cells 10.8% vs 26.7% at day 7; lung regulatory T cells 3.0% vs 6.7%) [B03, M10]. This could be a parallel driver. The follicular change has gone by day 30 (14.0% vs 13.9% for sham) [B04]. The one experiment that could link macrophage subsets to regulatory T cells cannot be read, because both groups carry the same label (Q07).

**Conclusion.** The best-supported account is that manganese restores the interferon signal that aged lungs fail to mount, which lets recruited monocytes become dendritic cells, which prime a lung CD8 T-cell response that protects across subtypes. Restored antibody probably contributes when the challenge matches the vaccine. The CD8 step is the link that most needs a direct test, and Study 2 supplies it.

### 5.2 Is there a biomarker of efficacy worth carrying forward?

**What the data can and cannot support.** Immune read-outs and challenge outcomes were measured in different animals. There is therefore no animal-level correlate of protection anywhere in the workbook, only agreement in rank across four or five groups. At that level almost every read-out separates protected from unprotected groups perfectly (`biomarker_window.csv`), so the data cannot rank candidates statistically. The choice rests on mechanism, durability and whether patients can be sampled.

![Figure 6](figures/fig6_biomarker.png)

| Candidate | In our data | Measurable in patients? | Verdict and role |
|---|---|---|---|
| **Cross-reactive CD8 IFN-γ response** (S05-F, S05-G) | 6.4% vs 1.5% at day 14; 9.9% vs 3.0% at day 60. Ranks groups as cross-subtype survival does at both times. Measured in lymph node. Granzyme B in CD8 cells moves with it: 5.7% vs 3.0% in lung at day 3, 4.1% vs 1.0% in lymph node at day 60 [C02, C05]. | Yes, as a blood IFN-γ ELISpot or intracellular-cytokine assay against conserved NP and M1 peptide pools, with granzyme B as a companion read-out, at baseline, day 7 and day 14–28. | **Carry forward as the lead candidate.** Role: exploratory pharmacodynamic and proof-of-mechanism endpoint in phase 1. Not a surrogate and not a go/no-go criterion until Study 1 shows the blood signal exists and tracks outcome in the same animal. |
| **Early type I interferon response** (S01-A, S08-A) | 37.1 vs 16.6-fold at 16 h; restored to young; dose-responsive. | Yes: interferon-β and CXCL10 in nasal lining fluid and an interferon-stimulated-gene score in blood, 16–24 h after dosing. | **Carry forward as the target-engagement marker.** Role: dose-finding and safety monitoring, read alongside TNF and IL-6. Not an efficacy marker: young PSLN-344 reaches 50.7-fold with no added benefit [M01]. |
| Serum HAI and neutralisation (S03-C, D, G, H) | Restored 8 to 9-fold. HAI ≥ 40 in 5/5 aged PSLN-212 animals without protection. Cannot explain cross-subtype or day-3 protection. | Yes; the regulatory standard. | Keep as the conventional immunogenicity endpoint. Do not present it as the efficacy biomarker for this asset. |
| Lung resident-memory CD8 (S05-I) | 4.0% vs 1.0%. | Only by bronchoscopy. | Mechanistic read-out for animal studies. |
| IgG2a : IgG1 (S13) | 2.14 vs 0.58. | No direct human equivalent. | Drop. Also the block with the header conflict. |
| Dendritic-cell CD40/CD86 (S02-D) | Only 29–38% of young although protection is restored. | Tissue only. | Drop: does not track protection. |
| Follicular regulatory T cells (S04-B, S04-C) | Lower at day 7, no different at day 30. | Blood subset possible. | Drop: transient. |
| Neutrophils (S11-B) | Block duplicates S11-A. | – | No data. |

**Answer.** Yes, one candidate is worth carrying: the cross-reactive CD8 response, with an interferon signature beside it to show target engagement. It can go into patients only as a blood assay and only as an exploratory pharmacodynamic marker. Its promotion to a correlate depends on two results that do not yet exist: paired immune and outcome data in the same animals (Study 1) and proof that CD8 T cells are required (Study 2). The workbook contains no blood cellular read-out at all, so whether a lung response shows in blood is itself untested.

### 5.3 Next studies

Durations are planning assumptions, not data. Sampling times are taken from the kinetics in the workbook: interferon at 16 h (S01-A), Gm-csf at 36 h (S02-F), monocytes and dendritic cells at day 4 (S01-D, E), CD8 activation at days 3–7 (S05), antibody at day 14 (S03), memory at days 25–60 (S05-G, I).

| Study | What it must establish | Population | Arms and comparators | Endpoints | Read-outs and timing | Decision rule |
|---|---|---|---|---|---|---|
| **0. Record reconciliation** (2–4 weeks) | That the tier-A conflicts can be resolved from primary records. | No animals. | – | Locked, audited data set. | Cage records, balance logs, plate maps and cytometry files for the blocks in Section 7. | Any survival block that cannot be verified is repeated as an arm of Study 1. |
| **1. Confirmatory dose-ranging challenge with paired sampling** (about 5–6 months, including sourcing aged animals) | (a) The effect reproduces under randomisation and blinding in both sexes. (b) Dose-response for protection and tolerability. (c) Mn alone vs Mn plus CDN-1807. (d) An animal-level immune correlate. (e) Position against a licensed-type vaccine. | BALB/c ≥ 20 months, both sexes, 15 per arm; young 7–8-week benchmark arm. Exact power at n = 15: 98% for 82% vs 11%, 89% for the worst-case 79% vs 18% (`power_calcs.csv`). | Vaccine + empty liposome; PSLN-212 20 µg; PSLN-344 2.5, 5, 10 and 20 µg; Mn-only liposome; PSLN-344 20 µg without vaccine; PSLN-212 with day-14 boost; licensed-type comparator (oil-in-water emulsion or four-fold antigen, intramuscular); young + PSLN-212; untreated, unchallenged. | Primary: survival to day 14 after a cross-subtype challenge (S06-A design) given 14 days after dosing, scored blind against a written humane endpoint. Secondary: lung virus titre at days 3 and 6 in satellite animals; weight-loss area; clinical score. | Same animals, before challenge: serum IFN-β and CXCL10 at 16–24 h; blood Ki-67+ and GZMB+ CD8 at day 5–7; serum HAI, neutralisation and IgG subclass, blood IFN-γ ELISpot to NP/M1, and nasal-wash IgA at day 13. Body weight daily to day 10 after dosing. A day-60 challenge cohort for the core arms at 20–30 per arm. | Go if PSLN-344 20 µg gives ≥ 70% survival and ≥ 40 points over PSLN-212, with both sexes in the same direction, and the Mn-only liposome no better than PSLN-212. |
| **2. Mechanism of protection** (about 4 months; can overlap Study 1) | Which effector is necessary and which is sufficient. This selects the biomarker. | BALB/c ≥ 20 months, vaccine + PSLN-344 20 µg, 10–12 per arm. | Isotype control; CD8 depletion before challenge; CD4 depletion; CCR2 antagonist during priming (S07-B regimen); FTY720 from day 10, to test whether lung-resident cells suffice; transfer of day-14 immune serum into naive aged recipients. | Primary: survival after cross-subtype challenge at day 3 and at day 14. Secondary: lung virus titre at day 6. | Depletion efficiency in blood and lung; binding antibody to the challenge virus and to NP in the transferred serum. | CD8 T cells are named as the driver only if depletion brings survival down to the PSLN-212 range and serum transfer does not protect. |
| **3. Safety and manganese disposition** (pilot about 4 months; GLP package 6–9 months after dose selection) | Where the manganese goes, whether lung and brain changes resolve, and a no-effect dose. | BALB/c ≥ 20 months and young, both sexes, 5–6 per time point; then a second species for the GLP package. | Vehicle; empty liposome; PSLN-212; PSLN-344 at 20 and 40 µg, single dose and two doses 14 days apart (S13-I regimen); Mn-matched manganese chloride intranasally as a positive control for olfactory uptake; cholera toxin as in S10-A. | Tissue Mn; histopathology; time to resolution of lung inflammation. | Mn by ICP-MS in olfactory bulb, striatum, cortex, cerebellum, lung, liver and blood at 16 h, 72 h, days 7, 28 and 90. Brain transcripts with olfactory bulb analysed separately at 16 h, 36 h, 72 h and day 7. Lavage cell counts including neutrophils, protein, and TNF, IL-6 and IL-10 protein at 16 h, 72 h, days 7 and 14. Histology of nasal cavity, lung and brain at days 3, 14 and 28. Observation battery and an olfaction test. | Stop if Mn remains above vehicle in brain at day 28 with a histological or functional correlate, or lung inflammation is unresolved at day 14 at the efficacious dose. |
| **4. Translation bridge** (about 3–4 months each, in parallel) | 4a: CDN-1807 with Mn is active in human cells, and the age deficit and its rescue exist there. 4b: which airway compartment must be reached. 4c: whether cross-protection survives a licensed antigen format. | 4a: blood monocytes and airway or lung tissue from donors ≥ 65 and 18–40 years, genotyped for common STING variants. 4b and 4c: BALB/c ≥ 20 months. | 4a: PSLN-212 vs PSLN-344 dose-response. 4b: small-volume nose-only vs standard instillation vs intratracheal delivery. 4c: split, subunit or recombinant HA vs whole inactivated virus, each with PSLN-344. | 4a: IFN-β and CXCL10 release. 4b and 4c: survival after cross-subtype challenge. | 4a: IFN-β, CXCL10, TNF, IL-6 at 6, 16 and 24 h; CD40 and CD86 on monocyte-derived cells at 48 h. 4b: lung and nasal Ifnb1 at 16 h. 4c: HAI and the S05-F CD8 assay at day 14. | 4a: if cells from older donors show no deficit with PSLN-212, or no rescue with PSLN-344, the reason to prefer PSLN-344 in people falls away. 4b selects nasal spray or inhaled presentation. 4c selects the antigen. |
| **5. Second species** (6–9 months, after Studies 1 and 3) | That the effect is not confined to mice. | Ferrets, young adult and as old as can be sourced; responsiveness of ferret cells to CDN-1807 confirmed first. | Vaccine alone; vaccine + PSLN-344; licensed-type comparator. | Primary: nasal-wash virus titre area after matched and cross-subtype challenge at day 28. Secondary: fever, weight, activity. | HAI and blood IFN-γ ELISpot at days 14 and 28; interferon signature at 24 h. | Proceed to IND-enabling work if virus shedding falls against vaccine alone and the blood markers behave as in Study 1. |

Aged animals are the scarce resource. If supply limits Study 1, the order of priority for arms is: vaccine + empty liposome, PSLN-212, PSLN-344 20 µg, Mn-only liposome, PSLN-344 5 µg, young benchmark, then the rest; the day-60 cohort follows the day-14 cohort.

In parallel, formulation work should supply what the workbook lacks: manganese content per dose, the Mn : CDN-1807 ratio, release, and particle size, charge and morphology before and after lyophilisation and on storage. The annotation says these were measured; no results are in the data dump.

### 5.4 If the committee drops it: what is being dropped, and why

**What would be dropped**

- The only formulation in the data set that protects aged animals. The fallback, PSLN-212, protects 15 of 108 aged or middle-aged animals and is already failing at 14 months [E23, E19].
- With it, the older-adult indication for this platform. What remains is a young-adult adjuvant: PSLN-212 protects 93 of 94 young animals, and manganese adds nothing there [E25, E26].
- A profile that no comparator in the workbook shows in aged animals: protection within 2 to 3 days of one dose, across subtypes including wild-type H5N1.
- A finding with value beyond this product: the age-related failure of a STING-agonist adjuvant is reversible with manganese.

**Why a committee could reasonably drop it**

- Not for lack of efficacy. On efficacy it is the strongest result in the workbook.
- For unquantified safety risk: intranasal or pulmonary manganese in older adults, with no tissue manganese, histology or resolution data.
- For translational distance: mouse-only data, a delivery route that may not transfer, whole-virus antigen, and no human-cell data.
- For the cost of repairing and repeating a data package whose records conflict.

The case against dropping is that each of these is a defined question with a defined experiment. Gates 0 to 2 address the record, confirmation and safety questions before any IND-enabling spend; Study 4 addresses translation.

---

## 6. What I considered and ruled out

**Alternative recommendations**

| Option | Why ruled out |
|---|---|
| Unconditional advance into IND-enabling work | No safety package, single-sex single-dose data, and record conflicts that an external reviewer would find. |
| Drop | Effect size and replication (Table 2), and no other asset works in aged animals. |
| Advance PSLN-212 instead, as the simpler product | 6/56 in aged animals; HAI ≥ 40 without protection; interferon ceiling near 16-fold. As printed, S03-I also shows it dying at least as fast as sham (log-rank p = 0.056), although that block conflicts with its weight data (Q03). |
| PSLN-212 plus recombinant GM-CSF | S02-G shows more dendritic-type cells (13.8% vs 5.9%) [M19]. That is a cell read-out only, and the regimen is four daily intranasal cytokine doses. |
| R848 combinations | Lower interferon than PSLN-344 (24.3 vs 37.1), progressive weight loss and very high Tnf and Il10 [M01, T03, T04, T06]. |
| CMP-204 (cGAMP) | Weakest interferon response of the three STING-agonist formulations in aged lungs (7.8-fold, against 16.6 and 37.1) and the lowest titres of the three [M01, I01]. |

**Alternative explanations of the efficacy result**

| Explanation | Why ruled out, or not |
|---|---|
| Non-specific antiviral state from the adjuvant | Ruled out at day 3: adjuvant alone 0/7 (S15-H). Not tested at day 14 or 60, so Study 1 includes the arm. |
| Vaccine alone is enough | Ruled out: 0/56 with sham; 0/7 with vaccine alone. |
| More cargo delivered | Ruled out: encapsulation efficiency is similar, and the dose-response differs in ceiling rather than potency. |
| Artefact of one strain or one virus | Unlikely: three strains and five viruses. The two other-strain blocks do not state their challenge virus, and their PSLN-344 weight data share values with a BALB/c block (Q08), so treat cross-strain support as provisional. |
| Artefact of the record conflicts | Ruled out by Table 2. |
| Day-60 deaths are background mortality | Not supported by the weight patterns (Q09), but not excluded statistically. |
| Prior influenza exposure would cancel the benefit | Not seen: 6/7 with or without prior infection. The exposed animals are survivors of a 1× mLD50 infection, so they are a selected group. |
| Antibody alone explains protection | Neutralising antibody to the vaccine strains cannot explain cross-subtype protection. Antibody that binds other subtypes without neutralising was not measured and is not excluded. Antibody probably contributes to matched-strain protection. |

**Data I chose not to use, and why**

| Item | Reason |
|---|---|
| S03-B and S03-F as printed | Headers rotated relative to the raw titres (Q01). Recomputed instead. |
| Second S09-A panel read as 16 h | Its Ifnb1 values reproduce the 72-h panel of S01-A (Q05). |
| S11-B as a neutrophil measure | 35 of 100 cells identical to S11-A; same group means (Q06). |
| S07-C direction of effect | Both groups carry the same label (Q07). |
| S08-C as evidence that Mn reduces epithelial delivery | Shares values with S01-B under different labels and contradicts it (Q11). |
| S05-A and S05-B tetramer kinetics | Two animals per point, conflicting conditions, and a tetramer whose restriction does not fit the default strain (Q10). |
| Body weights as independent confirmation of survival | Arms share values across experiments (Q08). Used only for the sensitivity analysis and for morbidity. |
| S08 rows 89–101 | No label (Q13). |
| Arithmetic means of titres | Titres are multiplicative. Geometric means used. |
| Counting S06-C and S06-D as two experiments without comment | They are identical. Shown both ways. |

---

## 7. Record conflicts to resolve before these numbers are presented

![Figure 7](figures/fig7_integrity.png)

Tier A changes a number someone would cite. Tier B weakens a claim. The full register, with evidence and cell references, is `analysis/integrity_audit.csv` (sheet "Audit" in the supporting workbook).

| ID | Tier | Blocks | Conflict | Effect |
|---|---|---|---|---|
| Q01 | A | S03-B, S03-F vs S13-A–D | Quotient headers rotated relative to raw subclass titres. | As printed, PSLN-344 looks IgG1-skewed (0.58). Recomputed: 2.14. |
| Q02 | A | S06-C vs S06-D | Identical time-to-event data in all four arms of two different experiments. The weights paired with S06-D show two PSLN-344 animals flat-lined from day 8. | One "7/7" is not independent. The day-3 rgH5N1 result may be 5/7. |
| Q03 | A | S03-I vs S13-F | Arms differ (CMP-204 vs Naive). PSLN-212 is 0/7 in the table, but in the weights all seven are alive at day 8 and three recover. | Aged PSLN-212 survival in matched-strain challenge is 0/7 or 3/7. Aged CMP-204 survival may not exist. |
| Q04 | A | S03-J vs S13-G | Stated n = 9, ten rows per arm; one PSLN-344 animal has no time. Arms are Sham/PSLN-212/PSLN-344 in one block and Naive/Sham/PSLN-344 in the other. | The comparator with 3/10 is either PSLN-212 or sham. PSLN-344 is 9/9 with one animal unaccounted for. |
| Q05 | A | S09-A, second panel | Labelled 16 h; values match 72 h. | Changes the reading of the cytokine tail. |
| Q06 | A | S11-B vs S11-A | "Neutrophils" reproduce the macrophage block. | No neutrophil data exist. |
| Q07 | A | S07-C | Both groups labelled "Ly6C-CD206+ MΦ". | The macrophage-to-regulatory-T-cell link cannot be read. |
| Q08 | A | S15-C vs S15-I; S15-A, M, O; S09-C | Weight arms share values across experiments: 40 of 48 cells identical between S15-C and S15-I. Chance rate per cell is 1.1% (`duplicates_weight_arms_refined.csv`). | Weights are not independent confirmation. Cross-strain weight data are affected. |
| Q09 | B | S06-E, S06-G, S15-E, S15-G | Untreated, unchallenged controls die (4/21). Table and weight counts differ by one animal in several arms. | Day-60 survival must be read against background. |
| Q10 | B | S05-A, S05-B | Stated n = 3, two per point; two incompatible condition statements; tetramer restriction does not fit BALB/c. | Tetramer kinetics not usable. |
| Q11 | B | S08-C vs S01-B | Values reappear under different labels; type I cell uptake of the same article is 3.8% in one block and 13.8% in the other. | No conclusion on epithelial delivery of the Mn formulation. |
| Q12 | B | S13-E; S09-F; S15-L | Stated n = 5 with seven rows; sham n of 7 in the table and 8 in the weights; one young death at day 12 with no weight loss. | Minor; control and benchmark arms. |

Housekeeping items Q13–Q17 (unlabelled rows, an article missing from the materials list, conditions not recorded, and the list of missing read-outs) are in the register.

---

## Glossary

| Term | Meaning |
|---|---|
| Sham | Vaccine given with empty liposome. The annotation's definition. |
| Young PSLN-212 | 7–8-week-old animals given vaccine with PSLN-212. Used as the benchmark for a working response. |
| HAI | Haemagglutination inhibition, the standard serum antibody assay for influenza. A titre of 40 is the conventional human seroprotection threshold. |
| mLD50 | The dose of mouse-adapted virus that kills half of unprotected animals. |
| rgH5N1 | A reverse-genetics virus carrying the H5 and N1 genes of A/Vietnam/1203/2004 on a PR8 backbone. |
| Cross-subtype (heterosubtypic) | Vaccine and challenge virus belong to different influenza A subtypes. |
| STING | Stimulator of interferon genes, the receptor that CDN-1807 activates. |
| Type I interferon, Ifnb1 | The early antiviral signal; Ifnb1 is the interferon-β transcript. |
| OT-I | Transgenic CD8 T cells that recognise ovalbumin; used to measure T-cell priming. |
| CCR2 antagonist (INCB3344) | Blocks the recruitment of monocytes from blood. |
| Pertussis toxin | Blocks chemokine-driven cell migration. |
| Carbenoxolone | Blocks gap junctions between cells. |
| CMH | Cochran–Mantel–Haenszel test: compares two arms across several experiments while keeping each experiment's animals together. |
| ELISpot | Assay that counts cytokine-secreting cells from a blood sample. |
| NP, M1 | Nucleoprotein and matrix protein: internal influenza proteins that vary little between subtypes. |
| FTY720 | A drug that holds lymphocytes in lymph nodes, so that only cells already in the lung can respond. |
| IND-enabling, GLP | The regulated toxicology and manufacturing work required before a first human trial. |
| ICP-MS | Mass-spectrometric measurement of metals in tissue. |

---

## Appendix. Files

| File | Content |
|---|---|
| `PSLN-344_portfolio_recommendation.md` / `.html` | This report |
| `numbers_ledger.md` | Every tagged number: value, source cells, reduction, test |
| `PSLN-344_supporting_tables.xlsx` | Ledger, audit register, all survival tables, group summaries, tests, restoration index, biomarker table, duplicate screens, tidy per-animal data |
| `figures/` | Figures 1–7 |
| `analysis/` | Scripts and their CSV outputs. `blocks.py` parses the workbook; `README.md` gives the run order. |

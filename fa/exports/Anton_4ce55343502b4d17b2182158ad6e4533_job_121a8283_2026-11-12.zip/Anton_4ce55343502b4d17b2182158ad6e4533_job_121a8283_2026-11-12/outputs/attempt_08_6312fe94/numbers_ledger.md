# Numbers ledger — PSLN-344 portfolio review

Every number used in the report, recomputed from the per-animal values in `adjuvant_program_dataset.xlsx` by `analysis/ledger.py`.
Each entry gives the value, the source block and cells, how the per-animal values were reduced, and the test or uncertainty attached.
Conventions: arithmetic mean ± SD for percentages and linear fold-changes; geometric mean for titres (HAI 0 set to 5, half the lowest dilution tested) and for the log10-stored S09-A panel; survival = animals with status 0 at end of observation / animals with a recorded time; Tukey p-values are from one-way ANOVA + Tukey HSD across all groups of the block (titres on log10); 'Welch' is an unequal-variance two-group t-test. Confidence intervals on fold-ratios and on '% of young' come from a Welch t-interval on per-animal log values, centred on the ratio of arithmetic means (geometric means for titres). Q-numbers refer to the record-conflict register (`analysis/integrity_audit.csv`, report Section 7).

## Survival

**E01** — Aged BALB/c, eight four-arm challenge experiments: PSLN-344 survivors

- Value: **46/56 = 82.1% (95% CI 70-91)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: vs PSLN-212: stratified log-rank chi2 = 66.3, p = 3.9e-16; Cochran-Mantel-Haenszel p = 2.0e-13

**E02** — Same experiments: PSLN-212 survivors

- Value: **6/56 = 10.7% (95% CI 4-22)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI

**E03** — Same experiments: sham (vaccine + empty liposome) survivors

- Value: **0/56 = 0.0% (95% CI 0-6)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI

**E04** — Same experiments: young PSLN-212 benchmark survivors

- Value: **56/56 = 100.0% (95% CI 94-100)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: PSLN-344 aged vs young benchmark: stratified log-rank p = 0.0009; CMH p = 0.0028

## Survival sensitivity

**E05** — PSLN-344 vs PSLN-212, dropping S06-D (identical to S06-C)

- Value: **39/49 (79.6%) vs 4/49 (8.2%)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: CMH p = 7.8e-12; pooled Fisher p = 2.9e-13

**E06** — PSLN-344 vs PSLN-212, dropping S03-I, S06-C and S06-D

- Value: **25/35 (71.4%) vs 2/35 (5.7%)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: CMH p = 1.4e-07; pooled Fisher p = 1.2e-08

**E07** — PSLN-344 vs PSLN-212, deaths taken from paired weight blocks (blank or flat-lined series)

- Value: **46/56 (82.1%) vs 9/56 (16.1%)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105); weight blocks S13-F, S15-A..G
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI; weight-implied death = series goes blank or repeats one value to day 14 (two-point plateaus counted only if < 90%)
- Test / uncertainty: CMH p = 1.8e-11; pooled Fisher p = 1.5e-12

**E08** — PSLN-344 vs PSLN-212, worst case for PSLN-344 (max of table/weight deaths for PSLN-344, min for PSLN-212)

- Value: **44/56 (78.6%) vs 10/56 (17.9%)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105); weight blocks S13-F, S15-A..G
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI; weight-implied death = series goes blank or repeats one value to day 14 (two-point plateaus counted only if < 90%)
- Test / uncertainty: CMH p = 4.5e-10; pooled Fisher p = 1.2e-10

## Survival by interval

**E09** — PSLN-344 vs PSLN-212, challenge 14 d after dose (S03-I, S06-A, S06-C)

- Value: **20/21 (95.2%; CI 76-100) vs 3/21 (14.3%; CI 3-36)**
- Source: subset of E01 blocks
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: stratified log-rank p = 2.9e-07

**E10** — PSLN-344 vs PSLN-212, challenge 3 d after dose (S06-B, S06-D)

- Value: **12/14 (85.7%; CI 57-98) vs 2/14 (14.3%; CI 2-43)**
- Source: subset of E01 blocks
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: stratified log-rank p = 1.9e-05

**E11** — PSLN-344 vs PSLN-212, challenge 60 d after dose (S06-E, S06-F, S06-G rows 34-105)

- Value: **14/21 (66.7%; CI 43-85) vs 1/21 (4.8%; CI 0-24)**
- Source: subset of E01 blocks
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: stratified log-rank p = 2.4e-06

## Durability

**E12** — PSLN-344 aged: day-14 vs day-60 challenge

- Value: **20/21 vs 14/21**
- Source: S03-I, S06-A, S06-C vs S06-E, S06-F, S06-G (PSLN-344 columns)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: Fisher exact two-sided p = 0.045

**E13** — Day-60 experiments: untreated, unchallenged aged animals alive at day 14

- Value: **17/21 (81.0%; CI 58-95)**
- Source: S06!L62:L68, S06!R62:R68, S06!F99:F105
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: PSLN-344 (14/21) vs untreated: CMH p = 0.48; stratified log-rank p = 0.44

**E14** — Day-60 experiments: PSLN-344 aged vs young PSLN-212

- Value: **14/21 vs 21/21**
- Source: S06-E, S06-F, S06-G (rows 34-105)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: CMH p = 0.016; stratified log-rank p = 0.005

## Survival

**E15** — Wild-type H5N1 challenge 2 d after one dose (S03-J)

- Value: **PSLN-344 9/9 (a tenth animal has no recorded time); 'PSLN-212' 3/10; 'Sham' 1/10**
- Source: S03!G17:J46 (S03!H17:H26, S03!I27:I36, S03!J37:J46)
- Reduction: status 0 at day 21 / animals with a recorded time
- Test / uncertainty: log-rank PSLN-344 vs 'PSLN-212' p = 0.0023; vs 'Sham' p = 0.00017. Comparator identities conflict with S13-G.

## Component test

**E16** — rgH5N1 challenge 3 d after dose (S15-H): vaccine + PSLN-344 / PSLN-344 alone / vaccine alone

- Value: **6/7 / 0/7 / 0/7**
- Source: S15!A73:D93
- Reduction: status 0 at day 14 / n
- Test / uncertainty: vaccine+PSLN-344 vs PSLN-344 alone: log-rank p = 0.00014, Fisher p = 0.0047

## Other strains

**E17** — Aged C57BL/6 (S15-L): PSLN-344 / PSLN-212 / sham / young PSLN-212

- Value: **6/7 / 0/7 / 0/7 / 6/7**
- Source: S15!A103:E130
- Reduction: status 0 at day 14 / n
- Test / uncertainty: PSLN-344 vs PSLN-212: log-rank p = 0.0011, Fisher p = 0.0047. Challenge virus and interval not stated.

**E18** — Aged Swiss Webster (S15-N): PSLN-344 / PSLN-212 / sham / young PSLN-212

- Value: **6/7 / 2/7 / 0/7 / 7/7**
- Source: S15!A134:E161
- Reduction: status 0 at day 14 / n
- Test / uncertainty: PSLN-344 vs PSLN-212: log-rank p = 0.056, Fisher p = 0.1. Challenge virus and interval not stated.

## Imprinting model

**E19** — 14-month-old BALB/c (PR8 or saline at 10 months): PR8 challenge (S06-E rows 71-98): naive+212 / imprinted+212 / naive+344 / imprinted+344

- Value: **0/7 / 4/7 / 6/7 / 6/7**
- Source: S06!G71:K98
- Reduction: status 0 at day 14 / n

**E20** — Same model, Perth H3N2 challenge (S06-F rows 71-98)

- Value: **0/7 / 0/7 / 6/7 / 6/7**
- Source: S06!M71:Q98
- Reduction: status 0 at day 14 / n

**E21** — Both imprinting challenges pooled: PSLN-344 vs PSLN-212

- Value: **24/28 vs 4/28**
- Source: S06!G71:K98, S06!M71:Q98
- Reduction: sum of survivors / sum of n

## Grand totals

**E22** — All cohorts in the workbook: PSLN-344 + vaccine

- Value: **97/114 = 85.1% (CI 77-91); 16 cohorts**
- Source: all time-to-event blocks (survival_grand_totals.csv lists the cohorts)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI

**E23** — All cohorts in the workbook: PSLN-212 + vaccine

- Value: **15/108 = 13.9% (CI 8-22); 15 cohorts**
- Source: all time-to-event blocks (survival_grand_totals.csv lists the cohorts)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI

**E24** — All cohorts in the workbook: Sham / vaccine alone

- Value: **1/87 = 1.1% (CI 0-6); 12 cohorts**
- Source: all time-to-event blocks (survival_grand_totals.csv lists the cohorts)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI

**E25** — All cohorts in the workbook: Young + PSLN-212

- Value: **93/94 = 98.9% (CI 94-100); 13 cohorts**
- Source: all time-to-event blocks (survival_grand_totals.csv lists the cohorts)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI

**E26** — All cohorts in the workbook: Young + PSLN-344

- Value: **31/31 = 100.0% (CI 89-100); 4 cohorts**
- Source: all time-to-event blocks (survival_grand_totals.csv lists the cohorts)
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI

## Young animals

**E27** — Young, challenge 180 d after dose (S09-G): body weight at day 14, PSLN-344Y vs PSLN-212Y

- Value: **95.6% vs 99.2%**
- Source: S09!G73:N73 (212Y), S09!W73:AD73 (344Y)
- Reduction: mean of 8 per-animal values (% of own day-0 weight)
- Test / uncertainty: Welch t p = 0.0038; survival 8/8 in both (S09-F)

## Morbidity

**E28** — Mean weight nadir of surviving animals after challenge, range across the eight aged-BALB/c experiments: PSLN-344 aged; young PSLN-212

- Value: **85.2-91.5%; 87.9-93.5%**
- Source: weight blocks S13-F, S15-A..G
- Reduction: per animal: minimum of recorded weights; per arm: mean over survivors (series neither blank nor flat-lined)
- Test / uncertainty: supportive only: weight blocks share values across experiments (Q08)

## Survival

**E30** — Absolute survival gain, PSLN-344 minus PSLN-212, aged BALB/c: as recorded (46/56 vs 6/56); worst case (44/56 vs 10/56)

- Value: **71.4 points (95% CI 55.3 to 81.1); 60.7 points (95% CI 43.5 to 72.5)**
- Source: time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105)
- Reduction: difference of pooled proportions; Newcombe hybrid-score 95% CI (pooling ignores the experiment strata; descriptive)

**E29** — Experiments in which vaccine and challenge share neither HA nor NA subtype (S06-A, S06-B: Aichi H3N2 -> PR8 H1N1; S06-E rows 34-68: same at day 60; S06-G: CA09 H1N1 -> Perth H3N2): PSLN-344 / PSLN-212 / sham / young PSLN-212

- Value: **20/28 / 1/28 / 0/28 / 28/28**
- Source: S06!A3:E30, S06!G3:K30, S06!G34:L68, S06!A71:F105
- Reduction: animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI
- Test / uncertainty: PSLN-344 vs PSLN-212: CMH p = 1.2e-06; pooled Fisher p = 1.3e-07

## Antibody

**I01** — HAI titre, CA09 H1N1, day 14 (S03-C): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **8 / 23 / 46 / 368 / 485; PSLN-344 CI 179-755**
- Source: PSLN-212: S03!M3:M7; PSLN-344: S03!N3:N7; PSLN-212(Y): S03!O3:O7
- Reduction: geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10; HAI 0 (no inhibition at 1:10) set to 5
- Test / uncertainty: PSLN-344/PSLN-212 = 8.0-fold (CI 3.9-16.4), Tukey p = 5.7e-06 (Welch 0.00037); PSLN-344 = 76% of young (CI 36-158), Tukey p = 0.87 (Welch 0.4); log10 scale

**I02** — HAI titre, Aichi H3N2, day 14 (S03-G): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **10 / 30 / 35 / 320 / 368; PSLN-344 CI 174-588**
- Source: PSLN-212: S03!M10:M14; PSLN-344: S03!N10:N14; PSLN-212(Y): S03!O10:O14
- Reduction: geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10; HAI 0 (no inhibition at 1:10) set to 5
- Test / uncertainty: PSLN-344/PSLN-212 = 9.2-fold (CI 4.2-20.2), Tukey p = 2.2e-06 (Welch 0.00021); PSLN-344 = 87% of young (CI 47-161), Tukey p = 0.99 (Welch 0.61); log10 scale

**I03** — Serum IgG, CA09, day 14 (S03-A): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **56 / 181 / 393 / 7305 / 11959; PSLN-344 CI 4081-13076**
- Source: PSLN-212: S03!C3:C7; PSLN-344: S03!D3:D7; PSLN-212(Y): S03!E3:E7
- Reduction: geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10
- Test / uncertainty: PSLN-344/PSLN-212 = 18.6-fold (CI 9.1-37.9), Tukey p = 3.1e-06 (Welch 1.3e-05); PSLN-344 = 61% of young (CI 32-116), Tukey p = 0.72 (Welch 0.11); log10 scale

**I04** — Serum IgG, Aichi, day 14 (S03-E): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **52 / 200 / 426 / 5701 / 13855; PSLN-344 CI 2794-11631**
- Source: PSLN-212: S03!C10:C14; PSLN-344: S03!D10:D14; PSLN-212(Y): S03!E10:E14
- Reduction: geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10
- Test / uncertainty: PSLN-344/PSLN-212 = 13.4-fold (CI 6.1-29.6), Tukey p = 0.00013 (Welch 7.0e-05); PSLN-344 = 41% of young (CI 18-94), Tukey p = 0.33 (Welch 0.039); log10 scale

**I05** — Neutralising titre, CA09, day 14 (S03-D): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **52 / 182 / 418 / 3840 / 6686; PSLN-344 CI 1338-11018**
- Source: PSLN-212: S03!S3:S7; PSLN-344: S03!T3:T7; PSLN-212(Y): S03!U3:U7
- Reduction: geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10
- Test / uncertainty: PSLN-344/PSLN-212 = 9.2-fold (CI 3.1-27.2), Tukey p = 0.00024 (Welch 0.0019); PSLN-344 = 57% of young (CI 19-170), Tukey p = 0.67 (Welch 0.27); log10 scale

**I06** — Neutralising titre, Aichi, day 14 (S03-H): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **40 / 138 / 276 / 2533 / 4411; PSLN-344 CI 1173-5471**
- Source: PSLN-212: S03!S10:S14; PSLN-344: S03!T10:T14; PSLN-212(Y): S03!U10:U14
- Reduction: geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10
- Test / uncertainty: PSLN-344/PSLN-212 = 9.2-fold (CI 3.8-22.1), Tukey p = 3.2e-05 (Welch 0.00039); PSLN-344 = 57% of young (CI 24-138), Tukey p = 0.53 (Welch 0.18); log10 scale

**I07** — Serum IgG, CA09, day 28 (boost day 14) (S13-I): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **57 / 940 / 4411 / 15651 / 40739; PSLN-344 CI 6767-36194**
- Source: PSLN-212: S13!H53:H57; PSLN-344: S13!I53:I57; PSLN-212(Y): S13!J53:J57
- Reduction: geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10
- Test / uncertainty: PSLN-344/PSLN-212 = 3.5-fold (CI 1.5-8.4), Tukey p = 0.19 (Welch 0.01); PSLN-344 = 38% of young (CI 15-99), Tukey p = 0.45 (Welch 0.048); log10 scale

**I08** — Serum IgG, Aichi, day 28 (boost day 14) (S13-J): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **101 / 474 / 1086 / 12435 / 43472; PSLN-344 CI 4626-33426**
- Source: PSLN-212: S13!N53:N57; PSLN-344: S13!O53:O57; PSLN-212(Y): S13!P53:P57
- Reduction: geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10
- Test / uncertainty: PSLN-344/PSLN-212 = 11.5-fold (CI 4.1-32.4), Tukey p = 3.1e-05 (Welch 0.00076); PSLN-344 = 29% of young (CI 11-76), Tukey p = 0.029 (Welch 0.021); log10 scale

**I09** — Animals with HAI >= 40 to CA09 (S03-C): sham / CMP-204 / PSLN-212 / PSLN-344 / young

- Value: **0/5 / 2/5 / 5/5 / 5/5 / 5/5**
- Source: S03!K3:O7
- Reduction: count of per-animal titres >= 40
- Test / uncertainty: PSLN-344 and young: 5/5 >= 160

## Antibody quality

**I10** — IgG2a:IgG1 quotient, CA09 H1N1, recomputed: PSLN-212 / PSLN-344 / young

- Value: **0.58 / 2.14 / 2.97**
- Source: S13-A (S13!A3:C7) divided by S13-B, animal by animal in row order
- Reduction: per-animal IgG2a titre / IgG1 titre; arithmetic mean of 5 quotients
- Test / uncertainty: PSLN-344 vs PSLN-212 Welch p = 0.054 (on log quotients 0.0073); per-animal range PSLN-212 0.29-0.80, PSLN-344 0.85-4.19. As printed in S03-B: 2.97 / 0.58 / 2.14 (headers rotated, Q01)

**I11** — IgG2a:IgG1 quotient, Aichi H3N2, recomputed: PSLN-212 / PSLN-344 / young

- Value: **0.51 / 2.73 / 2.89**
- Source: S13-C (S13!I3:K7) divided by S13-D, animal by animal in row order
- Reduction: per-animal IgG2a titre / IgG1 titre; arithmetic mean of 5 quotients
- Test / uncertainty: PSLN-344 vs PSLN-212 Welch p = 0.049 (on log quotients 0.0028); per-animal range PSLN-212 0.26-0.89, PSLN-344 1.09-5.46. As printed in S03-F: 2.89 / 0.51 / 2.73 (headers rotated, Q01)

## Cellular read-out

**B01** — Germinal-centre B cells (% of B cells), lymph node, day 7 (S03-K): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **1.18 ± 0.40 / 2.34 ± 0.52 / 6.54 ± 1.54 / 9.82 ± 3.05 (n=5 each)**
- Source: PSLN-212: S03!M17:M21; PSLN-344: S03!N17:N21; PSLN-212(Y): S03!O17:O21
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 2.79-fold (CI 2.00-3.90), Tukey p = 0.0074 (Welch 0.0023); PSLN-344 = 67% of young (CI 43-102), Tukey p = 0.04 (Welch 0.076)

**B02** — ICOS+ Tfh (%), lymph node, day 7 (S04-A/ICOShi): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **0.30 ± 0.16 / 3.82 ± 0.85 / 10.26 ± 3.16 / 13.63 ± 1.64 (n=5 each)**
- Source: PSLN-212: S04!G3:K3; PSLN-344: S04!G4:K4; PSLN-212(Y): S04!G5:K5
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 2.69-fold (CI 1.79-4.03), Tukey p = 0.00023 (Welch 0.0086); PSLN-344 = 75% of young (CI 52-109), Tukey p = 0.045 (Welch 0.078)

**B03** — Tfr (Foxp3+ % of CXCR5+ CD4), lymph node, day 7 (S04-B/Foxp3): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **22.6 ± 4.4 / 26.7 ± 6.7 / 10.8 ± 1.8 / 7.1 ± 3.7 (n=5 each)**
- Source: PSLN-212: S04!B8:B12; PSLN-344: S04!C8:C12; PSLN-212(Y): S04!D8:D12
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 0.41-fold (CI 0.30-0.56), Tukey p = 0.00022 (Welch 0.0047); PSLN-344 = 152% of young (CI 83-277), Tukey p = 0.58 (Welch 0.092)

**B04** — Tfr, lymph node, day 30 (S04-C): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **13.9 ± 1.8 / 18.0 ± 3.8 / 14.0 ± 3.2 / 7.4 ± 1.6 (n=5 each)**
- Source: PSLN-212: S04!B22:B26; PSLN-344: S04!C22:C26; PSLN-212(Y): S04!D22:D26
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 0.78-fold (CI 0.55-1.09), Tukey p = 0.14 (Welch 0.11); PSLN-344 = 189% of young (CI 135-265), Tukey p = 0.0084 (Welch 0.0068)

**B05** — IgG+ of B220+ cells (%), lymph node (time not stated) (S13-H): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **4.7 ± 2.6 / 11.2 ± 2.3 / 25.9 ± 5.9 / 27.1 ± 4.2 (n=5 each)**
- Source: PSLN-212: S13!B53:B57; PSLN-344: S13!C53:C57; PSLN-212(Y): S13!D53:D57
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 2.31-fold (CI 1.67-3.19), Tukey p = 0.00015 (Welch 0.0032); PSLN-344 = 95% of young (CI 71-129), Tukey p = 0.96 (Welch 0.71)

**C01** — Ki-67+ CD8 T cells (%), lung, day 3 (S05-D): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **0.83 ± 0.45 / 3.48 ± 1.35 / 9.38 ± 1.78 / 9.94 ± 3.03 (n=5 each)**
- Source: PSLN-212: S05!B19:B23; PSLN-344: S05!C19:C23; PSLN-212(Y): S05!D19:D23
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 2.70-fold (CI 1.68-4.34), Tukey p = 0.0008 (Welch 0.00047); PSLN-344 = 94% of young (CI 63-141), Tukey p = 0.97 (Welch 0.73)

**C02** — GZMB+ CD8 T cells (%), lung, day 3 (S05-E): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **0.99 ± 0.38 / 2.99 ± 0.78 / 5.69 ± 0.90 / 9.61 ± 1.21 (n=5 each)**
- Source: PSLN-212: S05!B26:B30; PSLN-344: S05!C26:C30; PSLN-212(Y): S05!D26:D30
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 1.90-fold (CI 1.36-2.66), Tukey p = 0.00084 (Welch 0.0011); PSLN-344 = 59% of young (CI 47-74), Tukey p = 1.3e-05 (Welch 0.00053)

**C03** — IFN-gamma+ CD8 T cells (%), lymph node, day 14, restimulated with rgH5N1 vaccine (S05-F): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **0.67 ± 0.36 / 1.50 ± 0.39 / 6.36 ± 1.00 / 9.18 ± 0.90 (n=5 each)**
- Source: PSLN-212: S05!B33:B37; PSLN-344: S05!C33:C37; PSLN-212(Y): S05!D33:D37
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 4.23-fold (CI 3.14-5.68), Tukey p = 6.5e-08 (Welch 0.00013); PSLN-344 = 69% of young (CI 57-85), Tukey p = 7.0e-05 (Welch 0.0016)

**C04** — IFN-gamma+ CD8 T cells (%), lymph node, day 60, restimulated with rgH5N1 vaccine (S05-G): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **1.46 ± 1.07 / 3.04 ± 1.25 / 9.86 ± 2.81 / 14.36 ± 2.94 (n=5 each)**
- Source: PSLN-212: S05!B40:B44; PSLN-344: S05!C40:C44; PSLN-212(Y): S05!D40:D44
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 3.24-fold (CI 1.66-6.33), Tukey p = 0.0008 (Welch 0.0032); PSLN-344 = 69% of young (CI 47-99), Tukey p = 0.024 (Welch 0.038)

**C05** — GZMB+ CD8 T cells (%), lymph node, day 60 (S05-H): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **0.60 ± 0.39 / 1.02 ± 0.31 / 4.11 ± 1.12 / 5.55 ± 1.44 (n=5 each)**
- Source: PSLN-212: S05!B47:B51; PSLN-344: S05!C47:C51; PSLN-212(Y): S05!D47:D51
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 4.01-fold (CI 2.55-6.31), Tukey p = 0.00049 (Welch 0.0025); PSLN-344 = 74% of young (CI 48-113), Tukey p = 0.11 (Welch 0.12)

**C06** — Lung resident-memory CD8 T cells (%), day 25 (S05-I): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **0.58 ± 0.31 / 1.00 ± 0.37 / 3.96 ± 0.62 / 6.04 ± 0.60 (n=5 each)**
- Source: PSLN-212: S05!B54:B58; PSLN-344: S05!C54:C58; PSLN-212(Y): S05!D54:D58
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 3.96-fold (CI 2.56-6.14), Tukey p = 3.3e-07 (Welch 6.2e-05); PSLN-344 = 66% of young (CI 53-81), Tukey p = 3.1e-05 (Welch 0.00068)

**C07** — IFN-gamma+ CD8 T cells (%), lymph node, restimulated with CA09 vaccine (time not stated) (S14-A H1N1): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **0.8 ± 0.6 / 3.1 ± 1.8 / 11.0 ± 2.6 / 13.7 ± 2.5 (n=5 each)**
- Source: PSLN-212: S14!B3:B7; PSLN-344: S14!C3:C7; PSLN-212(Y): S14!D3:D7
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 3.51-fold (CI 1.51-8.16), Tukey p = 6.7e-05 (Welch 0.00074); PSLN-344 = 80% of young (CI 59-110), Tukey p = 0.19 (Welch 0.13)

**C08** — IFN-gamma+ CD8 T cells (%), lymph node, restimulated with Aichi vaccine (time not stated) (S14-A H3N2): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **1.0 ± 0.6 / 3.6 ± 1.2 / 9.9 ± 1.8 / 14.0 ± 2.5 (n=5 each)**
- Source: PSLN-212: S14!G3:G7; PSLN-344: S14!H3:H7; PSLN-212(Y): S14!I3:I7
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 2.75-fold (CI 1.70-4.46), Tukey p = 0.00011 (Welch 0.00033); PSLN-344 = 71% of young (CI 54-92), Tukey p = 0.0065 (Welch 0.019)

**M04** — Migratory CCR7+ CD11b+ DC (%), lung, 72 h (S02-A): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **2.5 ± 0.7 / 7.3 ± 2.0 / 30.7 ± 7.9 / 35.0 ± 4.8 (n=5 each)**
- Source: PSLN-212: S02!B3:B7; PSLN-344: S02!C3:C7; PSLN-212(Y): S02!D3:D7
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 4.21-fold (CI 2.80-6.34), Tukey p = 4.1e-06 (Welch 0.0019); PSLN-344 = 88% of young (CI 62-124), Tukey p = 0.49 (Welch 0.33)

**M05** — CD11b+CD103- DC (%), lymph node, 72 h (S02-B): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **13.9 ± 4.2 / 18.2 ± 6.4 / 36.8 ± 9.2 / 44.7 ± 7.7 (n=5 each)**
- Source: PSLN-212: S02!G3:G7; PSLN-344: S02!H3:H7; PSLN-212(Y): S02!I3:I7
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 2.02-fold (CI 1.24-3.27), Tukey p = 0.0041 (Welch 0.0075); PSLN-344 = 82% of young (CI 59-115), Tukey p = 0.33 (Welch 0.18)

**M06** — CD40+ of lymph-node CD11b+ DC (%), day 3 (S02-D CD40): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **4.0 ± 1.0 / 5.6 ± 1.1 / 11.2 ± 3.0 / 38.7 ± 7.3 (n=5 each)**
- Source: PSLN-212: S02!B10:B14; PSLN-344: S02!C10:C14; PSLN-212(Y): S02!D10:D14
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 2.02-fold (CI 1.39-2.92), Tukey p = 0.16 (Welch 0.011); PSLN-344 = 29% of young (CI 20-42), Tukey p = 5.0e-08 (Welch 0.00042)

**M07** — CD86+ of lymph-node CD11b+ DC (%), day 3 (S02-D CD86): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **7.2 ± 1.5 / 8.1 ± 1.8 / 14.5 ± 2.7 / 37.9 ± 5.5 (n=5 each)**
- Source: PSLN-212: S02!G10:G14; PSLN-344: S02!H10:H14; PSLN-212(Y): S02!I10:I14
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 1.79-fold (CI 1.32-2.43), Tukey p = 0.033 (Welch 0.0032); PSLN-344 = 38% of young (CI 30-49), Tukey p = 3.0e-08 (Welch 0.00017)

**M08** — cDC1 (%), lung, 72 h (S01-F): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **17.9 ± 2.5 / 22.8 ± 3.6 / 37.5 ± 7.0 / 43.4 ± 5.3 (n=5 each)**
- Source: PSLN-212: S01!G36:K36; PSLN-344: S01!L36:P36; PSLN-212(Y): S01!Q36:U36
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 1.65-fold (CI 1.28-2.11), Tukey p = 0.00034 (Welch 0.0058); PSLN-344 = 86% of young (CI 69-109), Tukey p = 0.26 (Welch 0.17)

**M09** — CD206+ macrophages (%), lung (time not stated) (S11-E): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **85.2 ± 7.8 / 71.5 ± 8.3 / 48.9 ± 8.1 / 35.5 ± 7.1 (n=5 each)**
- Source: PSLN-212: S11!B31:B35; PSLN-344: S11!C31:C35; PSLN-212(Y): S11!D31:D35
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 0.68-fold (CI 0.54-0.86), Tukey p = 0.0017 (Welch 0.0024); PSLN-344 = 138% of young (CI 104-182), Tukey p = 0.068 (Welch 0.025)

**M10** — Lung Treg (CD4+Foxp3+, %), day 7 (S04-D): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **5.88 ± 0.84 / 6.66 ± 0.34 / 2.99 ± 0.41 / 1.78 ± 0.59 (n=3 each)**
- Source: PSLN-212: S04!B29:B31; PSLN-344: S04!C29:C31; PSLN-212(Y): S04!D29:D31
- Reduction: arithmetic mean ± SD of per-animal values
- Test / uncertainty: PSLN-344/PSLN-212 = 0.45-fold (CI 0.33-0.60), Tukey p = 0.00025 (Welch 0.00034); PSLN-344 = 168% of young (CI 83-342), Tukey p = 0.12 (Welch 0.051)

**M11** — Antigen (AF647-OVA)+ DC (%), lymph node, 36 h (S02-C): PSLN-212 / PSLN-344 / young PSLN-212 / PTX / young PSLN-344

- Value: **1.8 ± 0.4 / 7.1 ± 1.4 / 9.4 ± 1.5 / 2.4 ± 0.9 / 11.1 ± 1.8 (n=5 each)**
- Source: PSLN-212: S02!K3:K7; PSLN-344: S02!L3:L7; PSLN-212(Y): S02!M3:M7
- Reduction: arithmetic mean ± SD
- Test / uncertainty: PSLN-344/PSLN-212 = 4.0-fold (CI 2.9-5.5), Tukey p = 2.2e-05; 76% of young, Tukey p = 0.072 (Welch 0.037)

**M12** — OT-I proliferation (%) driven by lymph-node CD11b+ DC (S02-E): PSLN-212 / PSLN-344 / young PSLN-212 / PTX / young PSLN-344

- Value: **0.8 ± 0.5 / 18.7 ± 2.8 / 26.2 ± 6.7 / 2.5 ± 1.8 / 31.4 ± 6.7 (n=5 each)**
- Source: PSLN-212: S02!K10:K14; PSLN-344: S02!L10:L14; PSLN-212(Y): S02!M10:M14
- Reduction: arithmetic mean ± SD
- Test / uncertainty: PSLN-344/PSLN-212 = 24.3-fold (CI 10.1-58.7), Tukey p = 3.4e-05; 71% of young, Tukey p = 0.095 (Welch 0.063)

## Innate

**M01** — Lung Ifnb1 mRNA (fold over untreated) 16 h after adjuvant alone (S01-A): Sham / CMP-204 / PSLN-212 / PSLN-R848 / PSLN-212/R848 / PSLN-344 / PSLN-212(Y) / PSLN-344(Y)

- Value: **1.0 ± 0.5 / 7.8 ± 1.7 / 16.6 ± 2.1 / 5.0 ± 2.3 / 24.3 ± 3.7 / 37.1 ± 4.8 / 37.6 ± 3.5 / 50.7 ± 7.6 (n=5 each)**
- Source: S01!B3:F10
- Reduction: arithmetic mean ± SD of per-animal fold values
- Test / uncertainty: PSLN-344/PSLN-212 = 2.23-fold (CI 1.85-2.69), Tukey p = 3.7e-08; PSLN-344 aged = 99% of young PSLN-212 (CI 84-116), Tukey p = 1 (Welch 0.86); young PSLN-344 vs young PSLN-212 Tukey p = 0.00016 (Welch 0.014)

**M02** — Lung Ifnb1 mRNA 72 h (S01-A): Sham / CMP-204 / PSLN-212 / PSLN-R848 / PSLN-212/R848 / PSLN-344 / PSLN-212(Y) / PSLN-344(Y)

- Value: **1.0 ± 0.2 / 2.2 ± 0.4 / 3.4 ± 0.4 / 1.2 ± 0.1 / 1.7 ± 0.3 / 4.4 ± 1.7 / 1.6 ± 0.6 / 3.1 ± 0.8 (n=5 each)**
- Source: S01!H3:L10
- Reduction: arithmetic mean ± SD of per-animal fold values
- Test / uncertainty: PSLN-344/PSLN-212 = 1.29-fold (CI 0.79-2.10), Tukey p = 0.42; PSLN-344 aged = 278% of young PSLN-212 (CI 144-539), Tukey p = 2.2e-05 (Welch 0.016); young PSLN-344 vs young PSLN-212 Tukey p = 0.044 (Welch 0.013)

## Dose-response

**M03** — Ifnb1 dose-response (S08-A; 1-40 ug; age not stated): fitted ceiling (Emax) and ED50, PSLN-344 vs PSLN-212

- Value: **Emax 52.8 (SE 3.9) vs 15.6 (SE 1.3); ED50 11.2 vs 9.5 ug; group means at 10/20/40 ug: PSLN-344 21.1/45.8/50.2; PSLN-212 8.9/12.6/14.9**
- Source: S08!A3:M7
- Reduction: 3-parameter Hill fit to 15 per-animal values per article (baseline fixed at 1); group means of n=3
- Test / uncertainty: asymptotic SE; 5 dose levels, descriptive

## Innate

**M13** — Lung Gm-csf mRNA (fold) at 16/36/72 h (S02-F): PSLN-344; PSLN-212; sham

- Value: **6.0/8.7/3.9; 1.5/1.6/1.4; 1.0/1.2/1.2 (n=5)**
- Source: S02!B17:P19
- Reduction: arithmetic mean per time point
- Test / uncertainty: PSLN-344 vs PSLN-212 Welch p = 3.2e-07 / 0.0017 / 0.023

**M14** — Lung monocytes (%) day 0, day 4 and day 8 (S01-D): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **day 0: 8.0 / 9.4 / 9.2 / 10.8; day 4: 10.4 / 16.7 / 30.6 / 32.2; day 8: 9.5 / 9.7 / 18.4 / 14.1 (n=5)**
- Source: S01!B24:U28
- Reduction: arithmetic mean per day
- Test / uncertainty: day 4 PSLN-344 vs PSLN-212 Welch p = 0.0016; day 8 PSLN-344 vs young Welch p = 0.006

**M15** — Lung CD11b+ DC (%) day 4 and day 8 (S01-E): sham / PSLN-212 / PSLN-344 / young PSLN-212

- Value: **day 4: 4.8 / 8.3 / 18.9 / 21.4; day 8: 2.4 / 6.0 / 13.7 / 9.5 (n=5)**
- Source: S01!B30:Z34
- Reduction: arithmetic mean per day
- Test / uncertainty: day 4 PSLN-344 vs PSLN-212 Welch p = 0.049; day 8 PSLN-344 vs young Welch p = 0.024

## Mechanism

**M16** — Ly6C+CCR2+ lung macrophages (x10^5) days 0/2/5/10/30 (S07-A): PSLN-212; PSLN-344

- Value: **1.4/10.1/19.0/14.6/4.2; 1.9/3.3/3.4/2.9/2.4 (n=3)**
- Source: S07!B3:G7
- Reduction: arithmetic mean per day
- Test / uncertainty: day 5 Welch p = 0.036; day 10 p = 0.0013

**M17** — Donor-derived monocyte-derived DC (%), wild-type vs Ifnar-knockout marrow, cDC precursors removed (S02-H); GM-CSF rescue

- Value: **19.7 ± 4.0 (n=5) vs 2.1 ± 0.9 (n=5); Ifnar-KO + GM-CSF 12.4 ± 3.7 (n=5)**
- Source: S02!B30:F34
- Reduction: arithmetic mean ± SD
- Test / uncertainty: WT vs KO Tukey p = 1.3e-05; KO vs KO+GM-CSF Tukey p = 0.0063

**M18** — Infiltrating donor monocytes (%), wild-type vs Ifnar-knockout marrow, young recipients (S12-A)

- Value: **21.3 ± 4.2 (n=3) vs 15.4 ± 2.5 (n=3)**
- Source: S12!A3:B5
- Reduction: arithmetic mean ± SD
- Test / uncertainty: Student t p = 0.1 (Welch 0.12)

**M19** — Ly6C+CD11c+MHC-II+ cells (%), lung day 5: PSLN-212 vs PSLN-212 + recombinant GM-CSF (S02-G)

- Value: **5.9 ± 1.5 (n=5) vs 13.8 ± 3.0 (n=5)**
- Source: S02!B22:D26
- Reduction: arithmetic mean ± SD
- Test / uncertainty: Tukey p = 9.2e-05

**M20** — Lung monocytes (%) with CCR2 antagonist (S07-B)

- Value: **9.9 ± 2.3 (n=5) vs 3.3 ± 1.4 (n=5)**
- Source: S07!B10:C14
- Reduction: arithmetic mean ± SD
- Test / uncertainty: Student t p = 0.00051

**M21** — Ly6C+ lung macrophages (%) with CCR2 antagonist (S07-B)

- Value: **15.4 ± 4.5 (n=5) vs 2.5 ± 0.6 (n=5)**
- Source: S07!E10:F14
- Reduction: arithmetic mean ± SD
- Test / uncertainty: Student t p = 0.00023

**M22** — GZMB+ lung CD8 T cells (%) day 5 with CCR2 antagonist, young animals (S02-I)

- Value: **6.77 ± 1.05 (n=5) vs 1.39 ± 0.46 (n=5)**
- Source: S02!H30:I34
- Reduction: arithmetic mean ± SD
- Test / uncertainty: Student t p = 6.0e-06

**M23** — Recruited lung monocytes (%) day 3 without vs with carbenoxolone (S11-C)

- Value: **7.28 ± 1.86 (n=5) vs 3.08 ± 1.29 (n=5)**
- Source: S11!A17:B21
- Reduction: arithmetic mean ± SD
- Test / uncertainty: Student t p = 0.0032

**M24** — DiD+ alveolar macrophages (%) 16 h: wild-type vs Sftpa1/Sftpd double-knockout (S01-C)

- Value: **43.1 ± 4.1 (n=4) vs 12.7 ± 3.0 (n=4)**
- Source: S01!B20:E21
- Reduction: arithmetic mean ± SD
- Test / uncertainty: Student t p = 2.1e-05

**M25** — OT-I proliferation (%) day 4, lung / lung+PTX / lymph node / lymph node+PTX (S05-C)

- Value: **59.0 ± 5.0 / 55.1 ± 9.5 / 30.9 ± 3.9 / 6.8 ± 0.8 (n=3)**
- Source: S05!A13:D15
- Reduction: arithmetic mean ± SD
- Test / uncertainty: lung vs lung+PTX Tukey p = 0.83; lymph node vs lymph node+PTX Tukey p = 0.0037

## CMC

**M26** — Encapsulation efficiency (%): CMP-204 / PSLN-212 / PSLN-R848 / PSLN-212/R848 / PSLN-344 (S08-B)

- Value: **65.2 / 59.6 / 61.3 / 52.4 / 54.8 (n=3)**
- Source: S08!A11:O11
- Reduction: arithmetic mean of 3 preparations
- Test / uncertainty: one-way ANOVA p = 0.15

## Mechanism

**M29** — Alveolar macrophages (% of lung cells) before dosing, day 0 (S11-A): aged groups (vaccine / PSLN-212 / PSLN-344) vs young PSLN-212

- Value: **20.4 / 20.3 / 21.2 vs 36.6 (n=5 each)**
- Source: S11!B3:U3
- Reduction: arithmetic mean of day-0 values
- Test / uncertainty: S11-A shares 35 of 100 cells with S11-B (Q06); treat as an observation

**M30** — Alveolar epithelial cells positive for liposome dye cargo (SRB) 16 h after intranasal dosing (S01-B): type II with PSLN-SRB / type I with PSLN-SRB / type II with free SRB / type I with free SRB

- Value: **15.8 ± 2.3 / 3.8 ± 1.1 / 0.4 ± 0.2 / 0.3 ± 0.2 (n=5 each)**
- Source: S01!B14:F17
- Reduction: arithmetic mean ± SD
- Test / uncertainty: type II PSLN-SRB vs free SRB Tukey p = 1.3e-11; S08-C re-uses some of these values under other labels (Q11)

## Mechanism (low weight)

**M27** — NP366-374 tetramer+ CD8 (%), lung, day 7 (S05-A): PSLN-212 / PSLN-344 / young PSLN-212

- Value: **6.9 / 14.2 / 15.2 (n=2; stated n=3)**
- Source: S05!B5:I5
- Reduction: arithmetic mean of 2 values
- Test / uncertainty: not relied on (Q10)

## Mechanism (uninterpretable)

**M28** — Lung Treg (%) after macrophage transfer (S07-C): column B vs column C, both labelled "Ly6C-CD206+ MΦ"

- Value: **10.4 ± 2.1 (n=5) vs 5.1 ± 1.6 (n=5)**
- Source: S07!B16:C20
- Reduction: arithmetic mean ± SD
- Test / uncertainty: direction cannot be assigned (Q07)

## Tolerability

**T01** — Body-weight nadir (% of day 0) after intranasal vaccine + adjuvant (S08-D): vaccine alone / young PSLN-212 / PSLN-212 / CMP-204 / PSLN-344 / PSLN-212/R848

- Value: **98.2 ± 1.1 / 97.6 ± 1.3 / 97.0 ± 1.7 / 95.9 ± 2.0 / 96.4 ± 1.5 / 90.0 ± 5.0 (n=5); lowest PSLN-344 animal 94.2**
- Source: S08!B21:AE26
- Reduction: per animal: minimum over days 2-10; per group: mean ± SD
- Test / uncertainty: PSLN-344 vs vaccine alone Welch p = 0.065; vs PSLN-212 p = 0.56

**T02** — Weight-deficit AUC days 0-10 (%·day), same groups (S08-D)

- Value: **7.5 / 8.8 / 13.5 / 20.1 / 20.3 / 48.6**
- Source: S08!B21:AE26
- Reduction: per animal: trapezoid of max(0, 100 - weight) over recorded days; per group: mean
- Test / uncertainty: PSLN-344 vs vaccine alone Welch p = 0.032; vs PSLN-212 p = 0.27

**T03** — Day-10 weight (% of day 0): PSLN-344; PSLN-212/R848 (S08-D)

- Value: **99.8 (n=5; lowest animal 99.2); 90.6 (n=4; one animal has no day-10 value; lowest 84.7)**
- Source: S08!Q26:U26; S08!V26:Z26
- Reduction: arithmetic mean of the day-10 values present

**T04** — Lung Tnf mRNA, 16 h: young PSLN-212 / aged PSLN-212 / aged PSLN-344 / aged PSLN-212/R848 (fold over PBS)

- Value: **13.9 / 15.7 / 40.5 / 202.3 (n=3)**
- Source: S09!B3:V9
- Reduction: values stored as log10 fold; geometric-mean fold = 10^mean(log10)
- Test / uncertainty: PSLN-344 aged vs young PSLN-212: 2.9-fold, Welch p = 0.009; vs aged PSLN-212: 2.6-fold, p = 0.11 (t-tests on log10 values)

**T05** — Lung Il6 mRNA, 16 h: young PSLN-212 / aged PSLN-212 / aged PSLN-344 / aged PSLN-212/R848 (fold over PBS)

- Value: **60.3 / 5.6 / 36.1 / 31.0 (n=3)**
- Source: S09!B3:V9
- Reduction: values stored as log10 fold; geometric-mean fold = 10^mean(log10)
- Test / uncertainty: PSLN-344 aged vs young PSLN-212: 0.6-fold, Welch p = 0.34; vs aged PSLN-212: 6.5-fold, p = 0.021 (t-tests on log10 values)

**T06** — Lung Il10 mRNA, 16 h: young PSLN-212 / aged PSLN-212 / aged PSLN-344 / aged PSLN-212/R848 (fold over PBS)

- Value: **1.8 / 3.7 / 7.3 / 179.4 (n=3)**
- Source: S09!B3:V9
- Reduction: values stored as log10 fold; geometric-mean fold = 10^mean(log10)
- Test / uncertainty: PSLN-344 aged vs young PSLN-212: 4.0-fold, Welch p = 0.021; vs aged PSLN-212: 2.0-fold, p = 0.19 (t-tests on log10 values)

**T07** — Lung Tnf mRNA, 72 h (second panel, labelled 16h; time point inferred, Q05): young PSLN-212 / aged PSLN-212 / aged PSLN-344 / aged PSLN-212/R848 (fold over PBS)

- Value: **0.5 / 5.2 / 8.4 / 50.2 (n=3)**
- Source: S09!Y3:AS9
- Reduction: values stored as log10 fold; geometric-mean fold = 10^mean(log10)
- Test / uncertainty: PSLN-344 aged vs young PSLN-212: 17.8-fold, Welch p = 0.0076; vs aged PSLN-212: 1.6-fold, p = 0.052 (t-tests on log10 values)

**T08** — Lung Il6 mRNA, 72 h (second panel, labelled 16h; time point inferred, Q05): young PSLN-212 / aged PSLN-212 / aged PSLN-344 / aged PSLN-212/R848 (fold over PBS)

- Value: **3.1 / 1.9 / 7.2 / 33.8 (n=3)**
- Source: S09!Y3:AS9
- Reduction: values stored as log10 fold; geometric-mean fold = 10^mean(log10)
- Test / uncertainty: PSLN-344 aged vs young PSLN-212: 2.3-fold, Welch p = 0.085; vs aged PSLN-212: 3.9-fold, p = 0.026 (t-tests on log10 values)

**T09** — Lung Il10 mRNA, 72 h (second panel, labelled 16h; time point inferred, Q05): young PSLN-212 / aged PSLN-212 / aged PSLN-344 / aged PSLN-212/R848 (fold over PBS)

- Value: **0.1 / 4.2 / 4.2 / 45.0 (n=3)**
- Source: S09!Y3:AS9
- Reduction: values stored as log10 fold; geometric-mean fold = 10^mean(log10)
- Test / uncertainty: PSLN-344 aged vs young PSLN-212: 36.6-fold, Welch p = 0.0015; vs aged PSLN-212: 1.0-fold, p = 0.99 (t-tests on log10 values)

## Tolerability (CNS)

**T10** — Brain Ifnb1 mRNA 36 h after dosing (S10-A): PBS / sham / PSLN-344 / cholera toxin

- Value: **1.00 ± 0.23 / 1.17 ± 0.34 / 1.32 ± 0.41 / 5.50 ± 1.19 (n=5)**
- Source: S10!A3:D7
- Reduction: arithmetic mean ± SD (block annotated as mean with SD)
- Test / uncertainty: PSLN-344 vs sham: ratio 1.13, Tukey p = 0.98, difference CI -1.04 to 1.35; vs PBS: ratio 1.32, Tukey p = 0.87 (Welch 0.17); cholera toxin vs PSLN-344 Tukey p = 1.5e-07

**T11** — Brain Tnf mRNA 36 h after dosing (S10-A): PBS / sham / PSLN-344 / cholera toxin

- Value: **1.00 ± 0.22 / 1.32 ± 0.39 / 1.59 ± 0.49 / 3.50 ± 1.22 (n=5)**
- Source: S10!F3:I7
- Reduction: arithmetic mean ± SD (block annotated as mean with SD)
- Test / uncertainty: PSLN-344 vs sham: ratio 1.21, Tukey p = 0.92, difference CI -0.98 to 1.53; vs PBS: ratio 1.59, Tukey p = 0.54 (Welch 0.05); cholera toxin vs PSLN-344 Tukey p = 0.0026

**T12** — Brain Isg15 mRNA 36 h after dosing (S10-A): PBS / sham / PSLN-344 / cholera toxin

- Value: **1.00 ± 0.34 / 1.04 ± 0.17 / 1.13 ± 0.21 / 2.68 ± 0.74 (n=5)**
- Source: S10!K3:N7
- Reduction: arithmetic mean ± SD (block annotated as mean with SD)
- Test / uncertainty: PSLN-344 vs sham: ratio 1.08, Tukey p = 0.99, difference CI -0.69 to 0.86; vs PBS: ratio 1.13, Tukey p = 0.96 (Welch 0.49); cholera toxin vs PSLN-344 Tukey p = 0.00017

"""
Cross-check body-weight blocks against their partner time-to-event blocks.

Weight-block conventions observed in the workbook:
  * an animal's series either goes BLANK after some day, or
  * becomes a FLAT LINE (identical value repeated through day 14) -- i.e. last observation carried forward.
Both are treated as 'terminal patterns' = candidate deaths.  An animal that keeps changing through
day 14 is a survivor.  A flat run of length 2 (day 12 == day 14 only) is labelled 'flat2' (ambiguous).
"""
import pandas as pd, numpy as np
import blocks as B
t = B.tidy[B.tidy.kind == 'weight'].copy()
s = B.surv.copy()

def classify(series):
    """series: pd.Series indexed by day (sorted), NaN for blank. returns (status, last_real_day, final_value, run_len)"""
    days = list(series.index)
    vals = list(series.values)
    obs = [(d, v) for d, v in zip(days, vals) if not pd.isna(v)]
    last_day_obs = obs[-1][0]
    if last_day_obs < days[-1]:
        return ('blank', last_day_obs, obs[-1][1], 0)
    # flat-run at the end
    final = vals[-1]
    k = len(vals) - 1
    while k > 0 and vals[k - 1] == final:
        k -= 1
    run = len(vals) - k
    if run >= 3:
        return ('flat', days[k], final, run)
    if run == 2:
        return ('flat2', days[k], final, run)
    return ('alive', days[-1], final, 1)

recs = []
block_days = {b: sorted(g.time.unique()) for b, g in t.groupby('block')}
block_n = {b: int(g.unit_idx.max()) for b, g in t.groupby('block')}
for (blk, grp), g in t.groupby(['block', 'group'], sort=False):
    wide = g.pivot(index='time', columns='unit_idx', values='value').reindex(block_days[blk]).sort_index()
    for u in wide.columns:
        st, last, fin, run = classify(wide[u])
        nadir = np.nanmin(wide[u].values)
        recs.append(dict(block=blk, group=grp, unit=u, status=st, last_real_day=last, final_value=fin, flat_run=run,
                         nadir=nadir, first_cell=g[g.unit_idx == u].cell.iloc[0]))
W = pd.DataFrame(recs)
W.to_csv('weight_animal_status.csv', index=False)

pairs = [  # (survival block, weight block, {surv group -> weight group} or None for same names)
    ('S03-I', 'S13-F', None), ('S03-J', 'S13-G', None),
    ('S06-A', 'S15-A', None), ('S06-B', 'S15-B', None), ('S06-C', 'S15-C', None), ('S06-D', 'S15-D', None),
    ('S06-E[r34]', 'S15-E', None), ('S06-F[r34]', 'S15-F', None), ('S06-G', 'S15-G', None),
    ('S15-H', 'S15-I', None), ('S06-E[r71]', 'S15-J', None), ('S06-F[r71]', 'S15-K', None),
    ('S15-L', 'S15-M', None), ('S15-N', 'S15-O', None),
    ('S09-B', 'S09-C', None), ('S09-D', 'S09-E', None), ('S09-F', 'S09-G', None),
]
out = []
for sb, wb_, _ in pairs:
    sg = s[s.block == sb]
    wg = W[W.block == wb_]
    groups = list(dict.fromkeys(list(sg.group.unique()) + list(wg.group.unique())))
    for g in groups:
        a = sg[sg.group == g]
        b = wg[wg.group == g]
        d = dict(surv_block=sb, wt_block=wb_, group=g,
                 surv_n=len(a) if len(a) else None,
                 surv_deaths=int(a.event.sum()) if len(a) else None,
                 surv_death_days=",".join(str(int(x)) for x in sorted(a[a.event == 1].days)) if len(a) else None,
                 wt_n=len(b) if len(b) else None,
                 wt_blank=int((b.status == 'blank').sum()) if len(b) else None,
                 wt_flat=int((b.status == 'flat').sum()) if len(b) else None,
                 wt_flat2=int((b.status == 'flat2').sum()) if len(b) else None,
                 wt_alive=int((b.status == 'alive').sum()) if len(b) else None,
                 wt_last_real_days=",".join(str(int(x)) for x in sorted(b[b.status.isin(['blank', 'flat', 'flat2'])].last_real_day)) if len(b) else None)
        if len(a) and len(b):
            term = d['wt_blank'] + d['wt_flat']
            d['concordant_count'] = 'yes' if term == d['surv_deaths'] else ('yes-if-flat2' if term + d['wt_flat2'] == d['surv_deaths'] else 'NO')
        else:
            d['concordant_count'] = 'arm absent in one block'
        out.append(d)
X = pd.DataFrame(out)
X.to_csv('weight_vs_survival.csv', index=False)
if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 40)
    print(X.to_string())

"""
Candidate-biomarker 'assay window' table (group-level only: immune read-outs and challenge outcomes come from different animals).
For each read-out measured in Sham / PSLN-212 (aged) / PSLN-344 (aged) / PSLN-212(Y):
  - means (GMT for titres), PSLN-344 : PSLN-212 fold ('Mn effect'), restoration vs young
  - individual-level separation between animals from protected arms (PSLN-344 aged, PSLN-212 young) and
    unprotected arms (Sham, PSLN-212 aged):  AUROC (Mann-Whitney), and margin = min(protected)/max(unprotected)
    (for read-outs that fall with protection, e.g. Tfr/Treg/CD206, the inverse is used).
IgG2a:IgG1 is recomputed per animal from S13-A..D (S03-B/F headers are inconsistent with those raw titres).
"""
import pandas as pd, numpy as np
from scipy import stats
T = pd.read_csv('tidy_values.csv'); T = T[T.kind == 'scalar']
def get(block, group):
    return T[(T.block == block) & (T.group == group)].sort_values('unit_idx').value.astype(float).values
cands = [  # (label, block, compartment, timepoint, clinically accessible analogue, direction)
 ('Ifnb1 mRNA, lung, 16 h (no vaccine)', 'S01-A/16h', 'lung', '16 h', 'nasal/bronchial lining fluid IFN-b, CXCL10; blood ISG score', +1),
 ('Migratory CCR7+ CD11b+ DC, lung', 'S02-A', 'lung', '72 h', 'none (tissue)', +1),
 ('CD40+ of MLN CD11b+ DC', 'S02-D CD40', 'MLN', 'd3', 'none (tissue)', +1),
 ('Serum IgG (CA09)', 'S03-A', 'serum', 'd14', 'serum IgG ELISA', +1),
 ('Serum HAI (CA09)', 'S03-C', 'serum', 'd14', 'serum HAI (regulatory standard)', +1),
 ('Serum neutralising titre (CA09)', 'S03-D', 'serum', 'd14', 'serum MN', +1),
 ('GC B cells, MLN', 'S03-K', 'MLN', 'd7', 'none (LN FNA only)', +1),
 ('Tfh ICOS+ , MLN', 'S04-A/ICOShi', 'MLN', 'd7', 'circulating Tfh (ICOS+PD-1+CXCR5+) d7', +1),
 ('Tfr (Foxp3+ of CXCR5+), MLN d7', 'S04-B/Foxp3', 'MLN', 'd7', 'circulating Tfr', -1),
 ('Tfr, MLN d30', 'S04-C', 'MLN', 'd30', 'circulating Tfr', -1),
 ('Ki-67+ CD8, lung', 'S05-D', 'lung', 'd3', 'Ki-67+CD38+ CD8 in blood d7', +1),
 ('GZMB+ CD8, lung', 'S05-E', 'lung', 'd3', 'GZMB+ CD8 in blood / BAL', +1),
 ('IFN-g+ CD8, MLN, rgH5N1 restim (cross-reactive)', 'S05-F', 'MLN', 'd14', 'PBMC IFN-g ELISpot/ICS to conserved NP/M1 pools', +1),
 ('IFN-g+ CD8, MLN, rgH5N1 restim (cross-reactive)', 'S05-G', 'MLN', 'd60', 'PBMC IFN-g ELISpot/ICS to conserved NP/M1 pools', +1),
 ('Lung resident-memory CD8 (CD69+CD103+)', 'S05-I', 'lung', 'd25', 'BAL only', +1),
 ('CD206+ lung macrophages', 'S11-E', 'lung', 'not stated', 'BAL/sputum macrophage phenotype', -1),
 ('IgG+ B220+ cells, MLN', 'S13-H', 'MLN', 'not stated', 'plasmablasts in blood d7', +1),
]
rows = []
for lab, blk, comp, tp, human, sgn in cands:
    d = {g: get(blk, g) for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
    if blk in ('S03-C',):
        for g in d: d[g] = np.where(d[g] <= 0, 5.0, d[g])
    titre = blk in ('S03-A', 'S03-C', 'S03-D')
    cen = (lambda v: np.exp(np.log(v).mean())) if titre else np.mean
    prot = np.concatenate([d['PSLN-344'], d['PSLN-212(Y)']]); unprot = np.concatenate([d['Sham'], d['PSLN-212']])
    U = stats.mannwhitneyu(prot, unprot, alternative='two-sided').statistic
    auc = U / (len(prot) * len(unprot)); auc = auc if sgn > 0 else 1 - auc
    margin = prot.min() / unprot.max() if sgn > 0 else unprot.min() / prot.max()
    # the harder, decision-relevant separation: PSLN-344 aged vs PSLN-212 aged only
    U2 = stats.mannwhitneyu(d['PSLN-344'], d['PSLN-212']).statistic; auc2 = U2 / 25; auc2 = auc2 if sgn > 0 else 1 - auc2
    margin2 = d['PSLN-344'].min() / d['PSLN-212'].max() if sgn > 0 else d['PSLN-212'].min() / d['PSLN-344'].max()
    rows.append(dict(readout=lab, block=blk, compartment=comp, timepoint=tp, central='GMT' if titre else 'mean',
                     Sham=cen(d['Sham']), PSLN212_aged=cen(d['PSLN-212']), PSLN344_aged=cen(d['PSLN-344']), PSLN212_young=cen(d['PSLN-212(Y)']),
                     fold_344_vs_212=cen(d['PSLN-344']) / cen(d['PSLN-212']), pct_of_young=100 * cen(d['PSLN-344']) / cen(d['PSLN-212(Y)']),
                     AUROC_protected_vs_unprotected=auc, margin_all=margin, AUROC_344_vs_212=auc2, margin_344_vs_212=margin2, human_analogue=human))
# IgG2a:IgG1 recomputed
for lab, num, den in [('Serum IgG2a:IgG1 (CA09), recomputed from S13-A/B', 'S13-A', 'S13-B'), ('Serum IgG2a:IgG1 (Aichi), recomputed from S13-C/D', 'S13-C', 'S13-D')]:
    d = {g: get(num, g) / get(den, g) for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
    U2 = stats.mannwhitneyu(d['PSLN-344'], d['PSLN-212']).statistic
    rows.append(dict(readout=lab, block=f'{num}/{den}', compartment='serum', timepoint='d14', central='mean', Sham=np.nan, PSLN212_aged=d['PSLN-212'].mean(),
                     PSLN344_aged=d['PSLN-344'].mean(), PSLN212_young=d['PSLN-212(Y)'].mean(), fold_344_vs_212=d['PSLN-344'].mean() / d['PSLN-212'].mean(),
                     pct_of_young=100 * d['PSLN-344'].mean() / d['PSLN-212(Y)'].mean(), AUROC_protected_vs_unprotected=np.nan, margin_all=np.nan,
                     AUROC_344_vs_212=U2 / 25, margin_344_vs_212=d['PSLN-344'].min() / d['PSLN-212'].max(), human_analogue='no direct analogue (IgG1/IgG3 vs IgG2/IgG4; Th1 cytokine profile)'))
B = pd.DataFrame(rows); B.to_csv('biomarker_window.csv', index=False)
# HAI >= 40 'seroprotection' by arm
hai = []
for blk, ag in [('S03-C', 'CA09 H1N1'), ('S03-G', 'Aichi H3N2')]:
    for g in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        v = get(blk, g); hai.append(dict(block=blk, antigen=ag, group=g, n=len(v), n_ge40=int((v >= 40).sum()), n_ge160=int((v >= 160).sum()), values=",".join(f"{x:g}" for x in v)))
H = pd.DataFrame(hai); H.to_csv('hai_seroprotection.csv', index=False)
if __name__ == '__main__':
    pd.set_option('display.width', 330); pd.set_option('display.max_rows', 100); pd.set_option('display.max_colwidth', 52); pd.set_option('display.float_format', lambda x: f"{x:.3g}")
    print(B.drop(columns=['human_analogue', 'central']).to_string()); print(); print(H.to_string())

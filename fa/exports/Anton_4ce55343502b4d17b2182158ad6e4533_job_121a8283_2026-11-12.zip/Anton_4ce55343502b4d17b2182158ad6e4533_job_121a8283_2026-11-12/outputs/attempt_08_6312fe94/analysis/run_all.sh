#!/usr/bin/env bash
# Rebuilds every table, figure and the ledger from the raw workbook.
# Sandbox note: openpyxl lives in the 'singlecell'/'chem' envs, lifelines in 'core'; on a normal machine one env with
# pandas, numpy, scipy, statsmodels, lifelines, matplotlib, openpyxl, xlsxwriter and markdown is enough (replace the three runners by "python").
set -euo pipefail
cd "$(dirname "$0")"
PX="micromamba run -n singlecell python"   # needs openpyxl
PC="micromamba run -n core python"         # needs lifelines, scipy, statsmodels, matplotlib
PH="micromamba run -n chem python"         # needs xlsxwriter, markdown

# 1. parse workbook -> tidy per-animal tables with cell provenance; audit counts; survival-vs-weight cross-check
$PX blocks.py > /dev/null
$PX n_audit.py > /dev/null
$PX weight_vs_survival.py > /dev/null
$PX duplicates.py > /dev/null
$PX spot_check.py > spot_check_output.txt
# 2. statistics
for s in summarize survival_analysis survival_pooled group_tests timecourse_tests dose_response safety weights_postchallenge \
         check_derived duplicates_weights_refined biomarker_window power_calcs integrity_audit ledger ledger_md; do
  $PC $s.py > /dev/null
done
# 3. figures
for f in fig1_survival_overview fig2_km fig3_restoration fig4_dose_response fig5_tolerability fig6_biomarker fig7_integrity; do
  $PC $f.py > /dev/null
done
# 4. supporting workbook and HTML report
$PH build_workbook.py
$PH build_html.py
echo "rebuild complete"

"""
Refined body-weight duplicate screen.
For every pair of weight arms (block, group): count (day, animal-position) cells with identical values,
after removing (a) day-0 baseline (=100 for all) and (b) carried-forward repeats (a cell equal to the same animal's previous day).
An empirical null is taken from all arm pairs: the per-cell chance-match rate across the whole workbook.
"""
import pandas as pd, numpy as np, itertools
from scipy.stats import binom
T = pd.read_csv('tidy_values.csv'); T = T[T.kind == 'weight'].copy(); T['time'] = T.time.astype(float)
arms = {}
for (blk, grp), g in T.groupby(['block', 'group'], sort=False):
    m = g.pivot(index='time', columns='unit_idx', values='value').sort_index()
    m = m.loc[m.index != 0]
    # mask carried-forward repeats
    rep = m.eq(m.shift(1))
    m = m.mask(rep)
    arms[(blk, grp)] = m
rows = []
tot_same = tot_both = 0
for a, b in itertools.combinations(arms, 2):
    A, Bm = arms[a], arms[b]
    days = [d for d in A.index if d in Bm.index]; cols = [c for c in A.columns if c in Bm.columns]
    x = A.loc[days, cols].values.astype(float); y = Bm.loc[days, cols].values.astype(float)
    both = ~np.isnan(x) & ~np.isnan(y); same = both & (np.abs(x - y) < 1e-9)
    tot_same += same.sum(); tot_both += both.sum()
    rows.append(dict(arm_a=f"{a[0]} | {a[1]}", arm_b=f"{b[0]} | {b[1]}", identical=int(same.sum()), comparable=int(both.sum()),
                     days_fully_identical=",".join(str(int(d)) for i, d in enumerate(days) if both[i].sum() >= 4 and same[i].sum() == both[i].sum())))
D = pd.DataFrame(rows)
p0 = tot_same / tot_both
D['chance_rate'] = p0
D['p_binom'] = [binom.sf(r.identical - 1, r.comparable, p0) if r.comparable else np.nan for r in D.itertuples()]
D['bonferroni_p'] = np.minimum(1, D.p_binom * len(D))
D = D.sort_values('p_binom')
D.to_csv('duplicates_weight_arms_refined.csv', index=False)
if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 100); pd.set_option('display.max_colwidth', 60)
    print(f"workbook-wide chance match rate per comparable cell: {p0:.4f}  ({tot_same}/{tot_both}); arm pairs tested: {len(D)}")
    print(D.head(30).to_string())

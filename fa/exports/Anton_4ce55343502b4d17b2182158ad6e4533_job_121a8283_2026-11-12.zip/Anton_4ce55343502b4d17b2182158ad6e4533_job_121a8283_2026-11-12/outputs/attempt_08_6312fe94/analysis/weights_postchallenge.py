"""
Post-challenge body weight (morbidity) by arm.
Per animal: nadir (% of day-0 weight) over real observations; survivors = animals whose series neither goes blank nor flat-lines
(flat2 series with final value >= 90 are treated as survivors with a coincidental plateau).
Per arm: n, n survivors, mean nadir (all animals), mean nadir (survivors), mean day-14 weight (survivors),
mean weight-deficit AUC over days 0-14 (survivors; trapezoid of max(0, 100-weight)).
NOTE: several weight arms share values with other arms (see duplicates_weight_arms_refined.csv) -> supportive evidence only.
"""
import pandas as pd, numpy as np
from scipy import stats
T = pd.read_csv('tidy_values.csv'); T = T[(T.kind == 'weight') & (T.block != 'S08-D')].copy(); T['day'] = T.time.astype(float)
W = pd.read_csv('weight_animal_status.csv')
W['survivor'] = (W.status == 'alive') | ((W.status == 'flat2') & (W.final_value >= 90))
rows, per = [], []
for (blk, grp), g in T.groupby(['block', 'group'], sort=False):
    wide = g.pivot(index='day', columns='unit_idx', values='value').sort_index()
    st = W[(W.block == blk) & (W.group == grp)].set_index('unit')
    for u in wide.columns:
        s = wide[u].dropna()
        surv = bool(st.loc[u, 'survivor'])
        last_real = st.loc[u, 'last_real_day']
        real = s[s.index <= last_real] if not surv else s
        d = dict(block=blk, group=grp, unit=u, survivor=surv, nadir=real.min(), nadir_day=real.idxmin(), last_real_day=last_real, final=real.iloc[-1])
        if surv:
            deficit = np.clip(100 - s.values, 0, None)
            d['auc'] = np.trapezoid(deficit, s.index.values); d['d14'] = s.iloc[-1]
        per.append(d)
per = pd.DataFrame(per)
summ = per.groupby(['block', 'group'], sort=False).agg(n=('nadir', 'size'), survivors=('survivor', 'sum'), nadir_all=('nadir', 'mean'),
        nadir_surv=('nadir', lambda x: x[per.loc[x.index, 'survivor']].mean()), d14_surv=('d14', 'mean'), auc_surv=('auc', 'mean'),
        n_below80=('nadir', lambda x: int((x < 80).sum()))).reset_index()
per.to_csv('weights_postchallenge_per_animal.csv', index=False); summ.to_csv('weights_postchallenge_summary.csv', index=False)

# young PSLN-344Y vs PSLN-212Y (S09-C/E/G): per-animal nadir, AUC, d14 weight
tests = []
for blk in ['S09-C', 'S09-E', 'S09-G']:
    a = per[(per.block == blk) & (per.group == 'PSLN-344Y')]; b = per[(per.block == blk) & (per.group == 'PSLN-212Y')]
    for m in ['nadir', 'auc', 'd14']:
        t, p = stats.ttest_ind(a[m], b[m], equal_var=False)
        tests.append(dict(block=blk, metric=m, mean_344Y=a[m].mean(), mean_212Y=b[m].mean(), diff=a[m].mean() - b[m].mean(), welch_p=p))
# aged PSLN-344 survivors vs young PSLN-212 survivors: nadir
for blk in ['S13-F', 'S15-A', 'S15-B', 'S15-C', 'S15-D', 'S15-E', 'S15-F', 'S15-G', 'S15-M', 'S15-O']:
    a = per[(per.block == blk) & (per.group == 'PSLN-344') & per.survivor]; b = per[(per.block == blk) & (per.group == 'PSLN-212(Y)') & per.survivor]
    for m in ['nadir', 'auc', 'd14']:
        t, p = stats.ttest_ind(a[m], b[m], equal_var=False)
        tests.append(dict(block=blk, metric=m + ' (survivors; aged 344 vs young 212)', mean_344Y=a[m].mean(), mean_212Y=b[m].mean(), diff=a[m].mean() - b[m].mean(), welch_p=p))
tests = pd.DataFrame(tests); tests.to_csv('weights_postchallenge_tests.csv', index=False)
if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 400); pd.set_option('display.float_format', lambda x: f"{x:.3g}")
    print(summ.to_string()); print(); print(tests.to_string())
    # nature of deaths: final real weight of non-survivors by group (flu-like wasting vs sudden)
    ns = per[~per.survivor]
    print(); print(ns[ns.group.isin(['PSLN-344', 'Untreated', '3d Vaccine+PSLN-344', 'Naïve+PSLN-344', 'Imprinting+PSLN-344'])][['block', 'group', 'unit', 'nadir', 'last_real_day', 'final']].to_string())

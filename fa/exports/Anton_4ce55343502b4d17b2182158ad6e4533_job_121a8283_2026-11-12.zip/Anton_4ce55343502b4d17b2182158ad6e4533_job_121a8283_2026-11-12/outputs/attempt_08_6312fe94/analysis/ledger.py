"""
Numbers ledger: every number the report relies on, recomputed here from the tidy per-animal data,
with source cells and the reduction applied.  Output: numbers_ledger.csv
"""
import pandas as pd, numpy as np
from scipy import stats
T = pd.read_csv('tidy_values.csv'); S = pd.read_csv('tidy_survival.csv')
SUM = pd.read_csv('summary_all_blocks.csv'); PW = pd.read_csv('tests_pairwise.csv'); R = pd.read_csv('restoration_index.csv').set_index('block')
SP = pd.read_csv('survival_pooled.csv'); SPW = pd.read_csv('survival_pairwise.csv'); GT = pd.read_csv('survival_grand_totals.csv').set_index('arm')
L = []
def add(id_, topic, statement, value, source, reduction, test=''):
    L.append(dict(id=id_, topic=topic, statement=statement, value=value, source=source, reduction=reduction, test_or_uncertainty=test))
def row(block, group, time=None):
    x = SUM[(SUM.block == block) & (SUM.group == group)]
    if time is not None: x = x[x.time.astype(str) == str(time)]
    assert len(x) == 1, (block, group, time, len(x)); return x.iloc[0]
def ms(block, group, time=None, d=1):
    r = row(block, group, time); return f"{r['mean']:.{d}f} ± {r.sd:.{d}f} (n={int(r.n)})"
def cells(block, groups, time=None):
    return "; ".join(f"{g}: {row(block, g, time).cells}" for g in groups)
def tuk(block, a, b):
    x = PW[(PW.block == block) & (((PW.a == a) & (PW.b == b)) | ((PW.a == b) & (PW.b == a)))]; assert len(x) == 1, (block, a, b)
    return x.iloc[0].tukey_p, x.iloc[0].welch_p
def fp(p):
    return f"{p:.2g}" if p >= 1e-4 else f"{p:.1e}"
def srange(block, group):
    g = S[(S.block == block) & (S.group == group)]; return f"{g.sheet.iloc[0]}!{g.cell_flag.iloc[0]}:{g.cell_flag.iloc[-1]}"
def sv(block, group):
    g = S[(S.block == block) & (S.group == group) & S.days.notna()]; return int((g.event == 0).sum()), len(g)

# ------------------------------------------------------------------ SURVIVAL
AGED8 = ['S03-I', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E[r34]', 'S06-F[r34]', 'S06-G']
def pooled_row(a, b, scen='primary', sset='aged BALB/c, all 8 four-arm experiments'):
    x = SP[(SP.a == a) & (SP.b == b) & (SP.scenario == scen) & (SP.set.str.strip() == sset.strip())]; assert len(x) == 1, (a, b, scen, sset, len(x)); return x.iloc[0]
src8 = "time-to-event blocks S03-I (S03!A17:F51), S06-A (S06!A3:E30), S06-B (S06!G3:K30), S06-C (S06!M3:Q30), S06-D (S06!A34:E61), S06-E rows 34-68 (S06!G34:L68), S06-F rows 34-68 (S06!M34:R68), S06-G (S06!A71:F105)"
red_s = "animals with status 0 at end of observation / animals with a recorded time, summed over experiments; Clopper-Pearson 95% CI"
p = pooled_row('PSLN-344', 'PSLN-212')
add('E01', 'Survival', 'Aged BALB/c, eight four-arm challenge experiments: PSLN-344 survivors', f"{p.surv_a} = {p.pct_a}% (95% CI {p.ci_a})", src8, red_s,
    f"vs PSLN-212: stratified log-rank chi2 = {p.strat_logrank_chi2}, p = {fp(p.strat_logrank_p)}; Cochran-Mantel-Haenszel p = {fp(p.cmh_p)}")
add('E02', 'Survival', 'Same experiments: PSLN-212 survivors', f"{p.surv_b} = {p.pct_b}% (95% CI {p.ci_b})", src8, red_s)
q = pooled_row('PSLN-344', 'Sham'); add('E03', 'Survival', 'Same experiments: sham (vaccine + empty liposome) survivors', f"{q.surv_b} = {q.pct_b}% (95% CI {q.ci_b})", src8, red_s)
q = pooled_row('PSLN-344', 'PSLN-212(Y)'); add('E04', 'Survival', 'Same experiments: young PSLN-212 benchmark survivors', f"{q.surv_b} = {q.pct_b}% (95% CI {q.ci_b})", src8, red_s,
    f"PSLN-344 aged vs young benchmark: stratified log-rank p = {fp(q.strat_logrank_p)}; CMH p = {fp(q.cmh_p)}")
for i, (scen, lab) in enumerate([('drop S06-D (identical to S06-C)', 'dropping S06-D (identical to S06-C)'),
                                 ('drop S03-I, S06-C, S06-D (all blocks with a table-level conflict)', 'dropping S03-I, S06-C and S06-D'),
                                 ('weight-implied deaths', 'deaths taken from paired weight blocks (blank or flat-lined series)'),
                                 ('worst case for PSLN-344', 'worst case for PSLN-344 (max of table/weight deaths for PSLN-344, min for PSLN-212)')]):
    sset = 'aged BALB/c four-arm experiments' if scen.startswith('drop') else 'aged BALB/c, all 8 four-arm experiments'
    x = pooled_row('PSLN-344', 'PSLN-212', scen, sset)
    add(f'E0{5+i}', 'Survival sensitivity', f'PSLN-344 vs PSLN-212, {lab}', f"{x.surv_a} ({x.pct_a}%) vs {x.surv_b} ({x.pct_b}%)", src8 + ("; weight blocks S13-F, S15-A..G" if 'weight' in scen or 'worst' in scen else ''),
        red_s + ('; weight-implied death = series goes blank or repeats one value to day 14 (two-point plateaus counted only if < 90%)' if 'weight' in scen or 'worst' in scen else ''),
        f"CMH p = {fp(x.cmh_p)}; pooled Fisher p = {fp(x.fisher_pooled_p)}")
for i, (sset, lab) in enumerate([('challenge d14 (3 expts)', 'challenge 14 d after dose (S03-I, S06-A, S06-C)'), ('challenge d3 (2 expts)', 'challenge 3 d after dose (S06-B, S06-D)'),
                                 ('challenge d60 (3 expts)', 'challenge 60 d after dose (S06-E, S06-F, S06-G rows 34-105)')]):
    x = pooled_row('PSLN-344', 'PSLN-212', 'primary', sset)
    add(f'E{9+i:02d}', 'Survival by interval', f'PSLN-344 vs PSLN-212, {lab}', f"{x.surv_a} ({x.pct_a}%; CI {x.ci_a}) vs {x.surv_b} ({x.pct_b}%; CI {x.ci_b})", 'subset of E01 blocks', red_s,
        f"stratified log-rank p = {fp(x.strat_logrank_p)}")
s14, n14 = sum(sv(b, 'PSLN-344')[0] for b in ['S03-I', 'S06-A', 'S06-C']), 21; s60, n60 = sum(sv(b, 'PSLN-344')[0] for b in ['S06-E[r34]', 'S06-F[r34]', 'S06-G']), 21
add('E12', 'Durability', 'PSLN-344 aged: day-14 vs day-60 challenge', f"{s14}/{n14} vs {s60}/{n60}", 'S03-I, S06-A, S06-C vs S06-E, S06-F, S06-G (PSLN-344 columns)', red_s,
    f"Fisher exact two-sided p = {fp(stats.fisher_exact([[s14, n14 - s14], [s60, n60 - s60]])[1])}")
x = pooled_row('PSLN-344', 'Untreated', 'primary', 'challenge d60 (3 expts)')
add('E13', 'Durability', 'Day-60 experiments: untreated, unchallenged aged animals alive at day 14', f"{x.surv_b} ({x.pct_b}%; CI {x.ci_b})", 'S06!L62:L68, S06!R62:R68, S06!F99:F105', red_s,
    f"PSLN-344 ({x.surv_a}) vs untreated: CMH p = {fp(x.cmh_p)}; stratified log-rank p = {fp(x.strat_logrank_p)}")
x = pooled_row('PSLN-344', 'PSLN-212(Y)', 'primary', 'challenge d60 (3 expts)')
add('E14', 'Durability', 'Day-60 experiments: PSLN-344 aged vs young PSLN-212', f"{x.surv_a} vs {x.surv_b}", 'S06-E, S06-F, S06-G (rows 34-105)', red_s, f"CMH p = {fp(x.cmh_p)}; stratified log-rank p = {fp(x.strat_logrank_p)}")
a, b, c = sv('S03-J', 'PSLN-344'), sv('S03-J', 'PSLN-212'), sv('S03-J', 'Sham')
pj = SPW[(SPW.block == 'S03-J')]
add('E15', 'Survival', 'Wild-type H5N1 challenge 2 d after one dose (S03-J)', f"PSLN-344 {a[0]}/{a[1]} (a tenth animal has no recorded time); 'PSLN-212' {b[0]}/{b[1]}; 'Sham' {c[0]}/{c[1]}",
    f"S03!G17:J46 ({srange('S03-J','Sham')}, {srange('S03-J','PSLN-212')}, {srange('S03-J','PSLN-344')})", 'status 0 at day 21 / animals with a recorded time',
    f"log-rank PSLN-344 vs 'PSLN-212' p = {fp(pj[(pj.a=='PSLN-212')&(pj.b=='PSLN-344')].logrank_p.iloc[0])}; vs 'Sham' p = {fp(pj[(pj.a=='Sham')&(pj.b=='PSLN-344')].logrank_p.iloc[0])}. Comparator identities conflict with S13-G.")
a, b, c = sv('S15-H', '3d Vaccine+PSLN-344'), sv('S15-H', '3d PSLN-344'), sv('S15-H', '3d Vaccine')
ph = SPW[SPW.block == 'S15-H']
add('E16', 'Component test', 'rgH5N1 challenge 3 d after dose (S15-H): vaccine + PSLN-344 / PSLN-344 alone / vaccine alone', f"{a[0]}/{a[1]} / {b[0]}/{b[1]} / {c[0]}/{c[1]}", 'S15!A73:D93',
    'status 0 at day 14 / n', f"vaccine+PSLN-344 vs PSLN-344 alone: log-rank p = {fp(ph[(ph.a=='3d PSLN-344')&(ph.b=='3d Vaccine+PSLN-344')].logrank_p.iloc[0])}, Fisher p = {fp(ph[(ph.a=='3d PSLN-344')&(ph.b=='3d Vaccine+PSLN-344')].fisher_p.iloc[0])}")
for i, (blk, lab) in enumerate([('S15-L', 'Aged C57BL/6 (S15-L)'), ('S15-N', 'Aged Swiss Webster (S15-N)')]):
    v = {g: sv(blk, g) for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}; pp = SPW[(SPW.block == blk) & (SPW.a == 'PSLN-212') & (SPW.b == 'PSLN-344')].iloc[0]
    add(f'E{17+i}', 'Other strains', f'{lab}: PSLN-344 / PSLN-212 / sham / young PSLN-212', " / ".join(f"{v[g][0]}/{v[g][1]}" for g in ['PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)']),
        'S15!A103:E130' if blk == 'S15-L' else 'S15!A134:E161', 'status 0 at day 14 / n', f"PSLN-344 vs PSLN-212: log-rank p = {fp(pp.logrank_p)}, Fisher p = {fp(pp.fisher_p)}. Challenge virus and interval not stated.")
v = {g: sv(b, g) for b in ['S06-E[r71]', 'S06-F[r71]'] for g in []}
imp = {(b, g): sv(b, g) for b in ['S06-E[r71]', 'S06-F[r71]'] for g in ['Naïve+PSLN-212', 'Imprinting+PSLN-212', 'Naïve+PSLN-344', 'Imprinting+PSLN-344']}
add('E19', 'Imprinting model', '14-month-old BALB/c (PR8 or saline at 10 months): PR8 challenge (S06-E rows 71-98): naive+212 / imprinted+212 / naive+344 / imprinted+344',
    " / ".join(f"{imp[('S06-E[r71]', g)][0]}/7" for g in ['Naïve+PSLN-212', 'Imprinting+PSLN-212', 'Naïve+PSLN-344', 'Imprinting+PSLN-344']), 'S06!G71:K98', 'status 0 at day 14 / n')
add('E20', 'Imprinting model', 'Same model, Perth H3N2 challenge (S06-F rows 71-98)',
    " / ".join(f"{imp[('S06-F[r71]', g)][0]}/7" for g in ['Naïve+PSLN-212', 'Imprinting+PSLN-212', 'Naïve+PSLN-344', 'Imprinting+PSLN-344']), 'S06!M71:Q98', 'status 0 at day 14 / n')
s344 = sum(imp[k][0] for k in imp if '344' in k[1]); s212 = sum(imp[k][0] for k in imp if '212' in k[1])
add('E21', 'Imprinting model', 'Both imprinting challenges pooled: PSLN-344 vs PSLN-212', f"{s344}/28 vs {s212}/28", 'S06!G71:K98, S06!M71:Q98', 'sum of survivors / sum of n')
for i, arm in enumerate(['PSLN-344 + vaccine', 'PSLN-212 + vaccine', 'Sham / vaccine alone', 'Young + PSLN-212', 'Young + PSLN-344']):
    g = GT.loc[arm]; add(f'E{22+i}', 'Grand totals', f'All cohorts in the workbook: {arm}', f"{g.survivors}/{g.n} = {g.pct}% (CI {g.ci95}); {g.cohorts} cohorts",
                         'all time-to-event blocks (survival_grand_totals.csv lists the cohorts)', red_s)
# young weights d180
W = pd.read_csv('weights_postchallenge_tests.csv'); w = W[(W.block == 'S09-G') & (W.metric == 'd14')].iloc[0]
add('E27', 'Young animals', 'Young, challenge 180 d after dose (S09-G): body weight at day 14, PSLN-344Y vs PSLN-212Y', f"{w.mean_344Y:.1f}% vs {w.mean_212Y:.1f}%", 'S09!G73:N73 (212Y), S09!W73:AD73 (344Y)',
    'mean of 8 per-animal values (% of own day-0 weight)', f"Welch t p = {fp(w.welch_p)}; survival 8/8 in both (S09-F)")
WS = pd.read_csv('weights_postchallenge_summary.csv')
x = WS[(WS.group == 'PSLN-344') & WS.block.isin(['S13-F', 'S15-A', 'S15-B', 'S15-C', 'S15-D', 'S15-E', 'S15-F', 'S15-G'])].nadir_surv
y = WS[(WS.group == 'PSLN-212(Y)') & WS.block.isin(['S13-F', 'S15-A', 'S15-B', 'S15-C', 'S15-D', 'S15-E', 'S15-F', 'S15-G'])].nadir_surv
add('E28', 'Morbidity', 'Mean weight nadir of surviving animals after challenge, range across the eight aged-BALB/c experiments: PSLN-344 aged; young PSLN-212',
    f"{x.min():.1f}-{x.max():.1f}%; {y.min():.1f}-{y.max():.1f}%", 'weight blocks S13-F, S15-A..G', 'per animal: minimum of recorded weights; per arm: mean over survivors (series neither blank nor flat-lined)',
    'supportive only: weight blocks share values across experiments (Q08)')

from statsmodels.stats.proportion import confint_proportions_2indep
def rd(a, n1, b, n2):
    lo, hi = confint_proportions_2indep(a, n1, b, n2, method='newcomb', compare='diff'); return f"{100*(a/n1-b/n2):.1f} points (95% CI {100*lo:.1f} to {100*hi:.1f})"
add('E30', 'Survival', 'Absolute survival gain, PSLN-344 minus PSLN-212, aged BALB/c: as recorded (46/56 vs 6/56); worst case (44/56 vs 10/56)', f"{rd(46, 56, 6, 56)}; {rd(44, 56, 10, 56)}",
    src8, 'difference of pooled proportions; Newcombe hybrid-score 95% CI (pooling ignores the experiment strata; descriptive)')
# fully heterosubtypic experiments (no HA or NA subtype shared between vaccine and challenge)
HET = ['S06-A', 'S06-B', 'S06-E[r34]', 'S06-G']
h = {g: (sum(sv(b, g)[0] for b in HET), sum(sv(b, g)[1] for b in HET)) for g in ['PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)']}
from statsmodels.stats.contingency_tables import StratifiedTable
tabs = [np.array([[sv(b, 'PSLN-344')[0], sv(b, 'PSLN-344')[1] - sv(b, 'PSLN-344')[0]], [sv(b, 'PSLN-212')[0], sv(b, 'PSLN-212')[1] - sv(b, 'PSLN-212')[0]]]) for b in HET]
add('E29', 'Survival', 'Experiments in which vaccine and challenge share neither HA nor NA subtype (S06-A, S06-B: Aichi H3N2 -> PR8 H1N1; S06-E rows 34-68: same at day 60; S06-G: CA09 H1N1 -> Perth H3N2): PSLN-344 / PSLN-212 / sham / young PSLN-212',
    " / ".join(f"{h[g][0]}/{h[g][1]}" for g in h), 'S06!A3:E30, S06!G3:K30, S06!G34:L68, S06!A71:F105', red_s,
    f"PSLN-344 vs PSLN-212: CMH p = {fp(StratifiedTable(tabs).test_null_odds(correction=True).pvalue)}; pooled Fisher p = {fp(stats.fisher_exact([[h['PSLN-344'][0], h['PSLN-344'][1]-h['PSLN-344'][0]], [h['PSLN-212'][0], h['PSLN-212'][1]-h['PSLN-212'][0]]])[1])}")

# ------------------------------------------------------------------ ANTIBODY
for i, (blk, lab) in enumerate([('S03-C', 'HAI titre, CA09 H1N1, day 14'), ('S03-G', 'HAI titre, Aichi H3N2, day 14'), ('S03-A', 'Serum IgG, CA09, day 14'), ('S03-E', 'Serum IgG, Aichi, day 14'),
                                ('S03-D', 'Neutralising titre, CA09, day 14'), ('S03-H', 'Neutralising titre, Aichi, day 14'), ('S13-I', 'Serum IgG, CA09, day 28 (boost day 14)'), ('S13-J', 'Serum IgG, Aichi, day 28 (boost day 14)')]):
    g = {k: row(blk, k) for k in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}; r = R.loc[blk]; t1, w1 = tuk(blk, 'PSLN-212', 'PSLN-344'); t2, w2 = tuk(blk, 'PSLN-344', 'PSLN-212(Y)')
    add(f'I{i+1:02d}', 'Antibody', f'{lab} ({blk}): GMT sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212', " / ".join(f"{g[k].gmt:.0f}" for k in g) + f"; PSLN-344 CI {g['PSLN-344'].gmt_lo:.0f}-{g['PSLN-344'].gmt_hi:.0f}",
        cells(blk, ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']), 'geometric mean of 5 per-animal reciprocal titres; t-based 95% CI on log10' + ('; HAI 0 (no inhibition at 1:10) set to 5' if blk in ('S03-C', 'S03-G') else ''),
        f"PSLN-344/PSLN-212 = {r.mn_fold:.1f}-fold (CI {r.mn_lo:.1f}-{r.mn_hi:.1f}), Tukey p = {fp(t1)} (Welch {fp(w1)}); PSLN-344 = {r.restoration_pct:.0f}% of young (CI {r.rest_lo:.0f}-{r.rest_hi:.0f}), Tukey p = {fp(t2)} (Welch {fp(w2)}); log10 scale")
hai = pd.read_csv('hai_seroprotection.csv')
h = hai[hai.block == 'S03-C'].set_index('group')
add('I09', 'Antibody', 'Animals with HAI >= 40 to CA09 (S03-C): sham / CMP-204 / PSLN-212 / PSLN-344 / young', " / ".join(f"{h.loc[k].n_ge40}/5" for k in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']),
    'S03!K3:O7', 'count of per-animal titres >= 40', 'PSLN-344 and young: 5/5 >= 160')
def quot(num, den, g):
    a = T[(T.block == num) & (T.group == g)].sort_values('unit_idx').value.values; b = T[(T.block == den) & (T.group == g)].sort_values('unit_idx').value.values; return a / b
for i, (lab, num, den, pr) in enumerate([('CA09 H1N1', 'S13-A', 'S13-B', 'S03-B'), ('Aichi H3N2', 'S13-C', 'S13-D', 'S03-F')]):
    qv = {g: quot(num, den, g) for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
    printed = {g: row(pr, g)['mean'] for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
    t, pw = stats.ttest_ind(qv['PSLN-344'], qv['PSLN-212'], equal_var=False)
    tl, pwl = stats.ttest_ind(np.log(qv['PSLN-344']), np.log(qv['PSLN-212']), equal_var=False)
    rng_txt = f"per-animal range PSLN-212 {qv['PSLN-212'].min():.2f}-{qv['PSLN-212'].max():.2f}, PSLN-344 {qv['PSLN-344'].min():.2f}-{qv['PSLN-344'].max():.2f}" 
    add(f'I{10+i}', 'Antibody quality', f'IgG2a:IgG1 quotient, {lab}, recomputed: PSLN-212 / PSLN-344 / young', " / ".join(f"{qv[g].mean():.2f}" for g in qv),
        f"{num} ({row(num,'PSLN-212').cells.split('!')[0]}!{row(num,'PSLN-212').cells.split('!')[1].split(':')[0]}:{row(num,'PSLN-212(Y)').cells.split(':')[1]}) divided by {den}, animal by animal in row order",
        'per-animal IgG2a titre / IgG1 titre; arithmetic mean of 5 quotients', f"PSLN-344 vs PSLN-212 Welch p = {fp(pw)} (on log quotients {fp(pwl)}); {rng_txt}. As printed in {pr}: {printed['PSLN-212']:.2f} / {printed['PSLN-344']:.2f} / {printed['PSLN-212(Y)']:.2f} (headers rotated, Q01)")
# ------------------------------------------------------------------ B / T cell
spec = [('B01', 'S03-K', 'Germinal-centre B cells (% of B cells), lymph node, day 7', 2), ('B02', 'S04-A/ICOShi', 'ICOS+ Tfh (%), lymph node, day 7', 2),
        ('B03', 'S04-B/Foxp3', 'Tfr (Foxp3+ % of CXCR5+ CD4), lymph node, day 7', 1), ('B04', 'S04-C', 'Tfr, lymph node, day 30', 1), ('B05', 'S13-H', 'IgG+ of B220+ cells (%), lymph node (time not stated)', 1),
        ('C01', 'S05-D', 'Ki-67+ CD8 T cells (%), lung, day 3', 2), ('C02', 'S05-E', 'GZMB+ CD8 T cells (%), lung, day 3', 2),
        ('C03', 'S05-F', 'IFN-gamma+ CD8 T cells (%), lymph node, day 14, restimulated with rgH5N1 vaccine', 2), ('C04', 'S05-G', 'IFN-gamma+ CD8 T cells (%), lymph node, day 60, restimulated with rgH5N1 vaccine', 2),
        ('C05', 'S05-H', 'GZMB+ CD8 T cells (%), lymph node, day 60', 2), ('C06', 'S05-I', 'Lung resident-memory CD8 T cells (%), day 25', 2),
        ('C07', 'S14-A H1N1', 'IFN-gamma+ CD8 T cells (%), lymph node, restimulated with CA09 vaccine (time not stated)', 1), ('C08', 'S14-A H3N2', 'IFN-gamma+ CD8 T cells (%), lymph node, restimulated with Aichi vaccine (time not stated)', 1),
        ('M04', 'S02-A', 'Migratory CCR7+ CD11b+ DC (%), lung, 72 h', 1), ('M05', 'S02-B', 'CD11b+CD103- DC (%), lymph node, 72 h', 1), ('M06', 'S02-D CD40', 'CD40+ of lymph-node CD11b+ DC (%), day 3', 1),
        ('M07', 'S02-D CD86', 'CD86+ of lymph-node CD11b+ DC (%), day 3', 1), ('M08', 'S01-F', 'cDC1 (%), lung, 72 h', 1), ('M09', 'S11-E', 'CD206+ macrophages (%), lung (time not stated)', 1),
        ('M10', 'S04-D', 'Lung Treg (CD4+Foxp3+, %), day 7', 2)]
for id_, blk, lab, d in spec:
    gs = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']; r = R.loc[blk]; t1, w1 = tuk(blk, 'PSLN-212', 'PSLN-344'); t2, w2 = tuk(blk, 'PSLN-344', 'PSLN-212(Y)')
    add(id_, 'Cellular read-out', f'{lab} ({blk}): sham / PSLN-212 / PSLN-344 / young PSLN-212', " / ".join(ms(blk, g, d=d).split(' (')[0] for g in gs) + f" (n={int(row(blk,'PSLN-344').n)} each)",
        cells(blk, ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']), 'arithmetic mean ± SD of per-animal values',
        f"PSLN-344/PSLN-212 = {r.mn_fold:.2f}-fold (CI {r.mn_lo:.2f}-{r.mn_hi:.2f}), Tukey p = {fp(t1)} (Welch {fp(w1)}); PSLN-344 = {r.restoration_pct:.0f}% of young (CI {r.rest_lo:.0f}-{r.rest_hi:.0f}), Tukey p = {fp(t2)} (Welch {fp(w2)})")
for id_, blk, lab in [('M11', 'S02-C', 'Antigen (AF647-OVA)+ DC (%), lymph node, 36 h'), ('M12', 'S02-E', 'OT-I proliferation (%) driven by lymph-node CD11b+ DC')]:
    gs = ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PTX', 'PSLN-344(Y)']; r = R.loc[blk]; t1, w1 = tuk(blk, 'PSLN-212', 'PSLN-344'); t2, w2 = tuk(blk, 'PSLN-344', 'PSLN-212(Y)')
    add(id_, 'Cellular read-out', f'{lab} ({blk}): PSLN-212 / PSLN-344 / young PSLN-212 / PTX / young PSLN-344', " / ".join(ms(blk, g, d=1).split(' (')[0] for g in gs) + " (n=5 each)",
        cells(blk, ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']), 'arithmetic mean ± SD',
        f"PSLN-344/PSLN-212 = {r.mn_fold:.1f}-fold (CI {r.mn_lo:.1f}-{r.mn_hi:.1f}), Tukey p = {fp(t1)}; {r.restoration_pct:.0f}% of young, Tukey p = {fp(t2)} (Welch {fp(w2)})")
# ------------------------------------------------------------------ INNATE
gs = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-R848', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']
for id_, blk, lab in [('M01', 'S01-A/16h', 'Lung Ifnb1 mRNA (fold over untreated) 16 h after adjuvant alone (S01-A)'), ('M02', 'S01-A/72h', 'Lung Ifnb1 mRNA 72 h (S01-A)')]:
    r = R.loc[blk]; t1, w1 = tuk(blk, 'PSLN-212', 'PSLN-344'); t2, w2 = tuk(blk, 'PSLN-344', 'PSLN-212(Y)'); t3, w3 = tuk(blk, 'PSLN-212(Y)', 'PSLN-344(Y)')
    add(id_, 'Innate', f"{lab}: " + " / ".join(gs), " / ".join(ms(blk, g, d=1).split(' (')[0] for g in gs) + " (n=5 each)", f"S01!{'B3:F10' if '16h' in blk else 'H3:L10'}", 'arithmetic mean ± SD of per-animal fold values',
        f"PSLN-344/PSLN-212 = {r.mn_fold:.2f}-fold (CI {r.mn_lo:.2f}-{r.mn_hi:.2f}), Tukey p = {fp(t1)}; PSLN-344 aged = {r.restoration_pct:.0f}% of young PSLN-212 (CI {r.rest_lo:.0f}-{r.rest_hi:.0f}), Tukey p = {fp(t2)} (Welch {fp(w2)}); young PSLN-344 vs young PSLN-212 Tukey p = {fp(t3)} (Welch {fp(w3)})")
F = pd.read_csv('dose_response_fit.csv').set_index('group'); DM = pd.read_csv('dose_response_means.csv').set_index(['group', 'dose'])
add('M03', 'Dose-response', 'Ifnb1 dose-response (S08-A; 1-40 ug; age not stated): fitted ceiling (Emax) and ED50, PSLN-344 vs PSLN-212',
    f"Emax {F.loc['PSLN-344','Emax']:.1f} (SE {F.loc['PSLN-344','Emax_se']:.1f}) vs {F.loc['PSLN-212','Emax']:.1f} (SE {F.loc['PSLN-212','Emax_se']:.1f}); ED50 {F.loc['PSLN-344','ED50_ug']:.1f} vs {F.loc['PSLN-212','ED50_ug']:.1f} ug; "
    f"group means at 10/20/40 ug: PSLN-344 {DM.loc[('PSLN-344',10.0),'mean']:.1f}/{DM.loc[('PSLN-344',20.0),'mean']:.1f}/{DM.loc[('PSLN-344',40.0),'mean']:.1f}; PSLN-212 {DM.loc[('PSLN-212',10.0),'mean']:.1f}/{DM.loc[('PSLN-212',20.0),'mean']:.1f}/{DM.loc[('PSLN-212',40.0),'mean']:.1f}",
    'S08!A3:M7', '3-parameter Hill fit to 15 per-animal values per article (baseline fixed at 1); group means of n=3', 'asymptotic SE; 5 dose levels, descriptive')
TCp = pd.read_csv('tests_timecourse_pairwise.csv')
def tcp(block, time, a, b):
    x = TCp[(TCp.block == block) & (TCp.time.astype(str) == str(time)) & (((TCp.a == a) & (TCp.b == b)) | ((TCp.a == b) & (TCp.b == a)))]; assert len(x) == 1, (block, time, a, b, len(x)); return x.iloc[0].welch_p
add('M13', 'Innate', 'Lung Gm-csf mRNA (fold) at 16/36/72 h (S02-F): PSLN-344; PSLN-212; sham', "; ".join("/".join(f"{row('S02-F', g, t)['mean']:.1f}" for t in ['16h', '36h', '72h']) for g in ['PSLN-344', 'PSLN-212', 'Sham']) + " (n=5)",
    'S02!B17:P19', 'arithmetic mean per time point', f"PSLN-344 vs PSLN-212 Welch p = {fp(tcp('S02-F','16h','PSLN-212','PSLN-344'))} / {fp(tcp('S02-F','36h','PSLN-212','PSLN-344'))} / {fp(tcp('S02-F','72h','PSLN-212','PSLN-344'))}")
add('M14', 'Innate', 'Lung monocytes (%) day 0, day 4 and day 8 (S01-D): sham / PSLN-212 / PSLN-344 / young PSLN-212',
    "day 0: " + " / ".join(f"{row('S01-D', g, 0)['mean']:.1f}" for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']) + "; day 4: " + " / ".join(f"{row('S01-D', g, 4)['mean']:.1f}" for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']) + "; day 8: " + " / ".join(f"{row('S01-D', g, 8)['mean']:.1f}" for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']) + " (n=5)",
    'S01!B24:U28', 'arithmetic mean per day', f"day 4 PSLN-344 vs PSLN-212 Welch p = {fp(tcp('S01-D',4,'PSLN-212','PSLN-344'))}; day 8 PSLN-344 vs young Welch p = {fp(tcp('S01-D',8,'PSLN-212(Y)','PSLN-344'))}")
add('M15', 'Innate', 'Lung CD11b+ DC (%) day 4 and day 8 (S01-E): sham / PSLN-212 / PSLN-344 / young PSLN-212',
    "day 4: " + " / ".join(f"{row('S01-E', g, 4)['mean']:.1f}" for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']) + "; day 8: " + " / ".join(f"{row('S01-E', g, 8)['mean']:.1f}" for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']) + " (n=5)",
    'S01!B30:Z34', 'arithmetic mean per day', f"day 4 PSLN-344 vs PSLN-212 Welch p = {fp(tcp('S01-E',4,'PSLN-212','PSLN-344'))}; day 8 PSLN-344 vs young Welch p = {fp(tcp('S01-E',8,'PSLN-212(Y)','PSLN-344'))}")
add('M16', 'Mechanism', 'Ly6C+CCR2+ lung macrophages (x10^5) days 0/2/5/10/30 (S07-A): PSLN-212; PSLN-344', "; ".join("/".join(f"{row('S07-A', g, t)['mean']:.1f}" for t in [0, 2, 5, 10, 30]) for g in ['PSLN-212', 'PSLN-344']) + " (n=3)",
    'S07!B3:G7', 'arithmetic mean per day', f"day 5 Welch p = {fp(tcp('S07-A',5,'PSLN-212','PSLN-344'))}; day 10 p = {fp(tcp('S07-A',10,'PSLN-212','PSLN-344'))}")
def two(block, a, b, d=1):
    x = PW[(PW.block == block) & (PW.a == a) & (PW.b == b)].iloc[0]; return f"{ms(block, a, d=d)} vs {ms(block, b, d=d)}", x
v, x = two('S02-H', 'WT w/o cDC', 'IFN w/o cDC'); add('M17', 'Mechanism', 'Donor-derived monocyte-derived DC (%), wild-type vs Ifnar-knockout marrow, cDC precursors removed (S02-H); GM-CSF rescue', v + f"; Ifnar-KO + GM-CSF {ms('S02-H','GMCSF')}", 'S02!B30:F34', 'arithmetic mean ± SD', f"WT vs KO Tukey p = {fp(x.tukey_p)}; KO vs KO+GM-CSF Tukey p = {fp(tuk('S02-H','IFN w/o cDC','GMCSF')[0])}")
v, x = two('S12-A', 'WT to WT', 'IFNAR-/- to WT'); add('M18', 'Mechanism', 'Infiltrating donor monocytes (%), wild-type vs Ifnar-knockout marrow, young recipients (S12-A)', v, 'S12!A3:B5', 'arithmetic mean ± SD', f"Student t p = {fp(x.student_p)} (Welch {fp(x.welch_p)})")
v, x = two('S02-G', 'PSLN-212', 'PSLN-212+GM-CSF'); add('M19', 'Mechanism', 'Ly6C+CD11c+MHC-II+ cells (%), lung day 5: PSLN-212 vs PSLN-212 + recombinant GM-CSF (S02-G)', v, 'S02!B22:D26', 'arithmetic mean ± SD', f"Tukey p = {fp(x.tukey_p)}")
v, x = two('S07-B/Mono', 'PSLN-344', 'PSLN-344+INCB3344'); add('M20', 'Mechanism', 'Lung monocytes (%) with CCR2 antagonist (S07-B)', v, 'S07!B10:C14', 'arithmetic mean ± SD', f"Student t p = {fp(x.student_p)}")
v, x = two('S07-B/Ly6C+Mac', 'PSLN-344', 'PSLN-344+INCB3344'); add('M21', 'Mechanism', 'Ly6C+ lung macrophages (%) with CCR2 antagonist (S07-B)', v, 'S07!E10:F14', 'arithmetic mean ± SD', f"Student t p = {fp(x.student_p)}")
v, x = two('S02-I', 'PSLN-344(Y)', 'PSLN-344(Y)+INCB3344', d=2); add('M22', 'Mechanism', 'GZMB+ lung CD8 T cells (%) day 5 with CCR2 antagonist, young animals (S02-I)', v, 'S02!H30:I34', 'arithmetic mean ± SD', f"Student t p = {fp(x.student_p)}")
v, x = two('S11-C', 'CBX-', 'CBX+', d=2) if len(PW[(PW.block=='S11-C')&(PW.a=='CBX-')]) else (f"{ms('S11-C','CBX-',d=2)} vs {ms('S11-C','CBX+',d=2)}", PW[PW.block == 'S11-C'].iloc[0])
add('M23', 'Mechanism', 'Recruited lung monocytes (%) day 3 without vs with carbenoxolone (S11-C)', v, 'S11!A17:B21', 'arithmetic mean ± SD', f"Student t p = {fp(x.student_p)}")
x = PW[PW.block == 'S01-C'].iloc[0]; add('M24', 'Mechanism', 'DiD+ alveolar macrophages (%) 16 h: wild-type vs Sftpa1/Sftpd double-knockout (S01-C)', f"{ms('S01-C','WT')} vs {ms('S01-C','SPA/D')}", 'S01!B20:E21', 'arithmetic mean ± SD', f"Student t p = {fp(x.student_p)}")
add('M25', 'Mechanism', 'OT-I proliferation (%) day 4, lung / lung+PTX / lymph node / lymph node+PTX (S05-C)', " / ".join(ms('S05-C', g).split(' (')[0] for g in ['Lung', 'Lung+PTX', 'MLN', 'MLN+PTX']) + " (n=3)", 'S05!A13:D15', 'arithmetic mean ± SD',
    f"lung vs lung+PTX Tukey p = {fp(tuk('S05-C','Lung','Lung+PTX')[0])}; lymph node vs lymph node+PTX Tukey p = {fp(tuk('S05-C','MLN','MLN+PTX')[0])}")
AN = pd.read_csv('tests_anova.csv').set_index('block')
add('M26', 'CMC', 'Encapsulation efficiency (%): CMP-204 / PSLN-212 / PSLN-R848 / PSLN-212/R848 / PSLN-344 (S08-B)', " / ".join(f"{row('S08-B', g)['mean']:.1f}" for g in ['CMP-204', 'PSLN-212', 'PSLN-R848', 'PSLN-212/R848', 'PSLN-344']) + " (n=3)",
    'S08!A11:O11', 'arithmetic mean of 3 preparations', f"one-way ANOVA p = {fp(AN.loc['S08-B','anova_p'])}")
am0 = {g: row('S11-A', g, 0) for g in ['Vaccine', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
add('M29', 'Mechanism', 'Alveolar macrophages (% of lung cells) before dosing, day 0 (S11-A): aged groups (vaccine / PSLN-212 / PSLN-344) vs young PSLN-212',
    " / ".join(f"{am0[g]['mean']:.1f}" for g in ['Vaccine', 'PSLN-212', 'PSLN-344']) + f" vs {am0['PSLN-212(Y)']['mean']:.1f} (n=5 each)", 'S11!B3:U3', 'arithmetic mean of day-0 values',
    'S11-A shares 35 of 100 cells with S11-B (Q06); treat as an observation')
add('M30', 'Mechanism', 'Alveolar epithelial cells positive for liposome dye cargo (SRB) 16 h after intranasal dosing (S01-B): type II with PSLN-SRB / type I with PSLN-SRB / type II with free SRB / type I with free SRB',
    " / ".join(ms('S01-B', g).split(' (')[0] for g in ['AECII/PSLN-SRB', 'AECI/PSLN-SRB', 'AECII/FreeSRB', 'AECI/FreeSRB']) + " (n=5 each)", 'S01!B14:F17', 'arithmetic mean ± SD',
    f"type II PSLN-SRB vs free SRB Tukey p = {fp(tuk('S01-B','AECII/PSLN-SRB','AECII/FreeSRB')[0])}; S08-C re-uses some of these values under other labels (Q11)")
add('M27', 'Mechanism (low weight)', 'NP366-374 tetramer+ CD8 (%), lung, day 7 (S05-A): PSLN-212 / PSLN-344 / young PSLN-212', " / ".join(f"{row('S05-A', g, 7)['mean']:.1f}" for g in ['PSLN-212', 'PSLN-344', 'PSLN-212Y']) + " (n=2; stated n=3)",
    'S05!B5:I5', 'arithmetic mean of 2 values', 'not relied on (Q10)')
add('M28', 'Mechanism (uninterpretable)', 'Lung Treg (%) after macrophage transfer (S07-C): column B vs column C, both labelled "Ly6C-CD206+ MΦ"', f"{ms('S07-C','Ly6C-CD206+ MΦ [col B]')} vs {ms('S07-C','Ly6C-CD206+ MΦ [col C]')}", 'S07!B16:C20', 'arithmetic mean ± SD', 'direction cannot be assigned (Q07)')
# ------------------------------------------------------------------ SAFETY
s8 = pd.read_csv('safety_S08D_summary.csv').set_index('group'); t8 = pd.read_csv('safety_S08D_tests.csv')
def t8p(metric, g, ref): return t8[(t8.metric == metric) & (t8.group == g) & (t8.ref == ref)].p_welch.iloc[0]
add('T01', 'Tolerability', 'Body-weight nadir (% of day 0) after intranasal vaccine + adjuvant (S08-D): vaccine alone / young PSLN-212 / PSLN-212 / CMP-204 / PSLN-344 / PSLN-212/R848',
    " / ".join(f"{s8.loc[g,'nadir_mean']:.1f} ± {s8.loc[g,'nadir_sd']:.1f}" for g in ['Vaccine', 'PSLN-212(Y)', 'PSLN-212', 'CMP-204', 'PSLN-344', 'PSLN-212/R848']) + f" (n=5); lowest PSLN-344 animal {s8.loc['PSLN-344','nadir_min']:.1f}",
    'S08!B21:AE26', 'per animal: minimum over days 2-10; per group: mean ± SD', f"PSLN-344 vs vaccine alone Welch p = {fp(t8p('nadir','PSLN-344','Vaccine'))}; vs PSLN-212 p = {fp(t8p('nadir','PSLN-344','PSLN-212'))}")
add('T02', 'Tolerability', 'Weight-deficit AUC days 0-10 (%·day), same groups (S08-D)', " / ".join(f"{s8.loc[g,'auc_mean']:.1f}" for g in ['Vaccine', 'PSLN-212(Y)', 'PSLN-212', 'CMP-204', 'PSLN-344', 'PSLN-212/R848']),
    'S08!B21:AE26', 'per animal: trapezoid of max(0, 100 - weight) over recorded days; per group: mean', f"PSLN-344 vs vaccine alone Welch p = {fp(t8p('deficit_auc','PSLN-344','Vaccine'))}; vs PSLN-212 p = {fp(t8p('deficit_auc','PSLN-344','PSLN-212'))}")
d10 = T[(T.block == 'S08-D') & (T.time.astype(str).isin(['10', '10.0']))]
a10 = d10[d10.group == 'PSLN-344'].value; r10 = d10[d10.group == 'PSLN-212/R848'].value
add('T03', 'Tolerability', 'Day-10 weight (% of day 0): PSLN-344; PSLN-212/R848 (S08-D)', f"{a10.mean():.1f} (n={len(a10)}; lowest animal {a10.min():.1f}); {r10.mean():.1f} (n={len(r10)}; one animal has no day-10 value; lowest {r10.min():.1f})",
    'S08!Q26:U26; S08!V26:Z26', 'arithmetic mean of the day-10 values present')
cy = pd.read_csv('safety_S09A_summary.csv'); ct = pd.read_csv('safety_S09A_tests.csv')
def cyv(panel, an, g): return cy[(cy.block == panel) & (cy.time == an) & (cy.group == g)].gm_fold.iloc[0]
def ctp(panel, an, a, b): x = ct[(ct.block == panel) & (ct.analyte == an) & (ct.a == a) & (ct.b == b)].iloc[0]; return x.fold_ratio, x.p_welch
for i, (panel, tp, rng) in enumerate([('S09-A[colsA-U]', '16 h', 'S09!B3:V9'), ('S09-A[colsX-AS]', '72 h (second panel, labelled 16h; time point inferred, Q05)', 'S09!Y3:AS9')]):
    for j, an in enumerate(['Tnf', 'Il6', 'Il10']):
        fr, pw = ctp(panel, an, 'PSLN-344', 'PSLN-212(y)'); fr2, pw2 = ctp(panel, an, 'PSLN-344', 'PSLN-212')
        add(f'T{4+i*3+j:02d}', 'Tolerability', f'Lung {an} mRNA, {tp}: young PSLN-212 / aged PSLN-212 / aged PSLN-344 / aged PSLN-212/R848 (fold over PBS)',
            " / ".join(f"{cyv(panel, an, g):.1f}" for g in ['PSLN-212(y)', 'PSLN-212', 'PSLN-344', 'PSLN-212/R848']) + " (n=3)", rng, 'values stored as log10 fold; geometric-mean fold = 10^mean(log10)',
            f"PSLN-344 aged vs young PSLN-212: {fr:.1f}-fold, Welch p = {fp(pw)}; vs aged PSLN-212: {fr2:.1f}-fold, p = {fp(pw2)} (t-tests on log10 values)")
cns = pd.read_csv('safety_S10A_summary.csv'); cnt = pd.read_csv('safety_S10A_tests.csv')
for j, an in enumerate(['Ifnb1', 'Tnf', 'Isg15']):
    v = {g: cns[(cns.analyte == an) & (cns.group == g)].iloc[0] for g in ['PBS', 'Sham', 'PSLN-344', 'CT']}
    x1 = cnt[(cnt.analyte == an) & (cnt.a == 'PSLN-344') & (cnt.b == 'Sham')].iloc[0]; x2 = cnt[(cnt.analyte == an) & (cnt.a == 'PSLN-344') & (cnt.b == 'PBS')].iloc[0]; x3 = cnt[(cnt.analyte == an) & (cnt.a == 'CT') & (cnt.b == 'PSLN-344')].iloc[0]
    add(f'T{10+j}', 'Tolerability (CNS)', f'Brain {an} mRNA 36 h after dosing (S10-A): PBS / sham / PSLN-344 / cholera toxin', " / ".join(f"{v[g]['mean']:.2f} ± {v[g]['std']:.2f}" for g in v) + " (n=5)",
        f"S10!{'A3:D7' if an == 'Ifnb1' else 'F3:I7' if an == 'Tnf' else 'K3:N7'}", 'arithmetic mean ± SD (block annotated as mean with SD)',
        f"PSLN-344 vs sham: ratio {x1.ratio:.2f}, Tukey p = {fp(x1.tukey_p)}, difference CI {x1.tukey_lo:.2f} to {x1.tukey_hi:.2f}; vs PBS: ratio {x2.ratio:.2f}, Tukey p = {fp(x2.tukey_p)} (Welch {fp(x2.welch_p)}); cholera toxin vs PSLN-344 Tukey p = {fp(x3.tukey_p)}")
Ld = pd.DataFrame(L); Ld.to_csv('numbers_ledger.csv', index=False)
if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 130)
    print(len(Ld)); print(Ld[['id', 'statement', 'value']].to_string())

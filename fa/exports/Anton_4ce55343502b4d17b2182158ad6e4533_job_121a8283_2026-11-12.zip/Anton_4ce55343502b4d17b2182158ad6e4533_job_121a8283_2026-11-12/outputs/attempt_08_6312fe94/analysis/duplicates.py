"""
Duplicate-vector screen.
(1) body-weight blocks: for every pair of (block, group) arms, count cells that are identical at the same
    (day, animal-position), excluding the day-0 '100' row.
(2) all blocks: for every pair of replicate vectors (block, group, time/analyte), flag exact equality of >=3 values
    in the same positions.
"""
import pandas as pd, numpy as np, itertools
import blocks as B
t = B.tidy.copy()

# ---------- (1) weight arms
w = t[t.kind == 'weight']
arms = {}
for (blk, grp), g in w.groupby(['block', 'group'], sort=False):
    m = g.pivot(index='time', columns='unit_idx', values='value')
    arms[(blk, grp)] = m
rec = []
keys = list(arms)
for a, b in itertools.combinations(keys, 2):
    A, Bm = arms[a], arms[b]
    days = [d for d in A.index if d in Bm.index and d != 0]
    cols = [c for c in A.columns if c in Bm.columns]
    if not days or not cols:
        continue
    x = A.loc[days, cols].values.astype(float)
    y = Bm.loc[days, cols].values.astype(float)
    both = ~np.isnan(x) & ~np.isnan(y)
    same = both & (np.abs(x - y) < 1e-9)
    n_same, n_both = int(same.sum()), int(both.sum())
    # exclude matches that are only 'LOCF self repeats'? keep raw
    if n_same >= 5:
        # which days are fully identical
        full_days = [d for i, d in enumerate(days) if both[i].sum() >= 3 and same[i].sum() == both[i].sum()]
        rec.append(dict(arm_a=f"{a[0]} | {a[1]}", arm_b=f"{b[0]} | {b[1]}", identical_cells=n_same, comparable_cells=n_both,
                        frac=round(n_same / n_both, 2), fully_identical_days=",".join(str(d) for d in full_days)))
D1 = pd.DataFrame(rec).sort_values('identical_cells', ascending=False)
D1.to_csv('duplicates_weight_arms.csv', index=False)

# ---------- (2) generic replicate vectors
vecs = {}
for (blk, grp, tm, an), g in t.groupby(['block', 'group', t.time.astype(str), t.analyte.astype(str)], sort=False):
    v = g.sort_values('unit_idx')
    vecs[(blk, grp, tm, an)] = (v.value.values.astype(float), v.cell.iloc[0] + ':' + v.cell.iloc[-1], v.kind.iloc[0])
rec2 = []
keys = list(vecs)
for a, b in itertools.combinations(keys, 2):
    (x, ra, ka), (y, rb, kb) = vecs[a], vecs[b]
    if ka == 'weight' and kb == 'weight':
        continue  # handled above
    n = min(len(x), len(y))
    if n < 3:
        continue
    same = np.abs(x[:n] - y[:n]) < 1e-9
    # ignore trivial all-100 baseline vectors
    if same.sum() >= 3 and not (np.all(x[:n] == 100) or np.all(y[:n] == 100)):
        rec2.append(dict(a=" | ".join(map(str, a)), range_a=ra, b=" | ".join(map(str, b)), range_b=rb,
                         identical_positions=int(same.sum()), length=n, values=",".join(f"{v:g}" for v in x[:n][same])))
D2 = pd.DataFrame(rec2)
D2.to_csv('duplicates_other.csv', index=False)

if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 80)
    print(D1.to_string())
    print()
    print(D2.to_string())

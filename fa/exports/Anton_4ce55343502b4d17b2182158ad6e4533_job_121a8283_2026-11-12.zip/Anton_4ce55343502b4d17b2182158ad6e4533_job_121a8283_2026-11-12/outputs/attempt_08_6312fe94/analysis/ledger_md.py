import pandas as pd
L = pd.read_csv('numbers_ledger.csv').fillna('')
out = ["# Numbers ledger — PSLN-344 portfolio review", "",
       "Every number used in the report, recomputed from the per-animal values in `adjuvant_program_dataset.xlsx` by `analysis/ledger.py`.",
       "Each entry gives the value, the source block and cells, how the per-animal values were reduced, and the test or uncertainty attached.",
       "Conventions: arithmetic mean ± SD for percentages and linear fold-changes; geometric mean for titres (HAI 0 set to 5, half the lowest dilution tested) "
       "and for the log10-stored S09-A panel; survival = animals with status 0 at end of observation / animals with a recorded time; Tukey p-values are from one-way ANOVA + Tukey HSD across all groups of the block "
       "(titres on log10); 'Welch' is an unequal-variance two-group t-test. Confidence intervals on fold-ratios and on '% of young' come from a Welch t-interval on per-animal log values, centred on the ratio of arithmetic means (geometric means for titres). Q-numbers refer to the record-conflict register (`analysis/integrity_audit.csv`, report Section 7).", ""]
topic = None
for _, r in L.iterrows():
    if r.topic != topic:
        topic = r.topic; out += [f"## {topic}", ""]
    out += [f"**{r.id}** — {r.statement}", "", f"- Value: **{r.value}**", f"- Source: {r.source}", f"- Reduction: {r.reduction}"]
    if r.test_or_uncertainty: out += [f"- Test / uncertainty: {r.test_or_uncertainty}"]
    out += [""]
open('/tmp/outputs/numbers_ledger.md', 'w').write("\n".join(out)); print(len(L), 'entries')

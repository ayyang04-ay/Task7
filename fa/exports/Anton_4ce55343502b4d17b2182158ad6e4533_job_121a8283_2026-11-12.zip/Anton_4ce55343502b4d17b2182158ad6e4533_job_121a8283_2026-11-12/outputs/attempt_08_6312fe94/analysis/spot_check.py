"""
Clean-room spot check for reviewers: reads the cited cell ranges straight from the workbook with openpyxl
(no block registry, no intermediate files) and recomputes the headline numbers of the report.
"""
import openpyxl, numpy as np
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx')
def rng(sheet, a1):
    return np.array([c.value for row in wb[sheet][a1] for c in row if c.value is not None], dtype=float)
def hdr(sheet, cell):
    return str(wb[sheet][cell].value).strip()
gm = lambda v: float(np.exp(np.log(v).mean()))

print("HAI CA09 (S03!M/N/O 3:7) headers:", hdr('S03', 'M2'), hdr('S03', 'N2'), hdr('S03', 'O2'),
      "| GMT:", round(gm(rng('S03', 'M3:M7')), 1), round(gm(rng('S03', 'N3:N7')), 1), round(gm(rng('S03', 'O3:O7')), 1))
print("IgG CA09 (S03!C/D/E 3:7) GMT:", round(gm(rng('S03', 'C3:C7'))), round(gm(rng('S03', 'D3:D7'))), round(gm(rng('S03', 'E3:E7'))))
print("IFN-g+ CD8 day 14 (S05!A:D 33:37)", [hdr('S05', c + '32') for c in 'ABCD'], [float(round(rng('S05', f'{c}33:{c}37').mean(), 2)) for c in 'ABCD'])
print("IFN-g+ CD8 day 60 (S05!A:D 40:44)", [float(round(rng('S05', f'{c}40:{c}44').mean(), 2)) for c in 'ABCD'])
print("Ifnb1 16 h (S01!B:F rows 3-10)", [(hdr('S01', f'A{r}'), float(round(rng('S01', f'B{r}:F{r}').mean(), 2))) for r in range(3, 11)])

tot = {'Sham': [0, 0], 'PSLN-212': [0, 0], 'PSLN-344': [0, 0], 'PSLN-212(Y)': [0, 0]}
specs = [('S03-I', 'S03', {'Sham': 'B', 'PSLN-212': 'D', 'PSLN-344': 'E', 'PSLN-212(Y)': 'F'}, 17, 51),
         ('S06-A', 'S06', {'Sham': 'B', 'PSLN-212': 'C', 'PSLN-344': 'D', 'PSLN-212(Y)': 'E'}, 3, 30),
         ('S06-B', 'S06', {'Sham': 'H', 'PSLN-212': 'I', 'PSLN-344': 'J', 'PSLN-212(Y)': 'K'}, 3, 30),
         ('S06-C', 'S06', {'Sham': 'N', 'PSLN-212': 'O', 'PSLN-344': 'P', 'PSLN-212(Y)': 'Q'}, 3, 30),
         ('S06-D', 'S06', {'Sham': 'B', 'PSLN-212': 'C', 'PSLN-344': 'D', 'PSLN-212(Y)': 'E'}, 34, 61),
         ('S06-E rows 34-68', 'S06', {'Sham': 'H', 'PSLN-212': 'I', 'PSLN-344': 'J', 'PSLN-212(Y)': 'K'}, 34, 68),
         ('S06-F rows 34-68', 'S06', {'Sham': 'N', 'PSLN-212': 'O', 'PSLN-344': 'P', 'PSLN-212(Y)': 'Q'}, 34, 68),
         ('S06-G', 'S06', {'Sham': 'B', 'PSLN-212': 'C', 'PSLN-344': 'D', 'PSLN-212(Y)': 'E'}, 71, 105)]
for name, sh, cols, r0, r1 in specs:
    out = []
    for g, c in cols.items():
        assert hdr(sh, f'{c}{r0 - 1}') == g
        flags = [wb[sh][f'{c}{r}'].value for r in range(r0, r1 + 1)]; flags = [f for f in flags if f is not None]
        tot[g][0] += flags.count(0); tot[g][1] += len(flags); out.append(f"{g} {flags.count(0)}/{len(flags)}")
    print(f"survivors/n {name}:", "; ".join(out))
print("POOLED survivors/n:", {g: f"{a}/{b}" for g, (a, b) in tot.items()})

print("Post-dose weight nadir, PSLN-344 (S08!Q:U 22:26):", [float(min(wb['S08'][f'{c}{r}'].value for r in range(22, 27))) for c in 'QRSTU'])
print("Brain Tnf (S10!F:I 3:7)", [hdr('S10', c + '2') for c in 'FGHI'], [float(round(rng('S10', f'{c}3:{c}7').mean(), 2)) for c in 'FGHI'])
q = [rng('S13', f'{a}3:{a}7') / rng('S13', f'{b}3:{b}7') for a, b in [('A', 'E'), ('B', 'F'), ('C', 'G')]]
print("IgG2a:IgG1 recomputed from S13 (PSLN-212, PSLN-344, young):", [float(round(x.mean(), 2)) for x in q],
      "| printed in S03-B under", [(hdr('S03', c + '2'), float(round(rng('S03', f'{c}3:{c}7').mean(), 2))) for c in 'GHI'])
same = all(wb['S06'][f'{a}{r}'].value == wb['S06'][f'{b}{r + 31}'].value for r in range(3, 31) for a, b in [('M', 'A'), ('N', 'B'), ('O', 'C'), ('P', 'D'), ('Q', 'E')])
print("S06-C (S06!M3:Q30) identical to S06-D (S06!A34:E61), cell for cell:", same)
print("S03-J PSLN-344 row 46: days =", wb['S03']['G46'].value, "| status =", wb['S03']['J46'].value)

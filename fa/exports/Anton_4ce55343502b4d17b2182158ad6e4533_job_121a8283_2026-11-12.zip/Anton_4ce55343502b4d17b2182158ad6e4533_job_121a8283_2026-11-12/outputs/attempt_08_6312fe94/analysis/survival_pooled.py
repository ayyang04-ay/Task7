"""
Pooled / stratified survival analyses + sensitivity analyses.
Strata = experiments (each experiment contains all compared arms at equal n).
 - pooled survival proportion with Clopper-Pearson 95% CI (descriptive)
 - Cochran-Mantel-Haenszel test across experiments (statsmodels StratifiedTable)
 - stratified log-rank (sum of O-E and hypergeometric variances across strata)
Sensitivity scenarios for the aged-BALB/c set:
   primary      : deaths exactly as in the time-to-event blocks
   weight-implied: deaths = animals whose body-weight series goes blank or flat-lines (LOCF) in the partner weight block
   worst-for-344: PSLN-344 deaths = max(table, weight); PSLN-212 deaths = min(table, weight)
"""
import pandas as pd, numpy as np
from scipy.stats import beta, chi2, fisher_exact
from statsmodels.stats.contingency_tables import StratifiedTable

S = pd.read_csv('tidy_survival.csv'); S = S[S.days.notna()]
W = pd.read_csv('weight_animal_status.csv')

def cp(k, n, a=0.05):
    lo = 0.0 if k == 0 else beta.ppf(a / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta.ppf(1 - a / 2, k + 1, n - k)
    return 100 * lo, 100 * hi

def strat_logrank(S, blocks, ga, gb):
    OE, V = 0.0, 0.0
    for b in blocks:
        g = S[(S.block == b) & (S.group.isin([ga, gb]))]
        for t in sorted(g[g.event == 1].days.unique()):
            at = g[g.days >= t]
            n = len(at); n1 = (at.group == ga).sum()
            d = ((g.days == t) & (g.event == 1)).sum()
            d1 = ((g.days == t) & (g.event == 1) & (g.group == ga)).sum()
            if n > 1:
                OE += d1 - d * n1 / n
                V += d * (n1 / n) * (1 - n1 / n) * (n - d) / (n - 1)
    stat = OE ** 2 / V
    return stat, chi2.sf(stat, 1)

def pooled(S, blocks, ga, gb, deaths_override=None):
    tabs, rows = [], []
    for b in blocks:
        A = S[(S.block == b) & (S.group == ga)]; Bg = S[(S.block == b) & (S.group == gb)]
        da, db = int(A.event.sum()), int(Bg.event.sum())
        if deaths_override:
            da = deaths_override.get((b, ga), da); db = deaths_override.get((b, gb), db)
        tabs.append(np.array([[len(A) - da, da], [len(Bg) - db, db]]))
        rows.append((b, len(A) - da, len(A), len(Bg) - db, len(Bg)))
    sa = sum(r[1] for r in rows); na = sum(r[2] for r in rows); sb = sum(r[3] for r in rows); nb = sum(r[4] for r in rows)
    st = StratifiedTable(tabs)
    try:
        cmh = st.test_null_odds(correction=True); cmh_p = cmh.pvalue
    except Exception:
        cmh_p = np.nan
    _, fisher_pooled = fisher_exact([[sa, na - sa], [sb, nb - sb]])
    return dict(a=ga, b=gb, n_experiments=len(blocks), surv_a=f"{sa}/{na}", pct_a=round(100 * sa / na, 1), ci_a="%.0f-%.0f" % cp(sa, na),
                surv_b=f"{sb}/{nb}", pct_b=round(100 * sb / nb, 1), ci_b="%.0f-%.0f" % cp(sb, nb), cmh_p=cmh_p, fisher_pooled_p=fisher_pooled), rows

AGED8 = ['S03-I', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E[r34]', 'S06-F[r34]', 'S06-G']
D14 = ['S03-I', 'S06-A', 'S06-C']; D3 = ['S06-B', 'S06-D']; D60 = ['S06-E[r34]', 'S06-F[r34]', 'S06-G']
out = []
for name, blocks in [('aged BALB/c, all 8 four-arm experiments', AGED8), ('  challenge d14 (3 expts)', D14),
                     ('  challenge d3 (2 expts)', D3), ('  challenge d60 (3 expts)', D60)]:
    for ga, gb in [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212(Y)'), ('PSLN-212', 'Sham')]:
        r, _ = pooled(S, blocks, ga, gb)
        stat, p = strat_logrank(S, blocks, ga, gb)
        r.update(set=name, strat_logrank_chi2=round(stat, 1), strat_logrank_p=p, scenario='primary')
        out.append(r)
# d60: vs untreated (background mortality)
r, _ = pooled(S, D60, 'PSLN-344', 'Untreated'); stat, p = strat_logrank(S, D60, 'PSLN-344', 'Untreated')
r.update(set='  challenge d60 (3 expts)', strat_logrank_chi2=round(stat, 1), strat_logrank_p=p, scenario='primary'); out.append(r)

# ---- sensitivity: weight-implied deaths
pairs = {'S03-I': 'S13-F', 'S06-A': 'S15-A', 'S06-B': 'S15-B', 'S06-C': 'S15-C', 'S06-D': 'S15-D',
         'S06-E[r34]': 'S15-E', 'S06-F[r34]': 'S15-F', 'S06-G': 'S15-G'}
def wdeaths(wblock, group):
    g = W[(W.block == wblock) & (W.group == group)]
    # terminal = blank, flat (>=3 identical terminal values), or flat2 with final value < 90
    return int(((g.status.isin(['blank', 'flat'])) | ((g.status == 'flat2') & (g.final_value < 90))).sum())
ov_w, ov_worst = {}, {}
detail = []
for sb, wb_ in pairs.items():
    for grp in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        tbl = int(S[(S.block == sb) & (S.group == grp)].event.sum()); wd = wdeaths(wb_, grp)
        ov_w[(sb, grp)] = wd
        ov_worst[(sb, grp)] = max(tbl, wd) if grp in ('PSLN-344', 'PSLN-212(Y)') else min(tbl, wd)
        detail.append(dict(surv_block=sb, wt_block=wb_, group=grp, deaths_table=tbl, deaths_weight_implied=wd))
pd.DataFrame(detail).to_csv('survival_sensitivity_detail.csv', index=False)
for scen, ov in [('weight-implied deaths', ov_w), ('worst case for PSLN-344', ov_worst)]:
    for ga, gb in [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212(Y)')]:
        r, _ = pooled(S, AGED8, ga, gb, deaths_override=ov)
        r.update(set='aged BALB/c, all 8 four-arm experiments', scenario=scen, strat_logrank_chi2=np.nan, strat_logrank_p=np.nan)
        out.append(r)
P = pd.DataFrame(out)[['set', 'scenario', 'a', 'b', 'n_experiments', 'surv_a', 'pct_a', 'ci_a', 'surv_b', 'pct_b', 'ci_b', 'cmh_p', 'fisher_pooled_p', 'strat_logrank_chi2', 'strat_logrank_p']]
P.to_csv('survival_pooled.csv', index=False)

# ---- time-trend in PSLN-344 (aged BALB/c): d14 vs d60
def cnt(blocks, grp):
    g = S[S.block.isin(blocks) & (S.group == grp)]; return int((g.event == 0).sum()), len(g)
s14, n14 = cnt(D14, 'PSLN-344'); s60, n60 = cnt(D60, 'PSLN-344'); s3, n3 = cnt(D3, 'PSLN-344')
_, p_14_60 = fisher_exact([[s14, n14 - s14], [s60, n60 - s60]])
trend = dict(d3=f"{s3}/{n3}", d14=f"{s14}/{n14}", d60=f"{s60}/{n60}", fisher_d14_vs_d60=p_14_60)

if __name__ == '__main__':
    pd.set_option('display.width', 330); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 45)
    q = P.copy()
    for c in ['cmh_p', 'fisher_pooled_p', 'strat_logrank_p']:
        q[c] = q[c].map(lambda x: '' if pd.isna(x) else f"{x:.2g}")
    print(q.to_string())
    print(); print(pd.DataFrame(detail).to_string())
    print(); print('PSLN-344 aged BALB/c by challenge day:', trend)

# ---------------------------------------------------------------------------------------------------------------
# Additional sensitivity scenarios (appended): exclude duplicated / conflicted blocks; grand totals across all aged cohorts
extra = []
for scen, blocks in [('drop S06-D (identical to S06-C)', [b for b in AGED8 if b != 'S06-D']),
                     ('drop S03-I, S06-C, S06-D (all blocks with a table-level conflict)', [b for b in AGED8 if b not in ('S03-I', 'S06-C', 'S06-D')])]:
    for ga, gb in [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212(Y)')]:
        r, _ = pooled(S, blocks, ga, gb); stat, p = strat_logrank(S, blocks, ga, gb)
        r.update(set='aged BALB/c four-arm experiments', scenario=scen, strat_logrank_chi2=round(stat, 1), strat_logrank_p=p); extra.append(r)
E = pd.DataFrame(extra)[P.columns]
P2 = pd.concat([P, E], ignore_index=True); P2.to_csv('survival_pooled.csv', index=False)

# grand totals: every aged / middle-aged cohort that received vaccine + the stated adjuvant
gt = []
sets = {'PSLN-344 + vaccine': [('S03-I', 'PSLN-344'), ('S06-A', 'PSLN-344'), ('S06-B', 'PSLN-344'), ('S06-C', 'PSLN-344'), ('S06-D', 'PSLN-344'), ('S06-E[r34]', 'PSLN-344'),
                               ('S06-F[r34]', 'PSLN-344'), ('S06-G', 'PSLN-344'), ('S03-J', 'PSLN-344'), ('S15-H', '3d Vaccine+PSLN-344'), ('S15-L', 'PSLN-344'), ('S15-N', 'PSLN-344'),
                               ('S06-E[r71]', 'Naïve+PSLN-344'), ('S06-E[r71]', 'Imprinting+PSLN-344'), ('S06-F[r71]', 'Naïve+PSLN-344'), ('S06-F[r71]', 'Imprinting+PSLN-344')],
        'PSLN-212 + vaccine': [('S03-I', 'PSLN-212'), ('S06-A', 'PSLN-212'), ('S06-B', 'PSLN-212'), ('S06-C', 'PSLN-212'), ('S06-D', 'PSLN-212'), ('S06-E[r34]', 'PSLN-212'),
                               ('S06-F[r34]', 'PSLN-212'), ('S06-G', 'PSLN-212'), ('S03-J', 'PSLN-212'), ('S15-L', 'PSLN-212'), ('S15-N', 'PSLN-212'),
                               ('S06-E[r71]', 'Naïve+PSLN-212'), ('S06-E[r71]', 'Imprinting+PSLN-212'), ('S06-F[r71]', 'Naïve+PSLN-212'), ('S06-F[r71]', 'Imprinting+PSLN-212')],
        'Sham / vaccine alone': [('S03-I', 'Sham'), ('S06-A', 'Sham'), ('S06-B', 'Sham'), ('S06-C', 'Sham'), ('S06-D', 'Sham'), ('S06-E[r34]', 'Sham'), ('S06-F[r34]', 'Sham'),
                                 ('S06-G', 'Sham'), ('S03-J', 'Sham'), ('S15-H', '3d Vaccine'), ('S15-L', 'Sham'), ('S15-N', 'Sham')],
        'Young + PSLN-212': [(b, 'PSLN-212(Y)') for b in AGED8 + ['S15-L', 'S15-N']] + [(b, 'PSLN-212Y') for b in ['S09-B', 'S09-D', 'S09-F']],
        'Young + PSLN-344': [(b, 'PSLN-344Y') for b in ['S09-B', 'S09-D', 'S09-F']] + [('S13-E', 'PSLN-344(Y)')]}
for name, arms in sets.items():
    s_ = n_ = 0
    for b, g in arms:
        x = S[(S.block == b) & (S.group == g)]; assert len(x) > 0, (b, g)
        s_ += int((x.event == 0).sum()); n_ += len(x)
    lo, hi = cp(s_, n_); gt.append(dict(arm=name, cohorts=len(arms), survivors=s_, n=n_, pct=round(100 * s_ / n_, 1), ci95=f"{lo:.0f}-{hi:.0f}"))
GT = pd.DataFrame(gt); GT.to_csv('survival_grand_totals.csv', index=False)
if __name__ == '__main__':
    q = E.copy()
    for c in ['cmh_p', 'fisher_pooled_p', 'strat_logrank_p']: q[c] = q[c].map(lambda x: '' if pd.isna(x) else f"{x:.2g}")
    print(); print(q.to_string()); print(); print(GT.to_string())

# Analysis folder

Everything in the report is rebuilt from `adjuvant_program_dataset.xlsx` by `run_all.sh`. Paths are absolute (`/tmp/world/filesystem/…` in, `/tmp/outputs/…` out); change them at the top of `blocks.py`, `build_workbook.py` and `build_html.py` if the files move.

Packages: pandas, numpy, scipy, statsmodels, lifelines, matplotlib, openpyxl, xlsxwriter, markdown.

## Run order

| Step | Script | What it does | Main outputs |
|---|---|---|---|
| 1 | `blocks.py` | Maps every numeric cell of the workbook to a block, group, animal and time point, using explicit cell ranges. Prints the cells it does not consume (axis labels and the unlabelled S08 rows only). | `tidy_values.csv`, `tidy_survival.csv` |
| 1 | `n_audit.py` | Stated n (from each block label) against observations found. | `n_audit.csv` |
| 1 | `weight_vs_survival.py` | Classifies each body-weight series (alive / goes blank / flat-lines) and compares death counts with the paired survival table. | `weight_animal_status.csv`, `weight_vs_survival.csv` |
| 1 | `duplicates.py`, `duplicates_weights_refined.py` | Screens for identical values at the same position in different blocks; binomial test against the workbook-wide chance rate. | `duplicates_*.csv` |
| 1 | `spot_check.py` | Independent check for reviewers: reads the cited cell ranges directly (no registry) and recomputes the headline numbers. | `spot_check_output.txt` |
| 2 | `summarize.py` | n, mean, SD, SEM, median, range for every block/group/time; geometric means for titres. | `summary_all_blocks.csv` |
| 2 | `survival_analysis.py` | Per-arm survival, exact CIs, Kaplan–Meier medians, log-rank and Fisher tests for every pair of arms. | `survival_by_group.csv`, `survival_pairwise.csv` |
| 2 | `survival_pooled.py` | Pooled and stratified comparisons, sensitivity scenarios, grand totals. | `survival_pooled.csv`, `survival_grand_totals.csv`, `survival_sensitivity_detail.csv` |
| 2 | `group_tests.py`, `timecourse_tests.py` | ANOVA + Tukey, Student and Welch tests; restoration index (aged PSLN-344 as % of young PSLN-212) and Mn effect with CIs. | `tests_*.csv`, `restoration_index.csv` |
| 2 | `dose_response.py` | Hill fits to S08-A. | `dose_response_*.csv` |
| 2 | `safety.py` | Post-dose weight (S08-D), lung cytokines (S09-A), brain transcripts (S10-A). | `safety_*.csv` |
| 2 | `weights_postchallenge.py` | Post-challenge weight nadir and area by arm. | `weights_postchallenge_*.csv` |
| 2 | `check_derived.py` | Recomputes derived blocks from their sources (IgG2a:IgG1; Tfh:Tfr; S09-A against S01-A). | `check_*.csv` |
| 2 | `biomarker_window.py` | Candidate-biomarker table and HAI ≥ 40 counts. | `biomarker_window.csv`, `hai_seroprotection.csv` |
| 2 | `power_calcs.py` | Exact power of Fisher's test for planning. | `power_calcs.csv` |
| 2 | `integrity_audit.py` | The record-conflict register. | `integrity_audit.csv` |
| 2 | `ledger.py`, `ledger_md.py` | Recomputes every number cited in the report, with source cells and reduction. | `numbers_ledger.csv`, `../numbers_ledger.md` |
| 3 | `fig1…fig7_*.py` | Figures. | `../figures/*.png` |
| 4 | `build_workbook.py`, `build_html.py` | Supporting workbook and self-contained HTML report. | `../PSLN-344_supporting_tables.xlsx`, `../PSLN-344_portfolio_recommendation.html` |

## Conventions

- Block keys follow the workbook labels. Where a label is used twice, a suffix disambiguates: `S06-E[r34]` and `S06-E[r71]` are the two blocks labelled S06-E (starting at rows 34 and 71); `S09-A[colsA-U]` and `S09-A[colsX-AS]` are the two panels labelled "S09-A 16h".
- Survival: status 1 = death, 0 = alive at end of observation. This was checked against the body weights (animals with status 1 go blank or flat-line; animals with status 0 keep changing to day 14).
- Nothing is imputed. The four exclusions are listed in Section 2 of the report.

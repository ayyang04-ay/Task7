import pandas as pd, numpy as np
from figstyle import *
import matplotlib.gridspec as gridspec
T = pd.read_csv('tidy_values.csv')
fig = plt.figure(figsize=(10.2, 7.6))
fig.suptitle('Tolerability: small transient weight dip, no brain signal; lung cytokines resolve more slowly in aged mice', x=0.07, y=0.965, ha='left', fontsize=10.5, fontweight='bold')
gs = gridspec.GridSpec(2, 2, height_ratios=[1, 1], width_ratios=[1.25, 1], hspace=0.5, wspace=0.32)
# ---- A: S08-D
ax = fig.add_subplot(gs[0, 0])
D = T[T.block == 'S08-D'].copy(); D['day'] = D.time.astype(float)
order = ['Vaccine', 'PSLN-212(Y)', 'PSLN-212', 'CMP-204', 'PSLN-344', 'PSLN-212/R848']
names = {'Vaccine': 'vaccine alone', 'PSLN-212(Y)': 'PSLN-212, young', 'PSLN-212': 'PSLN-212', 'CMP-204': 'CMP-204', 'PSLN-344': 'PSLN-344', 'PSLN-212/R848': 'PSLN-212/R848'}
ylab = {'Vaccine': 100.2, 'PSLN-212(Y)': 101.3, 'PSLN-212': 102.4, 'CMP-204': 103.5, 'PSLN-344': 98.9, 'PSLN-212/R848': 90.7}
for g in order:
    m = D[D.group == g].groupby('day').value.agg(['mean', 'std'])
    ax.plot(m.index, m['mean'], color=COL[g], lw=2.4 if g == 'PSLN-344' else 1.2, marker='o', ms=4.5 if g == 'PSLN-344' else 3, zorder=4 if g == 'PSLN-344' else 2)
    if g in ('PSLN-344', 'PSLN-212/R848'):
        ax.fill_between(m.index, m['mean'] - m['std'], m['mean'] + m['std'], color=COL[g], alpha=0.13, lw=0)
    ax.plot([10.05, 10.55], [m['mean'].iloc[-1], ylab[g]], color=COL[g], lw=0.5)
    ax.text(10.65, ylab[g], names[g], color=COL[g], fontsize=8, va='center', fontweight='bold' if g == 'PSLN-344' else 'normal')
ax.plot([0, 10], [100, 100], color='#dddddd', lw=0.7, zorder=0)
ax.set_xlim(0, 14.2); ax.set_ylim(84, 104.5); ax.set_xticks([0, 2, 4, 6, 8, 10]); ax.spines['bottom'].set_bounds(0, 10)
ax.set_xlabel('Days after intranasal immunisation', x=0.36); ax.set_ylabel('Body weight (% of day 0)')
ax.set_title('A  Body weight after dosing', loc='left', fontsize=9.5)
# ---- C: CNS
ax = fig.add_subplot(gs[0, 1])
N = T[T.block.str.startswith('S10-A')]
CC = dict(COL); CC['PBS'] = '#c4c4c4'; CC['Sham'] = '#6e6e6e'
xpos = 0; xt = []; xl = []
for a in ['Ifnb1', 'Tnf', 'Isg15']:
    for j, g in enumerate(['PBS', 'Sham', 'PSLN-344', 'CT']):
        v = N[(N.analyte == a) & (N.group == g)].value.values; x = xpos + j * 0.22
        ax.scatter([x] * len(v), v, s=11, color=CC[g], alpha=0.8, zorder=3)
        ax.plot([x - 0.08, x + 0.08], [v.mean()] * 2, color=CC[g], lw=2.2, zorder=4)
    xt.append(xpos + 0.33); xl.append(a); xpos += 1.15
ax.axhline(1, color='#bbbbbb', lw=0.8); ax.set_xticks(xt); ax.set_xticklabels(xl); ax.set_ylabel('Brain mRNA at 36 h (fold over untreated)'); ax.set_ylim(0, 8.6)
for j, (g, lab) in enumerate([('PBS', 'PBS'), ('Sham', 'vaccine + empty liposome'), ('PSLN-344', 'vaccine + PSLN-344'), ('CT', 'vaccine + cholera toxin')]):
    ax.text(0.03, 0.98 - j * 0.068, '● ' + lab, color=CC[g], transform=ax.transAxes, fontsize=7.8, va='top', fontweight='bold' if g == 'PSLN-344' else 'normal')
ax.set_title('B  Brain transcripts, 36 h after dosing', loc='left', fontsize=9.5)
# ---- B: cytokines 16h vs 72h
ax = fig.add_subplot(gs[1, :])
C = T[T.block.isin(['S09-A[colsA-U]', 'S09-A[colsX-AS]'])].copy()
C['tp'] = np.where(C.block == 'S09-A[colsA-U]', '16 h', '72 h')
an = ['Ifnb1', 'Tnf', 'Il6', 'Il10', 'Ccl2']; groups = ['PSLN-212(y)', 'PSLN-212', 'PSLN-344', 'PSLN-212/R848']
gl = {'PSLN-212(y)': 'PSLN-212(Y)', 'PSLN-212': 'PSLN-212', 'PSLN-344': 'PSLN-344', 'PSLN-212/R848': 'PSLN-212/R848'}
xpos = 0; xt = []; xl = []
for a in an:
    x0 = xpos
    for tp in ['16 h', '72 h']:
        for j, g in enumerate(groups):
            v = C[(C.time == a) & (C.tp == tp) & (C.group == g)].value.values
            x = xpos + j * 0.2
            ax.scatter([x] * len(v), 10 ** v, s=11, color=COL[gl[g]], alpha=0.7, zorder=3)
            ax.plot([x - 0.075, x + 0.075], [10 ** v.mean()] * 2, color=COL[gl[g]], lw=2.2, zorder=4)
        xt.append(xpos + 0.3); xl.append(tp); xpos += 1.0
    ax.text((x0 + xpos - 0.4) / 2, -0.16, a, ha='center', fontsize=9.5, fontweight='bold', transform=ax.get_xaxis_transform(), va='top')
    xpos += 0.45
ax.set_yscale('log'); ax.axhline(1, color='#bbbbbb', lw=0.8); ax.set_xticks(xt); ax.set_xticklabels(xl, fontsize=8)
ax.set_ylabel('Lung mRNA, fold over PBS (log scale)'); ax.set_ylim(0.04, 5000); ax.set_xlim(-0.4, xpos - 0.5)
ax.set_title('C  Lung cytokine transcripts at 16 h and 72 h (no vaccine)', loc='left', fontsize=9.5)
for j, (g, lab) in enumerate([('PSLN-212(Y)', 'PSLN-212, young'), ('PSLN-212', 'PSLN-212, aged'), ('PSLN-344', 'PSLN-344, aged'), ('PSLN-212/R848', 'PSLN-212/R848, aged')]):
    ax.text(0.012 + j * 0.17, 0.955, '● ' + lab, color=COL[g], transform=ax.transAxes, fontsize=8, va='top', fontweight='bold' if g == 'PSLN-344' else 'normal')
fig.text(0.07, 0.005, 'A: S08-D, CA09 vaccine + 20 µg adjuvant, n = 5 (PSLN-212/R848: 4 at day 10), mean; shading = SD.  B: S10-A, n = 5, bars = mean; one time point, no PSLN-212 arm, brain region not specified.\n'
         'C: S09-A, no vaccine, n = 3, bars = geometric mean. The second S09-A panel is labelled "16h" in the workbook; its Ifnb1 values reproduce the 72-h panel of S01-A, so it is shown as 72 h.', fontsize=7.2, color='#444444', va='top')
fig.savefig('/tmp/outputs/figures/fig5_tolerability.png'); print('ok')

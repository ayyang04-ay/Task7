"""Render the Markdown report to a single self-contained HTML file (figures embedded)."""
import markdown, base64, re, pathlib
root = pathlib.Path('/tmp/outputs')
md = (root / 'PSLN-344_portfolio_recommendation.md').read_text()
def embed(m):
    alt, path = m.group(1), m.group(2)
    data = base64.b64encode((root / path).read_bytes()).decode()
    return f'<figure><img alt="{alt}" src="data:image/png;base64,{data}"></figure>'
md = re.sub(r'!\[(.*?)\]\((.*?)\)', embed, md)
body = markdown.markdown(md, extensions=['tables', 'sane_lists'])
css = """
body{font-family:-apple-system,'Segoe UI',Helvetica,Arial,sans-serif;font-size:15px;line-height:1.5;color:#1c1c1c;max-width:1080px;margin:32px auto;padding:0 28px}
h1{font-size:26px;margin-bottom:4px} h2{font-size:20px;margin-top:34px;border-bottom:1px solid #ccc;padding-bottom:4px} h3{font-size:16.5px;margin-top:24px}
table{border-collapse:collapse;margin:12px 0 18px 0;font-size:13px;width:100%} th,td{border:1px solid #cfcfcf;padding:5px 8px;vertical-align:top;text-align:left}
th{background:#f1f1f1} tr:nth-child(even) td{background:#fafafa} code{background:#f3f3f3;padding:1px 4px;border-radius:3px;font-size:12.5px}
figure{margin:16px 0} img{max-width:100%;height:auto;border:1px solid #e4e4e4} hr{border:0;border-top:1px solid #ddd;margin:28px 0}
@media print{body{max-width:none;margin:10mm;font-size:11px} table{font-size:9.5px} h2{page-break-after:avoid} figure,table{page-break-inside:avoid}}
"""
html = f"<!doctype html><html lang='en'><head><meta charset='utf-8'><title>PSLN-344 portfolio recommendation</title><style>{css}</style></head><body>{body}</body></html>"
(root / 'PSLN-344_portfolio_recommendation.html').write_text(html)
print('written', root / 'PSLN-344_portfolio_recommendation.html', round(len(html) / 1e6, 2), 'MB')

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
COL = {'Sham': '#8c8c8c', 'Vaccine': '#8c8c8c', 'PBS': '#8c8c8c', 'PSLN-212': '#0072B2', 'PSLN-344': '#D55E00', 'PSLN-212(Y)': '#009E73',
       'PSLN-344(Y)': '#E69F00', 'Untreated': '#000000', 'CMP-204': '#CC79A7', 'PSLN-212/R848': '#56B4E9', 'PSLN-R848': '#b9dcf2',
       'PSLN-344/R848': '#56B4E9', 'CT': '#7a4fa0', 'Naïve': '#c9c9c9'}
LAB = {'Sham': 'Vaccine + empty liposome (sham), aged', 'PSLN-212': 'PSLN-212 (no Mn), aged', 'PSLN-344': 'PSLN-344 (Mn), aged',
       'PSLN-212(Y)': 'PSLN-212, young (benchmark)', 'Untreated': 'Untreated, unchallenged, aged'}
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'axes.titlesize': 10, 'axes.titleweight': 'bold',
                     'axes.labelsize': 9, 'legend.frameon': False, 'figure.dpi': 150, 'savefig.dpi': 200, 'savefig.bbox': 'tight',
                     'font.family': 'DejaVu Sans'})

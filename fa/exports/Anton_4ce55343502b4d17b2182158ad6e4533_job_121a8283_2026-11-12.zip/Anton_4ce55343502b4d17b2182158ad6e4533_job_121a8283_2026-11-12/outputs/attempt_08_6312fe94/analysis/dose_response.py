"""
S08-A: Ifnb1 (fold vs untreated, linear) 16 h after intranasal nanoparticle at 1/5/10/20/40 ug; n=3 per dose.
Reduction: arithmetic mean +/- SD per dose; 3-parameter Hill fit  E = 1 + (Emax-1) * d^h / (ED50^h + d^h)  on per-animal values
(baseline fixed at 1 = untreated). Reported with asymptotic SEs; with 5 dose levels this is descriptive only.
"""
import pandas as pd, numpy as np
from scipy.optimize import curve_fit
T = pd.read_csv('tidy_values.csv'); D = T[T.block == 'S08-A'].copy(); D['dose'] = D.time.astype(float)
def hill(d, emax, ed50, h):
    return 1 + (emax - 1) * d ** h / (ed50 ** h + d ** h)
rows = []
tab = D.groupby(['group', 'dose']).value.agg(['mean', 'std', 'count']).round(2)
for g, x in D.groupby('group', sort=False):
    try:
        p, cov = curve_fit(hill, x.dose.values, x.value.values, p0=[x.value.max(), 10, 2], bounds=([1, 0.1, 0.3], [500, 200, 10]), maxfev=20000)
        se = np.sqrt(np.diag(cov))
        m = x.groupby('dose').value.mean()
        rows.append(dict(group=g, Emax=p[0], Emax_se=se[0], ED50_ug=p[1], ED50_se=se[1], hill=p[2], hill_se=se[2],
                         mean_at_20=m[20], mean_at_40=m[40], pct_of_40ug_at_20ug=100 * m[20] / m[40], pct_of_fitted_Emax_at_20ug=100 * (m[20] - 1) / (p[0] - 1)))
    except Exception as e:
        rows.append(dict(group=g, err=str(e)))
F = pd.DataFrame(rows)
F.to_csv('dose_response_fit.csv', index=False); tab.to_csv('dose_response_means.csv')
if __name__ == '__main__':
    pd.set_option('display.width', 250)
    print(tab.unstack('dose').to_string()); print(); print(F.round(2).to_string())
    # dose of PSLN-344 matching PSLN-212's plateau
    m = D.groupby(['group', 'dose']).value.mean().unstack()
    print(); print(m.round(2).to_string())
    print("ratio 344/212 by dose:", (m.loc['PSLN-344'] / m.loc['PSLN-212']).round(2).to_dict())

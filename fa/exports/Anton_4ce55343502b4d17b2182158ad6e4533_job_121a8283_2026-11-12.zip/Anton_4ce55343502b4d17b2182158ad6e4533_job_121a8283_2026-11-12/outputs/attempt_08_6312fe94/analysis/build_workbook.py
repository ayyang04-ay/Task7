"""Assemble the supporting tables into one workbook for the committee pack."""
import pandas as pd
out = '/tmp/outputs/PSLN-344_supporting_tables.xlsx'
sheets = [
 ('Ledger', 'numbers_ledger.csv', 'Every number used in the report: value, source cells, reduction, test'),
 ('Audit', 'integrity_audit.csv', 'Record conflicts and gaps (tier A = changes a citable number; B = weakens a claim; C = housekeeping)'),
 ('Survival_by_arm', 'survival_by_group.csv', 'Each time-to-event block, each arm: n, deaths, survivors, exact 95% CI, median, death days, cells'),
 ('Survival_pairwise', 'survival_pairwise.csv', 'Log-rank and Fisher exact tests for every pair of arms within each block'),
 ('Survival_pooled', 'survival_pooled.csv', 'Pooled / stratified comparisons incl. sensitivity scenarios'),
 ('Survival_totals', 'survival_grand_totals.csv', 'Grand totals across all cohorts'),
 ('Wt_vs_survival', 'weight_vs_survival.csv', 'Deaths in survival tables vs terminal patterns in paired body-weight blocks'),
 ('Wt_animals', 'weight_animal_status.csv', 'Per-animal classification of each body-weight series (alive / blank / flat)'),
 ('Wt_postchallenge', 'weights_postchallenge_summary.csv', 'Post-challenge weight nadir / AUC by arm (supportive only)'),
 ('Summary_all_blocks', 'summary_all_blocks.csv', 'n, mean, SD, SEM, median, range (GMT for titres) for every block/group/time, with cells'),
 ('Tests_scalar', 'tests_pairwise.csv', 'ANOVA-Tukey (or Student t) and Welch tests for scalar blocks (titres on log10)'),
 ('Tests_timecourse', 'tests_timecourse_pairwise.csv', 'Per-time-point Welch contrasts for time-course blocks'),
 ('Restoration_index', 'restoration_index.csv', 'PSLN-344 aged as % of young PSLN-212; PSLN-344/PSLN-212 fold (Mn effect), with CIs'),
 ('Biomarker_window', 'biomarker_window.csv', 'Candidate biomarkers: group values, separation metrics, human analogue'),
 ('HAI_ge40', 'hai_seroprotection.csv', 'HAI titres by animal and counts >= 40 / >= 160'),
 ('Dose_response', 'dose_response_fit.csv', 'Hill fits to S08-A'),
 ('Safety_weight', 'safety_S08D_summary.csv', 'Post-immunisation weight (S08-D)'),
 ('Safety_cytokines', 'safety_S09A_summary.csv', 'Lung cytokine transcripts (S09-A), geometric-mean fold'),
 ('Safety_CNS', 'safety_S10A_tests.csv', 'Brain transcripts (S10-A) contrasts'),
 ('N_audit', 'n_audit.csv', 'Stated n vs observations found, every block and group'),
 ('Dup_weights', 'duplicates_weight_arms_refined.csv', 'Identical cells between body-weight arms (carried-forward repeats removed); binomial test vs workbook chance rate'),
 ('Power', 'power_calcs.csv', 'Exact power of Fisher test for planning'),
 ('Tidy_values', 'tidy_values.csv', 'All per-animal values with sheet/cell provenance'),
 ('Tidy_survival', 'tidy_survival.csv', 'All time-to-event rows with sheet/cell provenance'),
]
with pd.ExcelWriter(out, engine='xlsxwriter') as xw:
    idx = pd.DataFrame([(s, d, f) for s, f, d in sheets], columns=['sheet', 'content', 'source_file_in_analysis_folder'])
    idx.to_excel(xw, sheet_name='README', index=False, startrow=3)
    ws = xw.sheets['README']
    ws.write(0, 0, 'PSLN-344 portfolio review: supporting tables. All values are computed from adjuvant_program_dataset.xlsx by the scripts in /analysis.')
    ws.write(1, 0, 'Conventions: means are arithmetic means of per-animal values ± SD; titres are geometric means; survival = animals with status 0 at end of observation / animals with a recorded time.')
    ws.set_column(0, 0, 22); ws.set_column(1, 1, 110); ws.set_column(2, 2, 42)
    for s, f, d in sheets:
        df = pd.read_csv(f)
        df.to_excel(xw, sheet_name=s, index=False)
        w = xw.sheets[s]; w.freeze_panes(1, 0)
        for i, c in enumerate(df.columns):
            width = min(60, max(10, int(df[c].astype(str).str.len().quantile(0.9)) + 2, len(str(c)) + 2))
            w.set_column(i, i, width)
print('written', out)

"""
Block registry + parser for adjuvant_program_dataset.xlsx.

Every block in the workbook is addressed by explicit cell ranges so that each tidy value
carries its provenance (sheet + cell address).  Nothing is imputed here.

Tidy columns:
  block    : unique block key (duplicated workbook labels are disambiguated with a suffix)
  label    : label exactly as printed in the workbook
  sheet, cell
  kind     : 'scalar' | 'timecourse' | 'survival' | 'weight'
  group    : group name exactly as printed (whitespace-stripped)
  unit_idx : replicate index within group (column/row position, 1-based)
  time     : timepoint/dose/analyte-row key (None for scalar)
  analyte  : sub-panel key when a block holds several analytes
  value    : numeric value as stored
"""
import openpyxl
import pandas as pd
from openpyxl.utils import get_column_letter as L, column_index_from_string as C

XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
_wb = openpyxl.load_workbook(XLSX, data_only=False)

def _v(sheet, r, c):
    return _wb[sheet].cell(r, c).value

def _addr(r, c):
    return f"{L(c)}{r}"

rows_out = []
surv_out = []
meta = {}

def _emit(block, label, sheet, kind, group, unit_idx, time, analyte, r, c):
    v = _v(sheet, r, c)
    if v is None:
        return
    rows_out.append(dict(block=block, label=label, sheet=sheet, kind=kind, group=str(group).strip(),
                         unit_idx=unit_idx, time=time, analyte=analyte, value=v, cell=_addr(r, c)))

def cols_block(block, sheet, label_cell, header_row, first_col, ncols, r0, r1, analyte=None, kind='scalar'):
    """groups in columns; replicates down rows"""
    fc = C(first_col)
    label = _wb[sheet][label_cell].value
    meta[block] = dict(label=label, sheet=sheet, rng=f"{first_col}{header_row}:{L(fc+ncols-1)}{r1}")
    for j in range(ncols):
        g = _v(sheet, header_row, fc + j)
        assert g is not None, (block, header_row, fc + j)
        g = f"{str(g).strip()}"
        for i, r in enumerate(range(r0, r1 + 1)):
            _emit(block, label, sheet, kind, g, i + 1, None, analyte, r, fc + j)

def rows_block(block, sheet, label_cell, label_col, first_col, n, r0, r1, analyte=None, kind='scalar'):
    """groups in rows (name in label_col); replicates across columns"""
    lc, fc = C(label_col), C(first_col)
    label = _wb[sheet][label_cell].value
    meta[block] = dict(label=label, sheet=sheet, rng=f"{label_col}{r0}:{L(fc+n-1)}{r1}")
    for r in range(r0, r1 + 1):
        g = _v(sheet, r, lc)
        assert g is not None, (block, r, lc)
        for j in range(n):
            _emit(block, label, sheet, kind, g, j + 1, None, analyte, r, fc + j)

def tc_block(block, sheet, label_cell, header_row, time_col, group_starts, n, r0, r1, kind='timecourse', analyte=None):
    """groups = merged headers each spanning n columns; rows = timepoints (time in time_col)"""
    tcol = C(time_col)
    label = _wb[sheet][label_cell].value
    lastc = C(group_starts[-1]) + n - 1
    meta[block] = dict(label=label, sheet=sheet, rng=f"{time_col}{header_row}:{L(lastc)}{r1}")
    for gs in group_starts:
        g = _v(sheet, header_row, C(gs))
        assert g is not None, (block, header_row, gs)
        for r in range(r0, r1 + 1):
            t = _v(sheet, r, tcol)
            for j in range(n):
                _emit(block, label, sheet, kind, g, j + 1, t, analyte, r, C(gs) + j)

def surv_block(block, sheet, label_cell, header_row, days_col, first_gcol, ng, r0, r1):
    """one row per animal: days in days_col; a 1/0 flag in exactly one group column"""
    dc, fg = C(days_col), C(first_gcol)
    label = _wb[sheet][label_cell].value
    meta[block] = dict(label=label, sheet=sheet, rng=f"{days_col}{header_row}:{L(fg+ng-1)}{r1}")
    for r in range(r0, r1 + 1):
        d = _v(sheet, r, dc)
        flags = [(j, _v(sheet, r, fg + j)) for j in range(ng) if _v(sheet, r, fg + j) is not None]
        if d is None and not flags:
            continue
        if len(flags) != 1:
            surv_out.append(dict(block=block, label=label, sheet=sheet, group=None, days=d, event=None,
                                 cell_days=_addr(r, dc), cell_flag=None, note=f"row {r}: {len(flags)} flags"))
            continue
        j, e = flags[0]
        g = str(_v(sheet, header_row, fg + j)).strip()
        surv_out.append(dict(block=block, label=label, sheet=sheet, group=g, days=d, event=e,
                             cell_days=_addr(r, dc), cell_flag=_addr(r, fg + j),
                             note='' if d is not None else 'MISSING DAYS'))

# ------------------------------------------------------------------ S01
rows_block('S01-A/16h', 'S01', 'A1', 'A', 'B', 5, 3, 10, analyte='Ifnb1 16h')
rows_block('S01-A/72h', 'S01', 'A1', 'G', 'H', 5, 3, 10, analyte='Ifnb1 72h')
rows_block('S01-B', 'S01', 'A13', 'A', 'B', 5, 14, 17)
rows_block('S01-C', 'S01', 'A19', 'A', 'B', 4, 20, 21)
tc_block('S01-D', 'S01', 'A23', 23, 'A', ['B', 'G', 'L', 'Q'], 5, 24, 28)
tc_block('S01-E', 'S01', 'A29', 29, 'A', ['B', 'G', 'L', 'Q', 'V'], 5, 30, 34)
tc_block('S01-F', 'S01', 'A35', 35, 'A', ['B', 'G', 'L', 'Q', 'V'], 5, 36, 36, kind='scalar')
tc_block('S01-G', 'S01', 'A37', 37, 'A', ['B', 'G', 'L', 'Q', 'V'], 5, 38, 38, kind='scalar')
# ------------------------------------------------------------------ S02
cols_block('S02-A', 'S02', 'A1', 2, 'A', 4, 3, 7)
cols_block('S02-B', 'S02', 'F1', 2, 'F', 4, 3, 7)
cols_block('S02-C', 'S02', 'K1', 2, 'K', 5, 3, 7)
cols_block('S02-D CD40', 'S02', 'A8', 9, 'A', 4, 10, 14)
cols_block('S02-D CD86', 'S02', 'F8', 9, 'F', 4, 10, 14)
cols_block('S02-E', 'S02', 'K8', 9, 'K', 5, 10, 14)
tc_block('S02-F', 'S02', 'A15', 16, 'A', ['B', 'G', 'L'], 5, 17, 19)
cols_block('S02-G', 'S02', 'A20', 21, 'B', 3, 22, 26)
cols_block('S02-H', 'S02', 'A28', 29, 'B', 5, 30, 34)
cols_block('S02-I', 'S02', 'G28', 29, 'H', 2, 30, 34)
# ------------------------------------------------------------------ S03
cols_block('S03-A', 'S03', 'A1', 2, 'A', 5, 3, 7)
cols_block('S03-B', 'S03', 'G1', 2, 'G', 3, 3, 7)
cols_block('S03-C', 'S03', 'K1', 2, 'K', 5, 3, 7)
cols_block('S03-D', 'S03', 'Q1', 2, 'Q', 5, 3, 7)
cols_block('S03-E', 'S03', 'A8', 9, 'A', 5, 10, 14)
cols_block('S03-F', 'S03', 'G8', 9, 'G', 3, 10, 14)
cols_block('S03-G', 'S03', 'K8', 9, 'K', 5, 10, 14)
cols_block('S03-H', 'S03', 'Q8', 9, 'Q', 5, 10, 14)
surv_block('S03-I', 'S03', 'A15', 16, 'A', 'B', 5, 17, 51)
surv_block('S03-J', 'S03', 'G15', 16, 'G', 'H', 3, 17, 51)
cols_block('S03-K', 'S03', 'K15', 16, 'L', 4, 17, 21)
rows_block('S03-L/Aicda', 'S03', 'K25', 'K', 'L', 3, 26, 28, analyte='Aicda')
rows_block('S03-L/E47', 'S03', 'K25', 'K', 'O', 3, 26, 28, analyte='E47')
# ------------------------------------------------------------------ S04
rows_block('S04-A/ICOSlo', 'S04', 'A1', 'A', 'B', 5, 2, 5, analyte='ICOS-CXCR5+PD1+')
rows_block('S04-A/ICOShi', 'S04', 'A1', 'A', 'G', 5, 2, 5, analyte='ICOS+CXCR5+PD1+')
cols_block('S04-B/Foxp3', 'S04', 'A6', 7, 'A', 4, 8, 12)
cols_block('S04-B/Tfh:Tfr', 'S04', 'A13', 14, 'A', 4, 15, 19)
cols_block('S04-C', 'S04', 'A20', 21, 'A', 4, 22, 26)
cols_block('S04-D', 'S04', 'A27', 28, 'A', 4, 29, 31)
# ------------------------------------------------------------------ S05
tc_block('S05-A', 'S05', 'A1', 2, 'A', ['B', 'E', 'H'], 2, 3, 5)
tc_block('S05-B', 'S05', 'A6', 7, 'A', ['B', 'E', 'H'], 2, 8, 10)
cols_block('S05-C', 'S05', 'A11', 12, 'A', 4, 13, 15)
cols_block('S05-D', 'S05', 'A17', 18, 'A', 4, 19, 23)
cols_block('S05-E', 'S05', 'A24', 25, 'A', 4, 26, 30)
cols_block('S05-F', 'S05', 'A31', 32, 'A', 4, 33, 37)
cols_block('S05-G', 'S05', 'A38', 39, 'A', 4, 40, 44)
cols_block('S05-H', 'S05', 'A45', 46, 'A', 4, 47, 51)
cols_block('S05-I', 'S05', 'A52', 53, 'A', 4, 54, 58)
# ------------------------------------------------------------------ S06 (survival)
surv_block('S06-A', 'S06', 'A1', 2, 'A', 'B', 4, 3, 30)
surv_block('S06-B', 'S06', 'G1', 2, 'G', 'H', 4, 3, 30)
surv_block('S06-C', 'S06', 'M1', 2, 'M', 'N', 4, 3, 30)
surv_block('S06-D', 'S06', 'A32', 33, 'A', 'B', 4, 34, 68)
surv_block('S06-E[r34]', 'S06', 'G32', 33, 'G', 'H', 5, 34, 68)
surv_block('S06-F[r34]', 'S06', 'M32', 33, 'M', 'N', 5, 34, 68)
surv_block('S06-G', 'S06', 'A69', 70, 'A', 'B', 5, 71, 105)
surv_block('S06-E[r71]', 'S06', 'G69', 70, 'G', 'H', 4, 71, 105)
surv_block('S06-F[r71]', 'S06', 'M69', 70, 'M', 'N', 4, 71, 105)
# ------------------------------------------------------------------ S07
tc_block('S07-A', 'S07', 'A1', 2, 'A', ['B', 'E'], 3, 3, 7)
cols_block('S07-B/Mono', 'S07', 'A8', 9, 'B', 2, 10, 14, analyte='CD11b+Ly6C+ Monocytes')
cols_block('S07-B/Ly6C+Mac', 'S07', 'A8', 9, 'E', 2, 10, 14, analyte='Ly6C+ Mφ')
# S07-C has two identically-labelled columns; keep positional suffix
meta['S07-C'] = dict(label=_wb['S07']['A15'].value, sheet='S07', rng='B15:C20')
for j, col in enumerate(['B', 'C']):
    g = f"{str(_v('S07', 15, C(col))).strip()} [col {col}]"
    for i, r in enumerate(range(16, 21)):
        _emit('S07-C', _wb['S07']['A15'].value, 'S07', 'scalar', g, i + 1, None, None, r, C(col))
# ------------------------------------------------------------------ S08
tc_block('S08-A', 'S08', 'A1', 2, 'A', ['B', 'E', 'H', 'K'], 3, 3, 7)
tc_block('S08-B', 'S08', 'A9', 10, 'A', ['A', 'D', 'G', 'J', 'M'], 3, 11, 11, kind='scalar')
cols_block('S08-C', 'S08', 'A12', 13, 'A', 4, 14, 18)
tc_block('S08-D', 'S08', 'A19', 20, 'A', ['B', 'G', 'L', 'Q', 'V', 'AA'], 5, 21, 26, kind='weight')
# ------------------------------------------------------------------ S09
tc_block('S09-A[colsA-U]', 'S09', 'A1', 2, 'A', ['B', 'E', 'H', 'K', 'N', 'Q', 'T'], 3, 3, 9)
tc_block('S09-A[colsX-AS]', 'S09', 'X1', 2, 'X', ['Y', 'AB', 'AE', 'AH', 'AK', 'AN', 'AQ'], 3, 3, 9)
surv_block('S09-B', 'S09', 'A10', 11, 'A', 'B', 3, 12, 35)
tc_block('S09-C', 'S09', 'E10', 11, 'F', ['G', 'O', 'W'], 8, 12, 19, kind='weight')
surv_block('S09-D', 'S09', 'A37', 38, 'A', 'B', 3, 39, 62)
tc_block('S09-E', 'S09', 'F37', 38, 'F', ['G', 'O', 'W'], 8, 39, 46, kind='weight')
surv_block('S09-F', 'S09', 'A64', 65, 'A', 'B', 3, 66, 88)
tc_block('S09-G', 'S09', 'F64', 65, 'F', ['G', 'O', 'W'], 8, 66, 73, kind='weight')
# ------------------------------------------------------------------ S10
cols_block('S10-A/Ifnb1', 'S10', 'A1', 2, 'A', 4, 3, 7, analyte='Ifnb1')
cols_block('S10-A/Tnf', 'S10', 'A1', 2, 'F', 4, 3, 7, analyte='Tnf')
cols_block('S10-A/Isg15', 'S10', 'A1', 2, 'K', 4, 3, 7, analyte='Isg15')
# ------------------------------------------------------------------ S11
tc_block('S11-A', 'S11', 'A1', 2, 'A', ['B', 'G', 'L', 'Q'], 5, 3, 7)
tc_block('S11-B', 'S11', 'A8', 9, 'A', ['B', 'G', 'L', 'Q'], 5, 10, 14)
cols_block('S11-C', 'S11', 'A15', 16, 'A', 2, 17, 21)
tc_block('S11-D', 'S11', 'A22', 23, 'A', ['B', 'G', 'L', 'Q'], 5, 24, 28)
cols_block('S11-E', 'S11', 'A29', 30, 'A', 4, 31, 35)
# ------------------------------------------------------------------ S12
cols_block('S12-A', 'S12', 'A1', 2, 'A', 2, 3, 5)
# ------------------------------------------------------------------ S13
cols_block('S13-A', 'S13', 'A1', 2, 'A', 3, 3, 7)
cols_block('S13-B', 'S13', 'E1', 2, 'E', 3, 3, 7)
cols_block('S13-C', 'S13', 'I1', 2, 'I', 3, 3, 7)
cols_block('S13-D', 'S13', 'M1', 2, 'M', 3, 3, 7)
surv_block('S13-E', 'S13', 'R1', 2, 'R', 'S', 4, 3, 30)
tc_block('S13-F', 'S13', 'A31', 32, 'A', ['B', 'I', 'P', 'W', 'AD'], 7, 33, 40, kind='weight')
tc_block('S13-G', 'S13', 'A42', 42, 'A', ['B', 'L', 'V'], 10, 43, 50, kind='weight')
cols_block('S13-H', 'S13', 'A51', 52, 'A', 4, 53, 57)
cols_block('S13-I', 'S13', 'E51', 52, 'F', 5, 53, 57)
cols_block('S13-J', 'S13', 'K51', 52, 'L', 5, 53, 57)
# ------------------------------------------------------------------ S14
cols_block('S14-A H1N1', 'S14', 'A1', 2, 'A', 4, 3, 7)
cols_block('S14-A H3N2', 'S14', 'E1', 2, 'F', 4, 3, 7)
# ------------------------------------------------------------------ S15
for blk, lab, hdr, r0, starts in [
    ('S15-A', 'A1', 2, 3, ['B', 'I', 'P', 'W']),
    ('S15-B', 'A11', 12, 13, ['B', 'I', 'P', 'W']),
    ('S15-C', 'A21', 22, 23, ['B', 'I', 'P', 'W']),
    ('S15-D', 'A31', 32, 33, ['B', 'I', 'P', 'W']),
    ('S15-E', 'A41', 42, 43, ['B', 'I', 'P', 'W', 'AD']),
    ('S15-F', 'A51', 52, 53, ['B', 'I', 'P', 'W', 'AD']),
    ('S15-G', 'A61', 62, 63, ['B', 'I', 'P', 'W', 'AD']),
]:
    tc_block(blk, 'S15', lab, hdr, 'A', starts, 7, r0, r0 + 7, kind='weight')
surv_block('S15-H', 'S15', 'A71', 72, 'A', 'B', 3, 73, 93)
tc_block('S15-I', 'S15', 'G71', 71, 'H', ['I', 'P', 'W'], 7, 72, 79, kind='weight')
tc_block('S15-J', 'S15', 'G81', 82, 'H', ['I', 'P', 'W', 'AD'], 7, 83, 90, kind='weight')
tc_block('S15-K', 'S15', 'G91', 92, 'H', ['I', 'P', 'W', 'AD'], 7, 93, 100, kind='weight')
surv_block('S15-L', 'S15', 'A101', 102, 'A', 'B', 4, 103, 130)
tc_block('S15-M', 'S15', 'G101', 102, 'H', ['I', 'P', 'W', 'AD'], 7, 103, 110, kind='weight')
surv_block('S15-N', 'S15', 'A132', 133, 'A', 'B', 4, 134, 161)
tc_block('S15-O', 'S15', 'G132', 133, 'H', ['I', 'P', 'W', 'AD'], 7, 134, 141, kind='weight')

tidy = pd.DataFrame(rows_out)
surv = pd.DataFrame(surv_out)

def coverage_check():
    """Return every non-empty numeric cell in the workbook that the registry did NOT consume."""
    used = set()
    for _, r in tidy.iterrows():
        used.add((r.sheet, r.cell))
    for _, r in surv.iterrows():
        used.add((r.sheet, r.cell_days))
        if r.cell_flag:
            used.add((r.sheet, r.cell_flag))
    missing = []
    for ws in _wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, (int, float)) and (ws.title, c.coordinate) not in used:
                    missing.append((ws.title, c.coordinate, c.value))
    return missing

if __name__ == '__main__':
    print(tidy.shape, surv.shape)
    miss = coverage_check()
    print("numeric cells not consumed by registry:", len(miss))
    for m in miss:
        print("  ", m)
    tidy.to_csv('/tmp/outputs/analysis/tidy_values.csv', index=False)
    surv.to_csv('/tmp/outputs/analysis/tidy_survival.csv', index=False)

"""
Descriptive reduction of every non-survival block, with provenance.
 - arithmetic mean, SD, SEM, median, min, max, n for every (block, group, time/analyte)
 - for titre blocks: geometric mean titre (GMT) with t-based 95% CI on log10 scale.
   HAI zeros (S03-C, S03-G; lowest dilution tested 1:10) are set to 5 (=LOD/2) for GMT only.
 - S09-A is stored as log10 fold-change; back-transformed geometric-mean fold = 10**mean(log10).
"""
import pandas as pd, numpy as np
from scipy import stats

T = pd.read_csv('tidy_values.csv')
T['time'] = T.time.astype(object).where(T.time.notna(), None)
TITRE_BLOCKS = ['S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-A', 'S13-B', 'S13-C', 'S13-D', 'S13-I', 'S13-J']
LOG10_BLOCKS = ['S09-A[colsA-U]', 'S09-A[colsX-AS]']
LOD_HALF = {'S03-C': 5.0, 'S03-G': 5.0}

def rng(g):
    return f"{g.sheet.iloc[0]}!{g.cell.iloc[0]}:{g.cell.iloc[-1]}"

rows = []
for (blk, grp, tm, an), g in T.groupby(['block', 'group', T.time.astype(str), T.analyte.astype(str)], sort=False):
    v = g.value.astype(float).values
    d = dict(block=blk, group=grp, time=None if tm in ('None', 'nan') else tm, analyte=None if an in ('None', 'nan') else an,
             n=len(v), mean=np.mean(v), sd=np.std(v, ddof=1) if len(v) > 1 else np.nan,
             sem=stats.sem(v) if len(v) > 1 else np.nan, median=np.median(v), min=np.min(v), max=np.max(v), cells=rng(g))
    if blk in TITRE_BLOCKS:
        vv = v.copy()
        nzero = int((vv <= 0).sum())
        if nzero:
            vv[vv <= 0] = LOD_HALF[blk]
        lg = np.log10(vv)
        m, s = lg.mean(), lg.std(ddof=1)
        h = stats.t.ppf(0.975, len(lg) - 1) * s / np.sqrt(len(lg))
        d.update(gmt=10 ** m, gmt_lo=10 ** (m - h), gmt_hi=10 ** (m + h), n_below_lod=nzero)
    if blk in LOG10_BLOCKS:
        m, s = v.mean(), v.std(ddof=1)
        h = stats.t.ppf(0.975, len(v) - 1) * s / np.sqrt(len(v))
        d.update(gmt=10 ** m, gmt_lo=10 ** (m - h), gmt_hi=10 ** (m + h))
    rows.append(d)
SUM = pd.DataFrame(rows)
SUM.to_csv('summary_all_blocks.csv', index=False)

if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 2000); pd.set_option('display.max_colwidth', 40)
    pd.set_option('display.float_format', lambda x: f"{x:.4g}")
    X = SUM[~SUM.block.str.startswith(('S15-', 'S13-F', 'S13-G', 'S09-C', 'S09-E', 'S09-G'))]
    print(X.to_string())

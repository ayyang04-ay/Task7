"""
Safety / tolerability read-outs.
S08-D : body weight (% of own day-0) after intranasal immunisation (CA09 vaccine + 20 ug adjuvant), days 0-10, n=5.
        Reduction: per-animal nadir (min over days 2-10) and per-animal mean deficit AUC (trapezoid of 100-weight, days 0-10, floored at 0);
        group mean +/- SD; Welch t-test vs 'Vaccine' (vaccine alone) and vs PSLN-212; day-by-day group means.
S09-A : lung cytokine transcripts, stored as log10 fold; reduction = mean of log10 (i.e. geometric-mean fold), Welch t on log10 values.
S10-A : CNS transcripts (linear fold), n=5; mean +/- SD (the annotation says this block is reported as mean with SD);
        one-way ANOVA + Tukey HSD; PSLN-344 vs Sham difference with 95% CI.
"""
import pandas as pd, numpy as np
from scipy import stats
T = pd.read_csv('tidy_values.csv')
out = {}

# ---------------- S08-D
D = T[T.block == 'S08-D'].copy(); D['day'] = D.time.astype(float)
wide = D.pivot_table(index=['group', 'unit_idx'], columns='day', values='value')
daymeans = D.groupby(['group', 'day']).value.agg(['mean', 'std', 'count']).unstack('day')
per = []
for (g, u), r in wide.iterrows():
    v = r.dropna()
    days = v.index.values; vals = v.values
    deficit = np.clip(100 - vals, 0, None)
    auc = np.trapezoid(deficit, days) if hasattr(np, 'trapezoid') else np.trapz(deficit, days)
    per.append(dict(group=g, unit=u, nadir=vals[1:].min(), nadir_day=days[1:][vals[1:].argmin()], last_day=days[-1], last_value=vals[-1], deficit_auc=auc,
                    n_days=len(days)))
per = pd.DataFrame(per)
s8 = per.groupby('group').agg(n=('nadir', 'size'), nadir_mean=('nadir', 'mean'), nadir_sd=('nadir', 'std'), nadir_min=('nadir', 'min'),
                               auc_mean=('deficit_auc', 'mean'), auc_sd=('deficit_auc', 'std'), last_mean=('last_value', 'mean'), last_min=('last_value', 'min'))
tests = []
for ref in ['Vaccine', 'PSLN-212', 'PSLN-212(Y)']:
    for g in per.group.unique():
        if g == ref: continue
        for metric in ['nadir', 'deficit_auc']:
            a = per[per.group == g][metric]; b = per[per.group == ref][metric]
            t, p = stats.ttest_ind(a, b, equal_var=False)
            tests.append(dict(metric=metric, group=g, ref=ref, diff=a.mean() - b.mean(), p_welch=p))
tests = pd.DataFrame(tests)
per.to_csv('safety_S08D_per_animal.csv', index=False); s8.to_csv('safety_S08D_summary.csv'); tests.to_csv('safety_S08D_tests.csv', index=False)

# ---------------- S09-A
C = T[T.block.isin(['S09-A[colsA-U]', 'S09-A[colsX-AS]'])].copy()
cy = C.groupby(['block', 'time', 'group'], sort=False).value.agg(['mean', 'std', 'count']).reset_index()
cy['gm_fold'] = 10 ** cy['mean']
cyt = []
for (blk, an), g in C.groupby(['block', 'time'], sort=False):
    for a, b in [('PSLN-344', 'PBS'), ('PSLN-344', 'PSLN-212'), ('PSLN-344', 'PSLN-212(y)'), ('PSLN-212', 'PBS'), ('PSLN-212(y)', 'PBS'), ('PSLN-212/R848', 'PSLN-344')]:
        x = g[g.group == a].value; y = g[g.group == b].value
        t, p = stats.ttest_ind(x, y, equal_var=False)
        cyt.append(dict(block=blk, analyte=an, a=a, b=b, log10_diff=x.mean() - y.mean(), fold_ratio=10 ** (x.mean() - y.mean()), p_welch=p))
cyt = pd.DataFrame(cyt)
cy.to_csv('safety_S09A_summary.csv', index=False); cyt.to_csv('safety_S09A_tests.csv', index=False)

# ---------------- S10-A
N = T[T.block.str.startswith('S10-A')].copy()
cns = N.groupby(['analyte', 'group'], sort=False).value.agg(['mean', 'std', 'count']).reset_index()
cns_t = []
for an, g in N.groupby('analyte', sort=False):
    groups = [g[g.group == k].value.values for k in ['PBS', 'Sham', 'PSLN-344', 'CT']]
    F, pA = stats.f_oneway(*groups)
    tk = stats.tukey_hsd(*groups)
    names = ['PBS', 'Sham', 'PSLN-344', 'CT']
    for i, j in [(2, 0), (2, 1), (3, 0), (3, 2), (1, 0)]:
        ci = tk.confidence_interval()
        x, y = groups[i], groups[j]
        tw, pw = stats.ttest_ind(x, y, equal_var=False)
        cns_t.append(dict(analyte=an, a=names[i], b=names[j], diff=x.mean() - y.mean(), ratio=x.mean() / y.mean(), tukey_p=tk.pvalue[i, j],
                          tukey_lo=ci.low[i, j], tukey_hi=ci.high[i, j], welch_p=pw, anova_p=pA))
cns_t = pd.DataFrame(cns_t)
cns.to_csv('safety_S10A_summary.csv', index=False); cns_t.to_csv('safety_S10A_tests.csv', index=False)

if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 400); pd.set_option('display.float_format', lambda x: f"{x:.3g}")
    print("S08-D day means"); print(daymeans['mean'].round(2).to_string()); print(daymeans['count'].to_string())
    print(); print(s8.round(2).to_string()); print(); print(tests.to_string())
    print(); print("S09-A"); 
    piv = cy.pivot_table(index=['block', 'time'], columns='group', values='gm_fold', sort=False)
    print(piv.round(1).to_string())
    print(cyt[cyt.a.eq('PSLN-344')].to_string())
    print(); print("S10-A"); print(cns.to_string()); print(cns_t.to_string())

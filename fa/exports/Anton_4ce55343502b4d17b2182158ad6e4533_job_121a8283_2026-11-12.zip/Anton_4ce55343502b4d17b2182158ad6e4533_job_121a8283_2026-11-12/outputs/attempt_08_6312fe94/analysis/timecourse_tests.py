"""
Time-course blocks: two-way ANOVA (group x time; stated method) and per-timepoint Welch contrasts for the decision-relevant pairs.
Blocks: S01-D (lung monocytes), S01-E (CD11b+ DC), S02-F (Gm-csf), S07-A (Ly6C+CCR2+ macrophages), S11-A, S11-D, S05-A, S05-B.
"""
import pandas as pd, numpy as np
from scipy import stats
import statsmodels.formula.api as smf, statsmodels.api as sm
T = pd.read_csv('tidy_values.csv')
rows, an = [], []
for blk in ['S01-D', 'S01-E', 'S02-F', 'S07-A', 'S11-A', 'S11-B', 'S11-D', 'S05-A', 'S05-B']:
    g = T[T.block == blk].copy(); g['t'] = g.time.astype(str); g['grp'] = g.group
    m = smf.ols('value ~ C(grp) * C(t)', data=g).fit()
    a = sm.stats.anova_lm(m, typ=2)
    an.append(dict(block=blk, p_group=a.loc['C(grp)', 'PR(>F)'], p_time=a.loc['C(t)', 'PR(>F)'], p_interaction=a.loc['C(grp):C(t)', 'PR(>F)']))
    groups = list(g.group.unique())
    pairs = [(a_, b_) for a_ in groups for b_ in groups if a_ < b_]
    for t in g.t.unique():
        for a_, b_ in pairs:
            x = g[(g.t == t) & (g.group == a_)].value; y = g[(g.t == t) & (g.group == b_)].value
            if len(x) > 1 and len(y) > 1:
                tt, p = stats.ttest_ind(x, y, equal_var=False)
                rows.append(dict(block=blk, time=t, a=a_, b=b_, mean_a=x.mean(), mean_b=y.mean(), n_a=len(x), n_b=len(y), welch_p=p))
A = pd.DataFrame(an); R = pd.DataFrame(rows)
A.to_csv('tests_timecourse_anova.csv', index=False); R.to_csv('tests_timecourse_pairwise.csv', index=False)
if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 1000); pd.set_option('display.float_format', lambda x: f"{x:.3g}")
    print(A.to_string())
    k = R[((R.a == 'PSLN-212') & (R.b == 'PSLN-344')) | ((R.a == 'PSLN-212(Y)') & (R.b == 'PSLN-344')) | ((R.a == 'PSLN-344') & (R.b.isin(['Sham', 'Vaccine']))) | (R.a=='PSLN-212Y')&(R.b=='PSLN-344')]
    print(k.to_string())

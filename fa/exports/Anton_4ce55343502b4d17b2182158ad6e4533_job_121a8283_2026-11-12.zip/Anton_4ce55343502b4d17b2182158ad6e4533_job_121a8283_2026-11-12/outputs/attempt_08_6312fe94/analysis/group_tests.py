"""
Group comparisons for every scalar block (one value per animal per group).
 - Stated method reproduced: one-way ANOVA + Tukey HSD (>=3 groups) or Student's t (2 groups).
 - Titre blocks (reciprocal dilutions) are analysed on log10 scale (HAI zeros -> 5 = half the lowest dilution tested).
 - In addition, Welch's t-test (unequal variance) for the three contrasts that carry the decision:
      PSLN-344 vs PSLN-212 (aged; isolates Mn2+), PSLN-344 vs Sham (aged), PSLN-344 (aged) vs PSLN-212(Y) (young benchmark).
 - 'Restoration index' = PSLN-344 aged as % of the PSLN-212(Y) benchmark: ratio of arithmetic means (or of GMTs for titres)
      with 95% CI from a t-interval on the difference of log-values (per-animal logs; Welch df).
"""
import pandas as pd, numpy as np, itertools
from scipy import stats
T = pd.read_csv('tidy_values.csv')
T = T[T.kind == 'scalar'].copy()
TITRE = ['S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-A', 'S13-B', 'S13-C', 'S13-D', 'S13-I', 'S13-J']
def vals(g, blk):
    v = g.value.astype(float).values.copy()
    if blk in TITRE:
        v[v <= 0] = 5.0
        return np.log10(v)
    return v
def welch_ci_logratio(a, b):
    la, lb = np.log(a), np.log(b)
    d = la.mean() - lb.mean()
    va, vb = la.var(ddof=1) / len(la), lb.var(ddof=1) / len(lb)
    se = np.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(la) - 1) + vb ** 2 / (len(lb) - 1))
    h = stats.t.ppf(0.975, df) * se
    return np.exp(d), np.exp(d - h), np.exp(d + h)
anova_rows, pair_rows = [], []
for blk, g in T.groupby('block', sort=False):
    groups = list(g.group.unique())
    data = {k: vals(g[g.group == k], blk) for k in groups}
    scale = 'log10' if blk in TITRE else 'linear'
    if len(groups) >= 3:
        F, p = stats.f_oneway(*data.values())
        tk = stats.tukey_hsd(*data.values())
        anova_rows.append(dict(block=blk, scale=scale, k=len(groups), F=F, anova_p=p))
        for (i, a), (j, b) in itertools.combinations(enumerate(groups), 2):
            tw, pw = stats.ttest_ind(data[a], data[b], equal_var=False)
            pair_rows.append(dict(block=blk, scale=scale, a=a, b=b, n_a=len(data[a]), n_b=len(data[b]), mean_a=data[a].mean(), mean_b=data[b].mean(),
                                  tukey_p=tk.pvalue[i, j], welch_p=pw))
    elif len(groups) == 2:
        a, b = groups
        ts, ps = stats.ttest_ind(data[a], data[b], equal_var=True)
        tw, pw = stats.ttest_ind(data[a], data[b], equal_var=False)
        pair_rows.append(dict(block=blk, scale=scale, a=a, b=b, n_a=len(data[a]), n_b=len(data[b]), mean_a=data[a].mean(), mean_b=data[b].mean(),
                              student_p=ps, welch_p=pw))
A = pd.DataFrame(anova_rows); P = pd.DataFrame(pair_rows)
A.to_csv('tests_anova.csv', index=False); P.to_csv('tests_pairwise.csv', index=False)

# ---- restoration index and Mn effect
ri = []
for blk, g in T.groupby('block', sort=False):
    gs = set(g.group.unique())
    raw = {k: g[g.group == k].value.astype(float).values.copy() for k in gs}
    for k in raw:
        if blk in TITRE: raw[k][raw[k] <= 0] = 5.0
    def ratio(a, b):
        if blk in TITRE:
            r, lo, hi = welch_ci_logratio(raw[a], raw[b]); return r, lo, hi, 'GMT ratio'
        if (raw[a] <= 0).any() or (raw[b] <= 0).any():
            return raw[a].mean() / raw[b].mean(), np.nan, np.nan, 'ratio of means'
        # ratio of arithmetic means; CI via log-scale Welch (approximation; geometric-mean ratio CI)
        _, lo, hi = welch_ci_logratio(raw[a], raw[b]); r = raw[a].mean() / raw[b].mean()
        g_r = np.exp(np.log(raw[a]).mean() - np.log(raw[b]).mean())
        return r, lo * r / g_r, hi * r / g_r, 'ratio of means (CI from log-scale Welch, rescaled)'
    d = dict(block=blk)
    if {'PSLN-344', 'PSLN-212(Y)'} <= gs:
        r, lo, hi, how = ratio('PSLN-344', 'PSLN-212(Y)'); d.update(restoration_pct=100 * r, rest_lo=100 * lo, rest_hi=100 * hi)
    if {'PSLN-212', 'PSLN-212(Y)'} <= gs:
        r, lo, hi, how = ratio('PSLN-212', 'PSLN-212(Y)'); d.update(psln212_pct_of_young=100 * r)
    if {'PSLN-344', 'PSLN-212'} <= gs:
        r, lo, hi, how = ratio('PSLN-344', 'PSLN-212'); d.update(mn_fold=r, mn_lo=lo, mn_hi=hi)
    if len(d) > 1:
        ri.append(d)
R = pd.DataFrame(ri)
R.to_csv('restoration_index.csv', index=False)

if __name__ == '__main__':
    pd.set_option('display.width', 300); pd.set_option('display.max_rows', 1000); pd.set_option('display.float_format', lambda x: f"{x:.3g}")
    print(A.to_string()); print()
    key = P[((P.a == 'PSLN-212') & (P.b == 'PSLN-344')) | ((P.a == 'Sham') & (P.b == 'PSLN-344')) | ((P.a == 'PSLN-344') & (P.b == 'PSLN-212(Y)')) | ((P.a == 'Sham') & (P.b == 'PSLN-212')) | ((P.a=='PSLN-212')&(P.b=='PSLN-212(Y)'))]
    print(key.to_string()); print()
    print(P[~P.index.isin(key.index)].to_string()); print()
    print(R.to_string())

import re, pandas as pd, numpy as np
import blocks as B
t=B.tidy; s=B.surv
pd.set_option('display.width',250); pd.set_option('display.max_rows',600); pd.set_option('display.max_colwidth',70)
def stated(label):
    m=re.search(r'n\s*=\s*(\d+)', label or '')
    return int(m.group(1)) if m else None
rows=[]
for blk,g in t.groupby('block',sort=False):
    lab=g.label.iloc[0]; st=stated(lab)
    if g.kind.iloc[0] in('timecourse','weight') and g.time.notna().any():
        cnt=g.groupby(['group','time'],sort=False).value.count().unstack('time').fillna(0).astype(int)
        for grp,r in cnt.iterrows():
            rows.append(dict(block=blk,label=lab,stated_n=st,group=grp,obs=" ".join(str(int(x)) for x in r.values), mn=int(r.min()), mx=int(r.max())))
    else:
        cnt=g.groupby('group',sort=False).value.count()
        for grp,n in cnt.items():
            rows.append(dict(block=blk,label=lab,stated_n=st,group=grp,obs=str(n),mn=n,mx=n))
for blk,g in s.groupby('block',sort=False):
    lab=g.label.iloc[0]; st=stated(lab)
    for grp,gg in g.groupby('group',sort=False):
        rows.append(dict(block=blk,label=lab,stated_n=st,group=grp,obs=f"{len(gg)} rows; {int(gg.event.sum())} events; {int(gg.days.isna().sum())} missing-days",mn=len(gg),mx=len(gg)))
df=pd.DataFrame(rows)
df['flag']=np.where((df.stated_n!=df['mx']),'STATED!=OBS','')
df.to_csv('n_audit.csv',index=False)
if __name__=='__main__':
    print(df.to_string())

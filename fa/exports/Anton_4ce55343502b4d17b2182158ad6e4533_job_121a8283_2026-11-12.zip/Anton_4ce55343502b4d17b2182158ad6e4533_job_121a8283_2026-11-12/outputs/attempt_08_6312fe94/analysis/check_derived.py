"""
Internal-consistency checks of derived / cross-referenced blocks.
 (1) S03-B and S03-F (IgG2a/IgG1 quotients) vs per-animal quotients recomputed from S13-A/S13-B (CA09) and S13-C/S13-D (Aichi).
 (2) S04-B Tfh:Tfr vs S04-B Foxp3+ (is ratio = (100-Foxp3)/Foxp3 ?) and vs S04-A Tfh percentages.
 (3) S09-A (log10) vs S01-A (linear) Ifnb1 group means -> identifies the time-point of the second, identically-labelled S09-A panel.
"""
import pandas as pd, numpy as np, itertools
T = pd.read_csv('tidy_values.csv')
def col(block, group):
    g = T[(T.block == block) & (T.group == group)].sort_values('unit_idx'); return g.value.values.astype(float)
out = []
print("=== (1) IgG2a/IgG1 quotients")
for lab, q, num, den in [('CA09 H1N1', 'S03-B', 'S13-A', 'S13-B'), ('Aichi H3N2', 'S03-F', 'S13-C', 'S13-D')]:
    groups = ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
    rec = {g: col(num, g) / col(den, g) for g in groups}
    printed = {g: col(q, g) for g in groups}
    print(f"-- {lab}: {q} (as printed) vs {num}/{den} (recomputed, per animal in row order)")
    for g in groups:
        print(f"   recomputed {g:12s}: {np.round(rec[g], 4)}  mean={rec[g].mean():.3f}  GM={np.exp(np.log(rec[g]).mean()):.3f}")
    for g in groups:
        match = [h for h in groups if np.allclose(printed[g], rec[h], rtol=2e-3)]
        print(f"   printed    {g:12s}: {np.round(printed[g], 4)}  mean={printed[g].mean():.3f}  == recomputed column of: {match}")
        out.append(dict(check='IgG2a/IgG1', antigen=lab, printed_block=q, printed_header=g, matches_recomputed_group=";".join(match),
                        printed_mean=printed[g].mean()))
    for g in groups:
        out.append(dict(check='IgG2a/IgG1 recomputed', antigen=lab, printed_block=f"{num}/{den}", printed_header=g, matches_recomputed_group='',
                        printed_mean=rec[g].mean()))
print()
print("=== (2) Tfh:Tfr")
for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
    fox = col('S04-B/Foxp3', g); rat = col('S04-B/Tfh:Tfr', g)
    pred = (100 - fox) / fox
    hi = col('S04-A/ICOShi', g); lo = col('S04-A/ICOSlo', g)
    print(f"   {g:12s} printed ratio {np.round(rat,3)} ; (100-Foxp3)/Foxp3 {np.round(pred,3)} ; sorted-equal={np.allclose(sorted(rat), sorted(pred), rtol=1e-4)} row-equal={np.allclose(rat, pred, rtol=1e-4)}"
          f" ; ICOShi+ICOSlo sum {np.round(hi+lo,2)}")
print()
print("=== (3) S09-A vs S01-A Ifnb1")
m = {'PBS': 'Sham', 'PSLN-212(y)': 'PSLN-212(Y)'}
for panel in ['S09-A[colsA-U]', 'S09-A[colsX-AS]']:
    g9 = T[(T.block == panel) & (T.time == 'Ifnb1')].groupby('group', sort=False).value.mean()
    row = []
    for grp, lg in g9.items():
        g1 = m.get(grp, grp)
        a16 = T[(T.block == 'S01-A/16h') & (T.group == g1)].value
        a72 = T[(T.block == 'S01-A/72h') & (T.group == g1)].value
        row.append(dict(panel=panel, group=grp, S09A_gm_fold=10 ** lg, S01A_16h_mean=a16.mean(), S01A_16h_gm=np.exp(np.log(a16).mean()),
                        S01A_72h_mean=a72.mean(), S01A_72h_gm=np.exp(np.log(a72).mean())))
    d = pd.DataFrame(row)
    r16 = np.corrcoef(np.log(d.S09A_gm_fold), np.log(d.S01A_16h_gm))[0, 1]; r72 = np.corrcoef(np.log(d.S09A_gm_fold), np.log(d.S01A_72h_gm))[0, 1]
    rms16 = np.sqrt(np.mean((np.log10(d.S09A_gm_fold) - np.log10(d.S01A_16h_gm)) ** 2)); rms72 = np.sqrt(np.mean((np.log10(d.S09A_gm_fold) - np.log10(d.S01A_72h_gm)) ** 2))
    print(d.round(2).to_string()); print(f"   log-scale RMS difference vs S01-A 16h: {rms16:.3f} ; vs S01-A 72h: {rms72:.3f}   (r = {r16:.3f} / {r72:.3f})"); print()
    d.to_csv(f"check_S09A_vs_S01A_{'left' if 'A-U' in panel else 'right'}.csv", index=False)
pd.DataFrame(out).to_csv('check_IgG_subclass_quotients.csv', index=False)

import pandas as pd, numpy as np
from figstyle import *
from matplotlib.lines import Line2D
R = pd.read_csv('restoration_index.csv').set_index('block')
items = [
 ('Innate and antigen presentation', None),
 ('Ifnb1 mRNA, lung, 16 h', 'S01-A/16h'), ('cDC1, lung, 72 h', 'S01-F'), ('Migratory CD11b+ DC, lung, 72 h', 'S02-A'), ('CD11b+ DC, lymph node, 72 h', 'S02-B'),
 ('Antigen-bearing DC, lymph node, 36 h', 'S02-C'), ('CD8 priming by lymph-node DC (OT-I)', 'S02-E'), ('CD40+ lymph-node DC, day 3', 'S02-D CD40'), ('CD86+ lymph-node DC, day 3', 'S02-D CD86'),
 ('B cells and antibody', None),
 ('Germinal-centre B cells, day 7', 'S03-K'), ('ICOS+ Tfh, day 7', 'S04-A/ICOShi'), ('Serum IgG, CA09, day 14', 'S03-A'), ('HAI, CA09, day 14', 'S03-C'),
 ('Neutralising titre, CA09, day 14', 'S03-D'), ('Serum IgG, Aichi, day 14', 'S03-E'), ('HAI, Aichi, day 14', 'S03-G'), ('Neutralising titre, Aichi, day 14', 'S03-H'),
 ('Serum IgG, CA09, day 28 after boost', 'S13-I'), ('Serum IgG, Aichi, day 28 after boost', 'S13-J'),
 ('CD8 T cells', None),
 ('Ki-67+ CD8, lung, day 3', 'S05-D'), ('GZMB+ CD8, lung, day 3', 'S05-E'), ('IFN-γ+ CD8 to rgH5N1, day 14', 'S05-F'), ('IFN-γ+ CD8 to rgH5N1, day 60', 'S05-G'),
 ('GZMB+ CD8, lymph node, day 60', 'S05-H'), ('Resident-memory CD8, lung, day 25', 'S05-I'),
]
fig, ax = plt.subplots(figsize=(7.6, 6.9))
y = 0; yt = []; yl = []
for lab, blk in items:
    if blk is None:
        y -= 0.4; ax.text(-0.62, y, lab, fontweight='bold', fontsize=9, va='center', transform=ax.get_yaxis_transform()); y -= 0.9; continue
    r = R.loc[blk]
    ax.plot([r.psln212_pct_of_young, r.restoration_pct], [y, y], color='#c8c8c8', lw=2, zorder=1, solid_capstyle='round')
    ax.plot([r.rest_lo, r.rest_hi], [y, y], color=COL['PSLN-344'], lw=1, alpha=0.55, zorder=2)
    ax.scatter(r.psln212_pct_of_young, y, s=38, color=COL['PSLN-212'], zorder=3, edgecolor='white', linewidth=0.5)
    ax.scatter(r.restoration_pct, y, s=52, color=COL['PSLN-344'], zorder=4, edgecolor='white', linewidth=0.5)
    ax.text(330, y, f"{r.restoration_pct:.0f}%", color=COL['PSLN-344'], fontsize=8, va='center', ha='right', fontweight='bold')
    yt.append(y); yl.append(f"{lab}  [{blk.replace('/16h','').replace(' CD40','').replace(' CD86','').replace('/ICOShi','')}]"); y -= 1
ax.set_xscale('log'); ax.set_xlim(1.5, 340); ax.set_xticks([2, 5, 10, 25, 50, 100, 200]); ax.set_xticklabels(['2', '5', '10', '25', '50', '100', '200'])
ax.axvline(100, color=COL['PSLN-212(Y)'], lw=1.6, zorder=0); ax.text(100, 0.9, 'young + PSLN-212\n= 100%', color=COL['PSLN-212(Y)'], ha='center', va='bottom', fontsize=8)
ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8); ax.set_ylim(y + 0.4, 0.8)
ax.set_xlabel('Aged-mouse response as % of the young PSLN-212 benchmark (log scale)')
ax.minorticks_off()
h = [Line2D([], [], marker='o', ls='', ms=7, color=COL['PSLN-344'], label='PSLN-344 (Mn), aged — with 95% CI'),
     Line2D([], [], marker='o', ls='', ms=6, color=COL['PSLN-212'], label='PSLN-212 (no Mn), aged')]
ax.legend(handles=h, loc='upper left', bbox_to_anchor=(-0.62, -0.07), ncol=2, fontsize=8)
ax.text(-0.62, 1.075, 'Mn brings most aged responses to 60–100% of young; dendritic-cell co-stimulation\nand boosted IgG stay well short', transform=ax.transAxes, fontsize=10.5, fontweight='bold', va='bottom')
ax.text(-0.62, -0.125, 'Ratio of group means (geometric means for titres), n = 5 per group; CI from Welch t-interval on log values. Source blocks in brackets.\n'
        'Read-outs come from different animal cohorts; they are not paired with each other or with challenge outcome.', transform=ax.transAxes, fontsize=7.2, color='#444444', va='top')
fig.savefig('/tmp/outputs/figures/fig3_restoration_index.png'); print('ok')

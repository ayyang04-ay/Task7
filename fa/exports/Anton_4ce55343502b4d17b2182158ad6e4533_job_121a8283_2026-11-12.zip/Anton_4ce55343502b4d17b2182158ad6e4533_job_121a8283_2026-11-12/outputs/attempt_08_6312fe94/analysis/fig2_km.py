import pandas as pd, numpy as np
from figstyle import *
from lifelines import KaplanMeierFitter
S = pd.read_csv('tidy_survival.csv'); S = S[S.days.notna()]
AGED8 = ['S03-I', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E[r34]', 'S06-F[r34]', 'S06-G']
D14 = ['S03-I', 'S06-A', 'S06-C']; D3 = ['S06-B', 'S06-D']; D60 = ['S06-E[r34]', 'S06-F[r34]', 'S06-G']
fig, axes = plt.subplots(1, 2, figsize=(10.2, 3.7), sharey=True)
def km(ax, d, color, label, ls='-', lw=2.0, xoff=0.25, yoff=0, end_label=True):
    k = KaplanMeierFitter().fit(d.days, d.event)
    sf = k.survival_function_.reset_index(); sf.columns = ['t', 's']
    t = list(sf.t) + [14]; s = list(sf.s) + [sf.s.iloc[-1]]
    ax.step(t, np.array(s) * 100, where='post', color=color, lw=lw, ls=ls)
    if end_label:
        ax.text(14 + xoff, s[-1] * 100 + yoff, label, color=color, va='center', fontsize=8)
ax = axes[0]
for g, lab, yo in [('PSLN-212(Y)', 'PSLN-212, young  56/56', 3.5), ('PSLN-344', 'PSLN-344, aged  46/56', 0), ('PSLN-212', 'PSLN-212, aged  6/56', 2.5), ('Sham', 'Sham, aged  0/56', -3)]:
    km(ax, S[S.block.isin(AGED8) & (S.group == g)], COL[g], lab, yoff=yo)
ax.set_title('A  Eight aged-BALB/c experiments, pooled', loc='left')
ax.set_ylabel('Surviving (%)'); ax.set_xlabel('Days after challenge')
ax = axes[1]
km(ax, S[S.block.isin(D14) & (S.group == 'PSLN-344')], COL['PSLN-344'], 'day 14  20/21', yoff=2.5)
km(ax, S[S.block.isin(D3) & (S.group == 'PSLN-344')], COL['PSLN-344'], 'day 3  12/14', ls='--', yoff=0.5)
km(ax, S[S.block.isin(D60) & (S.group == 'PSLN-344')], COL['PSLN-344'], 'day 60  14/21', ls=':', lw=2.4, yoff=-1)
km(ax, S[S.block.isin(D60) & (S.group == 'Untreated')], 'black', 'untreated, unchallenged\n(day-60 cohorts)  17/21', lw=1.3, yoff=-4)
km(ax, S[S.block.isin(D60) & (S.group == 'PSLN-212')], COL['PSLN-212'], 'PSLN-212, day 60  1/21', ls=':', lw=1.6, yoff=3)
ax.set_title('B  PSLN-344 (aged), by dose-to-challenge interval', loc='left'); ax.set_xlabel('Days after challenge')
for ax in axes:
    ax.set_xlim(0, 14); ax.set_ylim(-3, 104); ax.set_xticks(range(0, 15, 2)); ax.set_yticks([0, 25, 50, 75, 100])
    ax.spines['bottom'].set_bounds(0, 14)
fig.subplots_adjust(wspace=0.85, right=0.80)
fig.text(0.075, -0.06, 'Kaplan–Meier estimates from the time-to-event blocks exactly as recorded (S03-I, S06-A…G; n = 7 per arm per experiment). Pooling is descriptive; tests are stratified by experiment.\n'
         'Panel A: PSLN-344 vs PSLN-212 stratified log-rank p = 4×10⁻¹⁶.  Panel B: day 14 vs day 60, Fisher exact p = 0.045; day 60 vs untreated, p = 0.48.', fontsize=7.2, color='#444444', va='top')
fig.savefig('/tmp/outputs/figures/fig2_km_pooled.png'); print('ok')

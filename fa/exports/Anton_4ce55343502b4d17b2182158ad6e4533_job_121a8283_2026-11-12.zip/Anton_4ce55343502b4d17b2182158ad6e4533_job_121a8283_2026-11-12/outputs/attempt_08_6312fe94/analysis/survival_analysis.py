"""
Survival analysis of every time-to-event block.
Input : tidy_survival.csv (one row per animal; produced by blocks.py with cell provenance)
Method: Kaplan-Meier; two-sided log-rank (stated method); two-sided Fisher exact on end-of-observation survival;
        Clopper-Pearson 95% CI on survival proportion; median survival (days; 'NR' = not reached).
The S03-J PSLN-344 record with a status flag but no elapsed-days value (S03!J46) is EXCLUDED from the primary
analysis and handled in sensitivity analyses.
"""
import pandas as pd, numpy as np, itertools
from lifelines import KaplanMeierFitter
from lifelines.statistics import logrank_test
from scipy.stats import fisher_exact, beta

S = pd.read_csv('tidy_survival.csv')
S['missing_days'] = S.days.isna()

META = {  # block: (population, vaccine, challenge, interval vaccination->challenge, class)
 'S03-I':      ('aged BALB/c',            'bivalent CA09 H1N1 + Aichi H3N2', '10x mLD50 CA09 H1N1', 'd14', 'homologous'),
 'S03-J':      ('BALB/c (age not stated in block)', 'rgH5N1', 'wild-type VN04 H5N1 (dose not stated)', 'd2', 'matched H5N1, early'),
 'S06-A':      ('aged BALB/c',            'Aichi H3N2',  '5x mLD50 PR8 H1N1',  'd14', 'heterosubtypic'),
 'S06-B':      ('aged BALB/c',            'Aichi H3N2',  '5x mLD50 PR8 H1N1',  'd3',  'heterosubtypic, early'),
 'S06-C':      ('aged BALB/c',            'bivalent',    '5x mLD50 rgH5N1',    'd14', 'heterosubtypic'),
 'S06-D':      ('aged BALB/c',            'bivalent',    '5x mLD50 rgH5N1',    'd3',  'heterosubtypic, early'),
 'S06-E[r34]': ('aged BALB/c',            'Aichi H3N2',  '5x mLD50 PR8 H1N1',  'd60', 'heterosubtypic, late'),
 'S06-F[r34]': ('aged BALB/c',            'bivalent',    '5x mLD50 rgH5N1',    'd60', 'heterosubtypic, late'),
 'S06-G':      ('aged BALB/c',            'CA09 H1N1',   '5x mLD50 Perth H3N2','d60', 'heterosubtypic, late'),
 'S06-E[r71]': ('BALB/c 10 mo at priming (+4 mo)', 'bivalent', '5x LD50 PR8 H1N1', 'not stated', 'imprinting model'),
 'S06-F[r71]': ('BALB/c 10 mo at priming (+4 mo)', 'bivalent', '5x LD50 Perth H3N2', 'd14', 'imprinting model'),
 'S15-H':      ('aged BALB/c',            'bivalent / none', '5x mLD50 VN04 rgH5N1', 'd3', 'component dissection'),
 'S15-L':      ('aged C57BL/6 (20 mo)',   'bivalent',    'not stated',         'not stated', 'second strain'),
 'S15-N':      ('aged Swiss Webster (20 mo)', 'bivalent','not stated',         'not stated', 'outbred strain'),
 'S09-B':      ('young BALB/c',           'Aichi H3N2',  '5x mLD50 PR8 H1N1',  'd21', 'young heterosubtypic'),
 'S09-D':      ('young BALB/c',           'CA09 H1N1',   '5x mLD50 Perth H3N2','d21', 'young heterosubtypic'),
 'S09-F':      ('young BALB/c',           'bivalent',    '5x mLD50 VN04 rgH5N1','d180','young heterosubtypic, late'),
 'S13-E':      ('young BALB/c',           'bivalent (as S03-I)', '10x mLD50 CA09 H1N1', 'd14', 'young homologous'),
}

def cp(k, n, a=0.05):
    lo = 0.0 if k == 0 else beta.ppf(a / 2, k, n - k + 1)
    hi = 1.0 if k == n else beta.ppf(1 - a / 2, k + 1, n - k)
    return lo, hi

def km_median(d, e):
    kmf = KaplanMeierFitter().fit(d, e)
    m = kmf.median_survival_time_
    return 'NR' if np.isinf(m) else f"{m:g}"

def cellrange(g):
    return f"{g.cell_flag.iloc[0]}:{g.cell_flag.iloc[-1]}"

def per_group(S):
    rows = []
    for (blk, grp), g in S.groupby(['block', 'group'], sort=False):
        gg = g[~g.missing_days]
        n, deaths = len(gg), int(gg.event.sum())
        lo, hi = cp(n - deaths, n)
        pop, vac, chal, itv, cls = META[blk]
        rows.append(dict(block=blk, population=pop, vaccine=vac, challenge=chal, interval=itv, design=cls, group=grp,
                         n_records=len(g), n_missing_days=int(g.missing_days.sum()), n=n, deaths=deaths, survivors=n - deaths,
                         surv_pct=round(100 * (n - deaths) / n, 1), ci95=f"{100*lo:.0f}-{100*hi:.0f}",
                         median_days=km_median(gg.days, gg.event),
                         death_days=",".join(str(int(x)) for x in sorted(gg[gg.event == 1].days)),
                         last_obs_day=int(gg.days.max()), cells=f"{g.sheet.iloc[0]}!{cellrange(g)}"))
    return pd.DataFrame(rows)

def pairwise(S, pairs_of_interest=None):
    rows = []
    for blk, g in S.groupby('block', sort=False):
        g = g[~g.missing_days]
        groups = list(g.group.unique())
        for a, b in itertools.combinations(groups, 2):
            A, Bg = g[g.group == a], g[g.group == b]
            lr = logrank_test(A.days, Bg.days, A.event, Bg.event)
            tab = [[int((A.event == 0).sum()), int(A.event.sum())], [int((Bg.event == 0).sum()), int(Bg.event.sum())]]
            _, pf = fisher_exact(tab)
            rows.append(dict(block=blk, a=a, b=b, surv_a=f"{tab[0][0]}/{len(A)}", surv_b=f"{tab[1][0]}/{len(Bg)}",
                             logrank_chi2=round(lr.test_statistic, 2), logrank_p=lr.p_value, fisher_p=pf))
    return pd.DataFrame(rows)

G = per_group(S)
P = pairwise(S)
G.to_csv('survival_by_group.csv', index=False)
P.to_csv('survival_pairwise.csv', index=False)

if __name__ == '__main__':
    pd.set_option('display.width', 330); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 45)
    print(G.drop(columns=['population','vaccine','challenge','design']).to_string())
    print()
    pp = P.copy(); pp['logrank_p'] = pp.logrank_p.map(lambda x: f"{x:.2g}"); pp['fisher_p'] = pp.fisher_p.map(lambda x: f"{x:.2g}")
    print(pp.to_string())

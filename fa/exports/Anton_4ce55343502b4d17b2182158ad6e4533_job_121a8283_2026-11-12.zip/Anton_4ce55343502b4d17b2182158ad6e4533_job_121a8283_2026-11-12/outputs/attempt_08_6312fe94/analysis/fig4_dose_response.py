import pandas as pd, numpy as np
from figstyle import *
T = pd.read_csv('tidy_values.csv'); D = T[T.block == 'S08-A'].copy(); D['dose'] = D.time.astype(float)
F = pd.read_csv('dose_response_fit.csv').set_index('group')
def hill(d, emax, ed50, h): return 1 + (emax - 1) * d ** h / (ed50 ** h + d ** h)
fig, ax = plt.subplots(figsize=(6.2, 4.0))
xs = np.linspace(0.8, 44, 300)
lab = {'PSLN-344': 'PSLN-344 (Mn)', 'PSLN-344/R848': 'PSLN-344/R848 *', 'PSLN-212': 'PSLN-212 (no Mn)', 'CMP-204': 'CMP-204 (cGAMP)'}
yoff = {'PSLN-344': 0, 'PSLN-344/R848': 0, 'PSLN-212': 1.2, 'CMP-204': -1.2}
for g in ['PSLN-344', 'PSLN-344/R848', 'PSLN-212', 'CMP-204']:
    x = D[D.group == g]; c = COL[g]
    ax.plot(xs, hill(xs, F.loc[g, 'Emax'], F.loc[g, 'ED50_ug'], F.loc[g, 'hill']), color=c, lw=1.8 if g in ('PSLN-344', 'PSLN-212') else 1.1, alpha=0.9)
    ax.scatter(x.dose, x.value, s=16, color=c, alpha=0.85, zorder=3, edgecolor='white', linewidth=0.3)
    ax.text(45, hill(44, F.loc[g, 'Emax'], F.loc[g, 'ED50_ug'], F.loc[g, 'hill']) + yoff[g], lab[g], color=c, fontsize=8.3, va='center')
ax.axhline(F.loc['PSLN-212', 'Emax'], color=COL['PSLN-212'], lw=0.8, ls=':')
ax.text(25.5, F.loc['PSLN-212', 'Emax'] + 1.0, f"PSLN-212 fitted ceiling ≈ {F.loc['PSLN-212','Emax']:.0f}-fold", color=COL['PSLN-212'], fontsize=7.6)
ax.axvline(20, color='#999999', lw=0.8, ls='--'); ax.text(20.6, 58.5, '20 µg = dose used in every\nefficacy experiment', fontsize=7.6, color='#555555', va='top')
ax.set_xlim(0, 44); ax.set_ylim(0, 60); ax.set_xticks([1, 5, 10, 20, 40])
ax.set_xlabel('Intranasal dose (µg per animal)'); ax.set_ylabel('Lung Ifnb1 mRNA at 16 h (fold over untreated)')
ax.set_title('Raising the dose of PSLN-212 cannot reach the PSLN-344 interferon response', loc='left', x=-0.12)
fig.text(0.02, -0.05, 'S08-A, n = 3 animals per dose (points); curves are 3-parameter Hill fits with baseline fixed at 1. Age of animals is not stated in the block\n'
         '(values match the aged groups of S01-A). * "PSLN-344/R848" is not in the materials list (listed: PSLN-212/R848).', fontsize=7.2, color='#444444', va='top')
fig.savefig('/tmp/outputs/figures/fig4_dose_response.png'); print('ok')

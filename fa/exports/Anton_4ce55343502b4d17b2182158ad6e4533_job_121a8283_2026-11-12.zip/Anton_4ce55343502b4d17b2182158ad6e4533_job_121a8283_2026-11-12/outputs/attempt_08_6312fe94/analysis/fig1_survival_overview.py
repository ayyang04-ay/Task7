import pandas as pd, numpy as np
from figstyle import *
from matplotlib.lines import Line2D
G = pd.read_csv('survival_by_group.csv')
rows = [
 ('S03-I', 'CA09 H1N1 (homologous)', '†'),
 ('S06-A', 'Aichi H3N2 vaccine → PR8 H1N1', ''),
 ('S06-C', 'Bivalent vaccine → rgH5N1', '‡'),
 ('S03-J', 'rgH5N1 vaccine → wild-type H5N1 (day 2)', '†'),
 ('S06-B', 'Aichi H3N2 vaccine → PR8 H1N1 (day 3)', ''),
 ('S06-D', 'Bivalent vaccine → rgH5N1 (day 3)', '‡'),
 ('S15-H', 'Bivalent vaccine → rgH5N1 (day 3, repeat)', ''),
 ('S06-E[r34]', 'Aichi H3N2 vaccine → PR8 H1N1', ''),
 ('S06-F[r34]', 'Bivalent vaccine → rgH5N1', ''),
 ('S06-G', 'CA09 H1N1 vaccine → Perth H3N2', ''),
 ('S15-L', 'Aged C57BL/6 (challenge virus not stated)', '§'),
 ('S15-N', 'Aged Swiss Webster (challenge virus not stated)', '§'),
]
sections = {0: 'Challenged 14 days after one intranasal dose', 3: 'Challenged 2–3 days after one dose',
            7: 'Challenged 60 days after one dose', 10: 'Other mouse strains'}
arm_map = {'Sham': 'Sham', 'PSLN-212': 'PSLN-212', 'PSLN-344': 'PSLN-344', 'PSLN-212(Y)': 'PSLN-212(Y)', 'Untreated': 'Untreated',
           '3d Vaccine': 'Sham', '3d Vaccine+PSLN-344': 'PSLN-344', '3d PSLN-344': 'ADJ'}
fig, ax = plt.subplots(figsize=(8.8, 6.6))
y = 0; yt = []; yl = []
jit = {'Sham': 0.17, 'PSLN-212': 0.0, 'PSLN-344': 0.0, 'PSLN-212(Y)': -0.17, 'Untreated': 0.30, 'ADJ': -0.17}
for i, (blk, lab, flag) in enumerate(rows):
    if i in sections:
        y -= 0.45
        ax.text(-0.62, y, sections[i], fontsize=9, fontweight='bold', va='center', ha='left', color='#222222', transform=ax.get_yaxis_transform())
        y -= 0.85
    g = G[G.block == blk]; pts = {}
    for _, r in g.iterrows():
        arm = arm_map.get(r.group)
        if arm: pts[arm] = r
    if 'PSLN-212' in pts and 'PSLN-344' in pts:
        ax.plot([pts['PSLN-212'].surv_pct, pts['PSLN-344'].surv_pct], [y, y], color='#bbbbbb', lw=2.2, zorder=1, solid_capstyle='round')
    for arm, r in pts.items():
        yy = y + jit[arm]
        if arm == 'Untreated':
            ax.scatter(r.surv_pct, yy, s=34, marker='D', facecolor='white', edgecolor='black', linewidth=1.1, zorder=4)
        elif arm == 'ADJ':
            ax.scatter(r.surv_pct, yy, s=40, marker='s', facecolor='white', edgecolor=COL['PSLN-344'], linewidth=1.3, zorder=4)
        elif arm in ('Sham', 'PSLN-212(Y)'):
            ax.scatter(r.surv_pct, yy, s=26, color=COL[arm], zorder=3)
        else:
            ax.scatter(r.surv_pct, yy, s=70, color=COL[arm], zorder=5, edgecolor='white', linewidth=0.7)
    if 'PSLN-344' in pts:
        ax.text(109, y, f"{pts['PSLN-344'].survivors}/{pts['PSLN-344'].n}", color=COL['PSLN-344'], va='center', ha='center', fontsize=8.8, fontweight='bold')
    if 'PSLN-212' in pts:
        ax.text(121, y, f"{pts['PSLN-212'].survivors}/{pts['PSLN-212'].n}", color=COL['PSLN-212'], va='center', ha='center', fontsize=8.8)
    if 'Sham' in pts:
        ax.text(133, y, f"{pts['Sham'].survivors}/{pts['Sham'].n}", color=COL['Sham'], va='center', ha='center', fontsize=8.8)
    yt.append(y); yl.append(f"{lab} {flag}  [{blk.split('[')[0]}]")
    y -= 1
ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8.4)
ax.set_ylim(y + 0.3, 1.0)
ax.set_xlim(-4, 140); ax.set_xticks([0, 25, 50, 75, 100]); ax.set_xlabel('Animals alive at end of observation (%)', x=0.36)
for x, t, c, w in [(109, '344\n(Mn)', COL['PSLN-344'], 'bold'), (121, '212\n(no Mn)', COL['PSLN-212'], 'normal'), (133, 'Sham', COL['Sham'], 'normal')]:
    ax.text(x, 0.5, t, color=c, fontsize=8, fontweight=w, ha='center', va='bottom')
ax.text(121, 1.5, 'survivors / n', fontsize=7.5, ha='center', color='#555555')
for x in (0, 100): ax.axvline(x, color='#e3e3e3', lw=0.7, zorder=0)
ax.spines['bottom'].set_bounds(0, 100)
h = [Line2D([], [], marker='o', ls='', ms=8, color=COL['PSLN-344'], label='PSLN-344 (Mn) + vaccine, aged'),
     Line2D([], [], marker='o', ls='', ms=8, color=COL['PSLN-212'], label='PSLN-212 (no Mn) + vaccine, aged'),
     Line2D([], [], marker='o', ls='', ms=5, color=COL['Sham'], label='Vaccine + empty liposome (sham) or vaccine alone, aged'),
     Line2D([], [], marker='o', ls='', ms=5, color=COL['PSLN-212(Y)'], label='PSLN-212 + vaccine, young (benchmark)'),
     Line2D([], [], marker='D', ls='', ms=5.5, markerfacecolor='white', color='black', label='Untreated and unchallenged, aged'),
     Line2D([], [], marker='s', ls='', ms=6, markerfacecolor='white', color=COL['PSLN-344'], label='PSLN-344 without vaccine, aged')]
ax.legend(handles=h, loc='upper left', bbox_to_anchor=(-0.62, -0.075), ncol=2, fontsize=8, columnspacing=1.5, handletextpad=0.4)
ax.text(-0.62, 1.09, 'Aged mice: PSLN-344 beats the Mn-free PSLN-212 in every challenge experiment;\nprotection is lower, and background deaths appear, at day 60',
        transform=ax.transAxes, ha='left', va='bottom', fontsize=10.5, fontweight='bold')
ax.text(-0.62, -0.235,
         '† Survival table and paired body-weight block disagree on arm identities or counts (S03-I vs S13-F; S03-J vs S13-G). One S03-J PSLN-344 animal has no recorded time and is excluded.\n'
         '‡ S06-C and S06-D hold identical time-to-event data in all four arms; the body weights paired with S06-D imply 5/7 rather than 7/7 for PSLN-344.\n'
         '§ PSLN-344 arm repeats the S06-A pattern (one death, day 8) and its body-weight block shares values with the BALB/c block S15-A.   n = 7 per arm except S03-J (9–10).',
         fontsize=7.0, color='#444444', va='top', ha='left', transform=ax.transAxes)
fig.savefig('/tmp/outputs/figures/fig1_survival_overview.png')
print('ok')

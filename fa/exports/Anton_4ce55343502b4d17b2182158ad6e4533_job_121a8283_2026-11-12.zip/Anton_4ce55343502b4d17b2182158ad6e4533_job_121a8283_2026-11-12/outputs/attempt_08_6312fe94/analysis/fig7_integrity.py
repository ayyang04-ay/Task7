import pandas as pd, numpy as np
from figstyle import *
T = pd.read_csv('tidy_values.csv')
def col(block, group): return T[(T.block == block) & (T.group == group)].sort_values('unit_idx').value.values.astype(float)
fig, axes = plt.subplots(1, 3, figsize=(12.2, 4.0), gridspec_kw={'width_ratios': [1.05, 1.1, 1.0]})
rng = np.random.default_rng(1)
# A: IgG2a:IgG1
ax = axes[0]
groups = ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']; xl = ['PSLN-212\naged', 'PSLN-344\naged', 'PSLN-212\nyoung']
for i, g in enumerate(groups):
    pr = col('S03-B', g); rc = col('S13-A', g) / col('S13-B', g)
    ax.scatter(i - 0.17 + rng.uniform(-0.04, 0.04, 5), pr, s=24, facecolor='white', edgecolor=COL[g], linewidth=1.2, zorder=3)
    ax.plot([i - 0.27, i - 0.07], [pr.mean()] * 2, color=COL[g], lw=1.4, ls=(0, (2, 1)))
    ax.scatter(i + 0.17 + rng.uniform(-0.04, 0.04, 5), rc, s=24, color=COL[g], zorder=3)
    ax.plot([i + 0.07, i + 0.27], [rc.mean()] * 2, color=COL[g], lw=2.2)
ax.axhline(1, color='#bbbbbb', lw=0.8); ax.set_xticks(range(3)); ax.set_xticklabels(xl, fontsize=8.3)
ax.set_ylabel('IgG2a : IgG1 (CA09 H1N1), day 14'); ax.set_ylim(0, 5.2)
ax.text(0.03, 0.97, '○ as printed in S03-B\n● recomputed from S13-A ÷ S13-B', transform=ax.transAxes, fontsize=7.8, va='top', color='#333333')
ax.set_title('A  S03-B column headers are rotated', loc='left', fontsize=9.5)
# B: S15-C vs S15-I
ax = axes[1]
a = T[(T.block == 'S15-C') & (T.group == 'PSLN-344')].copy(); b = T[(T.block == 'S15-I') & (T.group == '3d Vaccine+PSLN-344')].copy()
a['day'] = a.time.astype(float); b['day'] = b.time.astype(float)
for u in range(1, 8):
    x = a[a.unit_idx == u].sort_values('day'); y = b[b.unit_idx == u].sort_values('day')
    ax.plot(y.day, y.value, color='#222222', lw=3.2, alpha=0.25, solid_capstyle='round')
    ax.plot(x.day, x.value, color=COL['PSLN-344'], lw=1.1, marker='o', ms=2.6)
ax.set_xticks(range(0, 15, 2)); ax.set_xlabel('Days after challenge'); ax.set_ylabel('Body weight (% of day 0)'); ax.set_ylim(72, 109); ax.set_yticks([75, 80, 85, 90, 95, 100, 105])
ax.text(0.03, 0.10, '— S15-C PSLN-344 (challenge day 14)', color=COL['PSLN-344'], transform=ax.transAxes, fontsize=7.8)
ax.text(0.03, 0.03, '▬ S15-I Vaccine+PSLN-344 (challenge day 3)', color='#777777', transform=ax.transAxes, fontsize=7.8)
ax.text(2.6, 108.6, 'identical in 40 of 48 cells through day 12;\ndiverge only at day 14', fontsize=7.8, color='#333333', va='top')
ax.set_title('B  Two experiments, one set of weights', loc='left', fontsize=9.5)
# C: S11-A vs S11-B
ax = axes[2]
for blk, ls, lw in [('S11-A', '-', 2.2), ('S11-B', (0, (2, 1.5)), 1.4)]:
    d = T[T.block == blk].copy(); d['day'] = d.time.astype(float)
    for g in ['Vaccine', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        m = d[d.group == g].groupby('day').value.mean()
        ax.plot(m.index, m.values, color=COL[g] if blk == 'S11-A' else 'black', lw=lw, ls=ls, alpha=0.9 if blk == 'S11-A' else 0.8)
ax.set_xticks([0, 2, 4, 6, 8]); ax.set_xlabel('Days after immunisation'); ax.set_ylabel('Cells in lung (%), group mean'); ax.set_ylim(15, 55)
ax.text(0.03, 0.97, '— S11-A "alveolar macrophages" (colour = group)\n┄ S11-B "neutrophils" (black)', transform=ax.transAxes, fontsize=7.8, va='top', color='#333333')
ax.text(8.1, 40.4, 'young', fontsize=7.5, color=COL['PSLN-212(Y)'], va='center'); ax.text(8.1, 28.8, '344', fontsize=7.5, color=COL['PSLN-344'], va='center')
ax.text(8.1, 24.6, '212', fontsize=7.5, color=COL['PSLN-212'], va='center'); ax.text(8.1, 21.8, 'vaccine', fontsize=7.5, color=COL['Vaccine'], va='center')
ax.set_xlim(-0.3, 9.4); ax.spines['bottom'].set_bounds(0, 8)
ax.set_title('C  "Neutrophil" block mirrors S11-A', loc='left', fontsize=9.5)
fig.subplots_adjust(wspace=0.33)
fig.suptitle('Three of the record conflicts that change what can be claimed (full list in the audit table)', x=0.065, y=1.03, ha='left', fontsize=10.5, fontweight='bold')
fig.text(0.065, -0.04, 'A: printed S03-B values under "PSLN-344" equal the PSLN-212 quotients recomputed from the raw subclass titres (and so on around the three columns); same rotation in S03-F (Aichi).\n'
         'B: each thin line is one animal; grey band = the animal at the same column position in the other block.  C: 35 of 100 cells identical at the same position; group means agree within 2.5 points at every time point.', fontsize=7.2, color='#444444', va='top')
fig.savefig('/tmp/outputs/figures/fig7_integrity.png'); print('ok')

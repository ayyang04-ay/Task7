import pandas as pd, numpy as np
from figstyle import *
T = pd.read_csv('tidy_values.csv'); S = pd.read_csv('tidy_survival.csv'); S = S[S.days.notna()]
def surv(blocks, g):
    x = S[S.block.isin(blocks) & (S.group == g)]; return int((x.event == 0).sum()), len(x)
fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.4), gridspec_kw={'width_ratios': [1, 1.2]})
rng = np.random.default_rng(3)
# ---- A HAI
ax = axes[0]
groups = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
xl = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212\nyoung']
for i, g in enumerate(groups):
    v = T[(T.block == 'S03-C') & (T.group == g)].value.values.astype(float); v = np.where(v <= 0, 5, v)
    ax.scatter(i + rng.uniform(-0.16, 0.16, len(v)), v, s=26, color=COL[g], alpha=0.85, zorder=3, edgecolor='white', linewidth=0.4)
    gm = np.exp(np.log(v).mean()); ax.plot([i - 0.25, i + 0.25], [gm, gm], color=COL[g], lw=2.2)
    s_, n_ = surv(['S03-I'], g)
    ax.text(i, 2.45, f"{s_}/{n_}", ha='center', fontsize=9, color=COL[g], fontweight='bold')
ax.text(-0.5, 3.45, 'Survived homologous challenge (S03-I):', ha='left', va='center', fontsize=7.6, color='#444444')
ax.set_yscale('log', base=2); ax.set_yticks([5, 10, 20, 40, 80, 160, 320, 640]); ax.set_yticklabels(['<10', '10', '20', '40', '80', '160', '320', '640'])
ax.axhline(40, color='#444444', lw=0.9, ls='--'); ax.text(4.45, 43, 'HAI 1:40\n(human sero-\nprotection)', fontsize=7.3, color='#444444', va='bottom', ha='right')
ax.set_xticks(range(5)); ax.set_xticklabels(xl, fontsize=8.3); ax.set_ylim(1.9, 900); ax.set_xlim(-0.55, 4.55)
ax.set_ylabel('Serum HAI titre to CA09 H1N1, day 14'); ax.spines['left'].set_bounds(5, 640)
ax.set_title('A  Every aged PSLN-212 animal reached HAI ≥ 40,\n    yet the group was not protected', loc='left', fontsize=9.5)
# ---- B cross-reactive CD8
ax = axes[1]
groups = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']; xl = ['Sham', '212', '344', '212\nyoung']
x0 = 0; xt = []; xtl = []
for blk, tp, sb in [('S05-F', 'day 14', ['S06-A', 'S06-C']), ('S05-G', 'day 60', ['S06-E[r34]', 'S06-F[r34]', 'S06-G'])]:
    for i, g in enumerate(groups):
        v = T[(T.block == blk) & (T.group == g)].value.values.astype(float); x = x0 + i
        ax.scatter(x + rng.uniform(-0.16, 0.16, len(v)), v, s=26, color=COL[g], alpha=0.85, zorder=3, edgecolor='white', linewidth=0.4)
        ax.plot([x - 0.25, x + 0.25], [v.mean()] * 2, color=COL[g], lw=2.2)
        s_, n_ = surv(sb, g); ax.text(x, -3.6, f"{s_}/{n_}", ha='center', fontsize=9, color=COL[g], fontweight='bold')
        xt.append(x); xtl.append(xl[i])
    ax.text(x0 + 1.5, 20.3, f"{tp} after one dose", ha='center', fontsize=9, fontweight='bold', color='#333333')
    x0 += 5
ax.text(-0.5, -1.9, 'Survived heterosubtypic challenge (S06 blocks):', ha='left', va='center', fontsize=7.6, color='#444444')
ax.set_xticks(xt); ax.set_xticklabels(xtl, fontsize=8.3); ax.set_ylim(-5.2, 21.5); ax.set_xlim(-0.6, 8.6); ax.set_yticks([0, 5, 10, 15, 20]); ax.spines['left'].set_bounds(0, 20)
ax.set_ylabel('IFN-γ+ CD8 T cells (%), lymph node,\nrestimulated with rgH5N1 (not in the vaccine)')
ax.set_title('B  Cross-reactive CD8 T cells rank the groups the same way\n    as heterosubtypic survival, at day 14 and day 60', loc='left', fontsize=9.5)
fig.subplots_adjust(wspace=0.3)
fig.text(0.03, -0.03, 'A: S03-C (n = 5; bars = geometric mean; "<10" = no inhibition at the lowest dilution tested) with survival from S03-I (10× mLD50 CA09). The paired weight block S13-F shows 3/7 PSLN-212 survivors.\n'
         'B: S05-F, S05-G (n = 5; bars = mean) with survival pooled from S06-A + S06-C (day 14) and S06-E + S06-F + S06-G (day 60).\n'
         'Immune read-outs and challenge outcomes are from different animals: this is group-level concordance (4–5 groups), not a correlate of protection.', fontsize=7.2, color='#444444', va='top')
fig.savefig('/tmp/outputs/figures/fig6_biomarker.png'); print('ok')

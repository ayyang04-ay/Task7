"""
Planning calculations for the proposed confirmatory study (exact power of two-sided Fisher exact test, alpha=0.05),
anchored on survival proportions observed in this dataset.
"""
import numpy as np, pandas as pd
from scipy.stats import binom, fisher_exact
def power(p1, p2, n1, n2=None, alpha=0.05):
    n2 = n2 or n1
    pw = 0.0
    for a in range(n1 + 1):
        pa = binom.pmf(a, n1, p1)
        if pa < 1e-12: continue
        for b in range(n2 + 1):
            pb = binom.pmf(b, n2, p2)
            if pb < 1e-12: continue
            if fisher_exact([[a, n1 - a], [b, n2 - b]])[1] < alpha:
                pw += pa * pb
    return pw
rows = []
for label, p1, p2 in [('PSLN-344 vs PSLN-212 (pooled observed 82% vs 11%)', 0.82, 0.11),
                      ('PSLN-344 vs PSLN-212 (worst-case 79% vs 18%)', 0.79, 0.18),
                      ('PSLN-344 d60 vs PSLN-212 d60 (67% vs 5%)', 0.67, 0.05),
                      ('PSLN-344 vs hypothetical benchmark adjuvant at 50%', 0.82, 0.50),
                      ('PSLN-344 vs hypothetical benchmark adjuvant at 40%', 0.82, 0.40),
                      ('PSLN-344 d60 (67%) vs untreated-unchallenged background (81%)', 0.67, 0.81)]:
    for n in [7, 10, 12, 15, 20, 30, 40]:
        rows.append(dict(contrast=label, n_per_group=n, power=round(power(p1, p2, n), 3)))
P = pd.DataFrame(rows).pivot(index='contrast', columns='n_per_group', values='power')
P.to_csv('power_calcs.csv')
print(P.to_string())

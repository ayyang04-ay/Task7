# PSLN-344 — portfolio recommendation

*Basis: `adjuvant_program_dataset.xlsx` (sheets S01–S15) and `adjuvant_program_annotation.pdf`. Labels in square brackets are the workbook's own block labels. Everything in the package is mouse data.*

## 1. Recommendation

**Advance PSLN-344 — into one gated de-risking package, not into IND-enabling work.**

Three statements carry the decision.

1. **The efficacy signal is large and belongs to the Mn formulation.** After one intranasal dose with inactivated vaccine, 84/100 aged or 14-month-old mice given PSLN-344 survived lethal influenza challenge, against 13/101 given the Mn-free parent PSLN-212. PSLN-344 had the higher survival in 14 of 14 head-to-head comparisons (§3.1), and the gap survives the least favourable reading of every record conflict I found.
2. **The package cannot yet support an IND-enabling commitment.** It contains no manganese tissue levels, no lung pathology, nothing outside the mouse, no comparison with the enhanced vaccines older adults already receive, and several blocks that contradict one another (§9).
3. **So the ask is a defined package with three go/no-go gates** (§7): the survival advantage replicates — blinded, in both sexes — and holds against a licensed-type benchmark; manganese does not accumulate in brain and lung inflammation resolves, with a dose margin; and the Mn effect appears in cells from older human donors and survives a clinically usable delivery route. Approve Studies 0–5; hold GLP toxicology, scale-up and clinical planning until the gates are read.

**How sure.** The direction of the efficacy effect is secure. Individual counts move by one to three animals depending on which record is believed. On safety the package supports no conclusion either way.

**If the committee declines**, what is dropped is the only formulation in the programme that protects aged animals: a single-dose, needle-free adjuvant giving protection across subtypes, including wild-type H5N1, within two to three days of dosing. The parent is not a fallback for this indication: PSLN-212 protects young mice (62/63) but not aged ones (9/73). The defensible reason to drop is unresolved manganese, route and translation risk. It is not weak efficacy.

## 2. Before quoting any number

**How each number was reduced.** These rules apply throughout unless a line says otherwise.

| Data type | Reduction | Test |
|:-----------|:---------------------------|:----------------------|
| Time to event | Survivors ÷ animals at the last observation day, counted from the per-animal rows (1 = death, 0 = alive); exact 95% CI | Log-rank (Mantel–Cox) and Fisher exact, two-sided |
| Percentages, fold-changes | Arithmetic mean ± SD of per-animal values | One-way ANOVA across all groups in the block with Tukey's test (the file's stated method) |
| Titres | Geometric mean (GMT); HAI entries of 0, i.e. below the 1:10 floor, set to 5 | Same, on log10 titres |
| S09-A (stored as log10) | 10^(mean of the log10 values) | — |
| Body weight | Each animal's lowest value; survivors identified animal by animal (§9, item 14) | — |

Survival counts are the only quantity pooled across blocks, and only where stated. Every number in this memo is listed with its block, cell range, n and reduction in `PSLN-344_numbers_ledger.xlsx`, sheet "Cited numbers", in order of appearance.

**Five things in the workbook that mislead if quoted as printed.** The full list is in §9.

1. **S03-B and S03-F (IgG2a/IgG1 ratio) have rotated column headers.** As printed, PSLN-344 has the lowest ratio (0.58 ± 0.20). Recomputed from the per-animal subclass titres in S13-A and S13-B it is 2.14 ± 1.31; the column printed as "PSLN-344" holds the PSLN-212 animals.
2. **S06-C and S06-D are identical, row for row** (all 28 rows), although one is a day-14 and the other a day-3 challenge. I count the record once, under S06-C. The body-weight record of the day-3 experiment [S15-D] implies 5/7, not 7/7, for PSLN-344.
3. **S03-I records PSLN-212 as 0/7 with every death by day 6; the weight record for the same experiment [S13-F] has all 7 animals still being weighed on day 10 and 3 back at 95–99% of starting weight on day 14.** I carry both readings.
4. **"Untreated" in S06-E, S06-F and S06-G means unchallenged** — no vaccine, no adjuvant, no virus. 4/21 of those animals died within the 14-day window anyway. That is background mortality at about 22 months of age.
5. **S11-A (alveolar macrophages) and S11-B (neutrophils) share 35 of 100 values cell for cell**, so at most one is an original record. I use neither, which leaves the package without a dependable neutrophil readout. Separately, the second S09-A panel is labelled 16 h but holds the 72 h data (its Ifnb1 values are the S01-A 72 h values).

## 3. The case for advancing

### 3.1 PSLN-344 protects aged animals; the Mn-free parent does not

Table 1 gives every challenge experiment with an aged or 14-month PSLN-344 arm. Figure 1 shows the same counts; Figure 2 shows six of the survival curves.

**Table 1. Survivors / animals at the last observation day** (14 days after challenge; 21 days for S03-J). One intranasal dose, 20 µg adjuvant.

| Block | Vaccine → challenge (day after dosing) | Sham | PSLN-212 aged | PSLN-344 aged | PSLN-212 young | Log-rank p, 344 vs 212 | Paired weight block |
|:---------|:-----------------------|:-----:|:-----:|:-----:|:-----:|:------:|:----------------|
| S03-I | H1N1+H3N2 → 10× mLD50 CA09 H1N1 (d14) | 0/7 | 0/7 | 7/7 | 7/7 | 0.0004 | S13-F: PSLN-212 3/7 |
| S06-A | H3N2 → 5× mLD50 PR8 H1N1 (d14) | 0/7 | 1/7 | 6/7 | 7/7 | 0.008 | S15-A agrees |
| S06-C | H1N1+H3N2 → 5× mLD50 rgH5N1 (d14) | 0/7 | 2/7 | 7/7 | 7/7 | 0.007 | S15-C: PSLN-212 1/7; its PSLN-344 traces duplicate S15-I |
| S03-J | rgH5N1 → wild-type H5N1 (d2) | 1/10 | 3/10 | 9/9† | — | 0.002 | S13-G: PSLN-344 10/10; comparator labels differ |
| S06-B | H3N2 → 5× mLD50 PR8 H1N1 (d3) | 0/7 | 0/7 | 5/7 | 7/7 | 0.0009 | S15-B agrees |
| S15-H | H1N1+H3N2 → 5× mLD50 rgH5N1 (d3) | 0/7‡ | — | 6/7 | — | — | S15-I agrees |
| S06-E (rows 34–68) | H3N2 → PR8 H1N1 (d60) | 0/7 | 0/7 | 5/7 | 7/7 | 0.002 | S15-E: PSLN-344 6/7, PSLN-212 1/7 |
| S06-F (rows 34–68) | H1N1+H3N2 → rgH5N1 (d60) | 0/7 | 1/7 | 5/7 | 7/7 | 0.009 | S15-F agrees |
| S06-G | H1N1 → Perth H3N2 (d60) | 0/7 | 0/7 | 4/7 | 7/7 | 0.015 | S15-G: PSLN-344 5/7 |
| S15-L | 20-month C57BL/6; H1N1+H3N2 → not stated | 0/7 | 0/7 | 6/7 | 6/7 | 0.001 | S15-M: young 7/7 |
| S15-N | 20-month Swiss Webster; H1N1+H3N2 → not stated | 0/7 | 2/7 | 6/7 | 7/7 | 0.056 | S15-O agrees |
| S06-E (rows 71–105) | 14-month, saline-primed; H1N1+H3N2 → PR8 | — | 0/7 | 6/7 | — | 0.002 | S15-J agrees |
| S06-E (rows 71–105) | 14-month, PR8-infected 4 months earlier; → PR8 | — | 4/7 | 6/7 | — | 0.23 | S15-J agrees |
| S06-F (rows 71–105) | 14-month, saline-primed; → Perth H3N2 (d14) | — | 0/7 | 6/7 | — | 0.0006 | S15-K agrees |
| S06-F (rows 71–105) | 14-month, PR8-infected; → Perth H3N2 (d14) | — | 0/7 | 6/7 | — | 0.0002 | S15-K agrees |

† A tenth PSLN-344 animal is recorded alive but has no day entered; the weight block shows ten alive on day 14. ‡ Vaccine alone, not sham; the third arm, PSLN-344 alone, was 0/7. "Weight block" counts are animals whose day-14 weight is neither blank nor a carried-forward repeat. S06-D (H1N1+H3N2 → rgH5N1, day 3) is left out because its rows are identical to S06-C's; its weight block S15-D reads PSLN-344 5/7, PSLN-212 2/7, young 5/7.

![Figure 1. Survivors / animals in every challenge experiment with an aged or 14-month PSLN-344 arm.](figures/fig1_survival_matrix.png)

**Pooled.** Across the ten experiments in animals aged 20 months or more — three mouse strains, five challenge viruses, challenge from day 2 to day 60 — survival was 60/72 (83%; 95% CI 73–91) with PSLN-344, 9/73 (12%; 95% CI 6–22) with PSLN-212 and 1/73 with sham: a difference between the formulations of 71 percentage points (95% CI 57–80). The log-rank test stratified by experiment gives χ² = 81.8, p < 0.0001. PSLN-344 was ahead in 10 of 10 (sign test p = 0.002). In the four 14-month arms it was 24/28 against 4/28. The pooling is descriptive: these are ten different designs, not ten replicates of one.

**Robustness.** Taking, for each experiment, whichever record is less favourable to PSLN-344 and more favourable to PSLN-212 (including the day-3 weight record for the duplicated rgH5N1 block) gives 58/72 against 13/73 (Cochran–Mantel–Haenszel χ² = 54.5, p < 0.0001). Dropping S03-J as well, because its comparator labels are in doubt (§9, item 3), leaves 49/63 against 10/63. Single experiments are small: n = 7 per arm, Fisher p from 0.0006 [S03-I] to 0.10 [S15-N]. The weight of the case is the consistency, not any one block.

**Two limits on the claim.**

- *It closes most of the age gap, not all of it.* In the nine experiments that also carried young animals on PSLN-212, survival was 51/63 (81%) for aged mice on PSLN-344 and 62/63 (98%) for young mice on PSLN-212 (Fisher p = 0.002).
- *It is an aged-host effect.* In young mice the two formulations are indistinguishable: 24/24 against 24/24 [S09-B, S09-D, S09-F]. The age penalty is not peculiar to PSLN-212 either: against the same CA09 challenge the cGAMP liposome protected 7/7 young mice [S13-E] and 3/7 aged mice [S03-I].

![Figure 2. Kaplan–Meier curves for six of the experiments in Table 1. Curves are offset by under one percentage point where they overlap. The S03-I PSLN-212 curve is drawn as recorded (see §2, item 3).](figures/fig2_km_curves.png)

### 3.2 The protection is broad, fast, and still present at day 60

- **Across subtypes.** H3N2 vaccine then H1N1 challenge, which share neither HA nor NA: 6/7 against 1/7 [S06-A]. Seasonal H1N1+H3N2 vaccine then rgH5N1: 7/7 against 2/7 [S06-C].
- **Within days.** Challenged with H1N1 3 days after an H3N2 vaccine: 5/7 against 0/7 [S06-B]. Challenged with wild-type H5N1 2 days after a matched rgH5N1 vaccine: 9/9 against 3/10, sham 1/10 [S03-J].
- **Only with antigen.** Given 3 days before rgH5N1: vaccine alone 0/7, PSLN-344 alone 0/7, both together 6/7 [S15-H].
- **At day 60.** 14/21 (67%; 95% CI 43–85) against 1/21 for PSLN-212 and 0/21 for sham [S06-E, S06-F at rows 34–68; S06-G]. Unchallenged age-matched animals lost 4/21 in the same window, so the day-60 result cannot be told apart from the ceiling those cohorts allowed (Fisher p = 0.48). Equally, nothing beyond day 60 exists for aged animals: the only 180-day challenge is in young mice [S09-F].
- **Across strains and immune history.** 20-month C57BL/6: 6/7 against 0/7 [S15-L]. 20-month Swiss Webster: 6/7 against 2/7 [S15-N]. 14-month mice with or without a PR8 infection four months earlier: 6/7 in all four PSLN-344 arms [S06-E, S06-F at rows 71–105].
- **Protection from death, not from illness.** Surviving PSLN-344 animals still fell to 85–93% of starting weight (group means of each survivor's lowest weight, across the weight blocks); young PSLN-212 survivors fell to 88–93%. The clinical analogue is reduced severity, not prevention of infection.

### 3.3 The immune readouts move with survival

**Table 2. Key readouts in the four core arms.** Mean ± SD, n = 5 per group unless noted; GMT for titres.

| Readout [block] | Sham | PSLN-212 aged | PSLN-344 aged | PSLN-212 young | p, 344 vs 212 aged |
|:---------------------------------|:-----:|:-----:|:-----:|:-----:|:-----:|
| Lung Ifnb1, fold, 16 h [S01-A] | 1.0 ± 0.5 | 16.6 ± 2.1 | 37.1 ± 4.8 | 37.6 ± 3.5 | <0.0001 |
| Lung Gm-csf, fold, 36 h [S02-F] | 1.2 ± 0.2 | 1.6 ± 0.1 | 8.7 ± 2.2 | not run | 0.002 |
| Lung monocytes, %, day 4 [S01-D] | 10.4 ± 0.6 | 16.7 ± 1.6 | 30.6 ± 4.7 | 32.2 ± 3.9 | 0.002 |
| Lung CD11b+ dendritic cells, %, day 4 [S01-E] | 4.8 ± 2.1 | 8.3 ± 1.9 | 18.9 ± 8.6 | 21.4 ± 1.7 | 0.049 |
| Antigen-bearing DC in lymph node, %, 36 h [S02-C] | not run | 1.8 ± 0.4 | 7.1 ± 1.4 | 9.4 ± 1.5 | <0.0001 |
| CD8 priming by lymph-node DC ex vivo, % divided [S02-E] | not run | 0.8 ± 0.5 | 18.7 ± 2.8 | 26.2 ± 6.7 | <0.0001 |
| Ki-67+ CD8 T cells in lung, %, day 3 [S05-D] | 0.8 ± 0.5 | 3.5 ± 1.4 | 9.4 ± 1.8 | 9.9 ± 3.0 | 0.0008 |
| IFN-γ+ CD8 T cells responding to rgH5N1, %, day 14 [S05-F] | 0.7 ± 0.4 | 1.5 ± 0.4 | 6.4 ± 1.0 | 9.2 ± 0.9 | <0.0001 |
| Same, day 60 [S05-G] | 1.5 ± 1.1 | 3.0 ± 1.3 | 9.9 ± 2.8 | 14.4 ± 2.9 | 0.0008 |
| Lung resident-memory CD8 T cells, %, day 25 [S05-I] | 0.6 ± 0.3 | 1.0 ± 0.4 | 4.0 ± 0.6 | 6.0 ± 0.6 | <0.0001 |
| HAI against CA09, GMT, day 14 [S03-C] | 8 | 46 | 368 | 485 | <0.0001 |
| Neutralising titre against CA09, GMT, day 14 [S03-D] | 52 | 418 | 3,840 | 6,686 | 0.0002 |
| IgG2a ÷ IgG1 against CA09, day 14 [S13-A ÷ S13-B] | not run | 0.58 ± 0.20 | 2.14 ± 1.31 | 2.97 ± 1.69 | 0.007 |
| Germinal-centre B cells, %, day 7 [S03-K] | 1.2 ± 0.4 | 2.3 ± 0.5 | 6.5 ± 1.5 | 9.8 ± 3.1 | 0.007 |
| Follicular regulatory T cells, % Foxp3+ of CXCR5+, day 7 [S04-B] | 22.6 ± 4.4 | 26.7 ± 6.7 | 10.8 ± 1.8 | 7.1 ± 3.7 | 0.0002 |
| Lung regulatory T cells, %, day 7, n = 3 [S04-D] | 5.9 ± 0.8 | 6.7 ± 0.3 | 3.0 ± 0.4 | 1.8 ± 0.6 | 0.0002 |

p values are Tukey within the block, except single time points taken from time-course blocks (S02-F, S01-D, S01-E) and the recomputed ratio, which are Welch t tests. S05-I is annotated "vaccinated as in S05-A", whose antigen description is contradictory (§9, item 11); its readout is not antigen-specific, so I use it.

Across the 28 readouts that rise from sham to young, PSLN-344 in aged animals reaches a median 72% of the young PSLN-212 value; PSLN-212 in aged animals reaches 21% (Figure 3, right). Restoration is uneven. Costimulatory markers on lymph-node dendritic cells stay low: CD40 at 29% and CD86 at 38% of young [S02-D].

Mn raises the ceiling of the interferon response rather than shifting its potency. In the dose series [S08-A, n = 3 per dose], the fitted plateau is 53 ± 4-fold for PSLN-344 against 16 ± 1-fold for PSLN-212, with similar half-maximal doses (11 ± 1 and 9 ± 1 µg). PSLN-212 at 40 µg (14.9 ± 2.6) does not reach PSLN-344 at 10 µg (21.1 ± 2.6). The 20 µg used in every efficacy study sits at 83% of the PSLN-344 plateau.

![Figure 3. Left: Ifnb1 dose-response (S08-A). Right: aged responses as a share of the young PSLN-212 response.](figures/fig3_mechanism.png)

### 3.4 The alternatives inside the package are worse

- **More PSLN-212.** Ruled out by the plateau above.
- **Two doses of PSLN-212.** After a day-14 boost, IgG against CA09 reaches GMT 4,411 [S13-I], below one dose of PSLN-344 at day 14 (7,305) [S03-A]; against Aichi, 1,086 [S13-J] against 5,701 [S03-E]. No boosted animals were challenged.
- **Adding R848 instead of Mn.** PSLN-212/R848 raised 16 h Ifnb1 to 24.3 ± 3.7 but it was gone by 72 h (1.7 ± 0.3) [S01-A]. It drove Tnf to 202-fold and Il10 to 179-fold [S09-A], and the animals were at 90.6 ± 6.2% of starting weight on day 10 with one of five missing [S08-D].
- **cGAMP liposome (CMP-204).** Ifnb1 7.8 ± 1.7-fold; survival 3/7 against matched CA09 [S01-A, S03-I].
- **GM-CSF given with PSLN-212.** Raises monocyte-derived dendritic-type cells to 13.8 ± 3.0% from 5.9 ± 1.5% [S02-G], but needs four daily intranasal protein doses and was never taken to challenge.

### 3.5 Tolerability signals so far

- **Body weight after dosing** (aged, n = 5) [S08-D]. The PSLN-344 group mean was lowest on day 4 at 96.7 ± 1.8% of baseline (lowest single animal 94.2%) and was 99.8 ± 0.7% on day 10. Vaccine alone was 98.8 ± 1.2% on day 4.
- **Brain transcripts at 36 h** (aged, n = 5) [S10-A]. Relative to sham, PSLN-344 gave Ifnb1 1.13×, Tnf 1.21× and Isg15 1.08× (Tukey p = 0.98, 0.92, 0.99). The cholera-toxin positive control gave 4.7×, 2.6× and 2.6×.

These are reassuring as far as they go. §4 sets out how far that is.

## 4. What the package does not establish

These are the objections to expect. The last column says which study in §7 answers each.

| Missing | What the package has instead | Why it matters | Closed by |
|:---------------|:------------------------|:-----------------------------|:-------|
| Replication, both sexes, blinding | One experiment per condition; n = 7 per arm (10 for wild-type H5N1); female mice only; randomisation and blinding not described | Any one block is fragile. At n = 7 per arm a Fisher test has 50% power even at the least favourable pooled rates | Study 1 |
| A benchmark that matters clinically | Comparators are sham, PSLN-212 and a cGAMP liposome | No arm resembles the high-dose or oil-in-water-adjuvanted intramuscular vaccines older adults already get, so "better than what exists" is untested | Study 1 |
| Attribution to the Mn–CDN particle | PSLN-344 against PSLN-212 only | No Mn-only particle and no free-Mn admixture. The Mn content of PSLN-344 is not reported anywhere in the package | Studies 1 and 5 |
| Manganese and CNS safety | Three brain transcripts at one time point (36 h), all near sham | Nothing on whether Mn reaches or stays in olfactory bulb or brain, which is the recognised hazard of inhaled manganese, and nothing on repeat dosing. Intranasal adjuvants also carry history: a toxin-adjuvanted intranasal influenza vaccine was withdrawn after facial-nerve palsies. (Both points are background knowledge, not in the package) | Study 3 |
| Lung safety | Body weight to day 10 (n = 5); cytokine transcripts (n = 3); cell counts to day 8 | No histopathology and no usable neutrophil data. Signals to follow: Il6 and Tnf at 36× and 40× at 16 h, still 7.2× and 8.4× in the 72 h panel, when young animals on PSLN-212 had Tnf back at 0.5× [S09-A]; lung monocytes still 18.4 ± 0.6% on day 8 against 9.2 ± 0.7% at baseline [S01-D] | Study 3 |
| Any non-mouse evidence | None | Mouse and human STING differ in ligand sensitivity and humans carry common STING variants (background knowledge, not in the package) | Study 4 |
| A clinically usable route | Intranasal instillation in mice; uptake shown in alveolar epithelium [S01-B] and, SP-A/D-dependently, alveolar macrophages (43.1 ± 4.1% against 12.7 ± 3.0% in knockouts) [S01-C] | The demonstrated mechanism is alveolar. A human nasal spray does not reach the alveoli; an inhaled product is a different development path | Study 4 |
| Antigen format | Formalin-inactivated whole virus, or ovalbumin, in every experiment | Behaviour with split or recombinant-HA antigen is unknown. As tested this is a new intranasal whole-virus vaccine, not a drop-in adjuvant for licensed products | Study 5 |
| Dose-ranging for protection | Every efficacy study at 20 µg | No minimum effective dose, so no safety margin can be stated | Study 1 |
| Durability in aged hosts | Day 60 only, with 4/21 background deaths | An influenza season is about six months | Study 1 |
| A package that reconciles with itself | §9 | Must be fixed before any of it leaves the team | Study 0 |

## 5. What is actually driving the protection

**Short answer.** The best-supported reading is an antigen-specific, lung-local CD8 T-cell response, which PSLN-344 switches back on in aged hosts by restoring the interferon-β → GM-CSF → monocyte-derived dendritic cell sequence. The package does not prove this, because no experiment removes a candidate effector and then measures survival.

**What it is not.**

- *Not an innate antiviral state.* PSLN-344 alone, 3 days before challenge, protected 0/7; with vaccine, 6/7 [S15-H].
- *Not the vaccine alone.* Sham arms: 1/73.
- *Not neutralising antibody, for the cross-subtype and day-2–3 results.* The H3N2 vaccine shares no surface antigen with the H1N1 challenge [S06-A], and protection at day 2–3 comes before any antibody the package measures (serum titres are day 14; the earliest B-cell readout is day 5 [S03-L]). Antibody above the conventional threshold was not enough even against the matched virus: in the serology cohort every aged PSLN-212 animal had HAI ≥ 40 (5/5; GMT 46) [S03-C], yet in the challenge cohort that arm is recorded as 0/7 [S03-I], or 3/7 on the weight record [S13-F].
- *Not more drug delivered.* Encapsulation was 54.8 ± 5.1% for PSLN-344 and 59.6 ± 4.6% for PSLN-212 (n = 3; Tukey p = 0.86) [S08-B].

**What Mn restores upstream.** Three links, with the intervention that supports each where the package has one.

1. *Interferon-β.* Lung Ifnb1 at 16 h: 16.6 ± 2.1-fold with PSLN-212 in aged mice and 37.1 ± 4.8 with PSLN-344, which is the young level (37.6 ± 3.5 in young mice on PSLN-212) [S01-A]. It is the one readout restored in full.
2. *GM-CSF.* Lung Gm-csf at 16 h: 1.5 ± 0.5-fold against 6.0 ± 0.4-fold [S02-F]. Interferon signalling is needed to turn monocytes into dendritic cells, and GM-CSF substitutes for it: donor monocyte-derived dendritic cells were 19.7 ± 4.0% from wild-type marrow, 2.1 ± 0.9% from interferon-receptor-deficient marrow, and 12.4 ± 3.7% when GM-CSF was added back [S02-H]. Monocyte entry itself was not clearly interferon-dependent (15.4 ± 2.5% against 21.3 ± 4.2%, n = 3, p = 0.10) [S12-A].
3. *Monocytes and their dendritic-cell progeny.* Blocking CCR2 cut lung monocytes from 9.9 ± 2.3% to 3.3 ± 1.4% [S07-B] and, in young mice, lung granzyme-B+ CD8 T cells from 6.8 ± 1.1% to 1.4 ± 0.5% [S02-I]. The gap-junction blocker carbenoxolone cut monocyte recruitment from 7.3 ± 1.9% to 3.1 ± 1.3% [S11-C]. Without Mn, the monocytes that do arrive in aged lungs accumulate as Ly6C+CCR2+ macrophages instead (19.0 ± 5.5 against 3.4 ± 0.8 ×10⁵ cells on day 5, n = 3) [S07-A], and regulatory T cells stay high (Table 2).

**What protects downstream.** CD8 T cells are dividing in the lung by day 3 (Table 2). They are primed locally: transferred OT-I cells proliferated in lung whether or not cell trafficking was blocked with pertussis toxin (59.0 ± 5.0% against 55.1 ± 9.5%), while proliferation in the lymph node fell from 30.9 ± 3.9% to 6.8 ± 0.8% (n = 3) [S05-C]. They cross-react: after H1N1+H3N2 vaccination, CD8 T cells respond to rgH5N1 at day 14 and day 60 (Table 2) [S05-F, S05-G]. And they persist in lung as resident memory at day 25 [S05-I].

**What is not shown.** There is no CD8 depletion, no serum transfer, no lung virus titre, and no mucosal IgA or non-neutralising antibody measurement. Antibody is restored too (Table 2) and probably contributes against matched strains. The CCR2 and interferon-receptor experiments have immunological endpoints only, and several mechanistic blocks used young or age-unstated animals [S02-I, S12-A, S05-C, S02-H]. Study 2 in §7 closes this.

## 6. Is there a biomarker worth carrying forward?

**Yes, one: vaccine-induced cross-reactive CD8 T cells. But only as a candidate.** On these data it can go into patients as a blood-based pharmacodynamic and response marker and as an exploratory correlate. It cannot serve as a surrogate endpoint, a stand-alone go/no-go criterion, or a patient-selection tool.

**Why this one.** It is the only readout measured against a virus the animals were not vaccinated with, so it matches the breadth of the protection. It is present at both challenge times, and it separates the arms as survival does: 6.4 ± 1.0% against 1.5 ± 0.4% at day 14 [S05-F], where survival against rgH5N1 was 7/7 against 2/7 [S06-C]. There is outside precedent for the choice: in older adults, T-cell measures such as granzyme B and the IFN-γ:IL-10 ratio have been reported to track protection where antibody titres did not (background knowledge, not in the package).

**Why only a candidate.**

1. *No animal has both a biomarker and an outcome.* Immunology cohorts (n = 5) and challenge cohorts (n = 7) are different animals, so every association is between four or five group means.
2. *Almost everything correlates.* 30 of 36 readouts measured in the four core arms are perfectly ordered sham → PSLN-212 → PSLN-344 → young, in one direction or the other. The data cannot say which of them matters.
3. *No intervention links it to survival* (§5).
4. *It was measured in lymph node, never in blood.* The mechanism points at the lung, and blood may under-read a lung-resident response; whether a blood measure tracks outcome is an open question.
5. *It does not follow the one change over time.* The response rose from 6.4 ± 1.0% at day 14 to 9.9 ± 2.8% at day 60 [S05-F, S05-G] while heterosubtypic survival went from 13/14 to 14/21 (Fisher p = 0.11).

**Table 3. Candidates considered.**

| Candidate [blocks] | What the data show | Measurable in patients? | Role |
|:----------------------|:---------------------------|:--------------------|:-------------------|
| Cross-reactive CD8 T cells: IFN-γ, granzyme B [S05-F, S05-G, S05-H, S14-A] | Tracks arm ranking at day 14 and day 60; matches breadth | Yes, in blood: ELISpot or intracellular staining against conserved-protein peptide pools. Mouse data are lymph node only | **Carry forward**: response marker and candidate correlate |
| Interferon-β and GM-CSF induction [S01-A, S08-A, S02-F] | Dose-responsive; separates PSLN-344 from PSLN-212; high at 16–36 h, mostly gone by 72 h | Yes: nasal lining fluid, blood interferon-signature within 24 h | **Carry forward** for target engagement and dose selection, with IL-6 and TNF alongside as safety monitors. Not an efficacy marker: adjuvant alone protects 0/7 |
| HAI and neutralising titre [S03-C, S03-D, S03-G, S03-H] | Restored 8-fold and 9-fold by PSLN-344. Silent on cross-subtype and day-2–3 protection. The ≥ 40 cut-off does not separate PSLN-344 from PSLN-212 against CA09 (5/5 and 5/5) | Yes, standard | **Keep**, because regulators expect it. Do not rely on it to show this product's benefit; report GMT ratios, not seroprotection rates |
| Lung resident-memory CD8 T cells [S05-I]; lung monocytes and dendritic cells [S01-D, S01-E] | Track arm ranking | No: tissue | Preclinical only |
| IgG2a ÷ IgG1 [S13-A to S13-D] | Restored (Table 2) | No human equivalent | Drop |
| Tfh:Tfr ratio [S04-B] | The stored ratio equals (100 − Foxp3%) ÷ Foxp3% exactly; it adds nothing to the Foxp3 block | Circulating Tfh is measurable | Optional, for the antibody arm only |
| NP tetramer [S05-A, S05-B] | Two animals per point; the annotation gives two different antigens | — | Not usable |

**What running it in patients would look like.** In Phase 1: interferon-axis markers at 6–24 h for dose selection; T-cell ELISpot against conserved internal proteins on days 7, 14, 28 and 180; HAI and neutralisation on day 28; nasal IgA, which the package never measured. The T-cell assay earns a larger role — bridging between age groups, or a Phase 2 endpoint — only if Study 1 shows a blood version predicts outcome animal by animal, Study 2 shows CD8 T cells are required, and a human challenge or efficacy study then links it to protection.

## 7. What the next studies have to establish

Gate 1 is Study 1, Gate 2 is Study 3, Gate 3 is Study 4; Studies 0 and 2 decide what can be claimed. Sequence them by how cheaply each can end the programme. Study 0 and the human-cell half of Study 4 take weeks. The single-dose manganese arm of Study 3 follows. Study 1 should be started at once, because animals of 20 months or more in both sexes have a long lead time. The second-species half of Study 4 waits until the others have passed. Durations are planning assumptions, not data: a decision on all three gates is realistic at roughly 9–12 months, with the day-180 durability cohort reading out later.

**Study 0 — Reconcile the source records.** No animals.

| Element | Specification |
|:--------------|:-----------------------------------------------------------|
| Must establish | Which record is correct for each conflict in §9; first S03-I vs S13-F, S06-C vs S06-D vs S15-D, S03-J vs S13-G, and the S03-B/F and S08-C headers |
| Population / comparators | None: a desk review of existing records |
| Endpoint | Every severity-A and severity-B item in §9 resolved against a primary record, with a corrected workbook |
| Readouts | Animal logs, raw cytometry and plate files against the workbook, cell by cell |
| Timing | 2–4 weeks, before anything else is shown outside the team |

**Study 1 — Confirmatory efficacy, dose and benchmark in aged mice (Gate 1).**

| Element | Specification |
|:--------------|:-----------------------------------------------------------|
| Must establish | (i) The survival advantage replicates with randomisation and blinded scoring, in both sexes. (ii) It needs Mn in the particle. (iii) It is at least as good as a licensed-type enhanced vaccine. (iv) The lowest fully effective dose. (v) How long it lasts |
| Population | BALB/c ≥ 20 months, both sexes, 16 per arm (power 94% at the least favourable observed rates; 74% if the true rates are 75% and 25%); young reference arm; 10 unchallenged age-matched sentinels per cohort, because background loss was 4/21 |
| Comparators | Sham; PSLN-212 20 µg; PSLN-344 5, 10 and 20 µg (Ifnb1 8.3-, 21.1- and 45.8-fold [S08-A]); Mn-only particle, Mn-matched; PSLN-212 with free Mn admixed; intramuscular vaccine with an oil-in-water adjuvant and at 4× antigen dose; PSLN-344 without antigen |
| Primary endpoint | Survival to day 21 after heterosubtypic challenge (H3N2 vaccine → 5× mLD50 PR8, the S06-A design) |
| Secondary endpoints | Survival after matched-strain challenge (the S03-I design), where the intramuscular benchmark should be at its best; weight nadir and area under the curve; clinical score; lung virus titre on days 3 and 6 after challenge in satellites (the package has none) |
| Readouts | From the same animals before challenge: blood IFN-γ ELISpot to conserved-protein peptides, serum HAI and neutralisation; nasal-wash IgA in satellites. Analysed animal by animal against outcome |
| Timing | Dose day 0; bleed days 7 and 13; challenge day 14, with separate cohorts challenged at days 90 and 180 |
| Pass | PSLN-344 beats PSLN-212 with the lower confidence bound of the survival difference above zero; it is not worse than the intramuscular benchmark against the matched strain and better against the heterosubtypic one; the Mn-only arm does not protect |

**Study 2 — What mediates protection.**

| Element | Specification |
|:--------------|:-----------------------------------------------------------|
| Must establish | Whether CD8 T cells are necessary, whether serum is sufficient, and whether lung-resident cells are enough. This decides which biomarker goes forward |
| Population | Aged mice vaccinated with PSLN-344 plus vaccine, 10–12 per arm |
| Comparators | Isotype control; CD8 depletion; CD4 depletion; FTY720 to block recirculation; CCR2 antagonist around dosing; naive aged recipients of day-14 immune serum |
| Endpoints | Survival, weight, lung virus titre |
| Readouts | Depletion efficiency; lung resident-memory and cross-reactive CD8 T cells; serum neutralisation of the challenge virus |
| Timing | Challenge at day 3 and at day 14 after one dose, matching S06-B and S06-A |
| Decision | If CD8 depletion removes protection, the T-cell marker in §6 goes forward. If immune serum transfers protection, antibody breadth and mucosal IgA assays take priority instead |

**Study 3 — Manganese disposition and respiratory/CNS safety (Gate 2).** Non-GLP pilot; GLP studies in two species only if it passes.

| Element | Specification |
|:--------------|:-----------------------------------------------------------|
| Must establish | Mn does not accumulate in olfactory bulb or brain; lung inflammation resolves; there is a margin of at least 10× over the lowest effective dose from Study 1; repeat dosing is tolerated |
| Population | Aged (≥ 20 months) and young mice, both sexes, 6–8 per arm per time point |
| Comparators | Vehicle; empty liposome; PSLN-212; PSLN-344 at 1×, 3× and 10× the lowest effective dose, single and three doses two weeks apart; intranasal MnCl₂, Mn-matched; cholera toxin as the CNS-inflammation control used in S10-A |
| Endpoints | Tissue Mn (olfactory bulb, striatum, cerebellum, lung, liver, blood); lung and CNS histopathology |
| Readouts | Lavage cell differential including neutrophils, lavage protein; lung and serum IL-6, TNF, CCL2, IFN-β; the S10-A brain transcript panel at more than one time; body weight and temperature; clinical pathology; autoantibodies at day 90 |
| Timing | 16 h, 72 h, and days 7, 14, 28 and 90 after the last dose |
| Pass | Brain Mn within the vehicle range by day 28; lung histology resolved by day 28; no adverse finding at 10× |

**Study 4 — Human relevance and delivery (Gate 3).**

| Element | Specification |
|:--------------|:-----------------------------------------------------------|
| Must establish | (a) Mn raises the CDN response in cells from older people, across common STING variants. (b) The adjuvant works in a second species through a device that could be used clinically |
| Population | (a) Blood monocytes/macrophages, and alveolar macrophages where obtainable, from donors ≥ 65 and 18–40 years, at least 10 each, STING-genotyped. (b) Ferrets, or aged macaques if (a) is positive |
| Comparators | (a) PSLN-212, PSLN-344, cGAMP, empty liposome, MnCl₂, across dose. (b) Antigen alone; PSLN-344 by nasal spray; PSLN-344 by lower-airway aerosol; licensed enhanced intramuscular vaccine |
| Endpoints | (a) IFN-β and GM-CSF output. (b) Virus shedding after challenge, fever and weight |
| Readouts | (a) CXCL10, IL-6, TNF. (b) HAI and neutralisation, nasal IgA, blood T-cell ELISpot, safety observations |
| Timing | (a) 6, 16 and 24 h (16 h was the mouse readout [S01-A]). (b) Days 0, 1, 7, 14, 28; challenge around day 28; a day-180 subset |
| Pass | (a) PSLN-344 at least 2× PSLN-212 for IFN-β in older donors' cells (the aged-mouse ratio was 2.2× [S01-A]) without disproportionate IL-6 or TNF. (b) Activity by a route a person could receive |

**Study 5 — Product definition.** Runs alongside; small.

| Element | Specification |
|:--------------|:-----------------------------------------------------------|
| Must establish | Mn content and Mn:CDN ratio; reproducibility of loading (the three measurements span 49–59% [S08-B]); particle size and charge; stability of the lyophilised product; whether the effect holds with split or recombinant antigen |
| Population / comparators | Aged mice; whole inactivated virus against split and recombinant-HA antigen, each with PSLN-344 |
| Endpoints and readouts | HAI, cross-reactive T cells, heterosubtypic survival; standard particle analytics |
| Timing | Analytics continuous; the antigen-format experiment on the Study 1 schedule |

**If the gates pass**, the first clinical study is a dose-escalation in adults 18–49 and then ≥ 65, against a licensed enhanced vaccine, with safety primary and the §6 markers as pharmacodynamic and exploratory endpoints.

## 8. What I considered and ruled out

**Decisions.**

- *Go straight to IND-enabling work.* Ruled out: §4.
- *Stop.* Ruled out: the effect survives the least favourable reading of the records (58/72 against 13/73), nothing in the package is an adverse safety finding for PSLN-344, and the open questions can be answered with a bounded package.
- *Carry PSLN-212 instead.* Ruled out for older adults: 9/73 in aged animals.
- *Another formulation or regimen from the package* — more PSLN-212, two doses, R848, the cGAMP liposome, added GM-CSF. Ruled out: §3.4.
- *Position PSLN-344 for all ages.* Ruled out: no advantage in young mice (24/24 against 24/24).

**Explanations for the protection.**

- *An interferon-driven antiviral state.* Ruled out: adjuvant alone 0/7 [S15-H].
- *Neutralising antibody as the whole story.* Ruled out for cross-subtype and early protection (§5); not ruled out for matched strains.
- *More CDN per dose in PSLN-344.* Ruled out: loading is no higher [S08-B].
- *Better uptake by the airway epithelium.* Not resolved. As printed, S08-C says Mn cuts uptake (type II cells 15.8 vs 3.8%; type I cells 13.8 vs 3.0%). But the printed headers put type I uptake of the Mn-free particle at 13.8%, against 3.8% for the same condition in S01-B. Swapping the two middle headers reconciles the blocks and gives no difference (15.8 vs 13.8% and 3.8 vs 3.0%; p = 0.25 and 0.20). I treat the headers as transposed and rest nothing on the block.
- *A BALB/c peculiarity.* Ruled out on the face of S15-L and S15-N, though their challenge virus is not stated and some weight traces in S15-M are shared with other blocks (§9).
- *Dependence on, or interference from, prior influenza exposure.* Ruled out within one model: 6/7 with or without prior PR8 [S06-E, S06-F at rows 71–105]. The "imprinted" animals are survivors of a 1× LD50 infection, so that comparison carries selection.
- *Background deaths explaining the day-60 losses.* Cannot be separated: 4/21 unchallenged animals died.

**Biomarkers.** Table 3.

**Data set aside.** S06-D (identical to S06-C); S11-A and S11-B (shared values); S07-C (both columns carry the same label); S05-A and S05-B (two animals per point, contradictory annotation); S08-A "PSLN-344/R848" (a preparation not defined anywhere); S08 rows 89–101 (13 unlabelled values); S03-B and S03-F as printed (recomputed instead).

**Analysis choices.** I did not pool immunology across blocks. I did not impute the undated S03-J animal. I report Fisher as well as log-rank because several arms have no events. I did not average body weights by day, because dead animals are blank in sham arms and carried forward in adjuvant arms.

## 9. Data-integrity findings the committee will run into

Severity: **A** changes a number in the case; **B** removes a block from use; **C** needs correcting but changes nothing here.

| # | Where | Finding | Handling | Sev. |
|:----|:---------------|:----------------------------------------------|:---------------------------|:----:|
| 1 | S03-I vs S13-F | PSLN-212 recorded 0/7, deaths on days 5, 5, 5, 6, 6, 6, 6, earlier than sham. Weights show 7 animals weighed on day 10 and 3 at 95–99% on day 14. S13-F also carries a "Naive" arm that S03-I lacks, and lacks CMP-204 | Both readings carried; 3/7 used in the least-favourable analysis | A |
| 2 | S06-D vs S06-C | All 28 rows identical, for a day-3 and a day-14 challenge. Weights for the day-3 experiment [S15-D] imply PSLN-344 5/7 and young PSLN-212 5/7 | Counted once, as S06-C; S15-D counts used in the least-favourable analysis | A |
| 3 | S03-J vs S13-G | Header says n = 9; 10 rows per arm; one PSLN-344 row has no day; longest day is 21 against a stated 22. S13-G arms are PSLN-344, Sham, Naive; S03-J arms are Sham, PSLN-212, PSLN-344, and the "Sham" weights (4/10 back above 95% on day 14) do not fit the "Sham" survival (1/10), which instead matches the weight block's "Naive" arm (1/10) | PSLN-344 counted 9/9; comparator identity flagged | A |
| 4 | S06-E (r34–68) vs S15-E; S06-G vs S15-G; S06-C vs S15-C; S15-L vs S15-M | One-animal disagreements between survival rows and weights (Table 1, last column) | Survival rows used; weights used for the least-favourable analysis | A |
| 5 | S03-B, S03-F | Ratio columns rotated one place against S13-A to S13-D | Recomputed from S13 | A |
| 6 | S06-E, S06-F, S06-G | "Untreated" is unchallenged; 4/21 died | Used as background mortality | A |
| 7 | S15-C vs S15-I | PSLN-344 weight traces share 40 of 49 post-baseline values with the day-3 "Vaccine+PSLN-344" arm; in S15-C one animal jumps from 77.9% to 90.1% between days 12 and 14 | S15-C PSLN-344 weights not used | B |
| 8 | S15-M vs S09-E; S15-A vs S15-M | Young C57BL/6 PSLN-212 traces match young BALB/c PSLN-344 traces in 6 of 7 animals; 2 aged PSLN-344 traces shared | Flagged; S15-M young weights not used | B |
| 9 | S11-B vs S11-A | 35 of 100 values identical cell for cell (first one or two animals of every group), for two different cell types | Neither used | B |
| 10 | S07-C | Both columns labelled "Ly6C-CD206+" | Not used | B |
| 11 | S05-A, S05-B | Header n = 3, two values per point; annotation names both ovalbumin and the bivalent vaccine as antigen; NP366–374 is an H-2Dᵇ-restricted epitope and the strain is not stated. S05-I ("vaccinated as in S05-A") inherits the antigen ambiguity | S05-A and S05-B not used; S05-I used, as its readout is not antigen-specific | B |
| 12 | S08-C vs S01-B | Headers conflict with S01-B on the shared condition | Treated as transposed; nothing rests on it | B |
| 13 | S09-A | Second panel labelled 16 h; values are the S01-A 72 h data. Control is "PBS" here and "Sham" in S01-A with identical values | Treated as 72 h | C |
| 14 | All weight blocks | Dead animals are blank in sham arms and carried forward unchanged in adjuvant arms. The annotation itself describes PSLN-212 observations as "declining" in S13-F and S15-A, where the workbook has repeated values | Per-animal reading: a value repeating unchanged to day 14 counted as dead | C |
| 15 | S13-E; S09-F; S08-D | S13-E header n = 5, 7 per arm. S09-F sham has 7 rows against 8 animals in S09-G (the annotation attributes the shortfall to S09-B). S08-D PSLN-212/R848 lacks one day-10 value | Counts taken from the rows | C |
| 16 | S09-C; S09-B | S09-C day-12 row identical for PSLN-212Y and PSLN-344Y. S09-B enters six sham deaths on days 6–7, but 7 of 8 sham animals have a day-8 weight | Outcome unaffected (all sham die, all adjuvanted survive) | C |
| 17 | S08-A; S08 rows 89–101 | "PSLN-344/R848" is not a defined preparation; 13 values with no labels | Not used | C |
| 18 | S03-C, S03-G | HAI entered as 0 below the assay floor | Set to 5 for GMT | C |
| 19 | S04-B | Tfh:Tfr is an arithmetic restatement of the Foxp3 block | Foxp3 block reported | C |
| 20 | S06 | Labels S06-E and S06-F each used twice | Cited by row range | C |
| 21 | S15-L, S15-N; S06-E (r71–105); S07-B, S11-E, S13-H, S14-A; S08-A; S02-C, S02-E | Challenge virus, challenge day, sampling time, animal age or the PTX arm's adjuvant not stated | Noted where used | C |

## Files

- `PSLN-344_recommendation.md` / `.docx` — this memo.
- `PSLN-344_numbers_ledger.xlsx` — every cited number with block, cells, n and reduction; per-block statistics for all 15 sheets; survival tests; weight-based cross-check; the audit above with evidence.
- `figures/` — Figures 1–3.
- `analysis/` — the scripts that produce every number and figure from the workbook.

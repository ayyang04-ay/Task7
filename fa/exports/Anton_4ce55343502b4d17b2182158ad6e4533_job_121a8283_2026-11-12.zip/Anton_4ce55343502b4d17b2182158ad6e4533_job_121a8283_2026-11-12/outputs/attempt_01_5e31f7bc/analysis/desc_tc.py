import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',1000)
rows=[]
for k in ['S01-D','S01-E','S02-F','S05-A','S05-B','S07-A','S08-A','S08-D','S11-A','S11-B','S11-D']:
    for g,df in TC[k].items():
        for day,row in df.iterrows():
            v=[x for x in row.tolist() if x is not None and not (isinstance(x,float) and np.isnan(x))]
            rows.append(dict(block=k,group=g,day=day,**desc(v)))
D=pd.DataFrame(rows)
D.to_csv(os.path.join(WORK,'desc_tc.csv'),index=False)
for k,d in D.groupby('block',sort=False):
    print('=====',k)
    p=d.pivot(index='day',columns='group',values='mean')
    p=p.loc[list(dict.fromkeys(d.day))][list(dict.fromkeys(d.group))]
    print('MEAN'); print(p.round(2).to_string())
    p=d.pivot(index='day',columns='group',values='sd'); p=p.loc[list(dict.fromkeys(d.day))][list(dict.fromkeys(d.group))]
    print('SD'); print(p.round(2).to_string())
    p=d.pivot(index='day',columns='group',values='n'); p=p.loc[list(dict.fromkeys(d.day))][list(dict.fromkeys(d.group))]
    print('N'); print(p.to_string())
print("===== S09-A (log10 relative expression; n=3): mean of log10, back-transformed geometric mean fold")
for nm,P in [('panel1 (cols A-V; Ifnb1 matches S01-A 16h)',S09A1),('panel2 (cols X-AS; labelled 16h; Ifnb1 matches S01-A 72h)',S09A2)]:
    print(nm)
    tab={}
    for an,d in P.items():
        tab[an]={g:10**np.mean(v) for g,v in d.items()}
    print(pd.DataFrame(tab).T.round(2).to_string())
    tab={}
    for an,d in P.items():
        tab[an]={g:np.mean(v) for g,v in d.items()}
    print('mean log10'); print(pd.DataFrame(tab).T.round(3).to_string())
    tab={}
    for an,d in P.items():
        tab[an]={g:np.std(v,ddof=1) for g,v in d.items()}
    print('sd log10'); print(pd.DataFrame(tab).T.round(3).to_string())

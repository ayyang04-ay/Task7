import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',2000)
WB_ = ['S13-F','S13-G','S15-A','S15-B','S15-C','S15-D','S15-E','S15-F','S15-G','S15-I','S15-J','S15-K','S15-M','S15-O','S09-C','S09-E','S09-G']
def classify(series, days):
    """returns dict: status ('survivor','dead'), last_obs_day, nadir"""
    v=[None if (x is None or (isinstance(x,float) and np.isnan(x))) else float(x) for x in series]
    nn=[i for i,x in enumerate(v) if x is not None]
    last=nn[-1]
    vals=[v[i] for i in nn]
    nadir=min(vals)
    if days[last]<days[-1]:
        return dict(status='dead',last_day=days[last],nadir=nadir,final=v[last],how='blank')
    j=last
    while j>0 and v[j-1]==v[last]: j-=1
    if j<last:
        # flat tail: treat as dead (LOCF) irrespective of level if tail length>=2 repeats (3 identical) or value<90
        ntail=last-j+1
        if v[last]<90 or ntail>=3:
            return dict(status='dead',last_day=days[j],nadir=nadir,final=v[last],how=f'flat x{ntail}')
    return dict(status='survivor',last_day=days[last],nadir=nadir,final=v[last],how='')
rows=[]
for k in WB_:
    for g,df in TC[k].items():
        days=list(df.index)
        for c in df.columns:
            r=classify(df[c].tolist(),days); r.update(block=k,group=g,animal=c); rows.append(r)
W=pd.DataFrame(rows)
W.to_csv(os.path.join(WORK,'weights_animals.csv'),index=False)
summ=W.groupby(['block','group'],sort=False).apply(lambda d: pd.Series(dict(n=len(d),surv=int((d.status=='survivor').sum()),
      nadir_mean_all=d.nadir.mean(), nadir_sd_all=d.nadir.std(ddof=1),
      nadir_mean_surv=d[d.status=='survivor'].nadir.mean() if (d.status=='survivor').any() else np.nan,
      nadir_sd_surv=d[d.status=='survivor'].nadir.std(ddof=1) if (d.status=='survivor').sum()>1 else np.nan,
      final_mean_surv=d[d.status=='survivor'].final.mean() if (d.status=='survivor').any() else np.nan,
      dead_how='; '.join(f"{a}:{h}@d{int(l)}({f})" for a,h,l,f in zip(d[d.status=='dead'].animal,d[d.status=='dead'].how,d[d.status=='dead'].last_day,d[d.status=='dead'].final)))))
print(summ.round(2).to_string())
summ.to_csv(os.path.join(WORK,'weights_summary.csv'))

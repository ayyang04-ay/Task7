import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
"""Helpers that compute every number used in the memo directly from the workbook
and log (text, block, cell range, groups, n, reduction) for the numbers ledger."""
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import numpy as np, pandas as pd
from scipy import stats as _st

TITRE = {'S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}
HAI = {'S03-C','S03-G'}
LOG=[]   # ledger rows in order of use
def _log(text, block, groups, n, reduction, loc=None):
    loc = loc or META.get(block,{}).get('loc','')
    LOG.append(dict(value_as_printed=text, block=block, cells=loc, groups=groups, n=n, reduction=reduction))
    return text
def fp(p):
    if p is None or (isinstance(p,float) and np.isnan(p)): return 'n/a'
    if p<0.0001: return '<0.0001'
    if p<0.001: return f"{p:.4f}"
    if p<0.01: return f"{p:.3f}"
    return f"{p:.2f}" if p>=0.095 else f"{p:.3f}"
def fnum(x,dec=1):
    if abs(x)>=1000: return f"{x:,.0f}"
    return f"{x:.{dec}f}"
# ---- simple blocks
def ms(block, group, dec=1):
    v=np.array(B[block][group],float)
    return _log(f"{fnum(v.mean(),dec)} ± {fnum(v.std(ddof=1),dec)}", block, group, len(v), 'arithmetic mean ± SD of per-animal values')
def mean(block, group, dec=1):
    v=np.array(B[block][group],float)
    return _log(fnum(v.mean(),dec), block, group, len(v), 'arithmetic mean of per-animal values')
def rng_(block, group, dec=0):
    v=np.array(B[block][group],float)
    return _log(f"{fnum(v.min(),dec)}–{fnum(v.max(),dec)}", block, group, len(v), 'min–max of per-animal values')
def gmt(block, group):
    fl=5 if block in HAI else None
    g=gmean(B[block][group],floor=fl)
    return _log(fnum(g,0), block, group, len(B[block][group]), 'geometric mean of per-animal titres' + ('; entries of 0 (<1:10) set to 5' if block in HAI else ''))
def gmt_ci(block, group):
    fl=5 if block in HAI else None
    g,lo,hi=gm_ci(B[block][group],floor=fl)
    return _log(f"{fnum(g,0)} ({fnum(lo,0)}–{fnum(hi,0)})", block, group, len(B[block][group]), 'geometric mean (95% CI, t on log scale)')
def fold(block, a, b, dec=1):
    if block in TITRE:
        fl=5 if block in HAI else None
        r=gmean(B[block][a],floor=fl)/gmean(B[block][b],floor=fl); red='ratio of geometric means'
    else:
        r=np.mean(B[block][a])/np.mean(B[block][b]); red='ratio of arithmetic means'
    return _log(f"{r:.{dec}f}", block, f"{a} ÷ {b}", f"{len(B[block][a])}/{len(B[block][b])}", red)
def pct(block, a, b):
    if block in TITRE:
        fl=5 if block in HAI else None
        r=100*gmean(B[block][a],floor=fl)/gmean(B[block][b],floor=fl); red='ratio of geometric means ×100'
    else:
        r=100*np.mean(B[block][a])/np.mean(B[block][b]); red='ratio of arithmetic means ×100'
    return _log(f"{r:.0f}%", block, f"{a} ÷ {b}", f"{len(B[block][a])}/{len(B[block][b])}", red)
_tk_cache={}
def tuk(block, a, b):
    if block not in _tk_cache:
        log = block in TITRE; fl=5 if block in HAI else None
        _tk_cache[block]=anova_tukey(B[block],log=log,floor=fl)[2]
    t=_tk_cache[block]
    r=t[((t.a==a)&(t.b==b))|((t.a==b)&(t.b==a))].iloc[0]
    return _log(fp(r.p_tukey), block, f"{a} vs {b}", f"{len(B[block][a])}/{len(B[block][b])}", "one-way ANOVA across all groups in the block + Tukey HSD" + (" on log10 titres" if block in TITRE else ""))
def wel(block, a, b):
    log = block in TITRE; fl=5 if block in HAI else None
    p=welch(B[block][a],B[block][b],log=log,floor=fl)[1]
    return _log(fp(p), block, f"{a} vs {b}", f"{len(B[block][a])}/{len(B[block][b])}", "Welch t test, two-sided" + (" on log10 titres" if log else ""))
def stu(block,a,b):
    p=student(B[block][a],B[block][b])[1]
    return _log(fp(p), block, f"{a} vs {b}", f"{len(B[block][a])}/{len(B[block][b])}", "Student t test, two-sided")
# ---- timecourses
def tc(block, group, day, dec=1, sd=True):
    v=np.array([x for x in TC[block][group].loc[day].tolist() if x is not None and not (isinstance(x,float) and np.isnan(x))],float)
    txt=f"{fnum(v.mean(),dec)} ± {fnum(v.std(ddof=1),dec)}" if sd else fnum(v.mean(),dec)
    return _log(txt, block, f"{group}, time {day}", len(v), 'arithmetic mean' + (' ± SD' if sd else '') + ' of per-animal values at that time')
def tcfold(block, a, b, day, dec=1):
    va=TC[block][a].loc[day].astype(float).mean(); vb=TC[block][b].loc[day].astype(float).mean()
    return _log(f"{va/vb:.{dec}f}", block, f"{a} ÷ {b}, time {day}", '', 'ratio of arithmetic means')
def tcwel(block,a,b,day):
    p=welch(TC[block][a].loc[day].astype(float).values, TC[block][b].loc[day].astype(float).values)[1]
    return _log(fp(p), block, f"{a} vs {b}, time {day}", '', 'Welch t test, two-sided')
# ---- S09-A
def s09(panel, analyte, group, dec=0):
    P = S09A1 if panel==1 else S09A2
    v=np.array(P[analyte][group],float); g=10**v.mean()
    loc = 'S09!A2:V9' if panel==1 else 'S09!X2:AS9'
    return _log(f"{g:.{dec}f}", 'S09-A (panel %d)'%panel, f"{analyte}, {group}", len(v), '10^(mean of log10 values) = geometric-mean fold over untreated', loc)
# ---- survival
def _sv(block, group):
    d=SV[block].dropna(subset=['time']); x=d[d.group==group]
    return x.time.values.astype(float), x.event.values.astype(int)
def sv(block, group):
    t,e=_sv(block,group)
    return _log(f"{int((e==0).sum())}/{len(e)}", block, group, len(e), 'survivors (event = 0) / animals with a recorded day, at last observation day')
def svci(block, group):
    t,e=_sv(block,group); s=int((e==0).sum()); n=len(e); lo,hi=cp_ci(s,n)
    return _log(f"{100*s/n:.0f}% ({100*lo:.0f}–{100*hi:.0f})", block, group, n, 'survival % with exact Clopper–Pearson 95% CI')
def deaths(block, group):
    t,e=_sv(block,group)
    return _log(', '.join(str(int(x)) for x in sorted(t[e==1])), block, group, len(e), 'days of death (event = 1)')
def lr(block, a, b):
    ta,ea=_sv(block,a); tb,eb=_sv(block,b)
    return _log(fp(logrank(ta,ea,tb,eb)[1]), block, f"{a} vs {b}", f"{len(ea)}/{len(eb)}", 'log-rank (Mantel–Cox), two-sided')
def fx(block, a, b):
    ta,ea=_sv(block,a); tb,eb=_sv(block,b)
    return _log(fp(fisher(int((ea==0).sum()),len(ea),int((eb==0).sum()),len(eb))), block, f"{a} vs {b}", f"{len(ea)}/{len(eb)}", 'Fisher exact on survivors at last observation day, two-sided')
# ---- weights
_W=None
def _wload():
    global _W
    if _W is None: _W=pd.read_csv(os.path.join(WORK,'weights_animals.csv'))
    return _W
def wsv(block, group):
    W=_wload(); d=W[(W.block==block)&(W.group==group)]
    return _log(f"{int((d.status=='survivor').sum())}/{len(d)}", block, group, len(d), "animals with a non-blank, non-carried-forward day-14 weight / animals (an animal whose last value repeats unchanged to day 14 at <90%, or ≥3 times, is counted dead)")
def wnadir(block, group, survivors=True, dec=1):
    W=_wload(); d=W[(W.block==block)&(W.group==group)]
    if survivors: d=d[d.status=='survivor']
    return _log(f"{d.nadir.mean():.{dec}f} ± {d.nadir.std(ddof=1):.{dec}f}", block, group + (' (survivors)' if survivors else ''), len(d), "per-animal lowest weight (% of own day-0 weight); mean ± SD")
# ---- custom
CUSTOM={}
def reg(key, text, block, groups, n, reduction, loc=''):
    CUSTOM[key]=dict(text=text, block=block, groups=groups, n=n, reduction=reduction, loc=loc)
def c(key):
    d=CUSTOM[key]
    loc = d['loc'] or META.get(d['block'],{}).get('loc') or "several blocks - cell ranges are listed per block in sheets 'Survival by arm' and 'Group stats'"
    return _log(d['text'], d['block'], d['groups'], d['n'], d['reduction'], loc)

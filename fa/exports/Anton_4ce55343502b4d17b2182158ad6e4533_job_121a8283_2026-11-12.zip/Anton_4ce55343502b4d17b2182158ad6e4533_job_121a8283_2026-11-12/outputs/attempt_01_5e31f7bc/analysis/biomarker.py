import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import numpy as np, pandas as pd
from scipy import stats
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
TITRE = {'S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}
HAI={'S03-C','S03-G'}
core=['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']
rows=[]
for k,d in B.items():
    if all(g in d for g in core):
        if k in TITRE:
            vals=[gmean(d[g],floor=5 if k in HAI else None) for g in core]; red='GMT'
        else:
            vals=[np.mean(d[g]) for g in core]; red='mean'
        rank=stats.rankdata(vals)
        mono = 'increasing' if list(rank)==[1,2,3,4] else ('decreasing' if list(rank)==[4,3,2,1] else 'non-monotone')
        rows.append(dict(block=k,red=red,Sham=vals[0],PSLN212=vals[1],PSLN344=vals[2],Young212=vals[3],order=mono,
                         pct_of_young_344=100*vals[2]/vals[3], pct_of_young_212=100*vals[1]/vals[3], fold_344_over_212=vals[2]/vals[1]))
# timecourse peaks
for k,day in [('S01-D',4),('S01-E',4),('S11-D',2)]:   # S11-A left out: it shares 35 of 100 values with S11-B
    d=TC[k]
    names={'Sham':'Sham' if 'Sham' in d else 'Vaccine','PSLN-212':'PSLN-212','PSLN-344':'PSLN-344','PSLN-212(Y)':'PSLN-212(Y)'}
    vals=[np.mean(d[names[g]].loc[day].astype(float)) for g in core]
    rank=stats.rankdata(vals)
    mono = 'increasing' if list(rank)==[1,2,3,4] else ('decreasing' if list(rank)==[4,3,2,1] else 'non-monotone')
    rows.append(dict(block=f'{k}@d{day}',red='mean',Sham=vals[0],PSLN212=vals[1],PSLN344=vals[2],Young212=vals[3],order=mono,
                     pct_of_young_344=100*vals[2]/vals[3], pct_of_young_212=100*vals[1]/vals[3], fold_344_over_212=vals[2]/vals[1]))
R=pd.DataFrame(rows)
print(R.round(2).to_string())
print(R.order.value_counts())
R.to_csv(os.path.join(WORK,'core4_readouts.csv'),index=False)
# 3-group blocks (no sham): S13-A..D
for k in ['S13-A','S13-B','S13-C','S13-D']:
    d=B[k]; print(k,{g:round(gmean(d[g]),1) for g in d})
# correct IgG2a/IgG1 ratios
for a,b,lab in [('S13-A','S13-B','CA09'),('S13-C','S13-D','Aichi')]:
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        r=np.array(B[a][g])/np.array(B[b][g])
        print(lab,g,'IgG2a/IgG1 per-animal (row-paired) mean',round(r.mean(),2),'sd',round(r.std(ddof=1),2),'gmean',round(gmean(r),2),'| ratio of GMTs',round(gmean(B[a][g])/gmean(B[b][g]),2))
    r3=np.array(B[a]['PSLN-344'])/np.array(B[b]['PSLN-344']); r2=np.array(B[a]['PSLN-212'])/np.array(B[b]['PSLN-212']); ry=np.array(B[a]['PSLN-212(Y)'])/np.array(B[b]['PSLN-212(Y)'])
    print('   welch log ratio 344 vs 212 p=',welch(r3,r2,log=True)[1],' 344 vs young p=',welch(r3,ry,log=True)[1], 'MWU 344 vs 212', mwu(r3,r2)[1])

import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',2000)
TITRE = {'S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}
HAI = {'S03-C','S03-G'}
out=[]
for k,d in B.items():
    if len(d)<2: continue
    log = k in TITRE
    fl = 5 if k in HAI else None
    names=list(d)
    if len(d)>=3:
        F,p,tk=anova_tukey(d,log=log,floor=fl)
        for _,r in tk.iterrows():
            a,b=r.a,r.b
            tw,pw=welch(d[a],d[b],log=log,floor=fl)
            try: u,pm=mwu(d[a],d[b])
            except Exception as e: pm=np.nan
            out.append(dict(block=k,scale='log10' if log else 'linear',a=a,b=b,mean_a=np.mean(d[a]),mean_b=np.mean(d[b]),anova_p=p,tukey_p=r.p_tukey,welch_p=pw,mwu_p=pm))
    else:
        a,b=names
        t,ps=student(d[a],d[b]) if not log else (np.nan,np.nan)
        tw,pw=welch(d[a],d[b],log=log,floor=fl)
        u,pm=mwu(d[a],d[b])
        out.append(dict(block=k,scale='log10' if log else 'linear',a=a,b=b,mean_a=np.mean(d[a]),mean_b=np.mean(d[b]),anova_p=np.nan,tukey_p=np.nan,student_p=ps,welch_p=pw,mwu_p=pm))
T=pd.DataFrame(out)
T.to_csv(os.path.join(WORK,'tests_simple.csv'),index=False)
key=T[((T.a.isin(['PSLN-212','PSLN-344']))&(T.b.isin(['PSLN-344','PSLN-212'])))|((T.a=='PSLN-344')&(T.b=='PSLN-212(Y)'))|((T.a=='Sham')&(T.b=='PSLN-344'))]
print(key.to_string(float_format=lambda x: f"{x:.4g}"))

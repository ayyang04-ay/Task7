import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from ledger import *
import ledger
_sv = ledger._sv
from statsmodels.stats.contingency_tables import StratifiedTable
from scipy.optimize import curve_fit

AGED10=['S03-I','S03-J','S06-A','S06-B','S06-C','S06-E(r34-68)','S06-F(r34-68)','S06-G','S15-L','S15-N']
IMPR=[('S06-E(r71-105)','Naive'),('S06-E(r71-105)','Imprinting'),('S06-F(r71-105)','Naive'),('S06-F(r71-105)','Imprinting')]
def cnt(block,group):
    t,e=_sv(block,group); return int((e==0).sum()), len(e)
def tot(pairs):
    a=b=0
    for blk,g in pairs:
        s,n=cnt(blk,g); a+=s; b+=n
    return a,b
_SUP=str.maketrans('-0123456789','⁻⁰¹²³⁴⁵⁶⁷⁸⁹')
def sci(p):
    m,e=f"{p:.0e}".split('e'); return f"{m}×10{str(int(e)).translate(_SUP)}"
def power_fisher(p1,p2,n,alpha=0.05):
    from scipy import stats as st
    pw=0
    for a in range(n+1):
        pa=st.binom.pmf(a,n,p1)
        for b in range(n+1):
            pb=st.binom.pmf(b,n,p2)
            if pa*pb<1e-12: continue
            if st.fisher_exact([[a,n-a],[b,n-b]])[1]<alpha: pw+=pa*pb
    return pw
def fmt_ci(a,b):
    lo,hi=cp_ci(a,b); return f"{a}/{b} ({100*a/b:.0f}%; 95% CI {100*lo:.0f}–{100*hi:.0f})"
lab10 = "S03-I, S03-J, S06-A, S06-B, S06-C, S06-E(r34–68), S06-F(r34–68), S06-G, S15-L, S15-N"
a344=tot([(b,'PSLN-344') for b in AGED10]); a212=tot([(b,'PSLN-212') for b in AGED10]); ash=tot([(b,'Sham') for b in AGED10])
reg('aged10_344', fmt_ci(*a344), lab10, 'PSLN-344 (aged ≥20 mo)', a344[1], 'sum of survivors / sum of animals over 10 experiments (S06-D excluded as a duplicate of S06-C; the undated S03-J row excluded); exact CI on the pooled proportion')
reg('aged10_212', fmt_ci(*a212), lab10, 'PSLN-212 (aged ≥20 mo)', a212[1], 'sum of survivors / sum of animals over the same 10 experiments')
reg('aged10_344_short', f"{a344[0]}/{a344[1]}", lab10, 'PSLN-344 (aged ≥20 mo)', a344[1], 'sum of survivors / sum of animals over 10 experiments')
reg('aged10_212_short', f"{a212[0]}/{a212[1]}", lab10, 'PSLN-212 (aged ≥20 mo)', a212[1], 'sum of survivors / sum of animals over 10 experiments')
reg('aged10_sham', f"{ash[0]}/{ash[1]}", lab10, 'Sham (aged ≥20 mo)', ash[1], 'sum of survivors / sum of animals over the same 10 experiments')
i344=tot([(b,f'{p}+PSLN-344') for b,p in IMPR]); i212=tot([(b,f'{p}+PSLN-212') for b,p in IMPR])
reg('impr_344', f"{i344[0]}/{i344[1]}", 'S06-E(r71–105), S06-F(r71–105)', 'Naive+PSLN-344 and Imprinting+PSLN-344', i344[1], 'sum over the four 14-month arms')
reg('impr_212', f"{i212[0]}/{i212[1]}", 'S06-E(r71–105), S06-F(r71–105)', 'Naive+PSLN-212 and Imprinting+PSLN-212', i212[1], 'sum over the four 14-month arms')
reg('all14_344', f"{a344[0]+i344[0]}/{a344[1]+i344[1]}", lab10+' + S06-E/F(r71–105)', 'PSLN-344, all 14 head-to-head strata', a344[1]+i344[1], 'sum of survivors / sum of animals')
reg('all14_212', f"{a212[0]+i212[0]}/{a212[1]+i212[1]}", lab10+' + S06-E/F(r71–105)', 'PSLN-212, all 14 head-to-head strata', a212[1]+i212[1], 'sum of survivors / sum of animals')
reg('all14_344_pct', f"{100*(a344[0]+i344[0])/(a344[1]+i344[1]):.0f}%", lab10+' + S06-E/F(r71–105)', 'PSLN-344', a344[1]+i344[1], 'pooled proportion')
reg('all14_212_pct', f"{100*(a212[0]+i212[0])/(a212[1]+i212[1]):.0f}%", lab10+' + S06-E/F(r71–105)', 'PSLN-212', a212[1]+i212[1], 'pooled proportion')
# stratified tests aged10
strata=[]; tabs=[]
for b in AGED10:
    t3,e3=_sv(b,'PSLN-344'); t2,e2=_sv(b,'PSLN-212'); strata.append((t3,e3,t2,e2))
    tabs.append(np.array([[int((e3==0).sum()),int((e3==1).sum())],[int((e2==0).sum()),int((e2==1).sum())]]))
chi,p,O,E=logrank_strat(strata)
reg('aged10_slr_p', sci(p), lab10, 'PSLN-344 vs PSLN-212', f"{a344[1]}/{a212[1]}", f'log-rank stratified by experiment (chi-square {chi:.1f}, 1 df)')
cm=StratifiedTable(tabs).test_null_odds(correction=True)
reg('aged10_cmh_p', sci(cm.pvalue), lab10, 'PSLN-344 vs PSLN-212', '', f'Cochran–Mantel–Haenszel, stratified by experiment (chi-square {cm.statistic:.1f})')
# least favourable reading
worst=[((7,0),(3,4)),((9,0),(3,7)),((6,1),(1,6)),((5,2),(0,7)),((5,2),(2,5)),((5,2),(1,6)),((5,2),(1,6)),((4,3),(0,7)),((6,1),(0,7)),((6,1),(2,5))]   # 5th stratum: the duplicated rgH5N1 record, read from the day-3 weight block S15-D
w344=(sum(t[0][0] for t in worst), sum(sum(t[0]) for t in worst)); w212=(sum(t[1][0] for t in worst), sum(sum(t[1]) for t in worst))
cmw=StratifiedTable([np.array(t) for t in worst]).test_null_odds(correction=True)
reg('worst_344', f"{w344[0]}/{w344[1]}", lab10+' with S13-F, S15-C, S15-D, S15-E, S15-G', 'PSLN-344', w344[1], 'for each experiment, the lower of (time-to-event count, weight-block count) for PSLN-344; for the duplicated S06-C/S06-D record, the day-3 weight block S15-D (5/7)')
reg('worst_212', f"{w212[0]}/{w212[1]} ({100*w212[0]/w212[1]:.0f}%)", lab10+' with S13-F, S15-C, S15-E', 'PSLN-212', w212[1], 'for each experiment, the higher of (time-to-event count, weight-block count) for PSLN-212: S03-I 3/7, S06-E(r34–68) 1/7 from weights; others as recorded')
reg('worst_cmh_p', sci(cmw.pvalue), lab10, 'PSLN-344 vs PSLN-212, least favourable reading', '', f'Cochran–Mantel–Haenszel, stratified by experiment (chi-square {cmw.statistic:.1f}; p = {cmw.pvalue:.1e})')
reg('sign_p', '0.002', lab10, 'PSLN-344 > PSLN-212 in 10 of 10 experiments', 10, 'two-sided sign test, 2 × 0.5^10')
# paired with young
P9=['S03-I','S06-A','S06-B','S06-C','S06-E(r34-68)','S06-F(r34-68)','S06-G','S15-L','S15-N']
lab9="S03-I, S06-A, S06-B, S06-C, S06-E(r34–68), S06-F(r34–68), S06-G, S15-L, S15-N"
y=tot([(b,'PSLN-212(Y)') for b in P9]); x=tot([(b,'PSLN-344') for b in P9])
reg('p9_344', f"{x[0]}/{x[1]} ({100*x[0]/x[1]:.0f}%)", lab9, 'PSLN-344 aged', x[1], 'sum over the nine experiments that also carry a young PSLN-212 arm')
reg('p9_young', f"{y[0]}/{y[1]} ({100*y[0]/y[1]:.0f}%)", lab9, 'PSLN-212(Y)', y[1], 'sum over the same nine experiments')
reg('p9_fisher', fp(fisher(x[0],x[1],y[0],y[1])), lab9, 'PSLN-344 aged vs PSLN-212 young', '', 'Fisher exact on pooled counts')
# d60
D60=['S06-E(r34-68)','S06-F(r34-68)','S06-G']; lab60='S06-E(r34–68), S06-F(r34–68), S06-G'
for g,key in [('PSLN-344','d60_344'),('PSLN-212','d60_212'),('Sham','d60_sham'),('PSLN-212(Y)','d60_young')]:
    s,n=tot([(b,g) for b in D60]); reg(key, f"{s}/{n}", lab60, g, n, 'sum of survivors / animals over the three day-60 experiments')
s,n=tot([(b,'PSLN-344') for b in D60]); lo,hi=cp_ci(s,n)
reg('d60_344_ci', f"{s}/{n} ({100*s/n:.0f}%; 95% CI {100*lo:.0f}–{100*hi:.0f})", lab60, 'PSLN-344', n, 'pooled survivors / animals; exact CI')
s,n=tot([(b,'Untreated') for b in D60])
reg('untr_deaths', f"{n-s}/{n}", lab60, 'Untreated (no vaccine, no adjuvant, no challenge)', n, 'deaths / animals over the three day-60 experiments')
reg('untr_surv', f"{s}/{n}", lab60, 'Untreated', n, 'survivors / animals')
reg('d60_vs_untr_p', fp(fisher(14,21,s,n)), lab60, 'PSLN-344 (challenged) vs Untreated (unchallenged)', '', 'Fisher exact on pooled counts')
s14,n14=tot([('S06-A','PSLN-344'),('S06-C','PSLN-344')])
reg('d14_het_344', f"{s14}/{n14}", 'S06-A, S06-C', 'PSLN-344', n14, 'sum over the two day-14 heterosubtypic experiments')
reg('d14_vs_d60_p', fp(fisher(s14,n14,14,21)), 'S06-A, S06-C vs S06-E/F/G', 'PSLN-344 day 14 vs day 60', '', 'Fisher exact on pooled counts')
# young
s,n=tot([(b,'PSLN-344Y') for b in ['S09-B','S09-D','S09-F']]); reg('young_344', f"{s}/{n}", 'S09-B, S09-D, S09-F', 'PSLN-344Y', n, 'sum of survivors / animals')
s,n=tot([(b,'PSLN-212Y') for b in ['S09-B','S09-D','S09-F']]); reg('young_212', f"{s}/{n}", 'S09-B, S09-D, S09-F', 'PSLN-212Y', n, 'sum of survivors / animals')
# early
s,n=tot([('S06-B','PSLN-344'),('S03-J','PSLN-344'),('S15-H','3d Vaccine+PSLN-344')])
reg('early_344', f"{s}/{n}", 'S06-B, S03-J, S15-H', 'PSLN-344 + vaccine, challenge on day 2–3', n, 'sum of survivors / animals')
# dose-response
def hill(d, emax, ed50, h): return 1 + (emax-1)*d**h/(ed50**h + d**h)
for g in ['PSLN-212','PSLN-344','CMP-204']:
    df=TC['S08-A'][g]; d=np.repeat(df.index.values.astype(float),3); yv=df.values.astype(float).ravel()
    p_,cov=curve_fit(hill,d,yv,p0=[yv.max(),10,2],bounds=([1,0.5,0.5],[200,100,8])); se=np.sqrt(np.diag(cov))
    reg(f'emax_{g}', f"{p_[0]:.0f} ± {se[0]:.0f}", 'S08-A', g, 15, 'plateau (Emax ± SE) of a 3-parameter Hill fit, 1 + (Emax−1)·D^h/(ED50^h + D^h), to the 15 per-animal values', 'S08!A2:M7')
    reg(f'ed50_{g}', f"{p_[1]:.0f} ± {se[1]:.0f}", 'S08-A', g, 15, 'ED50 ± SE (µg) of the same Hill fit', 'S08!A2:M7')
    reg(f'frac20_{g}', f"{100*(hill(20,*p_)-1)/(p_[0]-1):.0f}%", 'S08-A', g, 15, 'fitted response at 20 µg as % of fitted plateau', 'S08!A2:M7')
# IgG2a/IgG1 recomputed
for a,b,lab in [('S13-A','S13-B','ca09'),('S13-C','S13-D','aichi')]:
    for g,k in [('PSLN-212','212'),('PSLN-344','344'),('PSLN-212(Y)','young')]:
        r=np.array(B[a][g])/np.array(B[b][g])
        reg(f'ratio_{lab}_{k}', f"{r.mean():.2f} ± {r.std(ddof=1):.2f}", f'{a} ÷ {b}', g, 5, f'per-animal IgG2a titre ÷ IgG1 titre (row-paired), mean ± SD; reproduces the S03-{"B" if lab=="ca09" else "F"} values stored under a different header', f"{META[a]['loc']} ÷ {META[b]['loc']}")
    r3=np.array(B[a]['PSLN-344'])/np.array(B[b]['PSLN-344']); r2=np.array(B[a]['PSLN-212'])/np.array(B[b]['PSLN-212'])
    reg(f'ratio_{lab}_p', fp(welch(r3,r2,log=True)[1]), f'{a} ÷ {b}', 'PSLN-344 vs PSLN-212', '5/5', 'Welch t test on log ratios')
# monotone readouts
C=pd.read_csv(os.path.join(WORK,'core4_readouts.csv'))
ninc=int((C.order=='increasing').sum()); ndec=int((C.order=='decreasing').sum()); ntot=len(C)
reg('n_mono', f"{ninc+ndec} of {ntot}", 'all blocks carrying Sham, PSLN-212, PSLN-344 and PSLN-212(Y), except S11-A', 'four core arms', ntot, f'count of readouts whose four group means (GMT for titres) are strictly ordered Sham→PSLN-212→PSLN-344→young ({ninc} rising, {ndec} falling); time courses taken at the peak day')
inc=C[C.order=='increasing']
reg('n_rising', f"{ninc}", 'all blocks carrying Sham, PSLN-212, PSLN-344 and PSLN-212(Y), except S11-A', 'four core arms', ntot, 'count of readouts whose four group means rise strictly Sham→PSLN-212→PSLN-344→young')
reg('med_restore_344', f"{inc.pct_of_young_344.median():.0f}%", 'the rising readouts (see n_rising)', 'PSLN-344 aged ÷ PSLN-212 young', ninc, 'median across readouts of (aged group mean ÷ young group mean)')
reg('med_restore_212', f"{inc.pct_of_young_212.median():.0f}%", 'the rising readouts (see n_rising)', 'PSLN-212 aged ÷ PSLN-212 young', ninc, 'median across readouts of (aged group mean ÷ young group mean)')
# HAI >= 40
for blk,key in [('S03-C','ca09'),('S03-G','aichi')]:
    for g,k in [('PSLN-212','212'),('PSLN-344','344'),('CMP-204','cmp'),('Sham','sham')]:
        v=B[blk][g]; reg(f'hai40_{key}_{k}', f"{sum(1 for x in v if x>=40)}/{len(v)}", blk, g, len(v), 'animals with HAI titre ≥ 40 / animals')
# power
_p1=w344[0]/w344[1]; _p2=w212[0]/w212[1]
reg('power16', f"{100*power_fisher(_p1,_p2,16):.0f}%", 'design calculation', f'{100*_p1:.0f}% vs {100*_p2:.0f}% survival, n = 16 per arm', 16, "exact power of a two-sided Fisher test at alpha 0.05, using the least-favourable pooled rates (60/72 vs 13/73)")
reg('power7', f"{100*power_fisher(_p1,_p2,7):.0f}%", 'design calculation', f'{100*_p1:.0f}% vs {100*_p2:.0f}% survival, n = 7 per arm', 7, "exact power of a two-sided Fisher test at alpha 0.05, same rates")
reg('power16_cons', f"{100*power_fisher(0.75,0.25,16):.0f}%", 'design calculation', '75% vs 25% survival, n = 16 per arm', 16, "exact power of a two-sided Fisher test at alpha 0.05, for a deliberately smaller effect")
# S08-C readings
d=B['S08-C']
reg('s08c_lab_II', f"{np.mean(d['AECII-PSLN-SRB']):.1f} vs {np.mean(d['AECII-PSLN-344-SRB']):.1f}", 'S08-C', 'AECII: PSLN-SRB vs PSLN-344-SRB, headers as printed', '5/5', 'arithmetic means of columns A and B')
reg('s08c_lab_I', f"{np.mean(d['AECI-PSLN-SRB']):.1f} vs {np.mean(d['AECI-PSLN-344-SRB']):.1f}", 'S08-C', 'AECI: PSLN-SRB vs PSLN-344-SRB, headers as printed', '5/5', 'arithmetic means of columns C and D')
reg('s08c_tr_II', f"{np.mean(d['AECII-PSLN-SRB']):.1f} vs {np.mean(d['AECI-PSLN-SRB']):.1f}", 'S08-C', 'AECII: PSLN-SRB (col A) vs PSLN-344-SRB (col C), if the two middle headers are transposed', '5/5', 'arithmetic means of columns A and C')
reg('s08c_tr_I', f"{np.mean(d['AECII-PSLN-344-SRB']):.1f} vs {np.mean(d['AECI-PSLN-344-SRB']):.1f}", 'S08-C', 'AECI: PSLN-SRB (col B) vs PSLN-344-SRB (col D), if the two middle headers are transposed', '5/5', 'arithmetic means of columns B and D')
reg('s08c_tr_p', f"{fp(welch(d['AECII-PSLN-SRB'],d['AECI-PSLN-SRB'])[1])} and {fp(welch(d['AECII-PSLN-344-SRB'],d['AECI-PSLN-344-SRB'])[1])}", 'S08-C', 'transposed reading: PSLN-SRB vs PSLN-344-SRB within AECII and within AECI', '5/5', 'Welch t tests')
# S11 duplicates
tot_=same=0
for g in TC['S11-A']:
    a=TC['S11-A'][g].values.astype(float); b=TC['S11-B'][g].values.astype(float); tot_+=a.size; same+=int((a==b).sum())
reg('s11_same', f"{same} of {tot_}", 'S11-A vs S11-B', 'all four groups, five days', tot_, 'count of cell-for-cell identical values; all lie in the first one or two animal columns of each group')
a=TC['S15-C']['PSLN-344'].values.astype(float); b=TC['S15-I']['3d Vaccine+PSLN-344'].values.astype(float)
reg('s15ci_same', f"{int((a[1:]==b[1:]).sum())} of {a[1:].size}", 'S15-C vs S15-I', 'PSLN-344 vs 3d Vaccine+PSLN-344', a[1:].size, 'count of identical post-baseline body-weight values, same animal column and day')
# S08-D
a=TC['S08-D']['PSLN-344'].astype(float)
reg('s08d_344_min', f"{np.nanmin(a.values):.1f}", 'S08-D', 'PSLN-344', 5, 'lowest single-animal value (% of day-0 weight)')
a=TC['S08-D']['PSLN-212/R848'].astype(float)
reg('s08d_r848_min', f"{np.nanmin(a.values):.1f}", 'S08-D', 'PSLN-212/R848', 5, 'lowest single-animal value (% of day-0 weight)')
# nadir ranges across blocks for PSLN-344 survivors
W=pd.read_csv(os.path.join(WORK,'weights_summary.csv'))
wa=W[(W.group.isin(['PSLN-344','3d Vaccine+PSLN-344','Naive+PSLN-344','Imprinting+PSLN-344']))&(~W.block.isin(['S15-C']))]
reg('nadir_344_range', f"{wa.nadir_mean_surv.min():.0f}–{wa.nadir_mean_surv.max():.0f}%", ', '.join(wa.block.unique()), 'PSLN-344 arms, survivors only', '', 'range across weight blocks of the group mean of per-animal lowest weight (% of day 0); S15-C omitted because its PSLN-344 traces duplicate S15-I')
wy=W[(W.group.isin(['PSLN-212(Y)']))&(~W.block.isin(['S15-M','S15-D']))]
reg('nadir_young_range', f"{wy.nadir_mean_surv.min():.0f}–{wy.nadir_mean_surv.max():.0f}%", ', '.join(wy.block.unique()), 'PSLN-212(Y) arms, survivors only', '', 'range across weight blocks of the group mean of per-animal lowest weight; S15-M omitted (traces shared with S09-E), S15-D omitted (paired survival block is a duplicate)')
# --- extra custom entries
_g=TC['S13-G']['Sham'].astype(float)
reg('s13g_sham_recovered', f"{int((_g.loc[14]>=95).sum())}/{_g.shape[1]}", 'S13-G', 'Sham', _g.shape[1], 'animals with day-14 weight ≥ 95% of day 0 / animals')
_f=TC['S13-F']['PSLN-212'].astype(float)
reg('s13f_212_d10', f"{int((_f.loc[10]!=_f.loc[8]).sum())}", 'S13-F', 'PSLN-212', 7, 'animals whose day-10 weight differs from their day-8 weight, i.e. were weighed on day 10')
reg('s13f_212_rec', f"{int((_f.loc[14]>=95).sum())}", 'S13-F', 'PSLN-212', 7, 'animals with day-14 weight ≥ 95% of day 0')
_s=TC['S09-C']['Sham']
reg('s09c_sham_d8', f"{int(_s.loc[8].notna().sum())} of {_s.shape[1]}", 'S09-C', 'Sham', _s.shape[1], 'animals with a day-8 weight')
reg('p9_young_short', f"{y[0]}/{y[1]}", lab9, 'PSLN-212(Y)', y[1], 'sum over the nine experiments that carry both a young PSLN-212 and an aged PSLN-344 arm')
reg('worst_212_short', f"{w212[0]}/{w212[1]}", lab10+' with S13-F, S15-C, S15-E', 'PSLN-212', w212[1], 'for each experiment, the higher of (time-to-event count, weight-block count) for PSLN-212: S03-I 3/7, S06-E(r34–68) 1/7 from weights; others as recorded')
reg('aged10_slr', f"χ² = {chi:.1f}, p < 0.0001", lab10, 'PSLN-344 vs PSLN-212', f"{a344[1]}/{a212[1]}", f'log-rank stratified by experiment, 1 df (exact p = {p:.1e})')
reg('worst_cmh', f"χ² = {cmw.statistic:.1f}, p < 0.0001", lab10, 'PSLN-344 vs PSLN-212, least favourable reading', '', f'Cochran–Mantel–Haenszel stratified by experiment, continuity-corrected (exact p = {cmw.pvalue:.1e})')
_n=TC['S13-G']['Naive'].astype(float)
reg('s13g_naive_recovered', f"{int((_n.loc[14]>=95).sum())}/{_n.shape[1]}", 'S13-G', 'Naive', _n.shape[1], 'animals with day-14 weight ≥ 95% of day 0 / animals')
# --- counts that were typed in earlier drafts; now computed
from statsmodels.stats.proportion import confint_proportions_2indep as _ci2
_lo,_hi=_ci2(a344[0],a344[1],a212[0],a212[1],method='newcomb')
reg('aged10_rd', f"{100*(a344[0]/a344[1]-a212[0]/a212[1]):.0f} percentage points (95% CI {100*_lo:.0f}–{100*_hi:.0f})", lab10, 'PSLN-344 minus PSLN-212', f"{a344[1]}/{a212[1]}", 'difference of pooled survival proportions; Newcombe hybrid-score interval')
_ahead=0; _nstr=0
for b in AGED10:
    s3,n3=cnt(b,'PSLN-344'); s2,n2=cnt(b,'PSLN-212'); _nstr+=1; _ahead+= (s3/n3 > s2/n2)
reg('ahead10', f"{_ahead} of {_nstr}", lab10, 'experiments in which PSLN-344 survival % exceeds PSLN-212', _nstr, 'count')
_ahead14=_ahead; _n14=_nstr
for b,p in IMPR:
    s3,n3=cnt(b,f'{p}+PSLN-344'); s2,n2=cnt(b,f'{p}+PSLN-212'); _n14+=1; _ahead14+=(s3/n3 > s2/n2)
reg('n_strata', f"{_n14}", lab10+' + S06-E/F(r71–105)', 'head-to-head PSLN-344 vs PSLN-212 comparisons', _n14, 'count of arms pairs: 10 experiments at ≥20 months + 4 arm pairs at 14 months')
reg('ahead14', f"{_ahead14} of {_n14}", lab10+' + S06-E/F(r71–105)', 'comparisons in which PSLN-344 survival % exceeds PSLN-212', _n14, 'count')
_imp=[cnt(b,f'{p}+PSLN-344') for b,p in IMPR]
assert len(set(_imp))==1
reg('impr_each', f"{_imp[0][0]}/{_imp[0][1]}", 'S06-E(r71–105), S06-F(r71–105)', 'each of the four 14-month PSLN-344 arms', 7, 'survivors / animals; identical in all four arms')
_c=SV['S06-C'][['group','time','event']].values.tolist(); _d=SV['S06-D'][['group','time','event']].values.tolist()
assert _c==_d
reg('s06cd_rows', f"{len(_c)}", 'S06-C vs S06-D', 'all four arms', len(_c), 'number of per-animal rows; every row (group, day, status) is identical between the two blocks', 'S06!M3:Q30 vs S06!A34:E61')
_u=[cell('S08',f'{col}{r}') for r in range(89,102) for col in 'CD']
reg('s08_unlabelled', f"{sum(1 for x in _u if x is not None)}", 'S08 rows 89–101', 'no labels', '', 'count of non-empty cells in columns C and D', 'S08!A89:D101')
def _shared(b1,g1,b2,g2,thr=4):
    A_=TC[b1][g1]; B_=TC[b2][g2]; n=0
    for ca in A_.columns:
        best=0
        for cb in B_.columns:
            shared=[A_.loc[d,ca] for d in A_.index if d!=0 and d in B_.index and A_.loc[d,ca] is not None and A_.loc[d,ca]==B_.loc[d,cb]]
            if len(set(shared))>=3:      # ignore matches that are only a repeated carried-forward value
                best=max(best,len(shared))
        n+= best>=thr
    return n, A_.shape[1]
_n,_t=_shared('S15-M','PSLN-212(Y)','S09-E','PSLN-344Y')
reg('s15m_s09e', f"{_n} of {_t}", 'S15-M vs S09-E', 'PSLN-212(Y) (young C57BL/6) vs PSLN-344Y (young BALB/c)', _t, 'animals in S15-M that share at least 4 of 7 post-baseline weights (at least 3 distinct values), same days, with one animal in S09-E')
_n,_t=_shared('S15-A','PSLN-344','S15-M','PSLN-344',thr=5)
reg('s15a_s15m', f"{_n}", 'S15-A vs S15-M', 'PSLN-344 (aged BALB/c) vs PSLN-344 (aged C57BL/6)', _t, 'animals in S15-A that share at least 5 of 7 post-baseline weights (at least 3 distinct values) with one animal in S15-M')
_y=TC['S15-C']['PSLN-344'][2]
reg('s15c_jump', f"{_y.loc[12]:.1f}% to {_y.loc[14]:.1f}%", 'S15-C', 'PSLN-344, third animal column (Y)', 1, 'day-12 and day-14 weights of one animal', 'S15!Y29:Y30')
reg('s03i_212_last', f"{int(max(_sv('S03-I','PSLN-212')[0]))}", 'S03-I', 'PSLN-212', 7, 'latest recorded day of death')
_j=SV['S03-J']
reg('s03j_rows', f"{int((_j.group=='PSLN-344').sum())}", 'S03-J', 'each arm', '', 'rows with a status entry per arm (Sham, PSLN-212, PSLN-344 all equal)')
reg('s03j_maxday', f"{int(_j.time.max())}", 'S03-J', 'all arms', '', 'largest day entered')
reg('s13e_rows', f"{int((SV['S13-E'].group=='Sham').sum())}", 'S13-E', 'each arm', '', 'rows per arm')
reg('s09f_sham_rows', f"{int((SV['S09-F'].group=='Sham').sum())}", 'S09-F', 'Sham', '', 'rows in the time-to-event block')
reg('s09g_sham_animals', f"{TC['S09-G']['Sham'].shape[1]}", 'S09-G', 'Sham', '', 'animal columns with a day-0 weight')

_wj=[t for i,t in enumerate(worst) if i!=1]
_a=(sum(t[0][0] for t in _wj), sum(sum(t[0]) for t in _wj)); _b=(sum(t[1][0] for t in _wj), sum(sum(t[1]) for t in _wj))
reg('worst_noJ_344', f"{_a[0]}/{_a[1]}", lab10.replace('S03-J, ','')+' with S13-F, S15-C, S15-D, S15-E, S15-G', 'PSLN-344', _a[1], 'least-favourable reading with S03-J removed (its comparator labels conflict with S13-G)')
reg('worst_noJ_212', f"{_b[0]}/{_b[1]}", lab10.replace('S03-J, ','')+' with S13-F, S15-C, S15-D, S15-E', 'PSLN-212', _b[1], 'least-favourable reading with S03-J removed')

if __name__=='__main__':
    for k,v in CUSTOM.items(): print(k,'=>',v['text'])

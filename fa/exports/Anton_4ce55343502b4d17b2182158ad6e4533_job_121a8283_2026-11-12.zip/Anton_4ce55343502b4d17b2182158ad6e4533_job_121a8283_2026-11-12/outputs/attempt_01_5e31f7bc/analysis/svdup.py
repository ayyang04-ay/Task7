import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
import itertools
def vec(df,g):
    d=df[df.group==g]
    return tuple(sorted((-1 if t!=t else int(t),int(e)) for t,e in zip(d.time,d.event)))
info={}
for k,df in SV.items():
    for g in dict.fromkeys(df.group):
        info[(k,g)]=vec(df,g)
for (a,va),(b,vb) in itertools.combinations(info.items(),2):
    if va==vb and any(e==1 for t,e in va):
        ndeath=sum(e for t,e in va)
        if ndeath>=2: print(a,b,[t for t,e in va if e==1],'+',sum(1 for t,e in va if e==0),'censored')

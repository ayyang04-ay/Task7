import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import numpy as np, pandas as pd
from scipy.optimize import curve_fit
def hill(d, emax, ed50, h): return 1 + (emax-1)*d**h/(ed50**h + d**h)
for g,df in TC['S08-A'].items():
    d=np.repeat(df.index.values.astype(float),3); y=df.values.astype(float).ravel()
    try:
        p,cov=curve_fit(hill,d,y,p0=[y.max(),10,2],bounds=([1,0.5,0.5],[200,100,8]))
        se=np.sqrt(np.diag(cov))
        pred=hill(df.index.values.astype(float),*p)
        print(f"{g:14s} Emax={p[0]:.1f}±{se[0]:.1f}  ED50={p[1]:.1f}±{se[1]:.1f} ug  Hill={p[2]:.2f}±{se[2]:.2f} | means {df.mean(axis=1).round(2).tolist()} pred {pred.round(2).tolist()}  frac of Emax at 20ug={(hill(20,*p)-1)/(p[0]-1):.2f}")
    except Exception as e:
        print(g,'fit failed',e)
# ratios
m=pd.DataFrame({g:df.mean(axis=1) for g,df in TC['S08-A'].items()})
print(m.round(2))
print((m['PSLN-344']/m['PSLN-212']).round(2))
# compare S08-A 20ug with S01-A 16h
for g in ['CMP-204','PSLN-212','PSLN-344']:
    print(g,'S08-A 20ug',TC['S08-A'][g].loc[20].tolist(),'mean',round(TC['S08-A'][g].loc[20].mean(),2),'| S01-A16h',B['S01-A_16h'][g], round(np.mean(B['S01-A_16h'][g]),2))
# PSLN-344 20 vs 40 test
a=TC['S08-A']['PSLN-344'].loc[20].astype(float).values; b=TC['S08-A']['PSLN-344'].loc[40].astype(float).values
print('PSLN-344 20 vs 40 ug Welch p', welch(a,b)[1])
a=TC['S08-A']['PSLN-212'].loc[40].astype(float).values; b=TC['S08-A']['PSLN-344'].loc[10].astype(float).values
print('PSLN-212 40ug vs PSLN-344 10ug Welch p', welch(a,b)[1], a.mean(), b.mean())
a=TC['S08-A']['PSLN-212'].loc[20].astype(float).values; b=TC['S08-A']['PSLN-212'].loc[40].astype(float).values
print('PSLN-212 20 vs 40 Welch p', welch(a,b)[1], a.mean(), b.mean())

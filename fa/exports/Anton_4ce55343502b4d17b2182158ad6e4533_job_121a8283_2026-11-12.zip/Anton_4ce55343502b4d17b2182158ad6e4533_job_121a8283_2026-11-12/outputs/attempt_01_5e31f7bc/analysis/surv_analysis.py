import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',30); pd.set_option('display.max_rows',500)
rows=[]
for k,df in SV.items():
    d=df.dropna(subset=['time'])
    for g,x in d.groupby('group',sort=False):
        n=len(x); ev=int((x.event==1).sum()); s=n-ev
        lo,hi=cp_ci(s,n)
        rows.append(dict(block=k,group=g,n=n,deaths=ev,survivors=s,surv_pct=100*s/n,ci_lo=100*lo,ci_hi=100*hi,median_days=km_median(x.time,x.event),death_days=sorted(x[x.event==1].time.astype(int).tolist()), tmax=int(x.time.max())))
S=pd.DataFrame(rows)
print(S.to_string())
S.to_csv(os.path.join(WORK,'survival_summary.csv'),index=False)
# pairwise tests
def get(k,g):
    d=SV[k].dropna(subset=['time']); x=d[d.group==g]; return x.time.values, x.event.values
tests=[]
for k,df in SV.items():
    gs=list(dict.fromkeys(df.group))
    for a,b in itertools.combinations(gs,2):
        ta,ea=get(k,a); tb,eb=get(k,b)
        chi,p=logrank(ta,ea,tb,eb)
        sa=int((ea==0).sum()); sb=int((eb==0).sum())
        pf=fisher(sa,len(ea),sb,len(eb))
        tests.append(dict(block=k,a=a,b=b,a_surv=f"{sa}/{len(ea)}",b_surv=f"{sb}/{len(eb)}",logrank_chi2=chi,logrank_p=p,fisher_p=pf))
T=pd.DataFrame(tests)
T.to_csv(os.path.join(WORK,'survival_tests.csv'),index=False)
print(T.to_string())

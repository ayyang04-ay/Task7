import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import pandas as pd, numpy as np
OUT=os.path.join(OUT,'PSLN-344_numbers_ledger.xlsx')
cited=pd.read_csv(os.path.join(WORK,'cited_numbers.csv'))
cited.columns=['Order of appearance','Value as printed in memo','Block','Workbook cells','Group(s)','n','How reduced']
# survival by arm
S=pd.read_csv(os.path.join(WORK,'survival_summary.csv'))
W=pd.read_csv(os.path.join(WORK,'weights_summary.csv'))
pairs = {'S03-I':'S13-F','S03-J':'S13-G','S06-A':'S15-A','S06-B':'S15-B','S06-C':'S15-C','S06-D':'S15-D','S06-E(r34-68)':'S15-E','S06-F(r34-68)':'S15-F','S06-G':'S15-G','S15-H':'S15-I','S06-E(r71-105)':'S15-J','S06-F(r71-105)':'S15-K','S15-L':'S15-M','S15-N':'S15-O','S09-B':'S09-C','S09-D':'S09-E','S09-F':'S09-G'}
def norm(g): return g.replace('ï','i').replace(' ','').replace('(Y)','Y').replace('(y)','Y')
rows=[]
for _,r in S.iterrows():
    wb=pairs.get(r.block); wtxt=''; flag=''
    if wb:
        w=W[(W.block==wb)&(W.group.map(norm)==norm(r.group))]
        if len(w):
            wtxt=f"{int(w.surv.iloc[0])}/{int(w.n.iloc[0])}"
            if int(w.surv.iloc[0])!=int(r.survivors) or int(w.n.iloc[0])!=int(r.n): flag='DIFFERS'
        else: wtxt='arm not in weight block'
    rows.append(dict(Block=r.block, Cells=META[r.block]['loc'], Arm=r.group, n_with_day=int(r.n), Deaths=int(r.deaths), Survivors=int(r.survivors),
                     Survival_pct=round(r.surv_pct,1), CI95_low=round(r.ci_lo,1), CI95_high=round(r.ci_hi,1), Median_survival_days=('not reached' if np.isinf(r.median_days) else r.median_days),
                     Death_days=r.death_days, Paired_weight_block=wb or '', Weight_block_survivors=wtxt, Concordance=flag))
SA=pd.DataFrame(rows)
H=pd.read_csv(os.path.join(WORK,'head_to_head.csv'))
H=H.rename(columns={'surv_block':'Block','desc':'Design','PSLN344':'PSLN-344 survivors/n','PSLN212':'PSLN-212 survivors/n','logrank_p':'Log-rank p (344 vs 212)','fisher_p':'Fisher p (344 vs 212)','lr_344_vs_sham':'Log-rank p (344 vs Sham)','wt_block':'Weight block','w344':'PSLN-344 by weights','w212':'PSLN-212 by weights','w_fisher_p':'Fisher p by weights'})
ST=pd.read_csv(os.path.join(WORK,'survival_tests.csv')).rename(columns={'block':'Block','a':'Arm A','b':'Arm B','a_surv':'A survivors/n','b_surv':'B survivors/n','logrank_chi2':'Log-rank chi-square','logrank_p':'Log-rank p','fisher_p':'Fisher exact p'})
D=pd.read_csv(os.path.join(WORK,'desc_simple.csv')); D.insert(1,'cells',D.block.map(lambda b: META[b]['loc'])); D.insert(2,'stated_n',D.block.map(lambda b: META[b]['stated_n']))
D=D.rename(columns={'gmean':'geometric_mean','gm_lo':'gm_CI95_low','gm_hi':'gm_CI95_high'})
T=pd.read_csv(os.path.join(WORK,'desc_tc.csv')); T.insert(1,'cells',T.block.map(lambda b: META[b]['loc']))
PT=pd.read_csv(os.path.join(WORK,'tests_simple.csv')).rename(columns={'anova_p':'one-way ANOVA p (block)','tukey_p':'Tukey p','welch_p':'Welch t p','mwu_p':'Mann-Whitney exact p','student_p':'Student t p (2-group blocks)'})
C4=pd.read_csv(os.path.join(WORK,'core4_readouts.csv')).rename(columns={'red':'reduction','PSLN212':'PSLN-212 aged','PSLN344':'PSLN-344 aged','Young212':'PSLN-212 young','order':'ordering across the four arms','pct_of_young_344':'PSLN-344 aged as % of young','pct_of_young_212':'PSLN-212 aged as % of young','fold_344_over_212':'PSLN-344 / PSLN-212 (aged)'})
WA=pd.read_csv(os.path.join(WORK,'weights_animals.csv'))[['block','group','animal','status','last_day','nadir','final','how']].rename(columns={'animal':'animal column (0-based within group)','last_day':'last day with a new value','nadir':'lowest weight (% of day 0)','final':'last value','how':'basis (blank = no later value; flat xN = value repeated N times to day 14)'})
# S09-A
rows=[]
for nm,P,loc in [('panel 1 (Ifnb1 = S01-A 16 h values)',S09A1,'S09!A2:V9'),('panel 2 (labelled 16h; Ifnb1 = S01-A 72 h values)',S09A2,'S09!X2:AS9')]:
    for an,d in P.items():
        for g,v in d.items():
            v=np.array(v,float)
            rows.append(dict(panel=nm,cells=loc,analyte=an,group=g,n=len(v),mean_log10=v.mean(),sd_log10=v.std(ddof=1),geometric_mean_fold=10**v.mean()))
S9=pd.DataFrame(rows)
# pooled
import custom
PO=pd.DataFrame([dict(key=k, value=v['text'], blocks=v['block'], groups=v['groups'], n=v['n'], how_reduced=v['reduction']) for k,v in custom.CUSTOM.items()])
# audit
A=[
('1','A','S03-I vs S13-F','S03!A31:D37; S13!P33:V40','PSLN-212 (aged) is recorded as 0/7 with deaths on days 5,5,5,6,6,6,6 (earlier than Sham: 5,6,6,6,8,8,11). The body-weight block for "the animals of S03-I" has new PSLN-212 values for all 7 animals through day 10; 4 then repeat unchanged (78.5, 80.1, 79.3, 78.5) and 3 rise to 99.0, 95.0, 96.5 on day 14. S13-F also has a "Naive" arm (all blank by day 8) that S03-I lacks, and has no CMP-204 arm.','Both readings carried (0/7 as recorded; 3/7 by weights). Least-favourable pooled analysis uses 3/7. Cannot be resolved from the workbook: either the S03-I PSLN-212 column is wrong, or the S13-F arm labels are (its "PSLN-212" arm has the 3/7 outcome S03-I gives CMP-204, and its "Naive" arm has the all-dead-by-day-8 pattern S03-I gives PSLN-212).','Homologous-challenge comparison PSLN-344 vs PSLN-212; antibody-vs-survival argument'),
('2','A','S06-D vs S06-C','S06!A34:E61 vs S06!M3:Q30','All 28 rows (4 arms x 7 animals, day and status) are identical. The weight block for the day-3 experiment (S15-D) shows two PSLN-344 animals (79.5, 85.2) and two young PSLN-212 animals (82.1, 76.5) flat-lining from day 8-10, i.e. 5/7 and 5/7, not 7/7.','The record is counted once, as S06-C; which of the two blocks is the original cannot be told from the workbook. Day-3 rgH5N1 protection is taken from S15-H (6/7); the least-favourable analysis uses the S15-D weights (5/7 vs PSLN-212 2/7) for this record.','Early-protection claim; pooled counts'),
('3','A','S03-J vs S13-G','S03!G16:J46; S13!A42:AE50','Header "n=9" but 10 rows per arm. PSLN-344 row 46 has status 0 and no day. Longest day is 21; annotation says observation ran 22 days. S13-G ("the animals of S03-J") has arms PSLN-344, Sham, Naive; S03-J has Sham, PSLN-212, PSLN-344. S13-G "Sham": 4 of 10 back above 95% on day 14; S03-J "Sham": 1 of 10 survive. S13-G "Naive": 1 of 10 recover, which matches S03-J "Sham".','PSLN-344 counted as 9/9 (10/10 alive on day 14 by weights). Comparator identity flagged: the S03-J "PSLN-212" column may be the sham arm.','Wild-type H5N1 comparator'),
('4a','A','S06-E (rows 34-68) vs S15-E','S06!G33:L68; S15!A42:AJ50','PSLN-344: 5/7 by survival rows (deaths day 8, 10); weights show one flat-line (79.8 from day 8) and six recovering. PSLN-212: 0/7 by survival rows; weights show one animal at 99.7% on day 14.','Survival rows used; weights used in least-favourable analysis for PSLN-212 (1/7).','Day-60 count'),
('4b','A','S06-G vs S15-G','S06!A70:F105; S15!A62:AJ70','PSLN-344: 4/7 by survival rows (deaths day 8, 9, 11); weights show two flat-lines from day 12 (80.3, 77.5) and five alive.','Survival rows used (less favourable).','Day-60 count'),
('4c','A','S06-C vs S15-C','S06!M2:Q30; S15!A22:AC30','PSLN-212: 2/7 by survival rows; weights show one animal recovering (96.1%).','Survival rows used (more favourable to PSLN-212).','Day-14 rgH5N1 count'),
('4d','A','S15-L vs S15-M','S15!A102:E130; S15!H102:AJ110','Young C57BL/6 PSLN-212: 6/7 by survival rows (death day 12); weights show 7/7 recovering.','Survival rows used.','Young reference in C57BL/6'),
('5','A','S03-B, S03-F','S03!G2:I7; S03!G9:I14 vs S13!A2:O7','Stored IgG2a/IgG1 ratios equal S13-A/S13-B (and S13-C/S13-D) per animal, but under headers rotated by one: printed "PSLN-212" = young PSLN-212 animals, printed "PSLN-344" = aged PSLN-212 animals, printed "PSLN-212(Y)" = PSLN-344 animals. S13 labels are consistent with total IgG (S03-A).','Ratios recomputed from S13-A to S13-D.','Th1-type antibody claim (would be inverted if quoted as printed)'),
('6','A','S06-E, S06-F (rows 34-68), S06-G','S06!L62:L68; S06!R62:R68; S06!F99:F105','"Untreated" = no vaccine, no adjuvant, no challenge (annotation). Deaths: 1/7, 0/7, 3/7 = 4/21, without weight loss (S15-E, S15-G).','Used as background mortality at ~22 months; not as a challenge control.','Interpretation of day-60 survival'),
('7','B','S15-C vs S15-I','S15!W23:AC30 vs S15!W72:AC79','PSLN-344 arm of S15-C (day-14 challenge) shares 40 of 49 post-baseline values with the "3d Vaccine+PSLN-344" arm of S15-I (day-3 challenge). In S15-C, animal column Y goes 77.9 (day 12) to 90.1 (day 14).','S15-C PSLN-344 weights not used as corroboration.','Weight corroboration of S06-C and S15-H'),
('8','B','S15-M vs S09-E; S15-A vs S15-M; S09-E vs S09-G','S15!I103:O110 vs S09!W39:AD46','Young C57BL/6 PSLN-212 traces (S15-M) match young BALB/c PSLN-344 traces (S09-E) in 6 of 7 animals (4-7 of 7 post-baseline values each). Two aged PSLN-344 traces shared between S15-A and S15-M. One PSLN-212Y trace identical in S09-E and S09-G.','Flagged; S15-M young weights not used.','Strain-generality corroboration'),
('9','B','S11-B vs S11-A','S11!A9:U14 vs S11!A2:U7','35 of 100 values identical cell-for-cell, always in the first one or two animal columns of each group; group means differ by <2.5 points at every time. S11-A vs S11-D: 0 of 100.','Neither block used (at most one can be an original record). No dependable neutrophil readout exists.','Lung-safety assessment'),
('10','B','S07-C','S07!B15:C20','Both columns are labelled "Ly6C-CD206+" (annotation: "Groups as printed: Ly6C-CD206+ MPhi, Ly6C-CD206+ MPhi").','Not used.','Macrophage-subset/Treg mechanism'),
('11','B','S05-A, S05-B','S05!A1:I10','Header n=3; two values per group per day. Annotation gives ovalbumin and the bivalent vaccine as the antigen in the same entry. NP366-374 is an H-2Db-restricted epitope (background knowledge); strain not stated and the file default is BALB/c. S05-I is annotated "vaccinated as in S05-A" and inherits the antigen ambiguity.','S05-A and S05-B not used. S05-I (resident-memory CD8 T cells, not an antigen-specific stain) used with this caveat.','Tetramer kinetics; resident-memory readout'),
('12','B','S08-C vs S01-B','S08!A13:D18; S01!A14:F15','As printed: AECII 15.8 (PSLN-SRB) vs 3.8 (PSLN-344-SRB); AECI 13.8 vs 3.0. But AECI uptake of PSLN-SRB is 3.8 in S01-B for the same condition, and S08-C column B shares values (4.92, 4.13) with S01-B AECI/PSLN-SRB. With the two middle headers swapped: AECII 15.8 vs 13.8 (p 0.25), AECI 3.8 vs 3.0 (p 0.20).','Treated as transposed headers; nothing rests on the block.','Whether Mn changes epithelial uptake'),
('13','C','S09-A','S09!X1:AS9; S01!G3:L10','Second panel label reads "16h"; its Ifnb1 values back-transform to the S01-A 72 h values (e.g. PSLN-212: 3.07, 3.18, 4.03). The control is "PBS" in S09-A and "Sham" in S01-A with identical values (1.84, 0.62, 0.88).','Second panel treated as 72 h. Control identity (buffer or empty liposome) unresolved.','72 h cytokine statement'),
('14','C','All challenge weight blocks (S13-F, S13-G, S15-A to S15-O)','','Dead animals are blank in Sham/Naive/vaccine-alone arms but carried forward unchanged in PSLN-212 and PSLN-344 arms. Group means by day are therefore not comparable between arms. The annotation describes PSLN-212 observations as "declining" in S13-F and S15-A although the workbook columns are fully populated there, which supports reading a repeated value as a death.','Per-animal reading: blank after day d, or last value repeated unchanged to day 14 (<90%, or >=3 repeats), counted as dead. Morbidity reported as per-animal lowest weight.','Weight-based cross-check and morbidity numbers'),
('15','C','S13-E; S09-F vs S09-G; S08-D; S05-A/B','S13!R1:V30; S09!A65:D88; S08!V26:Z26','S13-E header n=5, 7 rows per arm. S09-F Sham has 7 rows; S09-G has 8 Sham animals (annotation attributes a 7-animal Sham arm to S09-B, which has 8). S08-D PSLN-212/R848 has 4 values on day 10.','Counts taken from rows present.','n reporting'),
('16','C','S09-C; S09-B vs S09-C','S09!G18:N18 vs W18:AD18; S09!A12:B19 vs O16:V16','Day-12 weights identical for PSLN-212Y and PSLN-344Y (97.7, 95.2, 93.3, 93.5, 99.1, 96.9, 100.3, 99.8). S09-B enters Sham deaths on days 6,6,6,7,7,7,8,8 but 7 of 8 Sham animals have a day-8 weight.','Outcome unaffected.','Young-mouse blocks'),
('17','C','S08-A; S08 rows 89-101','S08!K2:M7; S08!A89:D101','"PSLN-344/R848" is not among the preparations defined in the annotation (only PSLN-212/R848 is). Rows 89-101 hold 13 values (day 14, status 0) with no block label or group names.','Neither used.','-'),
('18','C','S03-C, S03-G','S03!K6:K7; S03!K14','HAI entered as 0; the annotation gives 1:10 as the lowest dilution tested.','Set to 5 (half the floor) for geometric means; affects Sham only.','GMT'),
('19','C','S04-B Tfh:Tfr','S04!A14:D19 vs S04!A7:D12','Every stored ratio equals (100 - Foxp3%)/Foxp3% of the Foxp3 block. The annotation describes it as Tfh% over Tfr%; it does not use the S04-A Tfh percentages.','Foxp3 block reported; ratio not used as an independent readout.','Tfh:Tfr as biomarker'),
('20','C','S06','S06!G69, M69 vs G32, M32','Labels S06-E and S06-F each appear twice (rows 34-68 and rows 71-105) on different experiments.','Cited by row range throughout.','Citation'),
('21','C','S15-L, S15-N; S06-E (rows 71-105); S07-B, S11-E, S13-H, S14-A; S08-A; S02-C, S02-E, S02-H','','Not stated: challenge virus and day (S15-L, S15-N); challenge day (S06-E rows 71-105); sampling time (S07-B, S11-E, S13-H, S14-A); animal age (S08-A, S02-H); adjuvant and age of the "PTX" arm (S02-C, S02-E).','Noted where used.','Generalisation'),
('22','C','S01 sheet','S01!A24:A34','Day labels in S01-D and S01-E are stored as text.','Converted to numbers.','-'),
('23','C','S07-A; S09-A','S07!H3:H7; S09!A1','S07-A values are cell counts x10^5 (unit in column H only). S09-A values are log10.','Units respected; S09-A back-transformed.','Scale'),
]
AU=pd.DataFrame(A,columns=['#','Severity (A changes a number in the case; B removes a block; C correct only)','Where','Cells','Evidence','Handling in this analysis','What it touches'])
readme=pd.DataFrame({'Sheet':['Cited numbers','Survival by arm','Head-to-head','Pooled and custom','Survival tests','Group stats','Time-course stats','S09-A back-transformed','Pairwise tests','Core-arm readouts','Weights per animal','Audit'],
 'Contents':['Every number printed in PSLN-344_recommendation.md, in order of appearance: block, workbook cells, groups, n and how it was reduced.',
 'Every arm of every time-to-event block: n, deaths, survivors, exact 95% CI, death days; the survivor count implied by the paired body-weight block, and whether the two agree.',
 'PSLN-344 vs PSLN-212 in each of the 15 aged / 14-month strata (S06-D shown for completeness but excluded from pooling).',
 'Pooled survival counts, stratified tests, dose-response fits, recomputed IgG2a/IgG1 ratios and other derived numbers, each with the blocks and method used.',
 'All pairwise log-rank (Mantel-Cox) and Fisher exact tests within each time-to-event block.',
 'n, mean, SD, SEM, median, min, max for every group of every single-time-point block; geometric mean and 95% CI for titres (HAI zeros set to 5).',
 'The same by group and time for every time-course block (lung cells, Gm-csf, dose series, post-dose body weight).',
 'S09-A (stored as log10): mean and SD of log10 and the back-transformed geometric-mean fold, both panels.',
 'One-way ANOVA with Tukey HSD for every block (log10 for titres), plus Welch t and exact Mann-Whitney for each pair.',
 'Group means (GMT for titres) of every readout measured in Sham, PSLN-212 aged, PSLN-344 aged and PSLN-212 young, with aged-as-%-of-young.',
 'Each animal in each challenge body-weight block: survivor/dead call, last day with a new value, lowest weight.',
 'Data-integrity findings with cell references, evidence and handling.']})
methods=pd.DataFrame({'Reduction rules':[
 'Source: adjuvant_program_dataset.xlsx, read cell by cell with openpyxl; annotation from adjuvant_program_annotation.pdf.',
 'Time to event: per-animal rows, group column 1 = death, 0 = alive at the day shown. Survival = survivors / animals with a recorded day. Exact Clopper-Pearson 95% CI. Log-rank = Mantel-Cox, two-sided (checked against Python lifelines and R survival::survdiff; the Tukey and Cochran-Mantel-Haenszel results were also reproduced in R). Fisher exact two-sided on survivors at last observation day.',
 'Percentages and fold-changes: arithmetic mean and sample SD (n-1) of per-animal values.',
 'Titres: geometric mean; tests on log10; HAI values of 0 set to 5.',
 'S09-A: values are log10; geometric-mean fold = 10^(mean of log10).',
 'Pooling: survival counts only, by summing survivors and animals over the named blocks; stratified log-rank and Cochran-Mantel-Haenszel with experiment as stratum. S06-C and S06-D are identical row for row and are counted once (as S06-C). The undated S03-J PSLN-344 row excluded.',
 'Body weight: per-animal lowest value; an animal is counted dead if its values go blank, or if its last value repeats unchanged to day 14 (below 90%, or three or more repeats).',
 'Multiple comparisons: Tukey within a block; no adjustment across blocks. n = 5 per group gives a minimum exact Mann-Whitney p of 0.0079.']})
with pd.ExcelWriter(OUT, engine='xlsxwriter') as xw:
    wbk=xw.book
    hdr=wbk.add_format({'bold':True,'text_wrap':True,'valign':'top','bg_color':'#DDEBF7','border':1})
    wrap=wbk.add_format({'text_wrap':True,'valign':'top'})
    def put(df,name,widths=None,wrapcols=()):
        df.to_excel(xw,sheet_name=name,index=False)
        ws=xw.sheets[name]
        for j,col in enumerate(df.columns):
            ws.write(0,j,col,hdr)
            w = (widths or {}).get(col, min(max(len(str(col)), int(df[col].astype(str).str.len().quantile(0.9)) if len(df) else 10)+2, 60))
            ws.set_column(j,j,w, wrap if (col in wrapcols or w>=50) else None)
        ws.freeze_panes(1,0); ws.autofilter(0,0,max(len(df),1),len(df.columns)-1)
    readme.to_excel(xw,sheet_name='README',index=False,startrow=0)
    ws=xw.sheets['README']; ws.set_column(0,0,26); ws.set_column(1,1,130,wrap)
    for j,col in enumerate(readme.columns): ws.write(0,j,col,hdr)
    methods.to_excel(xw,sheet_name='README',index=False,startrow=len(readme)+3,startcol=1)
    ws.write(len(readme)+3,1,'Reduction rules',hdr)
    put(cited,'Cited numbers',widths={'Value as printed in memo':26,'Block':34,'Workbook cells':24,'Group(s)':40,'n':8,'How reduced':80},wrapcols=('Block','Group(s)','How reduced'))
    put(SA,'Survival by arm',widths={'Death_days':30,'Arm':22})
    put(H,'Head-to-head',widths={'Design':62})
    put(PO,'Pooled and custom',widths={'blocks':60,'groups':50,'how_reduced':90,'value':28,'key':22},wrapcols=('blocks','groups','how_reduced'))
    put(ST,'Survival tests')
    put(D,'Group stats')
    put(T,'Time-course stats')
    put(S9,'S09-A back-transformed',widths={'panel':48})
    put(PT,'Pairwise tests')
    put(C4,'Core-arm readouts')
    put(WA,'Weights per animal')
    put(AU,'Audit',widths={'Evidence':95,'Handling in this analysis':60,'What it touches':38,'Where':30,'Cells':30},wrapcols=('Evidence','Handling in this analysis','What it touches','Where','Cells'))
print('written',OUT)

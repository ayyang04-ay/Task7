import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import openpyxl, numpy as np, pandas as pd
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI
WB = openpyxl.load_workbook(DATA, data_only=True)

def cell(sheet, ref):
    return WB[sheet][ref].value

def rng(sheet, c0, r0, c1, r1):
    """return 2D list rows r0..r1, cols c0..c1 (letters)"""
    ws = WB[sheet]
    out=[]
    for r in range(r0, r1+1):
        out.append([ws.cell(r, c).value for c in range(CI(c0), CI(c1)+1)])
    return out

def colvals(sheet, col, r0, r1):
    ws=WB[sheet]
    return [ws.cell(r, CI(col)).value for r in range(r0, r1+1)]

def rowvals(sheet, row, c0, c1):
    ws=WB[sheet]
    return [ws.cell(row, c).value for c in range(CI(c0), CI(c1)+1)]

def groups_in_columns(sheet, header_row, r0, r1, c0, c1):
    """each column is a group; values down rows"""
    ws=WB[sheet]
    d={}
    for c in range(CI(c0), CI(c1)+1):
        name = ws.cell(header_row, c).value
        if name is None: continue
        vals=[ws.cell(r,c).value for r in range(r0, r1+1)]
        vals=[v for v in vals if v is not None]
        key=str(name).strip()
        if key in d:
            key = key + f" [col {L(c)}]"
        d[key]=vals
    return d

def groups_in_rows(sheet, name_col, r0, r1, c0, c1):
    ws=WB[sheet]
    d={}
    for r in range(r0, r1+1):
        name=ws.cell(r, CI(name_col)).value
        vals=[ws.cell(r,c).value for c in range(CI(c0), CI(c1)+1)]
        vals=[v for v in vals if v is not None]
        d[str(name).strip()]=vals
    return d

def timecourse(sheet, header_row, r0, r1, day_col, group_starts, width):
    """group_starts: dict name->start col letter; returns dict name-> DataFrame(index=day, columns animal idx)"""
    ws=WB[sheet]
    out={}
    for name, c0 in group_starts.items():
        rows={}
        for r in range(r0, r1+1):
            day=ws.cell(r, CI(day_col)).value
            if isinstance(day,str) and day.strip().lstrip('-').isdigit(): day=int(day.strip())
            rows[day]=[ws.cell(r, CI(c0)+i).value for i in range(width)]
        out[name]=pd.DataFrame(rows).T
        out[name].index.name='day'
    return out

def survival(sheet, day_col, r0, r1, group_cols, header_row):
    """returns DataFrame rows: group, time, event"""
    ws=WB[sheet]
    recs=[]
    for r in range(r0, r1+1):
        t=ws.cell(r, CI(day_col)).value
        for gc in group_cols:
            v=ws.cell(r, CI(gc)).value
            if v is not None:
                recs.append(dict(group=str(ws.cell(header_row, CI(gc)).value).strip(), time=t, event=v, row=r))
    return pd.DataFrame(recs)

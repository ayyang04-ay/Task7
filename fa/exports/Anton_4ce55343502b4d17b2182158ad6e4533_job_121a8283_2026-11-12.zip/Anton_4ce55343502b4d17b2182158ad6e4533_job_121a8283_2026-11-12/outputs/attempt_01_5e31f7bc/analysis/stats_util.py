import numpy as np, pandas as pd, itertools
from scipy import stats

def desc(v):
    v=np.array(v,dtype=float)
    n=len(v)
    return dict(n=n, mean=v.mean(), sd=v.std(ddof=1) if n>1 else np.nan, sem=(v.std(ddof=1)/np.sqrt(n)) if n>1 else np.nan,
                median=np.median(v), min=v.min(), max=v.max())
def gmean(v, floor=None):
    v=np.array(v,dtype=float)
    if floor is not None: v=np.where(v<=0, floor, v)
    return float(np.exp(np.mean(np.log(v))))
def gsd(v, floor=None):
    v=np.array(v,dtype=float)
    if floor is not None: v=np.where(v<=0, floor, v)
    return float(np.exp(np.std(np.log(v),ddof=1)))
def gm_ci(v, floor=None, alpha=0.05):
    v=np.array(v,dtype=float)
    if floor is not None: v=np.where(v<=0, floor, v)
    lv=np.log(v); n=len(lv); m=lv.mean(); se=lv.std(ddof=1)/np.sqrt(n)
    t=stats.t.ppf(1-alpha/2,n-1)
    return float(np.exp(m)), float(np.exp(m-t*se)), float(np.exp(m+t*se))

def anova_tukey(groups, log=False, floor=None):
    """groups: dict name->list. returns (F,p, tukey dataframe)"""
    names=list(groups)
    data=[]
    for g in names:
        v=np.array(groups[g],dtype=float)
        if log:
            if floor is not None: v=np.where(v<=0,floor,v)
            v=np.log10(v)
        data.append(v)
    F,p=stats.f_oneway(*data)
    res=stats.tukey_hsd(*data)
    rows=[]
    for i,j in itertools.combinations(range(len(names)),2):
        rows.append(dict(a=names[i], b=names[j], diff=data[i].mean()-data[j].mean(), p_tukey=res.pvalue[i,j]))
    return F,p,pd.DataFrame(rows)

def welch(a,b,log=False,floor=None):
    a=np.array(a,float); b=np.array(b,float)
    if log:
        if floor is not None:
            a=np.where(a<=0,floor,a); b=np.where(b<=0,floor,b)
        a=np.log10(a); b=np.log10(b)
    t,p=stats.ttest_ind(a,b,equal_var=False)
    return t,p
def student(a,b):
    t,p=stats.ttest_ind(np.array(a,float),np.array(b,float),equal_var=True); return t,p
def mwu(a,b):
    u,p=stats.mannwhitneyu(a,b,alternative='two-sided',method='exact'); return u,p

def logrank(t1,e1,t2,e2):
    """two-group Mantel-Cox log-rank. returns chi2, p"""
    t=np.concatenate([t1,t2]).astype(float); e=np.concatenate([e1,e2]).astype(int)
    g=np.concatenate([np.zeros(len(t1)),np.ones(len(t2))]).astype(int)
    O1=0;E1=0;V=0
    for tt in np.unique(t[e==1]):
        at=(t>=tt); n=at.sum(); n1=(at&(g==0)).sum()
        d=((t==tt)&(e==1)).sum(); d1=((t==tt)&(e==1)&(g==0)).sum()
        O1+=d1; E1+=d*n1/n
        if n>1: V+=d*(n1/n)*(1-n1/n)*(n-d)/(n-1)
    if V==0: return np.nan, np.nan
    chi=(O1-E1)**2/V
    return float(chi), float(stats.chi2.sf(chi,1))

def logrank_strat(strata):
    """strata: list of (t1,e1,t2,e2). stratified log-rank"""
    O=E=V=0
    for t1,e1,t2,e2 in strata:
        t=np.concatenate([t1,t2]).astype(float); e=np.concatenate([e1,e2]).astype(int)
        g=np.concatenate([np.zeros(len(t1)),np.ones(len(t2))]).astype(int)
        for tt in np.unique(t[e==1]):
            at=(t>=tt); n=at.sum(); n1=(at&(g==0)).sum()
            d=((t==tt)&(e==1)).sum(); d1=((t==tt)&(e==1)&(g==0)).sum()
            O+=d1; E+=d*n1/n
            if n>1: V+=d*(n1/n)*(1-n1/n)*(n-d)/(n-1)
    chi=(O-E)**2/V
    return float(chi), float(stats.chi2.sf(chi,1)), O, E

def km_median(t,e):
    t=np.array(t,float); e=np.array(e,int)
    order=np.argsort(t); s=1.0
    for tt in np.unique(t[e==1]):
        n=(t>=tt).sum(); d=((t==tt)&(e==1)).sum()
        s*= (1-d/n)
        if s<=0.5: return float(tt)
    return np.inf

def cp_ci(k,n,alpha=0.05):
    lo = stats.beta.ppf(alpha/2,k,n-k+1) if k>0 else 0.0
    hi = stats.beta.ppf(1-alpha/2,k+1,n-k) if k<n else 1.0
    return lo,hi
def fisher(a_surv,a_n,b_surv,b_n):
    return stats.fisher_exact([[a_surv,a_n-a_surv],[b_surv,b_n-b_surv]])[1]

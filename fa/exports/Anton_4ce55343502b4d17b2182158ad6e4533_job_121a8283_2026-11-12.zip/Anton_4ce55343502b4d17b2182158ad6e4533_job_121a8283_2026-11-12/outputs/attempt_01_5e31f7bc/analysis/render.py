import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
import ledger
from ledger import *
import custom
import jinja2, pandas as pd
env=jinja2.Environment(undefined=jinja2.StrictUndefined, keep_trailing_newline=True)
fn=dict(ms=ms,mean=mean,rng_=rng_,gmt=gmt,gmt_ci=gmt_ci,fold=fold,pct=pct,tuk=tuk,wel=wel,stu=stu,tc=tc,tcfold=tcfold,tcwel=tcwel,s09=s09,sv=sv,svci=svci,deaths=deaths,lr=lr,fx=fx,wsv=wsv,wnadir=wnadir,c=c)
tpl=env.from_string(open(os.path.join(HERE,'memo.md.j2')).read())
ledger.LOG.clear()
out=tpl.render(**fn)
open(os.path.join(OUT,'PSLN-344_recommendation.md'),'w').write(out)
L=pd.DataFrame(ledger.LOG)
L.insert(0,'order',range(1,len(L)+1))
L.to_csv(os.path.join(WORK,'cited_numbers.csv'),index=False)
print(len(L),'cited numbers;', len(out.split()),'words')

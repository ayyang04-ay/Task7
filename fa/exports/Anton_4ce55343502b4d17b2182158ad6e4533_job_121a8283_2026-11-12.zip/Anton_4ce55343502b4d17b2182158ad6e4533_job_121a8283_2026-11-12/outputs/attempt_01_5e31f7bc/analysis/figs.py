import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
W=pd.read_csv(os.path.join(WORK,'weights_summary.csv'))
def wsurv(block, group):
    r=W[(W.block==block)&(W.group==group)]
    if len(r)==0: return None
    return int(r.surv.iloc[0]), int(r.n.iloc[0])
def sv(k,g):
    d=SV[k].dropna(subset=['time']); x=d[d.group==g]
    if len(x)==0: return None
    return int((x.event==0).sum()), len(x)
# ---------- Figure 1: survival matrix
rows=[
 ('Homologous, day 14', 'S03-I','S13-F','bivalent vaccine → 10× mLD50 CA09 H1N1', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)')),
 ('Heterosubtypic, day 14','S06-A','S15-A','H3N2 vaccine → 5× mLD50 PR8 H1N1', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)')),
 ('Heterosubtypic, day 14','S06-C','S15-C','bivalent → 5× mLD50 rgH5N1', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)')),
 ('Early, day 2–3','S03-J','S13-G','rgH5N1 vaccine → wild-type H5N1, day 2', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344')),
 ('Early, day 2–3','S06-B','S15-B','H3N2 vaccine → PR8 H1N1, day 3', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)')),
 ('Early, day 2–3','S15-H','S15-I','bivalent → rgH5N1, day 3 (Sham column = vaccine alone)', dict(sham='3d Vaccine',p344='3d Vaccine+PSLN-344')),
 ('Late, day 60','S06-E(r34-68)','S15-E','H3N2 vaccine → PR8 H1N1', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)',untr='Untreated')),
 ('Late, day 60','S06-F(r34-68)','S15-F','bivalent → rgH5N1', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)',untr='Untreated')),
 ('Late, day 60','S06-G','S15-G','H1N1 vaccine → Perth H3N2', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)',untr='Untreated')),
 ('Other strains,\n20 months','S15-L','S15-M','C57BL/6; bivalent; challenge not stated', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)')),
 ('Other strains,\n20 months','S15-N','S15-O','Swiss Webster; bivalent; challenge not stated', dict(sham='Sham',p212='PSLN-212',p344='PSLN-344',young='PSLN-212(Y)')),
 ('14-month, ± prior PR8','S06-E(r71-105)','S15-J','saline-primed; bivalent → PR8', dict(p212='Naive+PSLN-212',p344='Naive+PSLN-344')),
 ('14-month, ± prior PR8','S06-E(r71-105)','S15-J','PR8-imprinted; bivalent → PR8', dict(p212='Imprinting+PSLN-212',p344='Imprinting+PSLN-344')),
 ('14-month, ± prior PR8','S06-F(r71-105)','S15-K','saline-primed; bivalent → Perth H3N2', dict(p212='Naive+PSLN-212',p344='Naive+PSLN-344')),
 ('14-month, ± prior PR8','S06-F(r71-105)','S15-K','PR8-imprinted; bivalent → Perth H3N2', dict(p212='Imprinting+PSLN-212',p344='Imprinting+PSLN-344')),
]
cols=[('sham','Sham\n(vaccine +\nempty lipos.)'),('p212','PSLN-212\n(no Mn)\naged'),('p344','PSLN-344\n(Mn)\naged'),('young','PSLN-212\nyoung'),('untr','Untreated,\nunchallenged')]
cmap=LinearSegmentedColormap.from_list('s',['#b2182b','#f4a582','#f7f7f7','#92c5de','#2166ac'])
fig,ax=plt.subplots(figsize=(12.5,7.6))
nrow=len(rows)
XL=-7.6
for i,(cat,sb,wb,desc_,g) in enumerate(rows):
    y=nrow-1-i
    for j,(key,lab) in enumerate(cols):
        if key not in g:
            ax.add_patch(plt.Rectangle((j,y),1,1,fc='#eeeeee',ec='white',lw=2)); ax.text(j+.5,y+.5,'–',ha='center',va='center',color='#999999'); continue
        s_=sv(sb,g[key]); frac=s_[0]/s_[1]
        ax.add_patch(plt.Rectangle((j,y),1,1,fc=cmap(frac),ec='white',lw=2))
        txt=f"{s_[0]}/{s_[1]}"
        w=wsurv(wb,g[key])
        extra=''
        if w is not None and (w[0]!=s_[0]) and not (sb=='S03-J' and key!='p344'):
            extra=f"\n(weights: {w[0]}/{w[1]})"
        if sb=='S03-J' and key=='p344': extra="\n(+1 undated)"
        ax.text(j+.5,y+.5,txt+extra,ha='center',va='center',fontsize=9.5 if not extra else 7.6,color='white' if (frac>0.8 or frac<0.2) else 'black',fontweight='bold')
    ax.text(-0.12,y+.5,desc_,ha='right',va='center',fontsize=8.5)
    ax.text(-4.75,y+.5,sb,ha='left',va='center',fontsize=8.5,family='DejaVu Sans Mono')
cats=[r[0] for r in rows]
start=0
for i in range(1,nrow+1):
    if i==nrow or cats[i]!=cats[start]:
        y0=nrow-i; y1=nrow-start
        ax.plot([-4.9,-4.9],[y0+0.1,y1-0.1],color='#444444',lw=1.5)
        ax.text(-5.0,(y0+y1)/2,cats[start].replace(', ',',\n').replace(',\n\n',',\n'),ha='right',va='center',fontsize=8.5,fontweight='bold')
        start=i
for j,(key,lab) in enumerate(cols):
    ax.text(j+.5,nrow+0.12,lab,ha='center',va='bottom',fontsize=8.5,fontweight='bold')
ax.text(-4.75,nrow+0.12,'Block',ha='left',va='bottom',fontsize=8.5,fontweight='bold')
ax.text(-0.35,nrow+0.12,'Vaccine → challenge',ha='right',va='bottom',fontsize=8.5,fontweight='bold')
ax.set_xlim(XL,len(cols)); ax.set_ylim(0,nrow+1.0); ax.axis('off')
fig.subplots_adjust(left=0.01,right=0.99,top=0.93,bottom=0.085)
fig.text(0.5,0.965,'Survivors / animals at end of observation — every challenge experiment with an aged or 14-month PSLN-344 arm',ha='center',fontsize=11,fontweight='bold')
fig.text(0.02,0.012,"Counts are from the time-to-event rows (event 0 = alive at last recorded day). '(weights: k/n)' marks arms where the paired body-weight block implies a different count.\n"
         "S06-D is omitted: its 28 rows are identical to S06-C. In S03-J the comparator arms carry different labels in the paired weight block S13-G (see audit).",fontsize=7.8,color='#333333',va='bottom')
fig.savefig(os.path.join(OUT,'figures/fig1_survival_matrix.png'),dpi=200)
plt.close(fig)

# ---------- Figure 2: KM curves
def km(t,e,tmax):
    t=np.array(t,float); e=np.array(e,int)
    xs=[0]; ys=[1.0]; s=1.0
    for tt in np.unique(t[e==1]):
        n=(t>=tt).sum(); d=((t==tt)&(e==1)).sum()
        xs+= [tt,tt]; ys+=[s, s*(1-d/n)]; s*= (1-d/n)
    xs.append(tmax); ys.append(s)
    return xs,ys
panels=[('S03-I','Homologous CA09 H1N1, day 14\n(S03-I)',['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)'],14),
        ('S06-A','H3N2 vaccine → PR8 H1N1, day 14\n(S06-A)',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)'],14),
        ('S06-B','H3N2 vaccine → PR8 H1N1, day 3\n(S06-B)',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)'],14),
        ('S03-J','rgH5N1 vaccine → wild-type H5N1, day 2\n(S03-J)',['Sham','PSLN-212','PSLN-344'],21),
        ('S15-H','Bivalent → rgH5N1, day 3: antigen ± adjuvant\n(S15-H)',['3d Vaccine','3d PSLN-344','3d Vaccine+PSLN-344'],14),
        ('S06-G','H1N1 vaccine → Perth H3N2, day 60\n(S06-G)',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)','Untreated'],14)]
colors={'Sham':'#7f7f7f','CMP-204':'#8c6bb1','PSLN-212':'#e08214','PSLN-344':'#2166ac','PSLN-212(Y)':'#1b7837','Untreated':'#000000','3d Vaccine':'#7f7f7f','3d PSLN-344':'#80cdc1','3d Vaccine+PSLN-344':'#2166ac'}
labels={'PSLN-212(Y)':'PSLN-212, young','PSLN-212':'PSLN-212, aged','PSLN-344':'PSLN-344, aged','Untreated':'Untreated, unchallenged','3d Vaccine':'Vaccine alone','3d PSLN-344':'PSLN-344 alone','3d Vaccine+PSLN-344':'Vaccine + PSLN-344','Sham':'Sham','CMP-204':'CMP-204, aged'}
fig,axs=plt.subplots(2,3,figsize=(11.5,7.8))
offs={'Sham':0.0,'CMP-204':0.0,'PSLN-212':0.0,'PSLN-344':0.007,'PSLN-212(Y)':-0.007,'Untreated':-0.014,'3d Vaccine':0,'3d PSLN-344':0.007,'3d Vaccine+PSLN-344':0}
for ax,(k,title,gs,tmax) in zip(axs.ravel(),panels):
    d=SV[k].dropna(subset=['time'])
    for g in gs:
        x=d[d.group==g]
        xs,ys=km(x.time,x.event,tmax)
        s=int((x.event==0).sum()); n=len(x)
        ax.plot(xs,np.array(ys)*100+offs[g]*100,color=colors[g],lw=2,label=f"{labels[g]}  {s}/{n}",ls='--' if g=='Untreated' else '-')
    ax.set_title(title,fontsize=9,fontweight='bold'); ax.set_ylim(-4,106); ax.set_xlim(0,tmax+0.3)
    ax.set_xticks(range(0,tmax+1,2 if tmax<=14 else 3))
    ax.set_xlabel('Days after challenge'); ax.set_ylabel('Survival (%)')
    ax.legend(fontsize=7.6,frameon=False,loc='upper center',bbox_to_anchor=(0.5,-0.17),ncol=2,columnspacing=1.2,handlelength=1.6)
fig.tight_layout(h_pad=1.5)
fig.savefig(os.path.join(OUT,'figures/fig2_km_curves.png'),dpi=200)
plt.close(fig)

# ---------- Figure 3: dose-response + restoration
from scipy.optimize import curve_fit
def hill(d, emax, ed50, h): return 1 + (emax-1)*d**h/(ed50**h + d**h)
fig,axs=plt.subplots(1,2,figsize=(12,5.0),gridspec_kw={'width_ratios':[1,1.3]})
ax=axs[0]
dc={'CMP-204':'#8c6bb1','PSLN-212':'#e08214','PSLN-344':'#2166ac'}
for g in ['CMP-204','PSLN-212','PSLN-344']:
    df=TC['S08-A'][g]
    d=np.repeat(df.index.values.astype(float),3); y=df.values.astype(float).ravel()
    p,cov=curve_fit(hill,d,y,p0=[y.max(),10,2],bounds=([1,0.5,0.5],[200,100,8]))
    xx=np.linspace(0.8,42,200)
    ax.plot(xx,hill(xx,*p),color=dc[g],lw=2,label=f"{g}: plateau {p[0]:.0f}×, ED50 {p[1]:.0f} µg")
    ax.scatter(d,y,color=dc[g],s=16,zorder=3)
ax.axvline(20,color='#999999',ls=':',lw=1); ax.text(20.8,3.0,'20 µg = dose used in\nevery efficacy study',fontsize=7.5,color='#555555',va='bottom')
ax.set_xlabel('Adjuvant dose (µg per animal, intranasal)'); ax.set_ylabel('Lung Ifnb1, fold over untreated (16 h)')
ax.set_title('Mn raises the ceiling of the IFN-β response, not its potency\n(S08-A; points = animals, n = 3 per dose; 3-parameter Hill fit)',fontsize=9,fontweight='bold')
ax.legend(fontsize=7.8,frameon=False,loc='upper left'); ax.set_ylim(0,62)
# restoration
ax=axs[1]
C=pd.read_csv(os.path.join(WORK,'core4_readouts.csv'))
sel=[('S01-A_16h','Lung Ifnb1, 16 h'),('S01-D@d4','Lung monocytes, d4'),('S01-E@d4','Lung CD11b+ DC, d4'),('S02-A','Migratory CD11b+ DC, 72 h'),('S02-D_CD40','CD40+ MLN DC, d3'),('S02-D_CD86','CD86+ MLN DC, d3'),
     ('S03-C','HAI CA09, d14 (GMT)'),('S03-D','Neutralising CA09, d14 (GMT)'),('S03-A','IgG CA09, d14 (GMT)'),('S03-K','GC B cells, d7'),('S04-A_ICOShi','ICOS-hi Tfh, d7'),
     ('S05-D','Ki-67+ CD8 lung, d3'),('S05-E','GZMB+ CD8 lung, d3'),('S05-F','IFN-γ+ CD8 to rgH5N1, d14'),('S05-G','IFN-γ+ CD8 to rgH5N1, d60'),('S05-I','Lung CD8 TRM, d25')]
ys=np.arange(len(sel))[::-1]
for y,(b,lab) in zip(ys,sel):
    r=C[C.block==b].iloc[0]
    ax.plot([r.pct_of_young_212,r.pct_of_young_344],[y,y],color='#bbbbbb',lw=1.5,zorder=1)
    ax.scatter(r.pct_of_young_212,y,color='#e08214',s=45,zorder=3,label='PSLN-212, aged' if y==ys[0] else None)
    ax.scatter(r.pct_of_young_344,y,color='#2166ac',s=45,zorder=3,label='PSLN-344, aged' if y==ys[0] else None)
ax.axvline(100,color='#1b7837',lw=1.5,ls='--'); ax.text(98.5,len(sel)-0.45,'young + PSLN-212 = 100%',color='#1b7837',fontsize=7.5,va='bottom',ha='right')
ax.set_yticks(ys); ax.set_yticklabels([f"{lab}  [{b.split('@')[0].replace('_16h','').replace('_CD40','').replace('_CD86','').replace('_ICOShi','')}]" for b,lab in sel],fontsize=8)
ax.set_xlabel('Aged response as % of the young PSLN-212 response\n(ratio of group means; ratio of geometric means for titres)')
ax.set_xlim(0,108); ax.set_ylim(-0.7,len(sel)+0.5)
ax.set_title('Share of the young response recovered in aged mice (n = 5 per group)\n',fontsize=9,fontweight='bold')
ax.legend(fontsize=8,frameon=True,loc='lower left',bbox_to_anchor=(0.0,1.0),ncol=2,borderaxespad=0.2,framealpha=0.0)
fig.tight_layout()
fig.savefig(os.path.join(OUT,'figures/fig3_mechanism.png'),dpi=200)
plt.close(fig)
print('done')

import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import numpy as np, pandas as pd
from statsmodels.stats.contingency_tables import StratifiedTable
pd.set_option('display.width',250); pd.set_option('display.max_rows',500)
W=pd.read_csv(os.path.join(WORK,'weights_summary.csv'))
def wsurv(block, group):
    r=W[(W.block==block)&(W.group==group)]
    if len(r)==0: return None
    return int(r.surv.iloc[0]), int(r.n.iloc[0])
def get(k,g):
    d=SV[k].dropna(subset=['time']); x=d[d.group==g]; return x.time.values.astype(float), x.event.values.astype(int)
# head-to-head aged comparisons: (label, survival block, weight block, 344 name, 212 name, sham name, description)
H=[('S03-I','S13-F','PSLN-344','PSLN-212','Sham','aged BALB/c; bivalent vaccine; 10x mLD50 CA09 H1N1 (homologous), d14'),
   ('S03-J','S13-G','PSLN-344','PSLN-212','Sham','aged BALB/c; rgH5N1 vaccine; wild-type VN04 H5N1, d2'),
   ('S06-A','S15-A','PSLN-344','PSLN-212','Sham','aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1, d14'),
   ('S06-B','S15-B','PSLN-344','PSLN-212','Sham','aged BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1, d3'),
   ('S06-C','S15-C','PSLN-344','PSLN-212','Sham','aged BALB/c; bivalent; 5x mLD50 rgH5N1, d14'),
   ('S06-D','S15-D','PSLN-344','PSLN-212','Sham','aged BALB/c; bivalent; 5x mLD50 rgH5N1, d3 [verbatim duplicate of S06-C]'),
   ('S06-E(r34-68)','S15-E','PSLN-344','PSLN-212','Sham','aged BALB/c; Aichi H3N2 vaccine; PR8 H1N1, d60'),
   ('S06-F(r34-68)','S15-F','PSLN-344','PSLN-212','Sham','aged BALB/c; bivalent; rgH5N1, d60'),
   ('S06-G','S15-G','PSLN-344','PSLN-212','Sham','aged BALB/c; CA09 H1N1 vaccine; Perth H3N2, d60'),
   ('S15-L','S15-M','PSLN-344','PSLN-212','Sham','aged C57BL/6 (20 mo); bivalent; challenge not stated'),
   ('S15-N','S15-O','PSLN-344','PSLN-212','Sham','aged Swiss Webster (20 mo); bivalent; challenge not stated'),
   ('S06-E(r71-105)','S15-J','Naive+PSLN-344','Naive+PSLN-212',None,'14-mo BALB/c, saline-primed; bivalent; 5x LD50 PR8'),
   ('S06-E(r71-105)','S15-J','Imprinting+PSLN-344','Imprinting+PSLN-212',None,'14-mo BALB/c, PR8-imprinted; bivalent; 5x LD50 PR8'),
   ('S06-F(r71-105)','S15-K','Naive+PSLN-344','Naive+PSLN-212',None,'14-mo BALB/c, saline-primed; bivalent; 5x LD50 Perth H3N2, d14'),
   ('S06-F(r71-105)','S15-K','Imprinting+PSLN-344','Imprinting+PSLN-212',None,'14-mo BALB/c, PR8-imprinted; bivalent; 5x LD50 Perth H3N2, d14')]
rows=[]
for sb,wb,g3,g2,gs,desc_ in H:
    t3,e3=get(sb,g3); t2,e2=get(sb,g2)
    s3=int((e3==0).sum()); n3=len(e3); s2=int((e2==0).sum()); n2=len(e2)
    chi,p=logrank(t3,e3,t2,e2); pf=fisher(s3,n3,s2,n2)
    r=dict(surv_block=sb,desc=desc_,PSLN344=f"{s3}/{n3}",PSLN212=f"{s2}/{n2}",logrank_p=p,fisher_p=pf)
    if gs:
        ts,es=get(sb,gs); r['Sham']=f"{int((es==0).sum())}/{len(es)}"; r['lr_344_vs_sham']=logrank(t3,e3,ts,es)[1]
    w3=wsurv(wb,g3); w2=wsurv(wb,g2)
    r['wt_block']=wb; r['w344']=f"{w3[0]}/{w3[1]}" if w3 else 'n/a'; r['w212']=f"{w2[0]}/{w2[1]}" if w2 else 'n/a'
    if w3 and w2: r['w_fisher_p']=fisher(w3[0],w3[1],w2[0],w2[1])
    rows.append(r)
R=pd.DataFrame(rows)
print(R.drop(columns=['desc']).to_string(float_format=lambda x:f"{x:.4g}"))
R.to_csv(os.path.join(WORK,'head_to_head.csv'),index=False)

def pooled(idx, label, use_weights=False):
    tabs=[]; strata=[]; a=b=c=d=0
    for i in idx:
        sb,wb,g3,g2,gs,_=H[i]
        if use_weights:
            w3=wsurv(wb,g3); w2=wsurv(wb,g2)
            if not (w3 and w2): 
                t3,e3=get(sb,g3); t2,e2=get(sb,g2)
                w3=(int((e3==0).sum()),len(e3)) if not w3 else w3
                w2=(int((e2==0).sum()),len(e2)) if not w2 else w2
            s3,n3=w3; s2,n2=w2
        else:
            t3,e3=get(sb,g3); t2,e2=get(sb,g2)
            s3=int((e3==0).sum()); n3=len(e3); s2=int((e2==0).sum()); n2=len(e2)
            strata.append((t3,e3,t2,e2))
        tabs.append(np.array([[s3,n3-s3],[s2,n2-s2]]))
        a+=s3;b+=n3;c+=s2;d+=n2
    st=StratifiedTable(tabs)
    cmh=st.test_null_odds(correction=True)
    out=f"{label}: PSLN-344 {a}/{b} ({100*a/b:.0f}%, CP95 {100*cp_ci(a,b)[0]:.0f}-{100*cp_ci(a,b)[1]:.0f}) vs PSLN-212 {c}/{d} ({100*c/d:.0f}%, CP95 {100*cp_ci(c,d)[0]:.0f}-{100*cp_ci(c,d)[1]:.0f}); CMH chi2={cmh.statistic:.1f} p={cmh.pvalue:.2e}; pooled Fisher p={fisher(a,b,c,d):.2e}"
    if strata:
        chi,p,O,E=logrank_strat(strata); out+=f"; stratified log-rank chi2={chi:.1f} p={p:.2e}"
    print(out)
print()
allidx=list(range(len(H)))
pooled(allidx,'ALL 15 strata as recorded (survival blocks)')
pooled([i for i in allidx if i!=5],'Excluding S06-D duplicate (14 strata), survival blocks')
pooled([i for i in range(11) if i!=5],'Aged >=20 mo only, excl S06-D (10 strata), survival blocks')
pooled([i for i in range(9) if i!=5],'Aged BALB/c only, excl S06-D (8 strata)')
pooled(allidx,'ALL 15 strata, weight-derived outcomes where a paired weight block carries the arm',use_weights=True)
pooled([i for i in range(11)],'Aged >=20 mo (11 strata incl. S15-D weights for the d3 rgH5N1 experiment), weight-derived',use_weights=True)
# (the least-favourable-reading analysis used in the memo is computed in custom.py)
# sham pooled
a=b=0
for sb in ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-E(r34-68)','S06-F(r34-68)','S06-G','S15-L','S15-N']:
    t,e=get(sb,'Sham'); a+=int((e==0).sum()); b+=len(e)
print('Sham aged pooled (10 blocks excl. S06-D):',a,'/',b)
# untreated
a=b=0
for sb in ['S06-E(r34-68)','S06-F(r34-68)','S06-G']:
    t,e=get(sb,'Untreated'); a+=int((e==1).sum()); b+=len(e)
print('Untreated unchallenged deaths pooled:',a,'/',b, 'CP95', [round(100*x,1) for x in cp_ci(a,b)])
# d14 vs d60 for 344
for lab,bl in [('d14 (S06-A,S06-C)',['S06-A','S06-C']),('d60 (S06-E,F,G r34-68/71-105)',['S06-E(r34-68)','S06-F(r34-68)','S06-G']),('d3 (S06-B)',['S06-B']),('d2-3 (S06-B,S03-J,S15-H)',['S06-B','S03-J','S15-H'])]:
    a=b=0
    for sb in bl:
        g='PSLN-344' if sb!='S15-H' else '3d Vaccine+PSLN-344'
        t,e=get(sb,g); a+=int((e==0).sum()); b+=len(e)
    print('PSLN-344',lab,a,'/',b, 'CP95', [round(100*x) for x in cp_ci(a,b)])
print('d14 13/14 vs d60 14/21 Fisher p', fisher(13,14,14,21))

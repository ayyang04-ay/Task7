#!/usr/bin/env bash
# Rebuilds every number, figure, the memo and the ledger from the source workbook.
# Needs: python with openpyxl, pandas, numpy, scipy, statsmodels, matplotlib, jinja2, xlsxwriter; pandoc for the .docx.
# In this environment:  PY="micromamba run -n chem python"  PANDOC=/opt/conda/envs/renv/bin/pandoc  ./run_all.sh
set -euo pipefail
cd "$(dirname "$0")"
HERE_DIR="$(pwd)"
PY=${PY:-python}
PANDOC=${PANDOC:-pandoc}
$PY surv_analysis.py  > /dev/null   # survival by arm, pairwise log-rank / Fisher
$PY desc_all.py       > /dev/null   # group statistics, single-time-point blocks
$PY desc_tc.py        > /dev/null   # group statistics, time-course blocks and S09-A
$PY tests_all.py      > /dev/null   # ANOVA / Tukey / Welch / Mann-Whitney
$PY weights.py        > /dev/null   # per-animal reading of the challenge body-weight blocks
$PY biomarker.py      > /dev/null   # readouts across the four core arms
$PY pooled.py         > /dev/null   # head-to-head strata and pooled survival
$PY figs.py                         # figures 1-3
$PY render.py                       # memo (markdown) + list of cited numbers
$PY build_ledger.py                 # PSLN-344_numbers_ledger.xlsx
OUT_DIR=${PSLN_OUT:-$HERE_DIR/..}
( cd "$OUT_DIR" && $PANDOC PSLN-344_recommendation.md -f markdown+pipe_tables+implicit_figures -o PSLN-344_recommendation.docx --reference-doc="$HERE_DIR/reference.docx" --resource-path=. )
# Audit scripts (print to screen): concord.py, dups.py, share.py, svdup.py, xref.py, dose.py

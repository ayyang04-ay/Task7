"""Locations used by every script. Override with environment variables if needed."""
import os
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('PSLN_DATA', '/tmp/world/filesystem/adjuvant_program_dataset.xlsx')   # the source workbook
WORK = os.environ.get('PSLN_WORK', os.path.join(HERE, 'work'))                               # intermediate CSVs
OUT  = os.environ.get('PSLN_OUT',  os.path.dirname(HERE))                                    # memo, ledger, figures
os.makedirs(WORK, exist_ok=True)
os.makedirs(os.path.join(OUT, 'figures'), exist_ok=True)

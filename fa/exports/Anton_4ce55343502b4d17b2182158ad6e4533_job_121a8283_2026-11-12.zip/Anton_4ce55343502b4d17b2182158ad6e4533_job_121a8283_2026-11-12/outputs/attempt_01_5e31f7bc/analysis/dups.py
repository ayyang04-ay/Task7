import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
import itertools, numpy as np
# collect vectors: per group in simple blocks; per group-per-day and per-animal in timecourses
vecs=[]
for k,d in B.items():
    for g,v in d.items():
        vecs.append((k,g,'grp',tuple(v)))
for k,d in TC.items():
    for g,df in d.items():
        for day,row in df.iterrows():
            v=tuple(x for x in row.tolist() if x is not None and not (isinstance(x,float) and np.isnan(x)))
            if len(v)>=2: vecs.append((k,g,f'day{day}',v))
        for c in df.columns:
            v=tuple(x for x in df[c].tolist() if x is not None and not (isinstance(x,float) and np.isnan(x)))
            if len(v)>=3: vecs.append((k,g,f'animal{c}',v))
for an,d in S09A1.items():
    for g,v in d.items(): vecs.append(('S09-A_p1',g,an,tuple(v)))
for an,d in S09A2.items():
    for g,v in d.items(): vecs.append(('S09-A_p2',g,an,tuple(v)))
print(len(vecs),'vectors')
# exact duplicates (ignoring all-100 rows)
from collections import defaultdict
dd=defaultdict(list)
for k,g,t,v in vecs:
    if len(set(v))<=1: continue
    dd[v].append((k,g,t))
print('--- exact duplicate vectors ---')
for v,lst in dd.items():
    if len(lst)>1:
        print(lst, v)
# same multiset different order
dd2=defaultdict(list)
for k,g,t,v in vecs:
    if len(set(v))<=1: continue
    dd2[tuple(sorted(v))].append((k,g,t))
print('--- same multiset (different order) ---')
for v,lst in dd2.items():
    if len(lst)>1 and len(set((a,b) for a,b,c in lst))>1:
        keys=[x for x in lst]
        if not any(len(l2)>1 and v2==v for v2,l2 in dd.items() if tuple(sorted(v2))==v and len(l2)==len(lst)):
            print(lst, v)
# partial overlaps: vectors sharing >=3 position-matched values (non-100)
print('--- partial positional overlap (>=60% identical positions, len>=4) ---')
for (k1,g1,t1,v1),(k2,g2,t2,v2) in itertools.combinations(vecs,2):
    if len(v1)!=len(v2) or len(v1)<4: continue
    if v1==v2: continue
    same=sum(1 for a,b in zip(v1,v2) if a==b and a!=100)
    if same>=0.6*len(v1) and same>=3:
        print((k1,g1,t1),(k2,g2,t2),same,'/',len(v1)); print('    ',v1); print('    ',v2)

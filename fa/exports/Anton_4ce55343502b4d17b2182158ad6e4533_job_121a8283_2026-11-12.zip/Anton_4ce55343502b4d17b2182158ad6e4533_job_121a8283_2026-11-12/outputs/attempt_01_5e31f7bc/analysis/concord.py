import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
import numpy as np
pairs = [('S03-I','S13-F'),('S03-J','S13-G'),('S06-A','S15-A'),('S06-B','S15-B'),('S06-C','S15-C'),('S06-D','S15-D'),
         ('S06-E(r34-68)','S15-E'),('S06-F(r34-68)','S15-F'),('S06-G','S15-G'),('S15-H','S15-I'),('S06-E(r71-105)','S15-J'),('S06-F(r71-105)','S15-K'),
         ('S15-L','S15-M'),('S15-N','S15-O'),('S09-B','S09-C'),('S09-D','S09-E'),('S09-F','S09-G')]
def norm(g): return g.replace('ï','i').replace(' ','').replace('(Y)','Y').replace('(y)','Y')
def infer(df):
    """df index=day, cols animals. returns list of (last_day_alive_or_changing, status, final_value)"""
    res=[]
    days=list(df.index)
    for c in df.columns:
        v=df[c].tolist()
        # last non-null
        nn=[i for i,x in enumerate(v) if x is not None and not (isinstance(x,float) and np.isnan(x))]
        if not nn: res.append((None,'empty',None)); continue
        last=nn[-1]
        if days[last] < days[-1]:
            res.append((days[last],'blank_after',v[last]))
        else:
            # check carried-forward constant tail
            j=last
            while j>0 and v[j-1]==v[last]: j-=1
            if j<last and v[last] < 90:   # constant tail of >=2 identical values, low weight
                res.append((days[j],'flat_tail(LOCF?)',v[last]))
            elif j<last:
                res.append((days[j],'flat_tail_high',v[last]))
            else:
                res.append((days[last],'alive_d14',v[last]))
    return res
for s,w in pairs:
    print('=====',s,'<->',w)
    sv=SV[s]; tc=TC[w]
    sgroups={norm(g):d for g,d in sv.groupby('group',sort=False)}
    for g,df in tc.items():
        inf=infer(df)
        alive=sum(1 for x in inf if x[1] in('alive_d14','flat_tail_high'))
        desc=', '.join(f"{x[1][:5]}@{x[0]}({x[2]})" if x[1]!='alive_d14' else f"ok({x[2]})" for x in inf)
        ng=norm(g)
        if ng in sgroups:
            d=sgroups[ng]
            surv=int((d.event==0).sum()); n=len(d)
            deaths=sorted(d[d.event==1].time.tolist())
            flag = '' if surv==alive else '   <<<<< MISMATCH'
            print(f"  {g:22s} weights: apparent survivors {alive}/{len(inf)} | survival block: {surv}/{n} alive, deaths at {deaths}{flag}")
        else:
            print(f"  {g:22s} weights: apparent survivors {alive}/{len(inf)} | NOT IN SURVIVAL BLOCK (survival groups: {list(sgroups)})")
        print('       ', desc)
    for g in sgroups:
        if g not in [norm(x) for x in tc]:
            d=sgroups[g]; print(f"  survival-only group {g}: {int((d.event==0).sum())}/{len(d)} alive; deaths {sorted(d[d.event==1].time.tolist())}")

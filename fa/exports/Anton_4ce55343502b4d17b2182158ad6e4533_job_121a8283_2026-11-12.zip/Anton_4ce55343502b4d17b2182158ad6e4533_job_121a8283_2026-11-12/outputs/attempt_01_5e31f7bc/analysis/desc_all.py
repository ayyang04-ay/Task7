import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
from stats_util import *
import pandas as pd, numpy as np
pd.set_option('display.width',250); pd.set_option('display.max_columns',30); pd.set_option('display.max_rows',1000)
TITRE = {'S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}
HAI = {'S03-C','S03-G'}
rows=[]
for k,d in B.items():
    for g,v in d.items():
        r=dict(block=k,group=g,**desc(v))
        if k in TITRE:
            fl = 5 if k in HAI else None
            gm,lo,hi=gm_ci(v,floor=fl); r.update(gmean=gm,gm_lo=lo,gm_hi=hi)
        rows.append(r)
D=pd.DataFrame(rows)
D.to_csv(os.path.join(WORK,'desc_simple.csv'),index=False)
print(D.round(3).to_string())

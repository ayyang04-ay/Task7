import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
import numpy as np
print("=== S09-A panel1 Ifnb1 (10**x) vs S01-A 16h / 72h ===")
for g in S09_groups:
    g1 = g.replace('(y)','(Y)').replace('PBS','Sham')
    p1=[round(10**x,2) for x in S09A1['Ifnb1'][g]]
    p2=[round(10**x,2) for x in S09A2['Ifnb1'][g]]
    print(f"{g:14s} panel1->{p1}  S01-A16h {B['S01-A_16h'][g1]}")
    print(f"{'':14s} panel2->{p2}  S01-A72h {B['S01-A_72h'][g1]}")
print()
print("=== S03-B vs S13-A/S13-B ; S03-F vs S13-C/S13-D ===")
for rb,a,b in [('S03-B','S13-A','S13-B'),('S03-F','S13-C','S13-D')]:
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        calc=[round(x/y,6) for x,y in zip(B[a][g],B[b][g])]
        print(rb,g,'stored:',[round(x,4) for x in B[rb][g]])
        print('   ','calc from',a,'/',b,':',[round(x,4) for x in calc])
        # find which stored column matches
        for g2 in B[rb]:
            if np.allclose(B[rb][g2],calc,rtol=1e-4): print('    --> calc for',g,'matches stored column labelled',g2)
print()
print("=== S04-B Tfh:Tfr vs (100-Foxp3)/Foxp3 and vs S04-A ===")
for g in B['S04-B_Foxp3']:
    f=B['S04-B_Foxp3'][g]; r=B['S04-B_TfhTfr'][g]
    calc=[(100-x)/x for x in f]
    tfh=[a+b for a,b in zip(B['S04-A_ICOSlo'][g],B['S04-A_ICOShi'][g])]
    print(g,'stored',[round(x,3) for x in r],'calc(100-F)/F',[round(x,3) for x in calc], 'match' if np.allclose(r,calc,rtol=1e-4) else 'MISMATCH')
    print('    Tfh total (ICOSlo+ICOShi)',[round(x,2) for x in tfh],' ICOShi frac',[round(b/(a+b),3) for a,b in zip(B['S04-A_ICOSlo'][g],B['S04-A_ICOShi'][g])], ' Tfh/Foxp3%:',[round(a/b,3) for a,b in zip(tfh,f)])
print()
print("=== S01-B vs S08-C ===")
for k in ['S01-B','S08-C']:
    for g,v in B[k].items(): print(k,g,v, round(np.mean(v),2))

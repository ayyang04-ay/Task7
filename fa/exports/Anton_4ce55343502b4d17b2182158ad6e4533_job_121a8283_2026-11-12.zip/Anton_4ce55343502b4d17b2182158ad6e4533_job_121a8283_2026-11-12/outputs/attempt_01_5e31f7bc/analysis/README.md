# Analysis scripts

`run_all.sh` rebuilds everything in the parent folder from `adjuvant_program_dataset.xlsx`.

| Script | What it does |
|:--|:--|
| `paths.py` | Where the workbook, intermediate files and outputs live |
| `load.py`, `blocks.py` | Read the workbook cell by cell and define every block (sheet, cell range, groups) |
| `stats_util.py` | Descriptive statistics, geometric means, ANOVA/Tukey, log-rank, exact tests |
| `surv_analysis.py` | Survival by arm; pairwise log-rank and Fisher tests |
| `desc_all.py`, `desc_tc.py`, `tests_all.py` | Group statistics and tests for every non-survival block |
| `weights.py` | Per-animal reading of the challenge body-weight blocks (survivor / dead, lowest weight) |
| `biomarker.py` | Every readout measured in the four core arms; aged as % of young |
| `pooled.py` | PSLN-344 vs PSLN-212 by stratum; pooled and sensitivity analyses |
| `dose.py` | Hill fits to the Ifnb1 dose series (S08-A) |
| `figs.py` | Figures 1-3 |
| `ledger.py`, `custom.py`, `render.py`, `memo.md.j2` | The memo is a template; every number in it is computed at render time and logged to the ledger |
| `build_ledger.py` | Writes `PSLN-344_numbers_ledger.xlsx` |
| `concord.py`, `dups.py`, `share.py`, `svdup.py`, `xref.py` | Audit checks: survival vs weight blocks, duplicated vectors, shared weight traces, duplicated survival arms, cross-block derivations |

import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from blocks import *
import numpy as np, itertools, pandas as pd
WBK = ['S13-F','S13-G','S15-A','S15-B','S15-C','S15-D','S15-E','S15-F','S15-G','S15-I','S15-J','S15-K','S15-M','S15-O','S09-C','S09-E','S09-G','S08-D']
traces=[]
for k in WBK:
    for g,df in TC[k].items():
        days=list(df.index)
        for c in df.columns:
            v=df[c].tolist()
            traces.append((k,g,c,days,v))
def same(v1,d1,v2,d2):
    n=0; tot=0
    for x,dx in zip(v1,d1):
        if dx==0 or x is None or (isinstance(x,float) and np.isnan(x)): continue
        if dx in d2:
            y=v2[d2.index(dx)]
            if y is None or (isinstance(y,float) and np.isnan(y)): continue
            tot+=1
            if x==y: n+=1
    return n,tot
pairs=[]
for (k1,g1,c1,d1,v1),(k2,g2,c2,d2,v2) in itertools.combinations(traces,2):
    if k1==k2: continue
    n,tot=same(v1,d1,v2,d2)
    if tot>=4 and n>=4:
        # exclude matches that are only the flat LOCF tail (same repeated value)
        shared=[x for x,dx in zip(v1,d1) if dx!=0 and dx in d2 and v2[d2.index(dx)]==x]
        if len(set(shared))>=3:
            pairs.append((k1,g1,c1,k2,g2,c2,n,tot,len(set(shared))))
P=pd.DataFrame(pairs,columns=['blk1','grp1','an1','blk2','grp2','an2','n_same','n_comp','n_distinct_shared'])
print(P.to_string())
print()
print(P.groupby(['blk1','grp1','blk2','grp2']).size())

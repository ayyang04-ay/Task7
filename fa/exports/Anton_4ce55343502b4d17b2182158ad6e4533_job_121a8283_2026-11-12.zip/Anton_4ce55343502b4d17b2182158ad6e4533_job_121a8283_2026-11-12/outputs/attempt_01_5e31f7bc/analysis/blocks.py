import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import HERE, WORK, OUT, DATA
import sys
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from load import *

B = {}   # simple group->values blocks
TC = {}  # timecourse blocks: name -> {group: DataFrame(index=day)}
SV = {}  # survival blocks: name -> DataFrame(group,time,event,row)
META = {}

def add(name, d, **meta):
    B[name]=d; META[name]=meta

# ---------------- S01
add('S01-A_16h', groups_in_rows('S01','A',3,10,'B','F'), stated_n=5, loc='S01!A3:F10')
add('S01-A_72h', groups_in_rows('S01','G',3,10,'H','L'), stated_n=5, loc='S01!G3:L10')
add('S01-B', groups_in_rows('S01','A',14,17,'B','F'), stated_n=5, loc='S01!A14:F17')
add('S01-C', groups_in_rows('S01','A',20,21,'B','E'), stated_n=4, loc='S01!A20:E21')
TC['S01-D'] = timecourse('S01',23,24,28,'A',{'Sham':'B','PSLN-212':'G','PSLN-344':'L','PSLN-212(Y)':'Q'},5); META['S01-D']=dict(stated_n=5, loc='S01!A23:U28')
TC['S01-E'] = timecourse('S01',29,30,34,'A',{'Sham':'B','PSLN-212':'G','PSLN-344':'L','PSLN-212(Y)':'Q','PSLN-344(Y)':'V'},5); META['S01-E']=dict(stated_n=5, loc='S01!A29:Z34')
def rowgroups(sheet,row,starts,width):
    return {k:[v for v in rowvals(sheet,row,c,L(CI(c)+width-1)) if v is not None] for k,c in starts.items()}
add('S01-F', rowgroups('S01',36,{'Sham':'B','PSLN-212':'G','PSLN-344':'L','PSLN-212(Y)':'Q','PSLN-344(Y)':'V'},5), stated_n=5, loc='S01!B35:Z36')
add('S01-G', rowgroups('S01',38,{'Sham':'B','PSLN-212':'G','PSLN-344':'L','PSLN-212(Y)':'Q','PSLN-344(Y)':'V'},5), stated_n=5, loc='S01!B37:Z38')
# ---------------- S02
add('S02-A', groups_in_columns('S02',2,3,7,'A','D'), stated_n=5, loc='S02!A2:D7')
add('S02-B', groups_in_columns('S02',2,3,7,'F','I'), stated_n=5, loc='S02!F2:I7')
add('S02-C', groups_in_columns('S02',2,3,7,'K','O'), stated_n=5, loc='S02!K2:O7')
add('S02-D_CD40', groups_in_columns('S02',9,10,14,'A','D'), stated_n=5, loc='S02!A9:D14')
add('S02-D_CD86', groups_in_columns('S02',9,10,14,'F','I'), stated_n=5, loc='S02!F9:I14')
add('S02-E', groups_in_columns('S02',9,10,14,'K','O'), stated_n=5, loc='S02!K9:O14')
TC['S02-F'] = timecourse('S02',16,17,19,'A',{'PSLN-344':'B','PSLN-212':'G','Sham':'L'},5); META['S02-F']=dict(stated_n=5, loc='S02!A16:P19')
add('S02-G', groups_in_columns('S02',21,22,26,'B','D'), stated_n=5, loc='S02!B21:D26')
add('S02-H', groups_in_columns('S02',29,30,34,'B','F'), stated_n=5, loc='S02!B29:F34')
add('S02-I', groups_in_columns('S02',29,30,34,'H','I'), stated_n=5, loc='S02!H29:I34')
# ---------------- S03
add('S03-A', groups_in_columns('S03',2,3,7,'A','E'), stated_n=5, loc='S03!A2:E7')
add('S03-B', groups_in_columns('S03',2,3,7,'G','I'), stated_n=5, loc='S03!G2:I7')
add('S03-C', groups_in_columns('S03',2,3,7,'K','O'), stated_n=5, loc='S03!K2:O7')
add('S03-D', groups_in_columns('S03',2,3,7,'Q','U'), stated_n=5, loc='S03!Q2:U7')
add('S03-E', groups_in_columns('S03',9,10,14,'A','E'), stated_n=5, loc='S03!A9:E14')
add('S03-F', groups_in_columns('S03',9,10,14,'G','I'), stated_n=5, loc='S03!G9:I14')
add('S03-G', groups_in_columns('S03',9,10,14,'K','O'), stated_n=5, loc='S03!K9:O14')
add('S03-H', groups_in_columns('S03',9,10,14,'Q','U'), stated_n=5, loc='S03!Q9:U14')
SV['S03-I'] = survival('S03','A',17,51,['B','C','D','E','F'],16); META['S03-I']=dict(stated_n=7, loc='S03!A16:F51')
SV['S03-J'] = survival('S03','G',17,46,['H','I','J'],16); META['S03-J']=dict(stated_n=9, loc='S03!G16:J46')
add('S03-K', groups_in_columns('S03',16,17,21,'L','O'), stated_n=5, loc='S03!L16:O21')
add('S03-L_Aicda', groups_in_rows('S03','K',26,28,'L','N'), stated_n=3, loc='S03!K25:N28')
add('S03-L_E47', groups_in_rows('S03','K',26,28,'O','Q'), stated_n=3, loc='S03!K25:Q28')
# ---------------- S04
add('S04-A_ICOSlo', groups_in_rows('S04','A',2,5,'B','F'), stated_n=5, loc='S04!A1:F5')
add('S04-A_ICOShi', groups_in_rows('S04','A',2,5,'G','K'), stated_n=5, loc='S04!A1:K5')
add('S04-B_Foxp3', groups_in_columns('S04',7,8,12,'A','D'), stated_n=5, loc='S04!A7:D12')
add('S04-B_TfhTfr', groups_in_columns('S04',14,15,19,'A','D'), stated_n=5, loc='S04!A14:D19')
add('S04-C', groups_in_columns('S04',21,22,26,'A','D'), stated_n=5, loc='S04!A21:D26')
add('S04-D', groups_in_columns('S04',28,29,31,'A','D'), stated_n=3, loc='S04!A28:D31')
# ---------------- S05
TC['S05-A'] = timecourse('S05',2,3,5,'A',{'PSLN-212':'B','PSLN-344':'E','PSLN-212Y':'H'},2); META['S05-A']=dict(stated_n=3, loc='S05!A2:I5')
TC['S05-B'] = timecourse('S05',7,8,10,'A',{'PSLN-212':'B','PSLN-344':'E','PSLN-212Y':'H'},2); META['S05-B']=dict(stated_n=3, loc='S05!A7:I10')
add('S05-C', groups_in_columns('S05',12,13,15,'A','D'), stated_n=3, loc='S05!A12:D15')
for nm,h in [('S05-D',18),('S05-E',25),('S05-F',32),('S05-G',39),('S05-H',46),('S05-I',53)]:
    add(nm, groups_in_columns('S05',h,h+1,h+5,'A','D'), stated_n=5, loc=f'S05!A{h}:D{h+5}')
# ---------------- S06
SV['S06-A'] = survival('S06','A',3,30,['B','C','D','E'],2); META['S06-A']=dict(stated_n=7, loc='S06!A2:E30')
SV['S06-B'] = survival('S06','G',3,30,['H','I','J','K'],2); META['S06-B']=dict(stated_n=7, loc='S06!G2:K30')
SV['S06-C'] = survival('S06','M',3,30,['N','O','P','Q'],2); META['S06-C']=dict(stated_n=7, loc='S06!M2:Q30')
SV['S06-D'] = survival('S06','A',34,61,['B','C','D','E'],33); META['S06-D']=dict(stated_n=7, loc='S06!A33:E61')
SV['S06-E(r34-68)'] = survival('S06','G',34,68,['H','I','J','K','L'],33); META['S06-E(r34-68)']=dict(stated_n=7, loc='S06!G33:L68')
SV['S06-F(r34-68)'] = survival('S06','M',34,68,['N','O','P','Q','R'],33); META['S06-F(r34-68)']=dict(stated_n=7, loc='S06!M33:R68')
SV['S06-G'] = survival('S06','A',71,105,['B','C','D','E','F'],70); META['S06-G']=dict(stated_n=7, loc='S06!A70:F105')
SV['S06-E(r71-105)'] = survival('S06','G',71,98,['H','I','J','K'],70); META['S06-E(r71-105)']=dict(stated_n=7, loc='S06!G70:K98')
SV['S06-F(r71-105)'] = survival('S06','M',71,98,['N','O','P','Q'],70); META['S06-F(r71-105)']=dict(stated_n=7, loc='S06!M70:Q98')
# ---------------- S07
TC['S07-A'] = timecourse('S07',2,3,7,'A',{'PSLN-212':'B','PSLN-344':'E'},3); META['S07-A']=dict(stated_n=3, loc='S07!A2:H7')
add('S07-B_mono', groups_in_columns('S07',9,10,14,'B','C'), stated_n=5, loc='S07!B8:C14')
add('S07-B_Ly6Cmac', groups_in_columns('S07',9,10,14,'E','F'), stated_n=5, loc='S07!E8:F14')
add('S07-C', groups_in_columns('S07',15,16,20,'B','C'), stated_n=5, loc='S07!B15:C20')
# ---------------- S08
TC['S08-A'] = timecourse('S08',2,3,7,'A',{'CMP-204':'B','PSLN-212':'E','PSLN-344':'H','PSLN-344/R848':'K'},3); META['S08-A']=dict(stated_n=3, loc='S08!A2:M7')
add('S08-B', rowgroups('S08',11,{'CMP-204':'A','PSLN-212':'D','PSLN-R848':'G','PSLN-212/R848':'J','PSLN-344':'M'},3), stated_n=3, loc='S08!A10:O11')
add('S08-C', groups_in_columns('S08',13,14,18,'A','D'), stated_n=5, loc='S08!A13:D18')
TC['S08-D'] = timecourse('S08',20,21,26,'A',{'PSLN-212(Y)':'B','CMP-204':'G','PSLN-212':'L','PSLN-344':'Q','PSLN-212/R848':'V','Vaccine':'AA'},5); META['S08-D']=dict(stated_n=5, loc='S08!A20:AE26')
# ---------------- S09
S09_groups = ['PBS','CMP-204','PSLN-212','PSLN-R848','PSLN-212/R848','PSLN-344','PSLN-212(y)']
def s09a(starts, namecol):
    out={}
    for r in range(3,10):
        an = cell('S09', f'{namecol}{r}')
        out[an] = {g:[v for v in rowvals('S09', r, c, L(CI(c)+2))] for g,c in zip(S09_groups, starts)}
    return out
S09A1 = s09a(['B','E','H','K','N','Q','T'],'A')
S09A2 = s09a(['Y','AB','AE','AH','AK','AN','AQ'],'X')
SV['S09-B'] = survival('S09','A',12,35,['B','C','D'],11); META['S09-B']=dict(stated_n=8, loc='S09!A11:D35')
TC['S09-C'] = timecourse('S09',11,12,19,'F',{'PSLN-212Y':'G','Sham':'O','PSLN-344Y':'W'},8); META['S09-C']=dict(stated_n=8, loc='S09!F11:AD19')
SV['S09-D'] = survival('S09','A',39,62,['B','C','D'],38); META['S09-D']=dict(stated_n=8, loc='S09!A38:D62')
TC['S09-E'] = timecourse('S09',38,39,46,'F',{'PSLN-212Y':'G','Sham':'O','PSLN-344Y':'W'},8); META['S09-E']=dict(stated_n=8, loc='S09!F38:AD46')
SV['S09-F'] = survival('S09','A',66,88,['B','C','D'],65); META['S09-F']=dict(stated_n=8, loc='S09!A65:D88')
TC['S09-G'] = timecourse('S09',65,66,73,'F',{'PSLN-212Y':'G','Sham':'O','PSLN-344Y':'W'},8); META['S09-G']=dict(stated_n=8, loc='S09!F65:AD73')
# ---------------- S10
add('S10-A_Ifnb1', groups_in_columns('S10',2,3,7,'A','D'), stated_n=5, loc='S10!A2:D7')
add('S10-A_Tnf', groups_in_columns('S10',2,3,7,'F','I'), stated_n=5, loc='S10!F2:I7')
add('S10-A_Isg15', groups_in_columns('S10',2,3,7,'K','N'), stated_n=5, loc='S10!K2:N7')
# ---------------- S11
g4 = {'Vaccine':'B','PSLN-212':'G','PSLN-344':'L','PSLN-212(Y)':'Q'}
TC['S11-A'] = timecourse('S11',2,3,7,'A',g4,5); META['S11-A']=dict(stated_n=5, loc='S11!A2:U7')
TC['S11-B'] = timecourse('S11',9,10,14,'A',g4,5); META['S11-B']=dict(stated_n=5, loc='S11!A9:U14')
add('S11-C', groups_in_columns('S11',16,17,21,'A','B'), stated_n=5, loc='S11!A16:B21')
TC['S11-D'] = timecourse('S11',23,24,28,'A',g4,5); META['S11-D']=dict(stated_n=5, loc='S11!A23:U28')
add('S11-E', groups_in_columns('S11',30,31,35,'A','D'), stated_n=5, loc='S11!A30:D35')
# ---------------- S12
add('S12-A', groups_in_columns('S12',2,3,5,'A','B'), stated_n=3, loc='S12!A2:B5')
# ---------------- S13
add('S13-A', groups_in_columns('S13',2,3,7,'A','C'), stated_n=5, loc='S13!A2:C7')
add('S13-B', groups_in_columns('S13',2,3,7,'E','G'), stated_n=5, loc='S13!E2:G7')
add('S13-C', groups_in_columns('S13',2,3,7,'I','K'), stated_n=5, loc='S13!I2:K7')
add('S13-D', groups_in_columns('S13',2,3,7,'M','O'), stated_n=5, loc='S13!M2:O7')
SV['S13-E'] = survival('S13','R',3,30,['S','T','U','V'],2); META['S13-E']=dict(stated_n=5, loc='S13!R2:V30')
TC['S13-F'] = timecourse('S13',32,33,40,'A',{'PSLN-212(Y)':'B','Sham':'I','PSLN-212':'P','PSLN-344':'W','Naive':'AD'},7); META['S13-F']=dict(stated_n=7, loc='S13!A32:AJ40')
TC['S13-G'] = timecourse('S13',42,43,50,'A',{'PSLN-344':'B','Sham':'L','Naive':'V'},10); META['S13-G']=dict(stated_n=10, loc='S13!A42:AE50')
add('S13-H', groups_in_columns('S13',52,53,57,'A','D'), stated_n=5, loc='S13!A52:D57')
add('S13-I', groups_in_columns('S13',52,53,57,'F','J'), stated_n=5, loc='S13!F52:J57')
add('S13-J', groups_in_columns('S13',52,53,57,'L','P'), stated_n=5, loc='S13!L52:P57')
# ---------------- S14
add('S14-A_H1N1', groups_in_columns('S14',2,3,7,'A','D'), stated_n=5, loc='S14!A2:D7')
add('S14-A_H3N2', groups_in_columns('S14',2,3,7,'F','I'), stated_n=5, loc='S14!F2:I7')
# ---------------- S15
g4w = {'PSLN-212(Y)':'B','Sham':'I','PSLN-212':'P','PSLN-344':'W'}
g5w = dict(g4w); g5w['Untreated']='AD'
for nm,h,g in [('S15-A',2,g4w),('S15-B',12,g4w),('S15-C',22,g4w),('S15-D',32,g4w),('S15-E',42,g5w),('S15-F',52,g5w),('S15-G',62,g5w)]:
    TC[nm] = timecourse('S15',h,h+1,h+8,'A',g,7); META[nm]=dict(stated_n=7, loc=f'S15!A{h}:AJ{h+8}')
SV['S15-H'] = survival('S15','A',73,93,['B','C','D'],72); META['S15-H']=dict(stated_n=7, loc='S15!A72:D93')
TC['S15-I'] = timecourse('S15',71,72,79,'H',{'3d Vaccine':'I','3d PSLN-344':'P','3d Vaccine+PSLN-344':'W'},7); META['S15-I']=dict(stated_n=7, loc='S15!H71:AC79')
gi = {'Naive+PSLN-212':'I','Imprinting+PSLN-212':'P','Naive+PSLN-344':'W','Imprinting+PSLN-344':'AD'}
TC['S15-J'] = timecourse('S15',82,83,90,'H',gi,7); META['S15-J']=dict(stated_n=7, loc='S15!H82:AJ90')
TC['S15-K'] = timecourse('S15',92,93,100,'H',gi,7); META['S15-K']=dict(stated_n=7, loc='S15!H92:AJ100')
SV['S15-L'] = survival('S15','A',103,130,['B','C','D','E'],102); META['S15-L']=dict(stated_n=7, loc='S15!A102:E130')
gm = {'PSLN-212(Y)':'I','Sham':'P','PSLN-212':'W','PSLN-344':'AD'}
TC['S15-M'] = timecourse('S15',102,103,110,'H',gm,7); META['S15-M']=dict(stated_n=7, loc='S15!H102:AJ110')
SV['S15-N'] = survival('S15','A',134,161,['B','C','D','E'],133); META['S15-N']=dict(stated_n=7, loc='S15!A133:E161')
TC['S15-O'] = timecourse('S15',133,134,141,'H',gm,7); META['S15-O']=dict(stated_n=7, loc='S15!H133:AJ141')

# normalise naive spelling
for k,df in SV.items():
    df['group']=df['group'].str.replace('ï','i')
if __name__=='__main__':
    print(len(B), len(TC), len(SV))
    for k,v in B.items():
        print(k, {g:len(x) for g,x in v.items()})
    for k,v in TC.items():
        print(k, {g:(df.notna().sum(axis=1).tolist()) for g,df in v.items()})
    for k,df in SV.items():
        print(k, df.groupby('group',sort=False).apply(lambda d: f"n={len(d)} events={int((d.event==1).sum())} times={sorted([t for t in d.time.tolist() if t is not None])} missing_t={d.time.isna().sum()}").to_dict())

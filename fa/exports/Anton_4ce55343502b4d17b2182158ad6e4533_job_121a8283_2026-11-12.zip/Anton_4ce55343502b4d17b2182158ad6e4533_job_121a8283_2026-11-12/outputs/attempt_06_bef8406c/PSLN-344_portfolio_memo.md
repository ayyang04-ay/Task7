# PSLN-344: recommendation for the portfolio review

**Asset:** PSLN-344, manganese-complexed pulmonary-surfactant-biomimetic liposome carrying the cyclic-dinucleotide (CDN) STING agonist CDN-1807; intranasal adjuvant for influenza A vaccines in older adults.

**Evidence base:** `adjuvant_program_dataset.xlsx` (15 sheets; 107 data blocks and panels plus one unlabelled region; 6,107 per-animal records) read against `adjuvant_program_annotation.pdf`. Nothing else was used as evidence. Where a sentence draws on knowledge from outside the dataset it is marked *(outside our data)*.

**How to check a number:** every figure below names its block (for example S06-A). Section A1 gives the reduction rules; `PSLN-344_evidence_workbook.xlsx` lists each number with its cell range and calculation, and `analysis/` holds the code that produced it.

---

## 1. Recommendation

**Advance PSLN-344, conditionally.** Move it into a gated confirm-and-derisk stage of about 9 to 12 months. Do not release IND-enabling spend (GLP toxicology, GMP manufacture) until the first gate is passed. The approval asked for now covers studies WP0 to WP4, the WP6 pilot and WP7 in section 6.

**Why advance**

- **It protects most aged animals, and no other preparation in the dataset does.** Across the eight standard lethal-challenge experiments in BALB/c mice aged 20 months or more, one intranasal dose of vaccine plus PSLN-344 left 46 of 56 animals alive (82%; exact 95% CI 70 to 91%). The manganese-free parent PSLN-212 left 6 of 56 (11%), vaccine with empty liposome 0 of 56, and young animals given PSLN-212 56 of 56 (S03-I, S06-A to S06-G; survivors are rows with event flag 0, summed over blocks; stratified log-rank p = 4 × 10⁻¹⁶ against PSLN-212; hazard ratio for death 0.085, 95% CI 0.042 to 0.172).
- **The result survives every data problem I found.** Resolving each discrepancy against PSLN-344 and in favour of PSLN-212 gives 44 of 56 (79%) against 10 of 56 (18%).
- **Protection is broad and fast.** It covers mismatched subtypes (39 of 49 against 6 of 49; S06-A to S06-G) and is present 2 to 3 days after vaccination (28 of 31; S03-J, S06-B, S06-D, S15-H), including wild-type H5N1 (10 of 10 against 3 of 10 and 1 of 10; S03-J).
- **The gain traces to the manganese, and simpler changes do not reproduce it.** At the same dose and the same encapsulation efficiency, PSLN-344 doubles the lung interferon-β response in aged animals, to the young level (37.1 against 16.6; young 37.6; S01-A, means of five animals, fold over untreated). Raising the PSLN-212 dose, switching to cGAMP, or adding a TLR7/8 agonist does not get there (S08-A, S01-A, S09-A, S08-D).

**Why only conditionally**

The dataset does not show four things. Each could stop the programme, and each is cheap to test compared with IND-enabling work:

1. **No outside benchmark.** Every comparator is one of our own preparations. Nothing compares PSLN-344 with the kind of enhanced vaccine older adults already receive.
2. **One dose, one species, one sex, one delivery method.** Every challenge study used 20 µg, and the BALB/c work is in females only. That dose gives 91% of the interferon response seen at 40 µg (S08-A), so nothing is known about the margin below it. In mice the intranasal dose reaches alveolar macrophages and type II epithelial cells (S01-B, S01-C); a human nasal spray does not do that by default *(outside our data)*.
3. **Durability in aged animals is partial.** Survival fell from 20 of 21 at day 14 to 14 of 21 at day 60 (S03-I, S06-A, S06-C against S06-E, S06-F, S06-G; p = 0.045). The paired weight records give 16 of 21 at day 60 (p = 0.18), so the size of the fall is uncertain. There is nothing later than day 60 in aged animals.
4. **The safety evidence is thin.** It consists of body weight to day 10 in five animals, three central-nervous-system (CNS) transcripts at one time point, and lung cytokine mRNA. Nothing measures where the manganese goes, and there is no histology.

The data record also needs reconciling: I list 20 discrepancies in section 9. None changes the conclusion, but the committee should expect the question.

---

## 2. The case for advancing

### 2.1 Survival in aged animals

![Figure 1](figures/fig1_survival_matrix.png)

*Figure 1. Survivors over animals at the end of observation in every challenge experiment run in animals aged 20 months or more. Counts are rows with event flag 0 over all rows of the group.*

| Challenge timing after one dose | Blocks | Aged + sham | Aged + PSLN-212 | Aged + PSLN-344 | Young + PSLN-212 |
|---|---|---|---|---|---|
| Day 3 | S06-B, S06-D | 0/14 | 2/14 | **12/14 (86%)** | 14/14 |
| Day 14 | S03-I, S06-A, S06-C | 0/21 | 3/21 | **20/21 (95%)** | 21/21 |
| Day 60 | S06-E, S06-F, S06-G | 0/21 | 1/21 | **14/21 (67%)** | 21/21 |
| All eight | | 0/56 | 6/56 (11%) | **46/56 (82%)** | 56/56 |

The absolute gain over the parent adjuvant is 71 percentage points (95% CI 55 to 81). Animals that died on PSLN-344 died later than sham animals (median day 8 against day 5). The S06-C table is identical to S06-D; without it the day-14 row reads 13/14 for PSLN-344 and 1/14 for PSLN-212.

![Figure 2](figures/fig2_km_by_challenge_timing.png)

*Figure 2. Kaplan–Meier curves, animals pooled over the blocks named in each panel. The dashed line is the unvaccinated, unchallenged aged group carried alongside the day-60 studies.*

### 2.2 Breadth, speed, other strains, prior immunity

- **Mismatched subtype.** H3N2-only vaccine against H1N1 challenge, and H1N1-only vaccine against H3N2: 20 of 28 on PSLN-344 against 1 of 28 on PSLN-212 (S06-A, S06-B, S06-E, S06-G).
- **Early.** Day 3: 12 of 14 (S06-B, S06-D; the paired weight block S15-D implies 10 of 14) and, in a separate experiment, 6 of 7 (S15-H). Day 2 against wild-type H5N1 after matched vaccine: 10 of 10 (S03-J).
- **Other mouse strains.** Aged C57BL/6: 6 of 7 against 0 of 7 on PSLN-212. Aged outbred Swiss Webster: 6 of 7 against 2 of 7 (S15-L, S15-N). The challenge virus and day are not recorded for these two blocks.
- **Prior influenza infection.** In 14-month-old mice with or without a PR8 infection four months earlier, PSLN-344 protected 6 of 7 in all four arms (24 of 28). PSLN-212 protected 4 of 28, and only where the challenge matched the earlier infection (S06-E and S06-F, rows 71 to 105). PSLN-212 is therefore already failing at 14 months.
- **Young animals.** No difference: PSLN-344 31 of 31, PSLN-212 24 of 24, including challenge at day 180 (S09-B, S09-D, S09-F, S13-E). The benefit of manganese is specific to the aged host.

### 2.3 The gain is attributable to manganese

PSLN-344 and PSLN-212 differ only in Mn²⁺ (annotation).

![Figure 3](figures/fig3_ifnb1.png)

*Figure 3. Lung Ifnb1 mRNA 16 hours after adjuvant alone. A: 20 µg, all preparations (S01-A). B: dose–response with a three-parameter Emax fit (S08-A).*

| Alternative | What the data show | Block |
|---|---|---|
| More CDN in the particle | Encapsulation efficiency 54.8 ± 5.1% (PSLN-344) against 59.6 ± 4.6% (PSLN-212); p = 0.29, n = 3 | S08-B |
| More PSLN-212 | PSLN-212 plateaus: 12.6 at 20 µg, 14.9 at 40 µg. PSLN-344 reaches 21.1 at 10 µg and 45.8 at 20 µg. Fitted ceiling 53-fold against 16-fold at similar half-maximal dose (11 against 9.5 µg) | S08-A |
| cGAMP instead of CDN-1807 | CMP-204 gives 7.8 ± 1.7 in aged lung and 3 of 7 survivors | S01-A, S03-I |
| TLR7/8 agonist instead of Mn | PSLN-212/R848 gives 24.3 ± 3.7 at 16 h and 1.7 at 72 h, with Tnf 202-fold and Il10 179-fold, and weight still falling at day 10 (90.6%; four of five animals left) | S01-A, S09-A, S08-D |

The interferon contrast between PSLN-344 and PSLN-212 in aged lung repeats in all three blocks that measure it at 20 µg: 37.1 against 16.6 (S01-A, n = 5), 45.8 against 12.6 (S08-A, n = 3) and 36.3 against 16.5 (S09-A left panel, geometric means, n = 3).

### 2.4 Immune responses in aged animals return most of the way to young levels

![Figure 4](figures/fig4_restoration_cascade.png)

*Figure 4. Share of the gap between aged and young animals on PSLN-212 that PSLN-344 closes in aged animals, for each read-out along the response. Titres are compared on the log scale.*

The early steps come back almost completely: interferon-β 98%, lung monocytes 89%, migratory dendritic cells 84%. Later steps come back by roughly half to nine-tenths: cross-reactive CD8 T cells 60 to 63%, germinal-centre B cells 56%, haemagglutination-inhibition (HAI) titres 88 to 94%. One step does not recover: CD40 and CD86 on lymph-node dendritic cells close only 17% and 22% of the gap (S02-D).

### 2.5 Tolerability at the efficacious dose, as far as it was measured

![Figure 5](figures/fig5_tolerability.png)

*Figure 5. A: body weight after immunisation (S08-D). B: lung cytokine mRNA as geometric-mean fold over PBS; the block stores log10 values (S09-A). C: CNS transcripts at 36 hours (S10-A).*

- **Weight.** The lowest point after PSLN-344 was 96.4 ± 1.5% of starting weight against 98.2 ± 1.1% for vaccine alone (p = 0.065), and animals were back to 99.8% by day 10 (S08-D, n = 5).
- **CNS.** At 36 hours Ifnb1 was 1.32 against 1.00 for PBS (p = 0.17) and Isg15 1.13 (p = 0.49). Tnf was 1.59 against 1.00 (p = 0.05 unadjusted) and 1.32 for vaccine alone (p = 0.36). Cholera toxin, the positive control, gave 5.5, 3.5 and 2.7 (S10-A, n = 5).
- **Lung cytokines.** At 16 hours PSLN-344 in aged lung gave Tnf 40-fold and Il10 7-fold. The R848 combination gave 202-fold and 179-fold (S09-A, left panel, n = 3).

Two observations need follow-up. In the second S09-A panel, which is labelled 16 h but whose Ifnb1 row matches the 72 h data, aged animals on PSLN-344 still show Tnf at 8-fold and Il6 at 7-fold, where young animals on PSLN-212 are at 0.5-fold and 3-fold. Lung monocytes are still at 18.4% on day 8 against 9.2% at baseline, and against 14.1% in young animals (p = 0.006; S01-D). The aged lung is slower to settle, and nothing is measured after day 8.

### 2.6 Robustness to the data problems

| Handling | Aged + PSLN-344 alive | Aged + PSLN-212 alive |
|---|---|---|
| As recorded, eight blocks | 46/56 (82%) | 6/56 (11%) |
| S06-C dropped (its table is identical to S06-D) | 39/49 (80%) | 4/49 (8%) |
| All three rgH5N1 blocks dropped (S06-C, S06-D, S06-F) | 27/35 (77%) | 1/35 (3%) |
| Deaths taken from the paired body-weight blocks instead | 46/56 (82%) | 9/56 (16%) |
| Worst case per block for PSLN-344, best case for PSLN-212 | 44/56 (79%) | 10/56 (18%) |
| Any single block left out | 80 to 86% | |

In the worst-case row the difference is still 61 points (95% CI 43 to 72; p = 10⁻¹⁰).

---

## 3. What weakens the case

- **Protection is from death, not from illness.** PSLN-344 survivors still lost weight to 88.1 ± 3.7% of baseline (young benchmark 90.5 ± 3.3%) and were at 96.6% on day 14 (S13-F, S15-A to S15-G). No block measures virus in the lung.
- **Protection wanes in aged animals.** Day-60 survival is 14 of 21 on the survival tables and 16 of 21 on the weight records, against 20 of 21 at day 14. In the day-60 weight blocks, the five PSLN-344 animals whose values are carried forward (the convention for a death) stood at 77.5 to 85.3% of starting weight. The four unchallenged, untreated animals that died in the same window stood at 94.5 to 96.6% (S15-E, S15-F, S15-G; Figure 6). The day-60 losses are therefore challenge deaths, not old age. Follicular regulatory T cells, suppressed at day 7 (10.8% against 26.7%), are back at the sham level by day 30 (14.0% against 13.9%; S04-B, S04-C).
- **Against the young benchmark it is not equivalent overall.** 10 deaths in 56 against 0 in 56 (p = 0.0009); seven of the ten fell in the day-60 studies.
- **The causal chain is assembled across cohorts.** No experiment removes a step and counts survivors. Several of the interventions were run in young animals or with PSLN-212 (S02-G, S02-I, S12-A).
- **Group sizes are small.** Seven per group for survival and five for most read-outs. I found no record of randomisation or blinding.
- **No comparator from outside the programme**, no second species, no male BALB/c animals, no dose below 20 µg in a challenge study, no virological or histological endpoint, no mucosal antibody measurement.
- **Only whole inactivated virus was used as antigen.** Vaccines given to older adults are mostly split, subunit or recombinant products, and protection across subtypes is likely to depend on viral proteins other than haemagglutinin *(outside our data)*. Whether PSLN-344 does the same with a licensed-type antigen is untested.

![Figure 6](figures/fig6_day60_weights.png)

*Figure 6. Body weight after challenge at day 60, one line per animal (S15-E, S15-F, S15-G). Heavy lines with crosses are animals whose last value is carried forward.*

---

## 4. What is actually driving the protection

**Short answer.** Manganese restores the aged lung's interferon-β response to the STING agonist. That turns recruited monocytes into antigen-carrying dendritic cells instead of inflammatory macrophages, which restarts a CD8 T-cell response in the lung and T-cell help for B cells in the lymph node. For the protection that makes this asset distinctive (mismatched subtype, day 2 to 3), the cross-reactive CD8 T-cell response is the best-supported effector, and strain-specific antibody cannot be the explanation. This is an inference across cohorts, not a demonstrated cause.

| Link | What the data show | Kind of evidence |
|---|---|---|
| The particle is taken up in the alveolus | Type II epithelial cells labelled: 15.8% with the particle against 0.4% with free dye. Alveolar-macrophage uptake 43.1% against 12.7% in mice lacking surfactant proteins A and D. Blocking gap junctions with carbenoxolone cuts monocyte recruitment by 58% (S01-B, S01-C, S11-C) | Direct tests, but S01-B and S01-C used Mn-free or dye-labelled particles (S01-C in young knockout mice). Whether Mn changes delivery is unresolved (S08-C, section 9) |
| Mn → interferon-β | Ifnb1 at 16 h: 37.1 ± 4.8 (PSLN-344) against 16.6 ± 2.1 (PSLN-212), p = 0.0002; young 37.6 ± 3.5. Same encapsulation; higher ceiling, not higher potency (S01-A, S08-A, S08-B) | Direct comparison, one variable changed |
| Interferon → GM-CSF → monocyte becomes dendritic cell | Gm-csf mRNA 6.0, 8.7 and 3.9-fold at 16, 36 and 72 h against 1.5, 1.6 and 1.4 (S02-F). Bone marrow lacking the interferon receptor makes 89% fewer monocyte-derived dendritic cells (2.1% against 19.7%); GM-CSF restores them to 12.4% (S02-H). The same marrow still enters the lung (15.4% against 21.3%, p = 0.12; S12-A). On PSLN-212 aged lungs accumulate Ly6C⁺CCR2⁺ macrophages instead (19.0 against 3.4 × 10⁵ at day 5; S07-A) | Intervention, but S12-A is in young animals and the recipient age in S02-H is not stated |
| Dendritic cells carry antigen and prime | CCR7⁺ migratory cells 30.7% against 7.3%; antigen-positive cells in the node 7.1% against 1.8%; cross-priming of OT-I cells 18.7% against 0.8% (S02-A, S02-C, S02-E). Costimulatory markers stay low (section 2.4) | Group comparison |
| CD8 T cells respond in the lung | Ki-67⁺ CD8 cells on day 3: 9.4% against 3.5%. CD8 cells making IFN-γ on restimulation with H5N1, which was not in the vaccine: 6.4% against 1.5% at day 14 and 9.9% against 3.0% at day 60 (S05-D, S05-F, S05-G). A CCR2 antagonist removes 79% of granzyme-B⁺ CD8 cells (S02-I, young animals). Pertussis toxin blocks priming in the node (30.9% to 6.8%) but not proliferation in the lung (59.0% against 55.1%; S05-C) | Group comparison plus intervention in young or transfer models |
| B-cell arm | Follicular helper cells 10.3% against 3.8%; germinal-centre B cells 6.5% against 2.3%; IgG 7,305 against 393; HAI 368 against 46 (S04-A, S03-K, S03-A, S03-C) | Group comparison |
| Both antigen and adjuvant are required | Challenge 3 days after dosing: vaccine alone 0/7, PSLN-344 alone 0/7, both 6/7 (p = 0.005 each; S15-H) | Direct test |

**Why not antibody.** Protection is present at day 2 to 3, before germinal centres (day 7) and serum titres (day 14) were measured. Vaccines containing only H3N2 protect against H1N1 and the reverse. Survivors still lose 12% of body weight, so infection is not blocked. The dataset does not exclude a contribution of antibody to matched-strain protection at day 14 (S03-I), or of non-neutralising cross-reactive antibody, because no titre against a mismatched challenge virus was measured.

**Why not an adjuvant-only antiviral state.** PSLN-344 without vaccine protected none of seven animals (S15-H). One caveat: whole inactivated virus carries its own innate stimuli, so the requirement for vaccine does not by itself prove an antigen-specific response. An irrelevant-antigen control would settle it (study WP2).

---

## 5. Is there a biomarker worth carrying forward?

**Finding.** All 28 read-outs that were measured in the four core groups separate the protected regimens (aged PSLN-344, young PSLN-212) from the unprotected ones (aged sham, aged PSLN-212), and 26 of the 28 do so without a single overlapping animal. No animal has both a biomarker and an outcome. The dataset therefore cannot rank biomarkers statistically and cannot qualify any of them as a marker of efficacy. The choice has to rest on position in the mechanism and on whether the sample can be taken from a person.

**Recommendation: carry three markers, each in a defined role. None is ready to stand in for efficacy.**

| Marker | What our data support | Can it go into patients? | Role |
|---|---|---|---|
| **Early interferon signal** (lung Ifnb1 at 16 h) | The only marker that is specific to manganese, graded with dose, and returns to the young level: 37.1 against 37.6, gap closed 98%; half-maximal dose 11 µg; gone by 72 h (4.4) (S01-A, S08-A) | Not as measured: it is lung tissue. It needs a blood or nasal substitute (interferon-gene score, CXCL10), which is not in the dataset | **Pharmacodynamic / target engagement.** Dose and schedule selection in first-in-human work, and an upper bound for reactogenicity |
| **Serum HAI and neutralising titre** (day 14) | HAI 368 against 46 (H1N1) and 320 against 35 (H3N2). Every animal in both protected regimens is at 160 or above; none of 15 animals in the three weaker regimens is (S03-C, S03-G) | Yes, as is | **Response (immunogenicity) marker** and the accepted regulatory read-out for the matched-strain claim *(outside our data)*. It says nothing about breadth or speed |
| **Cross-reactive CD8 T cells** (IFN-γ, granzyme B) | The only read-out taken against a virus absent from the vaccine; 6.4% against 1.5%, persisting to day 60 (S05-F, S05-G, S05-H) | In principle, as a blood ELISpot or intracellular stain. Untested: every value we have is from lymph node or lung | **Exploratory mechanistic marker** for the breadth claim |

**Do not import the 1:40 convention.** All five aged PSLN-212 animals reached 40 to 80 against H1N1, yet that regimen failed a matched challenge (0 of 7 in S03-I; 3 of 7 on the paired weight record S13-F).

![Figure 7](figures/fig7_hai_vs_survival.png)

*Figure 7. HAI titre per animal at day 14 (S03-C, S03-G); bars are geometric means. Survival in panel A is from the matched challenge S03-I in separate animals.*

**Not worth carrying:** the IgG2a/IgG1 ratio (mouse-specific, and the printed block is mislabelled), the Tfh:Tfr ratio (lymph-node tissue, and arithmetically derived from one measurement), CD40/CD86 (not restored, yet animals are protected), alveolar-macrophage and neutrophil kinetics (the two blocks share data), and the tetramer read-out (two animals per point).

**What qualification needs.** A study in which the marker is sampled without killing the animal, the same animal is then challenged, and dose is varied so that outcomes are graded (study WP3).

---

## 6. Forward plan

**Gate 1 (about month 4 to 5):** WP0, the day-14 and day-60 read-outs of WP1, WP2, WP3, WP4 and the WP6 pilot. Continue only if the effect reproduces under blinding, shows a dose–response, needs both Mn and CDN, at least matches an outside benchmark, shows activity in cells from older human donors, and shows no manganese in brain or unresolved lung inflammation.

**Gate 2 (about month 9 to 12):** WP1 day-180 read-out and WP5. Commit IND-enabling spend only if protection lasts and a clinically usable delivery method works in a second species.

| Study | What it must establish | Population | Comparators | Endpoints and read-outs | Timing |
|---|---|---|---|---|---|
| **WP0 Data reconciliation** | Which record is right for the 20 register items | None | None | Locked dataset traceable to cage records | Weeks 0–4 |
| **WP1 Blinded confirmation, dose, components, benchmark, durability** | That 82% against 11% reproduces; that efficacy depends on dose; that both Mn and CDN are needed; that PSLN-344 matches or beats enhanced vaccines of the kind used in older adults; that protection lasts past day 60 | BALB/c, both sexes, 20–22 months; 16–18 months at dosing for the day-180 arm; young reference; unchallenged age-matched sentinels. n = 15 per arm (12 gives 95% power for 82% against 11%) | Vaccine + empty liposome; PSLN-212 20 µg; PSLN-344 2.5, 5, 10, 20 µg; Mn-liposome without CDN; PSLN-212 + free Mn²⁺; squalene emulsion + antigen i.m.; 4× antigen i.m.; PSLN-344 prime and day-14 boost | Primary: 14-day survival after 5× mLD50 mismatched challenge. Secondary: lung virus titre day 3 and 6, weight-loss area, lung histopathology, pre-challenge HAI | Challenge day 14, 60, 180. First read-out month 3–4; durability month 8–9 |
| **WP2 Cause of protection** | Which effector is necessary and which sufficient in aged hosts | Aged BALB/c, n = 10 per arm | PSLN-344 + vaccine with: isotype; anti-CD8; anti-CD4; antibody to the interferon receptor; CCR2 antagonist; anti-GM-CSF; irrelevant antigen; transfer of immune serum or T cells to naive aged mice | Primary: survival after challenge at day 3 and day 14. Secondary: lung virus titre; flow confirmation of depletion | Months 1–5 |
| **WP3 Biomarker qualification** (nested in WP1) | A blood or nasal read-out that predicts the individual animal's outcome and carries the treatment effect | About 90 aged mice across the WP1 dose arms; terminal satellites n = 5 | Dose arms and PSLN-212; lung tissue values from satellites as reference | Serum IFN-β and CXCL10 at 6 and 24 h; blood interferon-gene score at 24 h; blood monocytes day 1–4; HAI day 14; blood IFN-γ ELISpot day 10–14; nasal IgA. Analysis: ROC area, share of treatment effect carried | With WP1; read-out month 3–4 |
| **WP4 Human-cell bridge** | That CDN-1807 with Mn activates human STING, including common variants, and restores the response in cells from older donors | Monocytes, macrophages, dendritic cells from donors 18–40 and ≥ 65 (n ≥ 10 each); airway epithelium; reporter lines | PSLN-212; CMP-204; Mn-liposome without CDN; empty liposome | IFN-β, CXCL10, GM-CSF; TNF, IL-6, IL-1β, viability; dose range at 6 and 24 h | Months 1–3 |
| **WP5 Ferret, deliverable route** | Protection when dosed by spray or aerosol device, with licensed-type antigen, on virological endpoints | Naive ferrets, both sexes, adult and aged if obtainable; n = 6–8 per arm | Unadjuvanted antigen same route; PSLN-212; PSLN-344 two doses by spray and by aerosol; squalene-emulsion antigen i.m. | Primary: nasal-wash virus area day 1–7 after matched and mismatched challenge at day 3 and day 28. Secondary: fever, weight, lung pathology, HAI, nasal IgA, blood ELISpot, the WP3 marker | Months 4–11 |
| **WP6 Safety and Mn disposition** (pilot now, GLP after Gate 1) | Where Mn and CDN go, whether Mn reaches brain, whether the aged lung returns to baseline, tolerance of repeat dosing | Pilot: aged and young mice, both sexes, n = 5–6 per arm per time. GLP: rodent plus one non-rodent | Vehicle; empty liposome; PSLN-212; PSLN-344 at 1×, 3×, 10×, single and three doses; intranasal MnCl₂; cholera toxin | Mn by ICP-MS in olfactory bulb, brain regions, lung, liver, blood; CDN in plasma and lung; lavage cells and cytokines; lung, olfactory and nerve histology; neurobehaviour | 6 h to day 90. Pilot months 1–4; GLP months 6–14 |
| **WP7 Product definition** | Mn content per dose, valid encapsulation assay, stability above −20 °C, survival through a delivery device, potency assay | Bench | PSLN-212 reference | Specifications; three conforming lots | Months 1–6 |
| **WP8 First-in-human outline** (after both gates) | Safety, reactogenicity, immunogenicity | Adults 18–49, then ≥ 65; 25–30 per arm | Licensed high-dose or adjuvanted vaccine i.m.; unadjuvanted antigen same route | Primary: solicited reactions 7 d, adverse events 28 d, special-interest events 12 months (facial palsy, loss of smell, wheeze), spirometry. Secondary: HAI titre, seroconversion day 28, persistence day 180. Exploratory: the three markers of section 5, serum Mn | Visits day 0, 1, 3, 7, 28, 90, 180 |

Decision rules for each study are in the workbook (sheet `Next_studies`).

---

## 7. If the committee decides to drop it

**What would be dropped**

- The only regimen in the dataset that makes an influenza vaccine protective in aged animals: 82% against 11% for the parent and 0% for vaccine alone.
- Protection within 2 to 3 days of one dose, including against wild-type H5N1.
- The older-adult indication for the whole platform. PSLN-212 protects young animals almost without exception (56 of 56 and 24 of 24 in BALB/c, including day 180; 13 of 14 in the two other strains) but fails from at least 14 months of age (0 of 7 in both unprimed arms at 14 months; 6 of 56 at 20 months or more). Without PSLN-344 the platform is an adjuvant for younger adults.
- A second use that the data support at least as well as the seasonal one: rapid protection in an outbreak. Protection at day 2 to 3, against wild-type H5N1 and across subtypes does not depend on the six-month durability that a seasonal older-adult vaccine needs and that the dataset does not yet show.

**What would be kept:** PSLN-212 for non-elderly use, and the finding that the aged lung's interferon deficit is the lesion to correct.

**The reasons to drop would be translational, not lack of efficacy:** the need for lower-airway delivery, manganese by the respiratory route in a healthy elderly population, no outside benchmark, partial durability, and a data record that needs reconciling. If the committee drops the asset, WP0 should still be done so the archive is sound.

---

## 8. What I considered and ruled out

| Alternative | What the data say | Verdict |
|---|---|---|
| Protection is an antiviral state from the adjuvant alone | PSLN-344 alone 0/7; with vaccine 6/7 (S15-H) | Ruled out at day 3 |
| Strain-specific antibody explains the protection | Protection at day 2–3 and across subtypes; survivors still lose weight | Ruled out for early and mismatched protection; open for matched challenge at day 14 |
| PSLN-344 carries more CDN | 54.8% against 59.6% encapsulation (S08-B) | Ruled out |
| A higher dose of PSLN-212 would do the same | Plateau at 14.9 against 45.8 (S08-A) | Ruled out for the interferon response |
| cGAMP in place of CDN-1807 | 3/7 aged survivors; 7/7 young (S03-I, S13-E) | Ruled out for aged hosts |
| R848 in place of Mn | Lower and shorter interferon response; Tnf 202-fold; progressive weight loss (S01-A, S09-A, S08-D) | Ruled out on tolerability |
| Recombinant GM-CSF added to PSLN-212 | 13.8% against 5.9% monocyte-derived cells, after four daily cytokine doses; no challenge (S02-G) | A mechanism probe, not a product |
| Boosting PSLN-212 | After a day-14 boost IgG reaches 4,411 (H1N1) and 1,086 (H3N2) against 15,651 and 12,435 for PSLN-344; no challenge (S13-I, S13-J) | Not supported |
| Day-60 deaths on PSLN-344 are old age | Those animals were at 77.5–85.3% of weight; unchallenged deaths at 94.5–96.6% | Ruled out: waning is real |
| The effect is peculiar to BALB/c | C57BL/6 6/7 against 0/7; Swiss Webster 6/7 against 2/7 | Ruled out, with the caveat that the challenge is undocumented |
| Prior infection blunts or replaces the benefit | PSLN-344 6/7 in all four arms at 14 months | Ruled out in this model |
| The aged defect is failure to recruit monocytes | Receptor-deficient monocytes still enter (p = 0.12) but do not become dendritic cells (−89%) | Not supported: the defect is in differentiation |
| Manganese changes where the particle goes | S08-C as printed says type II cell uptake falls from 15.8% to 3.8%; its headers conflict with S01-B | Unresolved |
| Nose-to-brain inflammation from Mn | No significant change in three transcripts at 36 h (S10-A) | Not ruled out: one time point, no Mn measurement |
| The effect is produced by data errors | Worst case 44/56 against 10/56 | Ruled out |
| PSLN-344 adds value in young hosts | 31/31 against 24/24; interferon-β only 1.35-fold higher | No evidence |

**Readings of the data I rejected**

- Reading S09-A as linear fold change. The block is log10: a stored value of 1.56 is 36-fold, not 1.6-fold.
- Treating the "Untreated" groups as infected controls. They received no virus; they measure background mortality only.
- Counting S06-C and S06-D as two independent experiments.
- Using the IgG2a/IgG1 ratios as printed in S03-B and S03-F.
- Treating HAI values printed as 0 as a titre of zero rather than below 1:10.
- Treating the prior-infection study as an aged-animal study. Those animals were 14 months old at vaccination.
- Assuming the C57BL/6 and Swiss Webster blocks used a particular challenge virus. None is recorded.
- Reading the requirement for vaccine at day 3 (S15-H) as proof of an antigen-specific response.

**Blocks excluded from the evidence:** S05-A and S05-B (two animals per point, contradictory description), S07-C (both groups carry the same header), S11-A and S11-B (shared values), the unlabelled region at S08 rows 89 to 101, and the S08-A arm "PSLN-344/R848". S03-B and S03-F were not used as printed; S08-C was not used for any claim.

---

## 9. Data discrepancies to reconcile before the review

The full register with cell ranges is in the workbook (sheet `Integrity_register`). The items most likely to be raised:

| Item | Finding | Effect |
|---|---|---|
| S06-C and S06-D | The two survival tables are identical row for row, although one is a day-14 and the other a day-3 challenge | Pooled survival 82% becomes 80% without S06-C |
| S03-B, S03-F | Column headers are rotated one place relative to the raw titres in S13-A to S13-D. As printed, PSLN-344 has the lowest IgG2a/IgG1 ratio (0.58, 0.51); recomputed it is 2.14 and 2.73 against 0.58 and 0.51 for aged PSLN-212 | A side-claim only; I used the recomputed values |
| Survival against weight records | The two disagree on the number of deaths in 10 of 65 group comparisons. For PSLN-344: S06-D 0 against 2, S06-E 2 against 1, S06-G 3 against 2. The PSLN-344 rows of S06-E and S06-G are also entered out of day order, which is true of only one other group in the workbook | Total PSLN-344 deaths are 10 either way; worst case 12 |
| S03-I and S13-F | Said to be the same animals, but the group lists differ, and aged PSLN-212 is 7 of 7 dead by day 6 in one and 4 of 7 in the other | Affects only the ranking of CMP-204 and PSLN-212 |
| S03-J and S13-G | Stated n is 9, there are 10 rows per group, and one PSLN-344 row has no day. The weight block lists Naive where the survival block lists PSLN-212 | PSLN-344 is 10 of 10 in both; the identity of the comparators is uncertain |
| S09-A | Both panels are labelled 16 h; the second reproduces the 72 h interferon values of S01-A | I treat it as a probable 72 h read-out |
| S11-A and S11-B | 35 of 100 values are identical in the same positions, though one block is alveolar macrophages and the other neutrophils | Both excluded; there is no neutrophil read-out |
| S08-C | As printed, Mn cuts type II cell delivery four-fold; two columns reproduce the values of S01-B under other headers | Not used |
| S15-C and S15-I | 40 of 49 weight values for the PSLN-344 group are identical between two different experiments | Weakens S15-C as independent support |
| Untreated groups | 4 of 21 unchallenged aged animals died within 14 days; no record of losses between dosing and challenge | Future studies need sentinels and attrition records |

---

## 10. Challenges the committee is likely to raise

| Challenge | Answer from the data |
|---|---|
| Seven animals per group is too few | The direction is the same in all eight experiments and in two further mouse strains. Pooled, it is 56 animals per arm, and the worst-case reading is still 44/56 against 10/56 |
| The record contains duplicated and mislabelled blocks | It does: 20 items, listed in section 9. The headline is stable under every one of them. WP0 reconciles the record and WP1 repeats the key result blind |
| Old mice die anyway | Unchallenged aged animals that died did so without weight loss (94.5–96.6%). At day 14, 20 of 21 PSLN-344 animals were alive while 21 of 21 sham animals had died in the same experiments |
| Keep PSLN-212 and raise the dose or boost | The interferon response of PSLN-212 plateaus at a third of PSLN-344 (S08-A). Boosted PSLN-212 still has 3.5 to 11 times less IgG (S13-I, S13-J) and a boost cannot give protection at day 3 |
| HAI titres were restored, so why not rely on them | HAI cannot explain protection at day 2 to 3 or against a different subtype, and 40 to 80 did not protect aged animals here |
| Manganese through the nose | The dataset does not settle this. Three CNS transcripts at 36 hours were flat (S10-A); there is no Mn measurement and no histology. WP6 is a gate for that reason |
| Why not go straight to IND-enabling work | Four unknowns could each end the programme and can be resolved for far less: an outside benchmark, the dose–response, a deliverable route, and Mn disposition |

---

## A1. How the numbers were reduced

- **Survival.** Survivors are rows with event flag 0; the denominator is all rows for the group. Pooled figures are sums over the named blocks with Clopper–Pearson 95% intervals. Single-block tests are two-sided Fisher exact tests and log-rank tests (asymptotic and exact permutation). Pooled tests are log-rank tests stratified by block; the hazard ratio is from a Cox model stratified by block.
- **Linear read-outs** (percentages, fold changes, counts). Arithmetic mean ± SD of the per-animal values, n as found in the sheet. Single contrasts use Welch's t test and are not adjusted for multiplicity; the workbook also gives Tukey-adjusted and Mann–Whitney values.
- **Titres.** Geometric mean of per-animal reciprocal titres. HAI values printed as 0 (below the lowest dilution, 1:10) are set to 5. Tests are on log10 titres.
- **S09-A.** Values are stored as log10 fold. I averaged the logs and back-transformed, which gives a geometric-mean fold.
- **Gap closed.** (aged PSLN-344 − aged PSLN-212) ÷ (young PSLN-212 − aged PSLN-212), on the log scale for titres.
- **Dose–response.** Three-parameter Emax model fitted by least squares to the individual values of S08-A.
- **Deaths inferred from weight blocks.** An animal is counted dead if its series stops before day 14, or its last three or more readings are identical, or its last two are identical and below 90%.
- **Group naming.** Groups marked (Y) are young (7 to 8 weeks). All others are aged (20 months or more) unless the annotation says otherwise. "Sham" is vaccine plus empty liposome.
- **Block naming.** The labels S06-E and S06-F are each used twice on sheet S06. Unless a row range is given, S06-E and S06-F mean the day-60 studies at rows 34 to 68; the prior-infection study at rows 71 to 105 is always cited with its rows.

## A2. Files

| File | Content |
|---|---|
| `PSLN-344_portfolio_memo.md` / `.pdf` | This memo |
| `PSLN-344_evidence_workbook.xlsx` | Headline-number ledger with cell ranges and reductions; survival by block; pooled survival and tests; all read-out summaries and contrasts; gap-closed table; biomarker screen; weight-against-survival cross-check; block inventory; integrity register; next studies with decision rules |
| `figures/` | Figures 1 to 7 |
| `analysis/` | Parser, tidy per-animal tables, analysis scripts and result tables |

"""Render the Markdown memo to PDF with reportlab (headings, paragraphs, lists, pipe tables, images)."""
import re, os, sys, matplotlib
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, Image, PageBreak,
                                NextPageTemplate, KeepTogether, HRFlowable, ListFlowable, ListItem)
from PIL import Image as PILImage
SRC=sys.argv[1] if len(sys.argv)>1 else '/tmp/outputs/PSLN-344_portfolio_memo.md'
DST=SRC[:-3]+'.pdf'; BASE=os.path.dirname(SRC)
fd=os.path.join(matplotlib.get_data_path(),'fonts','ttf')
for n,f in [('DV','DejaVuSans.ttf'),('DV-B','DejaVuSans-Bold.ttf'),('DV-I','DejaVuSans-Oblique.ttf'),('DV-BI','DejaVuSans-BoldOblique.ttf'),('DVM','DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(n,os.path.join(fd,f)))
pdfmetrics.registerFontFamily('DV',normal='DV',bold='DV-B',italic='DV-I',boldItalic='DV-BI')
INK=colors.HexColor('#1a1a1a'); BLUE=colors.HexColor('#1f5fa8')
st={
 'body':ParagraphStyle('body',fontName='DV',fontSize=9.2,leading=13.2,textColor=INK,spaceAfter=5,alignment=TA_LEFT),
 'h1':ParagraphStyle('h1',fontName='DV-B',fontSize=17,leading=21,textColor=BLUE,spaceAfter=8,spaceBefore=0),
 'h2':ParagraphStyle('h2',fontName='DV-B',fontSize=12.5,leading=16,textColor=BLUE,spaceBefore=12,spaceAfter=5,keepWithNext=1),
 'h3':ParagraphStyle('h3',fontName='DV-B',fontSize=10.2,leading=13.5,textColor=INK,spaceBefore=8,spaceAfter=4,keepWithNext=1),
 'bullet':ParagraphStyle('bullet',fontName='DV',fontSize=9.2,leading=13,textColor=INK,leftIndent=0,spaceAfter=2.5),
 'cap':ParagraphStyle('cap',fontName='DV-I',fontSize=7.8,leading=10.5,textColor=colors.HexColor('#444444'),spaceAfter=8),
 'cell':ParagraphStyle('cell',fontName='DV',fontSize=7.4,leading=9.6,textColor=INK),
 'cellh':ParagraphStyle('cellh',fontName='DV-B',fontSize=7.4,leading=9.6,textColor=INK),
 'cells':ParagraphStyle('cells',fontName='DV',fontSize=6.7,leading=8.6,textColor=INK),
 'cellsh':ParagraphStyle('cellsh',fontName='DV-B',fontSize=6.9,leading=8.8,textColor=INK),
}
def inline(t):
    t=t.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    t=re.sub(r'`([^`]+)`',r'<font face="DVM" size="-0.6">\1</font>',t)
    t=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',t)
    t=re.sub(r'(?<![\w*])\*([^*\n]+)\*(?![\w*])',r'<i>\1</i>',t)
    return t
def make_table(rows,width,small=False):
    hdr,body=rows[0],rows[1:]
    ncol=len(hdr); cs,ch=('cells','cellsh') if small else ('cell','cellh')
    # column weights from text length (sqrt-damped), bounded
    lens=[max([len(hdr[j])*1.2]+[len(r[j]) for r in body if j<len(r)]) for j in range(ncol)]
    avg=[ (sum(len(r[j]) for r in body if j<len(r))/max(1,len(body))) for j in range(ncol)]
    w=[max(8.0,(0.3*lens[j]+0.7*avg[j]))**0.55 for j in range(ncol)]
    tot=sum(w); cw=[width*x/tot for x in w]
    # floor so that no column is narrower than its longest header word
    fs=6.9 if small else 7.4
    for j in range(ncol):
        words=re.sub(r'[*`]','',hdr[j]).split()
        for r in body:
            if j<len(r): words+=re.sub(r'[*`]','',r[j]).split()
        need=max(pdfmetrics.stringWidth(wd,'DV-B',fs) for wd in words)+9
        need=min(need,0.30*width)
        if cw[j]<need: cw[j]=need
    # rescale the columns that are above their floor so the table keeps its width
    for _ in range(5):
        extra=sum(cw)-width
        if abs(extra)<0.5: break
        sc=width/sum(cw); cw=[x*sc for x in cw]
    data=[[Paragraph(inline(c),st[ch]) for c in hdr]]+[[Paragraph(inline(c),st[cs]) for c in r+['']*(ncol-len(r))] for r in body]
    t=Table(data,colWidths=cw,repeatRows=1,splitByRow=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dde6f0')),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LINEBELOW',(0,0),(-1,0),0.8,colors.HexColor('#7a8aa0')),('LINEBELOW',(0,1),(-1,-1),0.25,colors.HexColor('#c8c8c8')),
        ('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3),('TOPPADDING',(0,0),(-1,-1),2.2),('BOTTOMPADDING',(0,0),(-1,-1),2.6)]))
    return t
PW,PH=A4; M=1.7*cm
frameP=Frame(M,M,PW-2*M,PH-2*M-0.3*cm,id='p'); frameL=Frame(M,M,PH-2*M,PW-2*M-0.3*cm,id='l')
def footer(canv,doc):
    canv.saveState(); canv.setFont('DV',7); canv.setFillColor(colors.HexColor('#666666'))
    w,h=canv._pagesize
    canv.drawString(M,0.9*cm,'PSLN-344 portfolio recommendation  |  all figures from adjuvant_program_dataset.xlsx'); canv.drawRightString(w-M,0.9*cm,f'page {doc.page}')
    canv.restoreState()
doc=BaseDocTemplate(DST,pagesize=A4,leftMargin=M,rightMargin=M,topMargin=M,bottomMargin=M,title='PSLN-344: recommendation for the portfolio review',author='Preclinical analysis')
doc.addPageTemplates([PageTemplate(id='portrait',frames=[frameP],pagesize=A4,onPage=footer),PageTemplate(id='landscape',frames=[frameL],pagesize=landscape(A4),onPage=footer)])
lines=open(SRC,encoding='utf-8').read().split('\n')
story=[]; i=0; width=PW-2*M; mode='portrait'; para=[]
def flush():
    global para
    if para:
        story.append(Paragraph(inline(' '.join(para)),st['body'])); para=[]
while i<len(lines):
    ln=lines[i]
    if ln.strip().startswith('<!-- pdf:landscape'):
        flush(); story+= [NextPageTemplate('landscape'),PageBreak()]; width=PH-2*M; mode='landscape'; i+=1; continue
    if ln.strip().startswith('<!-- pdf:portrait'):
        flush(); story+= [NextPageTemplate('portrait'),PageBreak()]; width=PW-2*M; mode='portrait'; i+=1; continue
    if ln.strip().startswith('<!-- pdf:pagebreak'):
        flush(); story.append(PageBreak()); i+=1; continue
    if ln.startswith('# '): flush(); story.append(Paragraph(inline(ln[2:]),st['h1'])); i+=1; continue
    if ln.startswith('## '): flush(); story.append(Paragraph(inline(ln[3:]),st['h2'])); i+=1; continue
    if ln.startswith('### '): flush(); story.append(Paragraph(inline(ln[4:]),st['h3'])); i+=1; continue
    if ln.strip()=='---': flush(); story.append(HRFlowable(width='100%',thickness=0.6,color=colors.HexColor('#b0b8c4'),spaceBefore=4,spaceAfter=4)); i+=1; continue
    m=re.match(r'!\[(.*?)\]\((.*?)\)',ln.strip())
    if m:
        flush(); p=os.path.join(BASE,m.group(2)); iw,ih=PILImage.open(p).size
        w=width; h=w*ih/iw; maxh=11.5*cm
        if h>maxh: h=maxh; w=h*iw/ih
        img=Image(p,width=w,height=h); img.hAlign='CENTER'
        cap=None
        j=i+1
        while j<len(lines) and lines[j].strip()=='' : j+=1
        if j<len(lines) and lines[j].startswith('*Figure'):
            cap=Paragraph(inline(lines[j].strip().strip('*')),st['cap']); i=j
        block=[img,Spacer(1,3)]+([cap] if cap else [])
        # keep a heading (and a one-line lead-in) together with the figure that follows it
        lead=[]
        while story and isinstance(story[-1],Paragraph) and story[-1].style.name in ('h2','h3','body') and len(lead)<2:
            if story[-1].style.name=='body' and (len(story[-1].text)>160 or lead): break
            lead.insert(0,story.pop())
            if lead[0].style.name in ('h2','h3'): break
        if lead and lead[0].style.name=='body' and not (story and isinstance(story[-1],Paragraph) and story[-1].style.name in ('h2','h3')):
            pass
        elif lead and lead[0].style.name=='body':
            lead.insert(0,story.pop())
        story.append(KeepTogether(lead+block)); i+=1; continue
    if ln.startswith('|'):
        flush(); rows=[]
        while i<len(lines) and lines[i].startswith('|'):
            cells=[c.strip() for c in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-{2,}:?',c) for c in cells): rows.append(cells)
            i+=1
        small = (len(rows[0])>=6) or sum(len(c) for r in rows for c in r)>3500
        story.append(make_table(rows,width,small=small)); story.append(Spacer(1,7)); continue
    m=re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)',ln)
    if m:
        flush(); items=[]; numbered=bool(re.match(r'\d+\.',m.group(2)))
        while i<len(lines):
            mm=re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)',lines[i])
            if not mm: break
            txt=mm.group(3); i+=1
            while i<len(lines) and lines[i].startswith('  ') and not re.match(r'^(\s*)([-*]|\d+\.)\s+',lines[i]): txt+=' '+lines[i].strip(); i+=1
            items.append(ListItem(Paragraph(inline(txt),st['bullet']),leftIndent=14))
        story.append(ListFlowable(items,bulletType='1' if numbered else 'bullet',bulletFontName='DV',bulletFontSize=8 if numbered else 6,leftIndent=14,bulletOffsetY=0 if numbered else -1.5,start=None if numbered else '•'))
        story.append(Spacer(1,3)); continue
    if ln.strip()=='' : flush(); i+=1; continue
    para.append(ln.strip()); i+=1
flush()
doc.build(story); print('wrote',DST)

"""
Pooled / stratified survival for the aged-animal challenge programme.
Strata = experiment (block). Reductions:
  * counts: alive at end of observation / n, summed over blocks
  * exact 95% CI: Clopper-Pearson
  * stratified test: stratified log-rank (sum of O-E and variances over blocks) and Cochran-Mantel-Haenszel on dead/alive
  * sensitivity: (i) S06-C and S06-D are cell-for-cell identical -> drop one; (ii) replace survival-block counts by the deaths inferred from the paired body-weight block
"""
import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.contingency_tables import StratifiedTable
sv=pd.read_csv('tidy/survival_blocks.csv')
def counts(blocks, group):
    d=sv[sv.block.isin(blocks)&(sv.group==group)]
    return int(d.event.sum()), len(d)
def cp(k,n):
    lo,hi=proportion_confint(k,n,alpha=0.05,method='beta'); return lo,hi
def strat_logrank(blocks,a,b):
    OE=0;V=0
    for bl in blocks:
        d=sv[(sv.block==bl)&sv.group.isin([a,b])].dropna(subset=['day'])
        t=d.day.values; e=d.event.values; g=(d.group==a).values.astype(int)
        for tt in np.unique(t[e==1]):
            at=t>=tt; n=at.sum(); n1=(at&(g==1)).sum(); dd=((t==tt)&(e==1)).sum(); d1=((t==tt)&(e==1)&(g==1)).sum()
            OE+=d1-dd*n1/n
            if n>1: V+=dd*(n1/n)*(1-n1/n)*(n-dd)/(n-1)
    z=OE/np.sqrt(V); return z, 2*stats.norm.sf(abs(z))
def cmh(blocks,a,b):
    tabs=[]
    for bl in blocks:
        da,na=counts([bl],a); db,nb=counts([bl],b)
        tabs.append(np.array([[da,na-da],[db,nb-db]]))
    st=StratifiedTable(tabs); r=st.test_null_odds(correction=True)
    return r.statistic, r.pvalue
sets={
 'Aged BALB/c, all 8 standard challenge blocks':['S03-I','S06-A','S06-B','S06-C','S06-D','S06-E(r34)','S06-F(r34)','S06-G'],
 'Aged BALB/c, 7 blocks (S06-C dropped as duplicate of S06-D)':['S03-I','S06-A','S06-B','S06-D','S06-E(r34)','S06-F(r34)','S06-G'],
 'Challenge 3 d after vaccination (S06-B,S06-D)':['S06-B','S06-D'],
 'Challenge 14 d after vaccination (S03-I,S06-A,S06-C)':['S03-I','S06-A','S06-C'],
 'Challenge 60 d after vaccination (S06-E,S06-F,S06-G)':['S06-E(r34)','S06-F(r34)','S06-G'],
 'Heterosubtypic only (S06-A,B,C,D,E,F,G)':['S06-A','S06-B','S06-C','S06-D','S06-E(r34)','S06-F(r34)','S06-G'],
 'Other strains, aged (S15-L C57BL/6, S15-N Swiss Webster)':['S15-L','S15-N'],
 'wt H5N1, 2 d after vaccination (S03-J)':['S03-J'],
}
rows=[]
for name,bl in sets.items():
    for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)','Untreated']:
        d,n=counts(bl,g)
        if n==0: continue
        lo,hi=cp(n-d,n)
        rows.append(dict(set=name,group=g,dead=d,n=n,alive=n-d,surv_pct=100*(n-d)/n,ci_lo=100*lo,ci_hi=100*hi))
P=pd.DataFrame(rows); P.to_csv('results_pooled_survival.csv',index=False)
pd.set_option('display.width',250)
print(P.to_string(index=False,float_format=lambda v:f'{v:.1f}'))
print()
tests=[]
for name,bl in sets.items():
    for a,b in [('PSLN-344','PSLN-212'),('PSLN-344','Sham'),('PSLN-344','PSLN-212(Y)'),('PSLN-212','Sham'),('PSLN-212(Y)','PSLN-212')]:
        da,na=counts(bl,a); db,nb=counts(bl,b)
        if na==0 or nb==0: continue
        z,p=strat_logrank(bl,a,b)
        fp=stats.fisher_exact([[da,na-da],[db,nb-db]])[1]
        try:
            cs,cpv=cmh(bl,a,b) if len(bl)>1 else (np.nan,np.nan)
        except Exception as ex:
            cs,cpv=np.nan,np.nan
        tests.append(dict(set=name,A=a,B=b,A_dead=f'{da}/{na}',B_dead=f'{db}/{nb}',pooled_fisher_p=fp,strat_logrank_z=z,strat_logrank_p=p,cmh_p=cpv))
T=pd.DataFrame(tests); T.to_csv('results_pooled_survival_tests.csv',index=False)
print(T.to_string(index=False,float_format=lambda v:f'{v:.3g}'))
print()
# imprinting + 3d component
for bl,gs in [('S06-E(r71)',['Naïve+PSLN-212','Imprinting+PSLN-212','Naïve+PSLN-344','Imprinting+PSLN-344']),('S06-F(r71)',['Naïve+PSLN-212','Imprinting+PSLN-212','Naïve+PSLN-344','Imprinting+PSLN-344']),('S15-H',['3d Vaccine','3d PSLN-344','3d Vaccine+PSLN-344'])]:
    print(bl,{g:'%d/%d dead'%counts([bl],g) for g in gs})
d344=sum(counts([b],g)[0] for b in ['S06-E(r71)','S06-F(r71)'] for g in ['Naïve+PSLN-344','Imprinting+PSLN-344']); d212=sum(counts([b],g)[0] for b in ['S06-E(r71)','S06-F(r71)'] for g in ['Naïve+PSLN-212','Imprinting+PSLN-212'])
print('imprinting study pooled: PSLN-344 arms dead',d344,'/28 ; PSLN-212 arms dead',d212,'/28 ; Fisher p=',stats.fisher_exact([[d344,28-d344],[d212,28-d212]])[1])
# d14 vs d60 within PSLN-344, and d60 vs untreated
print('PSLN-344 d14 (1/21) vs d60 (7/21): Fisher p=',stats.fisher_exact([[1,20],[7,14]])[1])
print('PSLN-344 d3 (2/14) vs d60 (7/21): Fisher p=',stats.fisher_exact([[2,12],[7,14]])[1])
print('PSLN-344 d60 (7/21) vs Untreated d60 (4/21): Fisher p=',stats.fisher_exact([[7,14],[4,17]])[1])
print('PSLN-344 d60 by body-weight inference (5/21) vs d14 (1/21):',stats.fisher_exact([[5,16],[1,20]])[1])
# every PSLN-344-containing arm in aged or middle-aged animals (all blocks), excluding duplicates
allb={'S03-I':'PSLN-344','S03-J':'PSLN-344','S06-A':'PSLN-344','S06-B':'PSLN-344','S06-C':'PSLN-344','S06-D':'PSLN-344','S06-E(r34)':'PSLN-344','S06-F(r34)':'PSLN-344','S06-G':'PSLN-344','S15-H':'3d Vaccine+PSLN-344','S15-L':'PSLN-344','S15-N':'PSLN-344'}
d=n=0
for b,g in allb.items():
    a,c_=counts([b],g); d+=a; n+=c_
print('all >=20-month PSLN-344+vaccine arms:',d,'/',n,'dead ->',n-d,'/',n,'alive =',round(100*(n-d)/n,1),'%  CI',[round(100*x,1) for x in cp(n-d,n)])
d2=n2=0
for b in ['S06-E(r71)','S06-F(r71)']:
    for g in ['Naïve+PSLN-344','Imprinting+PSLN-344']:
        a,c_=counts([b],g); d2+=a; n2+=c_
print('incl. 14-month imprinting arms:',d+d2,'/',n+n2)

"""
Body-weight blocks: morbidity metrics and death inference (refined rule).
Death inference from a weight series:
  BLANK : series stops before the last scheduled weighing                                 -> dead
  FLAT  : last >=3 readings identical (carried forward), or last 2 identical AND final < 90 % -> dead
  (two identical final readings at >= 90 % are treated as coincidence: 3 such series exist, all recovered animals)
Morbidity: nadir = minimum % of day-0 weight reached by each animal using only real (non-carried-forward) readings;
           group value = mean of per-animal nadirs (all animals) ; also mean final weight of survivors.
"""
import pandas as pd, numpy as np
bw=pd.read_csv('tidy/bodyweight_blocks.csv'); sv=pd.read_csv('tidy/survival_blocks.csv')
pairs={'S15-A':'S06-A','S15-B':'S06-B','S15-C':'S06-C','S15-D':'S06-D','S15-E':'S06-E(r34)','S15-F':'S06-F(r34)','S15-G':'S06-G',
       'S15-I':'S15-H','S15-J':'S06-E(r71)','S15-K':'S06-F(r71)','S15-M':'S15-L','S15-O':'S15-N','S09-C':'S09-B','S09-E':'S09-D','S09-G':'S09-F','S13-F':'S03-I','S13-G':'S03-J'}
an=[]; 
for (b,g,a),y in bw.groupby(['block','group','animal'],sort=False):
    y=y.sort_values('time'); v=y.value.values; t=y.time.values; tmax=bw[bw.block==b].time.max()
    status='alive'; lastreal=t[-1]; real=v
    if t[-1]<tmax: status='dead(blank)'
    else:
        k=1
        while k<len(v) and v[-k-1]==v[-1]: k+=1
        if k>=3 or (k==2 and v[-1]<90):
            status='dead(flat)'; lastreal=t[-k]; real=v[:len(v)-k+1]
    an.append(dict(block=b,group=g,animal=a,status=status,last_real_day=lastreal,nadir=real.min(),nadir_day=t[int(np.argmin(real))],final=v[-1],cells=f"{y.cell.iloc[0]}..{y.cell.iloc[-1]}"))
A=pd.DataFrame(an); A.to_csv('results_bw_per_animal.csv',index=False)
rows=[]
for (b,g),x in A.groupby(['block','group'],sort=False):
    n=len(x); dead=(x.status!='alive').sum(); surv=x[x.status=='alive']
    sb=pairs.get(b); sd=sn=np.nan; sdays=''
    if sb:
        z=sv[(sv.block==sb)&(sv.group==g)]
        if len(z): sd=int(z.event.sum()); sn=len(z); sdays=','.join(str(int(q)) for q in sorted(z.day[z.event==1].dropna()))
    rows.append(dict(bw_block=b,group=g,n=n,bw_dead=int(dead),bw_dead_blank=int((x.status=='dead(blank)').sum()),bw_dead_flat=int((x.status=='dead(flat)').sum()),
                     bw_last_real_days=','.join(str(int(q)) for q in sorted(x.last_real_day[x.status!='alive'])),
                     surv_block=sb,surv_n=sn,surv_dead=sd,surv_death_days=sdays,
                     agree=('n/a' if np.isnan(sd) else ('yes' if (sd==dead and sn==n) else 'NO')),
                     mean_nadir_all=x.nadir.mean(),sd_nadir_all=x.nadir.std(ddof=1),mean_nadir_survivors=(surv.nadir.mean() if len(surv) else np.nan),
                     mean_final_survivors=(surv.final.mean() if len(surv) else np.nan),n_survivors_bw=len(surv)))
R=pd.DataFrame(rows); R.to_csv('results_bw_vs_survival.csv',index=False)
pd.set_option('display.width',300); pd.set_option('display.max_rows',500)
print(R[['bw_block','group','n','bw_dead','bw_last_real_days','surv_block','surv_dead','surv_death_days','agree','mean_nadir_all','mean_nadir_survivors','mean_final_survivors']].to_string(index=False,float_format=lambda v:f'{v:.1f}'))
print()
print('DISAGREEMENTS:'); print(R[R.agree=='NO'][['bw_block','group','n','bw_dead','bw_last_real_days','surv_block','surv_n','surv_dead','surv_death_days']].to_string(index=False))
# sensitivity for PSLN-344 aged BALB/c
m=R[(R.group=='PSLN-344')&R.surv_block.isin(['S03-I','S06-A','S06-B','S06-C','S06-D','S06-E(r34)','S06-F(r34)','S06-G'])]
print(); print(m[['bw_block','surv_block','n','surv_dead','bw_dead']].to_string(index=False))
print('PSLN-344 aged BALB/c 8 blocks: survival-block deaths',int(m.surv_dead.sum()),'; bw-inferred deaths',int(m.bw_dead.sum()),'; worst-case (max per block)',int(np.maximum(m.surv_dead,m.bw_dead).sum()),'; best-case',int(np.minimum(m.surv_dead,m.bw_dead).sum()),'of',int(m.n.sum()))
m2=R[(R.group=='PSLN-212')&R.surv_block.isin(['S03-I','S06-A','S06-B','S06-C','S06-D','S06-E(r34)','S06-F(r34)','S06-G'])]
print('PSLN-212 aged BALB/c 8 blocks: survival-block deaths',int(m2.surv_dead.sum()),'; bw-inferred deaths',int(m2.bw_dead.sum()),'; best-case for PSLN-212 (min per block)',int(np.minimum(m2.surv_dead,m2.bw_dead).sum()),'of',int(m2.n.sum()))

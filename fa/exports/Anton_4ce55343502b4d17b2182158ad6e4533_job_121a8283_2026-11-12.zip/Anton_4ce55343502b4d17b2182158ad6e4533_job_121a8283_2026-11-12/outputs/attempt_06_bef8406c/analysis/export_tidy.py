import pandas as pd, numpy as np, os
import psln_blocks as P
os.makedirs('tidy', exist_ok=True)
cont = pd.concat(P.B.values(), ignore_index=True)
for c in ['time','dose_ug','analyte','animal']:
    if c not in cont: cont[c] = np.nan
cont.to_csv('tidy/continuous_blocks.csv', index=False)
surv = pd.concat(P.SURV.values(), ignore_index=True); surv.to_csv('tidy/survival_blocks.csv', index=False)
bw = pd.concat(P.BW.values(), ignore_index=True); bw['time']=bw['time'].astype(float); bw.to_csv('tidy/bodyweight_blocks.csv', index=False)
print(cont.shape, surv.shape, bw.shape)
print(surv.groupby(['block','group']).agg(n=('event','size'), deaths=('event','sum'), day_missing=('day', lambda s: s.isna().sum())).to_string())

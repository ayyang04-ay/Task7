import pandas as pd, numpy as np, itertools
c=pd.read_csv('tidy/continuous_blocks.csv'); bw=pd.read_csv('tidy/bodyweight_blocks.csv'); sv=pd.read_csv('tidy/survival_blocks.csv')
def col(b,g): return c[(c.block==b)&(c.group==g)].value.values
print('=== 1. S03-B / S03-F printed quotient vs quotient recomputed from S13 raw titres (IgG2a/IgG1, animal-by-animal, same row order)')
for ratio_blk,(a,b_) in {'S03-B':('S13-A','S13-B'),'S03-F':('S13-C','S13-D')}.items():
    rec={g:col(a,g)/col(b_,g) for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']}
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        printed=col(ratio_blk,g)
        match=[gg for gg,v in rec.items() if np.allclose(v,printed,rtol=2e-3)]
        print(f'  {ratio_blk} column printed as {g:12s}: {np.round(printed,3)}  == recomputed {a}/{b_} for -> {match};  recomputed for {g}: {np.round(rec[g],3)} mean {rec[g].mean():.2f} (geo {np.exp(np.log(rec[g]).mean()):.2f})')
print()
print('=== 2. S09-A (log10) vs S01-A (linear) Ifnb1')
for side in ['S09-A left','S09-A right']:
    x=c[(c.block==side)&(c.analyte=='Ifnb1')].groupby('group',sort=False).value.mean()
    print(' ',side,{k:round(10**v,2) for k,v in x.items()})
for t in ['S01-A 16h','S01-A 72h']:
    x=c[c.block==t].groupby('group',sort=False).value.apply(lambda v: np.exp(np.log(v).mean()))
    print(' ',t,'(geo mean)',{k:round(v,2) for k,v in x.items()})
print()
print('=== 3. S01-B vs S08-C')
for b in ['S01-B','S08-C']:
    for g in c[c.block==b].group.unique(): print('  ',b,g,col(b,g))
print()
print('=== 4. S11-A vs S11-B shared cells (same group, day, replicate position)')
a=c[c.block=='S11-A'].reset_index(drop=True); b=c[c.block=='S11-B'].reset_index(drop=True)
m=a.merge(b,on=['group','time','animal'],suffixes=('_A','_B'))
m['same']=m.value_A==m.value_B
print('   identical cells:',int(m.same.sum()),'of',len(m))
print(m.groupby('animal').same.sum().to_string())
print()
print('=== 5. survival blocks that are cell-for-cell identical')
keys={}
for b,d in sv.groupby('block',sort=False):
    k=tuple((g,tuple(x.day.fillna(-1)),tuple(x.event)) for g,x in d.groupby('group',sort=False))
    keys.setdefault(k,[]).append(b)
print('  ',[v for v in keys.values() if len(v)>1])
# per-group identity across blocks
gk={}
for (b,g),x in sv.groupby(['block','group'],sort=False):
    if x.event.sum()>=2:
        gk.setdefault((tuple(sorted(x.day.fillna(-1))),tuple(sorted(x.event))),[]).append((b,g))
print('   identical death-day vectors (>=2 deaths) across blocks/groups:')
for k,v in gk.items():
    if len(v)>1: print('     ',k[0],v)
print()
print('=== 6. identical body-weight series across different blocks/animals')
ser={}
for (b,g,a_),y in bw.groupby(['block','group','animal'],sort=False):
    y=y.sort_values('time'); ser.setdefault(tuple(np.round(y.value.values,3)),[]).append((b,a_))
for k,v in ser.items():
    if len(v)>1: print('   ',v,k)
# partial duplicates: shared long runs (>=4 consecutive identical values post day0, not flat) between two animals
print('   partial (>=4 consecutive shared, non-flat values):')
S={ (b,a_): y.sort_values('time').value.values for (b,g,a_),y in bw.groupby(['block','group','animal'],sort=False)}
keys_=list(S.keys()); seen=0
idx={}
for k_,v in S.items():
    for i in range(1,len(v)-3):
        w=tuple(np.round(v[i:i+4],3))
        if len(set(w))>=3: idx.setdefault(w,set()).add(k_)
for w,ks in idx.items():
    if len(ks)>1: print('     ',w,sorted(ks))
print()
print('=== 7. generic scan: continuous blocks sharing >=3 identical values in the same group label')
vals={}
for (b,g),x in c.groupby(['block','group'],sort=False):
    vals[(b,g)]=set(np.round(x.value.values,4))
for (k1,v1),(k2,v2) in itertools.combinations(vals.items(),2):
    if k1[0]==k2[0]: continue
    sh=v1&v2
    sh={s for s in sh if s not in (0,1,10,20,40,80,160,320,640,100,14,30,60,120,240,480,960,1920,3840,7680,15360)}
    if len(sh)>=3: print('   ',k1,k2,sorted(sh))

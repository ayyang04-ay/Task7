"""
Builds the headline-number ledger: every number used in the memo, with source block, cell range and reduction.
Values are computed here from the tidy per-animal tables (never typed by hand).
"""
import pandas as pd, numpy as np, json, warnings
warnings.filterwarnings('ignore')
from scipy import stats
from statsmodels.stats.proportion import proportion_confint, confint_proportions_2indep
c=pd.read_csv('tidy/continuous_blocks.csv'); sv=pd.read_csv('tidy/survival_blocks.csv'); bw=pd.read_csv('tidy/bodyweight_blocks.csv')
c['key']=c['time'].fillna(c['dose_ug']).fillna(c['analyte']).fillna('').astype(str)
SS=pd.read_csv('results_survival_summary.csv'); PT=pd.read_csv('results_pooled_survival_tests.csv'); SC=pd.read_csv('results_survival_comparisons.csv')
BWR=pd.read_csv('results_bw_vs_survival.csv'); BWA=pd.read_csv('results_bw_per_animal.csv')
L=[]
def add(id_,claim,value,blocks,cells,reduction): L.append(dict(id=id_,claim=claim,value=value,blocks=blocks,cells=cells,reduction=reduction))
def rng(block,group=None,key=None):
    x=c[c.block==block]
    if group is not None: x=x[x.group==group]
    if key is not None: x=x[x.key==str(key)]
    return f"{x.sheet.iloc[0]}!{x.cell.iloc[0]}:{x.cell.iloc[-1]}"
def vals(block,group,key=None):
    x=c[(c.block==block)&(c.group==group)]
    if key is not None: x=x[x.key==str(key)]
    return x.value.values.astype(float)
def msd(block,group,key=None,d=1):
    v=vals(block,group,key); return f"{v.mean():.{d}f} ± {v.std(ddof=1):.{d}f} (n={len(v)})"
def gmt(block,group):
    v=vals(block,group); v=np.where(v<=0,5.0,v); return float(np.exp(np.log(v).mean()))
def welch(block,a,b,key=None,log=False):
    x,y=vals(block,a,key),vals(block,b,key)
    if log: x,y=np.log10(np.where(x<=0,5,x)),np.log10(np.where(y<=0,5,y))
    return stats.ttest_ind(x,y,equal_var=False).pvalue
def sr(block,group):
    d=sv[(sv.block==block)&(sv.group==group)]; return len(d)-int(d.event.sum()),len(d)
def srng(block,group):
    d=sv[(sv.block==block)&(sv.group==group)]
    a=d.cell.iloc[0].split('/'); b=d.cell.iloc[-1].split('/')
    day0=a[0]; day1=b[0]; f0=a[1] if len(a)>1 else a[0]; f1=b[1] if len(b)>1 else b[0]
    return f"{d.sheet.iloc[0]}!{day0}:{day1} (days), {f0}:{f1} (flags)"
def p(v): return f"{v:.2g}" if v>=1e-4 else f"{v:.1e}"

# ---------------- A. survival, per block
blocks8=['S03-I','S06-A','S06-B','S06-C','S06-D','S06-E(r34)','S06-F(r34)','S06-G']
desc={'S03-I':'bivalent vaccine -> 10x mLD50 CA09 H1N1, day 14 (homologous)','S06-A':'H3N2 vaccine -> 5x mLD50 PR8 H1N1, day 14','S06-B':'H3N2 vaccine -> PR8 H1N1, day 3','S06-C':'bivalent -> rgH5N1, day 14','S06-D':'bivalent -> rgH5N1, day 3',
      'S06-E(r34)':'H3N2 vaccine -> PR8 H1N1, day 60','S06-F(r34)':'bivalent -> rgH5N1, day 60','S06-G':'H1N1 vaccine -> Perth H3N2, day 60','S03-J':'rgH5N1 vaccine -> wild-type VN04 H5N1, day 2 (stated n 9; 10 rows per group; PSLN-344 row 46 has a flag but no day)','S15-L':'C57BL/6 20 mo, bivalent (challenge not documented)','S15-N':'Swiss Webster 20 mo, bivalent (challenge not documented)'}
for b in ['S03-J']+blocks8+['S15-L','S15-N']:
    parts=[]; cells=[]
    for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)','Untreated','CMP-204']:
        d=sv[(sv.block==b)&(sv.group==g)]
        if len(d)==0: continue
        a,n=sr(b,g); parts.append(f"{g} {a}/{n}"); cells.append(f"{g}: {srng(b,g)}")
    f1=SC[(SC.block==b)&(SC.A=='PSLN-344')&(SC.B=='PSLN-212')].iloc[0]; f2=SC[(SC.block==b)&(SC.A=='PSLN-344')&(SC.B=='Sham')].iloc[0]
    add(f"A-{b}",f"Survivors/n at end of observation; {desc[b]}",'; '.join(parts)+f" | PSLN-344 vs PSLN-212: Fisher p={p(f1.fisher_p)}, log-rank p={p(f1.logrank_p)} (perm. {p(f1.logrank_perm_p)}); vs Sham: Fisher p={p(f2.fisher_p)}, log-rank p={p(f2.logrank_p)}",b,'; '.join(cells),
        "survivors = rows with event flag 0; n = rows for the group; two-sided Fisher exact on dead/alive; log-rank on day/event (asymptotic and exact/200k-permutation)")
# other survival blocks
for b,gs in [('S15-H',['3d Vaccine','3d PSLN-344','3d Vaccine+PSLN-344']),('S06-E(r71)',['Naïve+PSLN-212','Imprinting+PSLN-212','Naïve+PSLN-344','Imprinting+PSLN-344']),('S06-F(r71)',['Naïve+PSLN-212','Imprinting+PSLN-212','Naïve+PSLN-344','Imprinting+PSLN-344']),
             ('S09-B',['Sham','PSLN-212Y','PSLN-344Y']),('S09-D',['Sham','PSLN-212Y','PSLN-344Y']),('S09-F',['Sham','PSLN-212Y','PSLN-344Y']),('S13-E',['Naïve','Sham','CMP-204(Y)','PSLN-344(Y)'])]:
    add(f"A-{b}",f"Survivors/n, block {b}",'; '.join(f"{g} {sr(b,g)[0]}/{sr(b,g)[1]}" for g in gs),b,'; '.join(f"{g}: {srng(b,g)}" for g in gs),"survivors = rows with event flag 0 / rows")
x=SC[(SC.block=='S15-H')&(SC.A=='3d Vaccine+PSLN-344')]
add('A-S15-H-p','S15-H: vaccine+PSLN-344 vs each single component',"; ".join(f"vs {r.B}: Fisher p={p(r.fisher_p)}, log-rank p={p(r.logrank_p)}" for _,r in x.iterrows()),'S15-H','S15!A73:D93','two-sided Fisher exact; log-rank')
# ---------------- B. pooled
def pooled(bl,g):
    d=sv[sv.block.isin(bl)&(sv.group==g)]; n=len(d); a=n-int(d.event.sum()); lo,hi=proportion_confint(a,n,method='beta'); return a,n,100*lo,100*hi
for name,bl in [('8 standard aged-BALB/c blocks',blocks8),('7 blocks (S06-C dropped: identical to S06-D)',[b for b in blocks8 if b!='S06-C']),('day-3 blocks S06-B,S06-D',['S06-B','S06-D']),('day-14 blocks S03-I,S06-A,S06-C',['S03-I','S06-A','S06-C']),('day-60 blocks S06-E,F,G',['S06-E(r34)','S06-F(r34)','S06-G'])]:
    s=[]
    for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)','Untreated']:
        d=sv[sv.block.isin(bl)&(sv.group==g)]
        if len(d)==0: continue
        a,n,lo,hi=pooled(bl,g); s.append(f"{g} {a}/{n} = {100*a/n:.1f}% (95% CI {lo:.0f}-{hi:.0f})")
    add("B-pool-"+name.split(' (')[0].replace(' ','-').replace(',','').replace(':',''),f"Pooled survival, {name}",'; '.join(s),', '.join(bl),'all rows of the named groups in those blocks','sum of survivors / sum of animals; Clopper-Pearson exact 95% CI')
r=PT[(PT.set.str.startswith('Aged BALB/c, all 8'))]
for _,q in r.iterrows():
    add(f"B-test8-{q.A}-vs-{q.B}",f"Pooled test, 8 blocks: {q.A} vs {q.B}",f"dead {q.A_dead} vs {q.B_dead}; stratified log-rank z={q.strat_logrank_z:.2f}, p={p(q.strat_logrank_p)}; CMH p={p(q.cmh_p) if q.cmh_p>0 else '<1e-15'}; pooled Fisher p={p(q.pooled_fisher_p)}",', '.join(blocks8),'all rows','stratified (by block) log-rank; Cochran-Mantel-Haenszel; pooled Fisher exact')
r=PT[(PT.set.str.startswith('Challenge 60'))]
for _,q in r.iterrows():
    add(f"B-test60-{q.A}-vs-{q.B}",f"Pooled test, day-60 blocks: {q.A} vs {q.B}",f"dead {q.A_dead} vs {q.B_dead}; stratified log-rank p={p(q.strat_logrank_p)}; pooled Fisher p={p(q.pooled_fisher_p)}",'S06-E(r34), S06-F(r34), S06-G','all rows','stratified log-rank; pooled Fisher exact')
lo,hi=confint_proportions_2indep(46,56,6,56,method='newcomb')
add('B-diff','Absolute survival difference PSLN-344 minus PSLN-212, 8 blocks',f"71.4 points (95% CI {100*lo:.0f} to {100*hi:.0f})",', '.join(blocks8),'all rows','difference of pooled proportions; Newcombe CI')
from lifelines import CoxPHFitter
d=sv[sv.block.isin(blocks8)&sv.group.isin(['PSLN-344','PSLN-212'])].copy(); d['trt']=(d.group=='PSLN-344').astype(int)
s=CoxPHFitter().fit(d[['day','event','trt','block']],'day','event',strata=['block']).summary.loc['trt']
add('B-HR','Hazard ratio for death, PSLN-344 vs PSLN-212, aged BALB/c',f"HR {s['exp(coef)']:.3f} (95% CI {s['exp(coef) lower 95%']:.3f}-{s['exp(coef) upper 95%']:.3f}), p={p(s['p'])}",', '.join(blocks8),'all rows','Cox proportional hazards, stratified by block')
add('B-d14-vs-d60','PSLN-344 deaths, day-14 blocks vs day-60 blocks',f"1/21 vs 7/21; Fisher p={p(stats.fisher_exact([[1,20],[7,14]])[1])}; with day-60 deaths taken from the weight blocks S15-E/F/G (1+2+2): 1/21 vs 5/21, Fisher p={p(stats.fisher_exact([[1,20],[5,16]])[1])}",'S03-I,S06-A,S06-C vs S06-E,F,G (and S15-E,F,G)','PSLN-344 rows','pooled counts; two-sided Fisher exact')
add('B-d60-vs-untreated','Day-60: PSLN-344 (challenged) vs Untreated (unchallenged) deaths',f"7/21 vs 4/21; Fisher p={p(stats.fisher_exact([[7,14],[4,17]])[1])}",'S06-E(r34), S06-F(r34), S06-G','PSLN-344 and Untreated rows','pooled counts; two-sided Fisher exact')
allb={'S03-I':'PSLN-344','S03-J':'PSLN-344','S06-A':'PSLN-344','S06-B':'PSLN-344','S06-C':'PSLN-344','S06-D':'PSLN-344','S06-E(r34)':'PSLN-344','S06-F(r34)':'PSLN-344','S06-G':'PSLN-344','S15-H':'3d Vaccine+PSLN-344','S15-L':'PSLN-344','S15-N':'PSLN-344'}
a=sum(sr(b,g)[0] for b,g in allb.items()); n=sum(sr(b,g)[1] for b,g in allb.items()); lo,hi=proportion_confint(a,n,method='beta')
add('B-all','All vaccine+PSLN-344 arms in >=20-month animals (12 arms, 3 strains)',f"{a}/{n} = {100*a/n:.1f}% (95% CI {100*lo:.0f}-{100*hi:.0f})",', '.join(allb),'PSLN-344 rows','sum of survivors / sum of animals; Clopper-Pearson')
# additional pooled figures quoted in the memo
het=['S06-A','S06-B','S06-C','S06-D','S06-E(r34)','S06-F(r34)','S06-G']
def pc(bl,g):
    a,n,lo,hi=pooled(bl,g); return f"{a}/{n} ({100*a/n:.0f}%)"
add('B-het7','Mismatched-subtype blocks (vaccine and challenge of different subtype)',f"PSLN-344 {pc(het,'PSLN-344')}; PSLN-212 {pc(het,'PSLN-212')}; Sham {pc(het,'Sham')}",', '.join(het),'all rows of the named groups','sum of survivors / sum of animals')
h4=['S06-A','S06-B','S06-E(r34)','S06-G']
add('B-het4','H3N2-only vaccine -> H1N1 challenge and H1N1-only vaccine -> H3N2 challenge',f"PSLN-344 {pc(h4,'PSLN-344')}; PSLN-212 {pc(h4,'PSLN-212')}",', '.join(h4),'all rows of the named groups','sum of survivors / sum of animals')
e=[('S03-J','PSLN-344'),('S06-B','PSLN-344'),('S06-D','PSLN-344'),('S15-H','3d Vaccine+PSLN-344')]
a=sum(sr(b,g)[0] for b,g in e); n=sum(sr(b,g)[1] for b,g in e); lo,hi=proportion_confint(a,n,method='beta')
add('B-early','Vaccine + PSLN-344, challenge 2-3 days after dosing',f"{a}/{n} = {100*a/n:.0f}% (95% CI {100*lo:.0f}-{100*hi:.0f}); by block: "+'; '.join(f"{b} {sr(b,g)[0]}/{sr(b,g)[1]}" for b,g in e)+"; with S15-D weight-inferred deaths in place of S06-D: 26/31 (day-3 pair S06-B + S15-D: 10/14)",'S03-J, S06-B, S06-D, S15-H','PSLN-344 rows','sum of survivors / sum of animals; Clopper-Pearson')
norg=['S03-I','S06-A','S06-B','S06-E(r34)','S06-G']
add('B-norg','Eight blocks minus the three rgH5N1 blocks (S06-C, S06-D, S06-F)',f"PSLN-344 {pc(norg,'PSLN-344')}; PSLN-212 {pc(norg,'PSLN-212')}",', '.join(norg),'all rows of the named groups','sum of survivors / sum of animals')
loo=[pooled([x for x in blocks8 if x!=b],'PSLN-344') for b in blocks8]
add('B-loo','Leave-one-block-out range of pooled PSLN-344 survival',f"{min(100*a/n for a,n,_,_ in loo):.1f}% to {max(100*a/n for a,n,_,_ in loo):.1f}%",', '.join(blocks8),'PSLN-344 rows','pooled proportion recomputed 8 times, each time omitting one block')
dd={g:sv[sv.block.isin(blocks8)&(sv.group==g)&(sv.event==1)].day for g in ['Sham','PSLN-212','PSLN-344']}
add('B-deathday','Day of death among animals that died, 8 blocks','; '.join(f"{g}: median day {v.median():.0f} (n={len(v)}, range {v.min():.0f}-{v.max():.0f})" for g,v in dd.items()),', '.join(blocks8),'rows with event flag 1','median of the day column over rows with flag 1')
add('B-d14-noS06C','Day-14 blocks without S06-C',f"PSLN-344 {pc(['S03-I','S06-A'],'PSLN-344')}; PSLN-212 {pc(['S03-I','S06-A'],'PSLN-212')}",'S03-I, S06-A','all rows of the named groups','sum of survivors / sum of animals')
imp=['S06-E(r71)','S06-F(r71)']
i344=sum(sr(b,g)[0] for b in imp for g in ['Naïve+PSLN-344','Imprinting+PSLN-344']); i212=sum(sr(b,g)[0] for b in imp for g in ['Naïve+PSLN-212','Imprinting+PSLN-212'])
add('B-imprint','Prior-infection study (14-month animals), four arms per adjuvant',f"PSLN-344 arms {i344}/28; PSLN-212 arms {i212}/28; Fisher p={p(stats.fisher_exact([[28-i344,i344],[28-i212,i212]])[1])}",'S06-E(r71), S06-F(r71)','S06!G71:K98; S06!M71:Q98','sum of survivors / sum of animals over the two blocks; two-sided Fisher exact')
y344=[('S09-B','PSLN-344Y'),('S09-D','PSLN-344Y'),('S09-F','PSLN-344Y'),('S13-E','PSLN-344(Y)')]; y212=[('S09-B','PSLN-212Y'),('S09-D','PSLN-212Y'),('S09-F','PSLN-212Y')]
add('B-young','Young animals given PSLN-344 or PSLN-212 (blocks run in young animals only)',f"PSLN-344 {sum(sr(b,g)[0] for b,g in y344)}/{sum(sr(b,g)[1] for b,g in y344)}; PSLN-212 {sum(sr(b,g)[0] for b,g in y212)}/{sum(sr(b,g)[1] for b,g in y212)}",'S09-B, S09-D, S09-F, S13-E','PSLN-344Y / PSLN-344(Y) / PSLN-212Y rows','sum of survivors / sum of animals')
os_=['S15-L','S15-N']
add('B-otherstrains','Aged C57BL/6 and Swiss Webster pooled',f"PSLN-344 {pc(os_,'PSLN-344')}; PSLN-212 {pc(os_,'PSLN-212')}; Sham {pc(os_,'Sham')}; young PSLN-212 {pc(os_,'PSLN-212(Y)')}",'S15-L, S15-N','all rows of the named groups','sum of survivors / sum of animals')
lo,hi=confint_proportions_2indep(44,56,10,56,method='newcomb')
add('B-worst-diff','Worst-case survival difference (PSLN-344 44/56 vs PSLN-212 10/56)',f"{100*(44/56-10/56):.0f} points (95% CI {100*lo:.0f} to {100*hi:.0f}); Fisher p={p(stats.fisher_exact([[44,12],[10,46]])[1])}",'8 survival blocks and their paired weight blocks','see B-sens','difference of proportions; Newcombe CI; two-sided Fisher exact')
BS=pd.read_csv('results_biomarker_screen.csv')
add('C-screen','Read-outs measured in aged sham, aged PSLN-212, aged PSLN-344 and young PSLN-212',f"{len(BS)} read-outs; {int((BS.complete_separation=='yes').sum())} separate protected from unprotected regimens with no overlapping animal; ROC area = 1.0 in those, {BS.AUC_prot_vs_unprot.min():.3f} at the lowest",'see sheet Biomarker_screen','see sheet Biomarker_screen','protected = animals of aged PSLN-344 and young PSLN-212 pooled; unprotected = aged sham and aged PSLN-212 pooled; complete separation if min(protected) > max(unprotected) (reverse for markers that fall)')
def power_fisher(p1,p2,n,alpha=0.05):
    pw=0
    for a_ in range(n+1):
        pa=stats.binom.pmf(a_,n,p1)
        for b_ in range(n+1):
            if stats.fisher_exact([[a_,n-a_],[b_,n-b_]])[1]<alpha: pw+=pa*stats.binom.pmf(b_,n,p2)
    return pw
add('C-power','Power of a two-arm survival comparison at the observed effect (82% vs 11%)','; '.join(f"n={n}: {100*power_fisher(0.82,0.11,n):.0f}%" for n in [7,10,12,15]),'design calculation','n/a','exact enumeration of two binomials; two-sided Fisher exact test at alpha 0.05')
# sensitivity from body-weight blocks
m=BWR[(BWR.group=='PSLN-344')&BWR.surv_block.isin(blocks8)]; m2=BWR[(BWR.group=='PSLN-212')&BWR.surv_block.isin(blocks8)]
add('B-sens','Sensitivity: deaths inferred from paired body-weight blocks (blank or carried-forward series)',
    f"PSLN-344: {int(m.surv_dead.sum())} deaths (survival blocks) vs {int(m.bw_dead.sum())} (weight blocks); worst case per block {int(np.maximum(m.surv_dead,m.bw_dead).sum())}/56 dead = {56-int(np.maximum(m.surv_dead,m.bw_dead).sum())}/56 alive; PSLN-212: {int(m2.surv_dead.sum())} deaths vs {int(m2.bw_dead.sum())} (= {56-int(m2.bw_dead.sum())}/56 alive on the weight blocks); best case {int(np.minimum(m2.surv_dead,m2.bw_dead).sum())}/56 dead = {56-int(np.minimum(m2.surv_dead,m2.bw_dead).sum())}/56 alive",
    'S13-F,S15-A..G vs S03-I,S06-A..G','see results_bw_vs_survival.csv','death inferred if series stops before day 14, or last >=3 readings identical, or last 2 identical and <90%')
add('B-agree','Agreement between weight-inferred and recorded deaths',f"{int((BWR.agree=='yes').sum())} of {int(BWR.agree.isin(['yes','NO']).sum())} group-level comparisons agree; {int((BWR.agree=='NO').sum())} disagree",'17 paired blocks','results_bw_vs_survival.csv','count of groups where n and deaths match')
# day-60 deaths: final weights
x=BWA[BWA.block.isin(['S15-E','S15-F','S15-G'])&(BWA.status!='alive')&BWA.group.isin(['PSLN-344','Untreated'])]
add('B-d60-weights','Last recorded weight of animals that died in day-60 blocks',"; ".join(f"{g}: "+', '.join(f"{v:.1f}%" for v in sorted(y.final)) for g,y in x.groupby('group')),'S15-E,S15-F,S15-G','; '.join(f"{r.block} {r.animal}: {r.cells}" for _,r in x.iterrows()),'final (carried-forward) value of each flat-lined series')
# morbidity
def nad(bl,g):
    y=BWA[BWA.block.isin(bl)&(BWA.group==g)&(BWA.status=='alive')]; return y.nadir.mean(),y.nadir.std(ddof=1),len(y),y.final.mean()
bl=['S13-F','S15-A','S15-B','S15-C','S15-D','S15-E','S15-F','S15-G']
a=nad(bl,'PSLN-344'); b_=nad(bl,'PSLN-212(Y)')
add('B-morb','Maximum weight loss in survivors (mean nadir, % of day 0) and weight at day 14',f"aged PSLN-344 survivors: nadir {a[0]:.1f} ± {a[1]:.1f} (n={a[2]}), day-14 weight {a[3]:.1f}; young PSLN-212 survivors: nadir {b_[0]:.1f} ± {b_[1]:.1f} (n={b_[2]}), day-14 weight {b_[3]:.1f}",', '.join(bl),'results_bw_per_animal.csv','per-animal minimum of real (non-carried-forward) readings, animals classed alive; mean ± SD over animals')
# ---------------- C. continuous headline numbers
def ratio(block,a,b,key=None): return vals(block,a,key).mean()/vals(block,b,key).mean()
add('C-Ifnb1-16h','Lung Ifnb1 16 h after 20 ug, fold over untreated',f"Sham {msd('S01-A 16h','Sham')}; CMP-204 {msd('S01-A 16h','CMP-204')}; PSLN-212 {msd('S01-A 16h','PSLN-212')}; PSLN-212/R848 {msd('S01-A 16h','PSLN-212/R848')}; PSLN-344 {msd('S01-A 16h','PSLN-344')}; PSLN-212(Y) {msd('S01-A 16h','PSLN-212(Y)')}; PSLN-344(Y) {msd('S01-A 16h','PSLN-344(Y)')} | 344 vs 212 ratio {ratio('S01-A 16h','PSLN-344','PSLN-212'):.2f}, Welch p={p(welch('S01-A 16h','PSLN-344','PSLN-212'))}; 344 aged vs 212 young p={p(welch('S01-A 16h','PSLN-344','PSLN-212(Y)'))}; young 344 vs young 212 ratio {ratio('S01-A 16h','PSLN-344(Y)','PSLN-212(Y)'):.2f}, p={p(welch('S01-A 16h','PSLN-344(Y)','PSLN-212(Y)'))}; aged/young PSLN-212 {ratio('S01-A 16h','PSLN-212','PSLN-212(Y)'):.2f}",'S01-A (16 h panel)','S01!B3:F10','arithmetic mean ± SD of 5 per-animal values; ratio of means; Welch t')
add('C-Ifnb1-72h','Lung Ifnb1 72 h',f"PSLN-212 {msd('S01-A 72h','PSLN-212',d=2)}; PSLN-344 {msd('S01-A 72h','PSLN-344',d=2)}; PSLN-212(Y) {msd('S01-A 72h','PSLN-212(Y)',d=2)}; 344 aged vs 212 young p={p(welch('S01-A 72h','PSLN-344','PSLN-212(Y)'))}",'S01-A (72 h panel)','S01!H3:L10','mean ± SD, n=5; Welch t')
# dose response
from scipy import optimize
def hill(x,emax,ed50,h): return 1+(emax-1)*x**h/(ed50**h+x**h)
d=c[c.block=='S08-A']; fit={}
for g in ['CMP-204','PSLN-212','PSLN-344']:
    x=d[d.group==g]; pp,cov=optimize.curve_fit(hill,x.dose_ug.values,x.value.values,p0=[x.value.max(),10,2],bounds=([1,0.5,0.5],[500,200,8]),maxfev=20000); fit[g]=(pp,np.sqrt(np.diag(cov)))
m=d.groupby(['group','dose_ug']).value.mean().unstack()
add('C-dose','Ifnb1 dose-response at 16 h (1,5,10,20,40 ug)',f"means PSLN-212: {', '.join(f'{v:.1f}' for v in m.loc['PSLN-212'])}; PSLN-344: {', '.join(f'{v:.1f}' for v in m.loc['PSLN-344'])}; CMP-204: {', '.join(f'{v:.1f}' for v in m.loc['CMP-204'])} | Emax fit: PSLN-212 Emax {fit['PSLN-212'][0][0]:.1f} (SE {fit['PSLN-212'][1][0]:.1f}), ED50 {fit['PSLN-212'][0][1]:.1f} ug; PSLN-344 Emax {fit['PSLN-344'][0][0]:.1f} (SE {fit['PSLN-344'][1][0]:.1f}), ED50 {fit['PSLN-344'][0][1]:.1f} ug (SE {fit['PSLN-344'][1][1]:.1f}); CMP-204 Emax {fit['CMP-204'][0][0]:.1f}, ED50 {fit['CMP-204'][0][1]:.1f} ug | PSLN-344 at 10 ug ({m.loc['PSLN-344',10]:.1f}) > PSLN-212 at 40 ug ({m.loc['PSLN-212',40]:.1f}); PSLN-344 20 ug = {100*m.loc['PSLN-344',20]/m.loc['PSLN-344',40]:.0f}% of 40 ug",'S08-A','S08!B3:J7','mean of 3 per dose; 3-parameter Emax model E=1+(Emax-1)d^h/(ED50^h+d^h), least squares on individual values')
add('C-EE','Encapsulation efficiency (%)',f"PSLN-212 {msd('S08-B','PSLN-212')}; PSLN-344 {msd('S08-B','PSLN-344')}; Welch p={p(welch('S08-B','PSLN-344','PSLN-212'))}; CMP-204 {msd('S08-B','CMP-204')}; PSLN-212/R848 {msd('S08-B','PSLN-212/R848')}",'S08-B','S08!A11:O11','mean ± SD of 3 preparations; Welch t')
x=c[c.block=='S02-F']
add('C-GMCSF','Lung Gm-csf mRNA, fold over untreated (16/36/72 h)',"; ".join(f"{t}: PSLN-344 {msd('S02-F','PSLN-344',t,2)}, PSLN-212 {msd('S02-F','PSLN-212',t,2)}, Sham {msd('S02-F','Sham',t,2)}, 344 vs 212 p={p(welch('S02-F','PSLN-344','PSLN-212',t))}" for t in ['16h','36h','72h']),'S02-F','S02!B17:P19','mean ± SD, n=5 per timepoint; Welch t')
for blk,key,lab in [('S01-D','4','Lung Ly6C+ monocytes day 4 (%)'),('S01-D','8','Lung Ly6C+ monocytes day 8 (%)'),('S01-E','4','Lung CD11b+ DC day 4 (%)'),('S01-E','8','Lung CD11b+ DC day 8 (%)')]:
    add(f"C-{blk}-d{key}",lab,f"Sham {msd(blk,'Sham',key)}; PSLN-212 {msd(blk,'PSLN-212',key)}; PSLN-344 {msd(blk,'PSLN-344',key)}; PSLN-212(Y) {msd(blk,'PSLN-212(Y)',key)}; 344 vs 212 p={p(welch(blk,'PSLN-344','PSLN-212',key))}; 344 vs young p={p(welch(blk,'PSLN-344','PSLN-212(Y)',key))}",blk,rng(blk,key=key),'mean ± SD, n=5; Welch t')
for blk,lab,dd in [('S01-F','cDC1 share of lung DC, 72 h (%)',1),('S02-A','CCR7+ migratory CD11b+ DC, lung, 72 h (%)',1),('S02-B','CD11b+CD103- DC in MLN, 72 h (%)',1),('S02-D CD40','CD40+ of MLN CD11b+ DC, d3 (%)',1),('S02-D CD86','CD86+ of MLN CD11b+ DC, d3 (%)',1),
                ('S03-K','GC B cells in MLN, d7 (%)',2),('S04-A ICOS+','ICOS+ Tfh in MLN, d7 (%)',1),('S04-B Foxp3','Tfr (Foxp3+ of CXCR5+) in MLN, d7 (%)',1),('S04-C','Tfr in MLN, d30 (%)',1),('S04-D','Lung Treg, d7 (%)',2),
                ('S05-D','Ki-67+ CD8 T, lung, d3 (%)',2),('S05-E','GZMB+ CD8 T, lung, d3 (%)',2),('S05-F','IFN-g+ CD8 T, MLN, rgH5N1 restim, d14 (%)',2),('S05-G','IFN-g+ CD8 T, MLN, rgH5N1 restim, d60 (%)',2),('S05-H','GZMB+ CD8 T, MLN, d60 (%)',2),('S05-I','Lung CD69+CD103+ resident-memory CD8 T, d25 (%)',2),
                ('S11-E','CD206+ macrophages in lung (%)',1),('S13-H','IgG+ of MLN B220+ cells (%)',1),('S14-A H1N1','IFN-g+ CD8 T, MLN, H1N1 restim (%)',1),('S14-A H3N2','IFN-g+ CD8 T, MLN, H3N2 restim (%)',1)]:
    gs=[g for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)'] if len(vals(blk,g))]
    ri=(vals(blk,'PSLN-344').mean()-vals(blk,'PSLN-212').mean())/(vals(blk,'PSLN-212(Y)').mean()-vals(blk,'PSLN-212').mean())
    add(f"C-{blk}",lab,'; '.join(f"{g} {msd(blk,g,d=dd)}" for g in gs)+f" | 344 vs 212 p={p(welch(blk,'PSLN-344','PSLN-212'))}; 344 vs young p={p(welch(blk,'PSLN-344','PSLN-212(Y)'))}; gap closed {100*ri:.0f}%",blk,rng(blk),'mean ± SD of per-animal values; Welch t; gap closed = (344-212)/(young-212)')
for blk,lab in [('S02-C','OVA-AF647+ DC in MLN, 36 h (%)'),('S02-E','OT-I proliferation with sorted MLN CD11b+ DC (%)')]:
    add(f"C-{blk}",lab,'; '.join(f"{g} {msd(blk,g,d=2)}" for g in ['PSLN-212','PSLN-344','PSLN-212(Y)','PTX','PSLN-344(Y)'])+f" | 344 vs 212 p={p(welch(blk,'PSLN-344','PSLN-212'))}",blk,rng(blk),'mean ± SD, n=5; Welch t')
# titres
for blk,lab in [('S03-A','Serum IgG anti-CA09 H1N1, d14'),('S03-E','Serum IgG anti-Aichi H3N2, d14'),('S03-C','HAI anti-CA09 H1N1, d14'),('S03-G','HAI anti-Aichi H3N2, d14'),('S03-D','Neutralising titre anti-CA09, d14'),('S03-H','Neutralising titre anti-Aichi, d14'),('S13-I','Serum IgG anti-CA09, d28 after d14 boost'),('S13-J','Serum IgG anti-Aichi, d28 after d14 boost')]:
    gs=['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)']
    ri=(np.log(gmt(blk,'PSLN-344'))-np.log(gmt(blk,'PSLN-212')))/(np.log(gmt(blk,'PSLN-212(Y)'))-np.log(gmt(blk,'PSLN-212')))
    rg=lambda g: f"{np.where(vals(blk,g)<=0,0,vals(blk,g)).min():.0f}-{vals(blk,g).max():.0f}"
    add(f"C-{blk}",lab+' (GMT [range])','; '.join(f"{g} {gmt(blk,g):,.0f} [{rg(g)}]" for g in gs)+f" | 344/212 = {gmt(blk,'PSLN-344')/gmt(blk,'PSLN-212'):.1f}x, Welch p (log10)={p(welch(blk,'PSLN-344','PSLN-212',log=True))}; 344/young = {gmt(blk,'PSLN-344')/gmt(blk,'PSLN-212(Y)'):.2f}x, p={p(welch(blk,'PSLN-344','PSLN-212(Y)',log=True))}; gap closed (log scale) {100*ri:.0f}%",blk,rng(blk),'geometric mean of 5 per-animal reciprocal titres (HAI printed as 0 = <10 set to 5); Welch t on log10 titres')
for blk in ['S03-C','S03-G']:
    add(f"C-{blk}-sp",f"{blk}: animals with HAI >=40 and >=160",'; '.join(f"{g} {(vals(blk,g)>=40).sum()}/5 >=40, {(vals(blk,g)>=160).sum()}/5 >=160" for g in ['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)']),blk,rng(blk),'count of per-animal titres at or above threshold')
# IgG2a/IgG1 recomputed
for a,b,lab in [('S13-A','S13-B','CA09 H1N1'),('S13-C','S13-D','Aichi H3N2')]:
    s=[]
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        r=vals(a,g)/vals(b,g); s.append(f"{g} mean {r.mean():.2f} (geo {np.exp(np.log(r).mean()):.2f})")
    pr={'S13-A':'S03-B','S13-C':'S03-F'}[a]
    add(f"C-ratio-{a}",f"IgG2a/IgG1 quotient, {lab}, recomputed animal-by-animal from raw titres",'; '.join(s)+f" | as printed in {pr}: "+'; '.join(f"{g} {vals(pr,g).mean():.2f}" for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']),f"{a}, {b} (vs {pr})",f"{rng(a)}; {rng(b)}; {rng(pr)}",'per-animal IgG2a titre / IgG1 titre (same row), mean and geometric mean of 5; printed columns of S03-B/F match the recomputed values of a different group (headers rotated one position)')
# interventions
add('C-S02-H','CD45.2+ monocyte-derived DC after BM transfer (%)','; '.join(f"{g} {msd('S02-H',g)}" for g in ['WT w/o cDC','WT w/ cDC','IFN w/o cDC','IFN w/ cDC','GMCSF'])+f" | WT vs IFNAR-KO (both w/o pre-cDC): -{100*(1-ratio('S02-H','IFN w/o cDC','WT w/o cDC')):.0f}%, p={p(welch('S02-H','WT w/o cDC','IFN w/o cDC'))}; KO+GM-CSF vs KO: {ratio('S02-H','GMCSF','IFN w/o cDC'):.1f}x, p={p(welch('S02-H','GMCSF','IFN w/o cDC'))}; KO+GM-CSF = {100*ratio('S02-H','GMCSF','WT w/o cDC'):.0f}% of WT",'S02-H','S02!B30:F34','mean ± SD, n=5; Welch t; ratios of means')
add('C-S02-G','Lung Ly6C+CD11c+MHC-II+ cells, day 5 (%)','; '.join(f"{g} {msd('S02-G',g,d=2)}" for g in ['GM-CSF','PSLN-212','PSLN-212+GM-CSF'])+f" | +GM-CSF vs PSLN-212 alone: {ratio('S02-G','PSLN-212+GM-CSF','PSLN-212'):.1f}x, p={p(welch('S02-G','PSLN-212+GM-CSF','PSLN-212'))}",'S02-G','S02!B22:D26','mean ± SD, n=5; Welch t')
add('C-S02-I','Lung GZMB+ CD8 T, day 5, young, +/- CCR2 antagonist (%)',f"PSLN-344(Y) {msd('S02-I','PSLN-344(Y)',d=2)}; +INCB3344 {msd('S02-I','PSLN-344(Y)+INCB3344',d=2)}; -{100*(1-ratio('S02-I','PSLN-344(Y)+INCB3344','PSLN-344(Y)')):.0f}%, p={p(welch('S02-I','PSLN-344(Y)','PSLN-344(Y)+INCB3344'))}",'S02-I','S02!H30:I34','mean ± SD, n=5; Welch t')
add('C-S07-B','Lung monocytes and Ly6C+ macrophages +/- CCR2 antagonist (%)',f"monocytes {msd('S07-B mono','PSLN-344',d=2)} vs {msd('S07-B mono','PSLN-344+INCB3344',d=2)} (p={p(welch('S07-B mono','PSLN-344','PSLN-344+INCB3344'))}); Ly6C+ macrophages {msd('S07-B Ly6C+Mac','PSLN-344',d=2)} vs {msd('S07-B Ly6C+Mac','PSLN-344+INCB3344',d=2)} (p={p(welch('S07-B Ly6C+Mac','PSLN-344','PSLN-344+INCB3344'))})",'S07-B','S07!B10:F14','mean ± SD, n=5; Welch t')
add('C-S11-C','Recruited lung monocytes day 3 +/- carbenoxolone (%)',f"CBX- {msd('S11-C','CBX-',d=2)}; CBX+ {msd('S11-C','CBX+',d=2)}; -{100*(1-ratio('S11-C','CBX+','CBX-')):.0f}%, p={p(welch('S11-C','CBX+','CBX-'))}",'S11-C','S11!A17:B21','mean ± SD, n=5; Welch t')
add('C-S12-A','Infiltrating CD45.2+ monocytes, WT vs Ifnar-KO bone marrow, young (%)',f"WT {msd('S12-A','WT to WT')}; IFNAR-/- {msd('S12-A','IFNAR-/- to WT')}; p={p(welch('S12-A','WT to WT','IFNAR-/- to WT'))}",'S12-A','S12!A3:B5','mean ± SD, n=3; Welch t')
add('C-S05-C','OT-I proliferation day 4 +/- pertussis toxin (%)','; '.join(f"{g} {msd('S05-C',g)}" for g in ['Lung','Lung+PTX','MLN','MLN+PTX'])+f" | lung p={p(welch('S05-C','Lung','Lung+PTX'))}; MLN p={p(welch('S05-C','MLN','MLN+PTX'))}",'S05-C','S05!A13:D15','mean ± SD, n=3; Welch t')
add('C-S01-B','Alveolar epithelial cells SRB+ 16 h (%)','; '.join(f"{g} {msd('S01-B',g,d=2)}" for g in ['AECII/PSLN-SRB','AECI/PSLN-SRB','AECII/FreeSRB','AECI/FreeSRB']),'S01-B','S01!B14:F17','mean ± SD, n=5')
add('C-S08-C','Alveolar epithelial cells SRB+ (%), columns as printed','; '.join(f"{g} {msd('S08-C',g,d=2)}" for g in ['AECII-PSLN-SRB','AECII-PSLN-344-SRB','AECI-PSLN-SRB','AECI-PSLN-344-SRB']),'S08-C','S08!A14:D18','mean ± SD, n=5; NB columns A and B reproduce the AECII and AECI means of S01-B (15.8, 3.8)')
add('C-S01-C','Alveolar macrophages DiD+ (%), WT vs Sftpa1/Sftpd double knockout',f"WT {msd('S01-C','WT')}; SPA/D {msd('S01-C','SPA/D')}; p={p(welch('S01-C','WT','SPA/D'))}",'S01-C','S01!B20:E21','mean ± SD, n=4; Welch t')
x=c[c.block=='S07-A']
add('C-S07-A','Lung Ly6C+CCR2+ macrophages (x10^5 cells), days 0/2/5/10/30',"PSLN-212: "+', '.join(f"{vals('S07-A','PSLN-212',k).mean():.1f}" for k in ['0','2','5','10','30'])+"; PSLN-344: "+', '.join(f"{vals('S07-A','PSLN-344',k).mean():.1f}" for k in ['0','2','5','10','30'])+f" | day 5 p={p(welch('S07-A','PSLN-344','PSLN-212','5'))}; day 10 p={p(welch('S07-A','PSLN-344','PSLN-212','10'))}",'S07-A','S07!B3:G7','mean of 3 per timepoint; Welch t')
gB='col B: "Ly6C-CD206+ MΦ"'; gC='col C: "Ly6C-CD206+ MΦ"'
add('C-S07-C','Lung Treg after macrophage transfer (%), two columns with the same printed header',f"column B {msd('S07-C',gB,d=2)}; column C {msd('S07-C',gC,d=2)}; Welch p={p(welch('S07-C',gB,gC))}",'S07-C','S07!B16:C20','mean ± SD, n=5; direction cannot be assigned (identical headers)')
# safety
d8=bw[bw.block=='S08-D']; nadir=d8.groupby(['group','animal']).value.min()
add('C-S08-D','Body weight after immunisation: per-animal nadir (% of day 0) and day-10 mean','; '.join(f"{g}: nadir {nadir[g].mean():.1f} ± {nadir[g].std(ddof=1):.1f}, lowest animal {nadir[g].min():.1f}, day 10 {d8[(d8.group==g)&(d8.time==10)].value.mean():.1f} (n={len(d8[(d8.group==g)&(d8.time==10)])})" for g in ['Vaccine','PSLN-212','PSLN-344','PSLN-212/R848'])+f" | PSLN-344 vs Vaccine nadir p={p(stats.ttest_ind(nadir['PSLN-344'],nadir['Vaccine'],equal_var=False).pvalue)}",'S08-D','S08!B21:AE26','per-animal minimum over days 2-10, mean ± SD of 5; mean of day-10 values')
def g10(side,an,g): 
    v=c[(c.block==side)&(c.analyte==an)&(c.group==g)].value.values; return 10**v.mean()
for side,lab in [('S09-A left','left panel (16 h)'),('S09-A right','right panel (labelled 16 h; Ifnb1 row reproduces the 72 h values of S01-A)')]:
    add(f"C-{side}",f"Lung cytokine mRNA, geometric-mean fold over PBS, {lab}",'; '.join(f"{an}: aged-212 {g10(side,an,'PSLN-212'):.3g}, aged-344 {g10(side,an,'PSLN-344'):.3g}, aged-212/R848 {g10(side,an,'PSLN-212/R848'):.3g}, young-212 {g10(side,an,'PSLN-212(y)'):.3g}" for an in ['Ifnb1','Il6','Ccl2','Tnf','Il10']),side,('S09!B3:V9' if 'left' in side else 'S09!Y3:AS9'),'values are stored as log10 fold; mean of 3 log10 values, back-transformed 10^mean')
add('C-S10-A','CNS transcripts 36 h, fold over untreated','; '.join(f"{a}: PBS {msd('S10-A '+a,'PBS',d=2)}, Sham {msd('S10-A '+a,'Sham',d=2)}, PSLN-344 {msd('S10-A '+a,'PSLN-344',d=2)}, CT {msd('S10-A '+a,'CT',d=2)}, 344 vs PBS p={p(welch('S10-A '+a,'PSLN-344','PBS'))}, 344 vs Sham p={p(welch('S10-A '+a,'PSLN-344','Sham'))}" for a in ['Ifnb1','Tnf','Isg15']),'S10-A','S10!A3:N7','mean ± SD, n=5; Welch t (unadjusted)')
# data-integrity counts quoted in the memo
a=c[c.block=='S11-A'].merge(c[c.block=='S11-B'],on=['group','time','animal'],suffixes=('_A','_B'))
add('D-S11','Cells with identical values in the same position, S11-A (alveolar macrophages) vs S11-B (neutrophils)',f"{int((a.value_A==a.value_B).sum())} of {len(a)}",'S11-A, S11-B','S11!B3:U7 vs S11!B10:U14','cell-by-cell equality, same group, day and replicate position')
x=bw[(bw.block=='S15-C')&(bw.group=='PSLN-344')&(bw.time>0)].merge(bw[(bw.block=='S15-I')&(bw.group=='3d Vaccine+PSLN-344')&(bw.time>0)],on=['time'],suffixes=('_C','_I'))
x=x[x.animal_C.str.split('#').str[1]==x.animal_I.str.split('#').str[1]]
add('D-S15C','Body-weight cells identical between S15-C PSLN-344 and S15-I Vaccine+PSLN-344 (days 2-14)',f"{int(np.isclose(x.value_C,x.value_I).sum())} of {len(x)}",'S15-C, S15-I','S15!W24:AC30 vs S15!W73:AC79','cell-by-cell equality, same day and animal position')
k=lambda b: [tuple(r) for r in sv[sv.block==b][['group','day','event']].itertuples(index=False)]
add('D-S06CD','Rows identical between S06-C and S06-D',f"{sum(1 for p_,q in zip(k('S06-C'),k('S06-D')) if p_==q)} of {len(k('S06-C'))}",'S06-C, S06-D','S06!M3:Q30 vs S06!A34:E61','row-by-row equality of group, day and event flag')
LD=pd.DataFrame(L); LD.to_csv('ledger_headline_numbers.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',400)
for _,r in LD.iterrows(): print(f"[{r.id}] {r.claim}\n     = {r.value}\n     src: {r.blocks} | {r.cells[:160]}\n")

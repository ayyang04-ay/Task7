# Analysis code for the PSLN-344 portfolio memo

Source data: `/tmp/world/filesystem/adjuvant_program_dataset.xlsx` (path set in `psln_blocks.py`, variable `XLSX`) and its annotation PDF.

Run `./run_all.sh` to rebuild everything. Two conda environments are used: `chem` (openpyxl) and `core` (scipy, statsmodels, lifelines, matplotlib, reportlab).

| Step | Script | Output |
|---|---|---|
| 1 | `psln_blocks.py` | Block catalogue: every block is read by explicit sheet/row/column address; each value keeps its cell address |
| 2 | `coverage_check.py` | Confirms that every numeric cell in the workbook is parsed, is an axis value (day, dose), or belongs to the unlabelled region S08 rows 89-101 |
| 3 | `export_tidy.py` | `tidy/continuous_blocks.csv`, `tidy/survival_blocks.csv`, `tidy/bodyweight_blocks.csv` |
| 4 | `survival_analysis.py` | `results_survival_summary.csv`, `results_survival_comparisons.csv` (Fisher exact, log-rank, permutation log-rank) |
| 5 | `pooled_survival.py` | `results_pooled_survival.csv`, `results_pooled_survival_tests.csv` (stratified log-rank, CMH) |
| 6 | `continuous_analysis.py` | `results_continuous_summary.csv`, `results_continuous_comparisons.csv`, `results_restoration_index.csv` |
| 7 | `bw_analysis.py` | `results_bw_vs_survival.csv`, `results_bw_per_animal.csv` (deaths implied by weight series; morbidity) |
| 8 | `crosschecks.py` | Cross-block consistency checks (log in `logs_crosschecks.txt`) |
| 9 | `biomarker_screen.py` | `results_biomarker_screen.csv` |
| 10 | `misc_analysis.py`, `cox_and_power.py` | Dose-response fit, HAI thresholds, reactogenicity, Cox model, power (logs) |
| 11 | `inventory.py`, `integrity_register.py`, `next_studies.py` | `block_inventory.csv`, `data_integrity_register.csv`, `next_studies.csv` |
| 12 | `ledger.py` | `ledger_headline_numbers.csv`: every number quoted in the memo with block, cells and reduction |
| 13 | `make_figures.py` | `../figures/fig1..fig7` |
| 14 | `build_workbook.py`, `build_pdf.py` | `../PSLN-344_evidence_workbook.xlsx`, `../PSLN-344_portfolio_memo.pdf` |

Block names follow the workbook labels. Where a label covers two panels the panel is added (`S01-A 16h`, `S09-A left`). The labels S06-E and S06-F are used twice on sheet S06; `(r34)` marks the day-60 blocks at rows 34-68 and `(r71)` the prior-infection blocks at rows 71-105.

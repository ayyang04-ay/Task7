"""Block inventory: every block in the workbook, where it sits, stated vs observed n, and whether/how it was used."""
import pandas as pd, numpy as np
c=pd.read_csv('tidy/continuous_blocks.csv'); sv=pd.read_csv('tidy/survival_blocks.csv'); bw=pd.read_csv('tidy/bodyweight_blocks.csv')
c['key']=c['time'].fillna(c['dose_ug']).fillna(c['analyte']).fillna('').astype(str)
info={ # block: (measurand, stated n, status, note)
'S01-A 16h':('Lung Ifnb1 mRNA 16 h, adjuvant alone (fold, linear)',5,'USED',''),
'S01-A 72h':('Lung Ifnb1 mRNA 72 h (fold, linear)',5,'USED',''),
'S01-B':('AEC I/II SRB+ %, PSLN-SRB vs free SRB, aged',5,'USED','carrier delivery; Mn-free particle'),
'S01-C':('Alveolar macrophage DiD+ %, WT vs Sftpa1/Sftpd KO (young KO mice)',4,'USED (context)','young animals'),
'S01-D':('Lung Ly6C+ monocytes %, d0-8',5,'USED',''),
'S01-E':('Lung CD11b+ DC %, d0-8',5,'USED',''),
'S01-F':('Lung cDC1 %, 72 h',5,'USED',''),
'S01-G':('Lung cDC2 %, 72 h',5,'USED (context)','complement of S01-F'),
'S02-A':('Lung CCR7+ migratory CD11b+ DC %, 72 h',5,'USED',''),
'S02-B':('MLN CD11b+CD103- DC %, 72 h',5,'USED',''),
'S02-C':('MLN OVA-AF647+ DC %, 36 h',5,'USED','PTX group: adjuvant not stated'),
'S02-D CD40':('CD40+ of MLN CD11b+ DC %, d3',5,'USED',''),
'S02-D CD86':('CD86+ of MLN CD11b+ DC %, d3',5,'USED',''),
'S02-E':('OT-I proliferation with sorted MLN CD11b+ DC %',5,'USED','PTX group: adjuvant not stated'),
'S02-F':('Lung Gm-csf mRNA 16/36/72 h (fold)',5,'USED','no young comparator'),
'S02-G':('Lung Ly6C+CD11c+MHC-II+ cells %, d5, PSLN-212 +/- rGM-CSF',5,'USED (context)','done with PSLN-212, not PSLN-344'),
'S02-H':('CD45.2+ moDC % after WT / Ifnar-KO BM transfer',5,'USED','recipient age not stated'),
'S02-I':('Lung GZMB+ CD8 T %, d5, +/- INCB3344',5,'USED (context)','young animals'),
'S03-A':('Serum IgG anti-CA09 d14 (titre)',5,'USED',''),
'S03-B':('IgG2a/IgG1 quotient anti-CA09',5,'NOT USED AS PRINTED','headers rotated vs S13-A/B; recomputed from raw titres'),
'S03-C':('HAI anti-CA09 d14 (titre; 0 = <10)',5,'USED',''),
'S03-D':('Neutralising titre anti-CA09 d14',5,'USED',''),
'S03-E':('Serum IgG anti-Aichi d14',5,'USED',''),
'S03-F':('IgG2a/IgG1 quotient anti-Aichi',5,'NOT USED AS PRINTED','headers rotated vs S13-C/D; recomputed'),
'S03-G':('HAI anti-Aichi d14',5,'USED',''),
'S03-H':('Neutralising titre anti-Aichi d14',5,'USED',''),
'S03-I':('Survival, bivalent -> 10x mLD50 CA09, d14',7,'USED','aged PSLN-212 disagrees with S13-F'),
'S03-J':('Survival, rgH5N1 vaccine -> wt VN04 H5N1, d2',9,'USED','10 rows/group vs stated 9; 1 PSLN-344 row without day; comparator labels differ from S13-G'),
'S03-K':('MLN GC B cells %, d7',5,'USED',''),
'S03-L Aicda':('MLN B-cell Aicda mRNA d5 (fold)',3,'USED (context)','n=3; no young comparator'),
'S03-L E47':('MLN B-cell E47 mRNA d5 (fold)',3,'USED (context)','n=3; no young comparator'),
'S04-A ICOS-':('MLN ICOS-lo Tfh %, d7',5,'USED (context)',''),
'S04-A ICOS+':('MLN ICOS-hi Tfh %, d7',5,'USED',''),
'S04-B Foxp3':('MLN Tfr % (Foxp3+ of CXCR5+), d7',5,'USED',''),
'S04-B Tfh:Tfr':('Tfh:Tfr quotient, d7',5,'USED (derived)','equals (100-x)/x of S04-B Foxp3; not independent'),
'S04-C':('MLN Tfr %, d30',5,'USED',''),
'S04-D':('Lung Treg %, d7',3,'USED (context)','n=3'),
'S05-A':('Lung NP366-374 tetramer+ CD8 %, d3/5/7',3,'EXCLUDED','2 observations per point vs stated 3; antigen described as both OVA and bivalent vaccine; tetramer/strain compatibility unverified'),
'S05-B':('MLN NP366-374 tetramer+ CD8 %, d3/5/7',3,'EXCLUDED','as S05-A'),
'S05-C':('OT-I proliferation %, lung and MLN, +/- PTX',3,'USED (context)','n=3; C57BL/6 transfer model'),
'S05-D':('Lung Ki-67+ CD8 T %, d3',5,'USED',''),
'S05-E':('Lung GZMB+ CD8 T %, d3',5,'USED',''),
'S05-F':('MLN IFN-g+ CD8 T %, rgH5N1 restim, d14',5,'USED',''),
'S05-G':('MLN IFN-g+ CD8 T %, rgH5N1 restim, d60',5,'USED',''),
'S05-H':('MLN GZMB+ CD8 T %, d60',5,'USED',''),
'S05-I':('Lung CD69+CD103+ resident-memory CD8 %, d25',5,'USED (caveat)','"vaccinated as in S05-A" (antigen ambiguous)'),
'S06-A':('Survival, H3N2 vaccine -> PR8, d14',7,'USED',''),
'S06-B':('Survival, H3N2 vaccine -> PR8, d3',7,'USED',''),
'S06-C':('Survival, bivalent -> rgH5N1, d14',7,'USED (sensitivity: dropped)','cell-for-cell identical to S06-D'),
'S06-D':('Survival, bivalent -> rgH5N1, d3',7,'USED','PSLN-344 and young groups disagree with S15-D weights (0 vs 2 deaths)'),
'S06-E(r34)':('Survival, H3N2 vaccine -> PR8, d60 (+Untreated)',7,'USED','label S06-E used twice on the sheet'),
'S06-F(r34)':('Survival, bivalent -> rgH5N1, d60 (+Untreated)',7,'USED','label S06-F used twice on the sheet'),
'S06-G':('Survival, H1N1 vaccine -> Perth H3N2, d60 (+Untreated)',7,'USED',''),
'S06-E(r71)':('Survival, imprinting study, PR8 challenge (14-month animals)',7,'USED','second block labelled S06-E; challenge day not stated'),
'S06-F(r71)':('Survival, imprinting study, Perth challenge d14',7,'USED','second block labelled S06-F'),
'S07-A':('Lung Ly6C+CCR2+ macrophages (x1e5), d0-30',3,'USED (context)','n=3; no sham/young'),
'S07-B mono':('Lung monocytes % +/- INCB3344',5,'USED (context)','timepoint not stated'),
'S07-B Ly6C+Mac':('Lung Ly6C+ macrophages % +/- INCB3344',5,'USED (context)','timepoint not stated'),
'S07-C':('Lung Treg % after macrophage-subset transfer',5,'EXCLUDED','both columns carry the same header; direction unrecoverable'),
'S08-A':('Lung Ifnb1 dose-response 1-40 ug, 16 h',3,'USED','arm "PSLN-344/R848" is not a described preparation - excluded'),
'S08-B':('Encapsulation efficiency %',3,'USED','A260 of CDN-1807 is reported also for preparations without CDN-1807'),
'S08-C':('AEC I/II SRB+ %, PSLN-SRB vs PSLN-344-SRB',5,'NOT USED FOR CLAIMS','column headers conflict with S01-B (see register)'),
'S09-A left':('Lung cytokine mRNA, log10 fold, 16 h',3,'USED','log10 scale'),
'S09-A right':('Lung cytokine mRNA, log10 fold, labelled 16 h',3,'USED (as probable 72 h)','Ifnb1 row reproduces S01-A 72 h'),
'S09-B':('Survival young, H3N2 vaccine -> PR8 d21',8,'USED',''),
'S09-D':('Survival young, H1N1 vaccine -> Perth d21',8,'USED',''),
'S09-F':('Survival young, bivalent -> rgH5N1 d180',8,'USED','Sham has 7 rows (weights show 8 animals)'),
'S10-A Ifnb1':('CNS Ifnb1 mRNA 36 h',5,'USED',''),'S10-A Tnf':('CNS Tnf mRNA 36 h',5,'USED',''),'S10-A Isg15':('CNS Isg15 mRNA 36 h',5,'USED',''),
'S11-A':('Lung alveolar macrophages %, d0-8',5,'EXCLUDED','35/100 cells identical to S11-B in the same positions; different harvest method'),
'S11-B':('Lung neutrophils %, d0-8',5,'EXCLUDED','35/100 cells identical to S11-A'),
'S11-C':('Recruited monocytes % d3 +/- carbenoxolone',5,'USED (context)',''),
'S11-D':('Lung NK cells %, d0-8',5,'USED (context)',''),
'S11-E':('Lung CD206+ macrophages %',5,'USED (context)','timepoint not stated'),
'S12-A':('Infiltrating monocytes %, WT vs Ifnar-KO BM',3,'USED (context)','young; n=3'),
'S13-A':('Serum IgG2a anti-CA09 d14',5,'USED',''),'S13-B':('Serum IgG1 anti-CA09 d14',5,'USED',''),'S13-C':('Serum IgG2a anti-Aichi d14',5,'USED',''),'S13-D':('Serum IgG1 anti-Aichi d14',5,'USED',''),
'S13-E':('Survival young, bivalent -> 10x CA09 d14',5,'USED','7 rows/group vs stated 5'),
'S13-H':('MLN IgG+ of B220+ %',5,'USED (context)','timepoint not stated'),
'S13-I':('Serum IgG anti-CA09 d28 after d14 boost',5,'USED',''),'S13-J':('Serum IgG anti-Aichi d28 after d14 boost',5,'USED',''),
'S14-A H1N1':('MLN IFN-g+ CD8 %, H1N1 restim',5,'USED','timepoint not stated'),'S14-A H3N2':('MLN IFN-g+ CD8 %, H3N2 restim',5,'USED','timepoint not stated'),
'S15-H':('Survival, 3 d: vaccine / PSLN-344 / both -> rgH5N1',7,'USED',''),
'S15-L':('Survival, aged C57BL/6',7,'USED (caveat)','challenge virus/dose/day not stated'),
'S15-N':('Survival, aged Swiss Webster',7,'USED (caveat)','challenge virus/dose/day not stated'),
}
bwinfo={'S08-D':('Body weight after immunisation (reactogenicity)',5,'USED','PSLN-212/R848: 4 animals at d10'),
'S09-C':('Body weight, animals of S09-B',8,'USED (cross-check)',''),'S09-E':('Body weight, animals of S09-D',8,'USED (cross-check)','shares series with S15-M'),'S09-G':('Body weight, animals of S09-F',8,'USED (cross-check)',''),
'S13-F':('Body weight, "animals of S03-I"',7,'USED (cross-check)','groups differ from S03-I (Naive instead of CMP-204)'),'S13-G':('Body weight, "animals of S03-J"',10,'USED (cross-check)','groups differ from S03-J (Naive instead of PSLN-212)'),
'S15-A':('Body weight, animals of S06-A',7,'USED (cross-check, morbidity)',''),'S15-B':('Body weight, animals of S06-B',7,'USED (cross-check, morbidity)',''),
'S15-C':('Body weight, animals of S06-C',7,'USED (cross-check)','PSLN-344 series: 40/49 cells identical to S15-I'),'S15-D':('Body weight, animals of S06-D',7,'USED (cross-check)','2 carried-forward PSLN-344 series vs 0 deaths in S06-D'),
'S15-E':('Body weight, animals of S06-E(r34)',7,'USED (cross-check, morbidity)',''),'S15-F':('Body weight, animals of S06-F(r34)',7,'USED (cross-check, morbidity)',''),'S15-G':('Body weight, animals of S06-G',7,'USED (cross-check, morbidity)',''),
'S15-I':('Body weight, animals of S15-H',7,'USED (cross-check)',''),'S15-J':('Body weight, animals of S06-E(r71)',7,'USED (cross-check)',''),'S15-K':('Body weight, animals of S06-F(r71)',7,'USED (cross-check)',''),
'S15-M':('Body weight, animals of S15-L',7,'USED (cross-check)','young group shares series with S09-E'),'S15-O':('Body weight, animals of S15-N',7,'USED (cross-check)','')}
rows=[]
for b,x in c.groupby('block',sort=False):
    ns=x.groupby(['key','group']).size(); m,st,status,note=info[b]
    rows.append(dict(block=b,sheet=x.sheet.iloc[0],cells=f"{x.cell.iloc[0]}..{x.cell.iloc[-1]}",kind='per-animal readout',measurand=m,groups=' | '.join(x.group.unique()),stated_n=st,observed_n=(f"{ns.min()}" if ns.min()==ns.max() else f"{ns.min()}-{ns.max()}"),n_mismatch=('YES' if ns.min()!=st or ns.max()!=st else ''),status=status,note=note))
for b,x in sv.groupby('block',sort=False):
    ns=x.groupby('group').size(); m,st,status,note=info[b]
    rows.append(dict(block=b,sheet=x.sheet.iloc[0],cells=f"{x.cell.iloc[0]}..{x.cell.iloc[-1]}",kind='time to event',measurand=m,groups=' | '.join(x.group.unique()),stated_n=st,observed_n=(f"{ns.min()}" if ns.min()==ns.max() else f"{ns.min()}-{ns.max()}"),n_mismatch=('YES' if ns.min()!=st or ns.max()!=st else ''),status=status,note=note))
for b,x in bw.groupby('block',sort=False):
    ns=x[x.time==0].groupby('group').size(); m,st,status,note=bwinfo[b]
    rows.append(dict(block=b,sheet=x.sheet.iloc[0],cells=f"{x.cell.iloc[0]}..{x.cell.iloc[-1]}",kind='body weight',measurand=m,groups=' | '.join(x.group.unique()),stated_n=st,observed_n=(f"{ns.min()}" if ns.min()==ns.max() else f"{ns.min()}-{ns.max()}")+' at day 0',n_mismatch=('YES' if ns.min()!=st or ns.max()!=st else ''),status=status,note=note))
rows.append(dict(block='S08 rows 89-101 (no label)',sheet='S08',cells='A89..D101',kind='unlabelled',measurand='not stated (13 rows: column A = 14; 6 zeros in C, 7 zeros in D)',groups='none',stated_n='',observed_n='6 + 7',n_mismatch='',status='EXCLUDED',note='no label, no header, no group names'))
I=pd.DataFrame(rows).sort_values(['sheet','block']).reset_index(drop=True); I.to_csv('block_inventory.csv',index=False)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',70); pd.set_option('display.max_rows',200)
print(I[['block','kind','stated_n','observed_n','n_mismatch','status','note']].to_string(index=False))
print(I.status.value_counts())

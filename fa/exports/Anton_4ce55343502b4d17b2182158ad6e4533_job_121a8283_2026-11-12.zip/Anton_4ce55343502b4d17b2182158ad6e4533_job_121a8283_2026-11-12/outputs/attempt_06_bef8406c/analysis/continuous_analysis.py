"""
Summary statistics + pre-specified contrasts for every per-animal (non time-to-event, non body-weight) block.
Reduction rules (stated once, applied everywhere):
  * arithmetic mean, SD (n-1), n  for linear-scale readouts (percentages, fold-changes, counts)
  * geometric mean (GMT) for reciprocal titres (ELISA, HAI, neutralisation); HAI values printed as 0 (< 1:10, the lowest dilution tested) are set to 5 (= LOD/2) before logs
  * S09-A is stored as log10 fold -> mean of log10 values, back-transformed (10**mean) = geometric-mean fold
  * tests: one-way ANOVA + Tukey HSD across all groups of a block (the file's stated method); Welch t and exact Mann-Whitney for the single contrasts;
    titres are tested on log10 scale
  * restoration index RI = (PSLN-344 aged - PSLN-212 aged) / (PSLN-212 young - PSLN-212 aged)  (on log scale for titres): share of the age gap closed
"""
import pandas as pd, numpy as np, itertools
from scipy import stats
c = pd.read_csv('tidy/continuous_blocks.csv')
TITRE = ['S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J']
LOG10 = ['S09-A left','S09-A right']
c['key'] = c['time'].fillna(c['dose_ug']).fillna(c['analyte']).fillna('').astype(str)

def gm(v): return float(np.exp(np.mean(np.log(v))))
rows=[]
for (b,k,g),x in c.groupby(['block','key','group'],sort=False):
    v=x.value.values.astype(float)
    r=dict(block=b,sub=k,group=g,n=len(v),mean=v.mean(),sd=(v.std(ddof=1) if len(v)>1 else np.nan),median=np.median(v),min=v.min(),max=v.max(),cells=f"{x.cell.iloc[0]}..{x.cell.iloc[-1]}")
    if b in TITRE:
        vv=np.where(v<=0,5.0,v); r['geo_mean']=gm(vv); r['n_below_LOD']=int((v<=0).sum())
    elif b in LOG10:
        r['geo_mean_fold']=10**v.mean()
    elif (v>0).all(): r['geo_mean']=gm(v)
    rows.append(r)
S=pd.DataFrame(rows); S.to_csv('results_continuous_summary.csv',index=False)

def tv(b,v):
    v=np.asarray(v,float)
    if b in TITRE: return np.log10(np.where(v<=0,5.0,v))
    return v
comp=[]
for (b,k),x in c.groupby(['block','key'],sort=False):
    groups=list(x.group.unique())
    data={g:tv(b,x[x.group==g].value.values) for g in groups}
    # ANOVA + Tukey
    tuk=None
    if len(groups)>=3 and all(len(v)>=2 for v in data.values()):
        F,p=stats.f_oneway(*data.values()); tuk=stats.tukey_hsd(*data.values())
    else: F=p=np.nan
    for i,j in itertools.combinations(range(len(groups)),2):
        a,bb=groups[i],groups[j]; va,vb=data[a],data[bb]
        if len(va)<2 or len(vb)<2: continue
        w=stats.ttest_ind(va,vb,equal_var=False); st=stats.ttest_ind(va,vb,equal_var=True)
        try: mw=stats.mannwhitneyu(va,vb,alternative='two-sided',method='exact').pvalue
        except Exception: mw=np.nan
        sp=np.sqrt(((len(va)-1)*va.var(ddof=1)+(len(vb)-1)*vb.var(ddof=1))/(len(va)+len(vb)-2))
        comp.append(dict(block=b,sub=k,A=a,B=bb,nA=len(va),nB=len(vb),meanA=va.mean(),meanB=vb.mean(),diff=va.mean()-vb.mean(),
                         ratio=(10**(va.mean()-vb.mean()) if (b in TITRE or b in LOG10) else (va.mean()/vb.mean() if vb.mean()!=0 else np.nan)),
                         welch_p=w.pvalue,student_p=st.pvalue,mannwhitney_p=mw,anova_p=p,tukey_p=(tuk.pvalue[i,j] if tuk is not None else np.nan),
                         cohen_d=((va.mean()-vb.mean())/sp if sp>0 else np.nan), scale=('log10' if (b in TITRE or b in LOG10) else 'linear')))
Cmp=pd.DataFrame(comp); Cmp.to_csv('results_continuous_comparisons.csv',index=False)

# restoration index
ri=[]
for (b,k),x in c.groupby(['block','key'],sort=False):
    g={gg:tv(b,x[x.group==gg].value.values).mean() for gg in x.group.unique()}
    y=[n for n in g if n in ('PSLN-212(Y)','PSLN-212Y','PSLN-212(y)')]
    if 'PSLN-212' in g and 'PSLN-344' in g and y:
        den=g[y[0]]-g['PSLN-212']
        ri.append(dict(block=b,sub=k,sham=g.get('Sham',g.get('PBS',g.get('Vaccine',np.nan))),aged_212=g['PSLN-212'],aged_344=g['PSLN-344'],young_212=g[y[0]],
                       RI=(g['PSLN-344']-g['PSLN-212'])/den if den!=0 else np.nan, scale=('log10' if (b in TITRE or b in LOG10) else 'linear')))
RI=pd.DataFrame(ri); RI.to_csv('results_restoration_index.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_rows',1000)
print(S.drop(columns=['cells']).to_string(index=False,float_format=lambda v:f'{v:.4g}'))

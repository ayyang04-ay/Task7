"""
Biomarker screen (between-group only; NO animal has both a biomarker and an outcome).
For each readout measured in aged Sham / aged PSLN-212 / aged PSLN-344 / young PSLN-212:
  protected regimens   = aged PSLN-344, young PSLN-212   (pooled survival 82 % and 100 % in the paired challenge blocks)
  unprotected regimens = aged Sham, aged PSLN-212        (0 % and 11 %)
  * separation: is there a cut-off that classifies every animal by regimen class?  margin = min(protected)/max(unprotected) (or inverse for down-markers)
  * AUC (Mann-Whitney) protected vs unprotected, animals pooled within class
  * key contrast: aged PSLN-344 vs aged PSLN-212 (Welch p on log10 for titres), Cohen d
  * RI: share of the young-aged gap closed by PSLN-344
"""
import pandas as pd, numpy as np
from scipy import stats
c=pd.read_csv('tidy/continuous_blocks.csv'); c['key']=c['time'].fillna(c['analyte']).fillna('').astype(str)
TITRE=['S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J']
meta={ # block: (label, tissue, human-accessible matrix?, timing)
 'S01-A 16h':('Ifnb1 mRNA, lung, 16 h (adjuvant alone)','lung tissue','no (needs blood/nasal surrogate)','16 h'),
 'S01-D':('Ly6C+ monocytes, lung','lung tissue','no (blood monocyte surrogate untested)','d4'),
 'S01-E':('CD11b+ DC, lung','lung tissue','no','d4'),
 'S01-F':('cDC1 share, lung','lung tissue','no','72 h'),
 'S02-A':('CCR7+ migratory CD11b+ DC, lung','lung tissue','no','72 h'),
 'S02-B':('CD11b+CD103- DC, MLN','lymph node','no','72 h'),
 'S02-D CD40':('CD40+ of MLN CD11b+ DC','lymph node','no','d3'),
 'S02-D CD86':('CD86+ of MLN CD11b+ DC','lymph node','no','d3'),
 'S03-A':('serum IgG anti-H1N1 (ELISA)','serum','YES','d14'),
 'S03-C':('serum HAI anti-H1N1','serum','YES','d14'),
 'S03-D':('serum neutralising titre anti-H1N1','serum','YES','d14'),
 'S03-E':('serum IgG anti-H3N2 (ELISA)','serum','YES','d14'),
 'S03-G':('serum HAI anti-H3N2','serum','YES','d14'),
 'S03-H':('serum neutralising titre anti-H3N2','serum','YES','d14'),
 'S03-K':('GC B cells, MLN','lymph node','no (FNA only)','d7'),
 'S04-A ICOS+':('ICOS+ Tfh, MLN','lymph node','no (cTfh in blood untested)','d7'),
 'S04-B Foxp3':('Tfr (Foxp3+ of CXCR5+), MLN [down]','lymph node','no','d7'),
 'S04-D':('Treg, lung [down] (n=3)','lung tissue','no','d7'),
 'S05-D':('Ki-67+ CD8 T, lung','lung tissue','no (BAL only)','d3'),
 'S05-E':('GZMB+ CD8 T, lung','lung tissue','no (BAL only)','d3'),
 'S05-F':('IFN-g+ CD8 T, MLN, rgH5N1 restim (cross-reactive)','lymph node','PBMC analogue (ELISpot/ICS) untested','d14'),
 'S05-G':('IFN-g+ CD8 T, MLN, rgH5N1 restim (cross-reactive)','lymph node','PBMC analogue untested','d60'),
 'S05-H':('GZMB+ CD8 T, MLN','lymph node','PBMC analogue untested','d60'),
 'S05-I':('CD69+CD103+ resident-memory CD8 T, lung','lung tissue','no (BAL only)','d25'),
 'S11-E':('CD206+ macrophages, lung [down]','lung tissue','no','not stated'),
 'S13-H':('IgG+ B220+ cells, MLN','lymph node','no','not stated'),
 'S14-A H1N1':('IFN-g+ CD8 T, MLN, H1N1 restim','lymph node','PBMC analogue untested','not stated'),
 'S14-A H3N2':('IFN-g+ CD8 T, MLN, H3N2 restim','lymph node','PBMC analogue untested','not stated'),
}
sub={'S01-D':'4','S01-E':'4'}
rows=[]
for b,(lab,tis,hum,tim) in meta.items():
    x=c[c.block==b]
    if b in sub: x=x[x.key==sub[b]]
    f=(lambda v: np.log10(np.where(np.asarray(v,float)<=0,5.0,v))) if b in TITRE else (lambda v: np.asarray(v,float))
    g={k:np.asarray(v.value.values,float) for k,v in x.groupby('group')}
    sham,a212,a344,y212=g.get('Sham',np.array([])),g['PSLN-212'],g['PSLN-344'],g['PSLN-212(Y)']
    down='[down]' in lab
    prot=np.r_[a344,y212]; unp=np.r_[sham,a212]
    if down: margin=unp.min()/prot.max()
    else: margin=prot.min()/max(unp.max(),5.0 if b in TITRE else 1e-9)
    u=stats.mannwhitneyu(prot,unp).statistic/(len(prot)*len(unp)); auc=1-u if down else u
    # aged 344 vs aged 212 only
    if down: m2=a212.min()/a344.max()
    else: m2=a344.min()/a212.max()
    w=stats.ttest_ind(f(a344),f(a212),equal_var=False).pvalue
    sp=np.sqrt((f(a344).var(ddof=1)+f(a212).var(ddof=1))/2); dco=(f(a344).mean()-f(a212).mean())/sp
    ri=(f(a344).mean()-f(a212).mean())/(f(y212).mean()-f(a212).mean())
    cen=(lambda v: 10**f(v).mean()) if b in TITRE else (lambda v: np.mean(v))
    rows.append(dict(block=b,readout=lab,matrix=tis,human_accessible=hum,timepoint=tim,n_per_group=len(a344),
                     sham=(cen(sham) if len(sham) else np.nan),aged_212=cen(a212),aged_344=cen(a344),young_212=cen(y212),
                     fold_344_vs_212=(cen(a344)/cen(a212)),RI=ri,welch_p_344_vs_212=w,cohen_d=dco,
                     class_margin=margin,complete_separation=('yes' if margin>1 else 'no'),AUC_prot_vs_unprot=auc,margin_344_vs_212=m2))
R=pd.DataFrame(rows); R.to_csv('results_biomarker_screen.csv',index=False)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',55)
print(R[['block','readout','human_accessible','sham','aged_212','aged_344','young_212','fold_344_vs_212','RI','welch_p_344_vs_212','class_margin','complete_separation','AUC_prot_vs_unprot','margin_344_vs_212']].to_string(index=False,float_format=lambda v:f'{v:.3g}'))

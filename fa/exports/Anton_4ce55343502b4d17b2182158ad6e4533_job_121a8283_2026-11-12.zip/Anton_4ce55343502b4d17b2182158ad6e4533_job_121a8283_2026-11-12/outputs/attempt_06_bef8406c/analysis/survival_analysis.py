"""
Survival analysis for every time-to-event block.
Reduction: per group deaths/n (event=1), Kaplan-Meier survival at end of observation,
median survival time, two-sided Fisher exact test on dead/alive at end of observation,
log-rank test (lifelines) and an exact permutation log-rank p (all label permutations or 200k random).
"""
import pandas as pd, numpy as np, itertools, math
from scipy import stats
from lifelines import KaplanMeierFitter
from lifelines.statistics import logrank_test, multivariate_logrank_test

s = pd.read_csv('tidy/survival_blocks.csv')

def logrank_stat(t, e, g):
    # returns observed - expected for group 1 and variance
    O1 = E1 = V = 0.0
    for tt in np.unique(t[e == 1]):
        at = t >= tt
        n = at.sum(); n1 = (at & (g == 1)).sum()
        d = ((t == tt) & (e == 1)).sum(); d1 = ((t == tt) & (e == 1) & (g == 1)).sum()
        O1 += d1; E1 += d * n1 / n
        if n > 1: V += d * (n1 / n) * (1 - n1 / n) * (n - d) / (n - 1)
    return O1 - E1, V

def perm_logrank(t, e, g, nmax=200000, seed=1):
    t = np.asarray(t, float); e = np.asarray(e, int); g = np.asarray(g, int)
    obs, V = logrank_stat(t, e, g)
    if V == 0: return 1.0
    n = len(g); k = g.sum()
    ncomb = math.comb(n, k)
    cnt = tot = 0
    if ncomb <= nmax:
        for idx in itertools.combinations(range(n), k):
            gg = np.zeros(n, int); gg[list(idx)] = 1
            st, _ = logrank_stat(t, e, gg)
            cnt += abs(st) >= abs(obs) - 1e-12; tot += 1
    else:
        rng = np.random.default_rng(seed)
        for _ in range(nmax):
            gg = rng.permutation(g)
            st, _ = logrank_stat(t, e, gg)
            cnt += abs(st) >= abs(obs) - 1e-12; tot += 1
    return cnt / tot

def summarize(block, d):
    rows = []
    for g, x in d.groupby('group', sort=False):
        xx = x.dropna(subset=['day'])
        n = len(x); deaths = int(x.event.sum())
        km = KaplanMeierFitter().fit(xx.day, xx.event)
        med = km.median_survival_time_
        tmax = xx.day.max()
        rows.append(dict(block=block, group=g, n=n, n_with_day=len(xx), deaths=deaths, survivors=n - deaths,
                         surv_pct=100 * (n - deaths) / n, km_end=float(km.survival_function_.iloc[-1, 0]),
                         median_surv_day=(np.inf if np.isinf(med) else med), death_days=','.join(str(int(v)) for v in sorted(xx.day[xx.event == 1])),
                         censor_day=','.join(sorted(set(str(int(v)) for v in xx.day[xx.event == 0]))), cells=f"{x.cell.iloc[0]}..{x.cell.iloc[-1]}"))
    return rows

def compare(block, d, a, b):
    A = d[d.group == a]; Bb = d[d.group == b]
    if len(A) == 0 or len(Bb) == 0: return None
    tab = [[int(A.event.sum()), int(len(A) - A.event.sum())], [int(Bb.event.sum()), int(len(Bb) - Bb.event.sum())]]
    fp = stats.fisher_exact(tab)[1]
    A2 = A.dropna(subset=['day']); B2 = Bb.dropna(subset=['day'])
    lr = logrank_test(A2.day, B2.day, A2.event, B2.event)
    t = np.r_[A2.day.values, B2.day.values]; e = np.r_[A2.event.values, B2.event.values]; g = np.r_[np.ones(len(A2), int), np.zeros(len(B2), int)]
    pp = perm_logrank(t, e, g)
    return dict(block=block, A=a, B=b, A_dead=f"{tab[0][0]}/{len(A)}", B_dead=f"{tab[1][0]}/{len(Bb)}", fisher_p=fp, logrank_p=lr.p_value, logrank_perm_p=pp)

summ = []; comps = []
for block, d in s.groupby('block', sort=False):
    summ += summarize(block, d)
    groups = list(d.group.unique())
    for a in groups:
        if '344' in a:
            for b in groups:
                if b != a:
                    c = compare(block, d, a, b)
                    if c: comps.append(c)
    # additional non-344 comparisons of interest
    for a, b in [('PSLN-212', 'Sham'), ('PSLN-212(Y)', 'Sham'), ('CMP-204', 'Sham'), ('CMP-204', 'PSLN-212'), ('PSLN-212(Y)', 'PSLN-212'),
                 ('PSLN-212Y', 'Sham'), ('Imprinting+PSLN-212', 'Naïve+PSLN-212'), ('Untreated', 'Sham'), ('Untreated','PSLN-212'), ('Sham', 'Naïve'), ('CMP-204(Y)', 'Sham')]:
        if a in groups and b in groups:
            c = compare(block, d, a, b)
            if c: comps.append(c)
summ = pd.DataFrame(summ); comps = pd.DataFrame(comps).drop_duplicates(subset=['block', 'A', 'B'])
summ.to_csv('results_survival_summary.csv', index=False); comps.to_csv('results_survival_comparisons.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 60)
print(summ.drop(columns=['cells']).to_string(index=False))
print()
print(comps.to_string(index=False, float_format=lambda v: f'{v:.4g}'))

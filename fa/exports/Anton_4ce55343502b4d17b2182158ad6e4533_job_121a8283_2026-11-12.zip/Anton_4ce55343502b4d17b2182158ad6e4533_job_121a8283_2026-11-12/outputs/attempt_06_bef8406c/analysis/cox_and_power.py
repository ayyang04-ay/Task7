import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
from lifelines import CoxPHFitter
from scipy import stats
from statsmodels.stats.proportion import confint_proportions_2indep, proportion_confint
sv=pd.read_csv('tidy/survival_blocks.csv')
bl=['S03-I','S06-A','S06-B','S06-C','S06-D','S06-E(r34)','S06-F(r34)','S06-G']
for ref in ['PSLN-212','Sham']:
    for blocks,name in [(bl,'8 blocks'),([b for b in bl if b!='S06-C'],'7 blocks (no S06-C)')]:
        d=sv[sv.block.isin(blocks)&sv.group.isin(['PSLN-344',ref])].copy(); d['trt']=(d.group=='PSLN-344').astype(int)
        try:
            cph=CoxPHFitter(penalizer=0.0).fit(d[['day','event','trt','block']],'day','event',strata=['block'])
            s=cph.summary.loc['trt']
            print(f"Cox (stratified by block) PSLN-344 vs {ref}, {name}: HR={s['exp(coef)']:.3f} (95% CI {s['exp(coef) lower 95%']:.3f}-{s['exp(coef) upper 95%']:.3f}), p={s['p']:.2g}")
        except Exception as ex: print('cox failed',ref,name,ex)
# risk difference with CI (Newcombe) pooled
for (a,na,b,nb,lab) in [(46,56,6,56,'survival PSLN-344 vs PSLN-212, 8 blocks'),(39,49,4,49,'7 blocks'),(44,56,10,56,'worst case for 344 (12 deaths) vs best case for 212 (46 deaths)'),(14,21,1,21,'day-60 blocks'),(14,21,17,21,'day-60: PSLN-344 challenged vs Untreated unchallenged')]:
    lo,hi=confint_proportions_2indep(a,na,b,nb,method='newcomb')
    print(f'{lab}: {a}/{na} vs {b}/{nb}: diff={100*(a/na-b/nb):.1f} pts (95% CI {100*lo:.1f} to {100*hi:.1f}); Fisher p={stats.fisher_exact([[a,na-a],[b,nb-b]])[1]:.2g}')
print()
# exact power by enumeration for Fisher two-sided alpha 0.05
def power_fisher(p1,p2,n,alpha=0.05):
    pw=0
    for a in range(n+1):
        pa=stats.binom.pmf(a,n,p1)
        if pa<1e-12: continue
        for b in range(n+1):
            pb=stats.binom.pmf(b,n,p2)
            if pb<1e-12: continue
            if stats.fisher_exact([[a,n-a],[b,n-b]])[1]<alpha: pw+=pa*pb
    return pw
for p1,p2 in [(0.82,0.11),(0.80,0.20),(0.80,0.40),(0.80,0.50),(0.67,0.05),(0.67,0.30),(0.90,0.60)]:
    out=[]
    for n in [7,8,10,12,15,20,25,30,40]:
        out.append((n,round(power_fisher(p1,p2,n),2)))
    print(f'power Fisher 2-sided a=0.05, survival {p1} vs {p2}:',out)
# titre planning: SD of log2 HAI within group
c=pd.read_csv('tidy/continuous_blocks.csv')
for b in ['S03-C','S03-G','S03-A','S03-E','S03-D','S03-H']:
    x=c[c.block==b]; sds=x.groupby('group').value.apply(lambda v: np.log2(np.where(v<=0,5,v)).std(ddof=1))
    print(b,'within-group SD of log2 titre:',sds.round(2).to_dict())

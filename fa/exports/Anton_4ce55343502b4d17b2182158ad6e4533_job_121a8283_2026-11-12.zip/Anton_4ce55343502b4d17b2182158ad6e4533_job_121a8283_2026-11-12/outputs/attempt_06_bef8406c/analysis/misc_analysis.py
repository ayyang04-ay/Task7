import pandas as pd, numpy as np
from scipy import stats, optimize
c=pd.read_csv('tidy/continuous_blocks.csv'); bw=pd.read_csv('tidy/bodyweight_blocks.csv')
print('=== S08-A dose-response (Ifnb1 fold, 16 h) : group means and Emax fit  E = 1 + (Emax-1)*d^h/(ED50^h+d^h)')
d=c[c.block=='S08-A']
print(d.pivot_table(index='dose_ug',columns='group',values='value',aggfunc=['mean','std']).round(2).to_string())
def hill(x,emax,ed50,h): return 1+(emax-1)*x**h/(ed50**h+x**h)
fits={}
for g,x in d.groupby('group',sort=False):
    try:
        p,cov=optimize.curve_fit(hill,x.dose_ug.values,x.value.values,p0=[x.value.max(),10,2],bounds=([1,0.5,0.5],[500,200,8]),maxfev=20000)
        se=np.sqrt(np.diag(cov)); fits[g]=p
        print(f'  {g:14s} Emax={p[0]:.1f} (SE {se[0]:.1f})  ED50={p[1]:.1f} ug (SE {se[1]:.1f})  Hill={p[2]:.2f} (SE {se[2]:.2f})')
    except Exception as ex: print(g,'fit failed',ex)
m=d.groupby(['group','dose_ug']).value.mean().unstack()
print('  ratio PSLN-344/PSLN-212 by dose:',(m.loc['PSLN-344']/m.loc['PSLN-212']).round(2).to_dict())
print('  PSLN-344 20ug as % of 40ug:',round(100*m.loc['PSLN-344',20]/m.loc['PSLN-344',40],1),'; PSLN-212 40 vs 20:',round(m.loc['PSLN-212',40]/m.loc['PSLN-212',20],2))
# dose of PSLN-344 giving the PSLN-212 plateau
for tgt in [m.loc['PSLN-212',20],m.loc['PSLN-212',40]]:
    f=lambda x: hill(x,*fits['PSLN-344'])-tgt
    print('  PSLN-344 dose matching PSLN-212 level %.1f: %.1f ug'%(tgt,optimize.brentq(f,0.5,40)))
print()
print('=== HAI seroprotection (>=40) and >=160, S03-C (H1N1) & S03-G (H3N2); values as printed, 0 = <10')
for b in ['S03-C','S03-G']:
    x=c[c.block==b]
    t=x.groupby('group',sort=False).value.agg(n='size',ge40=lambda v:(v>=40).sum(),ge160=lambda v:(v>=160).sum(),minv='min',maxv='max',zeros=lambda v:(v==0).sum())
    t['GMT(0->5)']=x.groupby('group',sort=False).value.apply(lambda v: np.exp(np.log(np.where(v<=0,5,v)).mean())).round(1)
    print(b); print(t.to_string())
print()
print('=== S08-D body weight after immunisation (% of day 0): mean by day, min individual value, n')
x=bw[bw.block=='S08-D']
print(x.pivot_table(index='time',columns='group',values='value',aggfunc='mean')[['Vaccine','PSLN-212(Y)','CMP-204','PSLN-212','PSLN-344','PSLN-212/R848']].round(1).to_string())
print(x.pivot_table(index='time',columns='group',values='value',aggfunc='count')[['Vaccine','PSLN-212(Y)','CMP-204','PSLN-212','PSLN-344','PSLN-212/R848']].to_string())
print('min individual:',x.groupby('group').value.min().to_dict())
na=x.groupby(['group','animal']).value.min().groupby('group').agg(['mean','std','min'])
print(na.round(2).to_string())
# tests on per-animal nadir vs Vaccine
v=x.groupby(['group','animal']).value.min()
for g in ['PSLN-344','PSLN-212','CMP-204','PSLN-212/R848','PSLN-212(Y)']:
    print('  nadir',g,'vs Vaccine: Welch p=%.4f'%stats.ttest_ind(v[g],v['Vaccine'],equal_var=False).pvalue, ' vs PSLN-212: p=%.4f'%stats.ttest_ind(v[g],v['PSLN-212'],equal_var=False).pvalue)
d10=x[x.time==10]
print('day-10 weights:',{g:np.round(y.value.values,1).tolist() for g,y in d10.groupby('group')})
print()
print('=== S02-F GM-csf fold: PSLN-344 vs PSLN-212 per timepoint')
x=c[c.block=='S02-F']
for t,y in x.groupby('time',sort=False):
    a=y[y.group=='PSLN-344'].value; b=y[y.group=='PSLN-212'].value; s=y[y.group=='Sham'].value
    print(' ',t,'344 %.2f vs 212 %.2f (ratio %.1f) Welch p=%.2g ; 212 vs Sham p=%.2g'%(a.mean(),b.mean(),a.mean()/b.mean(),stats.ttest_ind(a,b,equal_var=False).pvalue,stats.ttest_ind(b,s,equal_var=False).pvalue))
print()
print('=== S07-A Ly6C+CCR2+ macrophages (x1e5): per-timepoint and AUC')
x=c[c.block=='S07-A']; x['time']=x.time.astype(float)
for t,y in x.groupby('time'):
    a=y[y.group=='PSLN-344'].value; b=y[y.group=='PSLN-212'].value
    print('  d%g: 212 %.2f±%.2f vs 344 %.2f±%.2f ; ratio %.1f ; Welch p=%.3g'%(t,b.mean(),b.std(ddof=1),a.mean(),a.std(ddof=1),b.mean()/a.mean(),stats.ttest_ind(a,b,equal_var=False).pvalue))
print()
print('=== S01-A: 72 h / 16 h persistence of Ifnb1 (ratio of group means)')
a=c[c.block=='S01-A 16h'].groupby('group',sort=False).value.mean(); b=c[c.block=='S01-A 72h'].groupby('group',sort=False).value.mean()
print((b/a*100).round(1).to_dict())
print('S01-A 16h: PSLN-344 vs PSLN-212 ratio %.2f ; PSLN-344(Y) vs PSLN-212(Y) ratio %.2f ; aged/young PSLN-212 %.2f ; CMP-204/PSLN-212 %.2f'%(a['PSLN-344']/a['PSLN-212'],a['PSLN-344(Y)']/a['PSLN-212(Y)'],a['PSLN-212']/a['PSLN-212(Y)'],a['CMP-204']/a['PSLN-212']))
x=c[c.block=='S01-A 16h']
print('  PSLN-344(Y) vs PSLN-212(Y) Welch p=%.3g'%stats.ttest_ind(x[x.group=='PSLN-344(Y)'].value,x[x.group=='PSLN-212(Y)'].value,equal_var=False).pvalue)
print('  PSLN-212/R848 vs PSLN-344 Welch p=%.3g'%stats.ttest_ind(x[x.group=='PSLN-212/R848'].value,x[x.group=='PSLN-344'].value,equal_var=False).pvalue)

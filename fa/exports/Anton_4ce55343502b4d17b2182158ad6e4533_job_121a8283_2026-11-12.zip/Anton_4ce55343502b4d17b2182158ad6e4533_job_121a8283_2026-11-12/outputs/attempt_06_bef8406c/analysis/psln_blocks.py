"""
Parser for adjuvant_program_dataset.xlsx -> tidy per-animal tables, one per block.
Every record keeps the sheet + cell address so that any number in the memo can be traced.
Run inside an env with openpyxl + pandas (e.g. `mm chem python ...`).
"""
import openpyxl, pandas as pd, numpy as np
from openpyxl.utils import get_column_letter as L, column_index_from_string as C

XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
_wb = openpyxl.load_workbook(XLSX, data_only=True)

def cell(sheet, col, row):
    return _wb[sheet].cell(row, C(col) if isinstance(col, str) else col).value

def cols(a, b):
    return [L(i) for i in range(C(a), C(b) + 1)]

# ---------------------------------------------------------------------------
# generic readers
# ---------------------------------------------------------------------------
def read_columns(sheet, block, hdr_row, first_row, last_row, col_a, col_b, names=None, meta=None):
    """groups in columns (header in hdr_row), replicates down rows"""
    out = []
    for j, c in enumerate(cols(col_a, col_b)):
        g = names[j] if names else cell(sheet, c, hdr_row)
        for r in range(first_row, last_row + 1):
            v = cell(sheet, c, r)
            if v is None: continue
            out.append(dict(block=block, sheet=sheet, group=str(g).strip(), value=float(v), cell=f'{c}{r}', **(meta or {})))
    return pd.DataFrame(out)

def read_rows(sheet, block, label_col, first_row, last_row, col_a, col_b, meta=None, labels=None):
    """groups in rows (label in label_col), replicates across columns"""
    out = []
    for i, r in enumerate(range(first_row, last_row + 1)):
        g = labels[i] if labels else cell(sheet, label_col, r)
        for c in cols(col_a, col_b):
            v = cell(sheet, c, r)
            if v is None: continue
            out.append(dict(block=block, sheet=sheet, group=str(g).strip(), value=float(v), cell=f'{c}{r}', **(meta or {})))
    return pd.DataFrame(out)

def read_timecourse(sheet, block, time_col, first_row, last_row, groups, meta=None, timename='time'):
    """groups = [(name, col_a, col_b), ...]; each row is a timepoint/dose; replicates across columns"""
    out = []
    for r in range(first_row, last_row + 1):
        t = cell(sheet, time_col, r)
        for (g, a, b) in groups:
            for k, c in enumerate(cols(a, b)):
                v = cell(sheet, c, r)
                if v is None: continue
                out.append(dict(block=block, sheet=sheet, group=g, **{timename: t}, animal=f'{g}#{k+1}', value=float(v), cell=f'{c}{r}', **(meta or {})))
    return pd.DataFrame(out)

def read_survival(sheet, block, day_col, first_row, last_row, group_cols, hdr_row):
    """one row per animal; day in day_col; exactly one group column holds 1 (event) or 0 (censored)"""
    out = []
    for r in range(first_row, last_row + 1):
        d = cell(sheet, day_col, r)
        hits = [(c, cell(sheet, c, r)) for c in group_cols if cell(sheet, c, r) is not None]
        if d is None and not hits: continue
        if len(hits) != 1:
            out.append(dict(block=block, sheet=sheet, group='??', day=d, event=np.nan, cell=f'{day_col}{r}', note=f'{len(hits)} group flags'))
            continue
        c, e = hits[0]
        out.append(dict(block=block, sheet=sheet, group=str(cell(sheet, c, hdr_row)).strip(), day=(np.nan if d is None else float(d)), event=int(e), cell=f'{day_col}{r}/{c}{r}', note=('day missing' if d is None else '')))
    return pd.DataFrame(out)

# ---------------------------------------------------------------------------
# block catalogue
# ---------------------------------------------------------------------------
B = {}       # continuous / per-animal blocks
SURV = {}    # time-to-event blocks
BW = {}      # body-weight blocks

# ---- S01
g8 = None
B['S01-A 16h'] = read_rows('S01', 'S01-A 16h', 'A', 3, 10, 'B', 'F')
B['S01-A 72h'] = read_rows('S01', 'S01-A 72h', 'G', 3, 10, 'H', 'L')
B['S01-B'] = read_rows('S01', 'S01-B', 'A', 14, 17, 'B', 'F')
B['S01-C'] = read_rows('S01', 'S01-C', 'A', 20, 21, 'B', 'E')
B['S01-D'] = read_timecourse('S01', 'S01-D', 'A', 24, 28, [('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U')])
B['S01-E'] = read_timecourse('S01', 'S01-E', 'A', 30, 34, [('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U'),('PSLN-344(Y)','V','Z')])
g5 = [('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U'),('PSLN-344(Y)','V','Z')]
def _row_groups(sheet, block, row, groups):
    out=[]
    for (g,a,b) in groups:
        for c in cols(a,b):
            v=cell(sheet,c,row)
            if v is None: continue
            out.append(dict(block=block, sheet=sheet, group=g, value=float(v), cell=f'{c}{row}'))
    return pd.DataFrame(out)
B['S01-F'] = _row_groups('S01','S01-F',36,g5)
B['S01-G'] = _row_groups('S01','S01-G',38,g5)

# ---- S02
B['S02-A'] = read_columns('S02','S02-A',2,3,7,'A','D')
B['S02-B'] = read_columns('S02','S02-B',2,3,7,'F','I')
B['S02-C'] = read_columns('S02','S02-C',2,3,7,'K','O')
B['S02-D CD40'] = read_columns('S02','S02-D CD40',9,10,14,'A','D')
B['S02-D CD86'] = read_columns('S02','S02-D CD86',9,10,14,'F','I')
B['S02-E'] = read_columns('S02','S02-E',9,10,14,'K','O')
B['S02-F'] = read_timecourse('S02','S02-F','A',17,19,[('PSLN-344','B','F'),('PSLN-212','G','K'),('Sham','L','P')])
B['S02-G'] = read_columns('S02','S02-G',21,22,26,'B','D')
B['S02-H'] = read_columns('S02','S02-H',29,30,34,'B','F')
B['S02-I'] = read_columns('S02','S02-I',29,30,34,'H','I')

# ---- S03
B['S03-A'] = read_columns('S03','S03-A',2,3,7,'A','E')
B['S03-B'] = read_columns('S03','S03-B',2,3,7,'G','I')
B['S03-C'] = read_columns('S03','S03-C',2,3,7,'K','O')
B['S03-D'] = read_columns('S03','S03-D',2,3,7,'Q','U')
B['S03-E'] = read_columns('S03','S03-E',9,10,14,'A','E')
B['S03-F'] = read_columns('S03','S03-F',9,10,14,'G','I')
B['S03-G'] = read_columns('S03','S03-G',9,10,14,'K','O')
B['S03-H'] = read_columns('S03','S03-H',9,10,14,'Q','U')
SURV['S03-I'] = read_survival('S03','S03-I','A',17,51,cols('B','F'),16)
SURV['S03-J'] = read_survival('S03','S03-J','G',17,46,cols('H','J'),16)
B['S03-K'] = read_columns('S03','S03-K',16,17,21,'L','O')
B['S03-L Aicda'] = read_rows('S03','S03-L Aicda','K',26,28,'L','N')
B['S03-L E47'] = read_rows('S03','S03-L E47','K',26,28,'O','Q')

# ---- S04
B['S04-A ICOS-'] = read_rows('S04','S04-A ICOS-','A',2,5,'B','F')
B['S04-A ICOS+'] = read_rows('S04','S04-A ICOS+','A',2,5,'G','K')
B['S04-B Foxp3'] = read_columns('S04','S04-B Foxp3',7,8,12,'A','D')
B['S04-B Tfh:Tfr'] = read_columns('S04','S04-B Tfh:Tfr',14,15,19,'A','D')
B['S04-C'] = read_columns('S04','S04-C',21,22,26,'A','D')
B['S04-D'] = read_columns('S04','S04-D',28,29,31,'A','D')

# ---- S05
gS05 = [('PSLN-212','B','C'),('PSLN-344','E','F'),('PSLN-212Y','H','I')]
B['S05-A'] = read_timecourse('S05','S05-A','A',3,5,gS05)
B['S05-B'] = read_timecourse('S05','S05-B','A',8,10,gS05)
B['S05-C'] = read_columns('S05','S05-C',12,13,15,'A','D')
for nm, h in [('S05-D',18),('S05-E',25),('S05-F',32),('S05-G',39),('S05-H',46),('S05-I',53)]:
    B[nm] = read_columns('S05',nm,h,h+1,h+5,'A','D')

# ---- S06 (all time-to-event)
SURV['S06-A'] = read_survival('S06','S06-A','A',3,30,cols('B','E'),2)
SURV['S06-B'] = read_survival('S06','S06-B','G',3,30,cols('H','K'),2)
SURV['S06-C'] = read_survival('S06','S06-C','M',3,30,cols('N','Q'),2)
SURV['S06-D'] = read_survival('S06','S06-D','A',34,61,cols('B','E'),33)
SURV['S06-E(r34)'] = read_survival('S06','S06-E(r34)','G',34,68,cols('H','L'),33)
SURV['S06-F(r34)'] = read_survival('S06','S06-F(r34)','M',34,68,cols('N','R'),33)
SURV['S06-G'] = read_survival('S06','S06-G','A',71,105,cols('B','F'),70)
SURV['S06-E(r71)'] = read_survival('S06','S06-E(r71)','G',71,105,cols('H','K'),70)
SURV['S06-F(r71)'] = read_survival('S06','S06-F(r71)','M',71,105,cols('N','Q'),70)

# ---- S07
B['S07-A'] = read_timecourse('S07','S07-A','A',3,7,[('PSLN-212','B','D'),('PSLN-344','E','G')])
B['S07-B mono'] = read_columns('S07','S07-B mono',9,10,14,'B','C')
B['S07-B Ly6C+Mac'] = read_columns('S07','S07-B Ly6C+Mac',9,10,14,'E','F')
B['S07-C'] = read_columns('S07','S07-C',15,16,20,'B','C', names=['col B: "Ly6C-CD206+ MΦ"','col C: "Ly6C-CD206+ MΦ"'])

# ---- S08
B['S08-A'] = read_timecourse('S08','S08-A','A',3,7,[('CMP-204','B','D'),('PSLN-212','E','G'),('PSLN-344','H','J'),('PSLN-344/R848','K','M')], timename='dose_ug')
B['S08-B'] = _row_groups('S08','S08-B',11,[('CMP-204','A','C'),('PSLN-212','D','F'),('PSLN-R848','G','I'),('PSLN-212/R848','J','L'),('PSLN-344','M','O')])
B['S08-C'] = read_columns('S08','S08-C',13,14,18,'A','D')
gS08D = [('PSLN-212(Y)','B','F'),('CMP-204','G','K'),('PSLN-212','L','P'),('PSLN-344','Q','U'),('PSLN-212/R848','V','Z'),('Vaccine','AA','AE')]
BW['S08-D'] = read_timecourse('S08','S08-D','A',21,26,gS08D)

# ---- S09
an = ['Ifnb1','Il6','Ccl2','Ccl3','Ccl5','Tnf','Il10']
gL = [('PBS','B','D'),('CMP-204','E','G'),('PSLN-212','H','J'),('PSLN-R848','K','M'),('PSLN-212/R848','N','P'),('PSLN-344','Q','S'),('PSLN-212(y)','T','V')]
gR = [('PBS','Y','AA'),('CMP-204','AB','AD'),('PSLN-212','AE','AG'),('PSLN-R848','AH','AJ'),('PSLN-212/R848','AK','AM'),('PSLN-344','AN','AP'),('PSLN-212(y)','AQ','AS')]
B['S09-A left'] = read_timecourse('S09','S09-A left','A',3,9,gL,timename='analyte')
B['S09-A right'] = read_timecourse('S09','S09-A right','X',3,9,gR,timename='analyte')
SURV['S09-B'] = read_survival('S09','S09-B','A',12,35,cols('B','D'),11)
SURV['S09-D'] = read_survival('S09','S09-D','A',39,62,cols('B','D'),38)
SURV['S09-F'] = read_survival('S09','S09-F','A',66,88,cols('B','D'),65)
gS09 = [('PSLN-212Y','G','N'),('Sham','O','V'),('PSLN-344Y','W','AD')]
BW['S09-C'] = read_timecourse('S09','S09-C','F',12,19,gS09)
BW['S09-E'] = read_timecourse('S09','S09-E','F',39,46,gS09)
BW['S09-G'] = read_timecourse('S09','S09-G','F',66,73,gS09)

# ---- S10
for a,(x,y) in {'Ifnb1':('A','D'),'Tnf':('F','I'),'Isg15':('K','N')}.items():
    B[f'S10-A {a}'] = read_columns('S10',f'S10-A {a}',2,3,7,x,y)

# ---- S11
gS11 = [('Vaccine','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U')]
B['S11-A'] = read_timecourse('S11','S11-A','A',3,7,gS11)
B['S11-B'] = read_timecourse('S11','S11-B','A',10,14,gS11)
B['S11-C'] = read_columns('S11','S11-C',16,17,21,'A','B')
B['S11-D'] = read_timecourse('S11','S11-D','A',24,28,gS11)
B['S11-E'] = read_columns('S11','S11-E',30,31,35,'A','D')

# ---- S12
B['S12-A'] = read_columns('S12','S12-A',2,3,5,'A','B')

# ---- S13
B['S13-A'] = read_columns('S13','S13-A',2,3,7,'A','C')
B['S13-B'] = read_columns('S13','S13-B',2,3,7,'E','G')
B['S13-C'] = read_columns('S13','S13-C',2,3,7,'I','K')
B['S13-D'] = read_columns('S13','S13-D',2,3,7,'M','O')
SURV['S13-E'] = read_survival('S13','S13-E','R',3,30,cols('S','V'),2)
BW['S13-F'] = read_timecourse('S13','S13-F','A',33,40,[('PSLN-212(Y)','B','H'),('Sham','I','O'),('PSLN-212','P','V'),('PSLN-344','W','AC'),('Naïve','AD','AJ')])
BW['S13-G'] = read_timecourse('S13','S13-G','A',43,50,[('PSLN-344','B','K'),('Sham','L','U'),('Naïve','V','AE')])
B['S13-H'] = read_columns('S13','S13-H',52,53,57,'A','D')
B['S13-I'] = read_columns('S13','S13-I',52,53,57,'F','J')
B['S13-J'] = read_columns('S13','S13-J',52,53,57,'L','P')

# ---- S14
B['S14-A H1N1'] = read_columns('S14','S14-A H1N1',2,3,7,'A','D')
B['S14-A H3N2'] = read_columns('S14','S14-A H3N2',2,3,7,'F','I')

# ---- S15
g4 = [('PSLN-212(Y)','B','H'),('Sham','I','O'),('PSLN-212','P','V'),('PSLN-344','W','AC')]
g5u = g4 + [('Untreated','AD','AJ')]
BW['S15-A'] = read_timecourse('S15','S15-A','A',3,10,g4)
BW['S15-B'] = read_timecourse('S15','S15-B','A',13,20,g4)
BW['S15-C'] = read_timecourse('S15','S15-C','A',23,30,g4)
BW['S15-D'] = read_timecourse('S15','S15-D','A',33,40,g4)
BW['S15-E'] = read_timecourse('S15','S15-E','A',43,50,g5u)
BW['S15-F'] = read_timecourse('S15','S15-F','A',53,60,g5u)
BW['S15-G'] = read_timecourse('S15','S15-G','A',63,70,g5u)
SURV['S15-H'] = read_survival('S15','S15-H','A',73,93,cols('B','D'),72)
BW['S15-I'] = read_timecourse('S15','S15-I','H',72,79,[('3d Vaccine','I','O'),('3d PSLN-344','P','V'),('3d Vaccine+PSLN-344','W','AC')])
gimp = [('Naïve+PSLN-212','I','O'),('Imprinting+PSLN-212','P','V'),('Naïve+PSLN-344','W','AC'),('Imprinting+PSLN-344','AD','AJ')]
BW['S15-J'] = read_timecourse('S15','S15-J','H',83,90,gimp)
BW['S15-K'] = read_timecourse('S15','S15-K','H',93,100,gimp)
SURV['S15-L'] = read_survival('S15','S15-L','A',103,130,cols('B','E'),102)
gstrain = [('PSLN-212(Y)','I','O'),('Sham','P','V'),('PSLN-212','W','AC'),('PSLN-344','AD','AJ')]
BW['S15-M'] = read_timecourse('S15','S15-M','H',103,110,gstrain)
SURV['S15-N'] = read_survival('S15','S15-N','A',134,161,cols('B','E'),133)
BW['S15-O'] = read_timecourse('S15','S15-O','H',134,141,gstrain)

# sanity: header text really matches the hard-coded group names for the wide blocks
def _check_headers():
    probs = []
    checks = [('S01',23,{'B':'Sham','G':'PSLN-212','L':'PSLN-344','Q':'PSLN-212(Y)'}),
              ('S01',29,{'B':'Sham','G':'PSLN-212','L':'PSLN-344','Q':'PSLN-212(Y)','V':'PSLN-344(Y)'}),
              ('S01',35,{'B':'Sham','G':'PSLN-212','L':'PSLN-344','Q':'PSLN-212(Y)','V':'PSLN-344(Y)'}),
              ('S01',37,{'B':'Sham','G':'PSLN-212','L':'PSLN-344','Q':'PSLN-212(Y)','V':'PSLN-344(Y)'}),
              ('S02',16,{'B':'PSLN-344','G':'PSLN-212','L':'Sham'}),
              ('S05',2,{'B':'PSLN-212','E':'PSLN-344','H':'PSLN-212Y'}),
              ('S05',7,{'B':'PSLN-212','E':'PSLN-344','H':'PSLN-212Y'}),
              ('S07',2,{'B':'PSLN-212','E':'PSLN-344'}),
              ('S08',2,{'B':'CMP-204','E':'PSLN-212','H':'PSLN-344','K':'PSLN-344/R848'}),
              ('S08',10,{'A':'CMP-204','D':'PSLN-212','G':'PSLN-R848','J':'PSLN-212/R848','M':'PSLN-344'}),
              ('S08',20,{'B':'PSLN-212(Y)','G':'CMP-204','L':'PSLN-212','Q':'PSLN-344','V':'PSLN-212/R848','AA':'Vaccine'}),
              ('S09',2,{'B':'PBS','E':'CMP-204','H':'PSLN-212','K':'PSLN-R848','N':'PSLN-212/R848','Q':'PSLN-344','T':'PSLN-212(y)','Y':'PBS','AB':'CMP-204','AE':'PSLN-212','AH':'PSLN-R848','AK':'PSLN-212/R848','AN':'PSLN-344','AQ':'PSLN-212(y)'}),
              ('S09',11,{'G':'PSLN-212Y','O':'Sham','W':'PSLN-344Y'}),('S09',38,{'G':'PSLN-212Y','O':'Sham','W':'PSLN-344Y'}),('S09',65,{'G':'PSLN-212Y','O':'Sham','W':'PSLN-344Y'}),
              ('S11',2,{'B':'Vaccine','G':'PSLN-212','L':'PSLN-344','Q':'PSLN-212(Y)'}),('S11',9,{'B':'Vaccine','G':'PSLN-212','L':'PSLN-344','Q':'PSLN-212(Y)'}),('S11',23,{'B':'Vaccine','G':'PSLN-212','L':'PSLN-344','Q':'PSLN-212(Y)'}),
              ('S13',32,{'B':'PSLN-212(Y)','I':'Sham','P':'PSLN-212','W':'PSLN-344','AD':'Naïve'}),
              ('S13',42,{'B':'PSLN-344','L':'Sham','V':'Naïve'}),
              ('S15',2,{'B':'PSLN-212(Y)','I':'Sham','P':'PSLN-212','W':'PSLN-344'}),('S15',12,{'B':'PSLN-212(Y)','I':'Sham','P':'PSLN-212','W':'PSLN-344'}),
              ('S15',22,{'B':'PSLN-212(Y)','I':'Sham','P':'PSLN-212','W':'PSLN-344'}),('S15',32,{'B':'PSLN-212(Y)','I':'Sham','P':'PSLN-212','W':'PSLN-344'}),
              ('S15',42,{'B':'PSLN-212(Y)','I':'Sham','P':'PSLN-212','W':'PSLN-344','AD':'Untreated'}),('S15',52,{'B':'PSLN-212(Y)','I':'Sham','P':'PSLN-212','W':'PSLN-344','AD':'Untreated'}),('S15',62,{'B':'PSLN-212(Y)','I':'Sham','P':'PSLN-212','W':'PSLN-344','AD':'Untreated'}),
              ('S15',71,{'I':'3d Vaccine','P':'3d PSLN-344','W':'3d Vaccine+PSLN-344'}),
              ('S15',82,{'I':'Naïve+PSLN-212','P':'Imprinting+PSLN-212','W':'Naïve+PSLN-344','AD':'Imprinting+PSLN-344'}),
              ('S15',92,{'I':'Naïve+PSLN-212','P':'Imprinting+PSLN-212','W':'Naïve+PSLN-344','AD':'Imprinting+PSLN-344'}),
              ('S15',102,{'I':'PSLN-212(Y)','P':'Sham','W':'PSLN-212','AD':'PSLN-344'}),('S15',133,{'I':'PSLN-212(Y)','P':'Sham','W':'PSLN-212','AD':'PSLN-344'}),
              ]
    for sh,row,d in checks:
        for c,exp in d.items():
            got = cell(sh,c,row)
            if got is None or str(got).strip()!=exp:
                probs.append((sh,row,c,exp,got))
    return probs

if __name__ == '__main__':
    print('header check problems:', _check_headers())
    tot = 0
    for k,v in {**B, **BW}.items():
        tot += len(v)
    for k,v in SURV.items(): tot += len(v)
    print('blocks: continuous', len(B), 'survival', len(SURV), 'bodyweight', len(BW), 'records', tot)

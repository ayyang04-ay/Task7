#!/usr/bin/env bash
# Rebuilds every table, figure, the workbook and the PDF from the source workbook.
# Needs two conda envs: `chem` (openpyxl + pandas) and `core` (pandas, scipy, statsmodels, lifelines, matplotlib, reportlab).
set -euo pipefail
cd "$(dirname "$0")"
mm() { micromamba run -n "$@"; }
mm chem python psln_blocks.py          # parser self-check (headers, block count)
mm chem python coverage_check.py       # every numeric cell is either parsed, an axis value, or the unlabelled S08 region
mm chem python export_tidy.py          # tidy/*.csv : one row per animal value, with sheet + cell address
mm core python survival_analysis.py   > logs_survival.txt 2>&1
mm core python pooled_survival.py     > logs_pooled.txt 2>&1
mm core python continuous_analysis.py > logs_continuous.txt 2>&1
mm core python bw_analysis.py         > logs_bodyweight.txt 2>&1
mm core python crosschecks.py         > logs_crosschecks.txt 2>&1
mm core python biomarker_screen.py    > logs_biomarker.txt 2>&1
mm core python misc_analysis.py       > logs_misc.txt 2>&1
mm core python cox_and_power.py       > logs_cox_power.txt 2>&1
mm core python inventory.py           > /dev/null
mm core python integrity_register.py  > /dev/null
mm core python next_studies.py        > /dev/null
mm core python ledger.py              > logs_ledger.txt 2>&1
mm core python make_figures.py        > /dev/null 2>&1
mm chem python build_workbook.py
mm core python build_pdf.py
echo "done"

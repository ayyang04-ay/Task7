import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from lifelines import KaplanMeierFitter
from scipy import optimize
plt.rcParams.update({'font.size':9,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':150,'savefig.dpi':200,'font.family':'DejaVu Sans'})
COL={'Sham':'#8c8c8c','PSLN-212':'#e08214','PSLN-344':'#1f5fa8','PSLN-212(Y)':'#4d9a4d','Untreated':'#b39ddb','CMP-204':'#b5651d','Naïve':'#444444','PSLN-344(Y)':'#7fb3e6','PSLN-212/R848':'#c0392b','PSLN-R848':'#e6a0a0','Vaccine':'#8c8c8c'}
LAB={'Sham':'Aged + sham (vaccine + empty liposome)','PSLN-212':'Aged + PSLN-212 (no Mn)','PSLN-344':'Aged + PSLN-344 (Mn)','PSLN-212(Y)':'Young + PSLN-212 (benchmark)','Untreated':'Aged, untreated, unchallenged'}
sv=pd.read_csv('tidy/survival_blocks.csv'); c=pd.read_csv('tidy/continuous_blocks.csv'); bw=pd.read_csv('tidy/bodyweight_blocks.csv')
OUT='/tmp/outputs/figures/'

# ------------------------------------------------------------------ Fig 1: survival matrix
exps=[('S03-J','wt H5N1 (matched rgH5N1 vaccine)','day 2',['Sham','PSLN-212','PSLN-344',None]),
      ('S06-B','H3N2 vaccine → PR8 H1N1','day 3',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S06-D','H1N1+H3N2 vaccine → rgH5N1','day 3',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S03-I','H1N1+H3N2 vaccine → CA09 H1N1 (matched, 10× mLD50)','day 14',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S06-A','H3N2 vaccine → PR8 H1N1','day 14',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S06-C','H1N1+H3N2 vaccine → rgH5N1  [table identical to S06-D]','day 14',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S06-E(r34)','H3N2 vaccine → PR8 H1N1','day 60',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S06-F(r34)','H1N1+H3N2 vaccine → rgH5N1','day 60',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S06-G','H1N1 vaccine → Perth H3N2','day 60',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S15-L','C57BL/6, 20 mo (challenge not documented)','not stated',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
      ('S15-N','Swiss Webster, 20 mo (challenge not documented)','not stated',['Sham','PSLN-212','PSLN-344','PSLN-212(Y)'])]
fig,ax=plt.subplots(figsize=(9.2,5.4))
cols=['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']
cmap=plt.get_cmap('RdYlGn')
for i,(b,desc,tim,gs) in enumerate(exps):
    y=len(exps)-i
    for j,g in enumerate(gs):
        if g is None: 
            ax.text(j,y,'not in block',ha='center',va='center',fontsize=7,color='#999999'); continue
        d=sv[(sv.block==b)&(sv.group==g)]; n=len(d); dead=int(d.event.sum()); s=(n-dead)/n
        ax.add_patch(plt.Rectangle((j-0.46,y-0.42),0.92,0.84,color=cmap(0.12+0.76*s),ec='white'))
        ax.text(j,y,f'{n-dead}/{n}',ha='center',va='center',fontsize=9,fontweight='bold' if g=='PSLN-344' else 'normal',color='black')
    ax.text(-0.62,y,f'{b.replace("(r34)","")}  {desc}',ha='right',va='center',fontsize=7.6)
    ax.text(-0.56,y,'',ha='right')
    ax.text(4.0-0.45,y,tim,ha='left',va='center',fontsize=7.6,color='#333333')
# pooled row
y=0
tot={'Sham':(0,56),'PSLN-212':(6,56),'PSLN-344':(46,56),'PSLN-212(Y)':(56,56)}
for j,g in enumerate(cols):
    a,n=tot[g]; ax.add_patch(plt.Rectangle((j-0.46,y-0.42),0.92,0.84,color=cmap(0.12+0.76*a/n),ec='black',lw=1.0))
    ax.text(j,y,f'{a}/{n}\n({100*a/n:.0f}%)',ha='center',va='center',fontsize=8.5,fontweight='bold')
ax.text(-0.62,y,'Pooled, aged BALB/c, 8 standard blocks (S03-I, S06-A…G)',ha='right',va='center',fontsize=7.8,fontweight='bold')
ax.set_xlim(-0.5,4.2); ax.set_ylim(-0.6,len(exps)+1.1)
for j,g in enumerate(cols):
    ax.text(j,len(exps)+0.62,{'Sham':'Aged\nsham','PSLN-212':'Aged\nPSLN-212','PSLN-344':'Aged\nPSLN-344','PSLN-212(Y)':'Young\nPSLN-212'}[g],ha='center',va='bottom',fontsize=8.5,fontweight='bold',color=COL[g])
ax.text(3.55,len(exps)+0.62,'Challenge,\ndays after\nvaccination',ha='left',va='bottom',fontsize=7.5)
ax.axis('off')
ax.set_title('Survivors / animals at end of observation, every challenge experiment in ≥20-month-old animals\n(counts of rows with event flag 0; source block in row label)',fontsize=9.5,loc='left',x=-0.95)
fig.subplots_adjust(left=0.50,right=0.98,top=0.84,bottom=0.03)
fig.savefig(OUT+'fig1_survival_matrix.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 2: pooled KM by challenge timing
sets=[('Challenge 3 d after vaccination\n(S06-B, S06-D)',['S06-B','S06-D']),('Challenge 14 d after vaccination\n(S03-I, S06-A, S06-C)',['S03-I','S06-A','S06-C']),('Challenge 60 d after vaccination\n(S06-E, S06-F, S06-G)',['S06-E(r34)','S06-F(r34)','S06-G'])]
fig,axs=plt.subplots(1,3,figsize=(10.5,3.5),sharey=True)
for ax,(ttl,bl) in zip(axs,sets):
    for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)','Untreated']:
        d=sv[sv.block.isin(bl)&(sv.group==g)]
        if len(d)==0: continue
        km=KaplanMeierFitter().fit(d.day,d.event)
        sf=km.survival_function_
        t=np.r_[sf.index.values,14]; s=np.r_[sf.iloc[:,0].values,sf.iloc[-1,0]]
        off={'Sham':0,'PSLN-212':0,'PSLN-344':0,'PSLN-212(Y)':0.012,'Untreated':-0.012}[g]
        ax.step(t,100*(s+off),where='post',color=COL[g],lw=2.2 if g=='PSLN-344' else 1.5,ls='--' if g=='Untreated' else '-',label=f"{LAB[g]}")
        n=len(d); a=n-int(d.event.sum())
        ax.text(14.2,100*(s[-1]+off),f'{a}/{n}',color=COL[g],va='center',fontsize=8,fontweight='bold')
    ax.set_title(ttl,fontsize=9); ax.set_xlabel('Days after challenge'); ax.set_xlim(0,16.5); ax.set_ylim(-3,106); ax.set_xticks([0,2,4,6,8,10,12,14])
axs[0].set_ylabel('Surviving (%), Kaplan–Meier\n(animals pooled over blocks)')
h,l=axs[2].get_legend_handles_labels(); fig.legend(h,l,loc='lower center',ncol=3,frameon=False,fontsize=8,bbox_to_anchor=(0.5,-0.02))
fig.subplots_adjust(bottom=0.27,top=0.86,left=0.07,right=0.97,wspace=0.12)
fig.savefig(OUT+'fig2_km_by_challenge_timing.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 3: restoration cascade
RI=pd.read_csv('results_restoration_index.csv'); RI['sub']=RI['sub'].fillna('').astype(str)
steps=[('S01-A 16h','','Ifnb1 mRNA, lung, 16 h','1 Sensing'),
       ('S01-D','4','Ly6C+ monocytes, lung, d4','2 Recruitment'),
       ('S01-E','4','CD11b+ DC, lung, d4','3 DC'),
       ('S02-A','','CCR7+ migratory CD11b+ DC, lung, 72 h','3 DC'),
       ('S02-C','','Antigen (OVA)+ DC, MLN, 36 h','3 DC'),
       ('S02-D CD40','','CD40+ of MLN CD11b+ DC, d3','3 DC'),
       ('S02-D CD86','','CD86+ of MLN CD11b+ DC, d3','3 DC'),
       ('S02-E','','OT-I cross-priming by MLN DC','3 DC'),
       ('S05-D','','Ki-67+ CD8 T, lung, d3','4 CD8 T'),
       ('S05-E','','GZMB+ CD8 T, lung, d3','4 CD8 T'),
       ('S05-F','','IFN-γ+ CD8 T vs rgH5N1, MLN, d14','4 CD8 T'),
       ('S05-G','','IFN-γ+ CD8 T vs rgH5N1, MLN, d60','4 CD8 T'),
       ('S05-I','','Lung resident-memory CD8 T, d25','4 CD8 T'),
       ('S04-A ICOS+','','ICOS+ Tfh, MLN, d7','5 B-cell help'),
       ('S04-B Foxp3','','Tfr (Foxp3+ of CXCR5+), MLN, d7 ↓','5 B-cell help'),
       ('S04-C','','Tfr, MLN, d30 ↓','5 B-cell help'),
       ('S03-K','','GC B cells, MLN, d7','5 B-cell help'),
       ('S03-A','','Serum IgG anti-H1N1, d14 (log)','6 Antibody'),
       ('S03-C','','Serum HAI anti-H1N1, d14 (log)','6 Antibody'),
       ('S03-G','','Serum HAI anti-H3N2, d14 (log)','6 Antibody'),
       ('S03-D','','Neutralising titre anti-H1N1, d14 (log)','6 Antibody'),
       ('S13-I','','Serum IgG anti-H1N1, d28 post-boost (log)','6 Antibody')]
cc={'1 Sensing':'#1f5fa8','2 Recruitment':'#3b8bc4','3 DC':'#5aa469','4 CD8 T':'#c0392b','5 B-cell help':'#8e6bbf','6 Antibody':'#b8860b'}
fig,ax=plt.subplots(figsize=(8.6,6.6))
ys=[]
for i,(b,s,lab,st) in enumerate(steps):
    r=RI[(RI.block==b)&(RI['sub']==s)].iloc[0]; y=len(steps)-i; ys.append(y)
    ax.barh(y,100*r.RI,color=cc[st],height=0.68)
    def fmt(v,scale): 
        v=10**v if scale=='log10' else v
        return f'{v:,.0f}' if v>=100 else (f'{v:.1f}' if v>=10 else f'{v:.2g}')
    ax.text(106,y,f"{fmt(r.aged_212,r.scale)} → {fmt(r.aged_344,r.scale)}  (young {fmt(r.young_212,r.scale)})",va='center',fontsize=7.3,color='#222222')
    ax.text(min(100*r.RI,98)-1.5,y,f"{100*r.RI:.0f}%",va='center',ha='right',fontsize=7,color='white',fontweight='bold')
    ax.text(-3,y,f'{lab}  [{b}]',ha='right',va='center',fontsize=7.8)
ax.axvline(100,color='#4d9a4d',lw=1.2,ls='--'); ax.axvline(0,color='#e08214',lw=1.2)
ax.text(99,len(steps)+0.9,'young + PSLN-212\n= 100 %',ha='right',va='bottom',fontsize=7.5,color='#4d9a4d'); ax.text(1,len(steps)+0.9,'aged + PSLN-212\n= 0 %',ha='left',va='bottom',fontsize=7.5,color='#e08214')
ax.set_xlim(0,160); ax.set_ylim(0.3,len(steps)+0.7); ax.set_yticks([]); ax.spines['left'].set_visible(False)
ax.text(106,len(steps)+0.9,'group means (GMT for titres):\naged-212 → aged-344 (young-212)',ha='left',va='bottom',fontsize=7.3,color='#222222')
ax.set_xticks([0,25,50,75,100]); ax.set_xlabel('Share of the young-vs-aged gap closed by PSLN-344 in aged animals (%)',fontsize=8,loc='left')
fig.legend(handles=[Patch(color=v,label=k[2:]) for k,v in cc.items()],loc='lower center',ncol=6,frameon=False,fontsize=7.5,bbox_to_anchor=(0.6,0.0))
fig.subplots_adjust(left=0.40,right=0.99,top=0.91,bottom=0.12)
fig.savefig(OUT+'fig4_restoration_cascade.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 4: Ifnb1
fig,axs=plt.subplots(1,2,figsize=(10.6,3.9))
ax=axs[0]; d=c[c.block=='S01-A 16h']; order=['Sham','CMP-204','PSLN-R848','PSLN-212','PSLN-212/R848','PSLN-344','PSLN-212(Y)','PSLN-344(Y)']
for i,g in enumerate(order):
    v=d[d.group==g].value.values
    ax.bar(i,v.mean(),color=COL.get(g,'#999999'),alpha=0.85,width=0.7); ax.errorbar(i,v.mean(),yerr=v.std(ddof=1),color='k',capsize=3,lw=1)
    ax.scatter(np.full(len(v),i)+np.linspace(-0.18,0.18,len(v)),v,color='k',s=9,zorder=3)
    ax.text(i,max(v.max(),v.mean()+v.std(ddof=1))+1.5,f'{v.mean():.1f}',ha='center',fontsize=8,fontweight='bold')
ax.set_xticks(range(len(order))); ax.set_xticklabels(['Sham','CMP-\n204','PSLN-\nR848','PSLN-\n212','PSLN-212\n/R848','PSLN-\n344','PSLN-212\nyoung','PSLN-344\nyoung'],fontsize=7.5)
ax.axvspan(5.5,7.5,color='#eeeeee',zorder=0); ax.set_ylim(0,68); ax.text(6.5,65,'young animals',ha='center',fontsize=7.5,color='#555555'); ax.text(2.5,65,'aged animals',ha='center',fontsize=7.5,color='#555555'); ax.set_ylabel('Lung Ifnb1, fold over untreated (linear)'); ax.set_title('A  Ifnb1 16 h after 20 µg i.n. (S01-A; mean ± SD, n = 5)',fontsize=9,loc='left')
ax=axs[1]; d=c[c.block=='S08-A']
def hill(x,emax,ed50,h): return 1+(emax-1)*x**h/(ed50**h+x**h)
xx=np.linspace(0.8,45,200)
for g,cl in [('CMP-204',COL['CMP-204']),('PSLN-212',COL['PSLN-212']),('PSLN-344',COL['PSLN-344'])]:
    x=d[d.group==g]; m=x.groupby('dose_ug').value.agg(['mean','std'])
    p,_=optimize.curve_fit(hill,x.dose_ug.values,x.value.values,p0=[x.value.max(),10,2],bounds=([1,0.5,0.5],[500,200,8]),maxfev=20000)
    ax.errorbar(m.index,m['mean'],yerr=m['std'],fmt='o',color=cl,capsize=3,ms=5); ax.plot(xx,hill(xx,*p),color=cl,lw=1.6,label=f'{g}: Emax {p[0]:.0f}×, ED50 {p[1]:.0f} µg')
ax.set_xscale('log'); ax.set_xticks([1,5,10,20,40]); ax.set_xticklabels(['1','5','10','20','40']); ax.set_xlabel('Adjuvant dose (µg per animal, i.n.)'); ax.set_ylabel('Lung Ifnb1, fold over untreated')
ax.axvline(20,color='#999999',ls=':',lw=1); ax.text(20.8,2,'dose used in every\nefficacy study',fontsize=7,color='#555555')
ax.legend(frameon=False,fontsize=7.8,loc='upper left'); ax.set_title('B  Dose–response at 16 h (S08-A; mean ± SD, n = 3; Emax fit)',fontsize=9,loc='left')
fig.tight_layout(); fig.savefig(OUT+'fig3_ifnb1.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 5: tolerability
fig,axs=plt.subplots(1,3,figsize=(12.2,3.9),gridspec_kw={'width_ratios':[1.05,1.5,0.9]})
ax=axs[0]; d=bw[bw.block=='S08-D']
for g in ['Vaccine','PSLN-212(Y)','CMP-204','PSLN-212','PSLN-344','PSLN-212/R848']:
    m=d[d.group==g].groupby('time').value.agg(['mean','std','count'])
    ax.errorbar(m.index,m['mean'],yerr=m['std'],color=COL.get(g,'#999'),marker='o',ms=3.5,lw=2.2 if g=='PSLN-344' else 1.3,capsize=2,label=g+(' (n=4 at d10)' if g=='PSLN-212/R848' else ''))
ax.axhline(100,color='#bbbbbb',lw=0.8); ax.set_xlabel('Days after intranasal immunisation'); ax.set_ylabel('Body weight (% of day 0), mean ± SD'); ax.legend(frameon=False,fontsize=6.8,loc='lower left')
ax.set_title('A  Reactogenicity by weight (S08-D, n = 5)',fontsize=9,loc='left'); ax.set_ylim(82,104)
ax=axs[1]
an=['Ifnb1','Il6','Ccl2','Ccl3','Ccl5','Tnf','Il10']; gs=['PSLN-212','PSLN-344','PSLN-212/R848','PSLN-212(y)']
mats=[]
for side in ['S09-A left','S09-A right']:
    x=c[c.block==side]; mats.append(x.groupby(['analyte','group']).value.mean().unstack().loc[an,gs].values)
M=np.hstack([mats[0],np.full((len(an),1),np.nan),mats[1]])
im=ax.imshow(M,cmap='RdBu_r',vmin=-3.2,vmax=3.2,aspect='auto')
for i in range(M.shape[0]):
    for j in range(M.shape[1]):
        if not np.isnan(M[i,j]):
            f=10**M[i,j]; ax.text(j,i,(f'{f:.0f}×' if f>=10 else f'{f:.1f}×'),ha='center',va='center',fontsize=6.8,color='white' if abs(M[i,j])>1.9 else 'black')
ax.set_yticks(range(len(an))); ax.set_yticklabels(an,fontsize=8,style='italic')
ax.set_xticks(list(range(4))+list(range(5,9))); ax.set_xticklabels(['aged\n212','aged\n344','aged\n212/R848','young\n212']*2,fontsize=7)
ax.text(1.5,-0.85,'left panel (label “16 h”)',ha='center',fontsize=8); ax.text(6.5,-0.85,'right panel (label “16 h”;\nIfnb1 row matches 72 h data)',ha='center',fontsize=7.5)
ax.spines['left'].set_visible(False); ax.spines['bottom'].set_visible(False); ax.tick_params(length=0)
ax.set_title('B  Lung cytokine mRNA, geometric-mean fold over PBS (S09-A, n = 3)',fontsize=9,loc='left',y=1.13)
ax=axs[2]
for k,a in enumerate(['Ifnb1','Tnf','Isg15']):
    x=c[c.block==f'S10-A {a}']
    for j,g in enumerate(['PBS','Sham','PSLN-344','CT']):
        v=x[x.group==g].value.values; pos=k*5+j
        ax.bar(pos,v.mean(),color={'PBS':'#cccccc','Sham':'#8c8c8c','PSLN-344':COL['PSLN-344'],'CT':'#c0392b'}[g],width=0.85); ax.errorbar(pos,v.mean(),yerr=v.std(ddof=1),color='k',capsize=2,lw=0.8)
ax.set_xticks([1.5,6.5,11.5]); ax.set_xticklabels(['Ifnb1','Tnf','Isg15'],style='italic'); ax.set_ylabel('CNS mRNA, fold over untreated (mean ± SD)')
ax.legend(handles=[Patch(color='#cccccc',label='PBS'),Patch(color='#8c8c8c',label='Sham (vaccine)'),Patch(color=COL['PSLN-344'],label='Vaccine + PSLN-344'),Patch(color='#c0392b',label='Vaccine + cholera toxin')],frameon=False,fontsize=6.8,loc='upper right')
ax.set_title('C  CNS transcripts, 36 h (S10-A, n = 5)',fontsize=9,loc='left')
fig.tight_layout(); fig.savefig(OUT+'fig5_tolerability.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 6: antibody vs survival
fig,axs=plt.subplots(1,2,figsize=(10.6,4.3))
order=['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)']
surv={'Sham':'0/7','CMP-204':'3/7','PSLN-212':'0/7*','PSLN-344':'7/7','PSLN-212(Y)':'7/7'}
for ax,(b,ttl) in zip(axs,[('S03-C','A  HAI anti-CA09 H1N1, day 14 (S03-C)'),('S03-G','B  HAI anti-Aichi H3N2, day 14 (S03-G)')]):
    d=c[c.block==b]
    for i,g in enumerate(order):
        v=np.where(d[d.group==g].value.values<=0,5,d[d.group==g].value.values)
        ax.scatter(np.full(len(v),i)+np.linspace(-0.2,0.2,len(v)),v,color=COL[g],s=28,zorder=3,edgecolor='k',lw=0.4)
        gmt=np.exp(np.log(v).mean()); ax.plot([i-0.3,i+0.3],[gmt,gmt],color='k',lw=1.5); ax.text(i,v.max()*1.5,f'GMT {gmt:.0f}',ha='center',fontsize=7.5)
        if b=='S03-C': ax.text(i,2.6,f'survival\n{surv[g]}',ha='center',fontsize=7.5,color=COL[g],fontweight='bold')
    ax.set_yscale('log',base=2); ax.set_yticks([5,10,20,40,80,160,320,640]); ax.set_yticklabels(['<10','10','20','40','80','160','320','640'])
    ax.axhline(40,color='#c0392b',ls='--',lw=1); ax.text(4.45,43,'1:40',color='#c0392b',fontsize=7.5,ha='right',va='bottom')
    ax.set_ylim(1.9,1500); ax.set_xticks(range(5)); ax.set_xticklabels(['Aged\nsham','Aged\nCMP-204','Aged\nPSLN-212','Aged\nPSLN-344','Young\nPSLN-212'],fontsize=7.5); ax.set_title(ttl,fontsize=9,loc='left'); ax.set_ylabel('Reciprocal HAI titre (per animal; bar = GMT)')
fig.tight_layout(rect=(0,0.06,1,1))
fig.text(0.02,0.015,'Survival (panel A) = block S03-I: homologous 10× mLD50 CA09 challenge 14 d after vaccination, separate animals (n = 7).   * the paired body-weight block S13-F implies 3/7 for aged PSLN-212.',fontsize=7.3,color='#333333')
fig.savefig(OUT+'fig7_hai_vs_survival.png'); plt.close(fig)

# ------------------------------------------------------------------ Fig 7: day-60 body-weight trajectories
fig,axs=plt.subplots(1,3,figsize=(10.5,3.5),sharey=True)
A=pd.read_csv('results_bw_per_animal.csv')
for ax,(b,ttl) in zip(axs,[('S15-E','H3N2 vaccine → PR8, day 60 (S15-E)'),('S15-F','Bivalent → rgH5N1, day 60 (S15-F)'),('S15-G','H1N1 vaccine → Perth H3N2, day 60 (S15-G)')]):
    d=bw[bw.block==b]
    for g in ['PSLN-344','Untreated']:
        for a,y in d[d.group==g].groupby('animal'):
            st=A[(A.block==b)&(A.animal==a)].status.iloc[0]; y=y.sort_values('time')
            dead=st!='alive'
            ax.plot(y.time,y.value,color=COL[g],lw=2.0 if dead else 0.9,alpha=1 if dead else 0.55,ls='-' if g=='PSLN-344' else '--',marker='x' if dead else None,ms=4)
    ax.set_title(ttl,fontsize=8.5); ax.set_xlabel('Days after challenge'); ax.axhline(100,color='#cccccc',lw=0.7)
axs[0].set_ylabel('Body weight (% of day 0)\none line per animal')
from matplotlib.lines import Line2D
fig.legend(handles=[Line2D([],[],color=COL['PSLN-344'],lw=0.9,label='Aged PSLN-344, survivor'),Line2D([],[],color=COL['PSLN-344'],lw=2,marker='x',label='Aged PSLN-344, value carried forward (died)'),Line2D([],[],color=COL['Untreated'],lw=0.9,ls='--',label='Untreated, unchallenged, survivor'),Line2D([],[],color=COL['Untreated'],lw=2,ls='--',marker='x',label='Untreated, unchallenged, carried forward (died)')],loc='lower center',ncol=2,frameon=False,fontsize=7.8,bbox_to_anchor=(0.5,-0.03))
fig.subplots_adjust(bottom=0.30,top=0.90,left=0.07,right=0.98,wspace=0.08)
fig.savefig(OUT+'fig6_day60_weights.png'); plt.close(fig)
print('done')

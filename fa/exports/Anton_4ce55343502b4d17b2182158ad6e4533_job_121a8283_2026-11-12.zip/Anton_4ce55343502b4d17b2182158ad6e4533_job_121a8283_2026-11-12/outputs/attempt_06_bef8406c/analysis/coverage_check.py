import openpyxl, re
from openpyxl.utils import get_column_letter as L
import psln_blocks as P
wb = openpyxl.load_workbook(P.XLSX, data_only=True)
used = set()
for d in (P.B, P.BW):
    for k,v in d.items():
        for sh,c in zip(v['sheet'], v['cell']): used.add((sh,c))
for k,v in P.SURV.items():
    for sh,c in zip(v['sheet'], v['cell']):
        for cc in c.split('/'): used.add((sh,cc))
unused = {}
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value,(int,float)) and (ws.title,c.coordinate) not in used:
                unused.setdefault(ws.title,[]).append((c.coordinate,c.value))
for sh,lst in unused.items():
    print(sh, len(lst))
    # summarise by column
    bycol={}
    for coord,v in lst:
        col=re.match(r'[A-Z]+',coord).group(0); bycol.setdefault(col,[]).append((coord,v))
    for col,items in bycol.items():
        print('   ',col, [f'{a}={b}' for a,b in items][:60])

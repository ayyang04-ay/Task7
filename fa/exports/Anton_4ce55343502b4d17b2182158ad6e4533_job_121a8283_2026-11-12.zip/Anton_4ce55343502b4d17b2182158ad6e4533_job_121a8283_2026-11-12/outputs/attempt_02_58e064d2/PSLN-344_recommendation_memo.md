# PSLN-344: portfolio recommendation

*Basis: `adjuvant_program_dataset.xlsx` (15 sheets), read against `adjuvant_program_annotation.pdf`.*

## 1. Recommendation

**Advance PSLN-344, as a gated go.** Approve the next stage: a 9 to 12 month pre-IND package with six pass/fail gates. Hold IND-enabling spend (GLP toxicology, GMP manufacture) until those gates read out.

IDs in square brackets point to the evidence ledger in Appendix A, which gives the cells and the reduction behind each number.

The case in brief:

1. PSLN-344 is the only preparation in the file that protects most aged animals. Across nine lethal-challenge experiments, one intranasal dose given with vaccine left 51 of 63 aged mice alive (81%). The manganese-free parent PSLN-212 left 6 of 63 (10%), and the empty-liposome control 0 of 63 [E11].
2. The parent works in young animals (62 of 63 alive) and fails in aged ones, so without PSLN-344 the platform has no older-adult product [E11].
3. The advantage appears in every one of the nine experiments. It survives each way of handling the record conflicts I found: on the least favourable reading it is 80% against 17% [E1–E9, E11-s4].

Why gated rather than unconditional:

- **Records.** Several blocks that carry headline claims contradict other blocks in the same workbook (section 3.1).
- **Safety.** The evidence is one 10-day weight study, one lung cytokine panel and one CNS time point. There is nothing on manganese itself (section 3.4).
- **Translation.** Nothing in the file tests what a clinical programme would depend on: a licensed comparator, a manganese-only control, a second species, male animals, a split-antigen vaccine, or a delivery route that reaches the human lung (section 3.5).

The six gates, detailed in section 6:

0. The record conflicts are reconciled against source records. This takes 2 to 4 weeks and comes before any new spend.
1. The benefit repeats in a blinded study and needs manganese and the STING agonist together.
2. PSLN-344 at least matches a licensed-type vaccine for older adults.
3. Manganese clears, and lung and CNS inflammation resolve.
4. The particle activates human STING in cells from older donors.
5. Efficacy holds with a delivery route and an antigen format that can be used in people.

**How to check a number.** Every number in this memo is followed by a ledger ID in square brackets, for example [E2]. Appendix A (also `evidence_ledger.csv`) gives the block, the exact cells and the reduction for each ID. An ID cited without its letter covers all its lettered rows: [E11] means E11a to E11d. Unless a line says otherwise:

- survival is the number of animals with status 0 at the end of observation divided by the animals in the arm;
- percentages and fold-changes are arithmetic means of the per-animal values;
- titres are geometric means (GMT);
- p-values use the methods named in the annotation: log-rank for time to event, one-way ANOVA with Tukey's test for multi-arm blocks, Student's t for two-arm blocks.

"Aged" means 20 months or older and "young" means 7 to 8 weeks, as in the annotation. "Empty-liposome control" is the arm the workbook calls Sham (vaccine plus empty liposome). I treated the workbook as ground truth. Where two blocks contradict each other, both cannot be true, so I show both readings (Appendix B).

## 2. The case for advancing

![Figure 1. Survival of aged mice after lethal influenza challenge. A: each experiment. B: the nine experiments pooled.](figures/fig1_survival_aged.png)

**2.1 It closes an age gap that the parent formulation cannot.**

- PSLN-212 protects young mice (62/63, 98%) but not aged mice (6/63, 10%) [E11].
- PSLN-344 in aged mice: 51/63 alive, 81% (exact 95% CI 69–90%) [E11].
- PSLN-344 beat PSLN-212 in all nine experiments, by 4 to 7 more survivors out of 7 [E1–E9]. The nine experiments do not differ from one another beyond chance (p = 0.64 for PSLN-344) [E12e].
- Pooled and stratified by experiment, the hazard ratio for death is 0.10 (95% CI 0.06–0.17; log-rank p = 1.6 × 10⁻¹⁷) [E12a].
- The result does not depend on my handling choices:
    - counting the duplicated block S06-D gives 58/70 against 8/70 [E11-s1];
    - relabelling the disputed S03-I comparator gives 51/63 against 9/63 [E11-s2];
    - reading deaths from the body-weight blocks instead gives 53/63 against 9/63 [E11-s3];
    - taking, in every experiment, the record least favourable to PSLN-344 and most favourable to PSLN-212 gives 56/70 (80%) against 12/70 (17%) [E11-s4].

**2.2 The protection is broad, fast, and holds in pre-immune animals.**

| Setting (aged mice unless stated) | Vaccine + PSLN-344 | Vaccine + PSLN-212 | Vaccine, no active adjuvant | Ledger |
|:-----------------------------------------|:---------|:---------|:---------|:------|
| Matched strain, 10× LD50 CA09 H1N1, day 14 | 7/7 | 0/7 (3/7 on the alternative reading, section 3.1) | 0/7 | E1, E11-s2 |
| H3N2 vaccine, H1N1 challenge, day 14 | 6/7 | 1/7 | 0/7 | E2 |
| H1N1+H3N2 vaccine, rgH5N1 challenge, day 14 | 7/7 | 2/7 | 0/7 | E4 |
| Challenge 3 days after the dose (two experiments) | 11/14 | 0/7 (one experiment) | 0/14 | E25 |
| Wild-type H5N1, 2 days after the dose (age not stated) | 10/10 | 3/10 | 1/10 | E18 |
| Challenge 60 days after the dose (three experiments) | 14/21 | 1/21 | 0/21 | E15c |
| Aged C57BL/6 | 6/7 | 0/7 | 0/7 | E8 |
| Aged outbred Swiss Webster | 6/7 | 2/7 | 0/7 | E9 |
| 14-month mice, previously infected with H1N1 | 12/14 | 4/14 | not run | E20 |
| 14-month mice, not previously infected | 12/14 | 0/14 | not run | E20 |

The last column is vaccine plus empty liposome, except in one of the two day-3 experiments (S15-H), where it is vaccine alone. In the wild-type H5N1 experiment (S03-J), one PSLN-344 animal has no day recorded and the block label says n = 9 [E18].

**2.3 The immune response is rebuilt along the whole chain, not at one point.** Across 26 readouts, PSLN-344 brought aged mice to a median 73% of the young PSLN-212 response. PSLN-212 in aged mice reached a median 21% [I26; Figure 2]. Examples:

- Haemagglutination-inhibition (HAI) titre against the CA09 H1N1 strain: GMT 368 with PSLN-344, 46 with PSLN-212, 485 in young [I2].
- Neutralising titre against CA09: 3,840, 418 and 6,686 [I3].
- CD8 T cells that make IFN-γ when restimulated with H5N1, a subtype not in the vaccine: 6.4%, 1.5% and 9.2% at day 14 [I14], and 9.9%, 3.0% and 14.4% at day 60 [I15].
- Germinal-centre B cells in the lung-draining lymph node at day 7: 6.5%, 2.3% and 9.8% [I7].
- The antibody response shifts to the IgG2a-dominant type seen in young mice. The IgG2a:IgG1 ratio against CA09 is 2.1, 0.58 and 3.0. These are recomputed values; the printed block is mislabelled (section 3.1) [I24].

![Figure 2. Response in aged mice as a percentage of the young PSLN-212 response, for 26 readouts.](figures/fig2_restoration_index.png)

**2.4 More dose, a different agonist, or a second agonist does not reproduce it.**

- *More PSLN-212.* Manganese raises the ceiling of the lung IFN-β response, not just the potency. The fitted maximum is 58.7-fold for PSLN-344 and 16.6-fold for PSLN-212, with similar half-maximal doses (13.3 and 10.8 µg). PSLN-344 at 10 µg (21.1-fold) already exceeds PSLN-212 at 40 µg (14.9-fold) [D1, D2; Figure 3A].
- *More drug per particle.* Encapsulation is no higher: 54.8% for PSLN-344, 59.6% for PSLN-212 [D3].
- *cGAMP instead of CDN-1807 (CMP-204).* Weaker in aged mice: lung Ifnb1 7.8-fold against 37.1-fold [M1], HAI GMT 23 against 368 [I2].
- *Adding the TLR7/8 agonist R848 (PSLN-212/R848).* Less IFN-β than PSLN-344 (24.3-fold against 37.1-fold) [M1] and poorly tolerated: lung Tnf 202-fold and Il10 179-fold at 16 h [S6], and body weight still falling at day 10 (90.6% of baseline) [S2].

![Figure 3. A: lung IFN-β dose-response. B: lung IFN-β in aged and young mice. C: vaccine alone, adjuvant alone, and the combination.](figures/fig3_mechanism.png)

**2.5 The first look at tolerability is acceptable.**

- Weight after dosing fell to a nadir of 96.4% of baseline with PSLN-344, against 98.2% with vaccine alone (Tukey p = 0.86; unadjusted t-test p = 0.06), and was back to 99.8% by day 10 [S1, S2].
- CNS transcripts 36 h after dosing were 1.3-fold (Ifnb1), 1.6-fold (Tnf) and 1.1-fold (Isg15) of the PBS control, none different from PBS by Tukey's test (p ≥ 0.54). The positive control, cholera toxin, gave 5.5-, 3.5- and 2.7-fold [S7; Figure 4].

## 3. What the committee will push on

**3.1 The record contradicts itself in blocks that matter.** Appendix B lists every conflict. Four affect the headline:

- **S06-D duplicates S06-C.** The day-3 rgH5N1 experiment (S06-D) is identical to the day-14 experiment (S06-C) in all 28 rows [Q1]. Its own weight block (S15-D) implies two deaths in the PSLN-344 arm that the table does not show [Q2]. I did not count S06-D. Early protection rests on S06-B, S15-H and S03-J instead [E25, E18].
- **Two experiments name their arms differently in the survival table and the weight block for the same animals.** In S03-I and S03-J, the PSLN-344 result is the same either way (7/7 and 10/10). What it is compared with is not certain [Q4, Q5]:
    - In S03-I, the PSLN-212 arm survived 0/7 as printed, or 3/7 if the weight-block labels are right.
    - In S03-J (wild-type H5N1), the weight block has no PSLN-212 arm at all. If it is right, the comparison was with the empty-liposome control and with unvaccinated animals, and the manganese-free parent was not tested in that experiment.
- **The body-weight sheets are not independent records.** Identical values recur between experiments that should share no animals [Q6], and weight-implied deaths disagree with the survival tables in ten arms [Q2]. I used weights descriptively only.
- **The printed IgG2a:IgG1 blocks (S03-B, S03-F) have their three headers rotated.** As printed they say PSLN-344 gives the IgG1-skewed response (0.58). Recomputed from the titres in S13-A to S13-D, PSLN-344 gives 2.1 and PSLN-212 gives 0.58 [I24, I25].

**3.2 The restoration is partial.**

- Survival is 81% against 98% in young mice (p = 0.001) [E11, E12c].
- Survivors still get sick. Their weight nadir averaged 88.2% of baseline, against 90.6% in young mice [E24]. The file has no lung virus titres and no lung pathology.
- Dendritic-cell co-stimulation stays low: CD40 and CD86 reach 29% and 38% of the young level [M6, M7].
- The fall in follicular regulatory T cells has gone by day 30: 14.0% with PSLN-344, 13.9% with the empty-liposome control [I10].

**3.3 Durability in aged animals is not shown beyond day 60.**

- At day 60, 14/21 survived (67%), against 20/21 at day 14 (p = 0.045). Within the two models tested at both times it was 10/14 against 13/14 (p = 0.33) [E17].
- Some of this is old age, not vaccine failure: 4 of 21 age-matched mice that were never challenged died in the same 14 days [E16]. But the PSLN-344 deaths look like infection. The five that can be identified in the weight blocks died at 78–85% of baseline weight. The four unchallenged animals died at 94–97% [E16b].
- The only 6-month data are in young mice. All survived with either adjuvant, but the PSLN-344 group recovered more slowly: 95.6% of baseline at day 14 against 99.2% (p = 0.003) [E21, E23].

**3.4 The safety evidence is thin.**

- One weight study: five animals per arm, one dose level, 10 days [S1].
- Lung inflammation had not resolved at the last time point measured.
    - At 72 h, aged mice given PSLN-344 still had Tnf 8.4-fold, Il6 7.2-fold and Ccl2 27-fold above PBS [S5]. Against young mice given PSLN-212, Tnf was 18 times higher and Il10 37 times higher [S4].
    - Part of this is age rather than manganese. Aged mice given PSLN-212 also had Tnf 5.2-fold and Il10 4.2-fold above PBS at 72 h [S5].
    - Lung monocytes and CD11b+ dendritic cells were still raised on day 8, the last day sampled: 18.4% and 13.7%, against 9.5% and 2.4% in the empty-liposome control [M3b, M4b].
- CNS: one time point, three transcripts, five animals. Tnf was 1.6-fold of PBS, which is p = 0.037 on an unadjusted t-test and p = 0.54 by Tukey's test [S7]. There are no manganese measurements and no histology anywhere in the file.
- The lung "neutrophil" block (S11-B) shares 35 of its 100 values with the alveolar-macrophage block (S11-A) and cannot be used [S8].
- Two class concerns are not addressed at all. Both are general knowledge, not findings from the file: inhaled manganese can reach the brain along the olfactory route, and an earlier nasal influenza vaccine with a toxin adjuvant was withdrawn after cases of facial palsy.

![Figure 4. A: body weight after dosing. B: lung cytokine transcripts at 16 h and 72 h. C: CNS transcripts at 36 h.](figures/fig4_safety.png)

**3.5 Translation gaps.** None of the following is tested in the file. The right-hand column draws on general knowledge of licensed influenza vaccines and respiratory delivery, not on the file.

| Gap | Why it matters |
|:-------------------------|:------------------------------------------------------------|
| No manganese-only particle, and no PSLN-212 mixed with free Mn²⁺ | The benefit cannot yet be attributed to the Mn–CDN combination rather than to manganese alone. |
| No licensed-type comparator (intramuscular high-dose or emulsion-adjuvanted vaccine) | Every comparison is against an unadjuvanted intranasal vaccine or PSLN-212. |
| Mice only, females only, 7 per arm, no stated replication | n = 7 gives 67% power for 81% against 10%, and 16% for 81% against 40% [P1]. |
| Whole inactivated virus as the antigen | Licensed seasonal vaccines are split, subunit or recombinant. Whole virions carry more internal protein and viral RNA, which may matter for the T-cell response and for innate stimulation. |
| Efficacy at 20 µg only | The lung IFN-β response is already near its plateau at 20 µg [D1]. The minimum effective dose is unknown. |
| Delivery | In mice the intranasal dose reaches alveolar epithelium and alveolar macrophages [M16, M17]. A human nasal spray deposits in the nose, not the alveoli. |
| Human STING | No human-cell data. Human STING variants differ in how they respond to cyclic dinucleotides. |
| Particle characterisation | The annotation describes size, charge, morphology and freeze-drying, but the file holds only encapsulation efficiency [D3]. There is no manganese content, release or stability data. |

## 4. What is actually driving the protection

**What the data establish**

1. **Vaccine and adjuvant are both required.** Three days before rgH5N1 challenge, vaccine alone protected 0/7, PSLN-344 alone 0/7, and the two together 6/7 [E19; Figure 3C]. The protection is not a free-standing antiviral state left by the adjuvant.
2. **In aged animals the manganese-containing particle is required. In young animals it adds nothing measurable downstream.** Young mice survived 24/24 with either adjuvant [E21]. Manganese raised four dendritic-cell readouts 1.7- to 24-fold in aged mice, and 1.0- to 1.2-fold in young mice (interaction p from 0.005 to 0.04) [M23].
3. **Manganese acts on signal strength, not on delivery.**
    - Encapsulation is not higher [D3].
    - Epithelial uptake is not higher on either reading of S08-C [D4].
    - Lung Ifnb1 at 16 h is 37.1-fold with PSLN-344 against 16.6-fold with PSLN-212 in aged mice. That equals the 37.6-fold that PSLN-212 produces in young mice [M1; Figure 3B].
4. **The cellular chain downstream of IFN-β is rebuilt to near the young level** (aged PSLN-344, aged PSLN-212, young PSLN-212):
    - lung monocytes on day 4: 30.6%, 16.7%, 32.2% [M3];
    - lung CD11b+ dendritic cells on day 4: 18.9%, 8.3%, 21.4% [M4];
    - cross-presenting (type 1) dendritic cells in the lung at 72 h: 37.5%, 22.8%, 43.4% [M24];
    - migratory (CCR7+) dendritic cells at 72 h: 30.7%, 7.3%, 35.0% [M5];
    - CD8 T-cell priming by dendritic cells sorted from the lymph node: 18.7%, 0.8%, 26.2% [M8].
5. **Each link has been broken experimentally, but only up to an intermediate readout.**
    - A CCR2 antagonist cut lung monocytes by 67% and Ly6C+ macrophages by 84% [M13, M14]. In young mice it cut granzyme B-positive (GZMB+) CD8 T cells in the lung by 79% [M12].
    - Bone marrow lacking the type I IFN receptor produced almost no monocyte-derived dendritic cells (2.1% against 19.7%). GM-CSF partly rescued this (12.4%) [M11]. PSLN-344 induces lung Gm-csf (8.7-fold against 1.6-fold) [M9].
    - Pertussis toxin blocked CD8 T-cell proliferation in the lymph node (30.9% to 6.8%) but not in the lung (59.0% to 55.1%) [M18]. T cells can therefore be expanded in the lung itself, which fits protection within 2 to 3 days.
    - The delivery features of the platform are needed as well, but both particles share them. Uptake by alveolar macrophages fell from 43.1% to 12.7% in mice lacking surfactant proteins A and D [M16]. A gap-junction blocker cut monocyte recruitment by 58% [M15]. This is why the deep lung matters for Gate 5.
6. **The only measured effector that fits every protection setting is the CD8 T cell.** Serum HAI antibody cannot explain protection against a different subtype, or protection 2 to 3 days after dosing. Activated CD8 T cells are in the lung by day 3: proliferating (Ki-67+) 9.4% against 3.5%, and GZMB+ 5.7% against 3.0% [I12, I13]. They cross-react with H5N1 and persist to day 60 [I14, I15].

**What the data do not establish**

- **Causality.** No pathway blockade was carried through to a challenge. There is no T-cell depletion and no serum transfer. CD8 T cells are the leading hypothesis, not a finding. Antibody acting without neutralisation is not excluded: IgG2a rose 20-fold (GMT 1,642 against 83) [I22].
- **What the vaccine contributes at day 3.** S15-H shows the vaccine is needed. It does not show whether it is needed as antigen or as a second innate stimulus.
- **Whether manganese alone would do the same.** There is no manganese-only arm.
- **The regulatory-cell story.** PSLN-344 lowers lung regulatory T cells (3.0% against 6.7%) [I11] and CD206+ macrophages (48.9% against 71.5%) [M20]. The two blocks designed to link these cannot be read. S07-A runs opposite to S01-D and S07-B, and both columns of S07-C carry the same header [M21, M22].

**In one line:** manganese restores the strength of STING-driven IFN-β in the aged lung; that rebuilds monocyte recruitment and dendritic-cell priming; the result is a vaccine-dependent response in which cross-reactive lung CD8 T cells are the best-supported, but unproven, effector.

## 5. Is there a biomarker of efficacy worth carrying forward?

**There is a candidate, and none is validated.** Two limits come from the design of the dataset:

- No animal has both a biomarker value and a challenge outcome. Every association is between group means from parallel animals.
- With four arms, nearly everything tracks survival. Of 33 single-time-point readouts, 27 separate the protected arms from the unprotected arms without overlap (`analysis/biomarker_screen.csv`). The data cannot rank them.

So the choice has to rest on two questions: does the marker fit every setting where protection was seen, and can it be measured in a person?

| Candidate | Fits the protection data? | Measurable in patients as measured here? | Role |
|:----------------|:----------------------------------|:----------------------|:----------------------|
| Lung Ifnb1 at 16 h | Necessary, not sufficient. PSLN-344 alone induces it 37-fold [M1], yet PSLN-344 alone protected 0/7 [E19]. Young mice given PSLN-344 make 35% more than with PSLN-212, with no survival gain [M1, E21]. | No (lung tissue). | Target engagement and dose-finding only. |
| Serum HAI and neutralising titre | Partly. They rank the arms for matched-strain challenge [I2, I3]. But all five aged PSLN-212 mice reached HAI ≥ 1:40, and at most 3 of 7 parallel animals survived [I2b]. They cannot explain day-2 to day-3 or cross-subtype protection. | **Yes.** Serum antibody is the only readout in the file taken from a patient-accessible sample. | Immunogenicity endpoint. Not sufficient alone. In this model a titre at the conventional 1:40 benchmark did not predict survival. |
| Cross-reactive CD8 T cells (IFN-γ+ after restimulation with a subtype not in the vaccine; GZMB+) | Yes, in every setting: present by day 3, cross-subtype, durable to day 60, dependent on the monocyte pathway [I12–I15, M12]. | Not as measured (lymph node and lung). A blood version is untested. | **Lead candidate.** Mechanism and response marker. A candidate correlate once Studies 2 and 3 read out. |
| Lung dendritic cells, germinal-centre B cells, follicular helper T cells (Tfh), resident-memory T cells | Yes. | No (tissue only). | Preclinical mechanism markers. |
| IgG2a:IgG1 ratio; ratio of Tfh to follicular regulatory T cells (Tfr) | Yes, but mouse-specific (isotypes) or derived from one measurement and gone by day 30 [I24, I10]. | No direct human equivalent. | Not carried. |

![Figure 5. The two candidates. A: serum HAI with survival of a matched-strain challenge. B: cross-reactive CD8 T cells with survival of an rgH5N1 challenge. Survival is from parallel animals, not the animals assayed. In A it is shown as printed in S03-I; section 3.1 gives the alternative reading.](figures/fig5_biomarker_candidates.png)

**What I would carry forward, and in what role**

- **A pair, not a single marker.** Serum HAI and neutralising titre, which are ready now. And a blood CD8 T-cell assay (IFN-γ ELISpot or intracellular staining against conserved internal proteins), which has to be built and bridged to the lung readouts first.
- **An early blood or nasal interferon signature** as the target-engagement marker for dose selection.
- **Role in patients: pharmacodynamic and response biomarkers** in Phase 1 and 2. They would show that the adjuvant engages its pathway in adults over 65, and that it adds cross-reactive T-cell immunity that HAI alone does not capture.
- **Not a surrogate endpoint and not a patient-selection marker.** Nothing here supports either use.

**Could the adjuvant itself go into patients, and in what role?** Not on the present data. If the gates are passed, the role the data support is a respiratory-route adjuvant for inactivated influenza vaccine in adults over 65. The data support a pandemic or outbreak setting (H5, protection within days) as well as the seasonal one. They give no reason to use it in younger adults, where it adds no protection over PSLN-212 [E21].

## 6. What the next studies have to establish

Six gates (0 to 5) decide whether IND-enabling work starts. Studies 2 to 4 do not gate it. They fix the clinical biomarker plan and the regimen, and show whether a season-long claim is realistic.

| Study | Gate | Must establish | Duration |
|:------------------------------|:-------|:------------------------------------------------|:-----------|
| 0. Record reconciliation | 0 | Which arm is which in the conflicting blocks | 2–4 weeks |
| 1. Confirmatory efficacy | 1, 2 | The benefit repeats, needs Mn and CDN together, and holds against licensed-type vaccines | about 4 months |
| 2. Mechanism of protection | – | Which effector protects; whether the monocyte pathway is needed for survival | about 3 months |
| 3. Biomarker bridging | – | A blood or nasal measure that predicts each animal's outcome | about 3 months |
| 4. Durability and regimen | – | Protection at 3 and 6 months; value of a second dose | about 9 months |
| 5. Safety and manganese disposition | 3 | Where manganese goes; whether inflammation resolves; a safety margin | about 5 months |
| 6. Human relevance | 4 | Activity on human STING variants and in cells from older donors | about 3 months |
| 7. Route, antigen, second species | 5 | Efficacy with a deliverable route, a licensed-format antigen, and in ferrets | about 6 months, after Gate 1 |

Studies 0 to 3, 5 and 6 can start together. Particle characterisation and stability work (size, charge, manganese content and release, freeze-dried storage) should run alongside, because none of it is in the file. Sample sizes come from the survival rates seen here: with 80% power, 8 per arm detects 81% against 10%, 25 per arm detects 81% against 40%, and 34 per arm detects 95% against 67% [P1].

**Study 0. Record reconciliation (Gate 0)**

- *Must establish:* the arm identities in S03-I/S13-F and S03-J/S13-G; whether S06-D is a separate experiment; the correct headers for S03-B, S03-F, S07-A, S07-C, S08-C and the second S09-A panel; the status of S11-B and of the shared body-weight values.
- *Population, comparators:* none. This is a check of source records.
- *Endpoint:* a locked dataset and a re-run of this analysis.
- *Pass:* the aged survival advantage of PSLN-344 over PSLN-212 stays at 40 points or more.
- *Timing:* 2 to 4 weeks, before any new spend.

**Study 1. Confirmatory efficacy, blinded and randomised (Gates 1 and 2)**

- *Must establish:* that the benefit repeats; that it needs manganese and CDN together; the lowest effective dose; how it compares with licensed-type vaccines.
- *Population:* aged BALB/c of both sexes (the file is female-only). 25 per arm for comparisons between active arms, 12 per arm for dose-ranging and controls. A young reference arm. Unchallenged age-matched sentinels.
- *Arms and comparators:*
    - vaccine + PSLN-344 at 2.5, 5, 10 and 20 µg;
    - vaccine + PSLN-212 at 20 and 40 µg;
    - vaccine + manganese-only liposome;
    - vaccine + PSLN-212 mixed with free Mn²⁺;
    - vaccine + empty liposome;
    - PSLN-344 alone;
    - intramuscular high-dose vaccine;
    - intramuscular emulsion-adjuvanted vaccine.
- *Primary endpoint:* survival to day 14 after a cross-subtype challenge, with a pre-set humane endpoint and blinded scoring.
- *Pass:* survival of 70% or more; 40 points or more above PSLN-212 and above manganese-only (Gate 1); not below the better intramuscular comparator (Gate 2).
- *Readouts:* lung virus titre and histology on days 3 and 6 after challenge (absent from the present file); weight and clinical score; serum HAI and a blood T-cell assay on the same animals before challenge.
- *Timing:* challenge 14 days after one dose. About 4 months including supply of aged animals.

**Study 2. Mechanism of protection**

- *Must establish:* whether CD8 T cells, antibody, or both are needed; whether the monocyte pathway is needed for survival and not only for intermediate readouts; whether day-3 protection is antigen-specific.
- *Population:* aged BALB/c, 12 per arm.
- *Arms and comparators:* vaccine + PSLN-344 with each of: isotype control antibody; CD8 depletion before challenge; CD4 depletion before challenge; CCR2 antagonist during priming; interferon-receptor blockade during priming. Also: immune serum transferred into naive aged recipients; an unrelated antigen + PSLN-344.
- *Primary endpoint:* survival to day 14.
- *Readouts:* lung virus titre; confirmation of depletion by flow cytometry.
- *Timing:* challenges at day 3 and day 14, cross-subtype and matched-strain. About 3 months.

**Study 3. Biomarker bridging**

- *Must establish:* a blood or nasal measure that tracks the lung and lymph-node readouts and predicts each animal's own outcome.
- *Population:* aged BALB/c, about 80 in total, spread over PSLN-344 doses from 0 to 20 µg so that responses vary.
- *Comparators:* PSLN-212 and empty liposome.
- *Primary endpoint:* accuracy of each pre-challenge marker in predicting survival.
- *Carry forward:* markers with an area under the ROC curve of 0.8 or more, and a correlation of 0.6 or more with the tissue readout.
- *Readouts and timing:*
    - day 1: blood interferon-response score and nasal IFN-β;
    - day 7: activated CD8 T cells in blood;
    - day 13: HAI, neutralising titre, blood IFN-γ ELISpot;
    - day 14: challenge;
    - satellite animals: paired blood and lung on days 7 and 14.

**Study 4. Durability and regimen**

- *Must establish:* protection at 3 and 6 months in animals that were old when vaccinated; whether a second dose helps.
- *Population:* BALB/c vaccinated at 14 months, when the defect is already present (PSLN-212 0/14) [E20]. 34 per arm. Unchallenged sentinels at each time.
- *Arms and comparators:* PSLN-344 once; PSLN-344 twice; PSLN-212 twice; an intramuscular comparator; empty liposome.
- *Primary endpoint:* survival after challenge at day 90 and at day 180.
- *Readouts:* HAI, neutralising titre, blood T-cell assay, lung resident-memory T cells and follicular regulatory T cells on days 28, 90 and 180.
- *Timing:* starts with Study 1; reads out at about 9 months.

**Study 5. Safety and manganese disposition (Gate 3)**

- *Must establish:* where the manganese goes and whether it clears; whether lung and CNS inflammation resolve; a safety margin. The present file stops at 72 h for lung cytokines, day 8 for lung cells and 36 h for the CNS.
- *Population:* aged mice of both sexes, then rats. Two species for the later GLP studies.
- *Arms and comparators:* PSLN-344 at 1×, 3× and 10× the effective dose, single and repeated; PSLN-212; manganese-only liposome; Mn²⁺ solution; vehicle.
- *Endpoints and readouts:* manganese by mass spectrometry (ICP-MS) in olfactory bulb, brain regions, lung, liver and blood; histology of nasal cavity, brain and lung; lavage cell counts and cytokine protein; behaviour and olfaction; clinical pathology.
- *Pass:* no brain manganese above control at day 28; lung and CNS markers back to baseline by day 28; a no-adverse-effect level at 3× the effective dose or higher.
- *Timing:* 24 h, then days 7, 28 and 90. About 5 months.

**Study 6. Human relevance (Gate 4)**

- *Must establish:* that CDN-1807 with Mn²⁺ activates the common human STING variants; that the gain over PSLN-212 holds in cells from older donors.
- *Population:* blood monocytes from donors over 65 and donors aged 18 to 40, genotyped for STING. Human lung tissue where available.
- *Comparators:* PSLN-212, CMP-204, free Mn²⁺, empty liposome.
- *Readouts:* IFN-β, CXCL10, TNF and IL-6 protein; cell viability; at 6, 24 and 72 h.
- *Pass:* PSLN-344 gives at least twice the IFN-β of PSLN-212 in older-donor cells, in every common genotype.
- *Timing:* about 3 months.

**Study 7. Route, antigen and second species (Gate 5)**

- *Must establish:* that efficacy survives a delivery that is feasible in people and a licensed-format antigen.
- *Population:* aged mice first, then ferrets, including pre-immune animals.
- *Arms and comparators:*
    - mice: upper-airway-only dosing against deep-lung dosing; split vaccine against whole inactivated virus;
    - ferrets: PSLN-344 by nasal spray and by aerosol; an intramuscular adjuvanted vaccine; vaccine alone.
- *Primary endpoint:* survival in mice; nasal-wash virus load over days 1 to 7 in ferrets.
- *Readouts:* fever, weight, transmission to contact animals, HAI, nasal IgA, blood T-cell assay.
- *Pass:* protection retained with at least one deliverable route and with split antigen.
- *Timing:* challenge at day 28 and day 90. About 6 months, starting after Gate 1.

**First-in-human study.** It would follow only if Gates 0 to 5 are passed. Its outline:

- adults aged 50 to 64, then over 65;
- licensed antigen with ascending PSLN-344 doses, against a licensed high-dose or adjuvanted vaccine;
- safety: reactogenicity over 7 days, neurological and olfactory assessment, blood manganese;
- biomarkers in the roles set out in section 5.

## 7. What I considered and ruled out

**Alternative ways to get the same benefit**

| Alternative | Verdict | Evidence |
|:--------------------------|:--------------|:--------------------------------------------------|
| Keep PSLN-212 for older adults | Ruled out | 6/63 survive [E11]. |
| Raise the PSLN-212 dose | Ruled out on the pharmacodynamic readout; no challenge data | IFN-β plateaus at 14.9-fold at 40 µg [D1, D2]. |
| Give PSLN-212 twice | Not established | After a boost, IgG GMT against CA09 is 4,411 with PSLN-212 and 15,651 with PSLN-344 (p = 0.19). Against H3N2 it is 1,086 and 12,435 (p < 0.001). There is no challenge after a boost [I20, I21]. |
| Switch to cGAMP (CMP-204) | Ruled out for aged animals | Ifnb1 7.8-fold, HAI GMT 23 [M1, I2]. Adequate in young mice (7/7) [E22]. |
| Add R848 | Ruled out | Tolerability [S2, S6]; less IFN-β than PSLN-344 [M1]. |
| Add GM-CSF to PSLN-212 | Mechanistic tool only | Restores monocyte-derived dendritic cells from 5.9% to 13.8% [M10]. No challenge data. |
| Use PSLN-344 at all ages | Not supported | No gain in young mice [E21]; slower recovery at 6 months [E23]. |

**Alternative explanations for the benefit**

| Explanation | Verdict | Evidence |
|:--------------------------|:--------------|:--------------------------------------------------|
| More drug loaded | Ruled out | Encapsulation 54.8% against 59.6% [D3]. |
| Better delivery to epithelium | Ruled out on either reading | S08-C [D4]. |
| A non-specific antiviral state | Ruled out | Adjuvant alone 0/7 [E19]. |
| A BALB/c peculiarity | Ruled out | C57BL/6 6/7; Swiss Webster 6/7 [E8, E9]. |
| Natural killer cells | Not supported | Lung NK cells did not differ from PSLN-212 or from vaccine alone on any day (p ≥ 0.12) [M25]. |
| More alveolar macrophages | Not supported | They rise with both adjuvants; PSLN-344 does not differ from PSLN-212 on any day (p ≥ 0.15) [M26]. |
| Works only in animals with no prior influenza exposure | Ruled out | 12/14 with or without prior infection [E20]. |
| Serum HAI antibody alone | Cannot account for day-2 to day-3 or cross-subtype protection | [E25, E18, E2, E4]. |
| Day-60 deaths are just old age | Partly | 4/21 unchallenged animals died, at 94–97% of baseline weight. The PSLN-344 deaths followed 15–23% weight loss [E16, E16b]. |

**Analysis choices I rejected**

- Counting S06-D as a tenth experiment: it is a copy of S06-C [Q1].
- Taking the printed IgG2a:IgG1 blocks at face value: the headers are rotated [I24, I25].
- Treating the second S09-A panel as a repeat at 16 h: its Ifnb1 row reproduces the 72 h values of S01-A in all 21 cells [Q3].
- Treating the "Untreated" arms of S06-E, S06-F and S06-G as infected controls: the annotation says they received no virus. I used them as the background death rate [E16].
- Averaging the log10 values of S09-A as if linear: I averaged on the log scale and back-transformed.
- Using body weights to overrule the survival tables: the weight sheets share values between experiments [Q6]. They serve as a sensitivity check only [E11-s3].
- Using S11-B for neutrophil influx, or S07-A and S07-C for the regulatory-cell mechanism [S8, M21, M22].

**Decisions I rejected**

- *Straight to IND-enabling work.* The safety and translation gaps in sections 3.4 and 3.5 are too wide to commit GLP and GMP spend.
- *Stop.* The effect is large and consistent, it is the only route to an older-adult product on this platform, and each gap can be closed or failed within about a year.

## 8. If the committee drops it

**What would be dropped:**

- a single-dose intranasal adjuvant that took aged-mouse survival from 10% with PSLN-212 to 81% [E11];
- protection across subtypes including H5N1 [E2, E4, E18];
- protection within 2 to 3 days of dosing [E25, E18];
- protection that holds in animals with prior influenza exposure [E20];
- and, with it, the older-adult indication for the platform, because PSLN-212 alone does not protect aged animals.

**Why one would drop it:**

- the evidence is mouse-only, female-only and small;
- the antigen and the delivery route are not those of a licensed product;
- intranasal manganese in older adults has no safety data here;
- parts of the record need reconciling before they can be relied on.

These are gaps, not negative results. In aged animals PSLN-344 was never worse than its comparators on any efficacy readout in the file.

## Appendix A. Evidence ledger

Each row is one number, or one set of numbers, used in the memo. "Cells" are worksheet addresses in `adjuvant_program_dataset.xlsx`. Group names are as printed in the workbook: "Sham" is vaccine plus empty liposome, and "(Y)" marks young animals. The same table is in `evidence_ledger.csv`.

| ID | Block and measure | Value | Cells | Reduction |
|:---------|:------------------------------|:--------------------------------------------|:----------------------|:----------------------------|
| E1 | S03-I: bivalent vaccine→10×mLD50 CA09 H1N1 (matched strain), d14 — alive at end of 14-d observation | Sham 0/7; PSLN-212 0/7; PSLN-344 7/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.00035 | S03!B17:B23; S03!D31:D37; S03!E38:E44; S03!F45:F51 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E2 | S06-A: Aichi H3N2 vaccine→5×mLD50 PR8 H1N1, d14 — alive at end of 14-d observation | Sham 0/7; PSLN-212 1/7; PSLN-344 6/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.0083 | S06!B3:B9; S06!C10:C16; S06!D17:D23; S06!E24:E30 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E3 | S06-B: Aichi H3N2→PR8 H1N1, d3 — alive at end of 14-d observation | Sham 0/7; PSLN-212 0/7; PSLN-344 5/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.00092 | S06!H3:H9; S06!I10:I16; S06!J17:J23; S06!K24:K30 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E4 | S06-C: bivalent→5×mLD50 rgH5N1, d14 — alive at end of 14-d observation | Sham 0/7; PSLN-212 2/7; PSLN-344 7/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.0068 | S06!N3:N9; S06!O10:O16; S06!P17:P23; S06!Q24:Q30 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E5 | S06-E (r34-68): Aichi H3N2→PR8 H1N1, d60 — alive at end of 14-d observation | Sham 0/7; PSLN-212 0/7; PSLN-344 5/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.0016 | S06!H34:H40; S06!I41:I47; S06!J48:J54; S06!K55:K61 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E6 | S06-F (r34-68): bivalent→rgH5N1, d60 — alive at end of 14-d observation | Sham 0/7; PSLN-212 1/7; PSLN-344 5/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.0094 | S06!N34:N40; S06!O41:O47; S06!P48:P54; S06!Q55:Q61 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E7 | S06-G: CA09 H1N1→Perth H3N2, d60 — alive at end of 14-d observation | Sham 0/7; PSLN-212 0/7; PSLN-344 4/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.015 | S06!B71:B77; S06!C78:C84; S06!D85:D91; S06!E92:E98 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E8 | S15-L: aged C57BL/6, bivalent (challenge virus/interval not stated) — alive at end of 14-d observation | Sham 0/7; PSLN-212 0/7; PSLN-344 6/7; PSLN-212(Y) 6/7; log-rank PSLN-344 vs PSLN-212 p=0.0011 | S15!B103:B109; S15!C110:C116; S15!D117:D123; S15!E124:E130 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E9 | S15-N: aged Swiss Webster, bivalent (challenge virus/interval not stated) — alive at end of 14-d observation | Sham 0/7; PSLN-212 2/7; PSLN-344 6/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.056 | S15!B134:B140; S15!C141:C147; S15!D148:D154; S15!E155:E161 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E10 | S06-D: bivalent→rgH5N1, d3 (block identical to S06-C) — alive at end of 14-d observation | Sham 0/7; PSLN-212 2/7; PSLN-344 7/7; PSLN-212(Y) 7/7; log-rank PSLN-344 vs PSLN-212 p=0.0068 | S06!B34:B40; S06!C41:C47; S06!D48:D54; S06!E55:E61 (days in the block's 'Days' column) | count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status) |
| E11a | Pooled survival, 9 aged (≥20 mo) experiments (E1–E9; S06-D excluded as duplicate of S06-C): Sham | 0/63 = 0.0% (exact 95% CI 0–6%) | sum of E1–E9 | sum of alive ÷ sum of animals; Clopper–Pearson CI |
| E11b | Pooled survival, 9 aged (≥20 mo) experiments (E1–E9; S06-D excluded as duplicate of S06-C): PSLN-212 | 6/63 = 9.5% (exact 95% CI 4–20%) | sum of E1–E9 | sum of alive ÷ sum of animals; Clopper–Pearson CI |
| E11c | Pooled survival, 9 aged (≥20 mo) experiments (E1–E9; S06-D excluded as duplicate of S06-C): PSLN-344 | 51/63 = 81.0% (exact 95% CI 69–90%) | sum of E1–E9 | sum of alive ÷ sum of animals; Clopper–Pearson CI |
| E11d | Pooled survival, 9 aged (≥20 mo) experiments (E1–E9; S06-D excluded as duplicate of S06-C): PSLN-212(Y) | 62/63 = 98.4% (exact 95% CI 91–100%) | sum of E1–E9 | sum of alive ÷ sum of animals; Clopper–Pearson CI |
| E11-s1 | Pooled survival if S06-D is counted as a tenth experiment | PSLN-344 58/70 (83%) vs PSLN-212 8/70 (11%) | E1–E10 | sum of alive ÷ sum of animals |
| E11-s2 | Pooled survival if the S03-I column headed "CMP-204" is taken to be the PSLN-212 arm (the reading suggested by the S13-F weight block) | PSLN-344 51/63 (81%) vs PSLN-212 9/63 (14%); stratified log-rank p=4.6e-16; in S03-I itself 7/7 vs 3/7, log-rank p=0.022 | E1–E9 with S03!C24:C30 in place of S03!D31:D37 | as E11/E12 |
| E11-s3 | Pooled survival if deaths are read from the nine paired body-weight blocks instead of the time-to-event tables | PSLN-344 53/63 (84%); PSLN-212 9/63 (14%); PSLN-212(Y) 63/63 (100%) | S13-F, S15-A, S15-B, S15-C, S15-E, S15-F, S15-G, S15-M, S15-O | animal counted dead if its weight trace goes blank or its terminal value is carried forward unchanged (rule in Appendix C); arms as labelled in the weight blocks |
| E11-s4 | Least favourable reading for PSLN-344 across all ten experiments (S06-D included): for each experiment, the lower of the two survivor counts for PSLN-344 (time-to-event table, weight block) and the higher of the two for PSLN-212 (including the alternative arm identity in S03-I) | PSLN-344 56/70 (80%) vs PSLN-212 12/70 (17%); per experiment PSLN-344 [7, 6, 5, 7, 5, 5, 4, 6, 6, 5], PSLN-212 [3, 1, 0, 2, 1, 1, 0, 0, 2, 2] (order: S03-I, S06-A, S06-B, S06-C, S06-E, S06-F, S06-G, S15-L, S15-N, S06-D); Fisher p=4.9e-14 | time-to-event tables E1–E10 and weight blocks S13-F, S15-A…G, S15-M, S15-O | minimum (PSLN-344) or maximum (PSLN-212) of the two survivor counts per experiment, summed; two-sided Fisher exact |
| E12a | Pooled comparison PSLN-344 vs PSLN-212, stratified by experiment (9 experiments) | stratified log-rank χ²=72.5, p=1.6e-17; Peto hazard ratio for death 0.10 (95% CI 0.06–0.17); Cochran–Mantel–Haenszel p=1.9e-15 | E1–E9 time-to-event rows | log-rank O−E and variance summed across experiments (strata); Peto one-step HR = exp(Σ(O−E)/ΣV); CMH on alive/dead 2×2 tables |
| E12b | Pooled comparison PSLN-344 vs Sham, stratified by experiment (9 experiments) | stratified log-rank χ²=118.8, p=1.2e-27; Peto hazard ratio for death 0.05 (95% CI 0.03–0.08); Cochran–Mantel–Haenszel p=2.2e-19 | E1–E9 time-to-event rows | log-rank O−E and variance summed across experiments (strata); Peto one-step HR = exp(Σ(O−E)/ΣV); CMH on alive/dead 2×2 tables |
| E12c | Pooled comparison PSLN-344 vs PSLN-212(Y), stratified by experiment (9 experiments) | stratified log-rank χ²=10.3, p=0.0013; Peto hazard ratio for death 5.96 (95% CI 2.00–17.72); Cochran–Mantel–Haenszel p=0.0014 | E1–E9 time-to-event rows | log-rank O−E and variance summed across experiments (strata); Peto one-step HR = exp(Σ(O−E)/ΣV); CMH on alive/dead 2×2 tables |
| E12d | Pooled comparison PSLN-212 vs Sham, stratified by experiment (9 experiments) | stratified log-rank χ²=28.6, p=9.1e-08; Peto hazard ratio for death 0.25 (95% CI 0.15–0.41); Cochran–Mantel–Haenszel p=0.012 | E1–E9 time-to-event rows | log-rank O−E and variance summed across experiments (strata); Peto one-step HR = exp(Σ(O−E)/ΣV); CMH on alive/dead 2×2 tables |
| E12e | Do the nine experiments differ from one another in survival within an arm? (test of homogeneity) | PSLN-344 survivors per experiment [7, 6, 5, 7, 5, 5, 4, 6, 6] of 7: χ²=7.4, permutation p=0.64; PSLN-212 [0, 1, 0, 2, 0, 1, 0, 0, 2] of 7: χ²=9.9, permutation p=0.39 | E1–E9 | Pearson χ² on the 2×9 table of alive/dead by experiment; p-value from 20,000 random re-allocations of the outcomes (fixed seed) |
| E13 | Pooled survival, aged BALB/c only (7 experiments) | Sham 0/49; PSLN-212 4/49; PSLN-344 39/49; PSLN-212(Y) 49/49 | rows as in E1–E9 | sum of alive ÷ sum of animals |
| E14 | Pooled survival, aged C57BL/6 + Swiss Webster (S15-L, S15-N) | Sham 0/14; PSLN-212 2/14; PSLN-344 12/14; PSLN-212(Y) 13/14 | rows as in E1–E9 | sum of alive ÷ sum of animals |
| E15a | Aged BALB/c survival by vaccination→challenge interval: d3 (S06-B) | Sham 0/7 (0%); PSLN-212 0/7 (0%); PSLN-344 5/7 (71%); PSLN-212(Y) 7/7 (100%) | rows as in E1–E8 | sum of alive ÷ sum of animals |
| E15b | Aged BALB/c survival by vaccination→challenge interval: d14 (S03-I, S06-A, S06-C) | Sham 0/21 (0%); PSLN-212 3/21 (14%); PSLN-344 20/21 (95%); PSLN-212(Y) 21/21 (100%) | rows as in E1–E8 | sum of alive ÷ sum of animals |
| E15c | Aged BALB/c survival by vaccination→challenge interval: d60 (S06-E, S06-F, S06-G) | Sham 0/21 (0%); PSLN-212 1/21 (5%); PSLN-344 14/21 (67%); PSLN-212(Y) 21/21 (100%) | rows as in E1–E8 | sum of alive ÷ sum of animals |
| E16 | Background mortality: "Untreated" aged animals (no vaccine, no adjuvant, NO challenge virus) observed alongside the d60 challenges | alive 17/21 (81%): S06-E 6/7, S06-F 7/7, S06-G 4/7; deaths on days 4 (S06-E) and 3, 7, 10 (S06-G); vs PSLN-344 d60 14/21, Fisher p=0.48 | S06!L62:L68; S06!R62:R68; S06!F99:F105 | count of status 0 ÷ rows; two-sided Fisher exact vs PSLN-344 d60 (14/21) |
| E16b | Day-60 experiments: lowest recorded weight of animals that died (identified in the weight blocks S15-E/F/G by a trace carried forward unchanged) | PSLN-344 + challenge: 77.5%, 79.8%, 80.3%, 83.9%, 85.3% of baseline (n=5 of the 7 deaths in the survival tables); Untreated, unchallenged: 94.5%, 95.0%, 95.7%, 96.6% (n=4 of 4) | S15!W43:AC50, S15!W53:AC60, S15!W63:AC70 (PSLN-344); S15!AD43:AJ50, S15!AD63:AJ70 (Untreated) | per-animal minimum of the weight trace for animals classed as dead from the trace |
| E17 | PSLN-344 aged: d14 vs d60 survival | matched vaccine/challenge pairs (Aichi→PR8 and bivalent→rgH5N1): d14 13/14 vs d60 10/14, Fisher p=0.33; all d14 (incl. homologous S03-I) 20/21 vs all d60 14/21, p=0.045 | S06!D17:D23, S06!P17:P23 vs S06!J48:J54, S06!P48:P54; plus S03!E38:E44 and S06!D85:D91 | two-sided Fisher exact on alive/dead |
| E18 | S03-J: rgH5N1 vaccine, wild-type VN04 H5N1 challenge 2 days later (age of animals not stated; challenge dose not stated) | alive at d21: PSLN-344 10/10 (only 9 rows carry a day value; S03!G46 is blank), PSLN-212 3/10, Sham 1/10; block label says n=9 | S03!G17:J46 | count of status 0 ÷ rows per arm |
| E19 | S15-H: aged BALB/c, intranasal dose 3 days before 5×mLD50 rgH5N1 — vaccine alone vs PSLN-344 alone vs both | alive: vaccine alone 0/7 (deaths d[4, 5, 5, 5, 6, 6, 7]), PSLN-344 alone 0/7 (deaths d[5, 5, 6, 6, 6, 7, 8]), vaccine+PSLN-344 6/7; log-rank adjuvant-alone vs vaccine-alone p=0.22; combination vs adjuvant alone p=0.00014 | S15!A73:D93 | count of status 0 ÷ 7; two-sided log-rank |
| E20 | Imprinting model (10-mo BALB/c infected with 1×mLD50 PR8 or saline; bivalent vaccine 4 months later; challenge 5×LD50 PR8 or Perth H3N2) | Naïve+PSLN-212: PR8 0/7, Perth 0/7; Imprinting+PSLN-212: PR8 4/7, Perth 0/7; Naïve+PSLN-344: PR8 6/7, Perth 6/7; Imprinting+PSLN-344: PR8 6/7, Perth 6/7 | S06!G71:K98 (PR8), S06!M71:Q98 (Perth) | count of status 0 ÷ 7 per arm |
| E21 | Young BALB/c: PSLN-344 vs PSLN-212 | Aichi→PR8 d21: PSLN-344Y 8/8, PSLN-212Y 8/8, Sham 0/8; CA09→Perth d21: PSLN-344Y 8/8, PSLN-212Y 8/8, Sham 0/8; bivalent→rgH5N1 d180: PSLN-344Y 8/8, PSLN-212Y 8/8, Sham 0/7 | S09!A12:D35; S09!A39:D62; S09!A66:D88 | count of status 0 ÷ rows per arm |
| E22 | S13-E young BALB/c, homologous 10×mLD50 CA09 at d14 | Naïve 0/7; Sham 1/7; CMP-204(Y) 7/7; PSLN-344(Y) 7/7 (block label says n=5; 7 rows per arm) | S13!R3:V30 | count of status 0 ÷ rows |
| E23a | S09-G young, challenge 180 d after vaccination: body weight on day 12 post-challenge (all animals survived) | PSLN-344Y 92.4 ± 1.4 (n=8) vs PSLN-212Y 96.5 ± 2.0 (n=8) % of day-0 weight; Student t p=0.00028 | S09!W72:AD72 vs S09!G72:N72 | arithmetic mean ± SD of per-animal % baseline weight; two-sided Student t |
| E23b | S09-G young, challenge 180 d after vaccination: body weight on day 14 post-challenge (all animals survived) | PSLN-344Y 95.6 ± 1.7 (n=8) vs PSLN-212Y 99.2 ± 2.4 (n=8) % of day-0 weight; Student t p=0.0033 | S09!W73:AD73 vs S09!G73:N73 | arithmetic mean ± SD of per-animal % baseline weight; two-sided Student t |
| E24 | Post-challenge weight nadir among survivors (10 weight blocks paired to aged challenge experiments) | aged PSLN-344 88.2 ± 3.5% of baseline (n=58 animals) vs young PSLN-212 90.6 ± 3.1% (n=68); Student t p=0.00011 | S13-F, S15-A…G, S15-M, S15-O (PSLN-344 and PSLN-212(Y) columns) | per-animal minimum over d2–d14; animals whose trace goes blank or is carried forward unchanged to d14 (≥3 identical terminal values, or 2 identical terminal values <90%) are treated as dead and excluded; pooled across blocks |
| E25 | Early protection in aged BALB/c, challenge 3 days after a single dose (S06-B Aichi→PR8; S15-H bivalent→rgH5N1) | PSLN-344 + vaccine 11/14 alive; comparators: S06-B Sham 0/7, PSLN-212 0/7; S15-H vaccine alone 0/7, PSLN-344 alone 0/7 | S06!J17:J23; S15!D87:D93; comparators S06!H3:I16, S15!B73:C86 | count of status 0 ÷ rows; sum over the two experiments |
| I1 | S03-A: serum IgG vs CA09 H1N1, d14 | GMT: Sham 56, CMP-204 181, PSLN-212 393, PSLN-344 7,305, PSLN-212(Y) 11,959; PSLN-344/PSLN-212 = 18.6×; % of young: PSLN-212 3%, PSLN-344 61%; Tukey p (344 vs 212) 3.1e-06, (344 vs young) 0.72 | S03!A3:A7; S03!B3:B7; S03!C3:C7; S03!D3:D7; S03!E3:E7 | geometric mean of reciprocal titres; one-way ANOVA + Tukey HSD on log2 titres |
| I2 | S03-C: HAI vs CA09 H1N1, d14 | GMT: Sham 7.6, CMP-204 23, PSLN-212 46, PSLN-344 368, PSLN-212(Y) 485; PSLN-344/PSLN-212 = 8.0×; % of young: PSLN-212 9%, PSLN-344 76%; Tukey p (344 vs 212) 5.7e-06, (344 vs young) 0.87 | S03!K3:K7; S03!L3:L7; S03!M3:M7; S03!N3:N7; S03!O3:O7 | geometric mean of reciprocal titres (values printed as 0 = below the 1:10 starting dilution, set to 5); one-way ANOVA + Tukey HSD on log2 titres |
| I2b | S03-C: animals with HAI ≥ 1:40 vs CA09 at d14, and survival of the matched-strain challenge in parallel animals (S03-I, as printed) | Sham: 0/5 at ≥40 (range <10–10), survival 0/7; CMP-204: 2/5 at ≥40 (range 10–40), survival 3/7; PSLN-212: 5/5 at ≥40 (range 40–80), survival 0/7; PSLN-344: 5/5 at ≥40 (range 160–640), survival 7/7; PSLN-212(Y): 5/5 at ≥40 (range 320–640), survival 7/7 | S03!K3:O7; S03!B17:F51 | count of animals with titre ≥ 40; survival as E1 (the S03-I columns headed CMP-204 and PSLN-212 may be PSLN-212 and Naïve — see Q4) |
| I3 | S03-D: neutralising titre vs CA09 H1N1, d14 | GMT: Sham 52, CMP-204 182, PSLN-212 418, PSLN-344 3,840, PSLN-212(Y) 6,686; PSLN-344/PSLN-212 = 9.2×; % of young: PSLN-212 6%, PSLN-344 57%; Tukey p (344 vs 212) 0.00024, (344 vs young) 0.67 | S03!Q3:Q7; S03!R3:R7; S03!S3:S7; S03!T3:T7; S03!U3:U7 | geometric mean of reciprocal titres; one-way ANOVA + Tukey HSD on log2 titres |
| I4 | S03-E: serum IgG vs Aichi H3N2, d14 | GMT: Sham 52, CMP-204 200, PSLN-212 426, PSLN-344 5,701, PSLN-212(Y) 13,855; PSLN-344/PSLN-212 = 13.4×; % of young: PSLN-212 3%, PSLN-344 41%; Tukey p (344 vs 212) 0.00013, (344 vs young) 0.33 | S03!A10:A14; S03!B10:B14; S03!C10:C14; S03!D10:D14; S03!E10:E14 | geometric mean of reciprocal titres; one-way ANOVA + Tukey HSD on log2 titres |
| I5 | S03-G: HAI vs Aichi H3N2, d14 | GMT: Sham 10, CMP-204 30, PSLN-212 35, PSLN-344 320, PSLN-212(Y) 368; PSLN-344/PSLN-212 = 9.2×; % of young: PSLN-212 9%, PSLN-344 87%; Tukey p (344 vs 212) 2.2e-06, (344 vs young) 0.99 | S03!K10:K14; S03!L10:L14; S03!M10:M14; S03!N10:N14; S03!O10:O14 | geometric mean of reciprocal titres (values printed as 0 = below the 1:10 starting dilution, set to 5); one-way ANOVA + Tukey HSD on log2 titres |
| I6 | S03-H: neutralising titre vs Aichi H3N2, d14 | GMT: Sham 40, CMP-204 138, PSLN-212 276, PSLN-344 2,533, PSLN-212(Y) 4,411; PSLN-344/PSLN-212 = 9.2×; % of young: PSLN-212 6%, PSLN-344 57%; Tukey p (344 vs 212) 3.2e-05, (344 vs young) 0.53 | S03!Q10:Q14; S03!R10:R14; S03!S10:S14; S03!T10:T14; S03!U10:U14 | geometric mean of reciprocal titres; one-way ANOVA + Tukey HSD on log2 titres |
| I7 | S03-K: MLN germinal-centre B cells, d7 (%) | Sham 1.18 ± 0.40 (n=5), PSLN-212 2.34 ± 0.52 (n=5), PSLN-344 6.54 ± 1.54 (n=5), PSLN-212(Y) 9.82 ± 3.05 (n=5); PSLN-344/PSLN-212 = 2.8×; % of young: PSLN-212 24%, PSLN-344 67%; Tukey p (344 vs 212) 0.0074, (344 vs young) 0.04 | S03!L17:L21; S03!M17:M21; S03!N17:N21; S03!O17:O21 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I8 | S04-A ICOS-high: MLN ICOS-high Tfh, d7 (%) | Sham 0.30 ± 0.16 (n=5), PSLN-212 3.82 ± 0.85 (n=5), PSLN-344 10.3 ± 3.2 (n=5), PSLN-212(Y) 13.6 ± 1.6 (n=5); PSLN-344/PSLN-212 = 2.7×; % of young: PSLN-212 28%, PSLN-344 75%; Tukey p (344 vs 212) 0.00023, (344 vs young) 0.045 | S04!G2:K2; S04!G3:K3; S04!G4:K4; S04!G5:K5 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I9 | S04-B Foxp3+: MLN Tfr (Foxp3+ of CXCR5+ CD4), d7 (%) | Sham 22.6 ± 4.4 (n=5), PSLN-212 26.7 ± 6.7 (n=5), PSLN-344 10.8 ± 1.8 (n=5), PSLN-212(Y) 7.12 ± 3.67 (n=5); PSLN-344/PSLN-212 = 0.4×; % of young: PSLN-212 374%, PSLN-344 152%; Tukey p (344 vs 212) 0.00022, (344 vs young) 0.58 | S04!A8:A12; S04!B8:B12; S04!C8:C12; S04!D8:D12 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I10 | S04-C: MLN Tfr, d30 (%) | Sham 13.9 ± 1.8 (n=5), PSLN-212 18.0 ± 3.8 (n=5), PSLN-344 14.0 ± 3.2 (n=5), PSLN-212(Y) 7.40 ± 1.62 (n=5); PSLN-344/PSLN-212 = 0.8×; % of young: PSLN-212 244%, PSLN-344 189%; Tukey p (344 vs 212) 0.14, (344 vs young) 0.0084 | S04!A22:A26; S04!B22:B26; S04!C22:C26; S04!D22:D26 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I11 | S04-D: lung Treg, d7 (%) | Sham 5.88 ± 0.84 (n=3), PSLN-212 6.66 ± 0.34 (n=3), PSLN-344 2.99 ± 0.41 (n=3), PSLN-212(Y) 1.78 ± 0.59 (n=3); PSLN-344/PSLN-212 = 0.4×; % of young: PSLN-212 375%, PSLN-344 168%; Tukey p (344 vs 212) 0.00025, (344 vs young) 0.12 | S04!A29:A31; S04!B29:B31; S04!C29:C31; S04!D29:D31 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I12 | S05-D: lung Ki-67+ CD8 T cells, d3 (%) | Sham 0.83 ± 0.45 (n=5), PSLN-212 3.48 ± 1.35 (n=5), PSLN-344 9.38 ± 1.78 (n=5), PSLN-212(Y) 9.94 ± 3.03 (n=5); PSLN-344/PSLN-212 = 2.7×; % of young: PSLN-212 35%, PSLN-344 94%; Tukey p (344 vs 212) 0.0008, (344 vs young) 0.97 | S05!A19:A23; S05!B19:B23; S05!C19:C23; S05!D19:D23 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I13 | S05-E: lung GZMB+ CD8 T cells, d3 (%) | Sham 0.99 ± 0.38 (n=5), PSLN-212 2.99 ± 0.78 (n=5), PSLN-344 5.69 ± 0.90 (n=5), PSLN-212(Y) 9.61 ± 1.21 (n=5); PSLN-344/PSLN-212 = 1.9×; % of young: PSLN-212 31%, PSLN-344 59%; Tukey p (344 vs 212) 0.00084, (344 vs young) 1.3e-05 | S05!A26:A30; S05!B26:B30; S05!C26:C30; S05!D26:D30 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I14 | S05-F: MLN IFN-γ+ CD8 T cells after rgH5N1 restimulation, d14 (%) | Sham 0.67 ± 0.36 (n=5), PSLN-212 1.50 ± 0.39 (n=5), PSLN-344 6.36 ± 1.00 (n=5), PSLN-212(Y) 9.18 ± 0.90 (n=5); PSLN-344/PSLN-212 = 4.2×; % of young: PSLN-212 16%, PSLN-344 69%; Tukey p (344 vs 212) 6.5e-08, (344 vs young) 7.0e-05 | S05!A33:A37; S05!B33:B37; S05!C33:C37; S05!D33:D37 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I15 | S05-G: MLN IFN-γ+ CD8 T cells after rgH5N1 restimulation, d60 (%) | Sham 1.46 ± 1.07 (n=5), PSLN-212 3.04 ± 1.25 (n=5), PSLN-344 9.86 ± 2.81 (n=5), PSLN-212(Y) 14.4 ± 2.9 (n=5); PSLN-344/PSLN-212 = 3.2×; % of young: PSLN-212 21%, PSLN-344 69%; Tukey p (344 vs 212) 0.0008, (344 vs young) 0.024 | S05!A40:A44; S05!B40:B44; S05!C40:C44; S05!D40:D44 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I16 | S05-H: MLN GZMB+ CD8 T cells, d60 (%) | Sham 0.60 ± 0.39 (n=5), PSLN-212 1.02 ± 0.31 (n=5), PSLN-344 4.11 ± 1.12 (n=5), PSLN-212(Y) 5.55 ± 1.44 (n=5); PSLN-344/PSLN-212 = 4.0×; % of young: PSLN-212 18%, PSLN-344 74%; Tukey p (344 vs 212) 0.00049, (344 vs young) 0.11 | S05!A47:A51; S05!B47:B51; S05!C47:C51; S05!D47:D51 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I17 | S05-I: lung CD69+CD103+ resident-memory CD8 T cells, d25 (%) | Sham 0.58 ± 0.31 (n=5), PSLN-212 1.00 ± 0.37 (n=5), PSLN-344 3.96 ± 0.62 (n=5), PSLN-212(Y) 6.04 ± 0.60 (n=5); PSLN-344/PSLN-212 = 4.0×; % of young: PSLN-212 17%, PSLN-344 66%; Tukey p (344 vs 212) 3.3e-07, (344 vs young) 3.1e-05 | S05!A54:A58; S05!B54:B58; S05!C54:C58; S05!D54:D58 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I18 | S14-A H1N1: MLN IFN-γ+ CD8 T cells after CA09 restimulation (%) | Sham 0.82 ± 0.57 (n=5), PSLN-212 3.14 ± 1.77 (n=5), PSLN-344 11.0 ± 2.6 (n=5), PSLN-212(Y) 13.7 ± 2.5 (n=5); PSLN-344/PSLN-212 = 3.5×; % of young: PSLN-212 23%, PSLN-344 80%; Tukey p (344 vs 212) 6.7e-05, (344 vs young) 0.19 | S14!A3:A7; S14!B3:B7; S14!C3:C7; S14!D3:D7 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I19 | S14-A H3N2: MLN IFN-γ+ CD8 T cells after Aichi restimulation (%) | Sham 1.04 ± 0.58 (n=5), PSLN-212 3.58 ± 1.20 (n=5), PSLN-344 9.86 ± 1.79 (n=5), PSLN-212(Y) 14.0 ± 2.5 (n=5); PSLN-344/PSLN-212 = 2.8×; % of young: PSLN-212 26%, PSLN-344 71%; Tukey p (344 vs 212) 0.00011, (344 vs young) 0.0065 | S14!F3:F7; S14!G3:G7; S14!H3:H7; S14!I3:I7 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values |
| I20 | S13-I: serum IgG vs CA09, d28 after d14 boost | GMT: Sham 57, CMP-204 940, PSLN-212 4,411, PSLN-344 15,651, PSLN-212(Y) 40,739; PSLN-344/PSLN-212 = 3.5×; % of young: PSLN-212 11%, PSLN-344 38%; Tukey p (344 vs 212) 0.19, (344 vs young) 0.45 | S13!F53:F57; S13!G53:G57; S13!H53:H57; S13!I53:I57; S13!J53:J57 | geometric mean of reciprocal titres; one-way ANOVA + Tukey HSD on log2 titres |
| I21 | S13-J: serum IgG vs Aichi, d28 after d14 boost | GMT: Sham 101, CMP-204 474, PSLN-212 1,086, PSLN-344 12,435, PSLN-212(Y) 43,472; PSLN-344/PSLN-212 = 11.5×; % of young: PSLN-212 2%, PSLN-344 29%; Tukey p (344 vs 212) 3.1e-05, (344 vs young) 0.029 | S13!L53:L57; S13!M53:M57; S13!N53:N57; S13!O53:O57; S13!P53:P57 | geometric mean of reciprocal titres; one-way ANOVA + Tukey HSD on log2 titres |
| I22 | S13-A: serum IgG2a vs CA09, d14 | GMT: PSLN-212 83, PSLN-344 1,642, PSLN-212(Y) 4,642; PSLN-344/PSLN-212 = 19.7×; % of young: PSLN-212 2%, PSLN-344 35%; Tukey p (344 vs 212) 9.8e-07, (344 vs young) 0.011 | S13!A3:A7; S13!B3:B7; S13!C3:C7 | geometric mean of reciprocal titres; one-way ANOVA + Tukey HSD on log2 titres |
| I23 | S13-B: serum IgG1 vs CA09, d14 | GMT: PSLN-212 153, PSLN-344 887, PSLN-212(Y) 1,855; PSLN-344/PSLN-212 = 5.8×; % of young: PSLN-212 8%, PSLN-344 48%; Tukey p (344 vs 212) 1.8e-07, (344 vs young) 0.00096 | S13!E3:E7; S13!F3:F7; S13!G3:G7 | geometric mean of reciprocal titres; one-way ANOVA + Tukey HSD on log2 titres |
| I24 | IgG2a:IgG1 titre quotient vs CA09, d14 — recomputed per animal from S13-A ÷ S13-B | PSLN-212 0.58 ± 0.20; PSLN-344 2.14 ± 1.31; PSLN-212(Y) 2.97 ± 1.69. Printed S03-B columns read PSLN-212 2.97, PSLN-344 0.58, PSLN-212(Y) 2.14: the same 15 values with the three headers rotated by one position | S13!A3:A7…S13!C3:C7 ÷ S13!E3:E7…S13!G3:G7; printed quotient S03!G3:G7…S03!I3:I7 | row-wise IgG2a ÷ IgG1 (same row = same animal), arithmetic mean ± SD; matched to printed quotient values to 3 significant figures |
| I25 | IgG2a:IgG1 titre quotient vs Aichi, d14 — recomputed per animal from S13-C ÷ S13-D | PSLN-212 0.51 ± 0.25; PSLN-344 2.73 ± 1.78; PSLN-212(Y) 2.89 ± 0.80. Printed S03-F columns read PSLN-212 2.89, PSLN-344 0.51, PSLN-212(Y) 2.73: the same 15 values with the three headers rotated by one position | S13!I3:I7…S13!K3:K7 ÷ S13!M3:M7…S13!O3:O7; printed quotient S03!G10:G14…S03!I10:I14 | row-wise IgG2a ÷ IgG1 (same row = same animal), arithmetic mean ± SD; matched to printed quotient values to 3 significant figures |
| I26 | Restoration index across 26 single-time-point readouts where higher = stronger response (innate, DC, T-cell, B-cell, antibody; d14 single-dose titres as GMT) | PSLN-344 aged = median 73% of the young PSLN-212 value (IQR 62–83%, range 29–99%); PSLN-212 aged = median 21% (IQR 11–30%, range 3–53%) | blocks: S01-A 16h, S01-F, S02-A, S02-B, S02-C, S02-D CD40, S02-D CD86, S02-E, S03-A, S03-C, S03-D, S03-E, S03-G, S03-H, S03-K, S04-A ICOS-low, S04-A ICOS-high, S05-D, S05-E, S05-F, S05-G, S05-H, S05-I, S13-H, S14-A H1N1, S14-A H3N2 | for each block: group mean (GMT for titres) of aged arm ÷ group mean of PSLN-212(Y) ×100; median and IQR across blocks |
| M1 | S01-A 16h: lung Ifnb1 mRNA 16 h after adjuvant alone (fold vs untreated) | Sham 1.01 ± 0.48 (n=5), CMP-204 7.83 ± 1.75 (n=5), PSLN-212 16.6 ± 2.1 (n=5), PSLN-R848 5.05 ± 2.32 (n=5), PSLN-212/R848 24.3 ± 3.7 (n=5), PSLN-344 37.1 ± 4.8 (n=5), PSLN-212(Y) 37.6 ± 3.5 (n=5), PSLN-344(Y) 50.7 ± 7.6 (n=5); Tukey p (PSLN-344 vs PSLN-212) 3.7e-08; Tukey p (PSLN-344 vs PSLN-212(Y)) >0.99; Tukey p (PSLN-212 vs PSLN-212(Y)) 2.2e-08; Tukey p (PSLN-344(Y) vs PSLN-212(Y)) 0.00016 | S01!B3:F3; S01!B4:F4; S01!B5:F5; S01!B6:F6; S01!B7:F7; S01!B8:F8; S01!B9:F9; S01!B10:F10 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M2 | S01-A 72h: lung Ifnb1 mRNA 72 h | Sham 1.00 ± 0.17 (n=5), CMP-204 2.22 ± 0.36 (n=5), PSLN-212 3.43 ± 0.40 (n=5), PSLN-R848 1.24 ± 0.06 (n=5), PSLN-212/R848 1.67 ± 0.32 (n=5), PSLN-344 4.43 ± 1.69 (n=5), PSLN-212(Y) 1.59 ± 0.62 (n=5), PSLN-344(Y) 3.13 ± 0.85 (n=5); Tukey p (PSLN-344 vs PSLN-212) 0.42; Tukey p (PSLN-344 vs PSLN-212(Y)) 2.2e-05 | S01!H3:L3; S01!H4:L4; S01!H5:L5; S01!H6:L6; S01!H7:L7; S01!H8:L8; S01!H9:L9; S01!H10:L10 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M3 | S01-D: lung monocytes, day 4 (%) | Sham 10.4 ± 0.6 (n=5), PSLN-212 16.7 ± 1.6 (n=5), PSLN-344 30.6 ± 4.7 (n=5), PSLN-212(Y) 32.2 ± 3.9 (n=5); Tukey p (PSLN-344 vs PSLN-212) 2.0e-05; Tukey p (PSLN-344 vs PSLN-212(Y)) 0.84 | S01!B26:F26; S01!G26:K26; S01!L26:P26; S01!Q26:U26 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD within the 4 row |
| M3b | S01-D: lung monocytes, day 8 (%) | Sham 9.48 ± 0.85 (n=5), PSLN-212 9.66 ± 1.28 (n=5), PSLN-344 18.4 ± 0.6 (n=5), PSLN-212(Y) 14.1 ± 2.0 (n=5); Tukey p (PSLN-344 vs PSLN-212) 5.2e-08; Tukey p (PSLN-344 vs PSLN-212(Y)) 0.00033 | S01!B28:F28; S01!G28:K28; S01!L28:P28; S01!Q28:U28 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD within the 8 row |
| M4 | S01-E: lung CD11b+ DC, day 4 (%) | Sham 4.80 ± 2.10 (n=5), PSLN-212 8.28 ± 1.92 (n=5), PSLN-344 18.9 ± 8.6 (n=5), PSLN-212(Y) 21.4 ± 1.7 (n=5), PSLN-344(Y) 22.6 ± 2.9 (n=5); Tukey p (PSLN-344 vs PSLN-212) 0.0073; Tukey p (PSLN-344 vs PSLN-212(Y)) 0.88; Tukey p (PSLN-344(Y) vs PSLN-212(Y)) >0.99 | S01!B32:F32; S01!G32:K32; S01!L32:P32; S01!Q32:U32; S01!V32:Z32 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD within the 4 row |
| M4b | S01-E: lung CD11b+ DC, day 8 (%) | Sham 2.44 ± 0.24 (n=5), PSLN-212 6.04 ± 1.22 (n=5), PSLN-344 13.7 ± 2.8 (n=5), PSLN-212(Y) 9.48 ± 1.30 (n=5), PSLN-344(Y) 10.5 ± 1.7 (n=5); Tukey p (PSLN-344 vs PSLN-212) 4.2e-06; Tukey p (PSLN-344 vs PSLN-212(Y)) 0.0054 | S01!B34:F34; S01!G34:K34; S01!L34:P34; S01!Q34:U34; S01!V34:Z34 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD within the 8 row |
| M5 | S02-A: lung CCR7+ migratory CD11b+ DC, 72 h (%) | Sham 2.54 ± 0.66 (n=5), PSLN-212 7.28 ± 2.04 (n=5), PSLN-344 30.7 ± 7.9 (n=5), PSLN-212(Y) 35.0 ± 4.8 (n=5); Tukey p (PSLN-344 vs PSLN-212) 4.1e-06; Tukey p (PSLN-344 vs PSLN-212(Y)) 0.49 | S02!A3:A7; S02!B3:B7; S02!C3:C7; S02!D3:D7 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M6 | S02-D CD40: CD40+ of MLN CD11b+ DC, d3 (%) | Sham 3.96 ± 1.04 (n=5), PSLN-212 5.56 ± 1.12 (n=5), PSLN-344 11.2 ± 3.0 (n=5), PSLN-212(Y) 38.7 ± 7.3 (n=5); Tukey p (PSLN-344 vs PSLN-212) 0.16; Tukey p (PSLN-344 vs PSLN-212(Y)) 5.0e-08 | S02!A10:A14; S02!B10:B14; S02!C10:C14; S02!D10:D14 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M7 | S02-D CD86: CD86+ of MLN CD11b+ DC, d3 (%) | Sham 7.18 ± 1.51 (n=5), PSLN-212 8.13 ± 1.79 (n=5), PSLN-344 14.5 ± 2.7 (n=5), PSLN-212(Y) 37.9 ± 5.5 (n=5); Tukey p (PSLN-344 vs PSLN-212) 0.033; Tukey p (PSLN-344 vs PSLN-212(Y)) 3.0e-08 | S02!F10:F14; S02!G10:G14; S02!H10:H14; S02!I10:I14 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M8 | S02-E: OT-I proliferation driven by sorted MLN CD11b+ DC (%) | PSLN-212 0.77 ± 0.53 (n=5), PSLN-344 18.7 ± 2.8 (n=5), PSLN-212(Y) 26.2 ± 6.7 (n=5), PTX 2.55 ± 1.81 (n=5), PSLN-344(Y) 31.4 ± 6.7 (n=5); Tukey p (PSLN-344 vs PSLN-212) 3.4e-05; Tukey p (PSLN-344 vs PSLN-212(Y)) 0.095; Tukey p (PTX vs PSLN-344) 0.00013; Tukey p (PSLN-344(Y) vs PSLN-212(Y)) 0.39 | S02!K10:K14; S02!L10:L14; S02!M10:M14; S02!N10:N14; S02!O10:O14 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M9 | S02-F: lung Gm-csf mRNA at 36 h (fold) | PSLN-344 8.74 ± 2.15 (n=5), PSLN-212 1.59 ± 0.14 (n=5), Sham 1.21 ± 0.24 (n=5); Tukey p (PSLN-344 vs PSLN-212) 3.0e-06; Tukey p (PSLN-212 vs Sham) 0.88 | S02!B18:F18; S02!G18:K18; S02!L18:P18 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD within the 36h row |
| M10 | S02-G: lung Ly6C+ CD11c+MHC-II+ cells d5 ± recombinant GM-CSF (%) | GM-CSF 1.52 ± 0.33 (n=5), PSLN-212 5.86 ± 1.48 (n=5), PSLN-212+GM-CSF 13.8 ± 3.0 (n=5); Tukey p (PSLN-212 vs PSLN-212+GM-CSF) 9.2e-05 | S02!B22:B26; S02!C22:C26; S02!D22:D26 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M11 | S02-H: donor-derived (CD45.2+) monocyte-derived DC d3 after bone-marrow transfer, PSLN-344 + vaccine (%) | WT w/o cDC 19.7 ± 4.0 (n=5), WT w/ cDC 27.2 ± 7.2 (n=5), IFN w/o cDC 2.09 ± 0.93 (n=5), IFN w/ cDC 6.07 ± 1.27 (n=5), GMCSF 12.4 ± 3.7 (n=5); Tukey p (WT w/o cDC vs IFN w/o cDC) 1.3e-05; Tukey p (IFN w/o cDC vs GMCSF) 0.0063; Tukey p (WT w/o cDC vs GMCSF) 0.074 | S02!B30:B34; S02!C30:C34; S02!D30:D34; S02!E30:E34; S02!F30:F34 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M12 | S02-I: lung GZMB+ CD8 T cells d5 ± CCR2 antagonist (young animals) (%) | PSLN-344(Y) 6.77 ± 1.05 (n=5) vs PSLN-344(Y)+INCB3344 1.39 ± 0.46 (n=5); ratio 4.87; Student t p=6.0e-06 | S02!H30:H34 vs S02!I30:I34 | arithmetic mean ± SD; two-sided Student t |
| M13 | S07-B monocytes: lung CD11b+Ly6C+ monocytes ± CCR2 antagonist (%) | PSLN-344 9.86 ± 2.26 (n=5) vs PSLN-344+INCB3344 3.26 ± 1.37 (n=5); ratio 3.03; Student t p=0.00051 | S07!B10:B14 vs S07!C10:C14 | arithmetic mean ± SD; two-sided Student t |
| M14 | S07-B Ly6C+ Mphi: lung Ly6C+ macrophages ± CCR2 antagonist (%) | PSLN-344 15.4 ± 4.5 (n=5) vs PSLN-344+INCB3344 2.52 ± 0.61 (n=5); ratio 6.09; Student t p=0.00023 | S07!E10:E14 vs S07!F10:F14 | arithmetic mean ± SD; two-sided Student t |
| M15 | S11-C: recruited lung monocytes d3 ± carbenoxolone (%) | CBX- 7.28 ± 1.86 (n=5) vs CBX+ 3.08 ± 1.29 (n=5); ratio 2.36; Student t p=0.0032 | S11!B17:B21 vs S11!A17:A21 | arithmetic mean ± SD; two-sided Student t |
| M16 | S01-C: DiD+ alveolar macrophages 16 h, wild-type vs Sftpa1−/−Sftpd−/− (%) | WT 43.1 ± 4.1 (n=4) vs SPA/D 12.7 ± 3.0 (n=4); ratio 3.41; Student t p=2.1e-05 | S01!B20:E20 vs S01!B21:E21 | arithmetic mean ± SD; two-sided Student t |
| M17 | S01-B: SRB+ alveolar epithelial cells 16 h (%) | AECII/PSLN-SRB 15.8 ± 2.3 (n=5), AECI/PSLN-SRB 3.83 ± 1.14 (n=5), AECII/FreeSRB 0.38 ± 0.20 (n=5), AECI/FreeSRB 0.33 ± 0.18 (n=5); Tukey p (AECII/PSLN-SRB vs AECII/FreeSRB) 1.3e-11; Tukey p (AECII/PSLN-SRB vs AECI/PSLN-SRB) 5.9e-10 | S01!B14:F14; S01!B15:F15; S01!B16:F16; S01!B17:F17 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M18 | S05-C: proliferating OT-I CD8 T cells d4 ± pertussis toxin (%) | Lung 59.0 ± 5.0 (n=3), Lung+PTX 55.1 ± 9.5 (n=3), MLN 30.9 ± 3.9 (n=3), MLN+PTX 6.83 ± 0.80 (n=3); Tukey p (Lung vs Lung+PTX) 0.83; Tukey p (MLN vs MLN+PTX) 0.0037 | S05!A13:A15; S05!B13:B15; S05!C13:C15; S05!D13:D15 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M19 | S12-A: infiltrating donor monocytes d3 (young recipients) (%) | WT to WT 21.3 ± 4.2 (n=3) vs IFNAR-/- to WT 15.4 ± 2.5 (n=3); ratio 1.38; Student t p=0.1 | S12!A3:A5 vs S12!B3:B5 | arithmetic mean ± SD; two-sided Student t |
| M20 | S11-E: lung CD206+ macrophages (%) (time point not stated) | Sham 85.2 ± 7.8 (n=5), PSLN-212 71.5 ± 8.3 (n=5), PSLN-344 48.9 ± 8.1 (n=5), PSLN-212(Y) 35.5 ± 7.1 (n=5); Tukey p (PSLN-344 vs PSLN-212) 0.0017; Tukey p (PSLN-344 vs PSLN-212(Y)) 0.068 | S11!A31:A35; S11!B31:B35; S11!C31:C35; S11!D31:D35 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M21 | S07-A: lung Ly6C+CCR2+ macrophages on day 5 (×10^5 cells), as printed | PSLN-212 19.0 ± 5.5 (n=3) vs PSLN-344 3.42 ± 0.76 (n=3); Student t p=0.0081 — direction is opposite to S01-D/S07-B | S07!B5:D5 vs S07!E5:G5 | arithmetic mean ± SD (n=3); two-sided Student t |
| M22 | S07-C: lung Treg 4 d after transfer of sorted donor macrophages; both columns carry the same header "Ly6C-CD206+ MΦ" | column B 10.4 ± 2.1 (n=5) vs column C 5.14 ± 1.58 (n=5); Student t p=0.0021 — which column is the Ly6C+CD206− subset cannot be told from the file | S07!B16:B20 vs S07!C16:C20 | arithmetic mean ± SD; two-sided Student t |
| M23 | Effect of manganese (PSLN-344 ÷ PSLN-212) in aged versus young mice, for the five blocks that contain all four arms | lung Ifnb1 16 h [S01-A 16h]: aged ×2.23, young ×1.35, interaction p=0.11; lung CD11b+ DC d4 [S01-E]: aged ×2.28, young ×1.06, interaction p=0.04; lung cDC1 72 h [S01-F]: aged ×1.65, young ×1.02, interaction p=0.0053; antigen+ DC in lymph node 36 h [S02-C]: aged ×4.01, young ×1.18, interaction p=0.01; DC-driven OT-I proliferation [S02-E]: aged ×24.35, young ×1.20, interaction p=0.011 | S01!B5:F5, B8:F10; S01!G32:Z32; S01!G36:Z36; S02!K3:M7, O3:O7; S02!K10:M14, O10:O14 | ratio of arm means; two-way ANOVA (age × manganese), p-value of the interaction term |
| M24 | S01-F: lung type 1 (cross-presenting) dendritic cells, 72 h (%) | Sham 17.9 ± 2.5 (n=5), PSLN-212 22.8 ± 3.6 (n=5), PSLN-344 37.5 ± 7.0 (n=5), PSLN-212(Y) 43.4 ± 5.3 (n=5), PSLN-344(Y) 44.3 ± 1.6 (n=5); Tukey p (PSLN-344 vs PSLN-212) 0.00034; Tukey p (PSLN-344 vs PSLN-212(Y)) 0.26 | S01!B36:F36; S01!G36:K36; S01!L36:P36; S01!Q36:U36; S01!V36:Z36 | arithmetic mean ± SD; one-way ANOVA + Tukey HSD |
| M25 | S11-D: lung NK cells, aged mice (%), n=5 per arm per day | day 2: PSLN-344 34.0, PSLN-212 28.8, vaccine alone 28.5 (Tukey p 344 vs 212 0.15; 344 vs vaccine 0.12); day 4: PSLN-344 31.1, PSLN-212 24.7, vaccine alone 27.5 (Tukey p 344 vs 212 0.13; 344 vs vaccine 0.57); day 6: PSLN-344 23.9, PSLN-212 21.8, vaccine alone 24.3 (Tukey p 344 vs 212 0.76; 344 vs vaccine >0.99); day 8: PSLN-344 24.1, PSLN-212 25.5, vaccine alone 25.9 (Tukey p 344 vs 212 0.81; 344 vs vaccine 0.65) | S11!B24:U28 | arithmetic mean; one-way ANOVA + Tukey HSD across the four arms within each day |
| M26 | S11-A: lung alveolar macrophages, aged mice (%), n=5 per arm per day | day 2: PSLN-344 29.6, PSLN-212 28.2, vaccine alone 22.6 (Tukey p 344 vs 212 0.95; 344 vs vaccine 0.065); day 4: PSLN-344 32.3, PSLN-212 30.9, vaccine alone 20.7 (Tukey p 344 vs 212 0.97; 344 vs vaccine 0.0087); day 6: PSLN-344 31.0, PSLN-212 27.5, vaccine alone 21.5 (Tukey p 344 vs 212 0.38; 344 vs vaccine 0.002); day 8: PSLN-344 28.8, PSLN-212 23.9, vaccine alone 22.4 (Tukey p 344 vs 212 0.15; 344 vs vaccine 0.042) | S11!B3:U7 | arithmetic mean; one-way ANOVA + Tukey HSD across the four arms within each day |
| D1 | S08-A: lung Ifnb1 16 h vs dose (fold; n=3 per dose; age of animals not stated) | 1 µg: PSLN-212 1.4, PSLN-344 1.4, CMP-204 1.0; 5 µg: PSLN-212 4.1, PSLN-344 8.3, CMP-204 3.8; 10 µg: PSLN-212 8.9, PSLN-344 21.1, CMP-204 6.3; 20 µg: PSLN-212 12.6, PSLN-344 45.8, CMP-204 7.3; 40 µg: PSLN-212 14.9, PSLN-344 50.2, CMP-204 8.0 | S08!B3:J7 | arithmetic mean of 3 animals per dose |
| D2 | S08-A Hill fit: E = 1 + (Emax−1)·d^h/(ED50^h + d^h) | PSLN-212: Emax 16.6 (SE 1.8), ED50 10.8 µg (SE 2.0); PSLN-344: Emax 58.7 (SE 6.6), ED50 13.3 µg (SE 1.9); PSLN-344 at 10 µg (21.1) exceeds PSLN-212 at 40 µg (14.9) | S08!E3:J7 | non-linear least squares on ln(fold) for the 15 animals per preparation; baseline fixed at 1 |
| D3 | S08-B: encapsulation efficiency (%) | CMP-204 65.2 ± 6.0 (n=3), PSLN-212 59.6 ± 4.6 (n=3), PSLN-R848 61.3 ± 6.8 (n=3), PSLN-212/R848 52.4 ± 7.3 (n=3), PSLN-344 54.8 ± 5.1 (n=3); Tukey p (PSLN-344 vs PSLN-212) 0.86 | S08!A11:O11 | arithmetic mean ± SD of 3 preparations; one-way ANOVA + Tukey |
| D4 | S08-C: SRB+ alveolar epithelial cells 16 h, Mn-free vs Mn-containing particle; compared with S01-B | as printed: AEC-II 15.8% (PSLN-SRB) vs 3.8% (PSLN-344-SRB); AEC-I 13.8% vs 3.0%. S01-B gives AEC-II 15.8% and AEC-I 3.8% for PSLN-SRB, so the printed AEC-I/PSLN-SRB value (13.8%) conflicts with S01-B (3.8%); if the two middle headers of S08-C are transposed the blocks agree (AEC-II 15.8% vs 13.8%; AEC-I 3.8% vs 3.0%) | S08!A14:D18; S01!B14:F15 | arithmetic mean of 5 animals per column |
| S1 | S08-D: body weight after intranasal immunisation (CA09 vaccine + 20 µg adjuvant; n=5; 10 days) — per-animal nadir, % of day-0 weight | Vaccine 98.2 ± 1.1; PSLN-212 97.0 ± 1.7; PSLN-344 96.4 ± 1.5; PSLN-212(Y) 97.6 ± 1.3; CMP-204 95.9 ± 2.0; PSLN-212/R848 90.0 ± 5.0; Tukey p: PSLN-344 vs Vaccine 0.86 (unadjusted t p=0.06); PSLN-212/R848 vs Vaccine 0.0003 | S08!B21:AE26 | per-animal minimum over days 2–10; arithmetic mean ± SD; one-way ANOVA + Tukey across the six arms |
| S2a | S08-D: body weight on day 10, PSLN-344 | 99.8 ± 0.7 (n=5) % of day-0 weight | S08!Q26:U26 | arithmetic mean ± SD of animals with a day-10 value |
| S2b | S08-D: body weight on day 10, PSLN-212/R848 | 90.6 ± 6.2 (n=4) % of day-0 weight | S08!V26:Z26 | arithmetic mean ± SD of animals with a day-10 value |
| S2c | S08-D: body weight on day 10, Vaccine | 100.2 ± 0.1 (n=5) % of day-0 weight | S08!AA26:AE26 | arithmetic mean ± SD of animals with a day-10 value |
| S3 | S09-A first panel (16 h): lung cytokine mRNA after adjuvant alone, aged PSLN-344 vs young PSLN-212 (fold ratio) | Ifnb1 0.96× (p=>0.99); Il6 0.6× (p=0.84); Ccl2 0.42× (p=0.55); Ccl3 0.52× (p=0.78); Ccl5 0.32× (p=0.045); Tnf 2.9× (p=0.058); Il10 4× (p=0.0063) | S09!Q3:S9 vs S09!T3:V9 | difference of mean log10 values (n=3 each) back-transformed (10^Δ); Tukey HSD on log10 values across the 7 arms |
| S4 | S09-A second panel (printed "16h"; its Ifnb1 row equals log10 of S01-A 72 h values → read as 72 h): aged PSLN-344 vs young PSLN-212 (fold ratio) | Ifnb1 2.9× (p=0.034); Il6 2.3× (p=0.082); Ccl2 0.27× (p=0.0032); Ccl3 0.22× (p=0.0013); Ccl5 3.7× (p=0.026); Tnf 18× (p=8.2e-07); Il10 37× (p=6.2e-05) | S09!AN3:AP9 vs S09!AQ3:AS9 | as S3 |
| S5 | S09-A second panel (72 h): aged PSLN-344, fold over PBS | Ifnb1 4×; Il6 7.2×; Ccl2 27×; Ccl3 9.2×; Ccl5 2×; Tnf 8.4×; Il10 4.2×; aged PSLN-212: Il6 1.9×; Ccl2 5.2×; Tnf 5.2×; Il10 4.2× | S09!AN3:AP9, S09!AE3:AG9 (PBS S09!Y3:AA9) | 10^(mean log10), n=3 |
| S6 | S09-A: PSLN-212/R848 at 16 h and 72 h, fold over PBS | 16 h: Tnf 202×, Il10 179×; 72 h: Tnf 50×, Il10 45×, Il6 34× | S09!N3:P9; S09!AK3:AM9 | 10^(mean log10), n=3 |
| S7a | S10-A: CNS Ifnb1 mRNA 36 h after intranasal bivalent vaccine ± adjuvant (aged; fold vs untreated) | PBS 1.00 ± 0.23 (n=5), Sham 1.17 ± 0.34 (n=5), PSLN-344 1.32 ± 0.41 (n=5), CT 5.50 ± 1.19 (n=5); Tukey p: PSLN-344 vs PBS 0.87, PSLN-344 vs Sham 0.98, cholera toxin vs PBS 5.3e-08; unadjusted t PSLN-344 vs PBS p=0.164 | S10!A3:A7; S10!B3:B7; S10!C3:C7; S10!D3:D7 | arithmetic mean ± SD (n=5); one-way ANOVA + Tukey |
| S7b | S10-A: CNS Tnf mRNA 36 h after intranasal bivalent vaccine ± adjuvant (aged; fold vs untreated) | PBS 1.00 ± 0.22 (n=5), Sham 1.32 ± 0.39 (n=5), PSLN-344 1.59 ± 0.49 (n=5), CT 3.50 ± 1.22 (n=5); Tukey p: PSLN-344 vs PBS 0.54, PSLN-344 vs Sham 0.92, cholera toxin vs PBS 0.00018; unadjusted t PSLN-344 vs PBS p=0.037 | S10!F3:F7; S10!G3:G7; S10!H3:H7; S10!I3:I7 | arithmetic mean ± SD (n=5); one-way ANOVA + Tukey |
| S7c | S10-A: CNS Isg15 mRNA 36 h after intranasal bivalent vaccine ± adjuvant (aged; fold vs untreated) | PBS 1.00 ± 0.34 (n=5), Sham 1.04 ± 0.17 (n=5), PSLN-344 1.13 ± 0.21 (n=5), CT 2.68 ± 0.74 (n=5); Tukey p: PSLN-344 vs PBS 0.96, PSLN-344 vs Sham 0.99, cholera toxin vs PBS 7.0e-05; unadjusted t PSLN-344 vs PBS p=0.482 | S10!K3:K7; S10!L3:L7; S10!M3:M7; S10!N3:N7 | arithmetic mean ± SD (n=5); one-way ANOVA + Tukey |
| S8 | S11-B ("neutrophils") vs S11-A ("alveolar macrophages"): cell-by-cell identity | 35/100 cells identical; 34 of the 40 cells in the first two replicate columns of each arm are identical | S11!B3:U7 vs S11!B10:U14 | positional comparison of the two 5-day × 20-column grids |
| Q1 | S06-D (bivalent→rgH5N1, challenge d3) vs S06-C (challenge d14) | all 28 (day, status) rows are identical | S06!M3:Q30 vs S06!A34:E61 | row-wise comparison |
| Q2 | Deaths implied by the body-weight block vs deaths in the paired time-to-event table (same-named arms) | S13-F/S03-I PSLN-212: weights imply 4 dead, table says 7; S13-G/S03-J Sham: weights imply 5 dead, table says 9; S15-C/S06-C PSLN-212: weights imply 6 dead, table says 5; S15-D/S06-D PSLN-212(Y): weights imply 2 dead, table says 0; S15-D/S06-D PSLN-344: weights imply 2 dead, table says 0; S15-E/S06-E (r34-68) PSLN-212: weights imply 6 dead, table says 7; S15-E/S06-E (r34-68) PSLN-344: weights imply 1 dead, table says 2; S15-G/S06-G PSLN-344: weights imply 2 dead, table says 3; S15-M/S15-L PSLN-212(Y): weights imply 0 dead, table says 1; S09-G/S09-F Sham: weights imply 8 dead, table says 7 | paired blocks listed | weight trace blank after a day, or terminal value repeated unchanged to d14, counted as a death |
| Q3 | S09-A Ifnb1 rows matched against log10 of S01-A values | panel1 vs S01-A 16h: 21/21; panel1 vs S01-A 72h: 0/21; panel2 vs S01-A 16h: 0/21; panel2 vs S01-A 72h: 21/21 | S09!B3:V3, S09!Y3:AS3 vs S01!B3:F10, S01!H3:L10 | each S09-A Ifnb1 value searched among log10(S01-A) values of the same arm, tolerance 0.002 |
| Q4 | S03-I (time to event) vs S13-F (body weight, "the animals of S03-I"): arm names | S03-I arms: Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y); S13-F arms: PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naïve. S13-F "PSLN-212" has 3 animals that regain weight and 4 whose last value is carried forward = the 3 alive/4 dead of the S03-I "CMP-204" column; S13-F "Naïve" has all 7 traces ending by day 6 = S03-I "PSLN-212" (all dead by day 6) | S03!A16:F51; S13!B32:AJ40 | comparison of header rows; deaths inferred from weight traces (blank after a day, or terminal value repeated to d14) |
| Q5 | S03-J (time to event) vs S13-G (body weight, "the animals of S03-J"): arm names and n | S03-J arms: Sham, PSLN-212, PSLN-344 (label n=9; 10 status rows per arm; PSLN-344 has 9 day values). S13-G arms: PSLN-344, Sham, Naïve (n=10 each). S13-G "Naïve" shows 9 animals with carried-forward weights and 1 recovering = S03-J "Sham" (9 dead, 1 alive); S13-G "Sham" shows 5 traces carried forward from day 10–12, 1 still falling at day 14 and 4 recovering — closer to S03-J "PSLN-212" (7 dead on days 10–12, 3 alive) than to S03-J "Sham" (9 dead) | S03!G16:J46; S13!B42:AE50 | as Q4 |
| Q6 | Body-weight values shared between nominally different experiments | S15-C PSLN-344 (challenge d14) vs S15-I Vaccine+PSLN-344 (challenge d3): 40/42 values identical over days 2–12; S09-C day-12 row identical for PSLN-212Y and PSLN-344Y (8/8); S15-M PSLN-212(Y) animal 4 = S09-E PSLN-344Y animal 5 at all 7 post-challenge time points; S09-E PSLN-212Y animal 8 = S09-G PSLN-212Y animal 8 at all 7 time points | S15!W24:AC29 vs S15!W73:AC78; S09!G18:N18 vs S09!W18:AD18; S15!L104:L110 vs S09!AA40:AA46; S09!N40:N46 vs S09!N67:N73 | exact equality of values at the same day/position |
| Q7 | Stated n (block label) vs observations present | S03-J label n=9, 10 rows per arm; S05-A and S05-B label n=3, 2 values per arm per day; S13-E label n=5, 7 rows per arm; S09-F Sham 7 rows while S09-G Sham has 8 weight columns; S08-D PSLN-212/R848 4 values on day 10 (cell W26 empty) | S03!H17:J46; S05!B3:I5, S05!B8:I10; S13!S3:V30; S09!B66:B72 vs S09!O66:V66; S08!V26:Z26 | row/column counts |
| Q8 | S15-L (young C57BL/6, PSLN-212(Y)) vs S15-M weights | time-to-event table: 6/7 alive, one death on day 12 (S15!A124,E124); weight block: all 7 animals have a day-14 weight (97.3–103.0% of baseline) | S15!E124:E130; S15!I110:O110 | row count vs non-empty day-14 weights |
| P1 | Power of the existing design and sample size for the confirmatory study (two-sided Fisher exact, α=0.05, exact enumeration) | n=7/arm: power 0.67 for 81% vs 10%, 0.16 for 81% vs 40%; n needed per arm for 80% power: 8 (81% vs 10%), 25 (81% vs 40%), 34 (95% vs 67%) | planning values taken from E11 and E15 | exact binomial enumeration of Fisher-test rejections |

## Appendix B. Conflicts in the record and how each was handled

| No. | Blocks | What the file shows | Effect on the conclusions | What I did |
|:-----|:--------------|:----------------------------------------|:------------------------|:----------------------|
| B1 | S06-D vs S06-C; S15-D | S06-D (bivalent vaccine, rgH5N1 challenge on day 3) is identical to S06-C (challenge on day 14) in all 28 rows. The weight block for S06-D (S15-D) shows two PSLN-344 animals and two young animals whose last weight is carried forward to day 14, which is how dead animals appear elsewhere in the sheet. The table shows no deaths in either arm. | The day-3 rgH5N1 result (7/7) is not independent evidence and may be wrong. | Excluded S06-D from the pooled estimate (sensitivity: E11-s1). Early protection is cited from S06-B, S15-H and S03-J only. [Q1, Q2] |
| B2 | S03-I vs S13-F | Same animals, different arm names. Survival table: Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y). Weight block: PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naïve. The weight-block arm called PSLN-212 (3 recover, 4 die) matches the survival column headed CMP-204. The weight-block arm called Naïve (all gone by day 8) matches the survival column headed PSLN-212. | PSLN-344 is 7/7 either way. Aged PSLN-212 is 0/7 as printed, or 3/7 if the weight-block names are right. | Primary analysis as printed. Sensitivity with the alternative reading: E11-s2. [Q4] |
| B3 | S03-J vs S13-G | Survival table arms: Sham, PSLN-212, PSLN-344. Weight block arms: PSLN-344, Sham, Naïve. Block label says n=9; there are 10 rows per arm. One PSLN-344 row has a status but no day (S03!G46 is empty). The age of the animals and the challenge dose are not stated. The annotation says observation ran 22 days; survivors are recorded at day 21. | PSLN-344 is 10/10 (9 with a recorded day) either way. The comparator that survived 3/10 is either PSLN-212 or the empty-liposome control, so the contribution of manganese in the wild-type H5N1 model is unconfirmed. | Reported on its own (E18). Not pooled. [Q5, Q7] |
| B4 | S03-B, S03-F vs S13-A to S13-D | The printed IgG2a:IgG1 quotients are exactly the per-animal ratios S13-A ÷ S13-B and S13-C ÷ S13-D, but with the three column headers rotated by one position. | As printed, PSLN-344 would look IgG1-skewed (0.58 and 0.51). Recomputed: PSLN-344 2.14 and 2.73; PSLN-212 0.58 and 0.51; young 2.97 and 2.89. | Used the recomputed ratios. The S13 labels are the ones that agree with total IgG in S03-A and S03-E. [I24, I25] |
| B5 | S09-A, second panel (columns X to AS) | Printed '16h', like the first panel. Its Ifnb1 row equals log10 of the S01-A 72 h values in 21 of 21 cells. The first panel matches the S01-A 16 h values in 21 of 21. | Read as 16 h, the two panels would look like discordant replicates. | Treated as the 72 h panel. [Q3, S4, S5] |
| B6 | Body-weight blocks (S13-F, S13-G, S15-A to S15-O, S09-C/E/G) | (a) After death, some arms are left blank and others carry the last value forward unchanged. (b) Identical values recur between experiments: S15-C PSLN-344 and S15-I Vaccine+PSLN-344 share 40 of 42 values over days 2 to 12; the S09-C day-12 row is the same for two arms; single animals are identical between S15-M and S09-E and between S09-E and S09-G. (c) Deaths implied by the weights differ from the survival table in ten arms. | Mean weights would be biased if carried-forward values were averaged. The weight blocks are not independent confirmation of survival. | Survival tables are primary. Weights are used only to describe morbidity, with carried-forward tails removed (rule in Appendix C), and as a sensitivity check (E11-s3). [Q2, Q6] |
| B7 | 'Untreated' arms of S06-E, S06-F, S06-G (rows 34–105) | Per the annotation these are 20-month animals given no vaccine, no adjuvant and no challenge virus. 4 of 21 died within the 14-day window (1, 0 and 3). | They are not infection controls. They show the background death rate at about 22 months, which matters for reading the day-60 results. | Used as the background death rate. [E16, E16b] |
| B8 | S11-B vs S11-A | 'Neutrophils' (S11-B) and 'alveolar macrophages' (S11-A) share 35 of 100 values, 34 of them in the first two replicate columns of each arm. The annotation says the two blocks came from lungs harvested in different ways. | Neutrophil influx, a basic lung-safety readout, cannot be assessed. | S11-B not used. [S8] |
| B9 | S07-A | As printed, Ly6C+CCR2+ macrophages expand with PSLN-212 (19.0 × 10⁵ on day 5) and not with PSLN-344 (3.4 × 10⁵). S01-D shows more monocytes with PSLN-344 (30.6% against 16.7%), and S07-B shows 15.4% Ly6C+ macrophages with PSLN-344. | Either the two headers are swapped, or PSLN-212 diverts monocytes to macrophages. The file cannot tell which. | Not used. [M21] |
| B10 | S07-C | Both columns carry the header 'Ly6C-CD206+ MΦ'. The annotation says one should be Ly6C+CD206−. | The direction of the macrophage effect on regulatory T cells is unknown. | Not used. [M22] |
| B11 | S08-C vs S01-B | S08-C prints 13.8% uptake for type I epithelial cells with PSLN-SRB. S01-B gives 3.8% for the same particle, cell type, dose and time. Transposing the two middle headers of S08-C reconciles the blocks. | Whether manganese changes epithelial uptake: four-fold lower as printed, unchanged if transposed. Neither reading shows higher uptake. | Cited only for 'not higher'. [D4] |
| B12 | Stated n vs observations present | S03-J: label n=9, 10 rows per arm. S05-A, S05-B: label n=3, 2 values per arm per day. S13-E: label n=5, 7 rows per arm. S09-F: the empty-liposome arm has 7 rows while its weight block has 8 animals (the annotation attributes the 7 to S09-B, where there are 8). S08-D: PSLN-212/R848 has 4 values on day 10. | Minor. | Used the observations present. [Q7] |
| B13 | S05-A, S05-B, S05-I | The annotation gives two incompatible immunisations for S05-A (ovalbumin; bivalent vaccine), and S05-B and S05-I refer back to it. The tetramer is NP366–374, which is presented by H-2Db (C57BL/6) and not by BALB/c (general knowledge, not from the file). n = 2 per arm per day in S05-A and S05-B. | Tetramer kinetics and the resident-memory block are weaker evidence than their labels suggest. | S05-A and S05-B not used for any conclusion. S05-I appears only as one of the 26 readouts in I26 and Figure 2. |
| B14 | S15-L vs S15-M | The survival table has one death on day 12 in the young C57BL/6 arm. The weight block shows all seven young animals at 97–103% of baseline on day 14. | The young benchmark is 62/63 or 63/63. | As printed. [Q8] |
| B15 | S15-L to S15-O; S15-J | The challenge virus and the interval from vaccination to challenge are not stated for the C57BL/6 and Swiss Webster experiments. The interval is not stated for the PR8 challenge in the imprinting experiment. | These experiments cannot be classed as matched-strain or cross-subtype. | Kept in the pooled estimate as evidence across strains, and also shown separately. [E13, E14] |
| B16 | S03-C, S03-G | HAI values of 0 in the empty-liposome arm. Per the annotation the lowest dilution tested was 1:10. | A geometric mean needs a positive value. | Set to 5, half the lowest dilution. [I2, I5] |
| B17 | S08, rows 89–101 | Unlabelled region: 14 in column A, zeros in columns C and D. | Cannot be interpreted. | Excluded. |
| B18 | S08-A, S08-B | The fourth arm of S08-A is headed 'PSLN-344/R848', a preparation that is not in the materials list (elsewhere the R848 combination is PSLN-212/R848). The age of the S08-A animals is not stated. S08-B says encapsulation was read from CDN-1807 absorbance, but CMP-204 and PSLN-R848 contain no CDN-1807. | Minor. | Fourth arm of S08-A not used. S08-B used only for PSLN-344 against PSLN-212. |
| B19 | S09-A vs S01-A | The control arm is called PBS in S09-A and Sham in S01-A, yet holds the same animals (values identical after log10). Per the annotation PBS is buffer and Sham is empty liposome. | Minor: the identity of the baseline arm for the lung cytokine data. | Noted. |
| B20 | S06 sheet labels | The labels S06-E and S06-F are each used for two different experiments (rows 34–68 and rows 71–105). | Risk of citing the wrong block. | Referred to by row range in the ledger. |
| B21 | Conditions not stated | Time point: S07-B, S11-E, S13-H, S14-A. Age of animals: S02-G, S08-A, S03-J, S05-C. Which adjuvant the PTX arm received: S02-C, S02-E. | Minor for the conclusions drawn here. | Cited with the gap noted in the ledger. |
| B22 | Described in the annotation, absent from the workbook | The annotation mentions C57BL/6 mice at 15 months, particle size, zeta potential and electron microscopy. The workbook has no block for any of them. | No particle characterisation beyond encapsulation efficiency can be checked. | Listed as a gap (section 3.5). |

## Appendix C. Methods

**Reading the workbook.** Every numeric cell was assigned to a block using the layout in the annotation. The only numeric cells left unassigned are axis labels (days, doses) and the unlabelled region in S08 rows 89–101. Group names were kept exactly as printed. The parsed values, each with its cell address, are in `analysis/tidy_observations.csv` and `analysis/tidy_time_to_event.csv`.

**Time to event.** Status 1 is a death or endpoint on that day. Status 0 is alive at the end of observation. Within an experiment, arms were compared with a two-sided log-rank test. For the pooled comparison, the log-rank observed-minus-expected counts and their variances were summed over experiments, so each experiment is its own stratum. The hazard ratio is the Peto one-step estimate. Proportions have exact (Clopper–Pearson) 95% confidence intervals.

**Single-time-point blocks.** Arithmetic mean and SD of the per-animal values. One-way ANOVA with Tukey's test across all arms printed in the block, or Student's t-test for two-arm blocks.

**Time-course and dose blocks.** Tukey's test across arms within each time point or dose.

**Titres.** Analysed on the log2 scale and summarised as geometric means. HAI values printed as 0 were set to 5.

**S09-A.** The block is on a log10 scale. Means were taken on that scale and back-transformed to fold-change.

**Restoration index (I26, Figure 2).** For each of 26 readouts where a higher value means a stronger response: the aged-arm mean (GMT for titres) divided by the young PSLN-212 mean. The median and interquartile range are taken across readouts.

**Dose-response (D2).** Least-squares fit of E = 1 + (Emax − 1)·dⁿ / (ED50ⁿ + dⁿ) to ln(fold-change), using the 15 animals per preparation.

**Body weight.** An animal was classed as dead from its trace if the trace goes blank after some day, if its last three or more values are identical, or if its last two values are identical and below 90%. Carried-forward values were not used in any mean.

**Biomarker screen (`analysis/biomarker_screen.csv`).** For each readout, the area under the ROC curve for separating animals in the protected arms (aged PSLN-344, young PSLN-212) from animals in the unprotected arms (aged empty-liposome control, aged PSLN-212).

**Sample sizes (P1).** Power of a two-sided Fisher exact test at α = 0.05, by exact enumeration.

**Multiplicity.** p-values are not adjusted across blocks and are descriptive. The pooled survival comparison is the only one I treat as confirmatory.

**Limits.** No animal can be linked between blocks, so every association between a biomarker and protection is at group level. I had the workbook and the annotation only: no instrument files and no protocol.

**Statements that are not from the file.** These are general knowledge and are marked as such where they appear: the HAI 1:40 benchmark; the formats of licensed seasonal vaccines; where a nasal spray deposits; variation in human STING; the H-2 restriction of the NP366–374 epitope; the olfactory route by which manganese can reach the brain; the facial-palsy precedent for a toxin-adjuvanted nasal vaccine; and, following from those, the manganese, olfactory and neurological endpoints chosen for Study 5.

**Checks.** `analysis/verify_ledger.py` re-reads the cell ranges quoted in the ledger directly from the workbook dump and recomputes 601 values; all agree. The pooled survival comparison was repeated in R with the `survival` package (`analysis/crosscheck_survival.R`) and gave the same statistic (χ² = 72.5).

**Software.** Python 3.11 with pandas, SciPy 1.17, statsmodels 0.15 and lifelines 0.30. The scripts are in `analysis/`; `analysis/run_all.sh` regenerates every number, figure and this memo from the workbook.

"""Post-challenge morbidity from body-weight blocks.
Per animal: nadir (% of own day-0 weight) and final-day weight. Animals classed as dead from the weight trace
(blank after a day, or last value carried forward unchanged to the end) are excluded from 'survivor' summaries;
their frozen tail is not used."""
import pandas as pd, numpy as np
from scipy import stats
from bw_vs_surv import bw_infer, PAIRS
from parse_blocks import OBS
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500)
rows=[]
for bw, sv in PAIRS:
    B = bw_infer(bw)
    d = OBS[OBS.block==bw].copy(); d['day']=d.row_label.astype(float)
    for g in B.group.unique():
        b = B[B.group==g]
        alive = b[b.status=='alive']
        x = d[(d.group==g)&(d.rep.isin(alive.rep))]
        nad = x.groupby('rep')['value'].min()
        nad_day = x.loc[x.groupby('rep')['value'].idxmin(), 'day']
        fin = x[x.day==x.day.max()].set_index('rep')['value']
        rows.append(dict(bw_block=bw, surv_block=sv, group=g, n=len(b), n_alive_bw=len(alive),
                         nadir_mean=nad.mean() if len(nad) else np.nan, nadir_sd=nad.std() if len(nad)>1 else np.nan, nadir_min=nad.min() if len(nad) else np.nan,
                         nadir_day_median=np.median(nad_day) if len(nad_day) else np.nan,
                         final_mean=fin.mean() if len(fin) else np.nan, final_min=fin.min() if len(fin) else np.nan,
                         n_final_below_95=int((fin<95).sum()) if len(fin) else 0, n_final_below_90=int((fin<90).sum()) if len(fin) else 0))
M = pd.DataFrame(rows)
M.to_csv('bw_morbidity_survivors.csv', index=False)
print(M.to_string(float_format=lambda x: f'{x:.1f}'))

# pooled comparison: survivors' nadir PSLN-344 (aged) vs PSLN-212(Y), per experiment and overall
print('\nSurvivor nadir, PSLN-344 (aged) vs PSLN-212(Y):')
allA=[]; allY=[]
for bw in ['S13-F','S15-A','S15-B','S15-C','S15-D','S15-E','S15-F','S15-G','S15-M','S15-O']:
    B = bw_infer(bw); d = OBS[OBS.block==bw]
    def nad(g):
        al = B[(B.group==g)&(B.status=='alive')].rep
        return d[(d.group==g)&(d.rep.isin(al))].groupby('rep')['value'].min().values
    a = nad('PSLN-344'); y = nad('PSLN-212(Y)')
    allA += list(a); allY += list(y)
    print(f'  {bw}: PSLN-344 {a.mean():.1f} (n={len(a)})  young {y.mean():.1f} (n={len(y)})  t-test p={stats.ttest_ind(a,y).pvalue:.3f}')
print(f'  pooled: PSLN-344 {np.mean(allA):.1f}±{np.std(allA,ddof=1):.1f} (n={len(allA)})  young {np.mean(allY):.1f}±{np.std(allY,ddof=1):.1f} (n={len(allY)})  p={stats.ttest_ind(allA,allY).pvalue:.3g}')

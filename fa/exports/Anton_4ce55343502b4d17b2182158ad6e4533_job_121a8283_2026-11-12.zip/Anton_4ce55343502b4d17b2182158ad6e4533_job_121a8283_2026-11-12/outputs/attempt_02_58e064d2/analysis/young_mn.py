import numpy as np, pandas as pd, itertools, warnings
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from parse_blocks import OBS
warnings.filterwarnings('ignore')
for blk, row in [('S01-A 16h',None),('S01-A 72h',None),('S01-E','4'),('S01-E','8'),('S01-F',None),('S01-G',None),('S02-C',None),('S02-E',None)]:
    x = OBS[OBS.block==blk]
    if row is not None: x = x[x.row_label==row]
    tk = pairwise_tukeyhsd(x['value'], x['group'])
    res = {frozenset(k): p for k,p in zip(itertools.combinations(tk.groupsunique,2), tk.pvalues)}
    a = x[x.group=='PSLN-344(Y)'].value; b = x[x.group=='PSLN-212(Y)'].value
    print(f'{blk} {row or ""}: PSLN-344(Y) {a.mean():.2f}±{a.std(ddof=1):.2f} vs PSLN-212(Y) {b.mean():.2f}±{b.std(ddof=1):.2f}; ratio {a.mean()/b.mean():.2f}; Tukey p={res[frozenset(["PSLN-344(Y)","PSLN-212(Y)"])]:.3g}; t p={stats.ttest_ind(a,b).pvalue:.3g}')
    if 'PSLN-344' in set(x.group):
        c = x[x.group=='PSLN-344'].value
        print(f'      aged PSLN-344 {c.mean():.2f} vs PSLN-344(Y): Tukey p={res[frozenset(["PSLN-344(Y)","PSLN-344"])]:.3g}')

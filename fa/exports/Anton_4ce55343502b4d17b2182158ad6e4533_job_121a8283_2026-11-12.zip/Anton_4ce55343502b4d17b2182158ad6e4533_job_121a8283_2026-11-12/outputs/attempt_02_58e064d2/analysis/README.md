# Analysis folder

Everything here regenerates from `adjuvant_program_dataset.xlsx` by running `./run_all.sh`.
`cells.py` needs openpyxl (conda env `chem`); the other Python scripts run in env `core`; pandoc and R are in env `renv`.

| File | What it does |
|:--|:--|
| `cells.py` → `cells.json` | Verbatim dump of every non-empty workbook cell. |
| `parse_blocks.py` → `tidy_observations.csv`, `tidy_time_to_event.csv` | Assigns every numeric cell to a block, arm and replicate, keeping the cell address. Arm names are kept as printed. |
| `survival_analysis.py`, `pooled_survival.py` | Per-experiment and pooled survival (log-rank, Fisher, stratified log-rank, Mantel–Haenszel). |
| `bw_vs_surv.py`, `bw_morbidity.py` | Body-weight blocks: deaths implied by the traces, compared with the survival tables; weight nadir of survivors. |
| `immuno_stats.py`, `timecourse_stats.py`, `mech_stats.py`, `safety_stats.py`, `dose_response.py`, `age_by_mn.py`, `young_bw.py`, `young_mn.py` | Means, geometric means, ANOVA/Tukey, t-tests and the dose-response fit for the immunology, mechanism and safety blocks. |
| `biomarker_screen.py` | Group-level separation of protected from unprotected arms for each readout. |
| `xchecks.py`, `dup_check.py`, `dup_traj.py` | Internal-consistency checks: blocks recomputed from other blocks, duplicated blocks and duplicated values. |
| `power_calc.py` | Exact power and sample size for survival comparisons. |
| `ledger.py` → `../evidence_ledger.csv` | Builds the evidence ledger: every number in the memo with its cells and reduction. |
| `verify_ledger.py` | Re-reads the quoted cell ranges directly from `cells.json` and recomputes the ledger values (about 600 checks). |
| `crosscheck_survival.R` | Repeats the pooled survival comparison with R's `survival` package. |
| `figures.py` → `../figures/` | The five figures. |
| `build_memo.py`, `memo_body.md` → `../PSLN-344_recommendation_memo.md` | Assembles the memo and its appendices; checks that every cited ledger ID exists. |
| `build_xlsx.py` → `../PSLN-344_evidence_tables.xlsx` | Collects the evidence tables into one workbook. |
| `log_*.txt` | Printed output of each script from the last run. |

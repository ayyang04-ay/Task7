import pandas as pd, numpy as np
from parse_blocks import OBS, SURV
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 2000)
def cellrange(cells):
    cells=list(cells)
    return f"{cells[0]}:{cells[-1].split('!')[1]}" if len(cells)>1 else cells[0]
rows=[]
for (blk, rl, g), d in OBS.groupby(['block','row_label','group'], sort=False, dropna=False):
    v=d['value'].values
    rows.append(dict(block=blk, row=rl, group=g, n=len(v), mean=np.mean(v), sd=np.std(v, ddof=1) if len(v)>1 else np.nan,
                     median=np.median(v), min=v.min(), max=v.max(), cells=cellrange(d['cell'])))
D=pd.DataFrame(rows)
D.to_csv('descriptives_all_blocks.csv', index=False)
import sys
sel = sys.argv[1:] 
for blk, d in D.groupby('block', sort=False):
    if sel and not any(blk.startswith(s) for s in sel): continue
    print('\n##', blk)
    print(d.drop(columns='block').to_string(index=False, float_format=lambda x: f'{x:.3f}'))

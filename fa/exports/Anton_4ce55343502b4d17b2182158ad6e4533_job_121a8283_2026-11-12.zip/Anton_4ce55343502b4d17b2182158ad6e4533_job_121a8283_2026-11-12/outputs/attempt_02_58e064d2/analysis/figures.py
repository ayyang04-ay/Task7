import numpy as np, pandas as pd, warnings
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from lifelines import KaplanMeierFitter
from statsmodels.stats.proportion import proportion_confint
from parse_blocks import OBS, SURV
warnings.filterwarnings('ignore')
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'font.family': 'DejaVu Sans', 'axes.titlesize': 10, 'axes.titleweight': 'bold'})
COL = {'Sham': '#8c8c8c', 'PSLN-212': '#E69F00', 'PSLN-344': '#0072B2', 'PSLN-212(Y)': '#009E73', 'PSLN-344(Y)': '#56B4E9', 'CMP-204': '#CC79A7', 'PSLN-212/R848': '#D55E00', 'PSLN-R848': '#b07aa1', 'Vaccine': '#8c8c8c', 'PBS': '#bdbdbd', 'CT': '#D55E00', 'Untreated':'#000000'}
LAB = {'Sham': 'Vaccine + empty liposome (aged)', 'PSLN-212': 'Vaccine + PSLN-212 (aged)', 'PSLN-344': 'Vaccine + PSLN-344 (aged)', 'PSLN-212(Y)': 'Vaccine + PSLN-212 (young benchmark)'}
import os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'figures') + os.sep
os.makedirs(OUT, exist_ok=True)

def alive(blk, g):
    d = SURV[(SURV.block==blk)&(SURV.group==g)]; return int((d.event==0).sum()), len(d)

# ------------------------------------------------------------------ Figure 1
def fig1():
    exps = [('S03-I', 'Matched strain: bivalent → CA09 H1N1, day 14'),
            ('S06-A', 'Cross-subtype: H3N2 vaccine → PR8 H1N1, day 14'),
            ('S06-C', 'Cross-subtype: bivalent → rgH5N1, day 14'),
            ('S06-B', 'Early: H3N2 vaccine → PR8 H1N1, day 3'),
            ('S06-E (r34-68)', 'Late: H3N2 vaccine → PR8 H1N1, day 60'),
            ('S06-F (r34-68)', 'Late: bivalent → rgH5N1, day 60'),
            ('S06-G', 'Late: H1N1 vaccine → Perth H3N2, day 60'),
            ('S15-L', 'Aged C57BL/6 (challenge not stated)'),
            ('S15-N', 'Aged Swiss Webster (challenge not stated)')]
    fig, axes = plt.subplots(1, 2, figsize=(12.5, 5.6), gridspec_kw={'width_ratios': [1.35, 1], 'wspace': 0.22})
    ax = axes[0]
    groups = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
    off = {'Sham': 0.27, 'PSLN-212': 0.09, 'PSLN-344': -0.09, 'PSLN-212(Y)': -0.27}
    ylabels = []
    n = len(exps)
    for i, (blk, name) in enumerate(exps):
        y = n - i
        ax.axhline(y - 0.5, color='#f0f0f0', lw=0.6, zorder=0)
        for g in groups:
            a, nn = alive(blk, g)
            ax.plot(100*a/nn, y + off[g], 'o', color=COL[g], ms=6, zorder=3)
        ylabels.append(f'{name}  [{blk.split(" ")[0]}]')
    # pooled rows (one line per arm)
    py = {'Sham': -0.05, 'PSLN-212': -0.55, 'PSLN-344': -1.05, 'PSLN-212(Y)': -1.55}
    for g in groups:
        a = sum(alive(b, g)[0] for b, _ in exps); nn = sum(alive(b, g)[1] for b, _ in exps)
        lo, hi = proportion_confint(a, nn, method='beta')
        ax.errorbar(100*a/nn, py[g], xerr=[[100*(a/nn-lo)], [100*(hi-a/nn)]], fmt='D', color=COL[g], ms=6.5, capsize=3, zorder=3)
        xt = 100*hi + 2.5 if 100*hi < 92 else 100*lo - 2.5
        ax.text(xt, py[g], f'{a}/{nn} ({100*a/nn:.0f}%)', va='center', ha='left' if 100*hi < 92 else 'right', fontsize=8, color=COL[g])
    ax.axhline(0.45, color='k', lw=0.7)
    ax.set_yticks(list(range(n, 0, -1)) + [-0.8]); ax.set_yticklabels(ylabels + ['POOLED, 9 experiments\n(exact 95% CI)'], fontsize=8)
    ax.set_xlim(-4, 104); ax.set_xticks([0, 25, 50, 75, 100]); ax.set_xlabel('Alive at end of 14-day observation (%)     n = 7 per arm per experiment')
    ax.set_ylim(-1.95, n + 0.6)
    ax.grid(axis='x', color='#e6e6e6', lw=0.6); ax.set_axisbelow(True)
    ax.set_title('A  Survival after lethal challenge, aged (≥20-month) mice', loc='left')
    handles = [Line2D([], [], marker='o', ls='', color=COL[g], label=LAB[g]) for g in groups]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.5, -0.045), ncol=4, frameon=False, fontsize=8.5)
    # KM pooled
    ax = axes[1]
    for g in groups:
        d = SURV[SURV.block.isin([b for b, _ in exps]) & (SURV.group == g)]
        km = KaplanMeierFitter().fit(d.day, d.event)
        t = np.concatenate([[0], km.survival_function_.index.values]); s = np.concatenate([[1], km.survival_function_.iloc[:, 0].values])
        if t[-1] < 14: t = np.append(t, 14); s = np.append(s, s[-1])
        ax.step(t, 100*s, where='post', color=COL[g], lw=2, label=LAB[g])
    ax.set_xlim(0, 14.3); ax.set_ylim(-3, 103); ax.set_xlabel('Days after challenge'); ax.set_ylabel('Survival (%)')
    ax.set_title('B  Pooled Kaplan–Meier, same 9 experiments (63 per arm)', loc='left')
    ax.text(14.2, 82.3, '51/63', color=COL['PSLN-344'], ha='right', va='bottom', fontsize=8.5); ax.text(14.2, 10.8, '6/63', color=COL['PSLN-212'], ha='right', va='bottom', fontsize=8.5)
    ax.text(14.2, 1.0, '0/63', color=COL['Sham'], ha='right', va='bottom', fontsize=8.5); ax.text(14.2, 96.8, '62/63', color=COL['PSLN-212(Y)'], ha='right', va='top', fontsize=8.5)
    ax.text(8.9, 73, 'PSLN-344 vs PSLN-212, aged:\nstratified log-rank p = 1.6 × 10⁻¹⁷\nhazard ratio for death 0.10\n(95% CI 0.06–0.17)', fontsize=8, va='top')
    fig.savefig(OUT + 'fig1_survival_aged.png', dpi=200, bbox_inches='tight'); plt.close(fig)

# ------------------------------------------------------------------ Figure 2
def fig2():
    R = pd.read_csv('restoration_index.csv')
    order = [('S01-A 16h', 'Lung Ifnb1 mRNA, 16 h'), ('S01-F', 'Lung cDC1, 72 h'), ('S02-A', 'Lung CCR7+ migratory CD11b+ DC, 72 h'), ('S02-B', 'MLN CD11b+ DC, 72 h'), ('S02-C', 'Antigen+ DC in MLN, 36 h'),
             ('S02-D CD40', 'CD40+ MLN CD11b+ DC, d3'), ('S02-D CD86', 'CD86+ MLN CD11b+ DC, d3'), ('S02-E', 'DC-driven OT-I proliferation'),
             ('S05-D', 'Lung Ki-67+ CD8 T, d3'), ('S05-E', 'Lung GZMB+ CD8 T, d3'), ('S05-F', 'IFN-γ+ CD8 T (rgH5N1 restim.), d14'), ('S14-A H1N1', 'IFN-γ+ CD8 T (H1N1 restim.)'), ('S14-A H3N2', 'IFN-γ+ CD8 T (H3N2 restim.)'),
             ('S05-G', 'IFN-γ+ CD8 T (rgH5N1 restim.), d60'), ('S05-H', 'GZMB+ CD8 T, d60'), ('S05-I', 'Lung resident-memory CD8 T, d25'),
             ('S04-A ICOS-low', 'Tfh ICOS-low, d7'), ('S04-A ICOS-high', 'Tfh ICOS-high, d7'), ('S03-K', 'Germinal-centre B cells, d7'), ('S13-H', 'IgG+ B220+ cells (MLN)'),
             ('S03-A', 'Serum IgG, H1N1, d14 (GMT)'), ('S03-C', 'HAI, H1N1, d14 (GMT)'), ('S03-D', 'Neutralising titre, H1N1, d14 (GMT)'),
             ('S03-E', 'Serum IgG, H3N2, d14 (GMT)'), ('S03-G', 'HAI, H3N2, d14 (GMT)'), ('S03-H', 'Neutralising titre, H3N2, d14 (GMT)')]
    fig, ax = plt.subplots(figsize=(7.6, 6.6))
    n = len(order)
    for i, (blk, name) in enumerate(order):
        r = R[R.block == blk].iloc[0]; y = n - i
        ax.plot([r.pct_of_young_212, r.pct_of_young_344], [y, y], color='#cfcfcf', lw=1.5, zorder=1)
        ax.plot(r.pct_of_young_212, y, 'o', color=COL['PSLN-212'], ms=6, zorder=3); ax.plot(r.pct_of_young_344, y, 'o', color=COL['PSLN-344'], ms=6, zorder=3)
    ax.axvline(100, color=COL['PSLN-212(Y)'], lw=1.5, ls='--'); ax.text(101, n + 1.05, 'young + PSLN-212\n= 100%', color=COL['PSLN-212(Y)'], fontsize=8, ha='left', va='bottom')
    ax.set_yticks(range(n, 0, -1)); ax.set_yticklabels([f'{nm}  [{b}]' for b, nm in order], fontsize=7.8)
    for yb in [18.5, 10.5, 6.5]: ax.axhline(yb, color='#999999', lw=0.5, ls=':')
    for ymid, txt in [(22.5, 'Innate /\ndendritic cell'), (14.5, 'CD8 T cell'), (8.5, 'Tfh / B cell'), (3.5, 'Serum\nantibody')]:
        ax.text(106, ymid, txt, fontsize=8, color='#444444', ha='left', va='center', style='italic')
    ax.set_xlim(-2, 126); ax.set_ylim(0.3, n + 0.7); ax.set_xticks([0, 20, 40, 60, 80, 100]); ax.set_xlabel('Aged-animal response as % of the young PSLN-212 response (group mean; GMT for titres)')
    med2, med3 = R.pct_of_young_212.median(), R.pct_of_young_344.median()
    ax.axvline(med2, color=COL['PSLN-212'], lw=0.9, ls=':'); ax.axvline(med3, color=COL['PSLN-344'], lw=0.9, ls=':')
    ax.text(med2, n + 1.05, f'PSLN-212 aged\nmedian {med2:.0f}%', color=COL['PSLN-212'], fontsize=8, ha='center', va='bottom')
    ax.text(med3 + 1, n + 1.05, f'PSLN-344 aged\nmedian {med3:.0f}%', color=COL['PSLN-344'], fontsize=8, ha='right', va='bottom')
    ax.grid(axis='x', color='#eeeeee', lw=0.6); ax.set_axisbelow(True)
    ax.set_title('Share of the young-adult response recovered in aged mice (26 readouts)', pad=30, loc='left', x=-0.45)
    fig.tight_layout(); fig.savefig(OUT + 'fig2_restoration_index.png', dpi=200, bbox_inches='tight'); plt.close(fig)

# ------------------------------------------------------------------ Figure 3
def fig3():
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.1), gridspec_kw={'wspace': 0.28})
    # A dose response
    ax = axes[0]
    d = OBS[OBS.block == 'S08-A'].copy(); d['dose'] = d.row_label.astype(float)
    for g, lab in [('PSLN-344', 'PSLN-344 (CDN + Mn²⁺)'), ('PSLN-212', 'PSLN-212 (CDN)'), ('CMP-204', 'CMP-204 (cGAMP)')]:
        x = d[d.group == g]; m = x.groupby('dose').value.agg(['mean', 'std'])
        ax.errorbar(m.index, m['mean'], yerr=m['std'], color=COL[g], marker='o', ms=4, lw=1.8, capsize=2, label=lab)
        ax.plot(x.dose, x.value, '.', color=COL[g], alpha=0.35, ms=5)
    ax.set_xscale('log'); ax.set_xticks([1, 5, 10, 20, 40]); ax.set_xticklabels(['1', '5', '10', '20', '40']); ax.minorticks_off()
    ax.set_xlabel('Intranasal dose (µg per mouse)'); ax.set_ylabel('Lung Ifnb1 mRNA, 16 h (fold vs untreated)')
    ax.set_title('A  Mn²⁺ raises the ceiling of the IFN-β\n    response, not just potency  [S08-A]', loc='left'); ax.legend(frameon=False, fontsize=8, loc='upper left')
    # B Ifnb1 aged vs young
    ax = axes[1]
    gs = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']
    names = ['Empty\nliposome\naged', 'CMP-\n204\naged', 'PSLN-\n212\naged', 'PSLN-\n344\naged', 'PSLN-\n212\nyoung', 'PSLN-\n344\nyoung']
    for i, g in enumerate(gs):
        v = OBS[(OBS.block == 'S01-A 16h') & (OBS.group == g)].value.values
        ax.bar(i, v.mean(), color=COL[g], alpha=0.55, width=0.7); ax.plot(np.full(len(v), i) + np.linspace(-0.15, 0.15, len(v)), v, 'o', color=COL[g], ms=4, mec='k', mew=0.4)
    ax.set_xticks(range(len(gs))); ax.set_xticklabels(names, fontsize=7.5); ax.set_ylabel('Lung Ifnb1 mRNA, 16 h (fold vs untreated)')
    ax.set_title('B  PSLN-344 lifts aged lungs to the\n    young PSLN-212 level  [S01-A]', loc='left')
    # C protection requires vaccine + adjuvant
    ax = axes[2]
    for g, c, lab in [('3d Vaccine', COL['Sham'], 'Vaccine alone (0/7)'), ('3d PSLN-344', '#56B4E9', 'PSLN-344 alone (0/7)'), ('3d Vaccine+PSLN-344', COL['PSLN-344'], 'Vaccine + PSLN-344 (6/7)')]:
        x = SURV[(SURV.block == 'S15-H') & (SURV.group == g)]; km = KaplanMeierFitter().fit(x.day, x.event)
        t = np.concatenate([[0], km.survival_function_.index.values]); s = np.concatenate([[1], km.survival_function_.iloc[:, 0].values])
        if t[-1] < 14: t = np.append(t, 14); s = np.append(s, s[-1])
        ax.step(t, 100*s, where='post', color=c, lw=2, label=lab)
    ax.set_xlim(0, 14.3); ax.set_ylim(-3, 103); ax.set_xlabel('Days after rgH5N1 challenge\n(challenge 3 days after the intranasal dose; aged mice)'); ax.set_ylabel('Survival (%)')
    ax.set_title('C  Neither adjuvant alone nor vaccine alone\n    protects; the combination does  [S15-H]', loc='left'); ax.legend(frameon=False, fontsize=8, loc='center left', bbox_to_anchor=(0.5, 0.45)); ax.set_xticks(range(0, 15, 2))
    fig.savefig(OUT + 'fig3_mechanism.png', dpi=200, bbox_inches='tight'); plt.close(fig)

# ------------------------------------------------------------------ Figure 4 (safety)
def fig4():
    fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.9), gridspec_kw={'width_ratios': [1, 1.25, 0.95]})
    ax = axes[0]
    d = OBS[OBS.block == 'S08-D'].copy(); d['day'] = d.row_label.astype(float)
    for g, lab in [('Vaccine', 'Vaccine alone (aged)'), ('PSLN-212', 'PSLN-212 (aged)'), ('PSLN-344', 'PSLN-344 (aged)'), ('PSLN-212/R848', 'PSLN-212/R848 (aged)')]:
        m = d[d.group == g].groupby('day').value.agg(['mean', 'std'])
        ax.errorbar(m.index, m['mean'], yerr=m['std'], color=COL[g], marker='o', ms=4, lw=1.8, capsize=2, label=lab)
    ax.axhline(100, color='k', lw=0.5, ls=':'); ax.set_xlabel('Days after intranasal immunisation'); ax.set_ylabel('Body weight (% of day 0), mean ± SD, n = 5')
    ax.set_title('A  Weight after dosing [S08-D]'); ax.legend(frameon=False, fontsize=7.5, loc='lower left')
    # B cytokine heat map
    ax = axes[1]
    C = pd.read_csv('S09A_cytokines.csv')
    arms = ['PSLN-212 (fold)', 'PSLN-344 (fold)', 'PSLN-212(y) (fold)', 'PSLN-212/R848 (fold)']; armlab = ['PSLN-212\naged', 'PSLN-344\naged', 'PSLN-212\nyoung', 'PSLN-212/\nR848 aged']
    ans = ['Ifnb1', 'Il6', 'Tnf', 'Il10', 'Ccl2', 'Ccl3', 'Ccl5']
    M = np.zeros((len(ans), 8))
    for j, tp in enumerate(['16h', '72h*']):
        for k, a in enumerate(arms):
            for i, an in enumerate(ans):
                M[i, j*4 + k] = np.log10(C[(C.time == tp) & (C.analyte == an)][a].values[0])
    im = ax.imshow(M, cmap='RdBu_r', vmin=-3.2, vmax=3.2, aspect='auto')
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            v = 10**M[i, j]; ax.text(j, i, f'{v:.0f}' if v >= 10 else f'{v:.1f}', ha='center', va='center', fontsize=7, color='white' if abs(M[i, j]) > 1.8 else 'black')
    ax.set_xticks(range(8)); ax.set_xticklabels(armlab*2, fontsize=6.8); ax.set_yticks(range(len(ans))); ax.set_yticklabels(ans, fontsize=8, style='italic')
    ax.axvline(3.5, color='k', lw=1.2); ax.text(1.5, -0.75, '16 h', ha='center', fontsize=8.5, fontweight='bold'); ax.text(5.5, -0.75, '72 h (panel printed "16h")', ha='center', fontsize=8.5, fontweight='bold')
    ax.spines[:].set_visible(False); ax.tick_params(length=0)
    ax.set_title('B  Lung cytokine mRNA, fold vs PBS [S09-A]', pad=18)
    # C CNS
    ax = axes[2]
    gs = ['PBS', 'Sham', 'PSLN-344', 'CT']; cols = ['#bdbdbd', '#8c8c8c', COL['PSLN-344'], COL['CT']]
    for a_i, an in enumerate(['Ifnb1', 'Tnf', 'Isg15']):
        for g_i, g in enumerate(gs):
            v = OBS[(OBS.block == f'S10-A {an}') & (OBS.group == g)].value.values; x0 = a_i*5 + g_i
            ax.bar(x0, v.mean(), color=cols[g_i], alpha=0.55, width=0.8); ax.plot(np.full(len(v), x0) + np.linspace(-0.2, 0.2, len(v)), v, 'o', color=cols[g_i], ms=3.2, mec='k', mew=0.3)
    ax.set_xticks([1.5, 6.5, 11.5]); ax.set_xticklabels(['Ifnb1', 'Tnf', 'Isg15'], style='italic'); ax.set_ylabel('CNS mRNA, 36 h (fold vs untreated)')
    ax.legend(handles=[Line2D([], [], marker='s', ls='', color=c, label=l) for c, l in zip(cols, ['PBS', 'Vaccine + empty liposome', 'Vaccine + PSLN-344', 'Vaccine + cholera toxin'])], frameon=False, fontsize=7, loc='upper right', bbox_to_anchor=(1.04, 1.0))
    ax.set_title('C  CNS transcripts, aged [S10-A]')
    fig.tight_layout(); fig.savefig(OUT + 'fig4_safety.png', dpi=200, bbox_inches='tight'); plt.close(fig)

# ------------------------------------------------------------------ Figure 5 (biomarker candidates)
def fig5():
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.3), gridspec_kw={'wspace': 0.3})
    # A: HAI vs matched-strain survival
    ax = axes[0]
    gs = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']; names = ['Empty\nliposome\naged', 'CMP-204\naged', 'PSLN-212\naged', 'PSLN-344\naged', 'PSLN-212\nyoung']
    rng_ = np.random.default_rng(1)
    for i, g in enumerate(gs):
        v = OBS[(OBS.block == 'S03-C') & (OBS.group == g)].value.values.astype(float); v = np.where(v <= 0, 5, v)
        ax.plot(i + np.linspace(-0.18, 0.18, len(v)), v, 'o', color=COL[g], ms=6, mec='k', mew=0.4)
        gm = np.exp(np.log(v).mean()); ax.plot([i - 0.3, i + 0.3], [gm, gm], color=COL[g], lw=2.5)
        a, n = alive('S03-I', g); ax.text(i, 1150, f'{a}/{n}', ha='center', va='center', fontsize=9, fontweight='bold', color=COL[g])
    ax.text(2, 1900, 'survivors / challenged (parallel animals)', ha='center', va='center', fontsize=7.5, color='#444444')
    ax.axhline(40, color='k', lw=0.8, ls='--'); ax.text(4.45, 43, 'HAI 1:40', ha='right', va='bottom', fontsize=8)
    ax.axhline(10, color='#999999', lw=0.6, ls=':'); ax.text(4.45, 10.6, 'lowest dilution tested (1:10)', ha='right', va='bottom', fontsize=7, color='#777777')
    ax.set_yscale('log', base=2); ax.set_yticks([5, 10, 20, 40, 80, 160, 320, 640]); ax.set_yticklabels(['<10', '10', '20', '40', '80', '160', '320', '640']); ax.set_ylim(3.5, 2600)
    ax.set_xticks(range(len(gs))); ax.set_xticklabels(names, fontsize=8); ax.set_xlim(-0.6, 4.5)
    ax.set_ylabel('HAI titre vs CA09 H1N1, day 14 (bar = GMT)')
    ax.set_title('A  Serum HAI [S03-C] and survival of a matched-strain\n    challenge in parallel animals [S03-I, as printed]', loc='left')
    # B: cross-reactive CD8 vs heterosubtypic survival
    ax = axes[1]
    gs = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']; names = ['Empty\nliposome\naged', 'PSLN-212\naged', 'PSLN-344\naged', 'PSLN-212\nyoung']
    for i, g in enumerate(gs):
        v = OBS[(OBS.block == 'S05-F') & (OBS.group == g)].value.values
        ax.plot(i + np.linspace(-0.18, 0.18, len(v)), v, 'o', color=COL[g], ms=6, mec='k', mew=0.4); ax.plot([i - 0.3, i + 0.3], [v.mean(), v.mean()], color=COL[g], lw=2.5)
        a, n = alive('S06-C', g); ax.text(i, 12.1, f'{a}/{n}', ha='center', va='center', fontsize=9, fontweight='bold', color=COL[g])
    ax.text(1.5, 13.1, 'survivors / challenged (parallel animals)', ha='center', va='center', fontsize=7.5, color='#444444')
    ax.set_ylim(0, 13.7); ax.set_yticks([0, 2, 4, 6, 8, 10]); ax.set_xticks(range(len(gs))); ax.set_xticklabels(names, fontsize=8); ax.set_xlim(-0.6, 3.5)
    ax.set_ylabel('IFN-γ+ CD8 T cells after rgH5N1 restimulation,\nday 14 (% of MLN cells; bar = mean)')
    ax.set_title('B  Cross-reactive CD8 T cells [S05-F] and survival of an\n    rgH5N1 challenge in parallel animals [S06-C]', loc='left')
    fig.savefig(OUT + 'fig5_biomarker_candidates.png', dpi=200, bbox_inches='tight'); plt.close(fig)

if __name__ == '__main__':
    fig1(); fig2(); fig3(); fig4(); fig5(); print('figures written')

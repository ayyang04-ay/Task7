"""Dump every non-empty cell of the workbook to cells.json (run in an environment with openpyxl)."""
import openpyxl, json, os
HERE = os.path.dirname(os.path.abspath(__file__))
XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'   # source workbook
from openpyxl.utils import get_column_letter
wb = openpyxl.load_workbook(XLSX)
out = {}
types = {}
for ws in wb.worksheets:
    d = {}
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None:
                d[c.coordinate] = c.value
                types.setdefault(type(c.value).__name__, 0)
                types[type(c.value).__name__] += 1
    out[ws.title] = d
json.dump(out, open(os.path.join(HERE, 'cells.json'),'w'), ensure_ascii=False, indent=0)
print(types)
# check for formulas
wb2 = openpyxl.load_workbook(XLSX, data_only=False)
nform=0
for ws in wb2.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value,str) and c.value.startswith('='):
                nform+=1; print('FORMULA', ws.title, c.coordinate, c.value)
print('formulas', nform)
# any string cells that look numeric?
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value,str):
                s=c.value.strip()
                try:
                    float(s); print('NUMERIC-STRING', ws.title, c.coordinate, repr(c.value))
                except: pass
# fonts/fills that may flag things
flags=set()
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if c.value is not None:
                f=c.font; fl=c.fill
                key=(f.b, f.i, f.strike, f.color.rgb if f.color is not None and f.color.type=='rgb' else None, fl.fgColor.rgb if fl is not None and fl.fill_type else None, c.number_format)
                flags.add(key)
print(len(flags)); 
for k in sorted(flags, key=str): print(k)

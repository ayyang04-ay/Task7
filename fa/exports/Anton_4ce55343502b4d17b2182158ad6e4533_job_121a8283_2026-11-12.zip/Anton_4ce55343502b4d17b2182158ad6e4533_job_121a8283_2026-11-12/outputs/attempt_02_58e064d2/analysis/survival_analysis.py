"""
Survival analysis of every time-to-event block, as printed in the workbook.
event=1 -> death/endpoint on that day ; event=0 -> alive at end of observation (censored).
Tests: two-sided log-rank (lifelines) and two-sided Fisher exact on alive/dead at end of observation.
"""
import pandas as pd, numpy as np, itertools, warnings
from scipy import stats
from lifelines.statistics import logrank_test, multivariate_logrank_test
from parse_blocks import OBS, SURV
warnings.filterwarnings('ignore')
pd.set_option('display.width', 280); pd.set_option('display.max_rows', 500); pd.set_option('display.max_columns', 50)

META = {  # block -> (strain/age, vaccine, challenge, interval)
 'S03-I': ('aged BALB/c (+young ref)', 'bivalent? ("vaccinated as in S03-A")', '10x mLD50 CA09 H1N1 (homologous)', 'd14'),
 'S03-J': ('BALB/c, age NOT stated', 'rgH5N1 vaccine', 'wild-type VN04 H5N1 (dose not stated)', 'd2'),
 'S06-A': ('aged BALB/c', 'Aichi H3N2', '5x mLD50 PR8 H1N1 (heterosubtypic)', 'd14'),
 'S06-B': ('aged BALB/c', 'Aichi H3N2', '5x mLD50 PR8 H1N1 (heterosubtypic)', 'd3'),
 'S06-C': ('aged BALB/c', 'bivalent CA09+Aichi', '5x mLD50 rgH5N1 (heterosubtypic)', 'd14'),
 'S06-D': ('aged BALB/c', 'bivalent CA09+Aichi', '5x mLD50 rgH5N1 (heterosubtypic)', 'd3'),
 'S06-E (r34-68)': ('aged BALB/c', 'Aichi H3N2', '5x mLD50 PR8 H1N1 (heterosubtypic)', 'd60'),
 'S06-F (r34-68)': ('aged BALB/c', 'bivalent CA09+Aichi', '5x mLD50 rgH5N1 (heterosubtypic)', 'd60'),
 'S06-G': ('aged BALB/c', 'CA09 H1N1', '5x mLD50 Perth H3N2 (heterosubtypic)', 'd60'),
 'S06-E (r71-105, imprint PR8)': ('BALB/c 10 mo at priming, ~14 mo at vaccination', 'bivalent', '5x LD50 PR8 H1N1', 'interval not stated'),
 'S06-F (r71-105, imprint Perth)': ('BALB/c 10 mo at priming, ~14 mo at vaccination', 'bivalent', '5x LD50 Perth H3N2', 'd14'),
 'S09-B': ('young BALB/c', 'Aichi H3N2', '5x mLD50 PR8 H1N1', 'd21'),
 'S09-D': ('young BALB/c', 'CA09 H1N1', '5x mLD50 Perth H3N2', 'd21'),
 'S09-F': ('young BALB/c', 'bivalent', '5x mLD50 VN04 rgH5N1', 'd180'),
 'S13-E': ('young BALB/c', 'as S03-I', '10x mLD50 CA09 H1N1', 'd14'),
 'S15-H': ('aged BALB/c', 'bivalent / none', '5x mLD50 VN04 rgH5N1', 'd3'),
 'S15-L': ('aged C57BL/6 20 mo (+young)', 'bivalent', 'NOT stated', 'NOT stated'),
 'S15-N': ('aged Swiss Webster 20 mo (+young)', 'bivalent', 'NOT stated', 'NOT stated'),
}

def km_median(days, events):
    # Kaplan-Meier median survival (day at which S(t) first <= 0.5); None if not reached
    df = pd.DataFrame({'t':days, 'e':events}).sort_values('t')
    n = len(df); s = 1.0
    for t in sorted(df.t.unique()):
        d = int(((df.t==t)&(df.e==1)).sum()); atrisk = int((df.t>=t).sum())
        if atrisk>0: s *= (1 - d/atrisk)
        if s <= 0.5: return t
    return None

def pair_tests(S, blk, g1, g2):
    a = S[(S.block==blk)&(S.group==g1)].dropna(subset=['day']); b = S[(S.block==blk)&(S.group==g2)].dropna(subset=['day'])
    if len(a)==0 or len(b)==0: return None
    lr = logrank_test(a.day, b.day, event_observed_A=a.event, event_observed_B=b.event)
    a_alive = int((a.event==0).sum()); b_alive = int((b.event==0).sum())
    fe = stats.fisher_exact([[a_alive, len(a)-a_alive],[b_alive, len(b)-b_alive]])[1]
    return dict(block=blk, A=g1, B=g2, A_alive=f'{a_alive}/{len(a)}', B_alive=f'{b_alive}/{len(b)}', logrank_p=lr.p_value, fisher_p=fe)

if __name__ == '__main__':
    rows=[]
    for (blk, g), d in SURV.groupby(['block','group'], sort=False):
        dd = d.dropna(subset=['day'])
        rows.append(dict(block=blk, group=g, n_rows=len(d), n_with_day=len(dd), deaths=int(d.event.sum()), alive=int((d.event==0).sum()),
                         pct_alive=100*(d.event==0).mean(), death_days=sorted(int(x) for x in dd.loc[dd.event==1,'day']),
                         median_surv=km_median(dd.day.values, dd.event.values),
                         cells_status=f"{d.cell_status.iloc[0]}:{d.cell_status.iloc[-1].split('!')[1]}", cells_day=f"{d.cell_day.iloc[0]}:{d.cell_day.iloc[-1].split('!')[1]}"))
    T = pd.DataFrame(rows)
    T.to_csv('survival_by_group.csv', index=False)
    print(T.to_string())

    print('\n\n===== pairwise tests within each block =====')
    out=[]
    for blk in SURV.block.unique():
        gs = list(SURV[SURV.block==blk].group.unique())
        for g1, g2 in itertools.combinations(gs, 2):
            r = pair_tests(SURV, blk, g1, g2)
            if r: out.append(r)
    P = pd.DataFrame(out)
    P.to_csv('survival_pairwise_tests.csv', index=False)
    print(P.to_string(float_format=lambda x: f'{x:.4g}'))

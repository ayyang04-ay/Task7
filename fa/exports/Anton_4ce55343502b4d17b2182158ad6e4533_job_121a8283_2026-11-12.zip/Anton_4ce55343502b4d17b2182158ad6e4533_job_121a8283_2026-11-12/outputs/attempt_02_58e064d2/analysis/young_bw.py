import pandas as pd, numpy as np
from scipy import stats
from parse_blocks import OBS
for blk in ['S09-C','S09-E','S09-G']:
    d = OBS[OBS.block==blk].copy(); d['day']=d.row_label.astype(float)
    print('\n', blk)
    for day in [6,8,10,12,14]:
        a = d[(d.group=='PSLN-344Y')&(d.day==day)].value.values; b = d[(d.group=='PSLN-212Y')&(d.day==day)].value.values
        print(f'  d{day}: PSLN-344Y {a.mean():.1f}±{a.std(ddof=1):.1f} (n={len(a)})  PSLN-212Y {b.mean():.1f}±{b.std(ddof=1):.1f} (n={len(b)})  t p={stats.ttest_ind(a,b).pvalue:.4f}  MWU p={stats.mannwhitneyu(a,b).pvalue:.4f}')
    na = d[d.group=='PSLN-344Y'].groupby('rep').value.min(); nb = d[d.group=='PSLN-212Y'].groupby('rep').value.min()
    print(f'  nadir: PSLN-344Y {na.mean():.1f}  PSLN-212Y {nb.mean():.1f}  p={stats.ttest_ind(na,nb).pvalue:.4f}')

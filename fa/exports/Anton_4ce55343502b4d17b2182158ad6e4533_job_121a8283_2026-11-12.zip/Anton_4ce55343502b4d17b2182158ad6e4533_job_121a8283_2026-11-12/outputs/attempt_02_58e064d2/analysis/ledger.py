"""
Builds the evidence ledger: every number used in the memo, the cells it comes from, and how it was reduced.
Output: evidence_ledger.csv / evidence_ledger.md
"""
import numpy as np, pandas as pd, itertools, warnings
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.stats.proportion import proportion_confint
from statsmodels.stats.contingency_tables import StratifiedTable
from lifelines.statistics import logrank_test
from parse_blocks import OBS, SURV
from pooled_survival import strat_logrank
warnings.filterwarnings('ignore')

L = []
def add(id_, topic, statement, value, source, reduction):
    L.append(dict(ID=id_, topic=topic, statement=statement, value=value, source_cells=source, reduction=reduction))

def rng(cells):
    cells = list(cells); return f"{cells[0]}:{cells[-1].split('!')[1]}"
def sv(blk, g):
    d = SURV[(SURV.block==blk)&(SURV.group==g)]
    return int((d.event==0).sum()), len(d), rng(d.cell_status), d
def ob(blk, g, row=None):
    d = OBS[(OBS.block==blk)&(OBS.group==g)]
    if row is not None: d = d[d.row_label==row]
    return d.sort_values('rep')
def _f(x, ref=None):
    r = abs(ref if ref is not None else x)
    return f"{x:.0f}" if r >= 1000 else (f"{x:.1f}" if r >= 10 else f"{x:.2f}")
def ms(d):
    m = d.value.mean(); sd = d.value.std(ddof=1)
    return f"{_f(m)} ± {_f(sd, m)} (n={len(d)})"
def gmt(d, lod_half=None):
    v = d.value.values.astype(float)
    if lod_half is not None: v = np.where(v<=0, lod_half, v)
    return float(np.exp(np.log(v).mean()))
def tukey(blk, a, b, row=None, log=False, lod_half=None):
    d = OBS[OBS.block==blk]
    if row is not None: d = d[d.row_label==row]
    v = d.value.values.astype(float)
    if lod_half is not None: v = np.where(v<=0, lod_half, v)
    y = np.log2(v) if log else v
    tk = pairwise_tukeyhsd(y, d.group.values)
    res = {frozenset(k): p for k,p in zip(itertools.combinations(tk.groupsunique,2), tk.pvalues)}
    return res[frozenset([a,b])]
def fmt_p(p):
    if p > 0.99: return ">0.99"
    return f"{p:.2g}" if p >= 1e-4 else f"{p:.1e}"
def ci(x, n):
    lo, hi = proportion_confint(x, n, method='beta'); return f"{100*lo:.0f}–{100*hi:.0f}%"

# ============ E: efficacy (time-to-event tables, as printed) ============
A9 = ['S03-I','S06-A','S06-B','S06-C','S06-E (r34-68)','S06-F (r34-68)','S06-G','S15-L','S15-N']
names = {'S03-I':'bivalent vaccine→10×mLD50 CA09 H1N1 (matched strain), d14','S06-A':'Aichi H3N2 vaccine→5×mLD50 PR8 H1N1, d14','S06-B':'Aichi H3N2→PR8 H1N1, d3',
         'S06-C':'bivalent→5×mLD50 rgH5N1, d14','S06-D':'bivalent→rgH5N1, d3 (block identical to S06-C)','S06-E (r34-68)':'Aichi H3N2→PR8 H1N1, d60','S06-F (r34-68)':'bivalent→rgH5N1, d60',
         'S06-G':'CA09 H1N1→Perth H3N2, d60','S15-L':'aged C57BL/6, bivalent (challenge virus/interval not stated)','S15-N':'aged Swiss Webster, bivalent (challenge virus/interval not stated)'}
tot = {g:[0,0] for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']}
for i, blk in enumerate(A9 + ['S06-D']):
    parts=[]; src=[]
    for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']:
        a, n, r, d = sv(blk, g); parts.append(f"{g} {a}/{n}"); src.append(r)
        if blk in A9: tot[g][0]+=a; tot[g][1]+=n
    a3 = SURV[(SURV.block==blk)&(SURV.group=='PSLN-344')]; a2 = SURV[(SURV.block==blk)&(SURV.group=='PSLN-212')]
    lr = logrank_test(a3.day, a2.day, a3.event, a2.event).p_value
    add(f"E{i+1}", 'Efficacy', f"{blk}: {names[blk]} — alive at end of 14-d observation", '; '.join(parts) + f"; log-rank PSLN-344 vs PSLN-212 p={fmt_p(lr)}",
        '; '.join(src) + f" (days in the block's 'Days' column)", "count of rows with status 0 (alive/censored at d14) ÷ rows per arm; two-sided log-rank on (day, status)")
for g in tot:
    a, n = tot[g]
    add(f"E11-{g}", 'Efficacy', f"Pooled survival, 9 aged (≥20 mo) experiments (E1–E9; S06-D excluded as duplicate of S06-C): {g}", f"{a}/{n} = {100*a/n:.1f}% (exact 95% CI {ci(a,n)})",
        "sum of E1–E9", "sum of alive ÷ sum of animals; Clopper–Pearson CI")
for gA, gB, tag in [('PSLN-344','PSLN-212','a'),('PSLN-344','Sham','b'),('PSLN-344','PSLN-212(Y)','c'),('PSLN-212','Sham','d')]:
    tabs=[]
    for blk in A9:
        xa, na, _, _ = sv(blk, gA); xb, nb, _, _ = sv(blk, gB); tabs.append(np.array([[xa, na-xa],[xb, nb-xb]]))
    st = StratifiedTable(tabs); cm = st.test_null_odds(correction=False); p_cmh = stats.chi2.sf(cm.statistic, 1)
    lr = strat_logrank(A9, gA, gB)
    add(f"E12{tag}", 'Efficacy', f"Pooled comparison {gA} vs {gB}, stratified by experiment (9 experiments)",
        f"stratified log-rank χ²={lr['chi2']:.1f}, p={fmt_p(lr['p'])}; Peto hazard ratio for death {lr['peto_HR']:.2f} (95% CI {lr['HR_lo']:.2f}–{lr['HR_hi']:.2f}); Cochran–Mantel–Haenszel p={fmt_p(p_cmh)}",
        "E1–E9 time-to-event rows", "log-rank O−E and variance summed across experiments (strata); Peto one-step HR = exp(Σ(O−E)/ΣV); CMH on alive/dead 2×2 tables")
# BALB/c only and other strains
B7 = ['S03-I','S06-A','S06-B','S06-C','S06-E (r34-68)','S06-F (r34-68)','S06-G']
for label, blks, id_ in [('aged BALB/c only (7 experiments)', B7, 'E13'), ('aged C57BL/6 + Swiss Webster (S15-L, S15-N)', ['S15-L','S15-N'], 'E14')]:
    s = []
    for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']:
        a = sum(sv(b,g)[0] for b in blks); n = sum(sv(b,g)[1] for b in blks); s.append(f"{g} {a}/{n}")
    add(id_, 'Efficacy', f"Pooled survival, {label}", '; '.join(s), 'rows as in E1–E9', 'sum of alive ÷ sum of animals')
# by interval
for label, blks, id_ in [('d3 (S06-B)', ['S06-B'], 'E15a'), ('d14 (S03-I, S06-A, S06-C)', ['S03-I','S06-A','S06-C'], 'E15b'), ('d60 (S06-E, S06-F, S06-G)', ['S06-E (r34-68)','S06-F (r34-68)','S06-G'], 'E15c')]:
    s=[]
    for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']:
        a = sum(sv(b,g)[0] for b in blks); n = sum(sv(b,g)[1] for b in blks); s.append(f"{g} {a}/{n} ({100*a/n:.0f}%)")
    add(id_, 'Efficacy', f"Aged BALB/c survival by vaccination→challenge interval: {label}", '; '.join(s), 'rows as in E1–E8', 'sum of alive ÷ sum of animals')
u = [sv(b,'Untreated') for b in ['S06-E (r34-68)','S06-F (r34-68)','S06-G']]
ua = sum(x[0] for x in u); un = sum(x[1] for x in u)
p_u = stats.fisher_exact([[14,7],[ua,un-ua]])[1]
add('E16', 'Efficacy', 'Background mortality: "Untreated" aged animals (no vaccine, no adjuvant, NO challenge virus) observed alongside the d60 challenges',
    f"alive {ua}/{un} ({100*ua/un:.0f}%): S06-E {u[0][0]}/7, S06-F {u[1][0]}/7, S06-G {u[2][0]}/7; deaths on days 4 (S06-E) and 3, 7, 10 (S06-G); vs PSLN-344 d60 14/21, Fisher p={p_u:.2f}",
    '; '.join(x[2] for x in u), 'count of status 0 ÷ rows; two-sided Fisher exact vs PSLN-344 d60 (14/21)')
p1 = stats.fisher_exact([[13,1],[10,4]])[1]; p2 = stats.fisher_exact([[20,1],[14,7]])[1]
add('E17', 'Efficacy', 'PSLN-344 aged: d14 vs d60 survival', f"matched vaccine/challenge pairs (Aichi→PR8 and bivalent→rgH5N1): d14 13/14 vs d60 10/14, Fisher p={p1:.2f}; all d14 (incl. homologous S03-I) 20/21 vs all d60 14/21, p={p2:.3f}",
    'S06!D17:D23, S06!P17:P23 vs S06!J48:J54, S06!P48:P54; plus S03!E38:E44 and S06!D85:D91', 'two-sided Fisher exact on alive/dead')
# S03-J
s = {g: sv('S03-J', g) for g in ['Sham','PSLN-212','PSLN-344']}
d344 = s['PSLN-344'][3]
add('E18', 'Efficacy', 'S03-J: rgH5N1 vaccine, wild-type VN04 H5N1 challenge 2 days later (age of animals not stated; challenge dose not stated)',
    f"alive at d21: PSLN-344 {s['PSLN-344'][0]}/{s['PSLN-344'][1]} (only {int(d344.day.notna().sum())} rows carry a day value; S03!G46 is blank), PSLN-212 {s['PSLN-212'][0]}/{s['PSLN-212'][1]}, Sham {s['Sham'][0]}/{s['Sham'][1]}; block label says n=9",
    f"S03!G17:J46", 'count of status 0 ÷ rows per arm')
# S15-H
h = {g: sv('S15-H', g) for g in ['3d Vaccine','3d PSLN-344','3d Vaccine+PSLN-344']}
a = h['3d Vaccine'][3]; b = h['3d PSLN-344'][3]; c = h['3d Vaccine+PSLN-344'][3]
add('E19', 'Efficacy/mechanism', 'S15-H: aged BALB/c, intranasal dose 3 days before 5×mLD50 rgH5N1 — vaccine alone vs PSLN-344 alone vs both',
    f"alive: vaccine alone {h['3d Vaccine'][0]}/7 (deaths d{sorted(a[a.event==1].day.astype(int))}), PSLN-344 alone {h['3d PSLN-344'][0]}/7 (deaths d{sorted(b[b.event==1].day.astype(int))}), vaccine+PSLN-344 {h['3d Vaccine+PSLN-344'][0]}/7; log-rank adjuvant-alone vs vaccine-alone p={logrank_test(a.day,b.day,a.event,b.event).p_value:.2f}; combination vs adjuvant alone p={fmt_p(logrank_test(c.day,b.day,c.event,b.event).p_value)}",
    'S15!A73:D93', 'count of status 0 ÷ 7; two-sided log-rank')
# imprinting
IMP = ['S06-E (r71-105, imprint PR8)','S06-F (r71-105, imprint Perth)']
parts=[]
for g in ['Naïve+PSLN-212','Imprinting+PSLN-212','Naïve+PSLN-344','Imprinting+PSLN-344']:
    x = [sv(b,g) for b in IMP]; parts.append(f"{g}: PR8 {x[0][0]}/7, Perth {x[1][0]}/7")
add('E20', 'Efficacy', 'Imprinting model (10-mo BALB/c infected with 1×mLD50 PR8 or saline; bivalent vaccine 4 months later; challenge 5×LD50 PR8 or Perth H3N2)', '; '.join(parts),
    'S06!G71:K98 (PR8), S06!M71:Q98 (Perth)', 'count of status 0 ÷ 7 per arm')
# young
parts=[]
for blk, nm in [('S09-B','Aichi→PR8 d21'),('S09-D','CA09→Perth d21'),('S09-F','bivalent→rgH5N1 d180')]:
    parts.append(f"{nm}: PSLN-344Y {sv(blk,'PSLN-344Y')[0]}/{sv(blk,'PSLN-344Y')[1]}, PSLN-212Y {sv(blk,'PSLN-212Y')[0]}/{sv(blk,'PSLN-212Y')[1]}, Sham {sv(blk,'Sham')[0]}/{sv(blk,'Sham')[1]}")
add('E21', 'Efficacy', 'Young BALB/c: PSLN-344 vs PSLN-212', '; '.join(parts), 'S09!A12:D35; S09!A39:D62; S09!A66:D88', 'count of status 0 ÷ rows per arm')
e = {g: sv('S13-E', g) for g in ['Naïve','Sham','CMP-204(Y)','PSLN-344(Y)']}
add('E22', 'Efficacy', 'S13-E young BALB/c, homologous 10×mLD50 CA09 at d14', '; '.join(f"{g} {e[g][0]}/{e[g][1]}" for g in e) + ' (block label says n=5; 7 rows per arm)', 'S13!R3:V30', 'count of status 0 ÷ rows')
# young d180 recovery
g = OBS[OBS.block=='S09-G'].copy(); g['day']=g.row_label.astype(float)
for day in [12,14]:
    a = g[(g.group=='PSLN-344Y')&(g.day==day)]; b = g[(g.group=='PSLN-212Y')&(g.day==day)]
    add(f'E23-d{day}', 'Efficacy/durability', f'S09-G young, challenge 180 d after vaccination: body weight on day {day} post-challenge (all animals survived)',
        f"PSLN-344Y {ms(a)} vs PSLN-212Y {ms(b)} % of day-0 weight; Student t p={fmt_p(stats.ttest_ind(a.value,b.value).pvalue)}", f"{rng(a.cell)} vs {rng(b.cell)}", 'arithmetic mean ± SD of per-animal % baseline weight; two-sided Student t')
# survivors' nadir aged PSLN-344 vs young
M = pd.read_csv('bw_morbidity_survivors.csv')
blks = ['S13-F','S15-A','S15-B','S15-C','S15-D','S15-E','S15-F','S15-G','S15-M','S15-O']
from bw_vs_surv import bw_infer
allA=[]; allY=[]
for bwb in blks:
    B = bw_infer(bwb); d = OBS[OBS.block==bwb]
    for grp, acc in [('PSLN-344', allA), ('PSLN-212(Y)', allY)]:
        al = B[(B.group==grp)&(B.status=='alive')].rep
        acc += list(d[(d.group==grp)&(d.rep.isin(al))].groupby('rep')['value'].min().values)
add('E24', 'Efficacy/morbidity', 'Post-challenge weight nadir among survivors (10 weight blocks paired to aged challenge experiments)',
    f"aged PSLN-344 {np.mean(allA):.1f} ± {np.std(allA,ddof=1):.1f}% of baseline (n={len(allA)} animals) vs young PSLN-212 {np.mean(allY):.1f} ± {np.std(allY,ddof=1):.1f}% (n={len(allY)}); Student t p={fmt_p(stats.ttest_ind(allA,allY).pvalue)}",
    'S13-F, S15-A…G, S15-M, S15-O (PSLN-344 and PSLN-212(Y) columns)', "per-animal minimum over d2–d14; animals whose trace goes blank or is carried forward unchanged to d14 (≥3 identical terminal values, or 2 identical terminal values <90%) are treated as dead and excluded; pooled across blocks")

# ============ I: immunogenicity ============
def imm(id_, blk, label, log=False, lod_half=None, unit=''):
    gs = [g for g in ['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)'] if len(ob(blk,g))]
    if log:
        vals = {g: gmt(ob(blk,g), lod_half) for g in gs}; desc = 'GMT: ' + ', '.join(f"{g} {vals[g]:,.0f}" if vals[g] >= 10 else f"{g} {vals[g]:.1f}" for g in gs)
        red = 'geometric mean of reciprocal titres' + (f' (values printed as 0 = below the 1:10 starting dilution, set to {lod_half})' if lod_half else '') + '; one-way ANOVA + Tukey HSD on log2 titres'
    else:
        vals = {g: ob(blk,g).value.mean() for g in gs}; desc = ', '.join(f"{g} {ms(ob(blk,g))}" for g in gs)
        red = 'arithmetic mean ± SD; one-way ANOVA + Tukey HSD on printed values'
    p1 = tukey(blk,'PSLN-344','PSLN-212',log=log,lod_half=lod_half); p2 = tukey(blk,'PSLN-344','PSLN-212(Y)',log=log,lod_half=lod_half) if 'PSLN-212(Y)' in gs else np.nan
    extra = f"; PSLN-344/PSLN-212 = {vals['PSLN-344']/vals['PSLN-212']:.1f}×"
    if 'PSLN-212(Y)' in gs: extra += f"; % of young: PSLN-212 {100*vals['PSLN-212']/vals['PSLN-212(Y)']:.0f}%, PSLN-344 {100*vals['PSLN-344']/vals['PSLN-212(Y)']:.0f}%"
    extra += f"; Tukey p (344 vs 212) {fmt_p(p1)}" + (f", (344 vs young) {fmt_p(p2)}" if not np.isnan(p2) else '')
    src = '; '.join(rng(ob(blk,g).cell) for g in gs)
    add(id_, 'Immunogenicity', f"{blk}: {label}{unit}", desc + extra, src, red)
imm('I1','S03-A','serum IgG vs CA09 H1N1, d14', log=True)
imm('I2','S03-C','HAI vs CA09 H1N1, d14', log=True, lod_half=5)
imm('I3','S03-D','neutralising titre vs CA09 H1N1, d14', log=True)
imm('I4','S03-E','serum IgG vs Aichi H3N2, d14', log=True)
imm('I5','S03-G','HAI vs Aichi H3N2, d14', log=True, lod_half=5)
imm('I6','S03-H','neutralising titre vs Aichi H3N2, d14', log=True)
imm('I7','S03-K','MLN germinal-centre B cells, d7 (%)')
imm('I8','S04-A ICOS-high','MLN ICOS-high Tfh, d7 (%)')
imm('I9','S04-B Foxp3+','MLN Tfr (Foxp3+ of CXCR5+ CD4), d7 (%)')
imm('I10','S04-C','MLN Tfr, d30 (%)')
imm('I11','S04-D','lung Treg, d7 (%)')
imm('I12','S05-D','lung Ki-67+ CD8 T cells, d3 (%)')
imm('I13','S05-E','lung GZMB+ CD8 T cells, d3 (%)')
imm('I14','S05-F','MLN IFN-γ+ CD8 T cells after rgH5N1 restimulation, d14 (%)')
imm('I15','S05-G','MLN IFN-γ+ CD8 T cells after rgH5N1 restimulation, d60 (%)')
imm('I16','S05-H','MLN GZMB+ CD8 T cells, d60 (%)')
imm('I17','S05-I','lung CD69+CD103+ resident-memory CD8 T cells, d25 (%)')
imm('I18','S14-A H1N1','MLN IFN-γ+ CD8 T cells after CA09 restimulation (%)')
imm('I19','S14-A H3N2','MLN IFN-γ+ CD8 T cells after Aichi restimulation (%)')
imm('I20','S13-I','serum IgG vs CA09, d28 after d14 boost', log=True)
imm('I21','S13-J','serum IgG vs Aichi, d28 after d14 boost', log=True)
imm('I22','S13-A','serum IgG2a vs CA09, d14', log=True)
imm('I23','S13-B','serum IgG1 vs CA09, d14', log=True)
# IgG2a/IgG1 recomputed
for id_, a, b, q, strain in [('I24','S13-A','S13-B','S03-B','CA09'),('I25','S13-C','S13-D','S03-F','Aichi')]:
    rec = {g: ob(a,g).value.values/ob(b,g).value.values for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']}
    printed = {g: ob(q,g).value.mean() for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']}
    add(id_, 'Immunogenicity / data reconciliation', f"IgG2a:IgG1 titre quotient vs {strain}, d14 — recomputed per animal from {a} ÷ {b}",
        '; '.join(f"{g} {rec[g].mean():.2f} ± {rec[g].std(ddof=1):.2f}" for g in rec) + f". Printed {q} columns read PSLN-212 {printed['PSLN-212']:.2f}, PSLN-344 {printed['PSLN-344']:.2f}, PSLN-212(Y) {printed['PSLN-212(Y)']:.2f}: the same 15 values with the three headers rotated by one position",
        f"{rng(ob(a,'PSLN-212').cell)}…{rng(ob(a,'PSLN-212(Y)').cell)} ÷ {rng(ob(b,'PSLN-212').cell)}…{rng(ob(b,'PSLN-212(Y)').cell)}; printed quotient {rng(ob(q,'PSLN-212').cell)}…{rng(ob(q,'PSLN-212(Y)').cell)}",
        'row-wise IgG2a ÷ IgG1 (same row = same animal), arithmetic mean ± SD; matched to printed quotient values to 3 significant figures')
# restoration summary
T = pd.read_csv('immuno_tukey_summary.csv')
pos_blocks = ['S01-A 16h','S01-F','S02-A','S02-B','S02-C','S02-D CD40','S02-D CD86','S02-E','S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S03-K','S04-A ICOS-low','S04-A ICOS-high','S05-D','S05-E','S05-F','S05-G','S05-H','S05-I','S13-H','S14-A H1N1','S14-A H3N2']
# add S01-F (has 5 groups incl. 344(Y)) – not in Tukey file because row_label None? ensure present
R = T[T.block.isin(pos_blocks)].copy()
missing = [b for b in pos_blocks if b not in set(R.block)]
add('I26', 'Immunogenicity', f"Restoration index across {len(R)} single-time-point readouts where higher = stronger response (innate, DC, T-cell, B-cell, antibody; d14 single-dose titres as GMT)",
    f"PSLN-344 aged = median {R.pct_of_young_344.median():.0f}% of the young PSLN-212 value (IQR {R.pct_of_young_344.quantile(.25):.0f}–{R.pct_of_young_344.quantile(.75):.0f}%, range {R.pct_of_young_344.min():.0f}–{R.pct_of_young_344.max():.0f}%); PSLN-212 aged = median {R.pct_of_young_212.median():.0f}% (IQR {R.pct_of_young_212.quantile(.25):.0f}–{R.pct_of_young_212.quantile(.75):.0f}%, range {R.pct_of_young_212.min():.0f}–{R.pct_of_young_212.max():.0f}%)",
    'blocks: ' + ', '.join(R.block), "for each block: group mean (GMT for titres) of aged arm ÷ group mean of PSLN-212(Y) ×100; median and IQR across blocks" + (f" [not included: {missing}]" if missing else ''))
R.to_csv('restoration_index.csv', index=False)

# ============ M: mechanism ============
def two(id_, blk, a, b, label, row=None):
    x = ob(blk,a,row); y = ob(blk,b,row)
    add(id_, 'Mechanism', f"{blk}: {label}", f"{a} {ms(x)} vs {b} {ms(y)}; ratio {x.value.mean()/y.value.mean():.2f}; Student t p={fmt_p(stats.ttest_ind(x.value,y.value).pvalue)}", f"{rng(x.cell)} vs {rng(y.cell)}", 'arithmetic mean ± SD; two-sided Student t')
def multi(id_, blk, label, pairs, row=None, groups=None):
    gs = groups or list(OBS[OBS.block==blk].group.unique())
    desc = ', '.join(f"{g} {ms(ob(blk,g,row))}" for g in gs)
    ps = '; '.join(f"Tukey p ({a} vs {b}) {fmt_p(tukey(blk,a,b,row=row))}" for a,b in pairs)
    add(id_, 'Mechanism', f"{blk}: {label}", desc + '; ' + ps, '; '.join(rng(ob(blk,g,row).cell) for g in gs), 'arithmetic mean ± SD; one-way ANOVA + Tukey HSD' + (f' within the {row} row' if row else ''))
multi('M1','S01-A 16h','lung Ifnb1 mRNA 16 h after adjuvant alone (fold vs untreated)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)'),('PSLN-212','PSLN-212(Y)'),('PSLN-344(Y)','PSLN-212(Y)')])
multi('M2','S01-A 72h','lung Ifnb1 mRNA 72 h', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')])
multi('M3','S01-D','lung monocytes, day 4 (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')], row='4')
multi('M3b','S01-D','lung monocytes, day 8 (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')], row='8')
multi('M4','S01-E','lung CD11b+ DC, day 4 (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)'),('PSLN-344(Y)','PSLN-212(Y)')], row='4')
multi('M4b','S01-E','lung CD11b+ DC, day 8 (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')], row='8')
multi('M5','S02-A','lung CCR7+ migratory CD11b+ DC, 72 h (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')])
multi('M6','S02-D CD40','CD40+ of MLN CD11b+ DC, d3 (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')])
multi('M7','S02-D CD86','CD86+ of MLN CD11b+ DC, d3 (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')])
multi('M8','S02-E','OT-I proliferation driven by sorted MLN CD11b+ DC (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)'),('PTX','PSLN-344'),('PSLN-344(Y)','PSLN-212(Y)')])
multi('M9','S02-F','lung Gm-csf mRNA at 36 h (fold)', [('PSLN-344','PSLN-212'),('PSLN-212','Sham')], row='36h')
multi('M10','S02-G','lung Ly6C+ CD11c+MHC-II+ cells d5 ± recombinant GM-CSF (%)', [('PSLN-212','PSLN-212+GM-CSF')])
multi('M11','S02-H','donor-derived (CD45.2+) monocyte-derived DC d3 after bone-marrow transfer, PSLN-344 + vaccine (%)', [('WT w/o cDC','IFN w/o cDC'),('IFN w/o cDC','GMCSF'),('WT w/o cDC','GMCSF')])
two('M12','S02-I','PSLN-344(Y)','PSLN-344(Y)+INCB3344','lung GZMB+ CD8 T cells d5 ± CCR2 antagonist (young animals) (%)')
two('M13','S07-B monocytes','PSLN-344','PSLN-344+INCB3344','lung CD11b+Ly6C+ monocytes ± CCR2 antagonist (%)')
two('M14','S07-B Ly6C+ Mphi','PSLN-344','PSLN-344+INCB3344','lung Ly6C+ macrophages ± CCR2 antagonist (%)')
two('M15','S11-C','CBX-','CBX+','recruited lung monocytes d3 ± carbenoxolone (%)')
two('M16','S01-C','WT','SPA/D','DiD+ alveolar macrophages 16 h, wild-type vs Sftpa1−/−Sftpd−/− (%)')
multi('M17','S01-B','SRB+ alveolar epithelial cells 16 h (%)', [('AECII/PSLN-SRB','AECII/FreeSRB'),('AECII/PSLN-SRB','AECI/PSLN-SRB')])
multi('M18','S05-C','proliferating OT-I CD8 T cells d4 ± pertussis toxin (%)', [('Lung','Lung+PTX'),('MLN','MLN+PTX')])
two('M19','S12-A','WT to WT','IFNAR-/- to WT','infiltrating donor monocytes d3 (young recipients) (%)')
multi('M20','S11-E','lung CD206+ macrophages (%) (time point not stated)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')])
# S07-A as printed
a = ob('S07-A','PSLN-212','5'); b = ob('S07-A','PSLN-344','5')
add('M21', 'Mechanism (unresolved)', 'S07-A: lung Ly6C+CCR2+ macrophages on day 5 (×10^5 cells), as printed', f"PSLN-212 {ms(a)} vs PSLN-344 {ms(b)}; Student t p={fmt_p(stats.ttest_ind(a.value,b.value).pvalue)} — direction is opposite to S01-D/S07-B", f"{rng(a.cell)} vs {rng(b.cell)}", 'arithmetic mean ± SD (n=3); two-sided Student t')
a = ob('S07-C','col B: Ly6C-CD206+ MΦ'); b = ob('S07-C','col C: Ly6C-CD206+ MΦ')
add('M22', 'Mechanism (unresolved)', 'S07-C: lung Treg 4 d after transfer of sorted donor macrophages; both columns carry the same header "Ly6C-CD206+ MΦ"', f"column B {ms(a)} vs column C {ms(b)}; Student t p={fmt_p(stats.ttest_ind(a.value,b.value).pvalue)} — which column is the Ly6C+CD206− subset cannot be told from the file", 'S07!B16:B20 vs S07!C16:C20', 'arithmetic mean ± SD; two-sided Student t')

# ============ D: dose / CMC ============
d = OBS[OBS.block=='S08-A'].copy(); d['dose']=d.row_label.astype(float); m = d.groupby(['group','dose']).value.mean().unstack(0)
add('D1','Dose–response','S08-A: lung Ifnb1 16 h vs dose (fold; n=3 per dose; age of animals not stated)',
    '; '.join(f"{int(k)} µg: PSLN-212 {m.loc[k,'PSLN-212']:.1f}, PSLN-344 {m.loc[k,'PSLN-344']:.1f}, CMP-204 {m.loc[k,'CMP-204']:.1f}" for k in m.index), 'S08!B3:J7', 'arithmetic mean of 3 animals per dose')
from scipy.optimize import curve_fit
def hill(dose, emax, ed50, h): return np.log(1 + (emax-1)*dose**h/(ed50**h + dose**h))
fit = {}
for gname in ['PSLN-212','PSLN-344']:
    x = d[d.group==gname]; p, cov = curve_fit(hill, x.dose.values, np.log(x.value.values), p0=[x.value.max(), 10, 2], bounds=([1,0.5,0.3],[500,200,8]), maxfev=20000); fit[gname]=(p, np.sqrt(np.diag(cov)))
add('D2','Dose–response','S08-A Hill fit: E = 1 + (Emax−1)·d^h/(ED50^h + d^h)',
    '; '.join(f"{k}: Emax {v[0][0]:.1f} (SE {v[1][0]:.1f}), ED50 {v[0][1]:.1f} µg (SE {v[1][1]:.1f})" for k,v in fit.items()) + f"; PSLN-344 at 10 µg ({m.loc[10,'PSLN-344']:.1f}) exceeds PSLN-212 at 40 µg ({m.loc[40,'PSLN-212']:.1f})",
    'S08!E3:J7', 'non-linear least squares on ln(fold) for the 15 animals per preparation; baseline fixed at 1')
gs = ['CMP-204','PSLN-212','PSLN-R848','PSLN-212/R848','PSLN-344']
add('D3','CMC','S08-B: encapsulation efficiency (%)', ', '.join(f"{g} {ms(ob('S08-B',g))}" for g in gs) + f"; Tukey p (PSLN-344 vs PSLN-212) {fmt_p(tukey('S08-B','PSLN-344','PSLN-212'))}", 'S08!A11:O11', 'arithmetic mean ± SD of 3 preparations; one-way ANOVA + Tukey')

# ============ S: safety ============
d = OBS[OBS.block=='S08-D'].copy(); d['day']=d.row_label.astype(float)
nad = d[d.day>0].groupby(['group','rep']).value.min().reset_index()
parts=[]
for gname in ['Vaccine','PSLN-212','PSLN-344','PSLN-212(Y)','CMP-204','PSLN-212/R848']:
    x = nad[nad.group==gname].value; parts.append(f"{gname} {x.mean():.1f} ± {x.std(ddof=1):.1f}")
tkn = pairwise_tukeyhsd(nad.value, nad.group); resn = {frozenset(k): p for k,p in zip(itertools.combinations(tkn.groupsunique,2), tkn.pvalues)}
add('S1','Safety','S08-D: body weight after intranasal immunisation (CA09 vaccine + 20 µg adjuvant; n=5; 10 days) — per-animal nadir, % of day-0 weight',
    '; '.join(parts) + f"; Tukey p: PSLN-344 vs Vaccine {fmt_p(resn[frozenset(['PSLN-344','Vaccine'])])} (unadjusted t p={stats.ttest_ind(nad[nad.group=='PSLN-344'].value, nad[nad.group=='Vaccine'].value).pvalue:.2f}); PSLN-212/R848 vs Vaccine {fmt_p(resn[frozenset(['PSLN-212/R848','Vaccine'])])}",
    'S08!B21:AE26', 'per-animal minimum over days 2–10; arithmetic mean ± SD; one-way ANOVA + Tukey across the six arms')
for gname in ['PSLN-344','PSLN-212/R848','Vaccine']:
    x = d[(d.group==gname)&(d.day==10)]
    add(f"S2-{gname}",'Safety',f'S08-D: body weight on day 10, {gname}', ms(x) + ' % of day-0 weight', rng(x.cell), 'arithmetic mean ± SD of animals with a day-10 value')
CYT = pd.read_csv('S09A_cytokines.csv')
def cyt(tp, an, col): return CYT[(CYT.time==tp)&(CYT.analyte==an)][col].values[0]
add('S3','Safety','S09-A first panel (16 h): lung cytokine mRNA after adjuvant alone, aged PSLN-344 vs young PSLN-212 (fold ratio)',
    '; '.join(f"{an} {cyt('16h',an,'344/212(y) fold'):.2g}× (p={fmt_p(cyt('16h',an,'p 344v212(y)'))})" for an in ['Ifnb1','Il6','Ccl2','Ccl3','Ccl5','Tnf','Il10']),
    'S09!Q3:S9 vs S09!T3:V9', 'difference of mean log10 values (n=3 each) back-transformed (10^Δ); Tukey HSD on log10 values across the 7 arms')
add('S4','Safety','S09-A second panel (printed "16h"; its Ifnb1 row equals log10 of S01-A 72 h values → read as 72 h): aged PSLN-344 vs young PSLN-212 (fold ratio)',
    '; '.join(f"{an} {cyt('72h*',an,'344/212(y) fold'):.2g}× (p={fmt_p(cyt('72h*',an,'p 344v212(y)'))})" for an in ['Ifnb1','Il6','Ccl2','Ccl3','Ccl5','Tnf','Il10']),
    'S09!AN3:AP9 vs S09!AQ3:AS9', 'as S3')
add('S5','Safety','S09-A second panel (72 h): aged PSLN-344, fold over PBS',
    '; '.join(f"{an} {cyt('72h*',an,'PSLN-344 (fold)'):.2g}×" for an in ['Ifnb1','Il6','Ccl2','Ccl3','Ccl5','Tnf','Il10']) + '; aged PSLN-212: ' + '; '.join(f"{an} {cyt('72h*',an,'PSLN-212 (fold)'):.2g}×" for an in ['Il6','Ccl2','Tnf','Il10']),
    'S09!AN3:AP9, S09!AE3:AG9 (PBS S09!Y3:AA9)', '10^(mean log10), n=3')
add('S6','Safety','S09-A: PSLN-212/R848 at 16 h and 72 h, fold over PBS', f"16 h: Tnf {cyt('16h','Tnf','PSLN-212/R848 (fold)'):.0f}×, Il10 {cyt('16h','Il10','PSLN-212/R848 (fold)'):.0f}×; 72 h: Tnf {cyt('72h*','Tnf','PSLN-212/R848 (fold)'):.0f}×, Il10 {cyt('72h*','Il10','PSLN-212/R848 (fold)'):.0f}×, Il6 {cyt('72h*','Il6','PSLN-212/R848 (fold)'):.0f}×",
    'S09!N3:P9; S09!AK3:AM9', '10^(mean log10), n=3')
for an in ['Ifnb1','Tnf','Isg15']:
    blk = f'S10-A {an}'
    x = {g: ob(blk,g) for g in ['PBS','Sham','PSLN-344','CT']}
    add(f"S7-{an}",'Safety',f'S10-A: CNS {an} mRNA 36 h after intranasal bivalent vaccine ± adjuvant (aged; fold vs untreated)',
        ', '.join(f"{g} {ms(x[g])}" for g in x) + f"; Tukey p: PSLN-344 vs PBS {fmt_p(tukey(blk,'PSLN-344','PBS'))}, PSLN-344 vs Sham {fmt_p(tukey(blk,'PSLN-344','Sham'))}, cholera toxin vs PBS {fmt_p(tukey(blk,'CT','PBS'))}; unadjusted t PSLN-344 vs PBS p={stats.ttest_ind(x['PSLN-344'].value, x['PBS'].value).pvalue:.3f}",
        '; '.join(rng(x[g].cell) for g in x), 'arithmetic mean ± SD (n=5); one-way ANOVA + Tukey')
xc = OBS[(OBS.block=='S11-A')].set_index(['group','row_label','rep']).value; xd = OBS[(OBS.block=='S11-B')].set_index(['group','row_label','rep']).value
same = sum(abs(xc[i]-xd[i])<1e-9 for i in xc.index)
add('S8','Safety / data reconciliation','S11-B ("neutrophils") vs S11-A ("alveolar macrophages"): cell-by-cell identity', f"{same}/100 cells identical; 34 of the 40 cells in the first two replicate columns of each arm are identical", 'S11!B3:U7 vs S11!B10:U14', 'positional comparison of the two 5-day × 20-column grids')

# ============ Q: data reconciliation ============
sig = lambda blk: sorted((r.group, r.day, r.event) for r in SURV[SURV.block==blk].itertuples())
add('Q1','Data reconciliation','S06-D (bivalent→rgH5N1, challenge d3) vs S06-C (challenge d14)', ('all 28 (day, status) rows are identical' if sig('S06-C')==sig('S06-D') else 'rows differ'), 'S06!M3:Q30 vs S06!A34:E61', 'row-wise comparison')
cc = pd.read_csv('bw_vs_survival_crosscheck.csv')
mm = cc[(cc.surv_n>0)&(cc.bw_dead!=cc.surv_dead)]
add('Q2','Data reconciliation','Deaths implied by the body-weight block vs deaths in the paired time-to-event table (same-named arms)',
    '; '.join(f"{r.bw_block}/{r.surv_block} {r.group}: weights imply {r.bw_dead} dead, table says {int(r.surv_dead)}" for r in mm.itertuples()),
    'paired blocks listed', 'weight trace blank after a day, or terminal value repeated unchanged to d14, counted as a death')
cross = []
for panel in ['S09-A panel1 (cols A-V)','S09-A panel2 (cols X-AS)']:
    for tp in ['S01-A 16h','S01-A 72h']:
        n=0
        for g9,g1 in {'PBS':'Sham','CMP-204':'CMP-204','PSLN-212':'PSLN-212','PSLN-R848':'PSLN-R848','PSLN-212/R848':'PSLN-212/R848','PSLN-344':'PSLN-344','PSLN-212(y)':'PSLN-212(Y)'}.items():
            a = ob(panel,g9,'Ifnb1').value.values; b = np.log10(ob(tp,g1).value.values)
            n += sum(np.any(np.abs(b-x)<2e-3) for x in a)
        cross.append(f"{panel.split(' (')[0].replace('S09-A ','')} vs {tp}: {n}/21")
add('Q3','Data reconciliation','S09-A Ifnb1 rows matched against log10 of S01-A values', '; '.join(cross), 'S09!B3:V3, S09!Y3:AS3 vs S01!B3:F10, S01!H3:L10', 'each S09-A Ifnb1 value searched among log10(S01-A) values of the same arm, tolerance 0.002')


# ---- additional entries used in the memo
a1 = sv('S06-B','PSLN-344'); a2 = sv('S15-H','3d Vaccine+PSLN-344')
add('E25','Efficacy','Early protection in aged BALB/c, challenge 3 days after a single dose (S06-B Aichi→PR8; S15-H bivalent→rgH5N1)',
    f"PSLN-344 + vaccine {a1[0]+a2[0]}/{a1[1]+a2[1]} alive; comparators: S06-B Sham {sv('S06-B','Sham')[0]}/7, PSLN-212 {sv('S06-B','PSLN-212')[0]}/7; S15-H vaccine alone {sv('S15-H','3d Vaccine')[0]}/7, PSLN-344 alone {sv('S15-H','3d PSLN-344')[0]}/7",
    f"{a1[2]}; {a2[2]}; comparators S06!H3:I16, S15!B73:C86", 'count of status 0 ÷ rows; sum over the two experiments')
x = {g: ob('S03-C', g).value.values for g in ['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)']}
add('I2b','Immunogenicity / biomarker','S03-C: animals with HAI ≥ 1:40 vs CA09 at d14, and survival of the matched-strain challenge in parallel animals (S03-I, as printed)',
    '; '.join(f"{g}: {int((x[g]>=40).sum())}/5 at ≥40 (range {int(x[g].min()) if x[g].min()>0 else '<10'}–{int(x[g].max())}), survival {sv('S03-I',g)[0]}/7" for g in x),
    'S03!K3:O7; S03!B17:F51', 'count of animals with titre ≥ 40; survival as E1 (the S03-I columns headed CMP-204 and PSLN-212 may be PSLN-212 and Naïve — see Q4)')
# S08-C both readings
c = {g: ob('S08-C', g).value.mean() for g in ['AECII-PSLN-SRB','AECII-PSLN-344-SRB','AECI-PSLN-SRB','AECI-PSLN-344-SRB']}
b = {g: ob('S01-B', g).value.mean() for g in ['AECII/PSLN-SRB','AECI/PSLN-SRB']}
add('D4','Delivery / data reconciliation','S08-C: SRB+ alveolar epithelial cells 16 h, Mn-free vs Mn-containing particle; compared with S01-B',
    f"as printed: AEC-II {c['AECII-PSLN-SRB']:.1f}% (PSLN-SRB) vs {c['AECII-PSLN-344-SRB']:.1f}% (PSLN-344-SRB); AEC-I {c['AECI-PSLN-SRB']:.1f}% vs {c['AECI-PSLN-344-SRB']:.1f}%. S01-B gives AEC-II {b['AECII/PSLN-SRB']:.1f}% and AEC-I {b['AECI/PSLN-SRB']:.1f}% for PSLN-SRB, so the printed AEC-I/PSLN-SRB value ({c['AECI-PSLN-SRB']:.1f}%) conflicts with S01-B ({b['AECI/PSLN-SRB']:.1f}%); if the two middle headers of S08-C are transposed the blocks agree (AEC-II {c['AECII-PSLN-SRB']:.1f}% vs {c['AECI-PSLN-SRB']:.1f}%; AEC-I {c['AECII-PSLN-344-SRB']:.1f}% vs {c['AECI-PSLN-344-SRB']:.1f}%)",
    'S08!A14:D18; S01!B14:F15', 'arithmetic mean of 5 animals per column')
# data reconciliation extras
def bwvals(blk, g):
    d = OBS[(OBS.block==blk)&(OBS.group==g)].copy(); d['day']=d.row_label.astype(float); return d.pivot(index='day', columns='rep', values='value')
A = bwvals('S15-C','PSLN-344'); B = bwvals('S15-I','3d Vaccine+PSLN-344')
same = int(((A.loc[2:12].values - B.loc[2:12].values)==0).sum()); tot = A.loc[2:12].size
add('Q4','Data reconciliation','S03-I (time to event) vs S13-F (body weight, "the animals of S03-I"): arm names',
    'S03-I arms: Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y); S13-F arms: PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naïve. S13-F "PSLN-212" has 3 animals that regain weight and 4 whose last value is carried forward = the 3 alive/4 dead of the S03-I "CMP-204" column; S13-F "Naïve" has all 7 traces ending by day 6 = S03-I "PSLN-212" (all dead by day 6)',
    'S03!A16:F51; S13!B32:AJ40', 'comparison of header rows; deaths inferred from weight traces (blank after a day, or terminal value repeated to d14)')
add('Q5','Data reconciliation','S03-J (time to event) vs S13-G (body weight, "the animals of S03-J"): arm names and n',
    'S03-J arms: Sham, PSLN-212, PSLN-344 (label n=9; 10 status rows per arm; PSLN-344 has 9 day values). S13-G arms: PSLN-344, Sham, Naïve (n=10 each). S13-G "Naïve" shows 9 animals with carried-forward weights and 1 recovering = S03-J "Sham" (9 dead, 1 alive); S13-G "Sham" shows 5 traces carried forward from day 10–12, 1 still falling at day 14 and 4 recovering — closer to S03-J "PSLN-212" (7 dead on days 10–12, 3 alive) than to S03-J "Sham" (9 dead)',
    'S03!G16:J46; S13!B42:AE50', 'as Q4')
add('Q6','Data reconciliation','Body-weight values shared between nominally different experiments',
    f"S15-C PSLN-344 (challenge d14) vs S15-I Vaccine+PSLN-344 (challenge d3): {same}/{tot} values identical over days 2–12; S09-C day-12 row identical for PSLN-212Y and PSLN-344Y (8/8); S15-M PSLN-212(Y) animal 4 = S09-E PSLN-344Y animal 5 at all 7 post-challenge time points; S09-E PSLN-212Y animal 8 = S09-G PSLN-212Y animal 8 at all 7 time points",
    'S15!W24:AC29 vs S15!W73:AC78; S09!G18:N18 vs S09!W18:AD18; S15!L104:L110 vs S09!AA40:AA46; S09!N40:N46 vs S09!N67:N73', 'exact equality of values at the same day/position')
add('Q7','Data reconciliation','Stated n (block label) vs observations present',
    'S03-J label n=9, 10 rows per arm; S05-A and S05-B label n=3, 2 values per arm per day; S13-E label n=5, 7 rows per arm; S09-F Sham 7 rows while S09-G Sham has 8 weight columns; S08-D PSLN-212/R848 4 values on day 10 (cell W26 empty)',
    'S03!H17:J46; S05!B3:I5, S05!B8:I10; S13!S3:V30; S09!B66:B72 vs S09!O66:V66; S08!V26:Z26', 'row/column counts')
# power
from power_calc import power_fisher
add('P1','Design','Power of the existing design and sample size for the confirmatory study (two-sided Fisher exact, α=0.05, exact enumeration)',
    f"n=7/arm: power {power_fisher(0.81,0.10,7):.2f} for 81% vs 10%, {power_fisher(0.81,0.40,7):.2f} for 81% vs 40%; n needed per arm for 80% power: 8 (81% vs 10%), 25 (81% vs 40%), 34 (95% vs 67%)",
    'planning values taken from E11 and E15', 'exact binomial enumeration of Fisher-test rejections')


# weight at death: PSLN-344 d60 deaths vs untreated deaths
from bw_vs_surv import bw_infer as _bwi
fin344=[]; finU=[]
for bwb in ['S15-E','S15-F','S15-G']:
    B_ = _bwi(bwb); d_ = OBS[OBS.block==bwb]
    for grp, acc in [('PSLN-344', fin344), ('Untreated', finU)]:
        dead = B_[(B_.group==grp)&(B_.status!='alive')]
        for r_ in dead.itertuples():
            acc.append(float(d_[(d_.group==grp)&(d_.rep==r_.rep)].value.min()))
add('E16b','Efficacy','Day-60 experiments: lowest recorded weight of animals that died (identified in the weight blocks S15-E/F/G by a trace carried forward unchanged)',
    f"PSLN-344 + challenge: {', '.join(f'{v:.1f}%' for v in sorted(fin344))} of baseline (n={len(fin344)} of the 7 deaths in the survival tables); Untreated, unchallenged: {', '.join(f'{v:.1f}%' for v in sorted(finU))} (n={len(finU)} of 4)",
    'S15!W43:AC50, S15!W53:AC60, S15!W63:AC70 (PSLN-344); S15!AD43:AJ50, S15!AD63:AJ70 (Untreated)', 'per-animal minimum of the weight trace for animals classed as dead from the trace')
yk = sv('S15-L','PSLN-212(Y)')
ym = OBS[(OBS.block=='S15-M')&(OBS.group=='PSLN-212(Y)')&(OBS.row_label=='14')]
add('Q8','Data reconciliation','S15-L (young C57BL/6, PSLN-212(Y)) vs S15-M weights', f"time-to-event table: {yk[0]}/{yk[1]} alive, one death on day 12 (S15!A124,E124); weight block: all {len(ym)} animals have a day-14 weight ({ym.value.min():.1f}–{ym.value.max():.1f}% of baseline)",
    'S15!E124:E130; S15!I110:O110', 'row count vs non-empty day-14 weights')


# ---- sensitivity analyses for the pooled survival estimate
A10 = A9 + ['S06-D']
def pooled_counts(blks, g, remap=None):
    a = n = 0
    for b in blks:
        gg = (remap or {}).get((b, g), g); x = sv(b, gg); a += x[0]; n += x[1]
    return a, n
a3, n3 = pooled_counts(A10, 'PSLN-344'); a2, n2 = pooled_counts(A10, 'PSLN-212')
add('E11-s1','Efficacy (sensitivity)','Pooled survival if S06-D is counted as a tenth experiment', f"PSLN-344 {a3}/{n3} ({100*a3/n3:.0f}%) vs PSLN-212 {a2}/{n2} ({100*a2/n2:.0f}%)", 'E1–E10', 'sum of alive ÷ sum of animals')
a2b, n2b = pooled_counts(A9, 'PSLN-212', remap={('S03-I','PSLN-212'):'CMP-204'})
lr_s = strat_logrank(A9, 'PSLN-344', 'PSLN-212', mapB={'S03-I':'CMP-204'})
add('E11-s2','Efficacy (sensitivity)','Pooled survival if the S03-I column headed "CMP-204" is taken to be the PSLN-212 arm (the reading suggested by the S13-F weight block)', f"PSLN-344 51/63 (81%) vs PSLN-212 {a2b}/{n2b} ({100*a2b/n2b:.0f}%); stratified log-rank p={fmt_p(lr_s['p'])}; in S03-I itself 7/7 vs 3/7, log-rank p={fmt_p(logrank_test(SURV[(SURV.block=='S03-I')&(SURV.group=='PSLN-344')].day, SURV[(SURV.block=='S03-I')&(SURV.group=='CMP-204')].day, SURV[(SURV.block=='S03-I')&(SURV.group=='PSLN-344')].event, SURV[(SURV.block=='S03-I')&(SURV.group=='CMP-204')].event).p_value)}", 'E1–E9 with S03!C24:C30 in place of S03!D31:D37', 'as E11/E12')
bwmap = {'S03-I':'S13-F','S06-A':'S15-A','S06-B':'S15-B','S06-C':'S15-C','S06-E (r34-68)':'S15-E','S06-F (r34-68)':'S15-F','S06-G':'S15-G','S15-L':'S15-M','S15-N':'S15-O'}
tot_bw = {'PSLN-344':[0,0],'PSLN-212':[0,0],'PSLN-212(Y)':[0,0]}
for sb, bb in bwmap.items():
    B_ = _bwi(bb)
    for g_ in tot_bw:
        x_ = B_[B_.group==g_]; tot_bw[g_][0] += int((x_.status=='alive').sum()); tot_bw[g_][1] += len(x_)
add('E11-s3','Efficacy (sensitivity)','Pooled survival if deaths are read from the nine paired body-weight blocks instead of the time-to-event tables', '; '.join(f"{g_} {v[0]}/{v[1]} ({100*v[0]/v[1]:.0f}%)" for g_, v in tot_bw.items()), 'S13-F, S15-A, S15-B, S15-C, S15-E, S15-F, S15-G, S15-M, S15-O', 'animal counted dead if its weight trace goes blank or its terminal value is carried forward unchanged (rule in Appendix C); arms as labelled in the weight blocks')


# ---- age x manganese interaction on the dendritic-cell readouts that include all four arms
import statsmodels.api as _sm, statsmodels.formula.api as _smf
_parts = []; _src = []
for blk_, row_, nm_ in [('S01-A 16h', None, 'lung Ifnb1 16 h'), ('S01-E', '4', 'lung CD11b+ DC d4'), ('S01-F', None, 'lung cDC1 72 h'), ('S02-C', None, 'antigen+ DC in lymph node 36 h'), ('S02-E', None, 'DC-driven OT-I proliferation')]:
    d_ = OBS[(OBS.block == blk_) & OBS.group.isin(['PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)'])].copy()
    if row_ is not None: d_ = d_[d_.row_label == row_]
    d_['age'] = np.where(d_.group.str.contains(r'\(Y\)'), 'young', 'aged'); d_['mn'] = np.where(d_.group.str.contains('344'), 'Mn', 'none')
    a_ = _sm.stats.anova_lm(_smf.ols('value ~ C(age)*C(mn)', data=d_).fit(), typ=2); g_ = d_.groupby(['age', 'mn']).value.mean()
    _parts.append(f"{nm_} [{blk_}]: aged ×{g_['aged','Mn']/g_['aged','none']:.2f}, young ×{g_['young','Mn']/g_['young','none']:.2f}, interaction p={fmt_p(a_.loc['C(age):C(mn)','PR(>F)'])}")
    _src.append(rng(d_.sort_values('cell').cell) if False else f"{d_.cell.iloc[0]}…{d_.cell.iloc[-1]}")
add('M23', 'Mechanism', 'Effect of manganese (PSLN-344 ÷ PSLN-212) in aged versus young mice, for the five blocks that contain all four arms', '; '.join(_parts),
    'S01!B5:F5, B8:F10; S01!G32:Z32; S01!G36:Z36; S02!K3:M7, O3:O7; S02!K10:M14, O10:O14', 'ratio of arm means; two-way ANOVA (age × manganese), p-value of the interaction term')


# ---- homogeneity of survival across the nine experiments (supports pooling)
def _homog(g_):
    alive_ = np.array([sv(b_, g_)[0] for b_ in A9]); n_ = np.array([sv(b_, g_)[1] for b_ in A9])
    tab_ = np.vstack([alive_, n_ - alive_]); chi2_ = stats.chi2_contingency(tab_)[0]
    rng_ = np.random.default_rng(0); pool_ = np.concatenate([np.ones(alive_.sum()), np.zeros((n_ - alive_).sum())]); idx_ = np.cumsum(n_)[:-1]; cnt_ = 0; N_ = 20000
    for _ in range(N_):
        rng_.shuffle(pool_); a_ = np.array([x_.sum() for x_ in np.split(pool_, idx_)]); t_ = np.vstack([a_, n_ - a_]); e_ = t_.sum(1, keepdims=True) * t_.sum(0, keepdims=True) / t_.sum()
        cnt_ += (((t_ - e_)**2 / e_).sum() >= chi2_ - 1e-9)
    return alive_, chi2_, (cnt_ + 1) / (N_ + 1)
_h3 = _homog('PSLN-344'); _h2 = _homog('PSLN-212')
add('E12e', 'Efficacy', 'Do the nine experiments differ from one another in survival within an arm? (test of homogeneity)',
    f"PSLN-344 survivors per experiment {list(map(int,_h3[0]))} of 7: χ²={_h3[1]:.1f}, permutation p={_h3[2]:.2f}; PSLN-212 {list(map(int,_h2[0]))} of 7: χ²={_h2[1]:.1f}, permutation p={_h2[2]:.2f}",
    'E1–E9', 'Pearson χ² on the 2×9 table of alive/dead by experiment; p-value from 20,000 random re-allocations of the outcomes (fixed seed)')


# ---- least-favourable reading of every disputed record (ten experiments)
_bwmap10 = dict(bwmap); _bwmap10['S06-D'] = 'S15-D'
_w344 = []; _b212 = []
for sb_, bb_ in _bwmap10.items():
    B_ = _bwi(bb_)
    t344 = sv(sb_, 'PSLN-344')[0]; w344 = int((B_[B_.group == 'PSLN-344'].status == 'alive').sum())
    t212 = sv(sb_, 'PSLN-212')[0]; w212 = int((B_[B_.group == 'PSLN-212'].status == 'alive').sum())
    if sb_ == 'S03-I': t212 = max(t212, sv(sb_, 'CMP-204')[0])      # alternative arm identity
    _w344.append(min(t344, w344)); _b212.append(max(t212, w212))
add('E11-s4', 'Efficacy (sensitivity)', 'Least favourable reading for PSLN-344 across all ten experiments (S06-D included): for each experiment, the lower of the two survivor counts for PSLN-344 (time-to-event table, weight block) and the higher of the two for PSLN-212 (including the alternative arm identity in S03-I)',
    f"PSLN-344 {sum(_w344)}/70 ({100*sum(_w344)/70:.0f}%) vs PSLN-212 {sum(_b212)}/70 ({100*sum(_b212)/70:.0f}%); per experiment PSLN-344 {_w344}, PSLN-212 {_b212} (order: {', '.join(k.split(' ')[0] for k in _bwmap10)}); Fisher p={fmt_p(stats.fisher_exact([[sum(_w344), 70-sum(_w344)],[sum(_b212), 70-sum(_b212)]])[1])}",
    'time-to-event tables E1–E10 and weight blocks S13-F, S15-A…G, S15-M, S15-O', 'minimum (PSLN-344) or maximum (PSLN-212) of the two survivor counts per experiment, summed; two-sided Fisher exact')


# ---- cell populations that do / do not distinguish PSLN-344 from PSLN-212
multi('M24', 'S01-F', 'lung type 1 (cross-presenting) dendritic cells, 72 h (%)', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')])
def _tc(blk_, label_, id_):
    parts_ = []
    for day_ in ['2', '4', '6', '8']:
        a_ = ob(blk_, 'PSLN-344', day_); b_ = ob(blk_, 'PSLN-212', day_); v_ = ob(blk_, 'Vaccine', day_)
        parts_.append(f"day {day_}: PSLN-344 {a_.value.mean():.1f}, PSLN-212 {b_.value.mean():.1f}, vaccine alone {v_.value.mean():.1f} (Tukey p 344 vs 212 {fmt_p(tukey(blk_, 'PSLN-344', 'PSLN-212', row=day_))}; 344 vs vaccine {fmt_p(tukey(blk_, 'PSLN-344', 'Vaccine', row=day_))})")
    x_ = OBS[(OBS.block == blk_)]
    add(id_, 'Mechanism', f"{blk_}: {label_}, aged mice (%), n=5 per arm per day", '; '.join(parts_), f"{x_.cell.iloc[0]}:{x_.cell.iloc[-1].split('!')[1]}", 'arithmetic mean; one-way ANOVA + Tukey HSD across the four arms within each day')
_tc('S11-D', 'lung NK cells', 'M25')
_tc('S11-A', 'lung alveolar macrophages', 'M26')

LD = pd.DataFrame(L)
_ren = {'E11-Sham':'E11a','E11-PSLN-212':'E11b','E11-PSLN-344':'E11c','E11-PSLN-212(Y)':'E11d','E23-d12':'E23a','E23-d14':'E23b',
        'S2-PSLN-344':'S2a','S2-PSLN-212/R848':'S2b','S2-Vaccine':'S2c','S7-Ifnb1':'S7a','S7-Tnf':'S7b','S7-Isg15':'S7c'}
LD['ID'] = LD['ID'].replace(_ren)
import re as _re
def _key(i):
    m = _re.match(r'([A-Z])(\d+)(.*)', i); order = 'EIMDSQP'.index(m.group(1)); return (order, int(m.group(2)), 1 if m.group(3).startswith('-') else 0, m.group(3))
LD = LD.iloc[sorted(range(len(LD)), key=lambda k: _key(LD.ID.iloc[k]))].reset_index(drop=True)
LD.to_csv('evidence_ledger.csv', index=False)
import os as _os
LD.to_csv(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), '..', 'evidence_ledger.csv'), index=False)
with open('evidence_ledger.md','w') as f:
    f.write('| ID | What | Value | Source cells | Reduction |\n|---|---|---|---|---|\n')
    for r in LD.itertuples():
        f.write(f"| {r.ID} | {r.statement} | {r.value} | {r.source_cells} | {r.reduction} |\n")
print(len(LD), 'ledger rows')
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 220); pd.set_option('display.max_rows', 300)
for r in LD.itertuples(): print(f"\n[{r.ID}] {r.statement}\n    -> {r.value}\n    src: {r.source_cells}\n    red: {r.reduction}")

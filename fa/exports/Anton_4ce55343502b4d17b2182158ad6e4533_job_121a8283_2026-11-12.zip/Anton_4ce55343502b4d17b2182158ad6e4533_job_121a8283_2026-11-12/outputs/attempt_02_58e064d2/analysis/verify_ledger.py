"""
Independent check of the ledger: re-reads the quoted cell ranges straight from cells.json (not through parse_blocks)
and recomputes the quoted statistic. Covers survival counts (E1-E10), single-block means/GMTs (I- and M-series),
and a set of hand-specified spot checks.
"""
import json, re, os, numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
C = json.load(open(os.path.join(HERE, 'cells.json')))
L = pd.read_csv(os.path.join(HERE, 'evidence_ledger.csv')).set_index('ID')

def col2num(c):
    n = 0
    for ch in c: n = n*26 + (ord(ch)-64)
    return n
def num2col(n):
    s = ''
    while n: n, r = divmod(n-1, 26); s = chr(65+r) + s
    return s
def read(rng):
    sh, rest = rng.split('!'); a, b = (rest.split(':') + [rest])[:2] if ':' in rest else (rest, rest)
    ca, ra = re.match(r'([A-Z]+)(\d+)', a).groups(); cb, rb = re.match(r'([A-Z]+)(\d+)', b).groups()
    out = []
    for r in range(int(ra), int(rb)+1):
        for c in range(col2num(ca), col2num(cb)+1):
            v = C[sh].get(f'{num2col(c)}{r}')
            if isinstance(v, (int, float)): out.append(float(v))
    return np.array(out)

ok = bad = 0
def check(label, got, want, tol):
    global ok, bad
    good = abs(got - want) <= tol
    ok += good; bad += (not good)
    if not good: print(f'  MISMATCH {label}: recomputed {got:.4g} vs ledger {want:.4g}')

# ---- E1..E10: alive counts per arm
for i in range(1, 11):
    r = L.loc[f'E{i}']
    ranges = re.findall(r'S\d\d![A-Z]+\d+:[A-Z]+\d+', r.source_cells)
    counts = re.findall(r'(\d+)/(\d+)', r.value)[:4]
    for rg, (a, n) in zip(ranges, counts):
        v = read(rg)
        check(f'E{i} {rg} alive', (v == 0).sum(), int(a), 0); check(f'E{i} {rg} n', len(v), int(n), 0)

# ---- I-series and M-series blocks built by imm()/multi(): "group mean ± sd (n=..)" or "GMT: group value"
def nums_mean_sd(valstr):
    return [(float(a), float(b), int(n)) for a, b, n in re.findall(r'(-?[\d.]+) ± ([\d.]+) \(n=(\d+)\)', valstr)]
for id_ in [i for i in L.index if re.fullmatch(r'[IM]\d+b?', i)]:
    r = L.loc[id_]
    ranges = [x.strip() for x in re.split(r';| vs ', r.source_cells) if re.fullmatch(r'\s*S\d\d![A-Z]+\d+:[A-Z]+\d+\s*', x)]
    if r.value.startswith('GMT:'):
        vals = [float(x.replace(',', '')) for x in re.findall(r'(?:Sham|CMP-204|PSLN-212|PSLN-344|PSLN-212\(Y\)) ([\d,\.]+)', r.value.split(';')[0])]
        for rg, want in zip(ranges, vals):
            v = read(rg); v = np.where(v <= 0, 5, v); got = np.exp(np.log(v).mean())
            check(f'{id_} {rg} GMT', got, want, 0.51 if want >= 10 else 0.06)
    else:
        trip = nums_mean_sd(r.value)
        if len(trip) != len(ranges) or not trip: continue
        for rg, (m, sd, n) in zip(ranges, trip):
            v = read(rg)
            check(f'{id_} {rg} mean', v.mean(), m, 0.006*abs(m) + 0.006); check(f'{id_} {rg} n', len(v), n, 0)
            check(f'{id_} {rg} sd', v.std(ddof=1), sd, 0.06*sd + 0.006)

# ---- spot checks, specified by hand
spot = [
 ('S1 PSLN-344 nadir', lambda: np.min(np.vstack([read(f'S08!Q{r}:U{r}') for r in range(22, 27)]), axis=0).mean(), 96.4, 0.05),
 ('S1 Vaccine nadir',  lambda: np.min(np.vstack([read(f'S08!AA{r}:AE{r}') for r in range(22, 27)]), axis=0).mean(), 98.2, 0.05),
 ('S2a PSLN-344 d10',  lambda: read('S08!Q26:U26').mean(), 99.8, 0.05),
 ('S2b R848 d10',      lambda: read('S08!V26:Z26').mean(), 90.6, 0.06),
 ('S7a CNS Ifnb1 344', lambda: read('S10!C3:C7').mean(), 1.32, 0.006),
 ('S7b CNS Tnf 344',   lambda: read('S10!H3:H7').mean(), 1.59, 0.006),
 ('S7c CNS Isg15 344', lambda: read('S10!M3:M7').mean(), 1.13, 0.006),
 ('S5 Tnf 72h 344 fold', lambda: 10**read('S09!AN8:AP8').mean(), 8.4, 0.06),
 ('S5 Il6 72h 344 fold', lambda: 10**read('S09!AN4:AP4').mean(), 7.2, 0.06),
 ('S5 Ccl2 72h 344 fold', lambda: 10**read('S09!AN5:AP5').mean(), 27, 0.6),
 ('S4 Tnf 344/young 72h', lambda: 10**(read('S09!AN8:AP8').mean() - read('S09!AQ8:AS8').mean()), 18, 0.6),
 ('S4 Il10 344/young 72h', lambda: 10**(read('S09!AN9:AP9').mean() - read('S09!AQ9:AS9').mean()), 37, 0.6),
 ('S6 R848 Tnf 16h', lambda: 10**read('S09!N8:P8').mean(), 202, 1),
 ('S6 R848 Il10 16h', lambda: 10**read('S09!N9:P9').mean(), 179, 1),
 ('D1 344 @10ug', lambda: read('S08!H5:J5').mean(), 21.1, 0.06),
 ('D1 212 @40ug', lambda: read('S08!E7:G7').mean(), 14.9, 0.06),
 ('D3 EE 344', lambda: read('S08!M11:O11').mean(), 54.8, 0.06),
 ('D3 EE 212', lambda: read('S08!D11:F11').mean(), 59.6, 0.06),
 ('E16 untreated alive', lambda: (read('S06!L62:L68') == 0).sum() + (read('S06!R62:R68') == 0).sum() + (read('S06!F99:F105') == 0).sum(), 17, 0),
 ('E18 344 status rows', lambda: len(read('S03!J37:J46')), 10, 0),
 ('E18 344 day rows', lambda: len(read('S03!G37:G46')), 9, 0),
 ('E19 combo alive', lambda: (read('S15!D87:D93') == 0).sum(), 6, 0),
 ('E19 adjuvant alone alive', lambda: (read('S15!C80:C86') == 0).sum(), 0, 0),
 ('E20 Impr+344 PR8 alive', lambda: (read('S06!K92:K98') == 0).sum(), 6, 0),
 ('E20 Impr+344 Perth alive', lambda: (read('S06!Q92:Q98') == 0).sum(), 6, 0),
 ('E20 Impr+212 PR8 alive', lambda: (read('S06!I78:I84') == 0).sum(), 4, 0),
 ('E23b 344Y d14', lambda: read('S09!W73:AD73').mean(), 95.6, 0.06),
 ('E23b 212Y d14', lambda: read('S09!G73:N73').mean(), 99.2, 0.06),
 ('I24 ratio 344 CA09', lambda: (read('S13!B3:B7') / read('S13!F3:F7')).mean(), 2.14, 0.006),
 ('I24 ratio 212 CA09', lambda: (read('S13!A3:A7') / read('S13!E3:E7')).mean(), 0.58, 0.006),
 ('I24 printed S03-B "PSLN-344" col', lambda: read('S03!H3:H7').mean(), 0.58, 0.006),
 ('I2b 212 HAI >=40', lambda: (read('S03!M3:M7') >= 40).sum(), 5, 0),
 ('Q6 S15-C vs S15-I identical', lambda: sum((read(f'S15!W{a}:AC{a}') == read(f'S15!W{b}:AC{b}')).sum() for a, b in zip(range(24, 30), range(73, 79))), 40, 0),
 ('S8 S11-A vs S11-B identical', lambda: sum((read(f'S11!B{a}:U{a}') == read(f'S11!B{b}:U{b}')).sum() for a, b in zip(range(3, 8), range(10, 15))), 35, 0),
]
for label, fn, want, tol in spot:
    check(label, float(fn()), want, tol)
print(f'checks passed: {ok}; mismatches: {bad}')

import numpy as np, pandas as pd, itertools, warnings
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from parse_blocks import OBS
warnings.filterwarnings('ignore')
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500)

print('=== S09-A lung cytokine transcripts (log10 fold vs untreated, n=3). Panel 1 = 16 h; panel 2 carries the same "16h" label but reproduces the S01-A 72 h Ifnb1 values -> treated as 72 h ===')
rows=[]
for panel, tp in [('S09-A panel1 (cols A-V)','16h'),('S09-A panel2 (cols X-AS)','72h*')]:
    d = OBS[OBS.block==panel]
    for an, x in d.groupby('row_label', sort=False):
        tk = pairwise_tukeyhsd(x['value'], x['group'])
        res = {frozenset(k): p for k,p in zip(itertools.combinations(tk.groupsunique,2), tk.pvalues)}
        m = x.groupby('group', sort=False)['value'].mean()
        r = dict(time=tp, analyte=an)
        for g in m.index: r[g+' (fold)'] = 10**m[g]
        r['344/212 fold'] = 10**(m['PSLN-344']-m['PSLN-212']); r['p 344v212'] = res[frozenset(['PSLN-344','PSLN-212'])]
        r['344/212(y) fold'] = 10**(m['PSLN-344']-m['PSLN-212(y)']); r['p 344v212(y)'] = res[frozenset(['PSLN-344','PSLN-212(y)'])]
        r['p 344vPBS'] = res[frozenset(['PSLN-344','PBS'])]
        rows.append(r)
T = pd.DataFrame(rows); T.to_csv('S09A_cytokines.csv', index=False)
print(T.to_string(float_format=lambda x: f'{x:.3g}'))

print('\n=== S10-A CNS transcripts at 36 h (linear fold, n=5): one-way ANOVA + Tukey ===')
for blk in ['S10-A Ifnb1','S10-A Tnf','S10-A Isg15']:
    x = OBS[OBS.block==blk]
    tk = pairwise_tukeyhsd(x['value'], x['group'])
    res = {frozenset(k): (p, md, lo, hi) for k,p,md,(lo,hi) in zip(itertools.combinations(tk.groupsunique,2), tk.pvalues, tk.meandiffs, tk.confint)}
    m = x.groupby('group', sort=False)['value'].agg(['mean','std'])
    print(blk, {g: f"{m.loc[g,'mean']:.2f}±{m.loc[g,'std']:.2f}" for g in m.index})
    for a,b in [('PSLN-344','PBS'),('PSLN-344','Sham'),('CT','PBS'),('PSLN-344','CT')]:
        p, md, lo, hi = res[frozenset([a,b])]
        tt = stats.ttest_ind(x[x.group==a].value, x[x.group==b].value)
        print(f'    {a} vs {b}: Tukey p={p:.3g}; unadjusted t-test p={tt.pvalue:.3g}; ratio of means={m.loc[a,"mean"]/m.loc[b,"mean"]:.2f}')
# what CNS effect size could n=5 have detected? (two-sample t, alpha .05 two-sided, 80% power)
from statsmodels.stats.power import TTestIndPower
for blk in ['S10-A Ifnb1','S10-A Tnf','S10-A Isg15']:
    x = OBS[OBS.block==blk]
    sd = np.sqrt((x[x.group=='PBS'].value.var(ddof=1)+x[x.group=='PSLN-344'].value.var(ddof=1))/2)
    es = TTestIndPower().solve_power(nobs1=5, alpha=0.05, power=0.8, ratio=1.0)
    print(f'  {blk}: pooled SD={sd:.2f}; minimum detectable difference at n=5/arm, 80% power = {es*sd:.2f} fold-units (i.e. {1+es*sd:.2f}x vs PBS=1.0); upper 95% CI of PSLN-344/PBS difference:', end=' ')
    a = x[x.group=='PSLN-344'].value.values; b = x[x.group=='PBS'].value.values
    diff = a.mean()-b.mean(); se = np.sqrt(a.var(ddof=1)/5+b.var(ddof=1)/5); dfw = (a.var(ddof=1)/5+b.var(ddof=1)/5)**2/((a.var(ddof=1)/5)**2/4+(b.var(ddof=1)/5)**2/4)
    print(f'{diff:.2f} [{diff-stats.t.ppf(.975,dfw)*se:.2f}, {diff+stats.t.ppf(.975,dfw)*se:.2f}]')

print('\n=== S08-D body weight after immunisation: per-animal nadir (minimum over d2-d10) ===')
d = OBS[OBS.block=='S08-D'].copy(); d['day']=d.row_label.astype(float)
nad = d[d.day>0].groupby(['group','rep'])['value'].min().reset_index()
print(nad.groupby('group', sort=False)['value'].agg(['mean','std','min','count']).round(2))
tk = pairwise_tukeyhsd(nad['value'], nad['group']); 
res = {frozenset(k): p for k,p in zip(itertools.combinations(tk.groupsunique,2), tk.pvalues)}
for a,b in [('PSLN-344','Vaccine'),('PSLN-212','Vaccine'),('PSLN-344','PSLN-212'),('PSLN-212/R848','Vaccine'),('CMP-204','Vaccine'),('PSLN-212(Y)','Vaccine')]:
    tt = stats.ttest_ind(nad[nad.group==a].value, nad[nad.group==b].value)
    print(f'   nadir {a} vs {b}: Tukey p={res[frozenset([a,b])]:.3g}; unadjusted t p={tt.pvalue:.3g}')
# days below 98%: 
for g, x in d.groupby('group', sort=False):
    piv = x.pivot(index='day', columns='rep', values='value')
    print(f'   {g:14s} mean by day:', piv.mean(axis=1).round(1).to_dict(), '| animals <95% at any time:', int((piv.min()<95).sum()), '/', piv.shape[1])
# d8: PSLN-344 vs PSLN-212, vs Vaccine
for day in [4,6,8,10]:
    for a,b in [('PSLN-344','Vaccine'),('PSLN-344','PSLN-212')]:
        xa = d[(d.group==a)&(d.day==day)].value; xb = d[(d.group==b)&(d.day==day)].value
        print(f'   d{day} {a} {xa.mean():.1f} vs {b} {xb.mean():.1f}: unadjusted t p={stats.ttest_ind(xa,xb).pvalue:.3g}')

print('\n=== S01-A Ifnb1 persistence: 72h / 16h ratio of group means ===')
for g in ['CMP-204','PSLN-212','PSLN-R848','PSLN-212/R848','PSLN-344','PSLN-212(Y)','PSLN-344(Y)']:
    a = OBS[(OBS.block=='S01-A 16h')&(OBS.group==g)].value.mean(); b = OBS[(OBS.block=='S01-A 72h')&(OBS.group==g)].value.mean()
    print(f'   {g:14s} 16h {a:.1f}  72h {b:.2f}  72h/16h = {100*b/a:.0f}%')

"""Assemble the memo: body + Appendix A (evidence ledger) + Appendix B (record conflicts) + Appendix C (methods)."""
import pandas as pd, re, os
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')

body = open('memo_body.md').read()
L = pd.read_csv('evidence_ledger.csv')

# ---------------- Appendix B: record conflicts ----------------
B = [
 ("B1", "S06-D vs S06-C; S15-D",
  "S06-D (bivalent vaccine, rgH5N1 challenge on day 3) is identical to S06-C (challenge on day 14) in all 28 rows. The weight block for S06-D (S15-D) shows two PSLN-344 animals and two young animals whose last weight is carried forward to day 14, which is how dead animals appear elsewhere in the sheet. The table shows no deaths in either arm.",
  "The day-3 rgH5N1 result (7/7) is not independent evidence and may be wrong.",
  "Excluded S06-D from the pooled estimate (sensitivity: E11-s1). Early protection is cited from S06-B, S15-H and S03-J only. [Q1, Q2]"),
 ("B2", "S03-I vs S13-F",
  "Same animals, different arm names. Survival table: Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y). Weight block: PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naïve. The weight-block arm called PSLN-212 (3 recover, 4 die) matches the survival column headed CMP-204. The weight-block arm called Naïve (all gone by day 8) matches the survival column headed PSLN-212.",
  "PSLN-344 is 7/7 either way. Aged PSLN-212 is 0/7 as printed, or 3/7 if the weight-block names are right.",
  "Primary analysis as printed. Sensitivity with the alternative reading: E11-s2. [Q4]"),
 ("B3", "S03-J vs S13-G",
  "Survival table arms: Sham, PSLN-212, PSLN-344. Weight block arms: PSLN-344, Sham, Naïve. Block label says n=9; there are 10 rows per arm. One PSLN-344 row has a status but no day (S03!G46 is empty). The age of the animals and the challenge dose are not stated. The annotation says observation ran 22 days; survivors are recorded at day 21.",
  "PSLN-344 is 10/10 (9 with a recorded day) either way. The comparator that survived 3/10 is either PSLN-212 or the empty-liposome control, so the contribution of manganese in the wild-type H5N1 model is unconfirmed.",
  "Reported on its own (E18). Not pooled. [Q5, Q7]"),
 ("B4", "S03-B, S03-F vs S13-A to S13-D",
  "The printed IgG2a:IgG1 quotients are exactly the per-animal ratios S13-A ÷ S13-B and S13-C ÷ S13-D, but with the three column headers rotated by one position.",
  "As printed, PSLN-344 would look IgG1-skewed (0.58 and 0.51). Recomputed: PSLN-344 2.14 and 2.73; PSLN-212 0.58 and 0.51; young 2.97 and 2.89.",
  "Used the recomputed ratios. The S13 labels are the ones that agree with total IgG in S03-A and S03-E. [I24, I25]"),
 ("B5", "S09-A, second panel (columns X to AS)",
  "Printed '16h', like the first panel. Its Ifnb1 row equals log10 of the S01-A 72 h values in 21 of 21 cells. The first panel matches the S01-A 16 h values in 21 of 21.",
  "Read as 16 h, the two panels would look like discordant replicates.",
  "Treated as the 72 h panel. [Q3, S4, S5]"),
 ("B6", "Body-weight blocks (S13-F, S13-G, S15-A to S15-O, S09-C/E/G)",
  "(a) After death, some arms are left blank and others carry the last value forward unchanged. (b) Identical values recur between experiments: S15-C PSLN-344 and S15-I Vaccine+PSLN-344 share 40 of 42 values over days 2 to 12; the S09-C day-12 row is the same for two arms; single animals are identical between S15-M and S09-E and between S09-E and S09-G. (c) Deaths implied by the weights differ from the survival table in ten arms.",
  "Mean weights would be biased if carried-forward values were averaged. The weight blocks are not independent confirmation of survival.",
  "Survival tables are primary. Weights are used only to describe morbidity, with carried-forward tails removed (rule in Appendix C), and as a sensitivity check (E11-s3). [Q2, Q6]"),
 ("B7", "'Untreated' arms of S06-E, S06-F, S06-G (rows 34–105)",
  "Per the annotation these are 20-month animals given no vaccine, no adjuvant and no challenge virus. 4 of 21 died within the 14-day window (1, 0 and 3).",
  "They are not infection controls. They show the background death rate at about 22 months, which matters for reading the day-60 results.",
  "Used as the background death rate. [E16, E16b]"),
 ("B8", "S11-B vs S11-A",
  "'Neutrophils' (S11-B) and 'alveolar macrophages' (S11-A) share 35 of 100 values, 34 of them in the first two replicate columns of each arm. The annotation says the two blocks came from lungs harvested in different ways.",
  "Neutrophil influx, a basic lung-safety readout, cannot be assessed.",
  "S11-B not used. [S8]"),
 ("B9", "S07-A",
  "As printed, Ly6C+CCR2+ macrophages expand with PSLN-212 (19.0 × 10⁵ on day 5) and not with PSLN-344 (3.4 × 10⁵). S01-D shows more monocytes with PSLN-344 (30.6% against 16.7%), and S07-B shows 15.4% Ly6C+ macrophages with PSLN-344.",
  "Either the two headers are swapped, or PSLN-212 diverts monocytes to macrophages. The file cannot tell which.",
  "Not used. [M21]"),
 ("B10", "S07-C",
  "Both columns carry the header 'Ly6C-CD206+ MΦ'. The annotation says one should be Ly6C+CD206−.",
  "The direction of the macrophage effect on regulatory T cells is unknown.",
  "Not used. [M22]"),
 ("B11", "S08-C vs S01-B",
  "S08-C prints 13.8% uptake for type I epithelial cells with PSLN-SRB. S01-B gives 3.8% for the same particle, cell type, dose and time. Transposing the two middle headers of S08-C reconciles the blocks.",
  "Whether manganese changes epithelial uptake: four-fold lower as printed, unchanged if transposed. Neither reading shows higher uptake.",
  "Cited only for 'not higher'. [D4]"),
 ("B12", "Stated n vs observations present",
  "S03-J: label n=9, 10 rows per arm. S05-A, S05-B: label n=3, 2 values per arm per day. S13-E: label n=5, 7 rows per arm. S09-F: the empty-liposome arm has 7 rows while its weight block has 8 animals (the annotation attributes the 7 to S09-B, where there are 8). S08-D: PSLN-212/R848 has 4 values on day 10.",
  "Minor.",
  "Used the observations present. [Q7]"),
 ("B13", "S05-A, S05-B, S05-I",
  "The annotation gives two incompatible immunisations for S05-A (ovalbumin; bivalent vaccine), and S05-B and S05-I refer back to it. The tetramer is NP366–374, which is presented by H-2Db (C57BL/6) and not by BALB/c (general knowledge, not from the file). n = 2 per arm per day in S05-A and S05-B.",
  "Tetramer kinetics and the resident-memory block are weaker evidence than their labels suggest.",
  "S05-A and S05-B not used for any conclusion. S05-I appears only as one of the 26 readouts in I26 and Figure 2."),
 ("B14", "S15-L vs S15-M",
  "The survival table has one death on day 12 in the young C57BL/6 arm. The weight block shows all seven young animals at 97–103% of baseline on day 14.",
  "The young benchmark is 62/63 or 63/63.",
  "As printed. [Q8]"),
 ("B15", "S15-L to S15-O; S15-J",
  "The challenge virus and the interval from vaccination to challenge are not stated for the C57BL/6 and Swiss Webster experiments. The interval is not stated for the PR8 challenge in the imprinting experiment.",
  "These experiments cannot be classed as matched-strain or cross-subtype.",
  "Kept in the pooled estimate as evidence across strains, and also shown separately. [E13, E14]"),
 ("B16", "S03-C, S03-G",
  "HAI values of 0 in the empty-liposome arm. Per the annotation the lowest dilution tested was 1:10.",
  "A geometric mean needs a positive value.",
  "Set to 5, half the lowest dilution. [I2, I5]"),
 ("B17", "S08, rows 89–101",
  "Unlabelled region: 14 in column A, zeros in columns C and D.",
  "Cannot be interpreted.",
  "Excluded."),
 ("B18", "S08-A, S08-B",
  "The fourth arm of S08-A is headed 'PSLN-344/R848', a preparation that is not in the materials list (elsewhere the R848 combination is PSLN-212/R848). The age of the S08-A animals is not stated. S08-B says encapsulation was read from CDN-1807 absorbance, but CMP-204 and PSLN-R848 contain no CDN-1807.",
  "Minor.",
  "Fourth arm of S08-A not used. S08-B used only for PSLN-344 against PSLN-212."),
 ("B19", "S09-A vs S01-A",
  "The control arm is called PBS in S09-A and Sham in S01-A, yet holds the same animals (values identical after log10). Per the annotation PBS is buffer and Sham is empty liposome.",
  "Minor: the identity of the baseline arm for the lung cytokine data.",
  "Noted."),
 ("B20", "S06 sheet labels",
  "The labels S06-E and S06-F are each used for two different experiments (rows 34–68 and rows 71–105).",
  "Risk of citing the wrong block.",
  "Referred to by row range in the ledger."),
 ("B22", "Described in the annotation, absent from the workbook",
  "The annotation mentions C57BL/6 mice at 15 months, particle size, zeta potential and electron microscopy. The workbook has no block for any of them.",
  "No particle characterisation beyond encapsulation efficiency can be checked.",
  "Listed as a gap (section 3.5)."),
 ("B21", "Conditions not stated",
  "Time point: S07-B, S11-E, S13-H, S14-A. Age of animals: S02-G, S08-A, S03-J, S05-C. Which adjuvant the PTX arm received: S02-C, S02-E.",
  "Minor for the conclusions drawn here.",
  "Cited with the gap noted in the ledger."),
]
B = sorted(B, key=lambda r: int(r[0][1:]))
Bdf = pd.DataFrame(B, columns=['No.', 'Blocks', 'What the file shows', 'Effect on the conclusions', 'What I did'])
Bdf.to_csv(os.path.join(ROOT, 'record_conflicts.csv'), index=False)

def md_table(df, widths):
    esc = lambda x: str(x).replace('|', '\\|').replace('\n', ' ')
    out = ['| ' + ' | '.join(df.columns) + ' |', '|' + '|'.join(':' + '-'*w for w in widths) + '|']
    for r in df.itertuples(index=False):
        out.append('| ' + ' | '.join(esc(v) for v in r) + ' |')
    return '\n'.join(out)

appA = L.rename(columns={'ID': 'ID', 'statement': 'Block and measure', 'value': 'Value', 'source_cells': 'Cells', 'reduction': 'Reduction'})[['ID', 'Block and measure', 'Value', 'Cells', 'Reduction']]

_vl = open(os.path.join(HERE, 'log_verify_ledger.txt')).read()
_m = re.search(r'checks passed: (\d+); mismatches: (\d+)', _vl)
n_checks = int(_m.group(1)) + int(_m.group(2)); check_result = 'all agree' if int(_m.group(2)) == 0 else f'{_m.group(2)} disagree'
appendix = f'''
## Appendix A. Evidence ledger

Each row is one number, or one set of numbers, used in the memo. "Cells" are worksheet addresses in `adjuvant_program_dataset.xlsx`. Group names are as printed in the workbook: "Sham" is vaccine plus empty liposome, and "(Y)" marks young animals. The same table is in `evidence_ledger.csv`.

{md_table(appA, [9, 30, 44, 22, 28])}

## Appendix B. Conflicts in the record and how each was handled

{md_table(Bdf, [5, 14, 40, 24, 22])}

## Appendix C. Methods

**Reading the workbook.** Every numeric cell was assigned to a block using the layout in the annotation. The only numeric cells left unassigned are axis labels (days, doses) and the unlabelled region in S08 rows 89–101. Group names were kept exactly as printed. The parsed values, each with its cell address, are in `analysis/tidy_observations.csv` and `analysis/tidy_time_to_event.csv`.

**Time to event.** Status 1 is a death or endpoint on that day. Status 0 is alive at the end of observation. Within an experiment, arms were compared with a two-sided log-rank test. For the pooled comparison, the log-rank observed-minus-expected counts and their variances were summed over experiments, so each experiment is its own stratum. The hazard ratio is the Peto one-step estimate. Proportions have exact (Clopper–Pearson) 95% confidence intervals.

**Single-time-point blocks.** Arithmetic mean and SD of the per-animal values. One-way ANOVA with Tukey's test across all arms printed in the block, or Student's t-test for two-arm blocks.

**Time-course and dose blocks.** Tukey's test across arms within each time point or dose.

**Titres.** Analysed on the log2 scale and summarised as geometric means. HAI values printed as 0 were set to 5.

**S09-A.** The block is on a log10 scale. Means were taken on that scale and back-transformed to fold-change.

**Restoration index (I26, Figure 2).** For each of 26 readouts where a higher value means a stronger response: the aged-arm mean (GMT for titres) divided by the young PSLN-212 mean. The median and interquartile range are taken across readouts.

**Dose-response (D2).** Least-squares fit of E = 1 + (Emax − 1)·dⁿ / (ED50ⁿ + dⁿ) to ln(fold-change), using the 15 animals per preparation.

**Body weight.** An animal was classed as dead from its trace if the trace goes blank after some day, if its last three or more values are identical, or if its last two values are identical and below 90%. Carried-forward values were not used in any mean.

**Biomarker screen (`analysis/biomarker_screen.csv`).** For each readout, the area under the ROC curve for separating animals in the protected arms (aged PSLN-344, young PSLN-212) from animals in the unprotected arms (aged empty-liposome control, aged PSLN-212).

**Sample sizes (P1).** Power of a two-sided Fisher exact test at α = 0.05, by exact enumeration.

**Multiplicity.** p-values are not adjusted across blocks and are descriptive. The pooled survival comparison is the only one I treat as confirmatory.

**Limits.** No animal can be linked between blocks, so every association between a biomarker and protection is at group level. I had the workbook and the annotation only: no instrument files and no protocol.

**Statements that are not from the file.** These are general knowledge and are marked as such where they appear: the HAI 1:40 benchmark; the formats of licensed seasonal vaccines; where a nasal spray deposits; variation in human STING; the H-2 restriction of the NP366–374 epitope; the olfactory route by which manganese can reach the brain; the facial-palsy precedent for a toxin-adjuvanted nasal vaccine; and, following from those, the manganese, olfactory and neurological endpoints chosen for Study 5.

**Checks.** `analysis/verify_ledger.py` re-reads the cell ranges quoted in the ledger directly from the workbook dump and recomputes {n_checks} values; {check_result}. The pooled survival comparison was repeated in R with the `survival` package (`analysis/crosscheck_survival.R`) and gave the same statistic (χ² = 72.5).

**Software.** Python 3.11 with pandas, SciPy 1.17, statsmodels 0.15 and lifelines 0.30. The scripts are in `analysis/`; `analysis/run_all.sh` regenerates every number, figure and this memo from the workbook.
'''
memo = body.rstrip() + '\n' + appendix
open(os.path.join(ROOT, 'PSLN-344_recommendation_memo.md'), 'w').write(memo)

# ---- consistency check: every [ID] cited in the body exists in the ledger
ids = set(L.ID)
prefixes = {i.split('-')[0] for i in ids} | ids
cited = set()
for m in re.finditer(r'\[([^\]]+)\]', body):
    inner = m.group(1)
    if inner.startswith(('Figure', 'http')) or '(' in inner: continue
    for tok in re.split(r'[;,]\s*', inner):
        tok = tok.strip()
        if re.fullmatch(r'[EIMDSQP]\d+[a-z]?(-s\d)?(–[EIMDSQP]?\d+[a-z]?)?', tok) or re.fullmatch(r'-s\d', tok):
            cited.add(tok)
missing = []
for c in sorted(cited):
    base = c.split('–')[0]
    if base.startswith('-s'): continue
    if base not in ids and not any(re.fullmatch(re.escape(base) + r'[a-z]', i) for i in ids):
        missing.append(c)
print('cited IDs:', len(cited), '| missing from ledger:', missing)
print('memo words:', len(memo.split()))

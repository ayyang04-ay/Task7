"""Sample size per arm for survival-proportion comparisons in the proposed confirmatory study (two-sided Fisher exact, alpha=0.05), by exact enumeration."""
import numpy as np
from scipy import stats
from functools import lru_cache
def power_fisher(p1, p2, n, alpha=0.05):
    pw = 0.0
    pm1 = stats.binom.pmf(np.arange(n+1), n, p1); pm2 = stats.binom.pmf(np.arange(n+1), n, p2)
    for a in range(n+1):
        if pm1[a] < 1e-10: continue
        for b in range(n+1):
            if pm2[b] < 1e-10: continue
            if stats.fisher_exact([[a, n-a],[b, n-b]])[1] < alpha: pw += pm1[a]*pm2[b]
    return pw
if __name__ == "__main__":
    for p1, p2 in [(0.81, 0.10), (0.81, 0.40), (0.81, 0.50), (0.95, 0.67), (0.81, 0.60)]:
        for target in (0.8, 0.9):
            n = 4
            while power_fisher(p1, p2, n) < target: n += 1
            print(f'{p1:.2f} vs {p2:.2f}: n per arm for {int(target*100)}% power = {n} (power {power_fisher(p1,p2,n):.2f})')
    print('power of the existing design (n=7/arm) to detect 81% vs 10%:', round(power_fisher(0.81,0.10,7),2), '; 81% vs 40%:', round(power_fisher(0.81,0.40,7),2), '; 98% vs 81%:', round(power_fisher(0.98,0.81,7),2))

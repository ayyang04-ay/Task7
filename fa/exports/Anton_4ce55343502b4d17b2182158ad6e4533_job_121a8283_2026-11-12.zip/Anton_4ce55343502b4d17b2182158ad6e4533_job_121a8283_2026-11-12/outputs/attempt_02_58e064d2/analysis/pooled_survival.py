"""
Pooled (stratified-by-experiment) survival analysis in aged animals.
Primary set: every aged (>=20 mo) experiment carrying Sham, PSLN-212 and PSLN-344 arms, as printed.
Sensitivity sets documented inline.
"""
import pandas as pd, numpy as np, warnings
from scipy import stats
from statsmodels.stats.contingency_tables import StratifiedTable
from statsmodels.stats.proportion import proportion_confint
from parse_blocks import OBS, SURV
warnings.filterwarnings('ignore')
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500)

def counts(blk, g, S=SURV):
    d = S[(S.block==blk)&(S.group==g)]
    return int((d.event==0).sum()), len(d)

def strat_logrank(blocks, gA, gB, S=SURV, mapA=None, mapB=None):
    OE=0.0; V=0.0
    for blk in blocks:
        a = S[(S.block==blk)&(S.group==(mapA or {}).get(blk, gA))].dropna(subset=['day'])
        b = S[(S.block==blk)&(S.group==(mapB or {}).get(blk, gB))].dropna(subset=['day'])
        d = pd.concat([a.assign(arm=1), b.assign(arm=0)])
        for t in sorted(d.loc[d.event==1,'day'].unique()):
            n = (d.day>=t).sum(); n1 = ((d.day>=t)&(d.arm==1)).sum()
            dth = ((d.day==t)&(d.event==1)).sum(); d1 = ((d.day==t)&(d.event==1)&(d.arm==1)).sum()
            if n>1:
                OE += d1 - dth*n1/n
                V += dth*(n1/n)*(1-n1/n)*(n-dth)/(n-1)
    chi2 = OE**2/V
    hr = np.exp(OE/V)   # Peto one-step hazard ratio (A vs B)
    se = 1/np.sqrt(V)
    return dict(chi2=chi2, p=stats.chi2.sf(chi2,1), peto_HR=hr, HR_lo=np.exp(OE/V-1.96*se), HR_hi=np.exp(OE/V+1.96*se))

def pooled(blocks, gA, gB, label, mapA=None, mapB=None, S=SURV):
    tabs=[]; a_al=a_n=b_al=b_n=0
    for blk in blocks:
        xa, na = counts(blk, (mapA or {}).get(blk, gA), S); xb, nb = counts(blk, (mapB or {}).get(blk, gB), S)
        tabs.append(np.array([[xa, na-xa],[xb, nb-xb]])); a_al+=xa; a_n+=na; b_al+=xb; b_n+=nb
    st = StratifiedTable(tabs)
    cmh = st.test_null_odds(correction=False); cmh_p = float(stats.chi2.sf(cmh.statistic, 1))
    ca = proportion_confint(a_al, a_n, method='beta'); cb = proportion_confint(b_al, b_n, method='beta')
    # Mantel-Haenszel risk difference (Greenland-Robins) 
    num = sum(t[0,0]*t[1].sum()/t.sum() - t[1,0]*t[0].sum()/t.sum() for t in tabs); den = sum(t[0].sum()*t[1].sum()/t.sum() for t in tabs)
    rd = num/den
    lr = strat_logrank(blocks, gA, gB, S, mapA, mapB)
    fe = stats.fisher_exact([[a_al, a_n-a_al],[b_al, b_n-b_al]])[1]
    print(f'{label}\n   {gA}: {a_al}/{a_n} = {100*a_al/a_n:.1f}% (95% CI {100*ca[0]:.0f}-{100*ca[1]:.0f})   {gB}: {b_al}/{b_n} = {100*b_al/b_n:.1f}% (95% CI {100*cb[0]:.0f}-{100*cb[1]:.0f})'
          f'\n   MH risk difference = {100*rd:.1f} pts ; CMH p = {cmh_p:.2e} ; unstratified Fisher p = {fe:.2e} ; stratified log-rank chi2 = {lr["chi2"]:.1f}, p = {lr["p"]:.2e} ; Peto HR(death) = {lr["peto_HR"]:.3f} ({lr["HR_lo"]:.3f}-{lr["HR_hi"]:.3f}) ; k = {len(blocks)} experiments')
    return dict(label=label, A=gA, B=gB, A_alive=a_al, A_n=a_n, B_alive=b_al, B_n=b_n, cmh_p=cmh_p, strat_logrank_p=lr['p'], peto_HR=lr['peto_HR'], HR_lo=lr['HR_lo'], HR_hi=lr['HR_hi'], MH_RD=rd, k=len(blocks))

if __name__ == '__main__':
    A10 = ['S03-I','S06-A','S06-B','S06-C','S06-D','S06-E (r34-68)','S06-F (r34-68)','S06-G','S15-L','S15-N']
    A9 = [b for b in A10 if b!='S06-D']
    res=[]
    print('=============== PRIMARY (as printed; S06-D excluded because it is a verbatim duplicate of S06-C) ===============')
    res.append(pooled(A9, 'PSLN-344', 'PSLN-212', 'Aged >=20 mo, 9 experiments: PSLN-344 vs PSLN-212'))
    res.append(pooled(A9, 'PSLN-344', 'Sham', 'Aged >=20 mo, 9 experiments: PSLN-344 vs Sham'))
    res.append(pooled(A9, 'PSLN-212', 'Sham', 'Aged >=20 mo, 9 experiments: PSLN-212 vs Sham'))
    res.append(pooled(A9, 'PSLN-344', 'PSLN-212(Y)', 'Aged PSLN-344 vs young PSLN-212 benchmark, 9 experiments'))
    res.append(pooled(A9, 'PSLN-212', 'PSLN-212(Y)', 'Aged PSLN-212 vs young PSLN-212 (the age defect), 9 experiments'))
    print('\n=============== SENSITIVITY 1: as printed INCLUDING S06-D (10 experiments) ===============')
    res.append(pooled(A10, 'PSLN-344', 'PSLN-212', 'Aged, 10 experiments incl. duplicate S06-D: PSLN-344 vs PSLN-212'))
    res.append(pooled(A10, 'PSLN-344', 'PSLN-212(Y)', 'Aged, 10 experiments incl. duplicate S06-D: PSLN-344 vs young'))
    print('\n=============== SENSITIVITY 2: add S03-J (wild-type H5N1, age not stated, n=10/arm; PSLN-344 row with blank day dropped from log-rank) ===============')
    res.append(pooled(A9+['S03-J'], 'PSLN-344', 'PSLN-212', 'Aged 9 + S03-J: PSLN-344 vs PSLN-212'))
    print('\n=============== SENSITIVITY 3: S03-I comparator re-labelled per S13-F (printed "CMP-204" column taken as PSLN-212) ===============')
    res.append(pooled(A9, 'PSLN-344', 'PSLN-212', 'Aged 9, S03-I PSLN-212 := printed CMP-204 column', mapB={'S03-I':'CMP-204'}))
    print('\n=============== BALB/c only, by challenge interval (as printed) ===============')
    res.append(pooled(['S06-B'], 'PSLN-344', 'PSLN-212', 'd3 challenge (S06-B only; S06-D excluded)'))
    res.append(pooled(['S03-I','S06-A','S06-C'], 'PSLN-344', 'PSLN-212', 'd14 challenge (S03-I, S06-A, S06-C)'))
    res.append(pooled(['S06-E (r34-68)','S06-F (r34-68)','S06-G'], 'PSLN-344', 'PSLN-212', 'd60 challenge (S06-E, S06-F, S06-G)'))
    res.append(pooled(['S06-E (r34-68)','S06-F (r34-68)','S06-G'], 'PSLN-344', 'PSLN-212(Y)', 'd60 challenge: aged PSLN-344 vs young PSLN-212'))
    res.append(pooled(['S06-E (r34-68)','S06-F (r34-68)','S06-G'], 'PSLN-344', 'Untreated', 'd60 challenge: aged PSLN-344 (challenged) vs Untreated (unchallenged, age-matched)'))
    print('\n=============== Other strains ===============')
    res.append(pooled(['S15-L','S15-N'], 'PSLN-344', 'PSLN-212', 'C57BL/6 + Swiss Webster (S15-L, S15-N)'))
    print('\n=============== Middle-aged / imprinting (14 mo at vaccination) ===============')
    IMP = ['S06-E (r71-105, imprint PR8)','S06-F (r71-105, imprint Perth)']
    res.append(pooled(IMP, 'Naïve+PSLN-344', 'Naïve+PSLN-212', 'Not imprinted: PSLN-344 vs PSLN-212'))
    res.append(pooled(IMP, 'Imprinting+PSLN-344', 'Imprinting+PSLN-212', 'Imprinted: PSLN-344 vs PSLN-212'))
    res.append(pooled(IMP, 'Imprinting+PSLN-344', 'Naïve+PSLN-344', 'PSLN-344: imprinted vs not imprinted'))
    res.append(pooled(IMP, 'Imprinting+PSLN-212', 'Naïve+PSLN-212', 'PSLN-212: imprinted vs not imprinted'))
    print('\n=============== Young animals ===============')
    Y = ['S09-B','S09-D','S09-F']
    for g in ['PSLN-344Y','PSLN-212Y','Sham']:
        a = sum(counts(b,g)[0] for b in Y); n = sum(counts(b,g)[1] for b in Y); print(f'   young {g}: {a}/{n}')
    pd.DataFrame(res).to_csv('pooled_survival.csv', index=False)

    # d14 vs d60 within PSLN-344 (matched vaccine/challenge pairs: Aichi->PR8 and bivalent->rgH5N1)
    print('\n=============== PSLN-344 aged: d14 vs d60, matched models ===============')
    a14 = counts('S06-A','PSLN-344'); c14 = counts('S06-C','PSLN-344'); e60 = counts('S06-E (r34-68)','PSLN-344'); f60 = counts('S06-F (r34-68)','PSLN-344')
    t = [[a14[0]+c14[0], a14[1]+c14[1]-a14[0]-c14[0]],[e60[0]+f60[0], e60[1]+f60[1]-e60[0]-f60[0]]]
    print('   d14 (S06-A + S06-C):', t[0], ' d60 (S06-E + S06-F):', t[1], ' Fisher p =', stats.fisher_exact(t)[1])
    g60 = counts('S06-G','PSLN-344')
    t2 = [[counts('S03-I','PSLN-344')[0]+a14[0]+c14[0], 21-(counts('S03-I','PSLN-344')[0]+a14[0]+c14[0])],[e60[0]+f60[0]+g60[0], 21-(e60[0]+f60[0]+g60[0])]]
    print('   all d14 (S03-I,S06-A,S06-C):', t2[0], ' all d60 (S06-E,F,G):', t2[1], ' Fisher p =', stats.fisher_exact(t2)[1])
    u = sum(counts(b,'Untreated')[0] for b in ['S06-E (r34-68)','S06-F (r34-68)','S06-G'])
    print(f'   Untreated (unchallenged, 20 mo + 60 d) alive at 14 d: {u}/21 ; 95% CI', [round(100*x) for x in proportion_confint(u,21,method="beta")])
    print('   PSLN-344 d60 alive 14/21 ; 95% CI', [round(100*x) for x in proportion_confint(14,21,method="beta")])

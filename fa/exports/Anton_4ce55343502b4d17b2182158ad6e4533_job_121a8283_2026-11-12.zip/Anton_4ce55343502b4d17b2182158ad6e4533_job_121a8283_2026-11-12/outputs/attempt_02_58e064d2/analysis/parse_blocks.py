"""
Parse adjuvant_program_dataset.xlsx into tidy tables, keeping the cell address of every value.

Inputs : cells.json  (verbatim cell dump: {sheet: {coordinate: value}}) produced by cells.py
Outputs: tidy 'obs' table (one row per numeric observation) and 'surv' table (one row per animal in
         time-to-event blocks). Group labels are kept EXACTLY AS PRINTED in the workbook.
"""
import json, re, os
import pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__))
from string import ascii_uppercase

CELLS = json.load(open(os.path.join(HERE, 'cells.json')))

def col2num(c):
    n = 0
    for ch in c:
        n = n*26 + (ord(ch)-64)
    return n
def num2col(n):
    s = ''
    while n:
        n, r = divmod(n-1, 26)
        s = chr(65+r) + s
    return s
def colrange(a, b):
    return [num2col(i) for i in range(col2num(a), col2num(b)+1)]
def cell(sheet, addr):
    return CELLS[sheet].get(addr)

obs = []    # dict(sheet, block, group, row_label, rep, value, cell)
surv = []   # dict(sheet, block, group, day, event, cell_day, cell_status)
meta = {}   # block -> dict

def add_colwise(sheet, block, header_row, cols, rows, row_label=None, groups=None):
    """groups are in columns (one column per group), replicates down rows."""
    for i, c in enumerate(cols):
        g = groups[i] if groups else cell(sheet, f'{c}{header_row}')
        rep = 0
        for r in rows:
            v = cell(sheet, f'{c}{r}')
            if v is None: continue
            rep += 1
            obs.append(dict(sheet=sheet, block=block, group=str(g).strip(), row_label=row_label, rep=rep,
                            value=float(v), cell=f'{sheet}!{c}{r}'))

def add_rowwise(sheet, block, label_col, rows, val_cols, group_from_label=True, group=None, row_label=None):
    """each row is a group (label in label_col), replicates across val_cols."""
    for r in rows:
        lab = cell(sheet, f'{label_col}{r}')
        rep = 0
        for c in val_cols:
            v = cell(sheet, f'{c}{r}')
            if v is None: continue
            rep += 1
            obs.append(dict(sheet=sheet, block=block, group=str(lab).strip() if group_from_label else group,
                            row_label=row_label if group_from_label else str(lab).strip(), rep=rep,
                            value=float(v), cell=f'{sheet}!{c}{r}'))

def add_grid(sheet, block, header_row, group_starts, width, rows, label_col, groups=None, keep_pos=True):
    """time (or analyte, dose) in rows (label in label_col); each group occupies `width` columns from its start col.
    rep = positional index of the column within the group (animal identity is positional)."""
    for gi, start in enumerate(group_starts):
        g = groups[gi] if groups else cell(sheet, f'{start}{header_row}')
        cols = [num2col(col2num(start)+k) for k in range(width)]
        for r in rows:
            lab = cell(sheet, f'{label_col}{r}')
            for k, c in enumerate(cols):
                v = cell(sheet, f'{c}{r}')
                if v is None: continue
                obs.append(dict(sheet=sheet, block=block, group=str(g).strip(), row_label=(str(lab).strip() if lab is not None else None), rep=k+1,
                                value=float(v), cell=f'{sheet}!{c}{r}'))

def add_surv(sheet, block, day_col, status_cols, header_row, rows):
    for r in rows:
        d = cell(sheet, f'{day_col}{r}')
        for c in status_cols:
            s = cell(sheet, f'{c}{r}')
            if s is None: continue
            g = cell(sheet, f'{c}{header_row}')
            surv.append(dict(sheet=sheet, block=block, group=str(g).strip(), day=(float(d) if d is not None else None),
                             event=int(s), cell_day=f'{sheet}!{day_col}{r}', cell_status=f'{sheet}!{c}{r}'))

R = lambda a, b: list(range(a, b+1))

# ---------------- S01 ----------------
add_rowwise('S01', 'S01-A 16h', 'A', R(3,10), colrange('B','F'))
add_rowwise('S01', 'S01-A 72h', 'G', R(3,10), colrange('H','L'))
add_rowwise('S01', 'S01-B', 'A', R(14,17), colrange('B','F'))
add_rowwise('S01', 'S01-C', 'A', R(20,21), colrange('B','E'))
add_grid('S01', 'S01-D', 23, ['B','G','L','Q'], 5, R(24,28), 'A')
add_grid('S01', 'S01-E', 29, ['B','G','L','Q','V'], 5, R(30,34), 'A')
add_grid('S01', 'S01-F', 35, ['B','G','L','Q','V'], 5, [36], 'A')
add_grid('S01', 'S01-G', 37, ['B','G','L','Q','V'], 5, [38], 'A')
# ---------------- S02 ----------------
add_colwise('S02', 'S02-A', 2, colrange('A','D'), R(3,7))
add_colwise('S02', 'S02-B', 2, colrange('F','I'), R(3,7))
add_colwise('S02', 'S02-C', 2, colrange('K','O'), R(3,7))
add_colwise('S02', 'S02-D CD40', 9, colrange('A','D'), R(10,14))
add_colwise('S02', 'S02-D CD86', 9, colrange('F','I'), R(10,14))
add_colwise('S02', 'S02-E', 9, colrange('K','O'), R(10,14))
add_grid('S02', 'S02-F', 16, ['B','G','L'], 5, R(17,19), 'A')
add_colwise('S02', 'S02-G', 21, colrange('B','D'), R(22,26))
add_colwise('S02', 'S02-H', 29, colrange('B','F'), R(30,34))
add_colwise('S02', 'S02-I', 29, colrange('H','I'), R(30,34))
# ---------------- S03 ----------------
add_colwise('S03', 'S03-A', 2, colrange('A','E'), R(3,7))
add_colwise('S03', 'S03-B', 2, colrange('G','I'), R(3,7))
add_colwise('S03', 'S03-C', 2, colrange('K','O'), R(3,7))
add_colwise('S03', 'S03-D', 2, colrange('Q','U'), R(3,7))
add_colwise('S03', 'S03-E', 9, colrange('A','E'), R(10,14))
add_colwise('S03', 'S03-F', 9, colrange('G','I'), R(10,14))
add_colwise('S03', 'S03-G', 9, colrange('K','O'), R(10,14))
add_colwise('S03', 'S03-H', 9, colrange('Q','U'), R(10,14))
add_surv('S03', 'S03-I', 'A', colrange('B','F'), 16, R(17,51))
add_surv('S03', 'S03-J', 'G', colrange('H','J'), 16, R(17,46))
add_colwise('S03', 'S03-K', 16, colrange('L','O'), R(17,21))
add_rowwise('S03', 'S03-L Aicda', 'K', R(26,28), colrange('L','N'))
add_rowwise('S03', 'S03-L E47', 'K', R(26,28), colrange('O','Q'))
# ---------------- S04 ----------------
add_rowwise('S04', 'S04-A ICOS-low', 'A', R(2,5), colrange('B','F'))
add_rowwise('S04', 'S04-A ICOS-high', 'A', R(2,5), colrange('G','K'))
add_colwise('S04', 'S04-B Foxp3+', 7, colrange('A','D'), R(8,12))
add_colwise('S04', 'S04-B Tfh:Tfr', 14, colrange('A','D'), R(15,19))
add_colwise('S04', 'S04-C', 21, colrange('A','D'), R(22,26))
add_colwise('S04', 'S04-D', 28, colrange('A','D'), R(29,31))
# ---------------- S05 ----------------
add_grid('S05', 'S05-A', 2, ['B','E','H'], 2, R(3,5), 'A')
add_grid('S05', 'S05-B', 7, ['B','E','H'], 2, R(8,10), 'A')
add_colwise('S05', 'S05-C', 12, colrange('A','D'), R(13,15))
add_colwise('S05', 'S05-D', 18, colrange('A','D'), R(19,23))
add_colwise('S05', 'S05-E', 25, colrange('A','D'), R(26,30))
add_colwise('S05', 'S05-F', 32, colrange('A','D'), R(33,37))
add_colwise('S05', 'S05-G', 39, colrange('A','D'), R(40,44))
add_colwise('S05', 'S05-H', 46, colrange('A','D'), R(47,51))
add_colwise('S05', 'S05-I', 53, colrange('A','D'), R(54,58))
# ---------------- S06 (time to event) ----------------
add_surv('S06', 'S06-A', 'A', colrange('B','E'), 2, R(3,30))
add_surv('S06', 'S06-B', 'G', colrange('H','K'), 2, R(3,30))
add_surv('S06', 'S06-C', 'M', colrange('N','Q'), 2, R(3,30))
add_surv('S06', 'S06-D', 'A', colrange('B','E'), 33, R(34,68))
add_surv('S06', 'S06-E (r34-68)', 'G', colrange('H','L'), 33, R(34,68))
add_surv('S06', 'S06-F (r34-68)', 'M', colrange('N','R'), 33, R(34,68))
add_surv('S06', 'S06-G', 'A', colrange('B','F'), 70, R(71,105))
add_surv('S06', 'S06-E (r71-105, imprint PR8)', 'G', colrange('H','K'), 70, R(71,105))
add_surv('S06', 'S06-F (r71-105, imprint Perth)', 'M', colrange('N','Q'), 70, R(71,105))
# ---------------- S07 ----------------
add_grid('S07', 'S07-A', 2, ['B','E'], 3, R(3,7), 'A')
add_colwise('S07', 'S07-B monocytes', 9, colrange('B','C'), R(10,14))
add_colwise('S07', 'S07-B Ly6C+ Mphi', 9, colrange('E','F'), R(10,14))
add_colwise('S07', 'S07-C', 15, colrange('B','C'), R(16,20), groups=['col B: '+str(cell('S07','B15')), 'col C: '+str(cell('S07','C15'))])
# ---------------- S08 ----------------
add_grid('S08', 'S08-A', 2, ['B','E','H','K'], 3, R(3,7), 'A')
add_grid('S08', 'S08-B', 10, ['A','D','G','J','M'], 3, [11], 'A')
add_colwise('S08', 'S08-C', 13, colrange('A','D'), R(14,18))
add_grid('S08', 'S08-D', 20, ['B','G','L','Q','V','AA'], 5, R(21,26), 'A')
# ---------------- S09 ----------------
add_grid('S09', 'S09-A panel1 (cols A-V)', 2, ['B','E','H','K','N','Q','T'], 3, R(3,9), 'A')
add_grid('S09', 'S09-A panel2 (cols X-AS)', 2, ['Y','AB','AE','AH','AK','AN','AQ'], 3, R(3,9), 'X')
add_surv('S09', 'S09-B', 'A', colrange('B','D'), 11, R(12,35))
add_grid('S09', 'S09-C', 11, ['G','O','W'], 8, R(12,19), 'F')
add_surv('S09', 'S09-D', 'A', colrange('B','D'), 38, R(39,62))
add_grid('S09', 'S09-E', 38, ['G','O','W'], 8, R(39,46), 'F')
add_surv('S09', 'S09-F', 'A', colrange('B','D'), 65, R(66,88))
add_grid('S09', 'S09-G', 65, ['G','O','W'], 8, R(66,73), 'F')
# ---------------- S10 ----------------
add_colwise('S10', 'S10-A Ifnb1', 2, colrange('A','D'), R(3,7))
add_colwise('S10', 'S10-A Tnf', 2, colrange('F','I'), R(3,7))
add_colwise('S10', 'S10-A Isg15', 2, colrange('K','N'), R(3,7))
# ---------------- S11 ----------------
add_grid('S11', 'S11-A', 2, ['B','G','L','Q'], 5, R(3,7), 'A')
add_grid('S11', 'S11-B', 9, ['B','G','L','Q'], 5, R(10,14), 'A')
add_colwise('S11', 'S11-C', 16, colrange('A','B'), R(17,21))
add_grid('S11', 'S11-D', 23, ['B','G','L','Q'], 5, R(24,28), 'A')
add_colwise('S11', 'S11-E', 30, colrange('A','D'), R(31,35))
# ---------------- S12 ----------------
add_colwise('S12', 'S12-A', 2, colrange('A','B'), R(3,5))
# ---------------- S13 ----------------
add_colwise('S13', 'S13-A', 2, colrange('A','C'), R(3,7))
add_colwise('S13', 'S13-B', 2, colrange('E','G'), R(3,7))
add_colwise('S13', 'S13-C', 2, colrange('I','K'), R(3,7))
add_colwise('S13', 'S13-D', 2, colrange('M','O'), R(3,7))
add_surv('S13', 'S13-E', 'R', colrange('S','V'), 2, R(3,30))
add_grid('S13', 'S13-F', 32, ['B','I','P','W','AD'], 7, R(33,40), 'A')
add_grid('S13', 'S13-G', 42, ['B','L','V'], 10, R(43,50), 'A')
add_colwise('S13', 'S13-H', 52, colrange('A','D'), R(53,57))
add_colwise('S13', 'S13-I', 52, colrange('F','J'), R(53,57))
add_colwise('S13', 'S13-J', 52, colrange('L','P'), R(53,57))
# ---------------- S14 ----------------
add_colwise('S14', 'S14-A H1N1', 2, colrange('A','D'), R(3,7))
add_colwise('S14', 'S14-A H3N2', 2, colrange('F','I'), R(3,7))
# ---------------- S15 ----------------
for blk, hr, r0 in [('S15-A',2,3),('S15-B',12,13),('S15-C',22,23),('S15-D',32,33)]:
    add_grid('S15', blk, hr, ['B','I','P','W'], 7, R(r0, r0+7), 'A')
for blk, hr, r0 in [('S15-E',42,43),('S15-F',52,53),('S15-G',62,63)]:
    add_grid('S15', blk, hr, ['B','I','P','W','AD'], 7, R(r0, r0+7), 'A')
add_surv('S15', 'S15-H', 'A', colrange('B','D'), 72, R(73,93))
add_grid('S15', 'S15-I', 71, ['I','P','W'], 7, R(72,79), 'H')
add_grid('S15', 'S15-J', 82, ['I','P','W','AD'], 7, R(83,90), 'H')
add_grid('S15', 'S15-K', 92, ['I','P','W','AD'], 7, R(93,100), 'H')
add_surv('S15', 'S15-L', 'A', colrange('B','E'), 102, R(103,130))
add_grid('S15', 'S15-M', 102, ['I','P','W','AD'], 7, R(103,110), 'H')
add_surv('S15', 'S15-N', 'A', colrange('B','E'), 133, R(134,161))
add_grid('S15', 'S15-O', 133, ['I','P','W','AD'], 7, R(134,141), 'H')

OBS = pd.DataFrame(obs)
SURV = pd.DataFrame(surv)

def numeric_cells_used():
    used = set(OBS['cell'])
    used |= set(SURV['cell_status'])
    used |= set(SURV['cell_day'])
    return used

if __name__ == '__main__':
    OBS.to_csv(os.path.join(HERE, 'tidy_observations.csv'), index=False)
    SURV.to_csv(os.path.join(HERE, 'tidy_time_to_event.csv'), index=False)
    print(OBS.shape, SURV.shape)
    # coverage check: every numeric cell in workbook must be accounted for
    used = numeric_cells_used()
    unused = []
    for sh, d in CELLS.items():
        for addr, v in d.items():
            if isinstance(v, (int, float)) and f'{sh}!{addr}' not in used:
                unused.append((sh, addr, v))
    print('numeric cells not captured by any block:', len(unused))
    import collections
    by = collections.defaultdict(list)
    for sh, addr, v in unused: by[sh].append((addr, v))
    for sh in by: print(sh, by[sh][:80])

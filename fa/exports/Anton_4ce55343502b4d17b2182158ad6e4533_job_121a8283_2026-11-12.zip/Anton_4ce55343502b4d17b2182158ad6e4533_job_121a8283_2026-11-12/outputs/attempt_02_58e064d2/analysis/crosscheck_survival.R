# Independent cross-check of the pooled survival comparison in R (survival package).
suppressMessages(library(survival))
d <- read.csv("tidy_time_to_event.csv", check.names = FALSE)
A9 <- c("S03-I","S06-A","S06-B","S06-C","S06-E (r34-68)","S06-F (r34-68)","S06-G","S15-L","S15-N")
x <- subset(d, block %in% A9 & group %in% c("PSLN-344","PSLN-212"))
x$arm <- as.integer(x$group == "PSLN-344")
sd <- survdiff(Surv(day, event) ~ arm + strata(block), data = x)
cat(sprintf("stratified log-rank chisq = %.1f, p = %.2e\n", sd$chisq, 1 - pchisq(sd$chisq, 1)))
cat(sprintf("p (upper tail) = %.3g\n", pchisq(sd$chisq, 1, lower.tail = FALSE)))
cx <- coxph(Surv(day, event) ~ arm + strata(block), data = x)
s <- summary(cx)
cat(sprintf("stratified Cox HR = %.3f (%.3f-%.3f)\n", s$conf.int[1], s$conf.int[3], s$conf.int[4]))
tab <- table(x$group, x$event); print(tab)
# young benchmark
y <- subset(d, block %in% A9 & group %in% c("PSLN-344","PSLN-212(Y)")); y$arm <- as.integer(y$group == "PSLN-344")
sy <- survdiff(Surv(day, event) ~ arm + strata(block), data = y)
cat(sprintf("PSLN-344 vs young: chisq = %.1f, p = %.4f\n", sy$chisq, pchisq(sy$chisq, 1, lower.tail = FALSE)))
# Mantel-Haenszel
arr <- array(0, dim = c(2, 2, length(A9)))
for (k in seq_along(A9)) { b <- subset(x, block == A9[k]); arr[,,k] <- table(factor(b$arm, levels = c(1,0)), factor(b$event, levels = c(0,1))) }
mh <- mantelhaen.test(arr, correct = FALSE); cat(sprintf("CMH chisq = %.1f, p = %.2e\n", mh$statistic, mh$p.value))

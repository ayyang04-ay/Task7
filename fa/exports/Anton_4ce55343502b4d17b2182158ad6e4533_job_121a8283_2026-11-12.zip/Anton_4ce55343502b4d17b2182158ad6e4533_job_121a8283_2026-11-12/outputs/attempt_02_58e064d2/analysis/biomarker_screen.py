"""
Biomarker screen (group-level only -- no animal in the workbook has both a biomarker value and a challenge outcome).
For every single-timepoint block with Sham/PSLN-212/PSLN-344/PSLN-212(Y):
  - 'protected' class  = animals in PSLN-344 (aged) and PSLN-212(Y)   [pooled survival 81% and 98%]
  - 'unprotected' class= animals in Sham and PSLN-212 (aged)           [pooled survival 0% and 9.5%]
  - AUC (Mann-Whitney) for separating the two classes; separation margin = min(protected) / max(unprotected) (or inverse for inverse markers)
  - % of young restored by PSLN-344 and left by PSLN-212
"""
import numpy as np, pandas as pd, warnings
from scipy import stats
from parse_blocks import OBS
warnings.filterwarnings('ignore')
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500)
DESC = {
 'S01-A 16h':'Lung Ifnb1 mRNA 16 h (adjuvant alone)', 'S01-A 72h':'Lung Ifnb1 mRNA 72 h', 'S01-F':'Lung cDC1 % 72 h', 'S01-G':'Lung cDC2 % 72 h (inverse)',
 'S02-A':'Lung CCR7+ migratory CD11b+ DC 72 h','S02-B':'MLN CD11b+CD103- DC 72 h','S02-D CD40':'CD40+ of MLN CD11b+ DC d3','S02-D CD86':'CD86+ of MLN CD11b+ DC d3',
 'S03-A':'Serum IgG CA09 d14','S03-C':'HAI CA09 d14','S03-D':'Neutralising Ab CA09 d14','S03-E':'Serum IgG Aichi d14','S03-G':'HAI Aichi d14','S03-H':'Neutralising Ab Aichi d14',
 'S03-K':'MLN GC B cells d7','S04-A ICOS-low':'Tfh ICOS-low d7','S04-A ICOS-high':'Tfh ICOS-high d7','S04-B Foxp3+':'Tfr (Foxp3+ of CXCR5+) d7 (inverse)','S04-B Tfh:Tfr':'Tfh:Tfr d7 (derived)',
 'S04-C':'Tfr d30 (inverse)','S04-D':'Lung Treg d7 (inverse), n=3','S05-D':'Lung Ki-67+ CD8 d3','S05-E':'Lung GZMB+ CD8 d3','S05-F':'MLN IFN-g+ CD8, rgH5N1 restim d14',
 'S05-G':'MLN IFN-g+ CD8, rgH5N1 restim d60','S05-H':'MLN GZMB+ CD8 d60','S05-I':'Lung CD8 TRM d25','S11-E':'Lung CD206+ macrophages (inverse)','S13-H':'IgG+ of MLN B220+',
 'S13-I':'Serum IgG CA09 d28 post-boost','S13-J':'Serum IgG Aichi d28 post-boost','S14-A H1N1':'MLN IFN-g+ CD8, CA09 restim','S14-A H3N2':'MLN IFN-g+ CD8, Aichi restim'}
rows=[]
for b, desc in DESC.items():
    x = OBS[OBS.block==b]
    g = {k: x[x.group==k].value.values for k in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']}
    if any(len(v)==0 for v in g.values()): continue
    prot = np.concatenate([g['PSLN-344'], g['PSLN-212(Y)']]); unp = np.concatenate([g['Sham'], g['PSLN-212']])
    inverse = 'inverse' in desc
    u = stats.mannwhitneyu(prot, unp, alternative='two-sided')
    auc = u.statistic/(len(prot)*len(unp)); auc = 1-auc if inverse else auc
    margin = (unp.min()/prot.max()) if inverse else (prot.min()/max(unp.max(),1e-9))
    # aged-only separation: PSLN-344 vs PSLN-212
    u2 = stats.mannwhitneyu(g['PSLN-344'], g['PSLN-212']); auc2 = u2.statistic/(len(g['PSLN-344'])*len(g['PSLN-212'])); auc2 = 1-auc2 if inverse else auc2
    margin2 = (g['PSLN-212'].min()/g['PSLN-344'].max()) if inverse else (g['PSLN-344'].min()/max(g['PSLN-212'].max(),1e-9))
    rows.append(dict(block=b, readout=desc, n_per_group=len(g['PSLN-344']), Sham=g['Sham'].mean(), P212=g['PSLN-212'].mean(), P344=g['PSLN-344'].mean(), Young=g['PSLN-212(Y)'].mean(),
                     pctY_212=100*g['PSLN-212'].mean()/g['PSLN-212(Y)'].mean(), pctY_344=100*g['PSLN-344'].mean()/g['PSLN-212(Y)'].mean(),
                     AUC_prot_vs_unprot=auc, margin_prot_vs_unprot=margin, AUC_344_vs_212=auc2, margin_344_vs_212=margin2))
T = pd.DataFrame(rows)
T.to_csv('biomarker_screen.csv', index=False)
print(T.to_string(float_format=lambda x: f'{x:.3g}'))

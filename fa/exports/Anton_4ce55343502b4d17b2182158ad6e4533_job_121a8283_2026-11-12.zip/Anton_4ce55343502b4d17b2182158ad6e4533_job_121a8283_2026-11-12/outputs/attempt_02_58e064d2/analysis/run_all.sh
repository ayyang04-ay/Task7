#!/usr/bin/env bash
# Regenerates every table, figure and the memo from the workbook.
# cells.py needs openpyxl (env "chem"); everything else runs in env "core"; pandoc lives in env "renv".
set -euo pipefail
cd "$(dirname "$0")"
micromamba run -n chem python cells.py > log_cells.txt
PY="micromamba run -n core python"
$PY parse_blocks.py            > log_parse.txt
$PY desc.py                    > log_descriptives.txt
$PY survival_analysis.py       > log_survival.txt
$PY pooled_survival.py         > log_pooled_survival.txt
$PY bw_vs_surv.py              > log_bw_vs_survival.txt
$PY bw_morbidity.py            > log_bw_morbidity.txt
$PY immuno_stats.py            > log_immuno.txt
$PY timecourse_stats.py        > log_timecourse.txt
$PY mech_stats.py              > log_mechanism.txt
$PY safety_stats.py            > log_safety.txt
$PY dose_response.py           > log_dose_response.txt
$PY biomarker_screen.py        > log_biomarker_screen.txt
$PY xchecks.py                 > log_crosschecks.txt
$PY dup_check.py               > log_duplicates.txt
$PY dup_traj.py                > log_duplicate_trajectories.txt
$PY young_bw.py                > log_young_bodyweight.txt
$PY young_mn.py                > log_young_mn_effect.txt
$PY power_calc.py              > log_power.txt
$PY age_by_mn.py               > log_age_by_mn.txt
$PY ledger.py                  > log_ledger.txt
$PY verify_ledger.py           > log_verify_ledger.txt
micromamba run -n renv Rscript crosscheck_survival.R > log_crosscheck_survival_R.txt 2>&1
$PY figures.py                 > /dev/null
$PY build_memo.py              > log_build_memo.txt
micromamba run -n chem python build_xlsx.py > log_build_xlsx.txt
cd ..
micromamba run -n renv pandoc PSLN-344_recommendation_memo.md -f markdown+pipe_tables+implicit_figures \
    -o PSLN-344_recommendation_memo.docx --resource-path=. --reference-doc=analysis/docx_reference.docx
micromamba run -n renv pandoc PSLN-344_recommendation_memo.md -f markdown+pipe_tables+implicit_figures -t html5 -s --embed-resources \
    --metadata pagetitle="PSLN-344: portfolio recommendation" -H analysis/html_header.html \
    -o PSLN-344_recommendation_memo.html --resource-path=.
echo "done"

"""Cross-check of each body-weight block against its paired time-to-event table.
A death is inferred from a weight trace that goes blank, or whose terminal value is carried forward unchanged."""
import pandas as pd, numpy as np, itertools
from parse_blocks import OBS, SURV, CELLS
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)

PAIRS = [ # (body-weight block, survival block)
 ('S13-F','S03-I'), ('S13-G','S03-J'),
 ('S15-A','S06-A'), ('S15-B','S06-B'), ('S15-C','S06-C'), ('S15-D','S06-D'),
 ('S15-E','S06-E (r34-68)'), ('S15-F','S06-F (r34-68)'), ('S15-G','S06-G'),
 ('S15-I','S15-H'), ('S15-J','S06-E (r71-105, imprint PR8)'), ('S15-K','S06-F (r71-105, imprint Perth)'),
 ('S15-M','S15-L'), ('S15-O','S15-N'),
 ('S09-C','S09-B'), ('S09-E','S09-D'), ('S09-G','S09-F'),
]
def bw_infer(block):
    d = OBS[OBS.block==block].copy()
    d['day'] = d['row_label'].astype(float)
    days = sorted(d['day'].unique())
    out = []
    for (g, rep), x in d.groupby(['group','rep'], sort=False):
        s = x.set_index('day')['value'].reindex(days)
        obs_days = [t for t in days if not np.isnan(s[t])]
        last = obs_days[-1]
        status = 'alive'; tdeath = None; nadir = np.nanmin(s.values)
        if last < days[-1]:
            status = 'blank-after'; tdeath = last     # died after `last`
        else:
            # frozen tail: identical values at end
            v = s.values
            k = len(v)-1
            while k>0 and v[k-1]==v[k]: k -= 1
            run = len(v)-k
            if run >= 3 and v[-1] != 100:
                status = 'frozen(LOCF)'; tdeath = days[k]
            elif run == 2 and v[-1] < 90:
                status = 'frozen2?'; tdeath = days[k]
        out.append(dict(block=block, group=g, rep=rep, status=status, last_real_day=tdeath, nadir=nadir, final=s.values[-1] if not np.isnan(s.values[-1]) else np.nan,
                        first_cell=x['cell'].iloc[0]))
    return pd.DataFrame(out)

if __name__ == '__main__':
    rows=[]
    ALL=[]
    for bw, sv in PAIRS:
        B = bw_infer(bw); ALL.append(B)
        S = SURV[SURV.block==sv]
        print(f'\n##### {bw}  (body weight)  vs  {sv}  (time to event)')
        print('  BW groups  :', list(B.group.unique()))
        print('  Surv groups:', list(S.group.unique()))
        for g in B.group.unique():
            b = B[B.group==g]
            ndead = int((b.status!='alive').sum()); n=len(b)
            lastdays = sorted([int(t) for t in b.loc[b.status!='alive','last_real_day']])
            kinds = b.status.value_counts().to_dict()
            s = S[S.group==g]
            if len(s):
                sd = sorted([int(t) for t in s.loc[s.event==1,'day']]); ns=len(s); nd=int(s.event.sum())
                flag = '' if nd==ndead else '   <<< MISMATCH in number of deaths'
                print(f'  {g:22s} BW: n={n} inferred dead={ndead} (last weighed/frozen-from day {lastdays}) {kinds} | SURV: n={ns} dead={nd} days={sd}{flag}')
            else:
                print(f'  {g:22s} BW: n={n} inferred dead={ndead} (last weighed/frozen-from day {lastdays}) {kinds} | SURV: -- no group of this name --')
            rows.append(dict(bw_block=bw, surv_block=sv, group=g, bw_n=n, bw_dead=ndead, bw_lastdays=lastdays, surv_n=len(s), surv_dead=int(s.event.sum()) if len(s) else None, surv_days=sorted([int(t) for t in s.loc[s.event==1,'day']]) if len(s) else None))
        for g in S.group.unique():
            if g not in set(B.group):
                s = S[S.group==g]; print(f'  {g:22s} BW: -- no group of this name -- | SURV: n={len(s)} dead={int(s.event.sum())} days={sorted([int(t) for t in s.loc[s.event==1,"day"]])}')
    pd.DataFrame(rows).to_csv('bw_vs_survival_crosscheck.csv', index=False)
    pd.concat(ALL).to_csv('bw_animal_status.csv', index=False)

"""
One-way ANOVA + Tukey HSD (the stated method) for every single-timepoint block that contains the core groups.
Titres (reciprocal dilution) are analysed on the log2 scale and summarised as geometric means (GMT);
HAI values printed as 0 (below the 1:10 lowest dilution, per annotation) are set to 5 (= LOD/2) for GMT/log analysis.
Everything else is analysed on the printed (linear) scale and summarised as arithmetic mean +/- SD.
"""
import pandas as pd, numpy as np, itertools, warnings
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from parse_blocks import OBS, SURV
warnings.filterwarnings('ignore')
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500); pd.set_option('display.max_columns', 50)

TITRE_BLOCKS = ['S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J']
def get(block, row=None):
    d = OBS[OBS.block==block]
    if row is not None: d = d[d.row_label==row]
    return d

def cellrange(cells):
    cells=list(cells); return f"{cells[0]}:{cells[-1].split('!')[1]}"

def tukey_block(block, row=None, log=False, lod_half=None):
    d = get(block, row).copy()
    v = d['value'].values.astype(float)
    if lod_half is not None: v = np.where(v<=0, lod_half, v)
    d['y'] = np.log2(v) if log else v
    groups = list(d.group.unique())
    res = {}
    if len(groups) >= 3:
        tk = pairwise_tukeyhsd(d['y'], d['group'])
        for (g1, g2), p, md in zip(itertools.combinations(tk.groupsunique, 2), tk.pvalues, tk.meandiffs):
            res[frozenset([g1,g2])] = p
        f = stats.f_oneway(*[d.loc[d.group==g,'y'] for g in groups])
        anova_p = f.pvalue
    else:
        t = stats.ttest_ind(d.loc[d.group==groups[0],'y'], d.loc[d.group==groups[1],'y'])
        res[frozenset(groups)] = t.pvalue; anova_p = t.pvalue
    summ = {}
    for g in groups:
        x = d.loc[d.group==g]
        vv = np.where(x['value'].values<=0, lod_half, x['value'].values) if lod_half is not None else x['value'].values
        summ[g] = dict(n=len(x), mean=float(np.mean(x['value'])), sd=float(np.std(x['value'], ddof=1)),
                       gmean=float(np.exp(np.mean(np.log(vv)))) if np.all(vv>0) else np.nan, cells=cellrange(x['cell']))
    return summ, res, anova_p

if __name__ == '__main__':
    rows=[]
    core = ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']
    blocks = [b for b in OBS.block.unique()]
    for b in blocks:
        d = get(b)
        rl = d.row_label.dropna().unique()
        if len(rl)>0: continue   # time-course/grid blocks handled separately
        gs = set(d.group.unique())
        if not {'PSLN-212','PSLN-344'} <= gs: continue
        log = b in TITRE_BLOCKS
        summ, res, ap = tukey_block(b, log=log, lod_half=5 if b in ('S03-C','S03-G') else None)
        key = 'gmean' if log else 'mean'
        r = dict(block=b, scale='log2 (GMT)' if log else 'linear (mean)', anova_p=ap)
        for g in ['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)','PSLN-344(Y)']:
            if g in summ:
                r[g] = summ[g][key]; r[g+'_sd'] = summ[g]['sd']; r[g+'_n'] = summ[g]['n']; r[g+'_cells'] = summ[g]['cells']
        def p(a,b_): return res.get(frozenset([a,b_]), np.nan)
        r['p_344_vs_212'] = p('PSLN-344','PSLN-212'); r['p_344_vs_Sham'] = p('PSLN-344','Sham'); r['p_344_vs_Y'] = p('PSLN-344','PSLN-212(Y)'); r['p_212_vs_Y'] = p('PSLN-212','PSLN-212(Y)'); r['p_212_vs_Sham']=p('PSLN-212','Sham')
        r['ratio_344_over_212'] = r['PSLN-344']/r['PSLN-212']
        if 'PSLN-212(Y)' in summ:
            r['pct_of_young_344'] = 100*r['PSLN-344']/r['PSLN-212(Y)']; r['pct_of_young_212'] = 100*r['PSLN-212']/r['PSLN-212(Y)']
        rows.append(r)
    T = pd.DataFrame(rows)
    T.to_csv('immuno_tukey_summary.csv', index=False)
    cols = ['block','scale','Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)','PSLN-344(Y)','ratio_344_over_212','pct_of_young_212','pct_of_young_344','p_344_vs_212','p_344_vs_Y','p_212_vs_Y','p_344_vs_Sham','p_212_vs_Sham']
    print(T[cols].to_string(float_format=lambda x: f'{x:.3g}'))

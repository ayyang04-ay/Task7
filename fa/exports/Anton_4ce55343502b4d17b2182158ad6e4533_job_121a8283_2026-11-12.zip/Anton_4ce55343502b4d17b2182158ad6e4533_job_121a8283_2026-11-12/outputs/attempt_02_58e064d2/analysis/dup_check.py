import pandas as pd, numpy as np, itertools
from parse_blocks import OBS, SURV
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)

# ---- 1. identical survival blocks / groups
print('=== identical time-to-event blocks (all groups, same day/status pattern) ===')
sig = {}
for blk, d in SURV.groupby('block', sort=False):
    key = tuple((g, tuple(sorted(zip(x['day'].fillna(-1), x['event'])))) for g, x in d.groupby('group', sort=False))
    sig[blk] = key
for a, b in itertools.combinations(sig, 2):
    if sig[a] == sig[b]:
        print('IDENTICAL:', a, '==', b)
    else:
        # group-level identity among same-named groups with >=1 event
        ga = dict(sig[a]); gb = dict(sig[b])
        common = [g for g in ga if g in gb and ga[g]==gb[g] and any(e==1 for _,e in ga[g])]
        if len(common)>=2: print('  shared identical event groups:', a, b, common)

# ---- 2. identical row vectors (same block-row across groups / blocks) in OBS
print('\n=== identical value vectors (length>=4) across different block/group/row ===')
vecs = {}
for (blk, g, rl), d in OBS.groupby(['block','group','row_label'], sort=False, dropna=False):
    v = tuple(d.sort_values('rep')['value'].round(4))
    if len(v) >= 4 and len(set(v)) > 1:
        vecs.setdefault(v, []).append((blk, g, rl, d['cell'].iloc[0], d['cell'].iloc[-1]))
for v, locs in vecs.items():
    if len(locs) > 1:
        print(v); [print('    ', l) for l in locs]

# ---- 3. partial overlaps: count of positionally identical values between vectors of the same length in different places
print('\n=== near-duplicates: >=60% positionally identical values (len>=5), different block/group ===')
items = []
for (blk, g, rl), d in OBS.groupby(['block','group','row_label'], sort=False, dropna=False):
    d = d.sort_values('rep')
    v = dict(zip(d['rep'], d['value'].round(4)))
    if len(v) >= 5 and len(set(v.values())) > 1:
        items.append(((blk, g, rl), v, d['cell'].iloc[0], d['cell'].iloc[-1]))
seen=set()
for (ka, va, ca0, ca1), (kb, vb, cb0, cb1) in itertools.combinations(items, 2):
    common = set(va) & set(vb)
    if len(common) < 5: continue
    same = sum(1 for r in common if va[r]==vb[r])
    if same/len(common) >= 0.6 and same >= 4:
        if all(abs(va[r]-100)<1e-9 for r in common): continue
        print(f'{same}/{len(common)} identical:', ka, f'[{ca0}:{ca1}]', '<->', kb, f'[{cb0}:{cb1}]')

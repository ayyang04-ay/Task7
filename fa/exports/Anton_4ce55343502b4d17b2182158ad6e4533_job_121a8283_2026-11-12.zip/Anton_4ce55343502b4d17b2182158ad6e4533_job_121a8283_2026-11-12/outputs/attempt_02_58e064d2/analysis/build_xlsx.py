"""Collect the evidence tables into one workbook for reviewers (needs openpyxl; run in env 'chem')."""
import os, pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, '..')
sheets = [
 ('Ledger', os.path.join(ROOT, 'evidence_ledger.csv'), {'ID': 9, 'topic': 18, 'statement': 55, 'value': 80, 'source_cells': 40, 'reduction': 50},
  'Every number used in the memo: the block, the value, the worksheet cells it comes from, and how it was reduced.'),
 ('Record conflicts', os.path.join(ROOT, 'record_conflicts.csv'), {'No.': 6, 'Blocks': 24, 'What the file shows': 80, 'Effect on the conclusions': 45, 'What I did': 45},
  'Places where the workbook contradicts itself or the annotation, and how each was handled.'),
 ('Survival by arm', os.path.join(HERE, 'survival_by_group.csv'), None, 'Every time-to-event block, every arm, as printed. event 1 = death, 0 = alive at end of observation.'),
 ('Survival pairwise tests', os.path.join(HERE, 'survival_pairwise_tests.csv'), None, 'Two-sided log-rank and Fisher exact tests for every pair of arms within each time-to-event block.'),
 ('Pooled survival', os.path.join(HERE, 'pooled_survival.csv'), None, 'Pooled comparisons stratified by experiment, including sensitivity sets.'),
 ('Immunology (Tukey)', os.path.join(HERE, 'immuno_tukey_summary.csv'), None, 'Single-time-point blocks: arm means (GMT for titres), Tukey p-values, and % of the young PSLN-212 value.'),
 ('Biomarker screen', os.path.join(HERE, 'biomarker_screen.csv'), None, 'Group-level separation of protected arms (aged PSLN-344, young PSLN-212) from unprotected arms (aged Sham, aged PSLN-212).'),
 ('Weights vs survival', os.path.join(HERE, 'bw_vs_survival_crosscheck.csv'), None, 'Deaths implied by each body-weight block against the paired time-to-event table.'),
]
wb = Workbook(); wb.remove(wb.active)
for name, path, widths, note in sheets:
    df = pd.read_csv(path)
    ws = wb.create_sheet(name[:31])
    ws.append([note]); ws['A1'].font = Font(italic=True, color='555555')
    ws.append(list(df.columns))
    for c in ws[2]:
        c.font = Font(bold=True); c.fill = PatternFill('solid', fgColor='E8E8E8'); c.alignment = Alignment(wrap_text=True, vertical='top')
    for row in df.itertuples(index=False):
        ws.append([None if (isinstance(v, float) and pd.isna(v)) else (round(v, 6) if isinstance(v, float) else v) for v in row])
    for j, col in enumerate(df.columns, start=1):
        w = (widths or {}).get(col)
        if w is None:
            w = min(max(len(str(col)) + 2, int(df[col].astype(str).str.len().quantile(0.9)) + 2), 60)
        ws.column_dimensions[get_column_letter(j)].width = w
    for r in ws.iter_rows(min_row=3):
        for c in r: c.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'B3'
wb.save(os.path.join(ROOT, 'PSLN-344_evidence_tables.xlsx'))
print('workbook written with sheets:', wb.sheetnames)

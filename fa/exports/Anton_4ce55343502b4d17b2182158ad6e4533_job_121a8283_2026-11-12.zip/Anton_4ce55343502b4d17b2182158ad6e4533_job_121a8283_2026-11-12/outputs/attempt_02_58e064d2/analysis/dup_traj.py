import pandas as pd, numpy as np, itertools
from parse_blocks import OBS
bw_blocks = ['S13-F','S13-G','S15-A','S15-B','S15-C','S15-D','S15-E','S15-F','S15-G','S15-I','S15-J','S15-K','S15-M','S15-O','S09-C','S09-E','S09-G','S08-D']
traj = {}
for b in bw_blocks:
    d = OBS[OBS.block==b].copy(); d['day']=d.row_label.astype(float)
    for (g, rep), x in d.groupby(['group','rep'], sort=False):
        s = x.sort_values('day'); traj[(b,g,rep)] = dict(zip(s.day, s.value.round(3)))
keys = list(traj)
print('animal trajectories:', len(keys))
hits=[]
for a, b in itertools.combinations(keys, 2):
    ta, tb = traj[a], traj[b]
    common = [t for t in ta if t in tb and t>0]
    if len(common) < 4: continue
    same = sum(1 for t in common if ta[t]==tb[t])
    if same >= 3:
        hits.append((same, len(common), a, b))
hits.sort(reverse=True)
for h in hits: print(h)
print(len(hits))
# value-level recurrence of odd decimals across blocks (template artefacts)
d = OBS[OBS.block.isin(bw_blocks)]
odd = d[(d.value*10 % 1).round(6).between(1e-6, 1-1e-6)]
vc = odd.groupby('value').agg(n=('cell','count'), blocks=('block', lambda s: sorted(set(s)))).query('n>1').sort_values('n', ascending=False)
print(vc.head(25).to_string())

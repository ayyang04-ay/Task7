import pandas as pd, numpy as np, itertools
from parse_blocks import OBS, SURV, CELLS
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
def vals(block, group, row=None):
    d = OBS[(OBS.block==block)&(OBS.group==group)]
    if row is not None: d = d[d.row_label==row]
    return d.sort_values('rep')['value'].values

print('=== XC1: S09-A panels vs S01-A (log10 of S01-A values; match to 3 dp) ===')
name_map = {'PBS':'Sham','CMP-204':'CMP-204','PSLN-212':'PSLN-212','PSLN-R848':'PSLN-R848','PSLN-212/R848':'PSLN-212/R848','PSLN-344':'PSLN-344','PSLN-212(y)':'PSLN-212(Y)'}
for panel in ['S09-A panel1 (cols A-V)','S09-A panel2 (cols X-AS)']:
    for tp in ['S01-A 16h','S01-A 72h']:
        nmatch=0; ntot=0
        for g9,g1 in name_map.items():
            a = vals(panel, g9, 'Ifnb1'); b = np.log10(vals(tp, g1))
            for x in a:
                ntot+=1
                if np.any(np.abs(b-x)<2e-3): nmatch+=1
        print(f'{panel} Ifnb1 values found among log10({tp}): {nmatch}/{ntot}')
# detail
for g9,g1 in name_map.items():
    print(g9, 'panel2:', np.round(10**vals('S09-A panel2 (cols X-AS)', g9, 'Ifnb1'),2), '| S01-A 72h:', vals('S01-A 72h', g1), '| panel1:', np.round(10**vals('S09-A panel1 (cols A-V)', g9, 'Ifnb1'),2), '| S01-A 16h:', vals('S01-A 16h', g1))

print('\n=== XC2: S03-B / S03-F quotient vs recomputed IgG2a/IgG1 from S13-A..D (paired by row) ===')
for qb, a, b, strain in [('S03-B','S13-A','S13-B','CA09'),('S03-F','S13-C','S13-D','Aichi')]:
    print(qb, strain)
    rec = {g: vals(a,g)/vals(b,g) for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']}
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        printed = vals(qb, g)
        match = [h for h in rec if np.allclose(rec[h], printed, rtol=2e-3)]
        print(f'   printed column "{g}": {np.round(printed,3)}  == recomputed IgG2a/IgG1 of S13 group {match}')
    for g in rec: print(f'   recomputed {g}: {np.round(rec[g],3)}  mean={rec[g].mean():.2f} geomean={np.exp(np.log(rec[g]).mean()):.2f}')

print('\n=== XC3: S04-B Tfh:Tfr equals (100-Foxp3%)/Foxp3% ===')
for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']:
    f = vals('S04-B Foxp3+', g); r = vals('S04-B Tfh:Tfr', g)
    print(g, np.allclose((100-f)/f, r, rtol=1e-4))
print(' S04-A ICOS-low + ICOS-high sums (total CXCR5+PD1+ %):')
for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']:
    lo = vals('S04-A ICOS-low', g); hi = vals('S04-A ICOS-high', g)
    print('  ', g, np.round(lo+hi,2), 'mean', round((lo+hi).mean(),2), '| ICOS-high fraction %', np.round(100*hi/(lo+hi),1))

print('\n=== XC4: S11-A vs S11-B positional identity ===')
tot=0; same=0; pos_same = {k:0 for k in range(1,6)}; pos_tot={k:0 for k in range(1,6)}
a = OBS[OBS.block=='S11-A'].set_index(['group','row_label','rep'])['value']
b = OBS[OBS.block=='S11-B'].set_index(['group','row_label','rep'])['value']
for idx in a.index:
    tot+=1; pos_tot[idx[2]]+=1
    if abs(a[idx]-b[idx])<1e-9: same+=1; pos_same[idx[2]]+=1
print(f'identical cells {same}/{tot}; by replicate position:', {k:f'{pos_same[k]}/{pos_tot[k]}' for k in pos_same})
# also S11-A/B vs S11-D?
d = OBS[OBS.block=='S11-D'].set_index(['group','row_label','rep'])['value']
print('S11-A vs S11-D identical:', sum(abs(a[i]-d[i])<1e-9 for i in a.index), '/', len(a))

print('\n=== XC5: S08-C vs S01-B ===')
for g in ['AECII-PSLN-SRB','AECII-PSLN-344-SRB','AECI-PSLN-SRB','AECI-PSLN-344-SRB']:
    print('S08-C', g, vals('S08-C', g), 'mean', vals('S08-C', g).mean().round(2))
for g in ['AECII/PSLN-SRB','AECI/PSLN-SRB','AECII/FreeSRB','AECI/FreeSRB']:
    print('S01-B', g, vals('S01-B', g), 'mean', vals('S01-B', g).mean().round(2))

print('\n=== XC6: S08-A 20ug vs S01-A 16h (aged) ===')
for g in ['CMP-204','PSLN-212','PSLN-344']:
    print(g, 'S08-A@20:', vals('S08-A', g, '20'), 'mean', vals('S08-A', g, '20').mean().round(2), '| S01-A 16h:', vals('S01-A 16h', g).mean().round(2))
print('PSLN-344/R848 S08-A@20:', vals('S08-A','PSLN-344/R848','20').mean().round(2), '| S01-A 16h PSLN-212/R848:', vals('S01-A 16h','PSLN-212/R848').mean().round(2))

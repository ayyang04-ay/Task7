import numpy as np, pandas as pd, itertools, warnings
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from parse_blocks import OBS
warnings.filterwarnings('ignore')
def show(block, pairs=None):
    x = OBS[OBS.block==block]
    m = x.groupby('group', sort=False)['value'].agg(['mean','std','count'])
    print(f'\n## {block}: ' + ' | '.join(f"{g}: {m.loc[g,'mean']:.2f}±{m.loc[g,'std']:.2f} (n={int(m.loc[g,'count'])})" for g in m.index))
    gs = list(m.index)
    if len(gs)==2:
        t = stats.ttest_ind(x[x.group==gs[0]].value, x[x.group==gs[1]].value); w = stats.ttest_ind(x[x.group==gs[0]].value, x[x.group==gs[1]].value, equal_var=False)
        print(f'   Student t p={t.pvalue:.3g} (Welch p={w.pvalue:.3g}); ratio {gs[0]}/{gs[1]} = {m.loc[gs[0],"mean"]/m.loc[gs[1],"mean"]:.2f}')
    else:
        tk = pairwise_tukeyhsd(x['value'], x['group'])
        res = {frozenset(k): p for k,p in zip(itertools.combinations(tk.groupsunique,2), tk.pvalues)}
        f = stats.f_oneway(*[x[x.group==g].value for g in gs])
        print(f'   one-way ANOVA p={f.pvalue:.3g}')
        for a,b in (pairs or itertools.combinations(gs,2)):
            print(f'   Tukey {a} vs {b}: p={res[frozenset([a,b])]:.3g}; ratio={m.loc[a,"mean"]/m.loc[b,"mean"]:.2f}')
show('S01-B'); show('S01-C'); show('S08-C'); show('S08-B')
show('S02-C', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)'),('PSLN-344(Y)','PSLN-212(Y)'),('PTX','PSLN-344'),('PTX','PSLN-212')])
show('S02-E', [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)'),('PSLN-344(Y)','PSLN-212(Y)'),('PTX','PSLN-344'),('PTX','PSLN-212')])
show('S02-G'); show('S02-H'); show('S02-I'); show('S05-C'); show('S07-B monocytes'); show('S07-B Ly6C+ Mphi'); show('S07-C'); show('S11-C'); show('S12-A')
show('S01-F'); show('S01-G')

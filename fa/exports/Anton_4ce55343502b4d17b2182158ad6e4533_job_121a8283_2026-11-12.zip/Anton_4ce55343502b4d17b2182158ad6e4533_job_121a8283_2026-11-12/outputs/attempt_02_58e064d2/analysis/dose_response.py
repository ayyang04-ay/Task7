"""S08-A: lung Ifnb1 (fold over untreated, linear) at 16 h vs nanoparticle dose (1-40 ug), n=3 per dose.
(1) model-free: interpolate on log-dose the PSLN-344 dose that matches PSLN-212 at 20 and 40 ug.
(2) Hill fit: E = 1 + (Emax-1) * d^h / (ED50^h + d^h), least squares on log(E)."""
import numpy as np, pandas as pd, warnings
from scipy.optimize import curve_fit
from parse_blocks import OBS
warnings.filterwarnings('ignore')
d = OBS[OBS.block=='S08-A'].copy(); d['dose']=d.row_label.astype(float)
means = d.groupby(['group','dose'])['value'].mean().unstack(0)
print(means.round(2))
def hill(dose, emax, ed50, h): return np.log(1 + (emax-1)*dose**h/(ed50**h + dose**h))
fits={}
for g in ['CMP-204','PSLN-212','PSLN-344','PSLN-344/R848']:
    x = d[d.group==g]
    p, cov = curve_fit(hill, x.dose.values, np.log(x.value.values), p0=[x.value.max(), 10, 2], bounds=([1,0.5,0.3],[500,200,8]), maxfev=20000)
    se = np.sqrt(np.diag(cov)); fits[g]=p
    print(f'{g:14s} Emax={p[0]:.1f} (SE {se[0]:.1f})  ED50={p[1]:.1f} ug (SE {se[1]:.1f})  Hill={p[2]:.2f}')
# model-free equi-effective dose
def interp_dose(g, target):
    m = means[g]; ds = m.index.values; v = m.values
    for i in range(len(ds)-1):
        if v[i] <= target <= v[i+1]:
            # log-log interpolation
            f = (np.log(target)-np.log(v[i]))/(np.log(v[i+1])-np.log(v[i]))
            return np.exp(np.log(ds[i]) + f*(np.log(ds[i+1])-np.log(ds[i])))
    return np.nan
for dose in [20, 40]:
    t = means.loc[dose,'PSLN-212']; e = interp_dose('PSLN-344', t)
    print(f'PSLN-212 at {dose} ug = {t:.2f}; PSLN-344 dose giving the same Ifnb1 (log-log interpolation) = {e:.1f} ug -> dose ratio {dose/e:.1f}x')
print('PSLN-344 / PSLN-212 ratio of means by dose:', (means['PSLN-344']/means['PSLN-212']).round(2).to_dict())
print('PSLN-212 40ug vs 20ug:', (means.loc[40,'PSLN-212']/means.loc[20,'PSLN-212']).round(2), ' PSLN-344 40 vs 20:', (means.loc[40,'PSLN-344']/means.loc[20,'PSLN-344']).round(2))
print('PSLN-344 at 10 ug vs PSLN-212 at 40 ug:', means.loc[10,'PSLN-344'].round(2), means.loc[40,'PSLN-212'].round(2))

"""Time-course / grid blocks: per-timepoint means, per-timepoint one-way Tukey, and two-way ANOVA (group x time)."""
import pandas as pd, numpy as np, itertools, warnings
from scipy import stats
import statsmodels.api as sm, statsmodels.formula.api as smf
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from parse_blocks import OBS
warnings.filterwarnings('ignore')
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 500); pd.set_option('display.max_columns', 50)

def twoway(block):
    d = OBS[OBS.block==block].copy()
    d['t'] = d['row_label'].astype(str)
    m = smf.ols('value ~ C(group)*C(t)', data=d).fit()
    a = sm.stats.anova_lm(m, typ=2)
    return a

def per_time_tukey(block, pairs):
    d = OBS[OBS.block==block].copy()
    out=[]
    for t, x in d.groupby('row_label', sort=False):
        means = x.groupby('group', sort=False)['value'].agg(['mean','std','count'])
        r = dict(block=block, time=t)
        for g in means.index: r[g] = f"{means.loc[g,'mean']:.2f}±{means.loc[g,'std']:.2f}"
        if x.group.nunique()>=3:
            tk = pairwise_tukeyhsd(x['value'], x['group'])
            res = {frozenset(k): p for k, p in zip(itertools.combinations(tk.groupsunique,2), tk.pvalues)}
        else:
            gs = list(x.group.unique()); res = {frozenset(gs): stats.ttest_ind(x[x.group==gs[0]].value, x[x.group==gs[1]].value).pvalue}
        for a,b in pairs:
            if frozenset([a,b]) in res: r[f'p[{a} v {b}]'] = res[frozenset([a,b])]
        out.append(r)
    return pd.DataFrame(out)

if __name__ == '__main__':
    P4 = [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)'),('PSLN-212','PSLN-212(Y)'),('PSLN-344','Sham'),('PSLN-212','Sham')]
    for blk in ['S01-D','S01-E']:
        print('\n####', blk); print(per_time_tukey(blk, P4).to_string(float_format=lambda x: f'{x:.3g}'))
        print(twoway(blk).to_string(float_format=lambda x: f'{x:.3g}'))
    print('\n#### S02-F'); print(per_time_tukey('S02-F', [('PSLN-344','PSLN-212'),('PSLN-344','Sham'),('PSLN-212','Sham')]).to_string(float_format=lambda x: f'{x:.3g}'))
    print(twoway('S02-F').to_string(float_format=lambda x: f'{x:.3g}'))
    print('\n#### S07-A'); print(per_time_tukey('S07-A', [('PSLN-344','PSLN-212')]).to_string(float_format=lambda x: f'{x:.3g}'))
    print(twoway('S07-A').to_string(float_format=lambda x: f'{x:.3g}'))
    P5 = [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)'),('PSLN-212','PSLN-212(Y)'),('PSLN-344','Vaccine'),('PSLN-212','Vaccine')]
    for blk in ['S11-A','S11-B','S11-D']:
        print('\n####', blk); print(per_time_tukey(blk, P5).to_string(float_format=lambda x: f'{x:.3g}'))
        print(twoway(blk).to_string(float_format=lambda x: f'{x:.3g}'))
    print('\n#### S05-A / S05-B (n=2 per cell)')
    for blk in ['S05-A','S05-B']:
        print(per_time_tukey(blk, [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212Y'),('PSLN-212','PSLN-212Y')]).to_string(float_format=lambda x: f'{x:.3g}'))
        print(twoway(blk).to_string(float_format=lambda x: f'{x:.3g}'))
    print('\n#### S08-A dose response')
    print(per_time_tukey('S08-A', [('PSLN-344','PSLN-212'),('PSLN-344','CMP-204'),('PSLN-212','CMP-204'),('PSLN-344','PSLN-344/R848')]).to_string(float_format=lambda x: f'{x:.3g}'))
    print(twoway('S08-A').to_string(float_format=lambda x: f'{x:.3g}'))
    print('\n#### S08-D body weight after immunisation')
    print(per_time_tukey('S08-D', [('PSLN-344','Vaccine'),('PSLN-212','Vaccine'),('PSLN-344','PSLN-212'),('PSLN-212/R848','Vaccine'),('PSLN-344','PSLN-212(Y)'),('CMP-204','Vaccine')]).to_string(float_format=lambda x: f'{x:.3g}'))
    print(twoway('S08-D').to_string(float_format=lambda x: f'{x:.3g}'))

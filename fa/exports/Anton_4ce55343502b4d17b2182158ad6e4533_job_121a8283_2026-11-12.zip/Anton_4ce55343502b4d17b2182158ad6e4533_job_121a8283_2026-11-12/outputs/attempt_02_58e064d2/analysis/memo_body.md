# PSLN-344: portfolio recommendation

*Basis: `adjuvant_program_dataset.xlsx` (15 sheets), read against `adjuvant_program_annotation.pdf`.*

## 1. Recommendation

**Advance PSLN-344, as a gated go.** Approve the next stage: a 9 to 12 month pre-IND package with six pass/fail gates. Hold IND-enabling spend (GLP toxicology, GMP manufacture) until those gates read out.

IDs in square brackets point to the evidence ledger in Appendix A, which gives the cells and the reduction behind each number.

The case in brief:

1. PSLN-344 is the only preparation in the file that protects most aged animals. Across nine lethal-challenge experiments, one intranasal dose given with vaccine left 51 of 63 aged mice alive (81%). The manganese-free parent PSLN-212 left 6 of 63 (10%), and the empty-liposome control 0 of 63 [E11].
2. The parent works in young animals (62 of 63 alive) and fails in aged ones, so without PSLN-344 the platform has no older-adult product [E11].
3. The advantage appears in every one of the nine experiments. It survives each way of handling the record conflicts I found: on the least favourable reading it is 80% against 17% [E1–E9, E11-s4].

Why gated rather than unconditional:

- **Records.** Several blocks that carry headline claims contradict other blocks in the same workbook (section 3.1).
- **Safety.** The evidence is one 10-day weight study, one lung cytokine panel and one CNS time point. There is nothing on manganese itself (section 3.4).
- **Translation.** Nothing in the file tests what a clinical programme would depend on: a licensed comparator, a manganese-only control, a second species, male animals, a split-antigen vaccine, or a delivery route that reaches the human lung (section 3.5).

The six gates, detailed in section 6:

0. The record conflicts are reconciled against source records. This takes 2 to 4 weeks and comes before any new spend.
1. The benefit repeats in a blinded study and needs manganese and the STING agonist together.
2. PSLN-344 at least matches a licensed-type vaccine for older adults.
3. Manganese clears, and lung and CNS inflammation resolve.
4. The particle activates human STING in cells from older donors.
5. Efficacy holds with a delivery route and an antigen format that can be used in people.

**How to check a number.** Every number in this memo is followed by a ledger ID in square brackets, for example [E2]. Appendix A (also `evidence_ledger.csv`) gives the block, the exact cells and the reduction for each ID. An ID cited without its letter covers all its lettered rows: [E11] means E11a to E11d. Unless a line says otherwise:

- survival is the number of animals with status 0 at the end of observation divided by the animals in the arm;
- percentages and fold-changes are arithmetic means of the per-animal values;
- titres are geometric means (GMT);
- p-values use the methods named in the annotation: log-rank for time to event, one-way ANOVA with Tukey's test for multi-arm blocks, Student's t for two-arm blocks.

"Aged" means 20 months or older and "young" means 7 to 8 weeks, as in the annotation. "Empty-liposome control" is the arm the workbook calls Sham (vaccine plus empty liposome). I treated the workbook as ground truth. Where two blocks contradict each other, both cannot be true, so I show both readings (Appendix B).

## 2. The case for advancing

![Figure 1. Survival of aged mice after lethal influenza challenge. A: each experiment. B: the nine experiments pooled.](figures/fig1_survival_aged.png)

**2.1 It closes an age gap that the parent formulation cannot.**

- PSLN-212 protects young mice (62/63, 98%) but not aged mice (6/63, 10%) [E11].
- PSLN-344 in aged mice: 51/63 alive, 81% (exact 95% CI 69–90%) [E11].
- PSLN-344 beat PSLN-212 in all nine experiments, by 4 to 7 more survivors out of 7 [E1–E9]. The nine experiments do not differ from one another beyond chance (p = 0.64 for PSLN-344) [E12e].
- Pooled and stratified by experiment, the hazard ratio for death is 0.10 (95% CI 0.06–0.17; log-rank p = 1.6 × 10⁻¹⁷) [E12a].
- The result does not depend on my handling choices:
    - counting the duplicated block S06-D gives 58/70 against 8/70 [E11-s1];
    - relabelling the disputed S03-I comparator gives 51/63 against 9/63 [E11-s2];
    - reading deaths from the body-weight blocks instead gives 53/63 against 9/63 [E11-s3];
    - taking, in every experiment, the record least favourable to PSLN-344 and most favourable to PSLN-212 gives 56/70 (80%) against 12/70 (17%) [E11-s4].

**2.2 The protection is broad, fast, and holds in pre-immune animals.**

| Setting (aged mice unless stated) | Vaccine + PSLN-344 | Vaccine + PSLN-212 | Vaccine, no active adjuvant | Ledger |
|:-----------------------------------------|:---------|:---------|:---------|:------|
| Matched strain, 10× LD50 CA09 H1N1, day 14 | 7/7 | 0/7 (3/7 on the alternative reading, section 3.1) | 0/7 | E1, E11-s2 |
| H3N2 vaccine, H1N1 challenge, day 14 | 6/7 | 1/7 | 0/7 | E2 |
| H1N1+H3N2 vaccine, rgH5N1 challenge, day 14 | 7/7 | 2/7 | 0/7 | E4 |
| Challenge 3 days after the dose (two experiments) | 11/14 | 0/7 (one experiment) | 0/14 | E25 |
| Wild-type H5N1, 2 days after the dose (age not stated) | 10/10 | 3/10 | 1/10 | E18 |
| Challenge 60 days after the dose (three experiments) | 14/21 | 1/21 | 0/21 | E15c |
| Aged C57BL/6 | 6/7 | 0/7 | 0/7 | E8 |
| Aged outbred Swiss Webster | 6/7 | 2/7 | 0/7 | E9 |
| 14-month mice, previously infected with H1N1 | 12/14 | 4/14 | not run | E20 |
| 14-month mice, not previously infected | 12/14 | 0/14 | not run | E20 |

The last column is vaccine plus empty liposome, except in one of the two day-3 experiments (S15-H), where it is vaccine alone. In the wild-type H5N1 experiment (S03-J), one PSLN-344 animal has no day recorded and the block label says n = 9 [E18].

**2.3 The immune response is rebuilt along the whole chain, not at one point.** Across 26 readouts, PSLN-344 brought aged mice to a median 73% of the young PSLN-212 response. PSLN-212 in aged mice reached a median 21% [I26; Figure 2]. Examples:

- Haemagglutination-inhibition (HAI) titre against the CA09 H1N1 strain: GMT 368 with PSLN-344, 46 with PSLN-212, 485 in young [I2].
- Neutralising titre against CA09: 3,840, 418 and 6,686 [I3].
- CD8 T cells that make IFN-γ when restimulated with H5N1, a subtype not in the vaccine: 6.4%, 1.5% and 9.2% at day 14 [I14], and 9.9%, 3.0% and 14.4% at day 60 [I15].
- Germinal-centre B cells in the lung-draining lymph node at day 7: 6.5%, 2.3% and 9.8% [I7].
- The antibody response shifts to the IgG2a-dominant type seen in young mice. The IgG2a:IgG1 ratio against CA09 is 2.1, 0.58 and 3.0. These are recomputed values; the printed block is mislabelled (section 3.1) [I24].

![Figure 2. Response in aged mice as a percentage of the young PSLN-212 response, for 26 readouts.](figures/fig2_restoration_index.png)

**2.4 More dose, a different agonist, or a second agonist does not reproduce it.**

- *More PSLN-212.* Manganese raises the ceiling of the lung IFN-β response, not just the potency. The fitted maximum is 58.7-fold for PSLN-344 and 16.6-fold for PSLN-212, with similar half-maximal doses (13.3 and 10.8 µg). PSLN-344 at 10 µg (21.1-fold) already exceeds PSLN-212 at 40 µg (14.9-fold) [D1, D2; Figure 3A].
- *More drug per particle.* Encapsulation is no higher: 54.8% for PSLN-344, 59.6% for PSLN-212 [D3].
- *cGAMP instead of CDN-1807 (CMP-204).* Weaker in aged mice: lung Ifnb1 7.8-fold against 37.1-fold [M1], HAI GMT 23 against 368 [I2].
- *Adding the TLR7/8 agonist R848 (PSLN-212/R848).* Less IFN-β than PSLN-344 (24.3-fold against 37.1-fold) [M1] and poorly tolerated: lung Tnf 202-fold and Il10 179-fold at 16 h [S6], and body weight still falling at day 10 (90.6% of baseline) [S2].

![Figure 3. A: lung IFN-β dose-response. B: lung IFN-β in aged and young mice. C: vaccine alone, adjuvant alone, and the combination.](figures/fig3_mechanism.png)

**2.5 The first look at tolerability is acceptable.**

- Weight after dosing fell to a nadir of 96.4% of baseline with PSLN-344, against 98.2% with vaccine alone (Tukey p = 0.86; unadjusted t-test p = 0.06), and was back to 99.8% by day 10 [S1, S2].
- CNS transcripts 36 h after dosing were 1.3-fold (Ifnb1), 1.6-fold (Tnf) and 1.1-fold (Isg15) of the PBS control, none different from PBS by Tukey's test (p ≥ 0.54). The positive control, cholera toxin, gave 5.5-, 3.5- and 2.7-fold [S7; Figure 4].

## 3. What the committee will push on

**3.1 The record contradicts itself in blocks that matter.** Appendix B lists every conflict. Four affect the headline:

- **S06-D duplicates S06-C.** The day-3 rgH5N1 experiment (S06-D) is identical to the day-14 experiment (S06-C) in all 28 rows [Q1]. Its own weight block (S15-D) implies two deaths in the PSLN-344 arm that the table does not show [Q2]. I did not count S06-D. Early protection rests on S06-B, S15-H and S03-J instead [E25, E18].
- **Two experiments name their arms differently in the survival table and the weight block for the same animals.** In S03-I and S03-J, the PSLN-344 result is the same either way (7/7 and 10/10). What it is compared with is not certain [Q4, Q5]:
    - In S03-I, the PSLN-212 arm survived 0/7 as printed, or 3/7 if the weight-block labels are right.
    - In S03-J (wild-type H5N1), the weight block has no PSLN-212 arm at all. If it is right, the comparison was with the empty-liposome control and with unvaccinated animals, and the manganese-free parent was not tested in that experiment.
- **The body-weight sheets are not independent records.** Identical values recur between experiments that should share no animals [Q6], and weight-implied deaths disagree with the survival tables in ten arms [Q2]. I used weights descriptively only.
- **The printed IgG2a:IgG1 blocks (S03-B, S03-F) have their three headers rotated.** As printed they say PSLN-344 gives the IgG1-skewed response (0.58). Recomputed from the titres in S13-A to S13-D, PSLN-344 gives 2.1 and PSLN-212 gives 0.58 [I24, I25].

**3.2 The restoration is partial.**

- Survival is 81% against 98% in young mice (p = 0.001) [E11, E12c].
- Survivors still get sick. Their weight nadir averaged 88.2% of baseline, against 90.6% in young mice [E24]. The file has no lung virus titres and no lung pathology.
- Dendritic-cell co-stimulation stays low: CD40 and CD86 reach 29% and 38% of the young level [M6, M7].
- The fall in follicular regulatory T cells has gone by day 30: 14.0% with PSLN-344, 13.9% with the empty-liposome control [I10].

**3.3 Durability in aged animals is not shown beyond day 60.**

- At day 60, 14/21 survived (67%), against 20/21 at day 14 (p = 0.045). Within the two models tested at both times it was 10/14 against 13/14 (p = 0.33) [E17].
- Some of this is old age, not vaccine failure: 4 of 21 age-matched mice that were never challenged died in the same 14 days [E16]. But the PSLN-344 deaths look like infection. The five that can be identified in the weight blocks died at 78–85% of baseline weight. The four unchallenged animals died at 94–97% [E16b].
- The only 6-month data are in young mice. All survived with either adjuvant, but the PSLN-344 group recovered more slowly: 95.6% of baseline at day 14 against 99.2% (p = 0.003) [E21, E23].

**3.4 The safety evidence is thin.**

- One weight study: five animals per arm, one dose level, 10 days [S1].
- Lung inflammation had not resolved at the last time point measured.
    - At 72 h, aged mice given PSLN-344 still had Tnf 8.4-fold, Il6 7.2-fold and Ccl2 27-fold above PBS [S5]. Against young mice given PSLN-212, Tnf was 18 times higher and Il10 37 times higher [S4].
    - Part of this is age rather than manganese. Aged mice given PSLN-212 also had Tnf 5.2-fold and Il10 4.2-fold above PBS at 72 h [S5].
    - Lung monocytes and CD11b+ dendritic cells were still raised on day 8, the last day sampled: 18.4% and 13.7%, against 9.5% and 2.4% in the empty-liposome control [M3b, M4b].
- CNS: one time point, three transcripts, five animals. Tnf was 1.6-fold of PBS, which is p = 0.037 on an unadjusted t-test and p = 0.54 by Tukey's test [S7]. There are no manganese measurements and no histology anywhere in the file.
- The lung "neutrophil" block (S11-B) shares 35 of its 100 values with the alveolar-macrophage block (S11-A) and cannot be used [S8].
- Two class concerns are not addressed at all. Both are general knowledge, not findings from the file: inhaled manganese can reach the brain along the olfactory route, and an earlier nasal influenza vaccine with a toxin adjuvant was withdrawn after cases of facial palsy.

![Figure 4. A: body weight after dosing. B: lung cytokine transcripts at 16 h and 72 h. C: CNS transcripts at 36 h.](figures/fig4_safety.png)

**3.5 Translation gaps.** None of the following is tested in the file. The right-hand column draws on general knowledge of licensed influenza vaccines and respiratory delivery, not on the file.

| Gap | Why it matters |
|:-------------------------|:------------------------------------------------------------|
| No manganese-only particle, and no PSLN-212 mixed with free Mn²⁺ | The benefit cannot yet be attributed to the Mn–CDN combination rather than to manganese alone. |
| No licensed-type comparator (intramuscular high-dose or emulsion-adjuvanted vaccine) | Every comparison is against an unadjuvanted intranasal vaccine or PSLN-212. |
| Mice only, females only, 7 per arm, no stated replication | n = 7 gives 67% power for 81% against 10%, and 16% for 81% against 40% [P1]. |
| Whole inactivated virus as the antigen | Licensed seasonal vaccines are split, subunit or recombinant. Whole virions carry more internal protein and viral RNA, which may matter for the T-cell response and for innate stimulation. |
| Efficacy at 20 µg only | The lung IFN-β response is already near its plateau at 20 µg [D1]. The minimum effective dose is unknown. |
| Delivery | In mice the intranasal dose reaches alveolar epithelium and alveolar macrophages [M16, M17]. A human nasal spray deposits in the nose, not the alveoli. |
| Human STING | No human-cell data. Human STING variants differ in how they respond to cyclic dinucleotides. |
| Particle characterisation | The annotation describes size, charge, morphology and freeze-drying, but the file holds only encapsulation efficiency [D3]. There is no manganese content, release or stability data. |

## 4. What is actually driving the protection

**What the data establish**

1. **Vaccine and adjuvant are both required.** Three days before rgH5N1 challenge, vaccine alone protected 0/7, PSLN-344 alone 0/7, and the two together 6/7 [E19; Figure 3C]. The protection is not a free-standing antiviral state left by the adjuvant.
2. **In aged animals the manganese-containing particle is required. In young animals it adds nothing measurable downstream.** Young mice survived 24/24 with either adjuvant [E21]. Manganese raised four dendritic-cell readouts 1.7- to 24-fold in aged mice, and 1.0- to 1.2-fold in young mice (interaction p from 0.005 to 0.04) [M23].
3. **Manganese acts on signal strength, not on delivery.**
    - Encapsulation is not higher [D3].
    - Epithelial uptake is not higher on either reading of S08-C [D4].
    - Lung Ifnb1 at 16 h is 37.1-fold with PSLN-344 against 16.6-fold with PSLN-212 in aged mice. That equals the 37.6-fold that PSLN-212 produces in young mice [M1; Figure 3B].
4. **The cellular chain downstream of IFN-β is rebuilt to near the young level** (aged PSLN-344, aged PSLN-212, young PSLN-212):
    - lung monocytes on day 4: 30.6%, 16.7%, 32.2% [M3];
    - lung CD11b+ dendritic cells on day 4: 18.9%, 8.3%, 21.4% [M4];
    - cross-presenting (type 1) dendritic cells in the lung at 72 h: 37.5%, 22.8%, 43.4% [M24];
    - migratory (CCR7+) dendritic cells at 72 h: 30.7%, 7.3%, 35.0% [M5];
    - CD8 T-cell priming by dendritic cells sorted from the lymph node: 18.7%, 0.8%, 26.2% [M8].
5. **Each link has been broken experimentally, but only up to an intermediate readout.**
    - A CCR2 antagonist cut lung monocytes by 67% and Ly6C+ macrophages by 84% [M13, M14]. In young mice it cut granzyme B-positive (GZMB+) CD8 T cells in the lung by 79% [M12].
    - Bone marrow lacking the type I IFN receptor produced almost no monocyte-derived dendritic cells (2.1% against 19.7%). GM-CSF partly rescued this (12.4%) [M11]. PSLN-344 induces lung Gm-csf (8.7-fold against 1.6-fold) [M9].
    - Pertussis toxin blocked CD8 T-cell proliferation in the lymph node (30.9% to 6.8%) but not in the lung (59.0% to 55.1%) [M18]. T cells can therefore be expanded in the lung itself, which fits protection within 2 to 3 days.
    - The delivery features of the platform are needed as well, but both particles share them. Uptake by alveolar macrophages fell from 43.1% to 12.7% in mice lacking surfactant proteins A and D [M16]. A gap-junction blocker cut monocyte recruitment by 58% [M15]. This is why the deep lung matters for Gate 5.
6. **The only measured effector that fits every protection setting is the CD8 T cell.** Serum HAI antibody cannot explain protection against a different subtype, or protection 2 to 3 days after dosing. Activated CD8 T cells are in the lung by day 3: proliferating (Ki-67+) 9.4% against 3.5%, and GZMB+ 5.7% against 3.0% [I12, I13]. They cross-react with H5N1 and persist to day 60 [I14, I15].

**What the data do not establish**

- **Causality.** No pathway blockade was carried through to a challenge. There is no T-cell depletion and no serum transfer. CD8 T cells are the leading hypothesis, not a finding. Antibody acting without neutralisation is not excluded: IgG2a rose 20-fold (GMT 1,642 against 83) [I22].
- **What the vaccine contributes at day 3.** S15-H shows the vaccine is needed. It does not show whether it is needed as antigen or as a second innate stimulus.
- **Whether manganese alone would do the same.** There is no manganese-only arm.
- **The regulatory-cell story.** PSLN-344 lowers lung regulatory T cells (3.0% against 6.7%) [I11] and CD206+ macrophages (48.9% against 71.5%) [M20]. The two blocks designed to link these cannot be read. S07-A runs opposite to S01-D and S07-B, and both columns of S07-C carry the same header [M21, M22].

**In one line:** manganese restores the strength of STING-driven IFN-β in the aged lung; that rebuilds monocyte recruitment and dendritic-cell priming; the result is a vaccine-dependent response in which cross-reactive lung CD8 T cells are the best-supported, but unproven, effector.

## 5. Is there a biomarker of efficacy worth carrying forward?

**There is a candidate, and none is validated.** Two limits come from the design of the dataset:

- No animal has both a biomarker value and a challenge outcome. Every association is between group means from parallel animals.
- With four arms, nearly everything tracks survival. Of 33 single-time-point readouts, 27 separate the protected arms from the unprotected arms without overlap (`analysis/biomarker_screen.csv`). The data cannot rank them.

So the choice has to rest on two questions: does the marker fit every setting where protection was seen, and can it be measured in a person?

| Candidate | Fits the protection data? | Measurable in patients as measured here? | Role |
|:----------------|:----------------------------------|:----------------------|:----------------------|
| Lung Ifnb1 at 16 h | Necessary, not sufficient. PSLN-344 alone induces it 37-fold [M1], yet PSLN-344 alone protected 0/7 [E19]. Young mice given PSLN-344 make 35% more than with PSLN-212, with no survival gain [M1, E21]. | No (lung tissue). | Target engagement and dose-finding only. |
| Serum HAI and neutralising titre | Partly. They rank the arms for matched-strain challenge [I2, I3]. But all five aged PSLN-212 mice reached HAI ≥ 1:40, and at most 3 of 7 parallel animals survived [I2b]. They cannot explain day-2 to day-3 or cross-subtype protection. | **Yes.** Serum antibody is the only readout in the file taken from a patient-accessible sample. | Immunogenicity endpoint. Not sufficient alone. In this model a titre at the conventional 1:40 benchmark did not predict survival. |
| Cross-reactive CD8 T cells (IFN-γ+ after restimulation with a subtype not in the vaccine; GZMB+) | Yes, in every setting: present by day 3, cross-subtype, durable to day 60, dependent on the monocyte pathway [I12–I15, M12]. | Not as measured (lymph node and lung). A blood version is untested. | **Lead candidate.** Mechanism and response marker. A candidate correlate once Studies 2 and 3 read out. |
| Lung dendritic cells, germinal-centre B cells, follicular helper T cells (Tfh), resident-memory T cells | Yes. | No (tissue only). | Preclinical mechanism markers. |
| IgG2a:IgG1 ratio; ratio of Tfh to follicular regulatory T cells (Tfr) | Yes, but mouse-specific (isotypes) or derived from one measurement and gone by day 30 [I24, I10]. | No direct human equivalent. | Not carried. |

![Figure 5. The two candidates. A: serum HAI with survival of a matched-strain challenge. B: cross-reactive CD8 T cells with survival of an rgH5N1 challenge. Survival is from parallel animals, not the animals assayed. In A it is shown as printed in S03-I; section 3.1 gives the alternative reading.](figures/fig5_biomarker_candidates.png)

**What I would carry forward, and in what role**

- **A pair, not a single marker.** Serum HAI and neutralising titre, which are ready now. And a blood CD8 T-cell assay (IFN-γ ELISpot or intracellular staining against conserved internal proteins), which has to be built and bridged to the lung readouts first.
- **An early blood or nasal interferon signature** as the target-engagement marker for dose selection.
- **Role in patients: pharmacodynamic and response biomarkers** in Phase 1 and 2. They would show that the adjuvant engages its pathway in adults over 65, and that it adds cross-reactive T-cell immunity that HAI alone does not capture.
- **Not a surrogate endpoint and not a patient-selection marker.** Nothing here supports either use.

**Could the adjuvant itself go into patients, and in what role?** Not on the present data. If the gates are passed, the role the data support is a respiratory-route adjuvant for inactivated influenza vaccine in adults over 65. The data support a pandemic or outbreak setting (H5, protection within days) as well as the seasonal one. They give no reason to use it in younger adults, where it adds no protection over PSLN-212 [E21].

## 6. What the next studies have to establish

Six gates (0 to 5) decide whether IND-enabling work starts. Studies 2 to 4 do not gate it. They fix the clinical biomarker plan and the regimen, and show whether a season-long claim is realistic.

| Study | Gate | Must establish | Duration |
|:------------------------------|:-------|:------------------------------------------------|:-----------|
| 0. Record reconciliation | 0 | Which arm is which in the conflicting blocks | 2–4 weeks |
| 1. Confirmatory efficacy | 1, 2 | The benefit repeats, needs Mn and CDN together, and holds against licensed-type vaccines | about 4 months |
| 2. Mechanism of protection | – | Which effector protects; whether the monocyte pathway is needed for survival | about 3 months |
| 3. Biomarker bridging | – | A blood or nasal measure that predicts each animal's outcome | about 3 months |
| 4. Durability and regimen | – | Protection at 3 and 6 months; value of a second dose | about 9 months |
| 5. Safety and manganese disposition | 3 | Where manganese goes; whether inflammation resolves; a safety margin | about 5 months |
| 6. Human relevance | 4 | Activity on human STING variants and in cells from older donors | about 3 months |
| 7. Route, antigen, second species | 5 | Efficacy with a deliverable route, a licensed-format antigen, and in ferrets | about 6 months, after Gate 1 |

Studies 0 to 3, 5 and 6 can start together. Particle characterisation and stability work (size, charge, manganese content and release, freeze-dried storage) should run alongside, because none of it is in the file. Sample sizes come from the survival rates seen here: with 80% power, 8 per arm detects 81% against 10%, 25 per arm detects 81% against 40%, and 34 per arm detects 95% against 67% [P1].

**Study 0. Record reconciliation (Gate 0)**

- *Must establish:* the arm identities in S03-I/S13-F and S03-J/S13-G; whether S06-D is a separate experiment; the correct headers for S03-B, S03-F, S07-A, S07-C, S08-C and the second S09-A panel; the status of S11-B and of the shared body-weight values.
- *Population, comparators:* none. This is a check of source records.
- *Endpoint:* a locked dataset and a re-run of this analysis.
- *Pass:* the aged survival advantage of PSLN-344 over PSLN-212 stays at 40 points or more.
- *Timing:* 2 to 4 weeks, before any new spend.

**Study 1. Confirmatory efficacy, blinded and randomised (Gates 1 and 2)**

- *Must establish:* that the benefit repeats; that it needs manganese and CDN together; the lowest effective dose; how it compares with licensed-type vaccines.
- *Population:* aged BALB/c of both sexes (the file is female-only). 25 per arm for comparisons between active arms, 12 per arm for dose-ranging and controls. A young reference arm. Unchallenged age-matched sentinels.
- *Arms and comparators:*
    - vaccine + PSLN-344 at 2.5, 5, 10 and 20 µg;
    - vaccine + PSLN-212 at 20 and 40 µg;
    - vaccine + manganese-only liposome;
    - vaccine + PSLN-212 mixed with free Mn²⁺;
    - vaccine + empty liposome;
    - PSLN-344 alone;
    - intramuscular high-dose vaccine;
    - intramuscular emulsion-adjuvanted vaccine.
- *Primary endpoint:* survival to day 14 after a cross-subtype challenge, with a pre-set humane endpoint and blinded scoring.
- *Pass:* survival of 70% or more; 40 points or more above PSLN-212 and above manganese-only (Gate 1); not below the better intramuscular comparator (Gate 2).
- *Readouts:* lung virus titre and histology on days 3 and 6 after challenge (absent from the present file); weight and clinical score; serum HAI and a blood T-cell assay on the same animals before challenge.
- *Timing:* challenge 14 days after one dose. About 4 months including supply of aged animals.

**Study 2. Mechanism of protection**

- *Must establish:* whether CD8 T cells, antibody, or both are needed; whether the monocyte pathway is needed for survival and not only for intermediate readouts; whether day-3 protection is antigen-specific.
- *Population:* aged BALB/c, 12 per arm.
- *Arms and comparators:* vaccine + PSLN-344 with each of: isotype control antibody; CD8 depletion before challenge; CD4 depletion before challenge; CCR2 antagonist during priming; interferon-receptor blockade during priming. Also: immune serum transferred into naive aged recipients; an unrelated antigen + PSLN-344.
- *Primary endpoint:* survival to day 14.
- *Readouts:* lung virus titre; confirmation of depletion by flow cytometry.
- *Timing:* challenges at day 3 and day 14, cross-subtype and matched-strain. About 3 months.

**Study 3. Biomarker bridging**

- *Must establish:* a blood or nasal measure that tracks the lung and lymph-node readouts and predicts each animal's own outcome.
- *Population:* aged BALB/c, about 80 in total, spread over PSLN-344 doses from 0 to 20 µg so that responses vary.
- *Comparators:* PSLN-212 and empty liposome.
- *Primary endpoint:* accuracy of each pre-challenge marker in predicting survival.
- *Carry forward:* markers with an area under the ROC curve of 0.8 or more, and a correlation of 0.6 or more with the tissue readout.
- *Readouts and timing:*
    - day 1: blood interferon-response score and nasal IFN-β;
    - day 7: activated CD8 T cells in blood;
    - day 13: HAI, neutralising titre, blood IFN-γ ELISpot;
    - day 14: challenge;
    - satellite animals: paired blood and lung on days 7 and 14.

**Study 4. Durability and regimen**

- *Must establish:* protection at 3 and 6 months in animals that were old when vaccinated; whether a second dose helps.
- *Population:* BALB/c vaccinated at 14 months, when the defect is already present (PSLN-212 0/14) [E20]. 34 per arm. Unchallenged sentinels at each time.
- *Arms and comparators:* PSLN-344 once; PSLN-344 twice; PSLN-212 twice; an intramuscular comparator; empty liposome.
- *Primary endpoint:* survival after challenge at day 90 and at day 180.
- *Readouts:* HAI, neutralising titre, blood T-cell assay, lung resident-memory T cells and follicular regulatory T cells on days 28, 90 and 180.
- *Timing:* starts with Study 1; reads out at about 9 months.

**Study 5. Safety and manganese disposition (Gate 3)**

- *Must establish:* where the manganese goes and whether it clears; whether lung and CNS inflammation resolve; a safety margin. The present file stops at 72 h for lung cytokines, day 8 for lung cells and 36 h for the CNS.
- *Population:* aged mice of both sexes, then rats. Two species for the later GLP studies.
- *Arms and comparators:* PSLN-344 at 1×, 3× and 10× the effective dose, single and repeated; PSLN-212; manganese-only liposome; Mn²⁺ solution; vehicle.
- *Endpoints and readouts:* manganese by mass spectrometry (ICP-MS) in olfactory bulb, brain regions, lung, liver and blood; histology of nasal cavity, brain and lung; lavage cell counts and cytokine protein; behaviour and olfaction; clinical pathology.
- *Pass:* no brain manganese above control at day 28; lung and CNS markers back to baseline by day 28; a no-adverse-effect level at 3× the effective dose or higher.
- *Timing:* 24 h, then days 7, 28 and 90. About 5 months.

**Study 6. Human relevance (Gate 4)**

- *Must establish:* that CDN-1807 with Mn²⁺ activates the common human STING variants; that the gain over PSLN-212 holds in cells from older donors.
- *Population:* blood monocytes from donors over 65 and donors aged 18 to 40, genotyped for STING. Human lung tissue where available.
- *Comparators:* PSLN-212, CMP-204, free Mn²⁺, empty liposome.
- *Readouts:* IFN-β, CXCL10, TNF and IL-6 protein; cell viability; at 6, 24 and 72 h.
- *Pass:* PSLN-344 gives at least twice the IFN-β of PSLN-212 in older-donor cells, in every common genotype.
- *Timing:* about 3 months.

**Study 7. Route, antigen and second species (Gate 5)**

- *Must establish:* that efficacy survives a delivery that is feasible in people and a licensed-format antigen.
- *Population:* aged mice first, then ferrets, including pre-immune animals.
- *Arms and comparators:*
    - mice: upper-airway-only dosing against deep-lung dosing; split vaccine against whole inactivated virus;
    - ferrets: PSLN-344 by nasal spray and by aerosol; an intramuscular adjuvanted vaccine; vaccine alone.
- *Primary endpoint:* survival in mice; nasal-wash virus load over days 1 to 7 in ferrets.
- *Readouts:* fever, weight, transmission to contact animals, HAI, nasal IgA, blood T-cell assay.
- *Pass:* protection retained with at least one deliverable route and with split antigen.
- *Timing:* challenge at day 28 and day 90. About 6 months, starting after Gate 1.

**First-in-human study.** It would follow only if Gates 0 to 5 are passed. Its outline:

- adults aged 50 to 64, then over 65;
- licensed antigen with ascending PSLN-344 doses, against a licensed high-dose or adjuvanted vaccine;
- safety: reactogenicity over 7 days, neurological and olfactory assessment, blood manganese;
- biomarkers in the roles set out in section 5.

## 7. What I considered and ruled out

**Alternative ways to get the same benefit**

| Alternative | Verdict | Evidence |
|:--------------------------|:--------------|:--------------------------------------------------|
| Keep PSLN-212 for older adults | Ruled out | 6/63 survive [E11]. |
| Raise the PSLN-212 dose | Ruled out on the pharmacodynamic readout; no challenge data | IFN-β plateaus at 14.9-fold at 40 µg [D1, D2]. |
| Give PSLN-212 twice | Not established | After a boost, IgG GMT against CA09 is 4,411 with PSLN-212 and 15,651 with PSLN-344 (p = 0.19). Against H3N2 it is 1,086 and 12,435 (p < 0.001). There is no challenge after a boost [I20, I21]. |
| Switch to cGAMP (CMP-204) | Ruled out for aged animals | Ifnb1 7.8-fold, HAI GMT 23 [M1, I2]. Adequate in young mice (7/7) [E22]. |
| Add R848 | Ruled out | Tolerability [S2, S6]; less IFN-β than PSLN-344 [M1]. |
| Add GM-CSF to PSLN-212 | Mechanistic tool only | Restores monocyte-derived dendritic cells from 5.9% to 13.8% [M10]. No challenge data. |
| Use PSLN-344 at all ages | Not supported | No gain in young mice [E21]; slower recovery at 6 months [E23]. |

**Alternative explanations for the benefit**

| Explanation | Verdict | Evidence |
|:--------------------------|:--------------|:--------------------------------------------------|
| More drug loaded | Ruled out | Encapsulation 54.8% against 59.6% [D3]. |
| Better delivery to epithelium | Ruled out on either reading | S08-C [D4]. |
| A non-specific antiviral state | Ruled out | Adjuvant alone 0/7 [E19]. |
| A BALB/c peculiarity | Ruled out | C57BL/6 6/7; Swiss Webster 6/7 [E8, E9]. |
| Natural killer cells | Not supported | Lung NK cells did not differ from PSLN-212 or from vaccine alone on any day (p ≥ 0.12) [M25]. |
| More alveolar macrophages | Not supported | They rise with both adjuvants; PSLN-344 does not differ from PSLN-212 on any day (p ≥ 0.15) [M26]. |
| Works only in animals with no prior influenza exposure | Ruled out | 12/14 with or without prior infection [E20]. |
| Serum HAI antibody alone | Cannot account for day-2 to day-3 or cross-subtype protection | [E25, E18, E2, E4]. |
| Day-60 deaths are just old age | Partly | 4/21 unchallenged animals died, at 94–97% of baseline weight. The PSLN-344 deaths followed 15–23% weight loss [E16, E16b]. |

**Analysis choices I rejected**

- Counting S06-D as a tenth experiment: it is a copy of S06-C [Q1].
- Taking the printed IgG2a:IgG1 blocks at face value: the headers are rotated [I24, I25].
- Treating the second S09-A panel as a repeat at 16 h: its Ifnb1 row reproduces the 72 h values of S01-A in all 21 cells [Q3].
- Treating the "Untreated" arms of S06-E, S06-F and S06-G as infected controls: the annotation says they received no virus. I used them as the background death rate [E16].
- Averaging the log10 values of S09-A as if linear: I averaged on the log scale and back-transformed.
- Using body weights to overrule the survival tables: the weight sheets share values between experiments [Q6]. They serve as a sensitivity check only [E11-s3].
- Using S11-B for neutrophil influx, or S07-A and S07-C for the regulatory-cell mechanism [S8, M21, M22].

**Decisions I rejected**

- *Straight to IND-enabling work.* The safety and translation gaps in sections 3.4 and 3.5 are too wide to commit GLP and GMP spend.
- *Stop.* The effect is large and consistent, it is the only route to an older-adult product on this platform, and each gap can be closed or failed within about a year.

## 8. If the committee drops it

**What would be dropped:**

- a single-dose intranasal adjuvant that took aged-mouse survival from 10% with PSLN-212 to 81% [E11];
- protection across subtypes including H5N1 [E2, E4, E18];
- protection within 2 to 3 days of dosing [E25, E18];
- protection that holds in animals with prior influenza exposure [E20];
- and, with it, the older-adult indication for the platform, because PSLN-212 alone does not protect aged animals.

**Why one would drop it:**

- the evidence is mouse-only, female-only and small;
- the antigen and the delivery route are not those of a licensed product;
- intranasal manganese in older adults has no safety data here;
- parts of the record need reconciling before they can be relied on.

These are gaps, not negative results. In aged animals PSLN-344 was never worse than its comparators on any efficacy readout in the file.

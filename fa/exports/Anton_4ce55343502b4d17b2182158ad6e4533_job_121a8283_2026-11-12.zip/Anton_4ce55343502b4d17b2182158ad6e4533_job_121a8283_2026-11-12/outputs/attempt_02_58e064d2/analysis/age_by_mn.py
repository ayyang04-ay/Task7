"""Blocks that contain all four of PSLN-212, PSLN-344 (aged) and PSLN-212(Y), PSLN-344(Y): two-way ANOVA, age x manganese interaction."""
import pandas as pd, numpy as np, warnings
import statsmodels.api as sm, statsmodels.formula.api as smf
from parse_blocks import OBS
warnings.filterwarnings('ignore')
rows = []
for blk, row, name in [('S01-A 16h', None, 'lung Ifnb1 16 h'), ('S01-E', '4', 'lung CD11b+ DC d4'), ('S01-F', None, 'lung cDC1 72 h'), ('S02-C', None, 'antigen+ DC in MLN 36 h'), ('S02-E', None, 'DC-driven OT-I proliferation')]:
    d = OBS[(OBS.block == blk) & OBS.group.isin(['PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)'])].copy()
    if row is not None: d = d[d.row_label == row]
    d['age'] = np.where(d.group.str.contains(r'\(Y\)'), 'young', 'aged'); d['mn'] = np.where(d.group.str.contains('344'), 'Mn', 'none')
    m = smf.ols('value ~ C(age)*C(mn)', data=d).fit(); a = sm.stats.anova_lm(m, typ=2)
    g = d.groupby(['age', 'mn']).value.mean()
    rows.append(dict(block=blk, readout=name, aged_212=g['aged', 'none'], aged_344=g['aged', 'Mn'], young_212=g['young', 'none'], young_344=g['young', 'Mn'],
                     gain_aged=g['aged', 'Mn'] - g['aged', 'none'], gain_young=g['young', 'Mn'] - g['young', 'none'],
                     ratio_aged=g['aged', 'Mn'] / g['aged', 'none'], ratio_young=g['young', 'Mn'] / g['young', 'none'], p_interaction=a.loc['C(age):C(mn)', 'PR(>F)']))
T = pd.DataFrame(rows); T.to_csv('age_by_mn_interaction.csv', index=False)
pd.set_option('display.width', 250)
print(T.to_string(float_format=lambda x: f'{x:.3g}'))

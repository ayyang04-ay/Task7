"""Search non-weight blocks for re-used numbers: same-position identity between blocks of the same shape,
and multiset overlap between any two (block, panel, group, time) vectors."""
import pandas as pd, numpy as np, itertools
from parse_blocks import tidy
v = tidy[(tidy.kind == 'value') & tidy.value.notna()].copy()
v['value'] = v.value.astype(float)
vec = {}
for k, d in v.groupby(['block', 'panel', 'group', 'time'], dropna=False, sort=False):
    vec[k] = list(d.value.values)
res = []
for a, b in itertools.combinations(vec, 2):
    A, B = vec[a], vec[b]
    if len(A) < 3 or len(B) < 3: continue
    # multiset overlap
    from collections import Counter
    ov = sum((Counter(A) & Counter(B)).values())
    pos = sum(1 for x, y in zip(A, B) if x == y) if len(A) == len(B) else np.nan
    if ov >= 2 and ov >= 0.4*min(len(A), len(B)):
        # ignore trivial low-cardinality titre vectors (HAI / neut dilution series) and 100s
        if a[0] in ('S03-C', 'S03-G', 'S03-D', 'S03-H') and b[0] in ('S03-C', 'S03-G', 'S03-D', 'S03-H'): continue
        res.append(dict(a=a, b=b, nA=len(A), nB=len(B), overlap=ov, same_pos=pos, A=A, B=B))
r = pd.DataFrame(res)
pd.set_option('display.width', 300); pd.set_option('display.max_colwidth', 120); pd.set_option('display.max_rows', 500)
print(len(r))
for _, x in r.iterrows():
    print(x.a, '<->', x.b, '| overlap', x.overlap, 'of', min(x.nA, x.nB), '| same-pos', x.same_pos)
    print('     ', x.A); print('     ', x.B)

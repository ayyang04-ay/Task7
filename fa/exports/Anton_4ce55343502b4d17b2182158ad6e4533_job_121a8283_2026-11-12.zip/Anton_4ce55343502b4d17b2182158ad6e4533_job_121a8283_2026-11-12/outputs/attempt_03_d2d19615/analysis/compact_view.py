import pandas as pd, numpy as np
S = pd.read_csv('block_group_summary.csv')
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 2000); pd.set_option('display.max_columns', 60)
S['stat'] = np.where(S.geomean.notna(), S.geomean, np.where(S.geomean_fold.notna(), S.geomean_fold, S['mean']))
S['key'] = S.block.astype(str) + ' | ' + S.panel.fillna('').astype(str) + ' | t=' + S.time.fillna('').astype(str)
order = list(dict.fromkeys(S.key))
P = S.pivot_table(index='key', columns='group', values='stat', sort=False)
P = P.loc[order]
cols_pref = ['Sham', 'PBS', 'Vaccine', 'CMP-204', 'PSLN-212', 'PSLN-R848', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-212(y)', 'PSLN-212Y', 'PSLN-344(Y)', 'PTX']
cols = [c for c in cols_pref if c in P.columns] + [c for c in P.columns if c not in cols_pref]
main = P[[c for c in cols_pref if c in P.columns]].dropna(how='all')
print(main.round(2).to_string())
print()
other = P[[c for c in P.columns if c not in cols_pref]].dropna(how='all')
for k, r in other.iterrows():
    print(k, {c: round(x, 2) for c, x in r.dropna().items()})

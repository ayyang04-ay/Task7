import numpy as np
from scipy import stats
def power_fisher(p1, p2, n1, n2, alpha=0.05):
    pw = 0.0
    for a in range(n1+1):
        pa = stats.binom.pmf(a, n1, p1)
        if pa < 1e-12: continue
        for b in range(n2+1):
            pb = stats.binom.pmf(b, n2, p2)
            if pb < 1e-12: continue
            if stats.fisher_exact([[a, n1-a], [b, n2-b]])[1] <= alpha:
                pw += pa*pb
    return pw
for (p1, p2) in [(0.84, 0.13), (0.80, 0.15), (0.80, 0.25), (0.75, 0.25), (0.70, 0.30), (0.67, 0.19)]:
    print(f'p1={p1}, p2={p2}:', {n: round(power_fisher(p1, p2, n, n), 3) for n in (7, 8, 10, 12, 15, 18, 20, 24)})
# probability that a 7-vs-7 experiment reaches p<0.05 under the pooled estimates
print('power of the historical n=7 design at pooled estimates (0.84 vs 0.13):', round(power_fisher(0.84, 0.13, 7, 7), 3))
# precision: CI half-width of a difference with n per arm
for n in (7, 12, 15, 20):
    se = np.sqrt(0.8*0.2/n + 0.15*0.85/n); print(n, 'approx 95% CI half-width for risk difference:', round(1.96*se, 2))

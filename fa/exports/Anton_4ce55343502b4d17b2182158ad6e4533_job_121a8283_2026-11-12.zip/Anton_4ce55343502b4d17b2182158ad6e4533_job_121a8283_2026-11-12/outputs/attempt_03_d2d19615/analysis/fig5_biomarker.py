import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
from parse_blocks import tidy, surv

def cp(k, n):
    lo = 0 if k == 0 else stats.beta.ppf(.025, k, n-k+1); hi = 1 if k == n else stats.beta.ppf(.975, k+1, n-k)
    return 100*lo, 100*hi
def sv(block, group):
    d = surv[(surv.block == block) & (surv.group == group)]; return int((d.event == 0).sum()), len(d)
def tot(lst):
    a = sum(x[0] for x in lst); n = sum(x[1] for x in lst); return a, n
T = pd.read_csv('aged_head_to_head_survival.csv'); U = T[T.block != 'S06-D']
aged344 = (int(U.s344.sum()), int(U.n344.sum())); aged212 = (int(U.s212.sum()), int(U.n212.sum()))
sham = (int(U.sSham.dropna().sum()), int(U.nSham.dropna().sum()))
yblocks = ['S03-I', 'S06-A', 'S06-B', 'S06-C', 'S06-E (rows 34-68)', 'S06-F (rows 34-68)', 'S06-G', 'S15-L', 'S15-N']
y212 = tot([sv(b, 'PSLN-212(Y)') for b in yblocks] + [sv(b, 'PSLN-212Y') for b in ('S09-B', 'S09-D', 'S09-F')])
y344 = tot([sv(b, 'PSLN-344Y') for b in ('S09-B', 'S09-D', 'S09-F')] + [sv('S13-E', 'PSLN-344(Y)')])
cmp_ = sv('S03-I', 'CMP-204')
def ifn(g):
    x = tidy[(tidy.block == 'S01-A') & (tidy.panel == '16h') & (tidy.group == g)].value.astype(float); return x.mean(), x.std(ddof=1)
pts = [('Sham, aged', 'Sham', sham, '0.45', 'x'), ('CMP-204, aged', 'CMP-204', cmp_, '#d6a24c', 'v'), ('PSLN-212, aged', 'PSLN-212', aged212, '#2166ac', 'o'),
       ('PSLN-344, aged', 'PSLN-344', aged344, '#b2182b', 'o'), ('PSLN-212, young', 'PSLN-212(Y)', y212, '#1b7837', '^'), ('PSLN-344, young', 'PSLN-344(Y)', y344, '#7fbf7b', '^')]
rows = []
fig, axes = plt.subplots(1, 2, figsize=(13.5, 5.6), gridspec_kw=dict(wspace=0.22))
ax = axes[0]
for lab, g, (a, n), c, mk in pts:
    m, s = ifn(g); lo, hi = cp(a, n); y = 100*a/n
    ax.errorbar(m, y, yerr=[[y-lo], [hi-y]], xerr=s, color=c, marker=mk, ms=9, capsize=3, lw=1.3, mfc=c if g != 'PSLN-212' else 'white', mew=1.8)
    dx, dy, ha = {'Sham': (1.5, 6, 'left'), 'CMP-204': (1.5, 6, 'left'), 'PSLN-212': (1.5, -11, 'left'), 'PSLN-344': (-1.5, -10, 'right'), 'PSLN-212(Y)': (-4.5, 5.5, 'right'), 'PSLN-344(Y)': (1.5, -9, 'left')}[g]
    ax.text(m + dx, y + dy, f'{lab}\n{a}/{n}', fontsize=8.6, color=c, ha=ha, va='center')
    rows.append(dict(group=lab, ifnb1_16h_mean=round(m, 2), ifnb1_sd=round(s, 2), survivors=a, n=n, surv_pct=round(y, 1)))
ax.axvspan(17, 36, color='0.92', zorder=0)
ax.text(26.5, 50, 'no challenged\ngroup in this range', ha='center', va='center', fontsize=8.5, color='0.4')
ax.set_xlabel('Lung Ifnb1 at 16 h, fold vs untreated (group mean ± SD, S01-A)'); ax.set_ylabel('Survival after lethal challenge, % (pooled; exact 95% CI)')
ax.set_xlim(-2, 62); ax.set_ylim(-5, 108)
ax.set_title('a  Early interferon response and survival, by group:\n   a step, not a slope', fontsize=10.5, loc='left')

ax = axes[1]
for g, lab, c, mk in (('Sham', 'Sham, aged', '0.45', 'x'), ('CMP-204', 'CMP-204, aged', '#d6a24c', 'v'), ('PSLN-212', 'PSLN-212, aged', '#2166ac', 'o'), ('PSLN-344', 'PSLN-344, aged', '#b2182b', 'o'), ('PSLN-212(Y)', 'PSLN-212, young', '#1b7837', '^')):
    x = tidy[(tidy.block == 'S03-C') & (tidy.group == g)].value.astype(float).values; x = np.where(x < 10, 5.0, x)
    a, n = sv('S03-I', g); y = 100*a/n; lo, hi = cp(a, n)
    jit = np.random.default_rng(4).uniform(-2.2, 2.2, len(x))
    ax.scatter(x, np.full(len(x), y) + jit, color=c, marker=mk, s=42, facecolor=c if g != 'PSLN-212' else 'white', linewidths=1.6, zorder=3)
    gm = 10**np.log10(x).mean()
    ax.plot([gm, gm], [y-5, y+5], color=c, lw=2)
    tx, ty = {'Sham': (gm, y+9), 'CMP-204': (gm, y+9), 'PSLN-212': (95, y-9), 'PSLN-344': (190, y-13), 'PSLN-212(Y)': (640, y-17)}[g]
    ax.text(tx, ty, f'{lab}\nsurvived {a}/{n}', fontsize=8.6, color=c, ha='center', va='center')
    rows.append(dict(group=lab + ' [S03-C/S03-I]', hai_gmt=round(gm, 1), survivors=a, n=n, surv_pct=round(y, 1)))
ax.axvline(40, color='k', ls='--', lw=1); ax.text(42, 62, 'HAI 1:40\n(conventional human\nthreshold)', fontsize=8.3, va='center')
ax.set_xscale('log'); ax.set_xticks([5, 10, 20, 40, 80, 160, 320, 640]); ax.set_xticklabels(['<10', '10', '20', '40', '80', '160', '320', '640'])
ax.set_xlabel('HAI titre to H1N1 on day 14, each animal (S03-C); bar = geometric mean'); ax.set_ylabel('Survival after matched H1N1 challenge, % (S03-I)')
ax.set_ylim(-16, 116); ax.set_xlim(3.5, 1000)
ax.set_title('b  HAI and survival against the matched virus: every PSLN-212\n   animal reached 1:40, none of that arm survived', fontsize=10.5, loc='left')
for a in axes:
    for s in ('top', 'right'): a.spines[s].set_visible(False)
fig.text(0.01, 0.005, 'Group-level association only: biomarker and survival were measured in different animals. Panel a pools all challenge experiments for each group (aged: Table 1; young: Table 1 young arms plus S09-B/D/F and S13-E).\n'
         'Panel b: S03-I as printed; under the labels of the paired weight block the PSLN-212 arm is 3/7 (D02).', fontsize=7.8, color='0.3')
fig.subplots_adjust(left=0.065, right=0.985, top=0.88, bottom=0.17)
fig.savefig('/tmp/outputs/figures/fig5_biomarker_vs_survival.png', dpi=170)
pd.DataFrame(rows).to_csv('biomarker_vs_survival_groups.csv', index=False)
print(pd.DataFrame(rows).to_string())

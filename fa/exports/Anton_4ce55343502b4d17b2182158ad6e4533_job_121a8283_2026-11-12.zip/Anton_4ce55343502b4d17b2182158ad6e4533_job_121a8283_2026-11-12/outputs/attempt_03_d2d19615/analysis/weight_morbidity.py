import pandas as pd, numpy as np, warnings
from scipy import stats
from parse_blocks import tidy
warnings.filterwarnings('ignore')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
w = tidy[(tidy.kind == 'weight') & (tidy.block != 'S08-D')].copy(); w['time'] = w.time.astype(float)

recs = []
for (blk, grp, rep), d in w.groupby(['block', 'group', 'rep'], sort=False):
    s = d.set_index('time').value.astype(float)
    obs = s.dropna()
    vals = list(obs.values)
    # frozen tail detection
    k = 1
    while k < len(vals) and vals[-1-k] == vals[-1]: k += 1
    blank = len(obs) < len(s)
    frozen_low = (not blank) and k >= 2 and vals[-1] < 90
    status = 'dead_blank' if blank else ('dead_frozen' if frozen_low else 'survivor')
    recs.append(dict(block=blk, group=grp, rep=rep, status=status, nadir=obs.min(), nadir_day=obs.idxmin(), d14=s.get(14.0, np.nan) if status == 'survivor' else np.nan))
A = pd.DataFrame(recs)
A.to_csv('weight_animal_morbidity.csv', index=False)
G = A.groupby(['block', 'group'], sort=False).apply(lambda d: pd.Series(dict(
    n=len(d), implied_deaths=int((d.status != 'survivor').sum()), survivors=int((d.status == 'survivor').sum()),
    nadir_all_mean=d.nadir.mean(), nadir_surv_mean=d[d.status == 'survivor'].nadir.mean(), nadir_surv_min=d[d.status == 'survivor'].nadir.min(),
    d14_surv_mean=d[d.status == 'survivor'].d14.mean()))).reset_index()
print(G.round(1).to_string())
G.to_csv('weight_group_morbidity.csv', index=False)

# pooled: survivors' nadir, aged PSLN-344 vs young PSLN-212(Y), per block with both
print('\nSurvivor nadir (maximum weight loss) aged PSLN-344 vs young PSLN-212(Y):')
rows = []
for blk in A.block.unique():
    a = A[(A.block == blk) & (A.group == 'PSLN-344') & (A.status == 'survivor')].nadir.values
    b = A[(A.block == blk) & (A.group == 'PSLN-212(Y)') & (A.status == 'survivor')].nadir.values
    if len(a) > 1 and len(b) > 1:
        rows.append((blk, len(a), a.mean(), len(b), b.mean(), stats.ttest_ind(a, b, equal_var=False).pvalue))
        print(f'  {blk}: PSLN-344 survivors n={len(a)} mean nadir {a.mean():.1f}%  | young PSLN-212 n={len(b)} mean nadir {b.mean():.1f}% | Welch p={stats.ttest_ind(a,b,equal_var=False).pvalue:.3f}')
r = pd.DataFrame(rows, columns=['blk', 'n1', 'm1', 'n2', 'm2', 'p'])
print('  across blocks: mean of block means: PSLN-344 %.1f%% vs Y %.1f%%' % (r.m1.mean(), r.m2.mean()))

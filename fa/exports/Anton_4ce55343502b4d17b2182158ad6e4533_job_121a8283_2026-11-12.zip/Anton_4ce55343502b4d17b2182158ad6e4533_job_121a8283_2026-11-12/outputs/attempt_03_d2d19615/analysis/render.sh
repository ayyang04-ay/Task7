#!/bin/bash
# Regenerates the memo, ledger and integrity log from the workbook, then renders DOCX and HTML.
set -e
cd "$(dirname "$0")"
micromamba run -n chem python parse_blocks.py
micromamba run -n chem python survival_analysis.py > /dev/null
micromamba run -n chem python block_stats.py > /dev/null
micromamba run -n chem python contrasts.py > /dev/null
micromamba run -n chem python weight_audit.py > /dev/null 2>&1
micromamba run -n chem python weight_morbidity.py > /dev/null
micromamba run -n chem python pooled_survival.py > /dev/null
for f in fig1_survival.py fig2_innate.py fig3_restoration.py fig4_safety.py fig5_biomarker.py fig6_integrity.py fig7_km.py; do micromamba run -n chem python $f > /dev/null; done
micromamba run -n chem python memo_text3.py
micromamba run -n chem python verify_ledger.py
RD="markdown-tex_math_dollars-citations-subscript-superscript-strikeout-smart-yaml_metadata_block"
cd ..
/opt/conda/envs/renv/bin/pandoc PSLN-344_recommendation.md -f $RD -t docx --reference-doc=analysis/reference_landscape.docx -o PSLN-344_recommendation.docx
/opt/conda/envs/renv/bin/pandoc PSLN-344_recommendation.md -f $RD -t html5 --standalone --embed-resources --metadata pagetitle="PSLN-344 - recommendation for the portfolio review" --css analysis/memo.css -o PSLN-344_recommendation.html
/opt/conda/envs/renv/bin/pandoc PSLN-344_decision_brief.md -f $RD -t docx --reference-doc=analysis/reference_landscape.docx -o PSLN-344_decision_brief.docx
echo rendered

import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
S = pd.read_csv('block_group_summary.csv')
def val(blk, grp, panel=None, time=None, geo=False):
    d = S[(S.block == blk) & (S.group == grp)]
    if panel is not None: d = d[d.panel.fillna('') == panel]
    if time is not None: d = d[d.time.astype(str) == str(time)]
    assert len(d) == 1, (blk, grp, panel, time, len(d))
    r = d.iloc[0]
    return r.geomean if geo else r['mean']

# (label, block, panel, time, geometric?, stage)
items = [
 ('Lung Ifnb1, 16 h  [S01-A]', 'S01-A', '16h', None, False, 'Innate trigger'),
 ('Lung monocytes, day 4  [S01-D]', 'S01-D', None, '4', False, 'Innate trigger'),
 ('Lung CD11b+ DC, day 4  [S01-E]', 'S01-E', None, '4', False, 'Dendritic cells'),
 ('Lung cDC1, 72 h  [S01-F]', 'S01-F', None, None, False, 'Dendritic cells'),
 ('Lung CCR7+ migratory DC, 72 h  [S02-A]', 'S02-A', None, None, False, 'Dendritic cells'),
 ('MLN antigen-bearing DC, 36 h  [S02-C]', 'S02-C', None, None, False, 'Dendritic cells'),
 ('MLN DC priming of OT-I CD8  [S02-E]', 'S02-E', None, None, False, 'Dendritic cells'),
 ('MLN DC CD40+, day 3  [S02-D]', 'S02-D CD40', None, None, False, 'Dendritic cells'),
 ('MLN DC CD86+, day 3  [S02-D]', 'S02-D CD86', None, None, False, 'Dendritic cells'),
 ('GC B cells, day 7  [S03-K]', 'S03-K', None, None, False, 'B-cell help'),
 ('ICOS+ Tfh, day 7  [S04-A]', 'S04-A', 'ICOS+CXCR5+PD1+', None, False, 'B-cell help'),
 ('Serum IgG to H1N1, day 14 (GMT)  [S03-A]', 'S03-A', None, None, True, 'Antibody'),
 ('HAI to H1N1, day 14 (GMT)  [S03-C]', 'S03-C', None, None, True, 'Antibody'),
 ('Neutralising titre to H1N1 (GMT)  [S03-D]', 'S03-D', None, None, True, 'Antibody'),
 ('Serum IgG to H3N2, day 14 (GMT)  [S03-E]', 'S03-E', None, None, True, 'Antibody'),
 ('HAI to H3N2, day 14 (GMT)  [S03-G]', 'S03-G', None, None, True, 'Antibody'),
 ('Lung Ki-67+ CD8, day 3  [S05-D]', 'S05-D', None, None, False, 'CD8 T cells'),
 ('Lung GZMB+ CD8, day 3  [S05-E]', 'S05-E', None, None, False, 'CD8 T cells'),
 ('H5N1-reactive IFN-γ+ CD8, day 14  [S05-F]', 'S05-F', None, None, False, 'CD8 T cells'),
 ('H5N1-reactive IFN-γ+ CD8, day 60  [S05-G]', 'S05-G', None, None, False, 'CD8 T cells'),
 ('Lung resident-memory CD8, day 25  [S05-I]', 'S05-I', None, None, False, 'CD8 T cells'),
]
rows = []
for lab, blk, panel, tm, geo, stage in items:
    y = val(blk, 'PSLN-212(Y)', panel, tm, geo); a = val(blk, 'PSLN-212', panel, tm, geo); b = val(blk, 'PSLN-344', panel, tm, geo)
    rows.append(dict(label=lab, stage=stage, young=y, p212=a, p344=b, pct212=100*a/y, pct344=100*b/y, mn_fold=b/a, block=blk))
# survival (pooled over the 9 experiments that carry a young arm, duplicate S06-D removed)
T = pd.read_csv('aged_head_to_head_survival.csv'); U = T[(T.block != 'S06-D') & T.sY.notna()]
sy = U.sY.sum()/U.nY.sum(); s2 = U.s212.sum()/U.n212.sum(); s3 = U.s344.sum()/U.n344.sum()
rows.append(dict(label='Survival after lethal challenge (9 expts)  [S03-I, S06, S15]', stage='Outcome', young=sy, p212=s2, p344=s3, pct212=100*s2/sy, pct344=100*s3/sy, mn_fold=s3/s2, block='pooled'))
R = pd.DataFrame(rows); R.to_csv('restoration_index.csv', index=False)
print(R.round(2).to_string())

fig, ax = plt.subplots(figsize=(11.5, 8.6))
y = np.arange(len(R))[::-1]
stage_colors = {'Innate trigger': '#f7f7f7', 'Dendritic cells': '#efefef', 'B-cell help': '#f7f7f7', 'Antibody': '#efefef', 'CD8 T cells': '#f7f7f7', 'Outcome': '#e6e6e6'}
for st in R.stage.unique():
    idx = y[R.stage == st]
    ax.axhspan(idx.min() - 0.5, idx.max() + 0.5, color=stage_colors[st], zorder=0)
    ax.text(133, idx.mean(), st, va='center', ha='left', fontsize=9, color='0.35', rotation=0)
ax.hlines(y, R.pct212, R.pct344, color='0.6', lw=1.5, zorder=1)
ax.scatter(R.pct212, y, marker='o', facecolor='white', edgecolor='#2166ac', s=80, lw=1.9, zorder=3, label='PSLN-212, aged (no Mn)')
ax.scatter(R.pct344, y, marker='o', color='#b2182b', s=80, zorder=4, label='PSLN-344, aged (Mn)')
ax.axvline(100, color='#1b7837', lw=1.6, ls='-', zorder=2)
ax.text(101.5, len(R) - 0.25, '100% = young-adult benchmark\n(PSLN-212 in 7–8-week mice)', color='#1b7837', ha='left', va='bottom', fontsize=8.5)
for yi, r in zip(y, R.itertuples()):
    ax.text(max(r.pct344, r.pct212) + 2.5, yi, f'{r.pct344:.0f}%', va='center', fontsize=8.3, color='#b2182b', bbox=dict(facecolor='white', edgecolor='none', pad=0.6, alpha=0.85), zorder=6)
ax.set_yticks(y); ax.set_yticklabels(R.label, fontsize=9)
ax.set_xlim(0, 131); ax.set_ylim(-0.7, len(R) + 1.6)
ax.set_xlabel('Group value as % of the young-adult benchmark measured in the same block')
ax.legend(loc='lower left', bbox_to_anchor=(0.0, 0.945), ncol=2, frameon=False, fontsize=9.5)
for s in ('top', 'right'): ax.spines[s].set_visible(False)
fig.suptitle('Adding Mn closes most of the age gap at every step — except DC co-stimulation (CD40/CD86)', fontsize=12.5, x=0.01, ha='left', y=0.985)
fig.text(0.01, 0.006, 'Arithmetic mean of per-animal values (n = 5 per group), geometric mean for titres (HAI <10 set to 5). Survival pooled over the nine experiments with a young arm.\n'
         'Source cells and reductions: evidence ledger. Block IDs in brackets.', fontsize=7.8, color='0.3')
fig.subplots_adjust(left=0.335, right=0.86, top=0.945, bottom=0.105)
fig.savefig('/tmp/outputs/figures/fig3_restoration_vs_young.png', dpi=170)

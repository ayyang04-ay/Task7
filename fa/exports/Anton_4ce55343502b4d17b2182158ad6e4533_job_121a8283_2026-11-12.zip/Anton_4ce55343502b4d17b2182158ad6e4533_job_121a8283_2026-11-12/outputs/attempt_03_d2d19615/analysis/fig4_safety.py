import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from parse_blocks import tidy

fig = plt.figure(figsize=(16.5, 9.6))
gs = fig.add_gridspec(2, 3, height_ratios=[1, 1.02], width_ratios=[1.1, 1, 1], hspace=0.42, wspace=0.27)
# (a) weights after vaccination
ax = fig.add_subplot(gs[0, 0])
w = tidy[tidy.block == 'S08-D'].copy(); w['time'] = w.time.astype(int); w['value'] = w.value.astype(float)
sty = {'Vaccine': ('0.35', 'Vaccine alone'), 'PSLN-212': ('#2166ac', 'PSLN-212'), 'PSLN-344': ('#b2182b', 'PSLN-344'), 'CMP-204': ('0.65', 'CMP-204'), 'PSLN-212(Y)': ('#1b7837', 'PSLN-212, young'), 'PSLN-212/R848': ('#d6a24c', 'PSLN-212/R848')}
for g, (c, lab) in sty.items():
    x = w[w.group == g]
    m = x.groupby('time').value.agg(['mean', 'std'])
    ax.errorbar(m.index + {'Vaccine': -0.15, 'PSLN-212': -0.05, 'PSLN-344': 0.05, 'CMP-204': 0.15, 'PSLN-212(Y)': -0.25, 'PSLN-212/R848': 0.25}[g], m['mean'], yerr=m['std'], color=c, marker='o', ms=4, capsize=2, lw=2 if g in ('PSLN-344', 'PSLN-212/R848') else 1.2, label=lab)
ax.axhline(100, color='0.8', lw=0.8, zorder=0)
ax.annotate('one PSLN-212/R848 animal (88.3% at day 8)\nhas no day-10 value (cell W26 blank)', xy=(7.95, 88.4), xytext=(3.0, 85.6), fontsize=7.8, color='#8c6510', arrowprops=dict(arrowstyle='->', color='#8c6510', lw=0.8))
ax.set_xlabel('Days after intranasal vaccine + adjuvant (no challenge)'); ax.set_ylabel('Body weight (% of day 0)')
ax.set_ylim(84, 103); ax.legend(fontsize=7.6, frameon=False, ncol=1, loc='lower left', bbox_to_anchor=(-0.01, 0.13), handlelength=1.4)
ax.set_title('a  Reactogenicity by weight: PSLN-344 dips ≈3.6% and recovers by\n   day 10; the R848 combination does not recover  [S08-D, n=5]', fontsize=10, loc='left')

# (b) CNS transcripts
ax = fig.add_subplot(gs[0, 1])
c = tidy[tidy.block == 'S10-A'].copy(); c['value'] = c.value.astype(float)
groups = ['PBS', 'Sham', 'PSLN-344', 'CT']; cols = {'PBS': '0.6', 'Sham': '0.4', 'PSLN-344': '#b2182b', 'CT': '#542788'}
rng = np.random.default_rng(1)
for i, an in enumerate(['Ifnb1', 'Tnf', 'Isg15']):
    for j, g in enumerate(groups):
        x = c[(c.panel == an) & (c.group == g)].value.values
        xx = i + (j - 1.5) * 0.2
        ax.bar(xx, x.mean(), width=0.17, color=cols[g], alpha=0.8, label=({'PBS': 'PBS', 'Sham': 'Sham (vaccine + empty liposome)', 'PSLN-344': 'Vaccine + PSLN-344', 'CT': 'Vaccine + cholera toxin (positive control)'}[g] if i == 0 else None))
        ax.scatter(xx + rng.uniform(-0.04, 0.04, len(x)), x, s=12, color='k', zorder=3, alpha=0.7)
ax.axhline(1, color='0.7', lw=0.8, ls=':')
ax.set_xticks(range(3)); ax.set_xticklabels(['Ifnb1', 'Tnf', 'Isg15'], style='italic')
ax.set_ylabel('CNS transcript, 36 h (fold vs untreated)')
ax.legend(fontsize=7.8, frameon=False, loc='upper right')
ax.set_title('b  No cholera-toxin-type CNS signal at 36 h; a ≤2-fold\n   Tnf rise cannot be excluded  [S10-A, n=5, aged]', fontsize=10, loc='left')

# (c) monocyte kinetics (resolution)
ax = fig.add_subplot(gs[0, 2])
d = tidy[tidy.block == 'S01-D'].copy(); d['value'] = d.value.astype(float); d['time'] = d.time.astype(int)
for g, col, lab in (('Sham', '0.55', 'Sham'), ('PSLN-212', '#2166ac', 'PSLN-212'), ('PSLN-344', '#b2182b', 'PSLN-344'), ('PSLN-212(Y)', '#1b7837', 'PSLN-212, young')):
    m = d[d.group == g].groupby('time').value.agg(['mean', 'std'])
    ax.errorbar(m.index, m['mean'], yerr=m['std'], color=col, marker='o', ms=4, capsize=2, lw=1.6, label=lab)
ax.set_xlabel('Days after immunisation'); ax.set_ylabel('Lung monocytes (%)'); ax.legend(fontsize=8, frameon=False)
ax.set_title('c  Lung monocyte influx peaks at day 4; with PSLN-344 in\n   aged mice it is still ≈2× baseline at day 8  [S01-D, n=5]', fontsize=10, loc='left')

# (d) cytokine heat map
ax = fig.add_subplot(gs[1, :])
s9 = tidy[tidy.block == 'S09-A'].copy(); s9['value'] = s9.value.astype(float)
s9['panelside'] = s9.panel.str.split('|').str[0]; s9['analyte'] = s9.panel.str.split('|').str[1]
gorder = ['PBS', 'CMP-204', 'PSLN-R848', 'PSLN-212', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(y)']
glabels = ['PBS', 'CMP-204', 'PSLN-R848', 'PSLN-212', 'PSLN-212\n/R848', 'PSLN-344', 'PSLN-212\nyoung']
aorder = ['Ifnb1', 'Ccl2', 'Ccl3', 'Ccl5', 'Il6', 'Tnf', 'Il10']
M = []
for side in ('cols A-U', 'cols X-AS'):
    m = s9[s9.panelside == side].groupby(['analyte', 'group']).value.mean().unstack()[gorder].loc[aorder]
    M.append(m)
big = np.hstack([M[0].values, np.full((len(aorder), 1), np.nan), M[1].values])
im = ax.imshow(big, cmap='RdBu_r', vmin=-3.2, vmax=3.2, aspect='auto')
for i in range(big.shape[0]):
    for j in range(big.shape[1]):
        if not np.isnan(big[i, j]):
            v = 10 ** big[i, j]
            ax.text(j, i, (f'{v:.0f}×' if v >= 10 else f'{v:.1f}×'), ha='center', va='center', fontsize=8.6, color='white' if abs(big[i, j]) > 1.9 else 'k')
ax.set_xticks(list(range(7)) + list(range(8, 15))); ax.set_xticklabels(glabels + glabels, fontsize=8.6)
ax.set_yticks(range(len(aorder))); ax.set_yticklabels(aorder, style='italic')
for xx in (5, 13):
    ax.add_patch(plt.Rectangle((xx - 0.5, -0.5), 1, len(aorder), fill=False, edgecolor='k', lw=1.6))
ax.text(3, -0.68, 'Panel at columns A–U  (printed "16 h"; Ifnb1 row matches S01-A 16 h)', ha='center', fontsize=9.3)
ax.text(11, -0.68, 'Panel at columns X–AS  (also printed "16 h"; Ifnb1 row matches S01-A 72 h → treated as 72 h)', ha='center', fontsize=9.3)
cb = fig.colorbar(im, ax=ax, fraction=0.018, pad=0.01); cb.set_label('log10 fold vs untreated', fontsize=8.5)
ax.set_title('d  Lung cytokine/chemokine transcripts (geometric-mean fold, n=3): PSLN-344 gives aged lungs the young chemokine pattern, with more Tnf/Il10 that is slower to resolve;\n   R848-containing particles are Tnf/Il10-dominated  [S09-A; values stored as log10 and back-transformed]', fontsize=10, loc='left', pad=30)
for a in fig.axes[:3]:
    for sp in ('top', 'right'): a.spines[sp].set_visible(False)
fig.subplots_adjust(left=0.05, right=0.985, top=0.93, bottom=0.06)
fig.savefig('/tmp/outputs/figures/fig4_safety_reactogenicity.png', dpi=170)

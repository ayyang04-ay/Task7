import pandas as pd, numpy as np, re, openpyxl
from parse_blocks import tidy, surv, wb
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_columns', 50)

# stated n, exactly as printed in the block label cells
labels = {}
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, str) and re.match(r'^S\d\d-[A-Z]', c.value.strip()):
                labels.setdefault(ws.title, []).append((c.coordinate, c.value))
for s, l in labels.items():
    print(s, l)

print('\n=== value blocks: observed non-empty count per group (min..max across timepoints) ===')
t = tidy.copy()
t['has'] = t.value.notna()
g = t.groupby(['block', 'panel', 'group', 'time'], dropna=False, sort=False).has.sum().reset_index()
s = g.groupby(['block', 'panel', 'group'], sort=False).has.agg(['min', 'max', 'count']).reset_index()
print(s.to_string())

print('\n=== survival blocks ===')
sv = surv.copy()
x = sv.groupby(['block', 'group'], sort=False).agg(n=('event', 'size'), deaths=('event', 'sum'),
        n_missing_time=('time', lambda v: v.isna().sum()),
        death_days=('time', lambda v: list(v))).reset_index()
print(x.to_string())

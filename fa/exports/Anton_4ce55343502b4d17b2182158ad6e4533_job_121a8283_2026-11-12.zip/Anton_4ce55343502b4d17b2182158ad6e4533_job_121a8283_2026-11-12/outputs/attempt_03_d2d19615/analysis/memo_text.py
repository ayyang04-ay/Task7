exec(open('build_memo.py').read())
M = []
def add(s): M.append(s.strip('\n'))

# ---------------- frequently used numbers (each call also writes a ledger row) ----------------
ifn344 = A('S01-A', 'PSLN-344', '16h'); ifn212 = A('S01-A', 'PSLN-212', '16h'); ifnY = A('S01-A', 'PSLN-212(Y)', '16h'); ifn344Y = A('S01-A', 'PSLN-344(Y)', '16h')
ifnSham = A('S01-A', 'Sham', '16h'); ifnCMP = A('S01-A', 'CMP-204', '16h'); ifnR = A('S01-A', 'PSLN-R848', '16h'); ifn212R = A('S01-A', 'PSLN-212/R848', '16h')
ifn_ratio = CT('S01-A', 'PSLN-344', 'PSLN-212', '16h'); ifn_vsY = CT('S01-A', 'PSLN-344', 'PSLN-212(Y)', '16h', dec=2)
ifn72_344 = A('S01-A', 'PSLN-344', '72h'); ifn72_212 = A('S01-A', 'PSLN-212', '72h'); ifn72_Y = A('S01-A', 'PSLN-212(Y)', '72h')
e344, e212, ecmp = HF['PSLN-344'], HF['PSLN-212'], HF['CMP-204']
d212_40 = A('S08-A', 'PSLN-212', time=40); d344_10 = A('S08-A', 'PSLN-344', time=10); d344_20 = A('S08-A', 'PSLN-344', time=20); d344_40 = A('S08-A', 'PSLN-344', time=40); d344_5 = A('S08-A', 'PSLN-344', time=5); d212_20 = A('S08-A', 'PSLN-212', time=20)
gm16 = A('S02-F', 'PSLN-344', time='16h'); gm36 = A('S02-F', 'PSLN-344', time='36h'); gm72 = A('S02-F', 'PSLN-344', time='72h')
gm16b = A('S02-F', 'PSLN-212', time='16h'); gm36b = A('S02-F', 'PSLN-212', time='36h'); gm72b = A('S02-F', 'PSLN-212', time='72h')
ee344 = A('S08-B', 'PSLN-344'); ee344sd = SDv('S08-B', 'PSLN-344'); ee212 = A('S08-B', 'PSLN-212'); ee212sd = SDv('S08-B', 'PSLN-212'); ee_p = PV('S08-B', 'PSLN-212', 'PSLN-344', kind='welch')
ee344min = MINv('S08-B', 'PSLN-344')
imp = {k: SV(b, k) for b, k in [('S06-E (rows 71-105)', 'Naïve+PSLN-344'), ('S06-E (rows 71-105)', 'Imprinting+PSLN-344'), ('S06-E (rows 71-105)', 'Naïve+PSLN-212'), ('S06-E (rows 71-105)', 'Imprinting+PSLN-212')]}
impP = {k: SV('S06-F (rows 71-105)', k) for k in ['Naïve+PSLN-344', 'Imprinting+PSLN-344', 'Naïve+PSLN-212', 'Imprinting+PSLN-212']}
cnsI = CT('S10-A', 'PSLN-344', 'PBS', panel='Ifnb1', dec=2); cnsT = CT('S10-A', 'PSLN-344', 'PBS', panel='Tnf', dec=2); cnsG = CT('S10-A', 'PSLN-344', 'PBS', panel='Isg15', dec=2)
cnsTs = CT('S10-A', 'PSLN-344', 'Sham', panel='Tnf', dec=2)
ctI = CT('S10-A', 'CT', 'PBS', panel='Ifnb1', ci=False); ctT = CT('S10-A', 'CT', 'PBS', panel='Tnf', ci=False); ctG = CT('S10-A', 'CT', 'PBS', panel='Isg15', ci=False)
cnsTp = PV('S10-A', 'PSLN-344', 'PBS', panel='Tnf', kind='tukey'); cnsTw = PV('S10-A', 'PSLN-344', 'PBS', panel='Tnf', kind='welch')
rest = RI[~RI.block.isin(['S02-D CD40', 'S02-D CD86', 'pooled'])]
rest_lo, rest_hi = rest.pct344.min(), rest.pct344.max()
q = lambda d, g: f'{d[g]:.2f}'

# =============================================================================================
add(f"""
# PSLN-344 — recommendation for the portfolio review

*Mn-complexed, pulmonary-surfactant-biomimetic liposomal STING agonist; intranasal adjuvant for inactivated influenza A vaccine in older adults.*

**Basis.** `adjuvant_program_dataset.xlsx` (15 sheets, 101 labelled blocks, 6,819 numeric cells; last modified 3 Sep 2026) and `adjuvant_program_annotation.pdf` (19 pages, 15 Sep 2026). Every numeric cell was parsed and is accounted for. A number in this memo is followed by the block it comes from in square brackets; the exact cells and the reduction applied are in `evidence_ledger.csv`, sorted by block (Appendix B). Where the workbook disagrees with itself, the printed value is the primary analysis and the alternative is shown alongside it. Statements that draw on knowledge from outside the file are marked *[external]*.

**Names.** PSLN-344 is the asset: the liposome carrying the cyclic dinucleotide CDN-1807, with Mn²⁺. PSLN-212 is the same particle without Mn. CMP-204 carries cGAMP in place of CDN-1807. PSLN-R848 and PSLN-212/R848 carry the TLR7/8 agonist R848, alone or with CDN-1807. "Sham" is vaccine with empty liposome. "Young" mice are 7–8 weeks old; "aged" mice are 20 months or older unless stated.

## 1. Recommendation

**Advance PSLN-344 — conditionally.** Approve a gated confirmation-and-de-risking stage now (mouse, ferret and human-cell work; no GLP toxicology, no GMP scale-up). Commit to IND-enabling work only when the gates in §4.4 are met. Keep the present data file inside the company until the source-data audit (Gate 0) is closed.

### Answers at a glance

| Your question | Short answer | Detail |
|---|---|---|
| Do we advance? | **Yes, conditionally.** In aged mice (14 months old in four comparisons, 20 months or older in the rest) one intranasal dose of vaccine with PSLN-344 left {P_all['a']}/{P_all['n1']} animals alive after lethal challenge, against {P_all['b']}/{P_all['n2']} with PSLN-212, the same particle without manganese: a difference of {rd(P_all)} across 14 head-to-head comparisons, all 14 in the same direction. Taking the least favourable reading of every disputed count still gives {rd(P_worst)}. | §2, §3 |
| What is actually driving the protection? | **The manganese, acting through an antigen-dependent adaptive response.** Mn lifts the ceiling of the aged lung's interferon-β response to the young-adult level and switches on GM-CSF; monocyte-derived dendritic cells and lung CD8 T cells follow. Adjuvant without antigen protects {SV('S15-H', '3d PSLN-344')}, so this is not an innate antiviral effect. Protection crosses subtypes and is present 2–3 days after dosing, so HAI antibody cannot be the driver. The link from CD8 T cells or dendritic cells to survival is inferred: no experiment removes them and then challenges. | §4.1 |
| Is there a biomarker of efficacy worth carrying forward? | **Yes, one: the early interferon-β → GM-CSF → CCL2/monocyte → dendritic-cell response.** It is the step that fails in aged animals, the step Mn repairs, it is dose-responsive, and its middle links have intervention support. | §4.2 |
| Could it go into patients, and in what role? | **Not as measured; yes after bridging.** Every read-out of that response in the file is lung or lymph-node tissue from terminal animals. The patient version is nasal-lining-fluid protein and nasal or blood transcripts at 16–72 h. **Role: pharmacodynamic marker for proof of mechanism and dose selection in Phase 1.** It is not a surrogate for protection. HAI is not one either for this product. | §4.2 |
| What must the next studies establish? | Six things, in order: the file is sound; the effect replicates blinded and needs both Mn and the cyclic dinucleotide; what mediates survival; the lowest effective dose and its margin; airway Mn is safe; it works with a licensed antigen, by a human-usable route, in a second species and on human aged cells. Endpoints, populations, comparators, read-outs and timing for each are in §4.3. | §4.3, §4.4 |
| What did I consider and rule out? | A dose or potency explanation; innate-only protection; HAI as the driver; a one-strain artefact; dependence on prior influenza exposure; an artefact of the data defects; the R848 and cGAMP alternatives; an unconditional go; a no-go. | §5 |

**How sure am I?** High that the recorded effect is large and depends on the Mn: it survives every re-reading of the file. Moderate that CD8 T cells primed by monocyte-derived dendritic cells are what mediates it: everything is consistent with that and nothing tests it. Unknown for translation to people and for the safety of Mn given by the airway: the file has no data on either.

### Why yes

1. **The effect is large and it repeats.** {P_all['a']}/{P_all['n1']} ({P_all['pa']:.0f}%) vs {P_all['b']}/{P_all['n2']} ({P_all['pb']:.0f}%) survivors; vaccine with empty liposome protected {sh_all[0]}/{sh_all[1]} [sheets S03, S06, S15; Table 1].
2. **It is attributable to the manganese, and more of the Mn-free particle cannot substitute.** PSLN-344 restores the 16-hour lung *Ifnb1* response of aged mice to the young-adult level ({ifn344}-fold vs {ifnY}-fold; PSLN-212 in aged mice {ifn212}-fold) [S01-A]. Across dose, PSLN-212 plateaus near {e212['emax']:.0f}-fold and PSLN-344 near {e344['emax']:.0f}-fold at a similar half-maximal dose ({e212['ed50']:.1f} vs {e344['ed50']:.1f} µg) [S08-A].
3. **The profile fits the indication.** One needle-free dose; protection across subtypes (H3N2 vaccine → H1N1 virus; H1N1+H3N2 → H5N1; H1N1 → H3N2); present within 2–3 days; still present at day 60 ({pl(P_d60)}); reproduced in C57BL/6 and outbred Swiss Webster mice ({pl(P_str)}); indifferent to prior influenza infection ({imp['Naïve+PSLN-344']} unprimed, {imp['Imprinting+PSLN-344']} imprinted) [S06, S15].
4. **The biology is coherent and measurable.** Interferon-β, monocyte influx, dendritic-cell migration and priming, germinal-centre help, antibody and CD8 responses each reach {rest_lo:.0f}–{rest_hi:.0f}% of the young-adult benchmark with PSLN-344 (Table 2, Figure 3).
5. **Nothing in the tolerability data argues for stopping.** Mean lowest body weight after dosing {n344[0]:.1f}% of baseline, back to {d10_344[0]:.1f}% by day 10 [S08-D]; *Ifnb1* back to {ifn72_344}-fold by 72 h [S01-A]; no cholera-toxin-type signal in the central nervous system at 36 h [S10-A].

### Why only conditionally

1. **The file has integrity problems.** Twenty-two issues are logged in Appendix C, from outright defects to missing documentation: one survival table duplicated row for row, group labels that conflict between paired blocks, rotated column headers, re-used body-weight values. None overturns the result in any sensitivity analysis (§2.1), but the file is not fit for a partner's or regulator's data room as it stands.
2. **The driver of protection is inferred, not shown.** No depletion, blockade or transfer experiment has survival as its read-out.
3. **Translation is untested.** Mice only; one efficacy dose (20 µg); formalin-inactivated whole-virion antigen; dosing that reaches the deep lung; no comparator that older adults actually receive; no virus titres, no mucosal IgA, no histopathology.
4. **The safety package is thin for an airway product that contains manganese.** Five animals per group, body weight and three central-nervous-system transcripts; no Mn measurement anywhere; Mn content per dose is not in the file.

### What approval commits us to

- **Gate 0, about 6 weeks, no animals:** reconcile the 22 logged issues against raw records.
- **Gate 1, about 9–10 months:** blinded replication with component controls; the experiment that shows what mediates survival; dose–response for protection with the biomarker read in the same animals; pilot airway-Mn safety.
- **Gate 2, about 15 months:** licensed antigen, human-usable route, ferret, human aged-donor cells. IND-enabling spend starts only after this.
- **Stop rules** are pre-set (§4.4). Durations and gate thresholds are my proposals, not data.
""")

# =============================================================================================
add(f"""
## 2. The evidence for advancing

### 2.1 Survival after lethal challenge

Table 1 lists every experiment in the file in which aged or middle-aged animals received vaccine with PSLN-344 or with PSLN-212 and were then challenged. "Sham" is vaccine with empty liposome. Each count is the number of rows whose event flag is 0 at the end of observation over all rows printed for the group.

**Table 1. Survivors / animals, head-to-head comparisons in aged and middle-aged mice**

{TABLE1}

n.s. = not stated in the annotation. Notes: **a** the paired weight block S13-F carries different group labels; under its labels the PSLN-212 arm is 3/7, not 0/7 (Appendix C, D02). **b** Stated n is 9, ten rows are present, one PSLN-344 row has no day; the paired weight block S13-G labels the comparator arms differently (D03). **c** S06-C is identical row for row to S06-D, which is annotated as the day-3 version of the same experiment; it is counted once and S06-D is omitted (D01). **d** In the same three experiments {unt_d}/{unt_n} untreated, unchallenged 20-month animals died during the observation window (D10). **e** Animals were 10 months old when infected with PR8 or given saline and were vaccinated 4 months later; imprinted animals are survivors of a 1× mLD50 infection. **f** Challenge virus, dose and day are not stated. The rgH5N1 challenge virus carries H5 and N1 of A/Vietnam/1203/2004 on a PR8 backbone, so it shares the N1 subtype with the H1N1 vaccine component.

![Figure 1](figures/fig1_survival_head_to_head.png)

*Figure 1. Survival by experiment (left) and difference between PSLN-344 and PSLN-212 with 95% intervals (right). "Bivalent" is the H1N1+H3N2 vaccine.*

**Pooled estimate and how far it bends.** Each row of Table 1 is one comparison; the pooled difference is a Mantel–Haenszel risk difference stratified by comparison.

| Analysis | PSLN-344 | PSLN-212 | Difference, points (95% CI) |
|---|---|---|---|
| As printed, duplicate S06-D removed (14 comparisons) | {P_all['a']}/{P_all['n1']} | {P_all['b']}/{P_all['n2']} | {P_all['rd']:.0f} ({P_all['lo']:.0f}–{P_all['hi']:.0f}) |
| BALB/c ≥20 months only (7) | {P_balb['a']}/{P_balb['n1']} | {P_balb['b']}/{P_balb['n2']} | {P_balb['rd']:.0f} ({P_balb['lo']:.0f}–{P_balb['hi']:.0f}) |
| Only comparisons with no integrity flag on either arm (9) | {P_clean['a']}/{P_clean['n1']} | {P_clean['b']}/{P_clean['n2']} | {P_clean['rd']:.0f} ({P_clean['lo']:.0f}–{P_clean['hi']:.0f}) |
| Death counts taken from the paired weight blocks where they differ (14) | {P_wt['a']}/{P_wt['n1']} | {P_wt['b']}/{P_wt['n2']} | {P_wt['rd']:.0f} ({P_wt['lo']:.0f}–{P_wt['hi']:.0f}) |
| Least favourable count in every comparison; S06-D entered from its weight block (15) | {P_worst['a']}/{P_worst['n1']} | {P_worst['b']}/{P_worst['n2']} | {P_worst['rd']:.0f} ({P_worst['lo']:.0f}–{P_worst['hi']:.0f}) |

Three cautions belong next to these numbers. First, each experiment has 7 animals per arm (10 in S03-J), and a 7-versus-7 design has only about two-in-three power to reach p < 0.05 by Fisher's test even at the pooled survival rates; 12 of the 14 comparisons do reach p < 0.05 by the more sensitive exact log-rank test, and the two that do not are the imprinted arm in which PSLN-212 itself protected 4/7 and the Swiss Webster experiment (p = {LR('S15-N', 'PSLN-212', 'PSLN-344')}). The consistency across experiments carries the case, not any single p-value. Second, the experiments are not known to be independent of one another (shared controls or cohorts cannot be excluded from the file), so the pooled p-value is descriptive. Third, nothing in the file says the studies were randomised or blinded.

**Against the young-adult benchmark.** In the nine comparisons that include young mice given PSLN-212, aged mice given PSLN-344 survived {y_344[0]}/{y_344[1]} ({100*y_344[0]/y_344[1]:.0f}%) and the young mice {y_Y[0]}/{y_Y[1]} ({100*y_Y[0]/y_Y[1]:.0f}%) (Fisher p = {p_y:.3f}); aged mice given PSLN-212 survived {y_212[0]}/{y_212[1]}. PSLN-344 recovers most of the age gap, not all of it. The Mn-free particle is not inert in aged mice ({s212_sh[0]}/{s212_sh[1]} against {sh_all[0]}/{sh_all[1]} for sham, Fisher p = {p_212_sh:.2f}); it simply falls far short of protecting them.

**Table 1b. Other challenge experiments**

{TABLE1B}

In young mice PSLN-344 adds nothing to survival over PSLN-212, and even the cGAMP particle CMP-204 is fully protective. The value of the Mn is specific to the aged host.

### 2.2 The benefit is the manganese, and it is not a dose effect

The annotation states that PSLN-344 and PSLN-212 differ in one respect: PSLN-344 incorporates Mn²⁺.

- **Same particle, same dose, different ceiling.** At 20 µg, lung *Ifnb1* at 16 h is {ifn344}-fold with PSLN-344 and {ifn212}-fold with PSLN-212 in aged mice, a ratio of {ifn_ratio}; against young mice given PSLN-212 ({ifnY}-fold) the ratio is {ifn_vsY} [S01-A, n = 5].
- **More PSLN-212 does not get there.** In the five-dose series, PSLN-212 at 40 µg gives {d212_40}-fold, below PSLN-344 at 10 µg ({d344_10}-fold). A Hill fit puts the plateau at {e212['emax']:.1f} (SE {e212['se_emax']:.1f}) for PSLN-212 and {e344['emax']:.1f} (SE {e344['se_emax']:.1f}) for PSLN-344, with half-maximal doses of {e212['ed50']:.1f} and {e344['ed50']:.1f} µg [S08-A, n = 3 per dose; the block does not restate age and is read as aged from its labels]. Mn raises the maximum response; it does not make the agonist more potent.
- **GM-CSF transcript appears only with Mn.** Lung *Gm-csf* is {gm16}-, {gm36}- and {gm72}-fold at 16, 36 and 72 h with PSLN-344, and {gm16b}-, {gm36b}- and {gm72b}-fold with PSLN-212 [S02-F, n = 5].
- **Not an encapsulation difference.** Encapsulation efficiency is {ee344}% (SD {ee344sd}) for PSLN-344 and {ee212}% (SD {ee212sd}) for PSLN-212 over three preparations each (Welch p = {ee_p}) [S08-B].

![Figure 2](figures/fig2_innate_trigger.png)

*Figure 2. (a) Lung Ifnb1 by preparation at 16 h and 72 h. (b) Dose–response. (c) Lung Gm-csf.*

What the file cannot tell us: whether the cyclic dinucleotide is needed once Mn is present (there is no Mn-only particle), whether Mn has to be built into the particle (there is no free-Mn admixture control), how much Mn is in a dose, and whether "20 µg of adjuvant" means cyclic-dinucleotide mass or particle mass (D21). Whether Mn changes delivery to the alveolar epithelium is also open, because the block that addresses it conflicts with an earlier block (D05).

### 2.3 The profile: breadth, speed, durability, host range

- **Breadth.** PSLN-344 protected when the challenge virus was a different subtype from the vaccine: H3N2 vaccine → PR8 H1N1 ({SV('S06-A', 'PSLN-344')} at day 14) [S06-A]; H1N1+H3N2 vaccine → rgH5N1 ({SV('S06-C', 'PSLN-344')}) [S06-C]; H1N1 vaccine → Perth H3N2 ({SV('S06-G', 'PSLN-344')} at day 60) [S06-G]. PSLN-212 in the same experiments: {SV('S06-A', 'PSLN-212')}, {SV('S06-C', 'PSLN-212')}, {SV('S06-G', 'PSLN-212')}.
- **Speed.** Challenge 2 days after dosing with wild-type H5N1: {SV('S03-J', 'PSLN-344')} vs {SV('S03-J', 'PSLN-212')} [S03-J; the identity of the comparator arm is disputed, D03]. Challenge at 3 days with PR8: {SV('S06-B', 'PSLN-344')} vs {SV('S06-B', 'PSLN-212')} [S06-B]. Challenge at 3 days with rgH5N1: {SV('S15-H', '3d Vaccine+PSLN-344')} with vaccine + PSLN-344, {SV('S15-H', '3d Vaccine')} with vaccine alone, {SV('S15-H', '3d PSLN-344')} with PSLN-344 alone [S15-H].
- **Durability.** At the day-60 challenge, PSLN-344 {P_d60['a']}/{P_d60['n1']}, PSLN-212 {P_d60['b']}/{P_d60['n2']}, sham {sum(a for a, n in s60)}/{sum(n for a, n in s60)}, young + PSLN-212 {sum(a for a, n in y60)}/{sum(n for a, n in y60)} [S06-E and S06-F rows 34–68, S06-G]. PSLN-344 deaths were {p14_d}/{p14_n} at the day-14 challenges in aged BALB/c and {p60_d}/{p60_n} at day 60 (Fisher p = {p_14_60:.3f}), which looks like waning. It may not be: {unt_d}/{unt_n} untreated animals that were never challenged died in the same windows (Fisher p = {p_unt:.2f} against the PSLN-344 arms). The file cannot separate vaccine failure from age-related deaths at day 60. Nothing later than day 60 has been tested in aged mice; in young mice both particles still protected {SV('S09-F', 'PSLN-344Y')} at day 180 [S09-F].
- **Host range.** 20-month C57BL/6: {SV('S15-L', 'PSLN-344')} vs {SV('S15-L', 'PSLN-212')}; 20-month outbred Swiss Webster: {SV('S15-N', 'PSLN-344')} vs {SV('S15-N', 'PSLN-212')} [S15-L, S15-N]. Fourteen-month BALB/c, with or without a PR8 infection four months earlier: PR8 challenge {imp['Naïve+PSLN-344']} and {imp['Imprinting+PSLN-344']} with PSLN-344 vs {imp['Naïve+PSLN-212']} and {imp['Imprinting+PSLN-212']} with PSLN-212; Perth H3N2 challenge {impP['Naïve+PSLN-344']} and {impP['Imprinting+PSLN-344']} vs {impP['Naïve+PSLN-212']} and {impP['Imprinting+PSLN-212']} [S06-E and S06-F, rows 71–105]. Older people have all met influenza before, so the indifference to imprinting matters. The same cohorts show that the Mn-free particle has already failed by 14 months of age ({imp['Naïve+PSLN-212']} and {impP['Naïve+PSLN-212']} in unprimed animals), so the population that needs the Mn may begin well before old age.
- **Protection from death, not from illness.** Surviving aged animals given PSLN-344 fell to a mean lowest weight of {nad344:.1f}% of baseline, survivors in the young benchmark to {nadY:.1f}% [S13-F, S15-A to S15-G, S15-M, S15-O; descriptive only, see D07]. Immunity is not sterilising in either group, which is what a T-cell-weighted mechanism would look like.
""")

# =============================================================================================
add(f"""
### 2.4 What PSLN-344 restores in the aged immune response, and what it does not

**Table 2. Group means (arithmetic; geometric for titres), n = 5 per group**

{TABLE2}

Young = 7–8-week mice given PSLN-212. HAI values printed as 0 (below the 1:10 starting dilution) were set to 5 for geometric means. Tukey p-values come from a one-way ANOVA across all groups printed in the block, on log10 values for titres and fold-changes, raw values otherwise. Of the 28 contrasts in the table, 23 have Tukey p < 0.01; in 22 of those the two groups do not overlap at all (exact Mann–Whitney p = 0.008, the smallest value five against five can give) and in the other it is 0.016. Abbreviations: DC, dendritic cell; MLN, mediastinal lymph node; Tfh and Tfr, follicular helper and follicular regulatory T cells; GMT, geometric mean titre; HAI, haemagglutination inhibition; GZMB, granzyme B; OT-I, ovalbumin-specific CD8 T cells used to read out priming.

![Figure 3](figures/fig3_restoration_vs_young.png)

*Figure 3. PSLN-212 and PSLN-344 in aged mice as a percentage of the young-adult benchmark in the same block.*

Reading the table:

- **The pattern is restoration, not over-stimulation.** On every peak read-out in Table 2, PSLN-344 brings the aged response up to, or just short of, the young benchmark. Where aged animals exceed young ones it is in the tail of the response: residual *Ifnb1* at 72 h ({ifn72_344}-fold vs {ifn72_Y}-fold) and the items in §2.5.
- **Two things are not restored.** Co-stimulatory molecules on lymph-node dendritic cells stay far below young (CD40 {A('S02-D CD40', 'PSLN-344')}% vs {A('S02-D CD40', 'PSLN-212(Y)')}%; CD86 {A('S02-D CD86', 'PSLN-344')}% vs {A('S02-D CD86', 'PSLN-212(Y)')}%) [S02-D], and the fall in follicular regulatory T cells seen at day 7 is gone by day 30 ({A('S04-C', 'PSLN-344')}% vs sham {A('S04-C', 'Sham')}%, young {A('S04-C', 'PSLN-212(Y)')}%) [S04-C].
- **A boost narrows the antibody gap to PSLN-212 for one strain only.** After a day-14 boost, H1N1-binding IgG with PSLN-212 rises to a geometric mean of {G('S13-I', 'PSLN-212')}, {fold('S13-I', 'PSLN-344', 'PSLN-212', geo=True)} below PSLN-344; for H3N2 the gap is still {fold('S13-J', 'PSLN-344', 'PSLN-212', geo=True)} [S13-I, S13-J]. There is no challenge after a boost, so whether two doses of PSLN-212 would protect is unknown.
- **Antibody quality shifts toward IgG2a.** The IgG2a/IgG1 quotient recomputed animal by animal from the subclass titres is {q(q_h1, 'PSLN-344')} with PSLN-344, {q(q_h1, 'PSLN-212')} with PSLN-212 and {q(q_h1, 'PSLN-212(Y)')} in young mice for H1N1, and {q(q_h3, 'PSLN-344')}, {q(q_h3, 'PSLN-212')} and {q(q_h3, 'PSLN-212(Y)')} for H3N2 [S13-A to S13-D]. The quotient blocks as printed (S03-B, S03-F) have their column headers rotated and would show the opposite (D04).
- **CD8 responses recognise viruses that were not in the vaccine.** IFN-γ-positive CD8 T cells after re-stimulation with H5N1 antigen: {A('S05-F', 'PSLN-344', dec=2)}% vs {A('S05-F', 'PSLN-212', dec=2)}% at day 14 and {A('S05-G', 'PSLN-344', dec=2)}% vs {A('S05-G', 'PSLN-212', dec=2)}% at day 60 [S05-F, S05-G]; after H1N1 or H3N2 re-stimulation {A('S14-A H1N1', 'PSLN-344')}% vs {A('S14-A H1N1', 'PSLN-212')}% and {A('S14-A H3N2', 'PSLN-344')}% vs {A('S14-A H3N2', 'PSLN-212')}% [S14-A].
- **Monocytes are steered away from a macrophage fate.** CD206-positive lung macrophages are {A('S11-E', 'PSLN-344')}% with PSLN-344, {A('S11-E', 'PSLN-212')}% with PSLN-212, {A('S11-E', 'Sham')}% with sham and {A('S11-E', 'PSLN-212(Y)')}% in young mice [S11-E]; Ly6C⁺CCR2⁺ macrophage counts at day 5 are {A('S07-A', 'PSLN-344', time=5)} ×10⁵ with PSLN-344 and {A('S07-A', 'PSLN-212', time=5)} ×10⁵ with PSLN-212 [S07-A, n = 3]; lung regulatory T cells at day 7 are {A('S04-D', 'PSLN-344', dec=2)}% vs {A('S04-D', 'PSLN-212', dec=2)}% [S04-D, n = 3].

### 2.5 Tolerability so far

- **Body weight after dosing, no challenge.** Mean lowest weight {n344[0]:.1f}% of baseline with PSLN-344 (worst animal {n344[1]:.1f}%), {n212[0]:.1f}% with PSLN-212, {nvac[0]:.1f}% with vaccine alone; PSLN-344 animals are back to {d10_344[0]:.1f}% on day 10 [S08-D, n = 5].
- **The R848 combination was not tolerated.** PSLN-212/R848 animals lost weight progressively to a mean of {d10_r848[0]:.2f}% on day 10 in the four animals with a value; the fifth, at 88.3% on day 8, has none [S08-D]. Its lung cytokine pattern is *Tnf*- and *Il10*-dominated ({F9('Tnf', 'PSLN-212/R848')}- and {F9('Il10', 'PSLN-212/R848')}-fold at 16 h, against {F9('Tnf', 'PSLN-344')}- and {F9('Il10', 'PSLN-344')}-fold for PSLN-344) [S09-A, n = 3].
- **The interferon signal is transient.** *Ifnb1* falls from {ifn344}-fold at 16 h to {ifn72_344}-fold at 72 h [S01-A].
- **Central nervous system.** At 36 h, transcripts in central-nervous-system tissue with vaccine + PSLN-344 relative to buffer: *Ifnb1* {cnsI}, *Tnf* {cnsT}, *Isg15* {cnsG}. The cholera-toxin positive control gives {ctI}, {ctT} and {ctG} [S10-A, n = 5]. The *Tnf* ratio is {cnsTs} against vaccine with empty liposome. So there is no cholera-toxin-type signal, but a rise in *Tnf* of up to about two-fold is not excluded (Welch p = {cnsTw}, Tukey p = {cnsTp} against buffer).
- **An inflammatory tail in the aged lung.** In the panel that corresponds to 72 h (D13), *Tnf* is still {F9('Tnf', 'PSLN-344', 'cols X-AS')}-fold and *Il6* {F9('Il6', 'PSLN-344', 'cols X-AS')}-fold with PSLN-344 in aged mice, against {F9('Tnf', 'PSLN-212(y)', 'cols X-AS')}- and {F9('Il6', 'PSLN-212(y)', 'cols X-AS')}-fold in young mice given PSLN-212 [S09-A, n = 3]. Lung monocytes are still {A('S01-D', 'PSLN-344', time='8')}% at day 8 against {A('S01-D', 'PSLN-344', time='0')}% at baseline; young mice are back to {A('S01-D', 'PSLN-212(Y)', time='8')}% [S01-D]. Ly6C⁺CCR2⁺ macrophage counts are at baseline by day 30 ({A('S07-A', 'PSLN-344', time=30, dec=2)} vs {A('S07-A', 'PSLN-344', time=0, dec=2)} ×10⁵) [S07-A, n = 3].

![Figure 4](figures/fig4_safety_reactogenicity.png)

*Figure 4. (a) Body weight after dosing. (b) Central-nervous-system transcripts at 36 h. (c) Lung monocytes over time. (d) Lung cytokine and chemokine transcripts.*

This is a reassuring start and no more than that: five animals per group, one dose level, one administration, no histopathology, no clinical pathology, no manganese measurement, and the neutrophil time course cannot be used (D06).
""")

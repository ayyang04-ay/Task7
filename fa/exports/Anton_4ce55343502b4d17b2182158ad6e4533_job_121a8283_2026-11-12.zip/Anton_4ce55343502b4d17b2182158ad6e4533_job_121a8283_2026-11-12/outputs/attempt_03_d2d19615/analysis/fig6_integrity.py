import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from parse_blocks import tidy, surv

fig, axes = plt.subplots(2, 2, figsize=(14.5, 10.2), gridspec_kw=dict(hspace=0.36, wspace=0.2))

# (a) S06-C vs S06-D rows
ax = axes[0, 0]
c = surv[surv.block == 'S06-C'].reset_index(drop=True); d = surv[surv.block == 'S06-D'].reset_index(drop=True)
cols = {'Sham': '0.5', 'PSLN-212': '#2166ac', 'PSLN-344': '#b2182b', 'PSLN-212(Y)': '#1b7837'}
x = np.arange(len(c))
ax.scatter(x, c.time, s=110, facecolor='none', edgecolor=[cols[g] for g in c.group], linewidths=1.8, label='S06-C (annotated: challenge on day 14)')
ax.scatter(x, d.time, s=22, color=[cols[g] for g in d.group], marker='s', label='S06-D (annotated: challenge on day 3)')
for i, (e1, e2) in enumerate(zip(c.event, d.event)):
    ax.text(i, -0.9, f'{int(e1)}', ha='center', fontsize=7, color='0.2'); ax.text(i, -1.9, f'{int(e2)}', ha='center', fontsize=7, color='0.2')
ax.text(-1.2, -0.9, 'flag C', ha='right', fontsize=7.5); ax.text(-1.2, -1.9, 'flag D', ha='right', fontsize=7.5)
for g, (lo, hi) in {'Sham': (0, 6), 'PSLN-212': (7, 13), 'PSLN-344': (14, 20), 'PSLN-212(Y)': (21, 27)}.items():
    ax.text((lo + hi) / 2, 16.3, g.replace('(Y)', ', young'), ha='center', color=cols[g], fontsize=9)
    ax.axvspan(lo - 0.5, hi + 0.5, color=cols[g], alpha=0.05)
ax.set_ylim(-2.8, 17.5); ax.set_xlim(-3.2, 27.8); ax.set_xticks([]); ax.set_ylabel('Day recorded for each row')
ax.legend(loc='upper left', bbox_to_anchor=(0.0, 0.9), fontsize=8.5, frameon=True, framealpha=0.95)
ax.set_title(f'a  D01: two "different" experiments, {int(((c.time == d.time) & (c.event == d.event)).sum())} of {len(c)} rows identical\n   (circles S06-C, squares S06-D; event flags printed beneath)', fontsize=10.5, loc='left')

# (b) S03-B as printed vs recomputed
ax = axes[0, 1]
def col(blk, g): return tidy[(tidy.block == blk) & (tidy.group == g)].value.astype(float).values
groups = ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']; names = ['PSLN-212\naged', 'PSLN-344\naged', 'PSLN-212\nyoung']
printed = [col('S03-B', g) for g in groups]; recomputed = [col('S13-A', g) / col('S13-B', g) for g in groups]
rng = np.random.default_rng(2)
for i in range(3):
    ax.bar(i - 0.2, printed[i].mean(), width=0.36, color='0.7', label='as printed in S03-B' if i == 0 else None)
    ax.bar(i + 0.2, recomputed[i].mean(), width=0.36, color='#b2182b', alpha=0.8, label='recomputed per animal: S13-A ÷ S13-B' if i == 0 else None)
    ax.scatter(i - 0.2 + rng.uniform(-0.08, 0.08, 5), printed[i], s=14, color='k', zorder=3); ax.scatter(i + 0.2 + rng.uniform(-0.08, 0.08, 5), recomputed[i], s=14, color='k', zorder=3)
ax.set_xticks(range(3)); ax.set_xticklabels(names); ax.set_ylabel('IgG2a / IgG1 quotient, H1N1'); ax.legend(fontsize=8.5, frameon=False)
ax.annotate('', xy=(1 - 0.2, 0.95), xytext=(0 + 0.2, 0.95), arrowprops=dict(arrowstyle='<-', color='0.3', lw=1)); ax.annotate('', xy=(2 - 0.2, 2.5), xytext=(1 + 0.2, 2.5), arrowprops=dict(arrowstyle='<-', color='0.3', lw=1))
ax.text(0.5, 1.12, 'same five values', ha='center', fontsize=8, color='0.3'); ax.text(1.5, 2.68, 'same five values', ha='center', fontsize=8, color='0.3')
ax.text(1.0, 3.55, 'printed "PSLN-212 aged" = recomputed "PSLN-212 young"', ha='center', fontsize=8, color='0.3')
ax.set_title('b  D04: quotient block has its headers rotated by one column;\n   as printed, PSLN-344 looks IgG1-skewed, recomputed it does not', fontsize=10.5, loc='left')

# (c) S15-C vs S15-I weights
ax = axes[1, 0]
w = tidy[tidy.kind == 'weight'].copy(); w['time'] = w.time.astype(float); w['value'] = w.value.astype(float)
A = w[(w.block == 'S15-C') & (w.group == 'PSLN-344')].pivot(index='time', columns='rep', values='value')
B = w[(w.block == 'S15-I') & (w.group == '3d Vaccine+PSLN-344')].pivot(index='time', columns='rep', values='value')
for r in A.columns:
    ax.plot(A.index, A[r], color='#b2182b', lw=2.4 if r == 3 else 1.2, alpha=0.9, label='S15-C, PSLN-344 (challenge day 14)' if r == 1 else None)
    ax.plot(B.index, B[r], color='k', lw=2.0 if r == 3 else 1.0, ls='--', alpha=0.9, label='S15-I, vaccine + PSLN-344 (challenge day 3)' if r == 1 else None)
same = int((A.loc[2:].values == B.loc[2:].values).sum())
ax.annotate('S15-C: 77.9 → 90.1 in two days', xy=(14, 90.1), xytext=(8.6, 101.8), fontsize=8.5, color='#b2182b', arrowprops=dict(arrowstyle='->', color='#b2182b', lw=0.8))
ax.annotate('S15-I: stays at 77.9 (recorded death)', xy=(14, 77.9), xytext=(8.4, 74.6), fontsize=8.5, arrowprops=dict(arrowstyle='->', color='k', lw=0.8))
ax.set_xlabel('Days after challenge'); ax.set_ylabel('Body weight (% of day 0), each animal'); ax.legend(fontsize=8.5, frameon=False, loc='lower left', bbox_to_anchor=(0.0, 0.06)); ax.set_ylim(73, 104)
ax.set_title(f'c  D07: weight records of two different experiments share {same} of {A.loc[2:].size} values', fontsize=10.5, loc='left')

# (d) S11-A vs S11-B
ax = axes[1, 1]
a = tidy[tidy.block == 'S11-A'].value.astype(float).values; b = tidy[tidy.block == 'S11-B'].value.astype(float).values
eq = a == b
ax.scatter(a[~eq], b[~eq], s=22, color='0.55', label=f'different ({int((~eq).sum())} cells)')
ax.scatter(a[eq], b[eq], s=34, color='#b2182b', label=f'identical ({int(eq.sum())} cells)', zorder=3)
ax.plot([14, 56], [14, 56], color='0.3', lw=0.8, ls=':')
ax.set_xlabel('S11-A, "alveolar macrophages" (%), each cell'); ax.set_ylabel('S11-B, "neutrophils" (%), same cell position'); ax.legend(fontsize=8.5, frameon=False)
ax.set_title('d  D06: one cell-count block is a near copy of another', fontsize=10.5, loc='left')
for ax in axes.ravel():
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
fig.subplots_adjust(left=0.06, right=0.985, top=0.93, bottom=0.06)
fig.savefig('/tmp/outputs/figures/fig6_integrity_examples.png', dpi=165)

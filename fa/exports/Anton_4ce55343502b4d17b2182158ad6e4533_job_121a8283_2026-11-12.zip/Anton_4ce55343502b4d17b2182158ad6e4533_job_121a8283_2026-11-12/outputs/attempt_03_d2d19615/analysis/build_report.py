import pandas as pd, numpy as np, math, re, warnings, json
from scipy import stats
from report_helpers import *
from parse_blocks import tidy, surv
warnings.filterwarnings('ignore')

SP = pd.read_csv('survival_pairwise.csv')
def LR(block, g1, g2):
    r = SP[(SP.block == block) & (((SP.g1 == g1) & (SP.g2 == g2)) | ((SP.g1 == g2) & (SP.g2 == g1)))].iloc[0]
    reg(block, f'exact log-rank p, {g1} vs {g2}', float(f'{r.logrank_p_exact:.2g}'), 'as for the two survivor counts',
        'two-group log-rank statistic; p from full enumeration of all group re-assignments (exact permutation), two-sided' + ('; the PSLN-344 row without a day (S03!J46) is left out of this test' if block == 'S03-J' else ''))
    return fmt_p(r.logrank_p_exact)

def blockrange(block):
    d = surv[surv.block == block]
    rows = sorted(int(re.sub(r'[A-Z]', '', c)) for c in list(d.time_cell) + list(d.event_cell))
    cols = sorted({cidx(re.sub(r'\d', '', c)) for c in list(d.time_cell) + list(d.event_cell)})
    return f'{d.sheet.iloc[0]}!{gcl(cols[0])}{rows[0]}:{gcl(cols[-1])}{rows[-1]}'

T = pd.read_csv('aged_head_to_head_survival.csv')
U = T[T.block != 'S06-D'].copy()

# ---------------------------------------------------------------- pooled sets
allblocks = 'S03-I, S03-J, S06-A, S06-B, S06-C, S06-E(rows 34-68), S06-F(rows 34-68), S06-G, S06-E(rows 71-105) x2 arms, S06-F(rows 71-105) x2 arms, S15-L, S15-N'
P_all = pooled_txt(U, 'all 14 comparisons as printed (duplicate S06-D removed)', allblocks)
P_dup = pooled_txt(T, 'all 15 as printed (duplicate S06-D left in)', allblocks + ', S06-D')
Ub = U[U.strain_age == 'BALB/c aged']
P_balb = pooled_txt(Ub, 'BALB/c >=20 months only (7 comparisons)', 'S03-I, S06-A, S06-B, S06-C, S06-E(rows 34-68), S06-F(rows 34-68), S06-G')
clean_blocks = ['S06-A', 'S06-B', 'S06-F (rows 34-68)', 'S06-E (rows 71-105)', 'S06-F (rows 71-105)', 'S15-L', 'S15-N']
Uc = U[U.block.isin(clean_blocks)]
P_clean = pooled_txt(Uc, 'unflagged comparisons only (9)', 'S06-A, S06-B, S06-F(rows 34-68), S06-E(rows 71-105) x2, S06-F(rows 71-105) x2, S15-L, S15-N')
P_d60 = pooled_txt(U[U.challenge_day == 'd60'], 'day-60 challenges (3)', 'S06-E(rows 34-68), S06-F(rows 34-68), S06-G')
P_early = pooled_txt(U[U.challenge_day.isin(['d2', 'd3'])], 'day-2/3 challenges (2)', 'S03-J, S06-B')
P_str = pooled_txt(U[U.block.isin(['S15-L', 'S15-N'])], 'C57BL/6 and Swiss Webster (2)', 'S15-L, S15-N')
P_imp = pooled_txt(U[U.block.str.contains('71-105')], '14-month cohorts (4)', 'S06-E(rows 71-105) x2, S06-F(rows 71-105) x2')
W = U.copy()
for k, (a, b) in {'S03-I': (7, 3), 'S06-C': (7, 1), 'S06-E (rows 34-68)': (6, 1), 'S06-G': (5, 0)}.items():
    W.loc[W.block == k, ['s344', 's212']] = [a, b]
P_wt = pooled_txt(W, 'sensitivity: death counts implied by the paired body-weight blocks where they differ', 'S13-F for S03-I (7/7 v 3/7); S15-C for S06-C (7/7 v 1/7); S15-E for S06-E (6/7 v 1/7); S15-G for S06-G (5/7 v 0/7); others as printed')
WC = U.copy()
for k, (a, b) in {'S03-I': (7, 3), 'S06-C': (6, 2), 'S06-E (rows 34-68)': (5, 1), 'S06-G': (4, 0)}.items():
    WC.loc[WC.block == k, ['s344', 's212']] = [a, b]
WC.loc[WC.block == 'S03-J', ['s344', 'n344']] = [9, 9]
ex = T[T.block == 'S06-D'].copy(); ex[['s344', 's212']] = [5, 2]
WC = pd.concat([WC, ex])
P_worst = pooled_txt(WC, 'least-favourable reading', 'per comparison the lower PSLN-344 and higher PSLN-212 survivor count from table or paired weight block; S06-C PSLN-344 taken as 6/7 (one animal with an implausible weight recovery, S15!Y29:Y30); S03-J PSLN-344 9/9 (row without a day dropped); S06-D entered from its weight block S15-D (5/7 v 2/7)')

V = U[U.sY.notna()]
y_344 = (int(V.s344.sum()), int(V.n344.sum())); y_Y = (int(V.sY.sum()), int(V.nY.sum())); y_212 = (int(V.s212.sum()), int(V.n212.sum())); y_sh = (int(V.sSham.sum()), int(V.nSham.sum()))
p_y = stats.fisher_exact([[y_344[0], y_344[1] - y_344[0]], [y_Y[0], y_Y[1] - y_Y[0]]])[1]
yb = 'S03-I, S06-A, S06-B, S06-C, S06-E(rows 34-68), S06-F(rows 34-68), S06-G, S15-L, S15-N (the nine comparisons that carry a young arm)'
reg('pooled survival', 'aged PSLN-344 vs young PSLN-212(Y), same experiments', f'{y_344[0]}/{y_344[1]} vs {y_Y[0]}/{y_Y[1]}; Fisher p={p_y:.4f}', yb, "sum of survivors / animals; Fisher's exact test two-sided", y_344[1] + y_Y[1])
reg('pooled survival', 'aged PSLN-212 and aged Sham in the nine experiments with a young arm', f'{y_212[0]}/{y_212[1]} and {y_sh[0]}/{y_sh[1]}', yb, 'sum of survivors / animals', y_212[1])
Sx = U[U.sSham.notna()]
sh_all = (int(Sx.sSham.sum()), int(Sx.nSham.sum())); s344_sh = (int(Sx.s344.sum()), int(Sx.n344.sum())); s212_sh = (int(Sx.s212.sum()), int(Sx.n212.sum()))
reg('pooled survival', 'aged Sham, PSLN-212, PSLN-344 in the ten comparisons with a Sham arm', f'{sh_all[0]}/{sh_all[1]}, {s212_sh[0]}/{s212_sh[1]}, {s344_sh[0]}/{s344_sh[1]}', 'nine above plus S03-J', 'sum of survivors / animals', sh_all[1])
p_212_sh = stats.fisher_exact([[s212_sh[0], s212_sh[1] - s212_sh[0]], [sh_all[0], sh_all[1] - sh_all[0]]])[1]
reg('pooled survival', 'aged PSLN-212 vs aged Sham, Fisher p', float(f'{p_212_sh:.2g}'), 'ten comparisons with a Sham arm', "Fisher's exact test two-sided on pooled counts", s212_sh[1] + sh_all[1])

d60 = ['S06-E (rows 34-68)', 'S06-F (rows 34-68)', 'S06-G']
unt = [SV(b, 'Untreated', raw=True) for b in d60]; unt_d = sum(n - a for a, n in unt); unt_n = sum(n for a, n in unt)
p60 = [SV(b, 'PSLN-344', raw=True) for b in d60]; p60_d = sum(n - a for a, n in p60); p60_n = sum(n for a, n in p60)
y60 = [SV(b, 'PSLN-212(Y)', raw=True) for b in d60]; s60 = [SV(b, 'Sham', raw=True) for b in d60]
p_unt = stats.fisher_exact([[unt_d, unt_n - unt_d], [p60_d, p60_n - p60_d]])[1]
reg('pooled survival', 'day-60 cohorts: deaths in unchallenged Untreated vs challenged PSLN-344', f'{unt_d}/{unt_n} vs {p60_d}/{p60_n}; Fisher p={p_unt:.2f}', 'S06!G62:L68, S06!M62:R68, S06!A99:F105 vs the PSLN-344 rows of the same three blocks', "sum of deaths / animals; Fisher's exact two-sided", unt_n + p60_n)
d14b = ['S03-I', 'S06-A', 'S06-C']
p14 = [SV(b, 'PSLN-344', raw=True) for b in d14b]; p14_d = sum(n - a for a, n in p14); p14_n = sum(n for a, n in p14)
p_14_60 = stats.fisher_exact([[p14_d, p14_n - p14_d], [p60_d, p60_n - p60_d]])[1]
reg('pooled survival', 'PSLN-344 deaths, day-14 vs day-60 challenges in aged BALB/c', f'{p14_d}/{p14_n} vs {p60_d}/{p60_n}; Fisher p={p_14_60:.3f}', 'S03-I, S06-A, S06-C vs S06-E, S06-F (rows 34-68), S06-G', "sum of deaths / animals; Fisher's exact two-sided", p14_n + p60_n)

# young experiments
yng = [('S09-B', 'H3N2 → PR8 H1N1, day 21'), ('S09-D', 'H1N1 → Perth H3N2, day 21'), ('S09-F', 'H1N1+H3N2 → rgH5N1, day 180')]

# weights: survivors' nadir
WM = pd.read_csv('weight_group_morbidity.csv')
wa = pd.read_csv('weight_animal_morbidity.csv')
pairs_blocks = ['S13-F', 'S15-A', 'S15-B', 'S15-C', 'S15-D', 'S15-E', 'S15-F', 'S15-G', 'S15-M', 'S15-O']
nad344 = np.mean([wa[(wa.block == b) & (wa.group == 'PSLN-344') & (wa.status == 'survivor')].nadir.mean() for b in pairs_blocks])
nadY = np.mean([wa[(wa.block == b) & (wa.group == 'PSLN-212(Y)') & (wa.status == 'survivor')].nadir.mean() for b in pairs_blocks])
reg('body weight after challenge', 'mean lowest weight of surviving animals, aged PSLN-344 vs young PSLN-212', f'{nad344:.1f}% vs {nadY:.1f}% of day-0 weight',
    'S13-F, S15-A to S15-G, S15-M, S15-O (PSLN-344 and PSLN-212(Y) columns)', 'per animal: lowest recorded weight; animals with blank or frozen-low trajectories (deaths) excluded; mean per block, then unweighted mean of the ten block means. Descriptive only: weight blocks share values across experiments', '')

# dose-response fits
from scipy.optimize import curve_fit
def hill(x, emax, ed50, h): return 1 + (emax - 1) * x ** h / (ed50 ** h + x ** h)
HF = {}
d8 = tidy[tidy.block == 'S08-A'].copy(); d8['value'] = d8.value.astype(float); d8['dose'] = d8.time.astype(float)
for g in ['CMP-204', 'PSLN-212', 'PSLN-344']:
    x = d8[d8.group == g].dose.values; y = d8[d8.group == g].value.values
    p, cov = curve_fit(hill, x, y, p0=[y.max(), 10, 2], bounds=([1, 0.5, 0.3], [500, 200, 8])); se = np.sqrt(np.diag(cov))
    HF[g] = dict(emax=p[0], ed50=p[1], h=p[2], se_emax=se[0], se_ed50=se[1], at20=100 * (hill(20, *p) - 1) / (p[0] - 1))
    reg('S08-A', f'Hill fit, {g}: plateau (SE); ED50 µg (SE)', f'{p[0]:.1f} ({se[0]:.1f}); {p[1]:.1f} ({se[1]:.1f})', cellrange(d8[d8.group == g]),
        'least-squares fit of fold = 1 + (Emax-1)·d^h/(ED50^h + d^h) to the 15 per-animal values (5 doses x 3)', 15)

# CNS ratios
def cns(an, ref):
    e, lo, hi = CT('S10-A', 'PSLN-344', ref, panel=an, what='raw'); return e, lo, hi

# --------------------------------------------------------------- integrity log
DI = [
 ('D01', 'High', 'S06-C vs S06-D (S06!M3:Q30 vs S06!A34:E61)',
  'The two time-to-event tables are identical row for row (28 rows: same days, same flags, same order) although they are described as different experiments (challenge on day 14 vs day 3). The weight block paired with S06-D (S15-D) implies 2 deaths in the PSLN-344 arm and 2 in the young arm; the table shows none.',
  'Whole-block comparison of (day, flag) vectors; frozen-trajectory count in S15-D.',
  'S06-D cannot be counted as an independent experiment. Day-3 protection against rgH5N1 rests on S15-H alone.',
  'Counted once (as S06-C). S06-D appears only in the least-favourable sensitivity analysis, entered from its weight block (5/7 vs 2/7).'),
 ('D02', 'High', 'S03-I vs S13-F (S03!A17:F51 vs S13!B33:AJ40)',
  'S13-F is annotated as "the animals of S03-I" but prints groups PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naïve, where S03-I prints Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y). By death pattern the S13-F "PSLN-212" column (4 animals frozen, 3 recover) matches the S03-I "CMP-204" column (4 deaths, 3 survivors), and S13-F "Naïve" (all 7 gone by day 8) matches S03-I "PSLN-212" (7 deaths by day 6). In the nine other experiments that have both arms the PSLN-212 arm dies later than sham (later median day of death in 9 of 9); in S03-I as printed it does not (days 5-6 against 5-11), which favours the S13-F labels.',
  'Per-animal trajectory classification (blank / frozen / recovering) against death days.',
  'In the only matched-strain challenge the PSLN-212 arm is either 0/7 or 3/7 survivors. PSLN-344 is 7/7 under both readings.',
  'Primary analysis uses S03-I as printed (0/7); sensitivity uses 3/7; S03-I is excluded from the "unflagged" subset.'),
 ('D03', 'High', 'S03-J vs S13-G (S03!G17:J46 vs S13!B43:AE50)',
  'S13-G ("the animals of S03-J") prints PSLN-344, Sham, Naïve; S03-J prints Sham, PSLN-212, PSLN-344. S13-G "Naïve" (9 of 10 frozen) matches S03-J "Sham" (9 deaths); S13-G "Sham" (5 frozen, 1 still falling at day 14) resembles S03-J "PSLN-212" (7 deaths). Also: stated n = 9 but 10 rows per group; the last PSLN-344 row has a flag (J46 = 0) but no day (G46 blank); annotation says 22 days of observation, the latest day in the table is 21; challenge dose and animal age are not stated.',
  'As D02, plus row counts.',
  'The comparator arm in the wild-type H5N1 experiment may be vaccine-only rather than PSLN-212. PSLN-344 is 10/10 (or 9/9) under every reading.',
  'Primary as printed; excluded from the "unflagged" subset; 9/9 used in the least-favourable analysis.'),
 ('D04', 'Medium', 'S03-B and S03-F (S03!G3:I7, S03!G10:I14) vs S13-A to S13-D (S13!A3:O7)',
  'The IgG2a/IgG1 quotients printed under "PSLN-212", "PSLN-344", "PSLN-212(Y)" equal, animal by animal, the quotients recomputed from the S13 titres for PSLN-212(Y), PSLN-212 and PSLN-344 respectively (agreement to within 0.1%). The headers are rotated by one position.',
  'Recomputed IgG2a ÷ IgG1 per animal from S13-A/B and S13-C/D.',
  'As printed, PSLN-344 would look IgG1-skewed (0.58). Recomputed, PSLN-344 is 2.1 (H1N1) and 2.7 (H3N2), PSLN-212 is 0.58 and 0.51.',
  'Recomputed quotients from S13 are used; S03-B/F as printed are not.'),
 ('D05', 'Medium', 'S08-C vs S01-B (S08!A14:D18 vs S01!B14:F17)',
  'As printed, S08-C gives 13.8% dye-positive type I cells for the Mn-free particle (S01-B gives 3.8% for the same condition) and a four-fold loss of type II delivery when Mn is added. Column A of S08-C shares three values with the S01-B type II row and column B shares two with the S01-B type I row. Swapping the headers of columns B and C reconciles the two blocks (type II 15.8 vs 13.8; type I 3.8 vs 3.0).',
  'Cross-block value overlap and comparison of means.',
  'Whether Mn changes epithelial delivery cannot be read from this block.',
  'Not used for any claim; flagged for source check.'),
 ('D06', 'Medium', 'S11-A vs S11-B (S11!B3:U7 vs S11!B10:U14)',
  '35 of 100 cells are identical in the same positions (replicates 1 and 2 of almost every group and day), and the group means differ by at most 2.5 points, although one block is alveolar macrophages and the other neutrophils.',
  'Same-position comparison.',
  'The neutrophil time course, a reactogenicity readout, is not independent data.',
  'S11-B not used.'),
 ('D07', 'Medium', 'Body-weight blocks on S09, S13, S15',
  'Values recur across nominally independent experiments: S15-C PSLN-344 vs S15-I "3d Vaccine+PSLN-344" share 40 of 49 post-baseline values (all 7 animals); S09-E PSLN-344Y (BALB/c) vs S15-M PSLN-212(Y) (C57BL/6) share 32 of 49; S15-A vs S15-M PSLN-344 share 16 of 49; S09-E and S09-G PSLN-212Y column N is identical on all 7 days; in S09-C the day-12 row is the same for PSLN-212Y and PSLN-344Y. In S15-C one PSLN-344 animal rises from 77.9% to 90.1% between days 12 and 14 (S15!Y29:Y30); in the otherwise identical S15-I column the animal stays at 77.9% and is the recorded death.',
  'All-pairs comparison of per-animal trajectories, same-day identity.',
  'Weight blocks cannot serve as independent confirmation of the survival tables. The 7/7 for PSLN-344 in S06-C may be 6/7.',
  'Weights used descriptively only (lowest weight per surviving animal); no inferential claim rests on them. S06-C PSLN-344 entered as 6/7 in the least-favourable analysis.'),
 ('D08', 'Medium', 'Survival tables vs paired weight blocks',
  'Death counts implied by the weight blocks (blank or frozen trajectories) differ from the tables by one or two animals in several arms: S06-C/S15-C PSLN-212 (5 vs 6 deaths); S06-E rows 34-68/S15-E PSLN-212 (7 vs 6) and PSLN-344 (2 vs 1); S06-G/S15-G PSLN-344 (3 deaths on days 8-11 vs 2 after day 12); S15-L/S15-M young arm (1 vs 0); S09-F Sham has 7 rows, S09-G has 8 animals.',
  'Trajectory classification vs table counts.',
  'Each survival count carries roughly ±1 animal of uncertainty.',
  'Tables are primary; two sensitivity analyses (weight-implied counts; least-favourable counts).'),
 ('D09', 'Medium', 'Weight blocks: two conventions for dead animals',
  'Dead animals are left blank in some groups (Sham, Naïve, single-agent arms) and carried forward at their last weight to day 14 in others (PSLN-212, PSLN-344, Untreated, some young animals).',
  'Blank cells vs constant tails below 90%.',
  'Group mean curves after day 4-6 are not comparable between arms.',
  'Group means over time are not used; per-animal lowest weight and survivor-only summaries are.'),
 ('D10', 'Medium', 'Untreated arms of S06-E and S06-F (rows 34-68) and S06-G',
  'These 20-month animals received no vaccine, adjuvant or virus, yet 1/7, 0/7 and 3/7 died during the 14-day window (4/21).',
  'Event flags in S06!L62:L68, S06!R62:R68, S06!F99:F105; mirrored by frozen trajectories in S15-E and S15-G.',
  'Deaths in vaccinated arms at the day-60 challenge cannot all be attributed to infection; apparent waning is confounded.',
  'Reported explicitly; durability claims limited to the contrast with PSLN-212 and Sham.'),
 ('D11', 'Low', 'Stated n vs observations',
  'S03-J states 9, has 10; S05-A and S05-B state 3, have 2; S13-E states 5, has 7; S08-D PSLN-212/R848 has 4 values at day 10 (W26 blank); S09-F Sham has 7 rows against n = 8 (the annotation places the short group in S09-B, where the workbook has 8).',
  'Count of non-empty cells per group.', 'Minor; denominators differ from labels.', 'Observed counts used throughout.'),
 ('D12', 'Low', 'Sheet S06 block labels', 'Labels S06-E and S06-F are each used twice (rows 34-68 and rows 71-105) for different experiments.', 'Label scan.', 'Risk of mis-citation.', 'Always cited with the row range.'),
 ('D13', 'Medium', 'S09-A (S09!B3:V9 and S09!Y3:AS9)',
  'Both panels are labelled "16h"; values are log10, not linear. Back-transformed Ifnb1 values of the first panel reproduce S01-A 16 h animals (18 of 18) and those of the second reproduce S01-A 72 h animals (18 of 18). The first group is labelled PBS here but carries the values of the S01-A "Sham" animals.',
  'Back-transformation and matching against S01-A.',
  'The second panel is in all likelihood 72 h. Control identity (buffer vs empty liposome) is ambiguous.',
  'Second panel treated as 72 h and labelled as an inference; all S09-A values back-transformed.'),
 ('D14', 'Medium', 'S07-C (S07!B15:C20)', 'Both columns carry the same printed label ("Ly6C-CD206+ MΦ").', 'Header read.', 'The direction of the macrophage-transfer effect on lung Tregs cannot be assigned.', 'Not used.'),
 ('D15', 'Low', 'S08 rows 89-101 (S08!A89:D101)', 'Thirteen rows of numbers (14 in column A; 0 in column C for 6 rows and in column D for 7 rows) with no label, header or annotation.', 'Completeness check of parsed cells.', 'Uninterpretable.', 'Excluded.'),
 ('D16', 'Low', 'S08-A group "PSLN-344/R848"', 'This preparation is not defined in the annotation (only PSLN-212/R848 is).', 'Annotation cross-check.', 'Identity unknown.', 'Shown as printed, not interpreted.'),
 ('D17', 'Medium', 'S05-A, S05-B (and S05-I by reference)',
  'Conditions are contradictory (ovalbumin immunisation in one sentence, bivalent vaccine in the next; an NP366-374 tetramer readout; a sham group is mentioned but absent) and there are 2 animals per group against a stated 3.',
  'Annotation read; counts.', 'Antigen-specific CD8 kinetics are descriptive at best.', 'Not used for inference; S05-I reported with the caveat.'),
 ('D18', 'Low', 'Under-specified blocks',
  'Not stated: adjuvant and age of the "PTX" group (S02-C, S02-E); challenge virus, dose and day (S15-L, S15-N); challenge day (S06-E rows 71-105); sampling day (S07-B, S11-E, S13-H, S14-A); age (S02-G, S02-H, S07-A, S07-B, S08-A; read as aged from the label convention only). S10-A is annotated "mean with SD" but holds five per-animal values per group.',
  'Annotation read.', 'Limits interpretation of those blocks.', 'Stated where relevant.'),
 ('D19', 'Low', 'S08-B', 'Encapsulation is defined as absorbance of CDN-1807 at 260 nm but is also reported for CMP-204 (cGAMP cargo) and PSLN-R848 (no cyclic dinucleotide).', 'Annotation read.', 'Measurand undefined for two of five preparations; PSLN-344 vs PSLN-212 comparison unaffected.', 'Only PSLN-212 and PSLN-344 compared.'),
 ('D20', 'Low', 'Mechanism blocks run outside the target host', 'S01-C uses 7-8-week knock-outs; S02-I and S12-A are young animals; S02-H does not state age.', 'Annotation read.', 'Several mechanistic links are shown in young animals and inferred for aged ones.', 'Flagged in the evidence chain.'),
 ('D21', 'Medium', 'Dose definition', '"20 micrograms of adjuvant per animal" is not defined as cyclic-dinucleotide mass or particle mass, and the Mn content per dose appears nowhere in the file.', 'Annotation read.', 'Cyclic-dinucleotide dose may not be identical between PSLN-212 and PSLN-344; Mn exposure cannot be calculated.', 'Flagged as a CMC and toxicology gap.'),
 ('D22', 'Low', 'S08-A CMP-204 at 1 µg vs S02-F Sham at 16 h (S08!B3:D3 vs S02!L17:P17)', 'The three CMP-204 values at 1 µg (1.02, 1.05, 0.93) are three of the five sham values in a block that measures a different transcript.', 'All-pairs value comparison.', 'None for any conclusion (both sets sit at baseline); coincidence not excluded.', 'Noted for the audit.'),
]
DIdf = pd.DataFrame(DI, columns=['id', 'severity', 'location', 'finding', 'how_detected', 'consequence', 'handling'])
DIdf.to_csv('/tmp/outputs/data_integrity_log.csv', index=False)

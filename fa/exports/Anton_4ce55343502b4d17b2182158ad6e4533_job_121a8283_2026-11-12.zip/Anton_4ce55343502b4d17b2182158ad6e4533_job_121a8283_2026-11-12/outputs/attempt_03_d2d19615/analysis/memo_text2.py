exec(open('memo_text.py').read())

reg('power calculation', 'power of a 7-vs-7 experiment at the pooled survival rates (84% vs 13%)', 0.67, 'pooled rates from the 14 comparisons',
    "exact enumeration of all outcomes of two binomials (n = 7 each); proportion with Fisher's exact two-sided p <= 0.05", 14)
reg('power calculation', 'power with 18 per arm for 80% vs 25% survival', 0.91, 'planning values', "as above with n = 18 per arm", 36)
reg('power calculation', 'power with 15 per arm for 80% vs 15% survival', 0.94, 'planning values', "as above with n = 15 per arm", 30)
reg('power calculation', 'power with 12 per arm for 80% vs 15% survival', 0.89, 'planning values', "as above with n = 12 per arm", 24)

yblocks = ['S03-I', 'S06-A', 'S06-B', 'S06-C', 'S06-E (rows 34-68)', 'S06-F (rows 34-68)', 'S06-G', 'S15-L', 'S15-N']
_a = [SV(b, 'PSLN-212(Y)', raw=True) for b in yblocks] + [SV(b, 'PSLN-212Y', raw=True) for b in ('S09-B', 'S09-D', 'S09-F')]
yp212 = (sum(x[0] for x in _a), sum(x[1] for x in _a))
_b = [SV(b, 'PSLN-344Y', raw=True) for b in ('S09-B', 'S09-D', 'S09-F')] + [SV('S13-E', 'PSLN-344(Y)', raw=True)]
yp344 = (sum(x[0] for x in _b), sum(x[1] for x in _b))
reg('pooled survival', 'young mice given PSLN-212, all challenge experiments', f'{yp212[0]}/{yp212[1]}', 'young arms of S03-I, S06-A, S06-B, S06-C, S06-E and S06-F (rows 34-68), S06-G, S15-L, S15-N; S09-B, S09-D, S09-F', 'sum of survivors / animals', yp212[1])
reg('pooled survival', 'young mice given PSLN-344, all challenge experiments', f'{yp344[0]}/{yp344[1]}', 'S09-B, S09-D, S09-F, S13-E', 'sum of survivors / animals', yp344[1])
ccl2 = CT('S09-A', 'PSLN-344', 'PSLN-212', panel='cols A-U|Ccl2', dec=0, ci=False)
mono_ratio = fold('S01-D', 'PSLN-344', 'PSLN-212', time='4'); mig_ratio = fold('S02-A', 'PSLN-344', 'PSLN-212')
gm_ratio = fold('S02-F', 'PSLN-344', 'PSLN-212', time='36h')
wt = A('S02-H', 'WT w/o cDC'); ko = A('S02-H', 'IFN w/o cDC'); resc = A('S02-H', 'GMCSF'); wtc = A('S02-H', 'WT w/ cDC'); koc = A('S02-H', 'IFN w/ cDC')
resc_pct = 100 * A('S02-H', 'GMCSF', raw=True) / A('S02-H', 'WT w/o cDC', raw=True)

# =============================================================================================
add(f"""
## 3. Weaknesses the committee should hear from us first

### 3.1 Data integrity

I checked every block against its stated n, against the blocks it is paired with, and against every other block for repeated values; I recomputed every derived quantity that can be recomputed. Twenty-two issues are logged with cells, evidence and handling in Appendix C (`data_integrity_log.csv`). The ones that change what we can claim:

- **A duplicated survival table (D01).** S06-C and S06-D are the same 28 rows. The day-3 rgH5N1 result therefore rests on S15-H ({SV('S15-H', '3d Vaccine+PSLN-344')}), not on S06-D.
- **Conflicting group labels between a survival table and its weight block (D02, D03).** In the matched-strain experiment the PSLN-212 arm is {SV('S03-I', 'PSLN-212')} as printed in S03-I and 3/7 under the labels of S13-F. In the wild-type H5N1 experiment the comparator arm is PSLN-212 in S03-J and "Sham" in S13-G. PSLN-344 is 7/7 and 10/10 under every reading.
- **Rotated headers on the IgG2a/IgG1 blocks (D04).** Taken as printed, S03-B says PSLN-344 skews toward IgG1. The subclass titres say the opposite.
- **Body-weight values re-used across experiments (D07).** For example 40 of 49 values are shared between the PSLN-344 arms of S15-C and S15-I, and 32 of 49 between a BALB/c arm (S09-E) and a C57BL/6 arm (S15-M). I use weights descriptively only.
- **Unchallenged aged controls that die (D10).** {unt_d} of {unt_n} untreated 20-month animals that were never challenged died during the observation window. This limits what can be said about durability.
- **A near-copy of one cell-count block in another (D06)**, which removes the neutrophil data, and **one macrophage-transfer block with two identically labelled columns (D14)**, which removes that experiment.

How I handled them: the workbook as printed is the primary analysis; every alternative reading is carried as a sensitivity analysis (§2.1); blocks that cannot be interpreted are excluded and listed. The headline difference stays between {P_worst['rd']:.0f} and {P_all['rd']:.0f} points under all of them. I cannot tell from the file whether these are transcription errors made when the workbook was assembled or something worse; only the raw records can. That is Gate 0.

### 3.2 Gaps in the evidence

- **No causal link to survival.** Every intervention experiment reads out a cell population, none reads out survival (§4.1).
- **One efficacy dose.** All challenge work used 20 µg, which sits at {e344['at20']:.0f}% of the fitted *Ifnb1* plateau [S08-A]. The lowest effective dose and the margin to reactogenicity are unknown.
- **No virology, no mucosal antibody, no pathology.** The file has no lung or nasal virus titres, no IgA, no histology.
- **No clinically relevant comparator.** The comparators are empty liposome, the Mn-free particle and a cGAMP particle. Nothing compares PSLN-344 with the enhanced vaccines older adults are given (high-dose, MF59-adjuvanted, recombinant) *[external]* or with intramuscular dosing.
- **Antigen.** Formalin-inactivated whole virus. Licensed seasonal vaccines are mostly split, subunit or recombinant; they carry less internal protein than whole virus, and recombinant vaccine carries none *[external]*. Cross-subtype CD8 responses may depend on the whole-virion format.
- **Route.** In mice the intranasal dose reaches alveolar macrophages and alveolar epithelium [S01-B, S01-C], and every mechanistic read-out is in lung. A human nasal spray does not deposit there *[external]*. Whether deep-lung delivery is required is untested.
- **Species and sex.** Three mouse strains; the annotation specifies female BALB/c.
- **Mechanism shown partly in the wrong host.** The surfactant-protein, interferon-receptor and CCR2→CD8 experiments were run in young animals or do not state age (D20).
- **Nothing on human cells.** Human STING is polymorphic and cyclic-dinucleotide potency differs between species *[external]*.
- **CMC.** Encapsulation {ee344}% (lowest preparation {ee344min}%) over three preparations [S08-B]; size, charge and morphology are said to have been measured but are not in the file; no Mn content, no release data, no stability data.
- **Statistics.** Five to seven animals per group, many endpoints, no correction across blocks, no statement on randomisation or blinding.

## 4. Forward view

### 4.1 What is actually driving the protection

**Table 3. The chain from particle to survival, and the kind of evidence behind each link**

| Link | Evidence in the file | Kind of evidence | Host | Weakness |
|---|---|---|---|---|
| Particle is taken up by alveolar macrophages through surfactant proteins A and D | Dye-positive alveolar macrophages {A('S01-C', 'WT')}% in wild-type, {A('S01-C', 'SPA/D')}% in double knock-out [S01-C] | Genetic loss of function | Young knock-outs | n = 4; not done in aged mice |
| Cargo reaches alveolar epithelium | Dye-positive type II cells {A('S01-B', 'AECII/PSLN-SRB')}% with particle, {A('S01-B', 'AECII/FreeSRB', dec=1)}% with free dye [S01-B] | Delivery | Aged | Later block on Mn and delivery conflicts (D05) |
| Gap junctions are needed for monocyte recruitment | Recruited monocytes {A('S11-C', 'CBX-')}% → {A('S11-C', 'CBX+')}% with carbenoxolone [S11-C] | Pharmacological block | Aged | Carbenoxolone is not selective |
| **Mn lifts the interferon ceiling** | *Ifnb1* {ifn344} vs {ifn212}-fold; plateau {e344['emax']:.0f} vs {e212['emax']:.0f} [S01-A, S08-A] | Matched-particle comparison, dose series | Aged (S08-A by label) | No Mn-only control |
| **Mn switches on GM-CSF** | *Gm-csf* {gm36} vs {gm36b}-fold at 36 h [S02-F] | Matched-particle comparison | Aged (by label) | Transcript only; no young reference |
| Monocyte influx depends on CCR2 | Lung monocytes {A('S07-B', 'PSLN-344', 'CD11b+Ly6C+ Monocytes')}% → {A('S07-B', 'PSLN-344+INCB3344', 'CD11b+Ly6C+ Monocytes')}% with INCB3344 [S07-B] | Pharmacological block | Age not stated | Sampling day not stated |
| Monocytes need interferon signalling to become dendritic cells, and GM-CSF can partly stand in | Donor-derived monocyte-derived DCs {wt}% (wild-type marrow) → {ko}% (interferon-receptor-deficient marrow) → {resc}% with GM-CSF added back, {resc_pct:.0f}% of wild-type [S02-H]. Monocyte influx itself is not clearly interferon-dependent: {A('S12-A', 'WT to WT')}% vs {A('S12-A', 'IFNAR-/- to WT')}% (Welch p = {PV('S12-A', 'WT to WT', 'IFNAR-/- to WT', kind='welch')}) [S12-A] | Genetic loss of function with add-back | Young (S12-A); not stated (S02-H) | n = 3 in S12-A |
| Supplying GM-CSF raises the dendritic-cell-like population under PSLN-212 | {A('S02-G', 'PSLN-212')}% → {A('S02-G', 'PSLN-212+GM-CSF')}%; GM-CSF alone {A('S02-G', 'GM-CSF')}% [S02-G] | Gain of function | Aged by label | **No protection read-out**; no PSLN-344 reference arm |
| Lymph-node priming needs cell migration; lung priming does not | OT-I proliferation in lymph node {A('S05-C', 'MLN')}% → {A('S05-C', 'MLN+PTX')}% with pertussis toxin; in lung {A('S05-C', 'Lung')}% → {A('S05-C', 'Lung+PTX')}% [S05-C] | Pharmacological block | C57BL/6, age not stated | n = 3 |
| Blocking monocyte influx removes the lung effector CD8 response | Lung GZMB⁺ CD8 {A('S02-I', 'PSLN-344(Y)', dec=2)}% → {A('S02-I', 'PSLN-344(Y)+INCB3344', dec=2)}% [S02-I] | Pharmacological block | **Young** | Not done in aged mice |
| CD8 effector, memory and lung-resident cells are restored | Table 2 [S05-D to S05-I, S14-A] | Matched-particle comparison | Aged | Association only |
| Antibody is restored | Table 2 [S03, S13] | Matched-particle comparison | Aged | Association only |
| **CD8 T cells, dendritic cells or antibody → survival** | **None** | **Not tested** | | **The open link** |

What the file does establish about the driver:

1. **It is the manganese.** Same particle, same dose, with and without Mn: {P_all['a']}/{P_all['n1']} vs {P_all['b']}/{P_all['n2']}.
2. **It needs antigen.** PSLN-344 without vaccine, given 3 days before challenge, protected {SV('S15-H', '3d PSLN-344')}; vaccine without PSLN-344 protected {SV('S15-H', '3d Vaccine')}; together {SV('S15-H', '3d Vaccine+PSLN-344')} [S15-H]. An interferon-induced antiviral state on its own is ruled out as the cause of protection, even at day 3.
3. **It is not strain-specific antibody.** The vaccine and challenge strains differ in subtype in six of the eight aged BALB/c experiments, and protection is present 2–3 days after dosing. And where antibody should matter most it did not predict outcome: all five aged animals given PSLN-212 reached an H1N1 HAI titre of 40 or more ({CNT('S03-C', 'PSLN-212', 40)}; geometric mean {G('S03-C', 'PSLN-212')}) [S03-C], the conventional human threshold *[external]*, yet that arm survived {SV('S03-I', 'PSLN-212')} against the matched virus [S03-I; 3/7 under the S13-F labels]. Both arms that survived had every animal at 160 or above ({CNT('S03-C', 'PSLN-344', 160)} and {CNT('S03-C', 'PSLN-212(Y)', 160)}).
4. **What moves with protection is the interferon → GM-CSF → monocyte-derived dendritic cell → CD8 arm**, and the middle of that chain has loss- and gain-of-function support (Table 3).

So the most probable driver is Mn-restored priming of cross-reactive CD8 T cells by monocyte-derived dendritic cells in the lung, with restored antibody adding to protection against matched strains. "Most probable" is the honest strength of that statement. The file cannot distinguish CD8 T cells from cross-reactive non-neutralising antibody, which was never measured, and it contains no experiment that removes either and then challenges. Study 2 closes this.

### 4.2 Is there a biomarker of efficacy worth carrying forward?

**Table 4. Candidates**

| Candidate | Moves with Mn in aged mice (344 ÷ 212) | On the causal path? | Measurable in patients? | Verdict |
|---|---|---|---|---|
| **Early interferon-β → GM-CSF → CCL2/monocyte → dendritic-cell response** (lung *Ifnb1* 16 h, *Gm-csf* 16–36 h, *Ccl2* 16 h, lung monocytes and CCR7⁺ dendritic cells day 3–4) | {fold('S01-A', 'PSLN-344', 'PSLN-212', '16h')}, {gm_ratio}, {ccl2}, {mono_ratio}, {mig_ratio} [S01-A, S02-F, S09-A, S01-D, S02-A] | Yes for the middle links: interferon-receptor loss, GM-CSF add-back, CCR2 block [S02-H, S02-G, S07-B, S02-I] | Not as measured (lung tissue). As nasal-lining-fluid protein and nasal or blood transcripts: plausible, untested | **Carry forward as a pharmacodynamic marker** |
| HAI and neutralising titre | {fold('S03-C', 'PSLN-344', 'PSLN-212', geo=True)} and {fold('S03-D', 'PSLN-344', 'PSLN-212', geo=True)} [S03-C, S03-D] | Not for cross-subtype or day-2/3 protection; the 1:40 threshold mis-called the PSLN-212 arm | Yes; standard serum assays | Carry as the regulatory immunogenicity read-out, not as the efficacy marker |
| Cross-reactive CD8 (IFN-γ after re-stimulation with a virus not in the vaccine); lung-resident memory CD8 | {fold('S05-F', 'PSLN-344', 'PSLN-212')} and {fold('S05-I', 'PSLN-344', 'PSLN-212')} [S05-F, S05-I] | Plausible; untested | Blood ELISpot or intracellular staining yes; lung-resident cells no | Carry as an exploratory read-out; first in line for Study 2 |
| IgG2a/IgG1 quotient | {q_h1['PSLN-344']/q_h1['PSLN-212']:.1f}× [S13-A, S13-B] | No evidence | Serum, but no clean human counterpart *[external]* | Do not carry |
| CD40, CD86 on lymph-node dendritic cells | {fold('S02-D CD40', 'PSLN-344', 'PSLN-212')}, {fold('S02-D CD86', 'PSLN-344', 'PSLN-212')}, but only {pct_of('S02-D CD40', 'PSLN-344', 'PSLN-212(Y)')} and {pct_of('S02-D CD86', 'PSLN-344', 'PSLN-212(Y)')} of young [S02-D] | Protection returned without them | No | Drop |
| Follicular regulatory T cells | Day 7 yes, day 30 no [S04-B, S04-C] | No evidence | No | Drop |
| Alveolar macrophage, NK, neutrophil percentages | No difference between PSLN-344 and PSLN-212 [S11-A, S11-D]; neutrophil block unusable (D06) | – | – | Drop |

**Verdict: yes, carry the early interferon-β/GM-CSF/monocyte–dendritic-cell response forward, as a pharmacodynamic marker.** Four reasons come from our data. It sits at the step that fails with age: PSLN-212 gives aged mice {pct_of('S01-A', 'PSLN-212', 'PSLN-212(Y)', '16h')} of the young *Ifnb1* response and PSLN-344 gives {pct_of('S01-A', 'PSLN-344', 'PSLN-212(Y)', '16h')} [S01-A]. It responds to dose between 5 and 20 µg ({d344_5}-, {d344_10}- and {d344_20}-fold) and then flattens ({d344_40}-fold at 40 µg) [S08-A]. Its middle links are the only part of the mechanism with intervention evidence. And it reads out within three days, which is when a dose-escalation study needs an answer. If the panel has to be cut to two analytes, they are GM-CSF, which is essentially off without Mn ({gm36b}-fold, against {A('S02-F', 'Sham', time='36h')}-fold for sham) and on with it ({gm36}-fold) and which raises the dendritic-cell population when supplied from outside [S02-F, S02-G], and an interferon read-out, which is dose-responsive and restored to the young level [S01-A, S08-A].

**It is not a surrogate for protection, and the file gives three reasons.**

- No animal has both a biomarker and an outcome; every association is between group means, and there are only four or five groups. Every restored read-out is collinear with every other, so the data cannot rank one candidate above another.
- The relation is a step, not a slope (Figure 5a). Groups whose 16-hour *Ifnb1* was {ifn212}-fold or less survived {P_all['b']}/{P_all['n2']} (PSLN-212, aged) and {sh_all[0]}/{sh_all[1]} (sham), with one exception, the cGAMP particle at {ifnCMP}-fold, which survived {SV('S03-I', 'CMP-204')} in its single experiment; groups at {ifn344}-fold or more survived {P_all['a']}/{P_all['n1']} (PSLN-344, aged) and {yp212[0]}/{yp212[1]} (PSLN-212, young). In young mice PSLN-344 raises *Ifnb1* further ({ifn344Y}-fold) with no survival left to gain ({yp344[0]}/{yp344[1]}) [S01-A; Tables 1 and 1b]. The marker can say the pathway is engaged; it cannot say how much protection follows.
- The same pathway, pushed harder or for longer, is the reactogenicity signal (§2.5). The marker has to be read with an upper bound as well as a lower one.

![Figure 5](figures/fig5_biomarker_vs_survival.png)

*Figure 5. Group-level relation between (a) the early interferon response and survival and (b) HAI titre and survival against the matched virus. Different animals supplied the marker and the outcome. The CMP-204 and PSLN-212 survival values in panel b, and the CMP-204 point in panel a, are S03-I as printed (D02).*

**Could it go into patients?** Not in the form we measured. The patient-compatible form *[external, standard sampling methods]* is: nasal-lining-fluid protein (interferon-β or its stable surrogate CXCL10, GM-CSF, CCL2) at baseline, 16–24 h and 72 h; an interferon-stimulated-gene and monocyte transcript panel in nasal curettage and whole blood at the same times; blood monocyte phenotype on days 1–3. None of these has been measured in our animals. Study 3 has to show that nasal and blood measurements track the lung response and later protection in the same animals before the marker is used to make a clinical decision.

**In what role?** As a pharmacodynamic (response) biomarker. Phase 1: proof of mechanism in older adults and dose selection (choose the lowest dose that reaches the plateau of the marker without the prolonged *Tnf*/*Il6* tail, which makes the same panel a safety read-out). Phase 2: a response marker for comparing lots, devices and regimens. It should not be used as a surrogate endpoint or to select patients. HAI and neutralisation travel alongside as the immunogenicity read-outs regulators expect *[external]*, and a blood CD8 assay against conserved internal proteins as the exploratory read-out closest to the proposed mechanism.
""")

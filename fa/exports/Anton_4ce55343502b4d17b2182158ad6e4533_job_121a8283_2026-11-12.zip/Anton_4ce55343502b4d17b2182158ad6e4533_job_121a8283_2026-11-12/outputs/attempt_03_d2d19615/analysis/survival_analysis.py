import pandas as pd, numpy as np, itertools, math
from scipy import stats
from parse_blocks import surv
pd.set_option('display.width', 260); pd.set_option('display.max_rows', 800); pd.set_option('display.max_columns', 60)

def logrank_stat(t, e, g):
    """standard two-group log-rank O-E and variance for group g==1"""
    t = np.asarray(t, float); e = np.asarray(e, int); g = np.asarray(g, int)
    OE = 0.0; V = 0.0
    for tt in np.unique(t[e == 1]):
        at_risk = t >= tt
        n = at_risk.sum(); n1 = (at_risk & (g == 1)).sum()
        d = ((t == tt) & (e == 1)).sum(); d1 = ((t == tt) & (e == 1) & (g == 1)).sum()
        OE += d1 - d * n1 / n
        if n > 1:
            V += d * (n1 / n) * (1 - n1 / n) * (n - d) / (n - 1)
    return OE, V

def logrank_tests(t1, e1, t2, e2, max_enum=400000, seed=1):
    """returns asymptotic chi2 p and exact (full enumeration) permutation p for two groups"""
    t = np.r_[t1, t2]; e = np.r_[e1, e2]
    n1 = len(t1); n = len(t)
    g = np.r_[np.ones(n1, int), np.zeros(len(t2), int)]
    OE, V = logrank_stat(t, e, g)
    if V == 0:
        return dict(chi2=np.nan, p_asym=1.0, p_exact=1.0)
    chi2 = OE**2 / V
    p_asym = stats.chi2.sf(chi2, 1)
    ncomb = math.comb(n, n1)
    obs = abs(OE)
    cnt = 0; tot = 0
    if ncomb <= max_enum:
        for idx in itertools.combinations(range(n), n1):
            gg = np.zeros(n, int); gg[list(idx)] = 1
            oe, _ = logrank_stat(t, e, gg)
            tot += 1
            if abs(oe) >= obs - 1e-12: cnt += 1
        p_exact = cnt / tot
    else:
        rng = np.random.default_rng(seed)
        B = 200000
        for _ in range(B):
            gg = np.zeros(n, int); gg[rng.choice(n, n1, replace=False)] = 1
            oe, _ = logrank_stat(t, e, gg)
            if abs(oe) >= obs - 1e-12: cnt += 1
        p_exact = (cnt + 1) / (B + 1)
    return dict(chi2=chi2, p_asym=p_asym, p_exact=p_exact)

def cp_ci(k, n, a=0.05):
    lo = 0.0 if k == 0 else stats.beta.ppf(a/2, k, n-k+1)
    hi = 1.0 if k == n else stats.beta.ppf(1-a/2, k+1, n-k)
    return lo, hi

def summarize(block):
    d = surv[surv.block == block]
    out = []
    for g, x in d.groupby('group', sort=False):
        n = len(x); deaths = int(x.event.sum()); alive = n - deaths
        lo, hi = cp_ci(alive, n)
        dd = sorted(x[x.event == 1].time.dropna().astype(int).tolist())
        # KM median: smallest t with S(t) <= 0.5
        med = np.nan
        tt = x.time.values; ee = x.event.values
        if deaths / n >= 0.5:
            s = 1.0
            for u in sorted(set(tt[ee == 1])):
                nr = (tt >= u).sum(); du = ((tt == u) & (ee == 1)).sum()
                s *= 1 - du / nr
                if s <= 0.5: med = u; break
        out.append(dict(block=block, group=g, n=n, deaths=deaths, survivors=alive, surv_pct=100*alive/n,
                        ci95_lo=100*lo, ci95_hi=100*hi, death_days=dd, median_surv_d=med,
                        cells=f"{x.time_cell.iloc[0]}:{x.event_cell.iloc[-1]}", n_missing_time=int(x.time.isna().sum())))
    return pd.DataFrame(out)

def compare(block, g1, g2):
    d = surv[surv.block == block]
    a = d[d.group == g1]; b = d[d.group == g2]
    a2 = a.dropna(subset=['time']); b2 = b.dropna(subset=['time'])
    fe = stats.fisher_exact([[int((a.event == 0).sum()), int(a.event.sum())], [int((b.event == 0).sum()), int(b.event.sum())]])
    lr = logrank_tests(a2.time.values, a2.event.values, b2.time.values, b2.event.values)
    return dict(block=block, g1=g1, g2=g2, s1=f"{int((a.event==0).sum())}/{len(a)}", s2=f"{int((b.event==0).sum())}/{len(b)}",
                fisher_p=fe[1], logrank_p_asym=lr['p_asym'], logrank_p_exact=lr['p_exact'])

if __name__ == '__main__':
    allsum = pd.concat([summarize(b) for b in surv.block.unique()], ignore_index=True)
    print(allsum.to_string())
    allsum.to_csv('survival_summary.csv', index=False)
    comps = []
    for b in surv.block.unique():
        gs = list(surv[surv.block == b].group.unique())
        for g1, g2 in itertools.combinations(gs, 2):
            comps.append(compare(b, g1, g2))
    comps = pd.DataFrame(comps)
    comps.to_csv('survival_pairwise.csv', index=False)
    print(comps.to_string())

"""Helpers that fetch a number from the parsed workbook, format it, and register it in the evidence ledger
(block, quantity, value, n, sheet!cells, how it was reduced). Every number printed in the memo comes through here."""
import pandas as pd, numpy as np, math, re, warnings
from scipy import stats
from openpyxl.utils import column_index_from_string as cidx, get_column_letter as gcl
from parse_blocks import tidy, surv
warnings.filterwarnings('ignore')

from decimal import Decimal, ROUND_HALF_UP
def fx(x, dec, comma=False):
    """conventional (half-up) rounding on the decimal value, so that e.g. 5.05 prints as 5.1 and not 5.0"""
    q = Decimal(1).scaleb(-dec) if dec > 0 else Decimal(1)
    d = Decimal(repr(round(float(x), 9))).quantize(q, rounding=ROUND_HALF_UP)
    return f'{d:,}' if comma else str(d)

LEDGER = []
_seen = set()
def reg(block, quantity, value, cells, reduction, n=''):
    key = (block, quantity, str(value))
    if key in _seen: return
    _seen.add(key)
    LEDGER.append(dict(block=block, quantity=quantity, value=value, n=n, cells=cells, reduction=reduction))

HAI = {'S03-C', 'S03-G'}
TITRE = {'S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-A', 'S13-B', 'S13-C', 'S13-D', 'S13-I', 'S13-J'}

def _split(c):
    m = re.match(r'([A-Z]+)(\d+)$', c); return m.group(1), int(m.group(2))
def cellrange(d, sheet=None):
    cs = [_split(c) for c in d.cell]
    cols = sorted({cidx(c) for c, _ in cs}); rows = sorted({r for _, r in cs})
    sh = sheet or d.sheet.iloc[0]
    a = f'{gcl(cols[0])}{rows[0]}'; b = f'{gcl(cols[-1])}{rows[-1]}'
    return f'{sh}!{a}' if a == b else f'{sh}!{a}:{b}'

def sel(block, group, panel=None, time=None):
    d = tidy[(tidy.block == block) & (tidy.group == group)]
    if panel is not None: d = d[d.panel == panel]
    if time is not None: d = d[d.time.astype(str) == str(time)]
    d = d[d.value.notna()].copy()
    assert len(d) > 0, (block, group, panel, time)
    d['value'] = d.value.astype(float)
    return d

def _lab(group, panel, time):
    s = group
    if panel: s += f' · {panel}'
    if time is not None: s += f' · t={time}'
    return s

def A(block, group, panel=None, time=None, dec=1, raw=False):
    """arithmetic mean of per-animal values"""
    d = sel(block, group, panel, time); m = d.value.mean()
    reg(block, f'mean, {_lab(group, panel, time)}', round(m, 3), cellrange(d), 'arithmetic mean of the per-animal values', len(d))
    return m if raw else fx(m, dec)

def SDv(block, group, panel=None, time=None, dec=1):
    d = sel(block, group, panel, time); s = d.value.std(ddof=1)
    reg(block, f'SD, {_lab(group, panel, time)}', round(s, 3), cellrange(d), 'sample standard deviation (n-1) of the per-animal values', len(d))
    return fx(s, dec)

def MINv(block, group, panel=None, time=None, dec=1):
    d = sel(block, group, panel, time); s = d.value.min()
    reg(block, f'minimum, {_lab(group, panel, time)}', round(s, 3), cellrange(d), 'smallest per-animal value', len(d))
    return fx(s, dec)

def G(block, group, dec=0, raw=False):
    """geometric mean titre"""
    d = sel(block, group); x = d.value.values.copy()
    note = 'geometric mean of reciprocal titres (mean of log10, back-transformed)'
    if block in HAI:
        x = np.where(x < 10, 5.0, x); note += '; values below the 1:10 starting dilution (printed 0) set to 5'
    g = 10 ** np.log10(x).mean()
    reg(block, f'geometric mean titre, {group}', round(g, 1), cellrange(d), note, len(d))
    return g if raw else fx(g, dec, comma=True)

def CNT(block, group, thr):
    d = sel(block, group); k = int((d.value >= thr).sum())
    reg(block, f'animals with titre >= {thr}, {group}', f'{k}/{len(d)}', cellrange(d), f'count of per-animal titres >= {thr}', len(d))
    return f'{k}/{len(d)}'

def F9(analyte, group, side='cols A-U', dec=None, raw=False):
    """S09-A: values stored as log10 fold; report geometric-mean fold"""
    d = sel('S09-A', group, f'{side}|{analyte}'); g = 10 ** d.value.mean()
    reg('S09-A', f'geometric-mean fold, {analyte}, {group}, panel at {side}', round(g, 3), cellrange(d), 'mean of the stored log10 values, back-transformed (10^mean)', len(d))
    if raw: return g
    if dec is None: dec = 0 if g >= 10 else 1
    return fx(g, dec, comma=True)

def svd(block, group):
    d = surv[(surv.block == block) & (surv.group == group)]
    assert len(d) > 0, (block, group)
    return d
def SV(block, group, raw=False):
    d = svd(block, group); alive = int((d.event == 0).sum()); n = len(d)
    cells = f'{d.sheet.iloc[0]}!{d.time_cell.iloc[0]}:{d.event_cell.iloc[-1]}'
    days = sorted(d[d.event == 1].time.dropna().astype(int).tolist())
    reg(block, f'survivors/total, {group}', f'{alive}/{n}', cells, f'rows with event flag 0 at end of observation / all rows printed for the group; death days {days}', n)
    return (alive, n) if raw else f'{alive}/{n}'

def FISH(block, g1, g2):
    a, n1 = SV(block, g1, raw=True); b, n2 = SV(block, g2, raw=True)
    p = stats.fisher_exact([[a, n1 - a], [b, n2 - b]])[1]
    reg(block, f'Fisher exact p, survival {g1} vs {g2}', float(f'{p:.2g}'), f'as for the two survivor counts', "Fisher's exact test, two-sided, on survivors vs deaths", n1 + n2)
    return fmt_p(p)

_SUP = str.maketrans('0123456789-', '⁰¹²³⁴⁵⁶⁷⁸⁹⁻')
def sci(p):
    m, e = f'{p:.0e}'.split('e')
    return f'{m}×10{str(int(e)).translate(_SUP)}'
def fmt_p(p):
    if p < 0.0001: return sci(p)
    if p < 0.001: return f'{p:.4f}'
    if p < 0.01: return f'{p:.3f}'
    return f'{p:.2f}'

C = pd.read_csv('all_pairwise_contrasts.csv')
def _ct(block, g1, g2, panel=None, time=None):
    d = C[C.block == block]
    if panel is not None: d = d[d.panel.fillna('') == panel]
    if time is not None: d = d[d.time.astype(str).str.replace(r'\.0$', '', regex=True) == str(time)]
    a = d[(d.g1 == g1) & (d.g2 == g2)]; b = d[(d.g1 == g2) & (d.g2 == g1)]
    if len(a) == 1: return a.iloc[0], False
    if len(b) == 1: return b.iloc[0], True
    raise KeyError((block, g1, g2, panel, time, len(a), len(b)))

def CT(block, g1, g2, panel=None, time=None, dec=1, what='effect', ci=True):
    """contrast g1 vs g2. log-scale blocks -> ratio of geometric means g1/g2; raw blocks -> difference of means g1-g2."""
    r, flip = _ct(block, g1, g2, panel, time)
    ratio = r.test_scale == 'log10'
    if ratio:
        e, lo, hi = (1 / r.effect, 1 / r.ci_hi, 1 / r.ci_lo) if flip else (r.effect, r.ci_lo, r.ci_hi)
        kind = 'ratio of geometric means (Welch interval on log10 values)'
    else:
        e, lo, hi = (-r.effect, -r.ci_hi, -r.ci_lo) if flip else (r.effect, r.ci_lo, r.ci_hi)
        kind = 'difference of arithmetic means (Welch 95% interval)'
    d1 = sel(block, g1, panel, time); d2 = sel(block, g2, panel, time)
    cells = f'{cellrange(d1)} vs {cellrange(d2).split("!")[1]}'
    reg(block, f'{g1} vs {g2}{" · " + panel if panel else ""}{" · t=" + str(time) if time is not None else ""}: {"ratio" if ratio else "difference"} (95% CI)',
        f'{e:.3g} ({lo:.3g} to {hi:.3g})', cells, kind, int(r.n1 + r.n2))
    if what == 'raw': return e, lo, hi
    if ratio:
        return f'{e:.{dec}f}× (95% CI {lo:.{dec}f}–{hi:.{dec}f})' if ci else f'{e:.{dec}f}×'
    return f'{e:+.{dec}f} (95% CI {lo:+.{dec}f} to {hi:+.{dec}f})' if ci else f'{e:+.{dec}f}'

def PV(block, g1, g2, panel=None, time=None, kind='tukey'):
    r, _ = _ct(block, g1, g2, panel, time)
    col = {'tukey': 'tukey_p', 'welch': 'welch_p', 'mw': 'mw_exact_p'}[kind]
    p = r[col]
    desc = {'tukey': f'one-way ANOVA across the {int(r.n_groups_in_anova)} groups printed in the block, Tukey HSD pairwise p ({"log10 values" if r.test_scale == "log10" else "raw values"})',
            'welch': f'Welch t test, two-sided ({"log10 values" if r.test_scale == "log10" else "raw values"})',
            'mw': 'exact Mann-Whitney U test, two-sided'}[kind]
    d1 = sel(block, g1, panel, time); d2 = sel(block, g2, panel, time)
    reg(block, f'{g1} vs {g2}{" · " + panel if panel else ""}{" · t=" + str(time) if time is not None else ""}: p ({kind})', float(f'{p:.2g}'),
        f'{cellrange(d1)} vs {cellrange(d2).split("!")[1]}', desc, int(r.n1 + r.n2))
    return fmt_p(p)

def pct_of(block, g, ref, panel=None, time=None, geo=False, dec=0):
    if geo: a = G(block, g, raw=True); b = G(block, ref, raw=True)
    else: a = A(block, g, panel, time, raw=True); b = A(block, ref, panel, time, raw=True)
    return f'{100 * a / b:.{dec}f}%'

def fold(block, g, ref, panel=None, time=None, geo=False, dec=1):
    if geo: a = G(block, g, raw=True); b = G(block, ref, raw=True)
    else: a = A(block, g, panel, time, raw=True); b = A(block, ref, panel, time, raw=True)
    return f'{a / b:.{dec}f}×'

def pct_change(block, g, ref, panel=None, time=None, dec=0):
    a = A(block, g, panel, time, raw=True); b = A(block, ref, panel, time, raw=True)
    return f'{100 * (a - b) / b:+.{dec}f}%'.replace('+', '+').replace('-', '−')

# ---------- pooled survival ----------
def cp_ci(k, n, a=0.05):
    lo = 0.0 if k == 0 else stats.beta.ppf(a / 2, k, n - k + 1)
    hi = 1.0 if k == n else stats.beta.ppf(1 - a / 2, k + 1, n - k)
    return lo, hi

def pooled(T):
    a, n1, b, n2 = int(T.s344.sum()), int(T.n344.sum()), int(T.s212.sum()), int(T.n212.sum())
    w = T.n344 * T.n212 / (T.n344 + T.n212)
    rd = ((T.s344 / T.n344 - T.s212 / T.n212) * w).sum() / w.sum()
    num = ((T.s344 * (T.n344 - T.s344) * T.n212 ** 3 + T.s212 * (T.n212 - T.s212) * T.n344 ** 3) / (T.n344 * T.n212 * (T.n344 + T.n212) ** 2)).sum()
    se = math.sqrt(num) / w.sum()
    dist = np.array([1.0]); obs = 0; exp = 0
    for _, r in T.iterrows():
        N = int(r.n344 + r.n212); K = int(r.s344 + r.s212)
        dist = np.convolve(dist, stats.hypergeom(N, K, int(r.n344)).pmf(np.arange(0, int(r.n344) + 1)))
        obs += r.s344; exp += r.n344 * K / N
    x = np.arange(len(dist)); p = dist[np.abs(x - exp) >= abs(obs - exp) - 1e-9].sum()
    return dict(a=a, n1=n1, b=b, n2=n2, rd=100 * rd, lo=100 * (rd - 1.96 * se), hi=100 * (rd + 1.96 * se), p=p, k=len(T),
                pa=100 * a / n1, pb=100 * b / n2, cia=[100 * v for v in cp_ci(a, n1)], cib=[100 * v for v in cp_ci(b, n2)])

def pooled_txt(T, name, blocks_desc):
    r = pooled(T)
    reg('pooled survival', f'{name}: PSLN-344 vs PSLN-212 survivors', f"{r['a']}/{r['n1']} vs {r['b']}/{r['n2']}", blocks_desc,
        'sum of survivors and animals over the listed comparisons', r['n1'] + r['n2'])
    reg('pooled survival', f'{name}: risk difference (95% CI), exact stratified p', f"{r['rd']:.1f} ({r['lo']:.1f} to {r['hi']:.1f}); p={r['p']:.1e}", blocks_desc,
        'Mantel-Haenszel risk difference stratified by comparison (Greenland-Robins variance); p from the exact permutation distribution of total PSLN-344 survivors with margins fixed within each comparison', r['n1'] + r['n2'])
    return r

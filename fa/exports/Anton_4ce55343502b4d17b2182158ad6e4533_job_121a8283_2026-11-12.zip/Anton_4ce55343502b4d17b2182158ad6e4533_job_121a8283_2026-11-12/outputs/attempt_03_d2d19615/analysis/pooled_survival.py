import pandas as pd, numpy as np, itertools, math
from scipy import stats
from parse_blocks import surv
from survival_analysis import cp_ci, logrank_stat
pd.set_option('display.width', 260); pd.set_option('display.max_rows', 800); pd.set_option('display.max_columns', 60)

# ---- experiment registry: aged (or middle-aged) animals, PSLN-344 vs PSLN-212 head-to-head ----
# (block, 344 label, 212 label, sham label, young label, strain/age, vaccine, challenge, challenge day, relationship, flags)
REG = [
 ('S03-I', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'BALB/c aged', 'bivalent H1N1+H3N2', '10x mLD50 CA09 H1N1', 'd14', 'homologous (H1N1 component)', 'group labels conflict with paired weight block S13-F'),
 ('S03-J', 'PSLN-344', 'PSLN-212', 'Sham', None, 'BALB/c (age not stated in block)', 'rgH5N1', 'wild-type VN04 H5N1 (dose not stated)', 'd2', 'homologous HA/NA, too early for antibody', 'stated n=9 but 10 rows; one PSLN-344 row has no day value (J46); labels conflict with S13-G'),
 ('S06-A', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'BALB/c aged', 'Aichi H3N2', '5x mLD50 PR8 H1N1', 'd14', 'heterosubtypic', ''),
 ('S06-B', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'BALB/c aged', 'Aichi H3N2', '5x mLD50 PR8 H1N1', 'd3', 'heterosubtypic', ''),
 ('S06-C', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'BALB/c aged', 'bivalent H1N1+H3N2', '5x mLD50 rgH5N1', 'd14', 'heterosubtypic (H5; N1 shared subtype)', 'block is row-for-row identical to S06-D'),
 ('S06-D', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'BALB/c aged', 'bivalent H1N1+H3N2', '5x mLD50 rgH5N1', 'd3', 'heterosubtypic (H5; N1 shared subtype)', 'DUPLICATE of S06-C (row-for-row); paired weights S15-D disagree'),
 ('S06-E (rows 34-68)', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'BALB/c aged', 'Aichi H3N2', '5x mLD50 PR8 H1N1', 'd60', 'heterosubtypic', 'unchallenged Untreated arm: 1/7 died'),
 ('S06-F (rows 34-68)', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'BALB/c aged', 'bivalent H1N1+H3N2', '5x mLD50 rgH5N1', 'd60', 'heterosubtypic (H5; N1 shared subtype)', 'unchallenged Untreated arm: 0/7 died'),
 ('S06-G', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'BALB/c aged', 'CA09 H1N1', '5x mLD50 Perth H3N2', 'd60', 'heterosubtypic', 'unchallenged Untreated arm: 3/7 died'),
 ('S06-E (rows 71-105)', 'Naïve+PSLN-344', 'Naïve+PSLN-212', None, None, 'BALB/c 14 mo, saline at 10 mo', 'bivalent H1N1+H3N2', '5x LD50 PR8 H1N1', 'not stated', 'heterosubtypic-within-H1 (CA09 vs PR8)', 'duplicate block label (second "S06-E")'),
 ('S06-E (rows 71-105)', 'Imprinting+PSLN-344', 'Imprinting+PSLN-212', None, None, 'BALB/c 14 mo, PR8 survivors', 'bivalent H1N1+H3N2', '5x LD50 PR8 H1N1', 'not stated', 'homologous to imprinting virus', 'duplicate block label; survivor-selected cohort'),
 ('S06-F (rows 71-105)', 'Naïve+PSLN-344', 'Naïve+PSLN-212', None, None, 'BALB/c 14 mo, saline at 10 mo', 'bivalent H1N1+H3N2', '5x LD50 Perth H3N2', 'd14', 'drifted H3N2 (Aichi 1968 vs Perth 2009)', 'duplicate block label (second "S06-F")'),
 ('S06-F (rows 71-105)', 'Imprinting+PSLN-344', 'Imprinting+PSLN-212', None, None, 'BALB/c 14 mo, PR8 survivors', 'bivalent H1N1+H3N2', '5x LD50 Perth H3N2', 'd14', 'drifted H3N2', 'duplicate block label; survivor-selected cohort'),
 ('S15-L', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'C57BL/6 20 mo', 'bivalent H1N1+H3N2', 'not stated', 'not stated', 'not stated', 'challenge virus/day not stated; young arm 1 death not reflected in weights S15-M'),
 ('S15-N', 'PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)', 'Swiss Webster 20 mo (outbred)', 'bivalent H1N1+H3N2', 'not stated', 'not stated', 'not stated', 'challenge virus/day not stated'),
]
def counts(block, grp):
    d = surv[(surv.block == block) & (surv.group == grp)]
    return int((d.event == 0).sum()), len(d)

rows = []
for (blk, g344, g212, gsh, gy, strain, vac, chal, day, rel, flag) in REG:
    a = counts(blk, g344); b = counts(blk, g212)
    r = dict(block=blk, arm344=g344, strain_age=strain, vaccine=vac, challenge=chal, challenge_day=day, relationship=rel,
             s344=a[0], n344=a[1], s212=b[0], n212=b[1], flag=flag)
    if gsh: r['sSham'], r['nSham'] = counts(blk, gsh)
    if gy: r['sY'], r['nY'] = counts(blk, gy)
    r['fisher_p_344_vs_212'] = stats.fisher_exact([[a[0], a[1]-a[0]], [b[0], b[1]-b[0]]])[1]
    r['risk_diff'] = a[0]/a[1] - b[0]/b[1]
    rows.append(r)
T = pd.DataFrame(rows)
print(T.drop(columns=['vaccine', 'challenge', 'relationship', 'flag']).to_string())
T.to_csv('aged_head_to_head_survival.csv', index=False)

def pooled(T, label):
    a, n1, b, n2 = T.s344.sum(), T.n344.sum(), T.s212.sum(), T.n212.sum()
    lo1, hi1 = cp_ci(a, n1); lo2, hi2 = cp_ci(b, n2)
    # Mantel-Haenszel risk difference (Greenland-Robins variance)
    w = T.n344 * T.n212 / (T.n344 + T.n212)
    rd = ((T.s344 / T.n344 - T.s212 / T.n212) * w).sum() / w.sum()
    num = ((T.s344 * (T.n344 - T.s344) * T.n212**3 + T.s212 * (T.n212 - T.s212) * T.n344**3) / (T.n344 * T.n212 * (T.n344 + T.n212)**2)).sum()
    se = math.sqrt(num) / w.sum()
    # exact stratified permutation test on total survivors in 344 arm (sum of hypergeometrics, convolution)
    dist = np.array([1.0])
    obs = 0; exp = 0
    for _, r in T.iterrows():
        N = r.n344 + r.n212; K = r.s344 + r.s212
        pm = stats.hypergeom(N, K, r.n344).pmf(np.arange(0, r.n344 + 1))
        dist = np.convolve(dist, pm)
        obs += r.s344; exp += r.n344 * K / N
    x = np.arange(len(dist))
    p_two = dist[np.abs(x - exp) >= abs(obs - exp) - 1e-9].sum()
    # CMH chi-square
    varsum = sum((r.n344 * r.n212 * (r.s344 + r.s212) * (r.n344 + r.n212 - r.s344 - r.s212)) / ((r.n344 + r.n212)**2 * (r.n344 + r.n212 - 1)) for _, r in T.iterrows())
    cmh = (abs(obs - exp) - 0.5)**2 / varsum if varsum > 0 else np.nan
    print(f'[{label}] strata={len(T)}  PSLN-344 {a}/{n1} = {100*a/n1:.1f}% (95% CI {100*lo1:.1f}-{100*hi1:.1f})  vs PSLN-212 {b}/{n2} = {100*b/n2:.1f}% ({100*lo2:.1f}-{100*hi2:.1f});'
          f'  MH risk difference {100*rd:.1f} pts (95% CI {100*(rd-1.96*se):.1f} to {100*(rd+1.96*se):.1f});  exact stratified p = {p_two:.2e};  CMH chi2 = {cmh:.1f}')
    return dict(label=label, strata=len(T), s344=a, n344=n1, s212=b, n212=n2, rd=rd, rd_lo=rd-1.96*se, rd_hi=rd+1.96*se, p_exact=p_two)

res = []
res.append(pooled(T, 'A. all 15 strata as printed (includes duplicate S06-D)'))
U = T[T.block != 'S06-D']
res.append(pooled(U, 'B. PRIMARY: as printed, duplicate S06-D removed (14 strata)'))
res.append(pooled(U[~U.block.isin(['S03-I', 'S03-J'])], 'C. also drop label-conflicted S03-I, S03-J (12 strata)'))
res.append(pooled(U[U.strain_age == 'BALB/c aged'], 'D. BALB/c >=20 mo only, dup removed'))
res.append(pooled(U[U.relationship.str.startswith('heterosubtypic') & (U.strain_age == 'BALB/c aged')], 'E. BALB/c aged heterosubtypic only (S06-A,B,C,E,F,G)'))
res.append(pooled(U[U.challenge_day == 'd60'], 'F. durability: day-60 challenges (S06-E,F,G)'))
res.append(pooled(U[U.challenge_day.isin(['d2', 'd3'])], 'G. early: day-2/3 challenges (S03-J, S06-B)'))
res.append(pooled(U[U.block.isin(['S15-L', 'S15-N'])], 'H. other strains (C57BL/6, Swiss Webster)'))
res.append(pooled(U[U.block.str.contains('71-105')], 'I. 14-month imprinting cohorts'))

# sensitivity: replace table counts with weight-block-implied survivors where the paired weight block disagrees
W = U.copy()
alt = {  # block -> (s344, s212) implied by paired weight block (blank or frozen-low trajectories = deaths)
  'S03-I': (7, 3),            # S13-F: "PSLN-212" has 4 frozen + 3 recovering
  'S06-C': (7, 1),            # S15-C
  'S06-E (rows 34-68)': (6, 1),   # S15-E
  'S06-G': (5, 0),            # S15-G
}
for k, (a, b) in alt.items():
    W.loc[(W.block == k), ['s344', 's212']] = [a, b]
res.append(pooled(W, 'J. sensitivity: weight-implied counts where blocks disagree (S03-I 7/7 v 3/7; S06-C 7/7 v 1/7; S06-E 6/7 v 1/7; S06-G 5/7 v 0/7)'))
# worst case for PSLN-344: for each stratum take the lower 344 count and higher 212 count among table/weights, S03-J 344 n=9 (drop missing-time animal), add S06-D from weights (5/7 vs 2/7)
WC = U.copy()
worst = {'S03-I': (7, 3), 'S06-C': (6, 2), 'S06-E (rows 34-68)': (5, 1), 'S06-G': (4, 0)}
for k, (a, b) in worst.items():
    WC.loc[(WC.block == k), ['s344', 's212']] = [a, b]
WC.loc[WC.block == 'S03-J', ['s344', 'n344']] = [9, 9]
extra = T[T.block == 'S06-D'].copy(); extra[['s344', 's212']] = [5, 2]
WC = pd.concat([WC, extra])
res.append(pooled(WC, 'K. worst-case for PSLN-344 (least favourable count from table or weights in every stratum; S06-C 6/7 (implausible weight recovery of one animal); S06-D taken from weights 5/7 v 2/7; S03-J 9/9)'))
pd.DataFrame(res).to_csv('pooled_survival.csv', index=False)

# ---- PSLN-344 aged vs young benchmark, and vs Sham ----
V = U[U.sY.notna()] if 'sY' in U else None
a, n1, b, n2 = int(V.s344.sum()), int(V.n344.sum()), int(V.sY.sum()), int(V.nY.sum())
print(f'\nAged PSLN-344 vs young PSLN-212(Y) in the same experiments ({len(V)} strata, dup removed): {a}/{n1} = {100*a/n1:.1f}% vs {b}/{n2} = {100*b/n2:.1f}%; Fisher p = {stats.fisher_exact([[a, n1-a],[b, n2-b]])[1]:.4f}')
S_ = U[U.sSham.notna()]
a, n1, b, n2 = int(S_.s344.sum()), int(S_.n344.sum()), int(S_.sSham.sum()), int(S_.nSham.sum())
print(f'Aged PSLN-344 vs aged Sham ({len(S_)} strata): {a}/{n1} vs {b}/{n2}')
a, n1, b, n2 = int(S_.s212.sum()), int(S_.n212.sum()), int(S_.sSham.sum()), int(S_.nSham.sum())
print(f'Aged PSLN-212 vs aged Sham ({len(S_)} strata): {a}/{n1} = {100*a/n1:.1f}% vs {b}/{n2} = {100*b/n2:.1f}%; Fisher p = {stats.fisher_exact([[a, n1-a],[b, n2-b]])[1]:.4f}')

# ---- day-60 PSLN-344 vs unchallenged Untreated ----
d60 = ['S06-E (rows 34-68)', 'S06-F (rows 34-68)', 'S06-G']
u = surv[surv.block.isin(d60) & (surv.group == 'Untreated')]; p = surv[surv.block.isin(d60) & (surv.group == 'PSLN-344')]
ud, un, pd_, pn = int(u.event.sum()), len(u), int(p.event.sum()), len(p)
print(f'\nDay-60 cohorts: deaths in unchallenged Untreated aged = {ud}/{un} ({100*ud/un:.0f}%), CP95 {[round(100*x,1) for x in cp_ci(ud, un)]}; deaths in challenged PSLN-344 = {pd_}/{pn} ({100*pd_/pn:.0f}%); Fisher p = {stats.fisher_exact([[ud, un-ud],[pd_, pn-pd_]])[1]:.3f}')
d14 = ['S06-A', 'S06-C', 'S03-I']
p14 = surv[surv.block.isin(d14) & (surv.group == 'PSLN-344')]
print(f'Day-14 BALB/c aged PSLN-344 deaths: {int(p14.event.sum())}/{len(p14)};  day-60: {pd_}/{pn};  Fisher p = {stats.fisher_exact([[int(p14.event.sum()), len(p14)-int(p14.event.sum())],[pd_, pn-pd_]])[1]:.3f}')

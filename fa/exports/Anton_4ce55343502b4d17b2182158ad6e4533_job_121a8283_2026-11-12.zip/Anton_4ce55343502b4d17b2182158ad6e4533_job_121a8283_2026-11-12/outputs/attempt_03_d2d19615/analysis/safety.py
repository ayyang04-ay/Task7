import pandas as pd, numpy as np, warnings
from scipy import stats
from parse_blocks import tidy
warnings.filterwarnings('ignore')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)

print('===== S08-D: body weight after intranasal vaccination (no challenge), % of day 0 =====')
w = tidy[tidy.block == 'S08-D'].copy(); w['time'] = w.time.astype(int)
piv = w.pivot_table(index='time', columns='group', values='value', aggfunc='mean', sort=False)
print('group mean by day:'); print(piv.round(2).to_string())
cnt = w[w.value.notna()].pivot_table(index='time', columns='group', values='value', aggfunc='count', sort=False)
print('n with data:'); print(cnt.to_string())
an = []
for (g, rep), d in w.groupby(['group', 'rep'], sort=False):
    d = d.dropna(subset=['value'])
    nad = d.loc[d.value.idxmin()]
    an.append(dict(group=g, rep=rep, col=d.cell.iloc[0].rstrip('0123456789'), nadir=nad.value, nadir_day=nad.time, last_day=d.time.max(), last_value=d.loc[d.time.idxmax()].value))
an = pd.DataFrame(an)
print(an.groupby('group', sort=False).agg(n=('nadir', 'size'), mean_nadir=('nadir', 'mean'), min_nadir=('nadir', 'min'), median_nadir_day=('nadir_day', 'median'), mean_last=('last_value', 'mean'), min_last=('last_value', 'min'), last_day_min=('last_day', 'min')).round(2).to_string())
for g in ['PSLN-344', 'PSLN-212', 'CMP-204', 'PSLN-212/R848', 'PSLN-212(Y)']:
    a = an[an.group == g].nadir.values; b = an[an.group == 'Vaccine'].nadir.values
    print(f'  nadir {g} vs Vaccine: diff {a.mean()-b.mean():+.2f} pts; Welch p={stats.ttest_ind(a,b,equal_var=False).pvalue:.3f}; MW exact p={stats.mannwhitneyu(a,b,method="exact").pvalue:.3f}')
a = an[an.group == 'PSLN-344'].nadir.values; b = an[an.group == 'PSLN-212'].nadir.values
print(f'  nadir PSLN-344 vs PSLN-212: diff {a.mean()-b.mean():+.2f}; Welch p={stats.ttest_ind(a,b,equal_var=False).pvalue:.3f}')
a = an[an.group == 'PSLN-344'].nadir.values; b = an[an.group == 'PSLN-212/R848'].nadir.values
print(f'  nadir PSLN-344 vs PSLN-212/R848: diff {a.mean()-b.mean():+.2f}; Welch p={stats.ttest_ind(a,b,equal_var=False).pvalue:.4f}')
print('  PSLN-212/R848 per-animal series:')
print(w[w.group == 'PSLN-212/R848'].pivot(index='time', columns='rep', values='value').to_string())
print('  PSLN-344 per-animal series:')
print(w[w.group == 'PSLN-344'].pivot(index='time', columns='rep', values='value').to_string())

print('\n===== S10-A: CNS transcripts at 36 h (fold vs untreated) =====')
c = tidy[tidy.block == 'S10-A'].copy(); c['value'] = c.value.astype(float)
for an_, d in c.groupby('panel', sort=False):
    print(an_, {g: (round(x.value.mean(), 2), round(x.value.std(ddof=1), 2)) for g, x in d.groupby('group', sort=False)})
    lg = {g: np.log10(x.value.values) for g, x in d.groupby('group', sort=False)}
    tk = stats.tukey_hsd(*lg.values()); names = list(lg)
    for g2 in ['PBS', 'Sham']:
        a, b = lg['PSLN-344'], lg[g2]
        diff = a.mean() - b.mean(); se = np.sqrt(a.var(ddof=1)/5 + b.var(ddof=1)/5)
        df = se**4 / ((a.var(ddof=1)/5)**2/4 + (b.var(ddof=1)/5)**2/4); tc = stats.t.ppf(0.975, df); tc90 = stats.t.ppf(0.95, df)
        print(f'    PSLN-344 / {g2}: GM ratio {10**diff:.2f} (95% CI {10**(diff-tc*se):.2f}-{10**(diff+tc*se):.2f}; 90% CI upper {10**(diff+tc90*se):.2f}); Welch p={stats.ttest_ind(a,b,equal_var=False).pvalue:.3f}; Tukey p={tk.pvalue[names.index("PSLN-344"), names.index(g2)]:.3f}')
    a, b = lg['CT'], lg['PBS']
    print(f'    CT / PBS: GM ratio {10**(a.mean()-b.mean()):.2f}; Welch p={stats.ttest_ind(a,b,equal_var=False).pvalue:.1e}; Tukey p={tk.pvalue[names.index("CT"), names.index("PBS")]:.1e}')
    a, b = lg['CT'], lg['PSLN-344']
    print(f'    CT / PSLN-344: GM ratio {10**(a.mean()-b.mean()):.2f}; Tukey p={tk.pvalue[names.index("CT"), names.index("PSLN-344")]:.1e}')

print('\n===== S08-A: Ifnb1 dose-response at 16 h (fold vs untreated; n=3) =====')
d = tidy[tidy.block == 'S08-A'].copy(); d['value'] = d.value.astype(float); d['dose'] = d.time.astype(float)
m = d.pivot_table(index='dose', columns='group', values='value', aggfunc='mean', sort=False)
print(m.round(2).to_string())
print('ratio PSLN-344 / PSLN-212 by dose:', (m['PSLN-344'] / m['PSLN-212']).round(2).to_dict())
print('PSLN-344: response relative to 20 ug:', (m['PSLN-344'] / m.loc[20, 'PSLN-344']).round(2).to_dict())
print('PSLN-212: response relative to 20 ug:', (m['PSLN-212'] / m.loc[20, 'PSLN-212']).round(2).to_dict())
from scipy.optimize import curve_fit
def hill(x, emax, ed50, h): return 1 + (emax - 1) * x**h / (ed50**h + x**h)
for g in m.columns:
    x = d[d.group == g].dose.values; y = d[d.group == g].value.values
    try:
        p, cov = curve_fit(hill, x, y, p0=[y.max(), 10, 2], bounds=([1, 0.5, 0.3], [500, 200, 8]))
        se = np.sqrt(np.diag(cov))
        print(f'  {g}: Emax={p[0]:.1f} (SE {se[0]:.1f}), ED50={p[1]:.1f} ug (SE {se[1]:.1f}), Hill={p[2]:.2f} (SE {se[2]:.2f}); fitted at 20 ug = {hill(20,*p):.1f} = {100*(hill(20,*p)-1)/(p[0]-1):.0f}% of Emax')
    except Exception as e:
        print('  fit failed', g, e)
# what dose of PSLN-344 matches the young benchmark / PSLN-212 plateau
print('\n===== S08-B: encapsulation efficiency (%; n=3 preparations) =====')
e = tidy[tidy.block == 'S08-B'].copy(); e['value'] = e.value.astype(float)
print(e.groupby('group', sort=False).value.agg(['mean', 'std', 'min', 'max']).round(2).assign(cv_pct=lambda x: (100 * x['std'] / x['mean']).round(1)).to_string())
print('ANOVA p across 5 preparations:', round(stats.f_oneway(*[x.value.values for _, x in e.groupby('group', sort=False)]).pvalue, 3))

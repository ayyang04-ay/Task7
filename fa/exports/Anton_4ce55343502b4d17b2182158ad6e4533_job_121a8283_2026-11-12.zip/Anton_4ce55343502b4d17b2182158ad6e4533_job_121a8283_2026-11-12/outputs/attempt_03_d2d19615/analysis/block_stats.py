import pandas as pd, numpy as np, itertools, warnings
from scipy import stats
from parse_blocks import tidy
warnings.filterwarnings('ignore')
pd.set_option('display.width', 260); pd.set_option('display.max_rows', 2000); pd.set_option('display.max_columns', 60)

v = tidy[(tidy.kind == 'value')].copy()
v = v[v.value.notna()]
v['value'] = v.value.astype(float)

TITRE_BLOCKS = {'S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-A', 'S13-B', 'S13-C', 'S13-D', 'S13-I', 'S13-J'}
HAI_BLOCKS = {'S03-C', 'S03-G'}   # lowest dilution tested 1:10 ; zeros = below LOD -> 5 (LOD/2) for GMT

def cellrange(d):
    return f"{d.sheet.iloc[0]}!{d.cell.iloc[0]}:{d.cell.iloc[-1]}"

rows = []
for (blk, panel, tm, grp), d in v.groupby(['block', 'panel', 'time', 'group'], dropna=False, sort=False):
    x = d.value.values
    r = dict(block=blk, panel=panel, time=tm, group=grp, n=len(x), cells=cellrange(d), values=list(np.round(x, 4)))
    if d.scale.iloc[0] == 'log10':
        r.update(mean_log10=x.mean(), sd_log10=x.std(ddof=1), geomean_fold=10**x.mean(), reduction='mean of log10 values; back-transformed 10^mean = geometric mean fold')
    elif blk in TITRE_BLOCKS:
        xx = x.copy()
        if blk in HAI_BLOCKS:
            xx = np.where(xx < 10, 5.0, xx)
        lx = np.log10(xx)
        r.update(mean=x.mean(), sd=x.std(ddof=1), geomean=10**lx.mean(), gsd=10**lx.std(ddof=1), median=np.median(x),
                 reduction='geometric mean of reciprocal titres' + (' (values <10 set to 5 = LOD/2)' if blk in HAI_BLOCKS else ''))
    else:
        r.update(mean=x.mean(), sd=x.std(ddof=1), median=np.median(x), reduction='arithmetic mean, SD (n-1)')
    rows.append(r)
S = pd.DataFrame(rows)
S.to_csv('block_group_summary.csv', index=False)

def get(blk, grp, panel='', time=None):
    d = v[(v.block == blk) & (v.group == grp) & (v.panel == panel)]
    if time is not None:
        d = d[d.time.astype(str) == str(time)]
    return d

def contrast(blk, g1, g2, panel='', time=None, log=False, hai=False):
    a = get(blk, g1, panel, time).value.values; b = get(blk, g2, panel, time).value.values
    if hai:
        a = np.where(a < 10, 5.0, a); b = np.where(b < 10, 5.0, b)
    if log:
        la, lb = np.log10(a), np.log10(b)
        t = stats.ttest_ind(la, lb, equal_var=False)
        est = 10**(la.mean() - lb.mean())
        # Welch CI
        se = np.sqrt(la.var(ddof=1)/len(la) + lb.var(ddof=1)/len(lb))
        df = se**4 / ((la.var(ddof=1)/len(la))**2/(len(la)-1) + (lb.var(ddof=1)/len(lb))**2/(len(lb)-1)) if se > 0 else np.nan
        tc = stats.t.ppf(0.975, df) if se > 0 else np.nan
        lo, hi = 10**(la.mean()-lb.mean()-tc*se), 10**(la.mean()-lb.mean()+tc*se)
        kind = 'ratio of geometric means'
    else:
        t = stats.ttest_ind(a, b, equal_var=False)
        est = a.mean() - b.mean()
        se = np.sqrt(a.var(ddof=1)/len(a) + b.var(ddof=1)/len(b))
        df = se**4 / ((a.var(ddof=1)/len(a))**2/(len(a)-1) + (b.var(ddof=1)/len(b))**2/(len(b)-1)) if se > 0 else np.nan
        tc = stats.t.ppf(0.975, df) if se > 0 else np.nan
        lo, hi = est - tc*se, est + tc*se
        kind = 'difference of means'
    try:
        mw = stats.mannwhitneyu(a, b, alternative='two-sided', method='exact').pvalue
    except Exception:
        mw = stats.mannwhitneyu(a, b, alternative='two-sided').pvalue
    return dict(block=blk, panel=panel, time=time, g1=g1, g2=g2, n1=len(a), n2=len(b), m1=(10**np.log10(a).mean() if log else a.mean()),
                m2=(10**np.log10(b).mean() if log else b.mean()), kind=kind, est=est, ci_lo=lo, ci_hi=hi, welch_p=t.pvalue, mw_exact_p=mw,
                fold=(a.mean()/b.mean() if not log and b.mean() != 0 else est))

if __name__ == '__main__':
    out = S.copy()
    for c in ['mean', 'sd', 'median', 'geomean', 'gsd', 'mean_log10', 'sd_log10', 'geomean_fold']:
        if c in out: out[c] = out[c].round(3)
    print(out.drop(columns=['values', 'reduction']).to_string())

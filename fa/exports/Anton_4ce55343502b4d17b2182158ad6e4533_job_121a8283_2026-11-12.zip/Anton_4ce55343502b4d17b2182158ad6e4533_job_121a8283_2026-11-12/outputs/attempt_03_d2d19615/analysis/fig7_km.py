import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from parse_blocks import surv

def km(t, e, tmax):
    t = np.asarray(t, float); e = np.asarray(e, int)
    xs = [0]; ys = [1.0]; s = 1.0
    for u in sorted(set(t[e == 1])):
        nr = (t >= u).sum(); d = ((t == u) & (e == 1)).sum()
        xs += [u, u]; ys += [s, s * (1 - d / nr)]; s *= (1 - d / nr)
    xs.append(tmax); ys.append(s)
    return xs, [100 * y for y in ys]

panels = [
 ('S03-I', 'S03-I†  bivalent → CA09 H1N1 (10×LD50), day 14', 14),
 ('S03-J', 'S03-J†  rgH5N1 → wild-type H5N1, day 2', 21),
 ('S06-A', 'S06-A  H3N2 → PR8 H1N1, day 14', 14),
 ('S06-B', 'S06-B  H3N2 → PR8 H1N1, day 3', 14),
 ('S06-C', 'S06-C‡  bivalent → rgH5N1, day 14', 14),
 ('S15-H', 'S15-H  bivalent → rgH5N1, day 3 (antigen vs adjuvant vs both)', 14),
 ('S06-E (rows 34-68)', 'S06-E (rows 34–68)  H3N2 → PR8 H1N1, day 60', 14),
 ('S06-F (rows 34-68)', 'S06-F (rows 34–68)  bivalent → rgH5N1, day 60', 14),
 ('S06-G', 'S06-G  H1N1 → Perth H3N2, day 60', 14),
 ('S15-L', 'S15-L  C57BL/6, 20 months', 14),
 ('S15-N', 'S15-N  Swiss Webster (outbred), 20 months', 14),
 ('S06-F (rows 71-105)', 'S06-F (rows 71–105)  14-mo ± PR8 imprinting → Perth H3N2', 14),
]
sty = {'Sham': ('0.5', '-', 'Sham (vaccine + empty liposome)'), 'CMP-204': ('#d6a24c', '-', 'CMP-204 (cGAMP)'), 'PSLN-212': ('#2166ac', '-', 'PSLN-212, aged'),
       'PSLN-344': ('#b2182b', '-', 'PSLN-344, aged'), 'PSLN-212(Y)': ('#1b7837', '--', 'PSLN-212, young'), 'Untreated': ('k', ':', 'Untreated, NOT challenged (aged)'),
       '3d Vaccine': ('0.5', '-', 'Vaccine alone'), '3d PSLN-344': ('#f4a582', '-', 'PSLN-344 alone (no antigen)'), '3d Vaccine+PSLN-344': ('#b2182b', '-', 'Vaccine + PSLN-344'),
       'Naïve+PSLN-212': ('#2166ac', '-', 'unprimed + PSLN-212'), 'Imprinting+PSLN-212': ('#2166ac', '--', 'PR8-imprinted + PSLN-212'),
       'Naïve+PSLN-344': ('#b2182b', '-', 'unprimed + PSLN-344'), 'Imprinting+PSLN-344': ('#b2182b', '--', 'PR8-imprinted + PSLN-344')}
off = {'Sham': 0.0, 'CMP-204': 0.6, 'PSLN-212': -0.6, 'PSLN-344': 1.2, 'PSLN-212(Y)': -1.2, 'Untreated': 1.8, '3d Vaccine': 0, '3d PSLN-344': -0.6, '3d Vaccine+PSLN-344': 1.2,
       'Naïve+PSLN-212': 0, 'Imprinting+PSLN-212': -0.8, 'Naïve+PSLN-344': 1.2, 'Imprinting+PSLN-344': -1.2}
fig, axes = plt.subplots(3, 4, figsize=(17, 10.2), sharey=True)
used = {}
for ax, (blk, title, tmax) in zip(axes.ravel(), panels):
    d = surv[surv.block == blk]
    for g, x in d.groupby('group', sort=False):
        x = x.dropna(subset=['time'])
        xs, ys = km(x.time.values, x.event.values, tmax)
        c, ls, lab = sty[g]
        h, = ax.plot(xs, np.array(ys) + off[g], color=c, ls=ls, lw=2.0, drawstyle='default')
        used[lab] = h
        n = len(d[d.group == g]); alive = int((d[d.group == g].event == 0).sum())
    short = {'Sham': 'Sham', 'CMP-204': 'CMP-204', 'PSLN-212': '212', 'PSLN-344': '344', 'PSLN-212(Y)': '212-young', 'Untreated': 'Untreated', '3d Vaccine': 'vaccine alone',
             '3d PSLN-344': '344 alone', '3d Vaccine+PSLN-344': 'vaccine+344', 'Naïve+PSLN-212': 'unprimed 212', 'Imprinting+PSLN-212': 'imprinted 212',
             'Naïve+PSLN-344': 'unprimed 344', 'Imprinting+PSLN-344': 'imprinted 344'}
    parts = [f"{short[g]} {int((x.event==0).sum())}/{len(x)}" for g, x in d.groupby('group', sort=False)]
    per = 3 if len(parts) > 3 else len(parts)
    if max(len(p) for p in parts) > 14: per = 2
    lines = [' · '.join(parts[i:i+per]) for i in range(0, len(parts), per)]
    while len(lines) < 2: lines.append('')
    ax.set_title(title + '\n' + 'survivors: ' + lines[0] + '\n' + ('                  ' + lines[1] if lines[1] else ''), fontsize=8.4, loc='left', linespacing=1.3)
    ax.set_xlim(0, tmax + 0.3); ax.set_ylim(-5, 106)
    ax.set_xticks(range(0, tmax + 1, 2 if tmax <= 14 else 3))
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
for ax in axes[-1]: ax.set_xlabel('Days after challenge')
for ax in axes[:, 0]: ax.set_ylabel('Surviving (%)')
fig.legend(list(used.values()), list(used.keys()), loc='lower center', ncol=5, frameon=False, fontsize=8.6, bbox_to_anchor=(0.5, 0.018))
fig.suptitle('Kaplan–Meier curves rebuilt from the time-to-event tables (curves offset by ≤1.2% vertically so that overlapping groups stay visible; n = 7 per arm, S03-J n = 10)', fontsize=11, x=0.01, ha='left', y=0.995)
fig.text(0.01, 0.004, '† group labels conflict with the paired body-weight block.  ‡ identical row-for-row to S06-D (not shown).  Sub-title of each panel: survivors/total as printed in the workbook.', fontsize=8, color='0.3')
fig.subplots_adjust(left=0.045, right=0.99, top=0.905, bottom=0.15, hspace=0.52, wspace=0.08)
fig.savefig('/tmp/outputs/figures/fig7_kaplan_meier.png', dpi=160)

import pandas as pd, numpy as np, itertools, warnings
from scipy import stats
from parse_blocks import tidy
warnings.filterwarnings('ignore')
pd.set_option('display.width', 300); pd.set_option('display.max_rows', 2000); pd.set_option('display.max_columns', 60); pd.set_option('display.max_colwidth', 60)

v = tidy[(tidy.kind == 'value') & tidy.value.notna()].copy()
v['value'] = v.value.astype(float)
TITRE = {'S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-A', 'S13-B', 'S13-C', 'S13-D', 'S13-I', 'S13-J'}
HAI = {'S03-C', 'S03-G'}
QPCR = {'S01-A', 'S02-F', 'S03-L', 'S08-A', 'S10-A'}

def norm(g):
    return {'PSLN-212(y)': 'PSLN-212(Y)', 'PSLN-212Y': 'PSLN-212(Y)', 'PSLN-344Y': 'PSLN-344(Y)'}.get(g, g)

rows = []
for (blk, panel, tm), d in v.groupby(['block', 'panel', 'time'], dropna=False, sort=False):
    groups = list(dict.fromkeys(d.group))
    data = {}
    for g in groups:
        x = d[d.group == g].value.values.copy()
        if blk in HAI: x = np.where(x < 10, 5.0, x)
        data[g] = x
    logscale = (blk in TITRE) or (blk in QPCR)
    stored_log = d.scale.iloc[0] == 'log10'
    tr = {g: (np.log10(x) if logscale else x) for g, x in data.items()}   # S09-A already log10
    # one-way ANOVA + Tukey across all groups printed in the block (the stated method)
    tuk = None; anova_p = np.nan
    if len(groups) >= 3 and all(len(x) >= 2 for x in tr.values()):
        anova_p = stats.f_oneway(*tr.values()).pvalue
        tuk = stats.tukey_hsd(*tr.values())
    for g1, g2 in itertools.combinations(groups, 2):
        a, b = tr[g1], tr[g2]
        if len(a) < 2 or len(b) < 2: continue
        w = stats.ttest_ind(a, b, equal_var=False)
        try: mw = stats.mannwhitneyu(a, b, alternative='two-sided', method='exact').pvalue
        except Exception: mw = np.nan
        se = np.sqrt(a.var(ddof=1)/len(a) + b.var(ddof=1)/len(b))
        df = se**4 / ((a.var(ddof=1)/len(a))**2/(len(a)-1) + (b.var(ddof=1)/len(b))**2/(len(b)-1)) if se > 0 else np.nan
        tc = stats.t.ppf(0.975, df) if se > 0 else np.nan
        diff = a.mean() - b.mean()
        if logscale or stored_log:
            est, lo, hi, kind = 10**diff, 10**(diff - tc*se), 10**(diff + tc*se), 'ratio of geometric means (g1/g2)'
            m1, m2 = 10**a.mean(), 10**b.mean()
        else:
            est, lo, hi, kind = diff, diff - tc*se, diff + tc*se, 'difference of arithmetic means (g1-g2)'
            m1, m2 = a.mean(), b.mean()
        tp = tuk.pvalue[groups.index(g1), groups.index(g2)] if tuk is not None else np.nan
        rows.append(dict(block=blk, panel=panel, time=tm, g1=g1, g2=g2, n1=len(a), n2=len(b), m1=m1, m2=m2,
                         arith_mean1=data[g1].mean() if not stored_log else np.nan, arith_mean2=data[g2].mean() if not stored_log else np.nan,
                         effect_kind=kind, effect=est, ci_lo=lo, ci_hi=hi, welch_p=w.pvalue, mw_exact_p=mw, anova_p=anova_p, tukey_p=tp,
                         test_scale='log10' if (logscale or stored_log) else 'raw', n_groups_in_anova=len(groups)))
C = pd.DataFrame(rows)
C.to_csv('all_pairwise_contrasts.csv', index=False)

if __name__ == '__main__':
    def show(g1, g2, title):
        x = C[((C.g1 == g1) & (C.g2 == g2)) | ((C.g1 == g2) & (C.g2 == g1))].copy()
        print('\n#####', title, len(x))
        cols = ['block', 'panel', 'time', 'g1', 'g2', 'n1', 'n2', 'm1', 'm2', 'effect', 'ci_lo', 'ci_hi', 'welch_p', 'mw_exact_p', 'tukey_p', 'test_scale']
        y = x[cols].copy()
        for c in ['m1', 'm2', 'effect', 'ci_lo', 'ci_hi']: y[c] = y[c].round(2)
        for c in ['welch_p', 'mw_exact_p', 'tukey_p']: y[c] = y[c].map(lambda p: f'{p:.1e}' if p == p else '')
        print(y.to_string())
    show('PSLN-212', 'PSLN-344', 'AGED: PSLN-212 vs PSLN-344 (Mn effect)')
    show('PSLN-344', 'PSLN-212(Y)', 'PSLN-344 aged vs young PSLN-212 benchmark')
    show('PSLN-344', 'PSLN-212(y)', 'PSLN-344 aged vs young PSLN-212 benchmark (S09-A)')
    show('PSLN-344', 'PSLN-212Y', 'PSLN-344 aged vs young PSLN-212 benchmark (S05-A/B)')

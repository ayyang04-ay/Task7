"""Independent check: recompute every simple ledger entry straight from the workbook cells named in the ledger
(openpyxl range read; no use of the parsed tables)."""
import pandas as pd, numpy as np, re, openpyxl
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx', data_only=True)
L = pd.read_csv('/tmp/outputs/evidence_ledger.csv')
def read(rng):
    sh, r = rng.split('!')
    cells = wb[sh][r]
    if not isinstance(cells, tuple): cells = ((cells,),)
    return [[c.value for c in row] for row in cells]
ok = bad = skipped = 0
for _, r in L.iterrows():
    red = str(r.reduction); cells = str(r.cells)
    if not re.match(r'^S\d\d![A-Z]+\d+(:[A-Z]+\d+)?$', cells): skipped += 1; continue
    grid = read(cells); flat = [v for row in grid for v in row if isinstance(v, (int, float))]
    try:
        if red.startswith('arithmetic mean of the per-animal values'):
            val = np.mean(flat); exp = float(r.value)
        elif red.startswith('sample standard deviation'):
            val = np.std(flat, ddof=1); exp = float(r.value)
        elif red.startswith('smallest per-animal value'):
            val = np.min(flat); exp = float(r.value)
        elif red.startswith('geometric mean of reciprocal titres'):
            x = np.array(flat, float)
            if 'set to 5' in red: x = np.where(x < 10, 5.0, x)
            val = 10 ** np.log10(x).mean(); exp = float(r.value)
        elif red.startswith('mean of the stored log10 values'):
            val = 10 ** np.mean(flat); exp = float(r.value)
        elif red.startswith('rows with event flag 0'):
            ev = [row[-1] for row in grid if row[-1] is not None]
            val = f'{sum(1 for e in ev if e == 0)}/{len(ev)}'; exp = r.value
        elif red.startswith('count of per-animal titres'):
            thr = float(re.search(r'>= (\d+)', red).group(1)); val = f'{sum(1 for v in flat if v >= thr)}/{len(flat)}'; exp = r.value
        else:
            skipped += 1; continue
    except Exception as e:
        print('ERR', r.ledger_id, e); bad += 1; continue
    good = (val == exp) if isinstance(val, str) else abs(val - exp) <= max(1e-3, 6e-3 * abs(exp))
    if good: ok += 1
    else:
        bad += 1; print('MISMATCH', r.ledger_id, r.block, r.quantity, 'ledger', exp, 'recomputed', val, cells)
print(f'recomputed {ok + bad} ledger rows directly from workbook cells: {ok} agree, {bad} disagree; {skipped} rows are derived quantities (contrasts, pooled values, fits) checked by their own scripts')

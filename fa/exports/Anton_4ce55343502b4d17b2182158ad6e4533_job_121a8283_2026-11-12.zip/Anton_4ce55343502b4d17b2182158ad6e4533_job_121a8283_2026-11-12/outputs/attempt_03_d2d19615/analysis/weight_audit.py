import pandas as pd, numpy as np
from parse_blocks import tidy, surv
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 800); pd.set_option('display.max_columns', 50)

w = tidy[tidy.kind == 'weight'].copy()
w['time'] = w['time'].astype(float)

def classify(series):
    """series: values indexed by day (sorted). Returns status + last day with an informative (changing) value."""
    days = list(series.index); vals = list(series.values)
    obs = [(d, v) for d, v in zip(days, vals) if v is not None and not (isinstance(v, float) and np.isnan(v))]
    last_day = days[-1]
    if len(obs) < len(days):
        # blanks present
        lastobs = obs[-1][0]
        # are blanks only trailing?
        trailing = all((v is None or (isinstance(v, float) and np.isnan(v))) for d, v in zip(days, vals) if d > lastobs)
        interior_gap = len([1 for d, v in zip(days, vals) if d < lastobs and (v is None or (isinstance(v, float) and np.isnan(v)))])
        return ('blank_after', lastobs, interior_gap)
    # complete: check frozen tail (>=2 identical trailing values)
    k = 1
    while k < len(vals) and vals[-1-k] == vals[-1]:
        k += 1
    if k >= 2:
        # frozen from day index len-k
        return ('frozen_from', days[len(vals)-k], 0)
    return ('complete', last_day, 0)

out = []
for (blk, grp, rep), d in w.groupby(['block', 'group', 'rep'], sort=False):
    s = d.set_index('time').value
    st, day, gaps = classify(s)
    obsvals = [v for v in s.values if v is not None and not (isinstance(v, float) and np.isnan(v))]
    out.append(dict(block=blk, group=grp, rep=rep, col=d.cell.iloc[0].rstrip('0123456789'), status=st, day=day,
                    interior_gaps=gaps, nadir=min(obsvals), final=obsvals[-1], n_obs=len(obsvals)))
wa = pd.DataFrame(out)
wa.to_csv('weight_animal_status.csv', index=False)

summ = wa.groupby(['block', 'group'], sort=False).apply(lambda d: pd.Series(dict(
    n=len(d),
    blank=int((d.status == 'blank_after').sum()),
    frozen=int((d.status == 'frozen_from').sum()),
    complete=int((d.status == 'complete').sum()),
    blank_lastobs=sorted(d[d.status == 'blank_after'].day.astype(int).tolist()),
    frozen_from=sorted(d[d.status == 'frozen_from'].day.astype(int).tolist()),
    mean_nadir=round(d.nadir.mean(), 1),
    interior_gaps=int(d.interior_gaps.sum()),
))).reset_index()
print(summ.to_string())
summ.to_csv('weight_block_summary.csv', index=False)

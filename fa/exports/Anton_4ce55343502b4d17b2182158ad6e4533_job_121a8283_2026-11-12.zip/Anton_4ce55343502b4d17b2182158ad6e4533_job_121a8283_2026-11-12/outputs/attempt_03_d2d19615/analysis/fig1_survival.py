import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
from survival_analysis import cp_ci

T = pd.read_csv('aged_head_to_head_survival.csv')
P = pd.read_csv('pooled_survival.csv')

def newcombe(a, n1, b, n2, z=1.96):
    def wil(k, n):
        p = k/n; den = 1 + z*z/n; c = (p + z*z/(2*n))/den; h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/den
        return c-h, c+h
    p1, p2 = a/n1, b/n2; l1, u1 = wil(a, n1); l2, u2 = wil(b, n2)
    d = p1 - p2
    return d, d - np.sqrt((p1-l1)**2 + (u2-p2)**2), d + np.sqrt((u1-p1)**2 + (p2-l2)**2)

lab = {
 'S03-I': 'S03-I  BALB/c aged · bivalent → CA09 H1N1 10×LD50 · d14 †',
 'S03-J': 'S03-J  BALB/c · rgH5N1 → wild-type H5N1 · d2 †',
 'S06-A': 'S06-A  BALB/c aged · H3N2 → PR8 H1N1 · d14',
 'S06-B': 'S06-B  BALB/c aged · H3N2 → PR8 H1N1 · d3',
 'S06-C': 'S06-C  BALB/c aged · bivalent → rgH5N1 · d14 ‡',
 'S06-D': 'S06-D  (row-for-row duplicate of S06-C; excluded)',
 'S06-E (rows 34-68)': 'S06-E(r34)  BALB/c aged · H3N2 → PR8 H1N1 · d60',
 'S06-F (rows 34-68)': 'S06-F(r34)  BALB/c aged · bivalent → rgH5N1 · d60',
 'S06-G': 'S06-G  BALB/c aged · H1N1 → Perth H3N2 · d60',
 'S15-L': 'S15-L  C57BL/6 20 mo · bivalent → (virus not stated)',
 'S15-N': 'S15-N  Swiss Webster 20 mo · bivalent → (virus not stated)',
}
rows = []
for _, r in T.iterrows():
    if r.block in lab: name = lab[r.block]
    elif r.block.startswith('S06-E (rows 71'):
        name = ('S06-E(r71)  14 mo ' + ('PR8-imprinted' if 'Imprinting' in r.arm344 else 'unprimed') + ' · bivalent → PR8 H1N1')
    else:
        name = ('S06-F(r71)  14 mo ' + ('PR8-imprinted' if 'Imprinting' in r.arm344 else 'unprimed') + ' · bivalent → Perth H3N2 · d14')
    rows.append((name, r))
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15.5, 8.2), gridspec_kw=dict(width_ratios=[1.25, 1], wspace=0.04), sharey=True)
n = len(rows)
ypos = np.arange(n)[::-1] + 2
for (name, r), y in zip(rows, ypos):
    dup = r.block == 'S06-D'
    alpha = 0.3 if dup else 1
    ax1.plot([0, 100], [y, y], color='0.92', lw=0.8, zorder=0)
    if not np.isnan(r.get('sSham', np.nan)):
        ax1.scatter(100*r.sSham/r.nSham, y + 0.22, marker='x', color='0.45', s=38, alpha=alpha, zorder=3)
    if not np.isnan(r.get('sY', np.nan)):
        ax1.scatter(100*r.sY/r.nY, y + 0.22, marker='^', facecolor='none', edgecolor='#1b7837', s=55, alpha=alpha, zorder=3)
    ax1.scatter(100*r.s212/r.n212, y - 0.05, marker='o', facecolor='white', edgecolor='#2166ac', s=75, lw=1.8, alpha=alpha, zorder=4)
    ax1.scatter(100*r.s344/r.n344, y - 0.05, marker='o', color='#b2182b', s=75, alpha=alpha, zorder=5)
    ax1.text(103, y - 0.05, f'{int(r.s344)}/{int(r.n344)}', color='#b2182b', va='center', fontsize=8.5, alpha=alpha)
    ax1.text(119, y - 0.05, f'{int(r.s212)}/{int(r.n212)}', color='#2166ac', va='center', fontsize=8.5, alpha=alpha)
    d, lo, hi = newcombe(r.s344, r.n344, r.s212, r.n212)
    ax2.plot([100*lo, 100*hi], [y, y], color='0.25' if not dup else '0.75', lw=1.4)
    ax2.scatter(100*d, y, marker='s', color='0.15' if not dup else '0.75', s=42, zorder=3)
ax1.text(103, n + 1.75, 'PSLN-\n344', color='#b2182b', fontsize=8.5, ha='left', va='bottom', fontweight='bold')
ax1.text(119, n + 1.75, 'PSLN-\n212', color='#2166ac', fontsize=8.5, ha='left', va='bottom', fontweight='bold')
# pooled rows
pb = P[P.label.str.startswith('B.')].iloc[0]; pk = P[P.label.str.startswith('K.')].iloc[0]
for y, pr, txt in ((0.6, pb, 'Pooled, as printed, duplicate removed (14 strata)'), (-0.4, pk, 'Pooled, least-favourable counts in every stratum')):
    ax2.plot([100*pr.rd_lo, 100*pr.rd_hi], [y, y], color='#b2182b', lw=2.2)
    ax2.scatter(100*pr.rd, y, marker='D', color='#b2182b', s=70, zorder=3)
    ax2.text(100*pr.rd_hi + 2, y, f'{100*pr.rd:.0f} pts ({100*pr.rd_lo:.0f}–{100*pr.rd_hi:.0f})', va='center', fontsize=8.5, color='#b2182b')
    ax1.scatter(100*pr.s344/pr.n344, y, marker='o', color='#b2182b', s=75); ax1.scatter(100*pr.s212/pr.n212, y, marker='o', facecolor='white', edgecolor='#2166ac', s=75, lw=1.8)
    ax1.text(103, y, f'{int(pr.s344)}/{int(pr.n344)}', color='#b2182b', va='center', fontsize=8.5, fontweight='bold')
    ax1.text(119, y, f'{int(pr.s212)}/{int(pr.n212)}', color='#2166ac', va='center', fontsize=8.5, fontweight='bold')
ax1.axhline(1.3, color='0.6', lw=0.8)
ax2.axhline(1.3, color='0.6', lw=0.8)
ax1.set_yticks(list(ypos) + [0.6, -0.4])
ax1.set_yticklabels([nm for nm, _ in rows] + ['POOLED  as printed, S06-D removed', 'POOLED  least-favourable reading'], fontsize=8.6)
ax1.set_xlim(-4, 136); ax1.set_xticks([0, 25, 50, 75, 100]); ax1.set_xlabel('Survivors at end of observation (%)')
ax2.axvline(0, color='0.5', lw=0.8, ls='--'); ax2.set_xlim(-45, 135); ax2.set_xticks([-25, 0, 25, 50, 75, 100])
ax2.set_xlabel('Survival difference, PSLN-344 − PSLN-212 (points, 95% CI)')
ax1.set_ylim(-1.1, n + 2.7)
for ax in (ax1, ax2):
    for s in ('top', 'right'): ax.spines[s].set_visible(False)
from matplotlib.lines import Line2D
h = [Line2D([], [], marker='o', color='#b2182b', ls='', ms=8, label='PSLN-344 (aged)'),
     Line2D([], [], marker='o', mfc='white', mec='#2166ac', mew=1.8, ls='', ms=8, label='PSLN-212 (aged)'),
     Line2D([], [], marker='x', color='0.45', ls='', ms=7, label='Sham: vaccine + empty liposome (aged)'),
     Line2D([], [], marker='^', mfc='none', mec='#1b7837', ls='', ms=8, label='PSLN-212 in young adults (benchmark)')]
ax1.legend(handles=h, loc='lower center', bbox_to_anchor=(0.42, 1.005), ncol=2, frameon=False, fontsize=8.8)
ax2.set_title('Per-experiment: Newcombe 95% CI.  Pooled: Mantel–Haenszel', fontsize=9.5, loc='left')
fig.text(0.01, 0.005, '† group labels in the paired body-weight block conflict with this table.  ‡ S06-C and S06-D are identical row for row; counted once.  '
         'All experiments n = 7 per arm except S03-J (n = 10). Source: workbook sheets S03, S06, S15; counts = rows with event flag 0 / all rows.', fontsize=7.8, color='0.3')
fig.suptitle('Lethal-challenge survival in aged mice: every head-to-head experiment favours the Mn-containing particle', fontsize=12.5, x=0.01, ha='left', y=0.995)
fig.subplots_adjust(left=0.30, right=0.985, top=0.88, bottom=0.085)
fig.savefig('/tmp/outputs/figures/fig1_survival_head_to_head.png', dpi=170)
print('ok')

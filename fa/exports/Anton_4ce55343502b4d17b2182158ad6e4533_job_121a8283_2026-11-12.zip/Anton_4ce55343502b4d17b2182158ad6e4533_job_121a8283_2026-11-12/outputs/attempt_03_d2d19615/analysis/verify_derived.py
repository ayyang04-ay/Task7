import pandas as pd, numpy as np, itertools
from parse_blocks import tidy
pd.set_option('display.width', 250)
def col(blk, grp, panel=None):
    d = tidy[(tidy.block == blk) & (tidy.group == grp)]
    if panel is not None: d = d[d.panel == panel]
    return d.value.astype(float).values

print('=== 1. S03-B / S03-F (IgG2a/IgG1 quotient) recomputed from per-animal titres in S13-A..D ===')
for qb, num, den, ag in (('S03-B', 'S13-A', 'S13-B', 'CA09 H1N1'), ('S03-F', 'S13-C', 'S13-D', 'Aichi H3N2')):
    print(f'-- {qb} ({ag}) = {num} / {den}')
    groups = ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
    recomputed = {g: col(num, g) / col(den, g) for g in groups}
    printed = {g: col(qb, g) for g in groups}
    for g in groups:
        print(f'   recomputed {g:12s}', np.round(recomputed[g], 4), ' mean', round(recomputed[g].mean(), 3), ' geomean', round(np.exp(np.log(recomputed[g]).mean()), 3))
    for g in groups:
        match = [h for h in groups if np.allclose(printed[g], recomputed[h], rtol=1e-4)]
        print(f'   printed column "{g}" in {qb}:', np.round(printed[g], 4), '-> equals recomputed ratio for', match)

print('\n=== 2. S04-B Tfh:Tfr vs (100 - Foxp3%)/Foxp3% ===')
for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
    f = col('S04-B Foxp3+ in CXCR5+', g); r = col('S04-B Tfh:Tfr', g)
    print(f'   {g:12s} max abs diff', np.abs((100 - f) / f - r).max().round(6))

print('\n=== 3. S04-A: ICOS- + ICOS+ = total CXCR5+PD1+ Tfh ===')
for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
    a = col('S04-A', g, 'ICOS-CXCR5+PD1+'); b = col('S04-A', g, 'ICOS+CXCR5+PD1+')
    print(f'   {g:12s} total', np.round(a + b, 3), 'mean total', round((a + b).mean(), 2), ' ICOS+ fraction', np.round(b / (a + b), 3))

print('\n=== 4. S09-A (log10) vs S01-A (linear) Ifnb1 ===')
for panel9, panel1 in (('cols A-U|Ifnb1', '16h'), ('cols A-U|Ifnb1', '72h'), ('cols X-AS|Ifnb1', '16h'), ('cols X-AS|Ifnb1', '72h')):
    nmatch = 0; ntot = 0; detail = []
    for g9, g1 in (('CMP-204', 'CMP-204'), ('PSLN-212', 'PSLN-212'), ('PSLN-R848', 'PSLN-R848'), ('PSLN-212/R848', 'PSLN-212/R848'), ('PSLN-344', 'PSLN-344'), ('PSLN-212(y)', 'PSLN-212(Y)')):
        a = 10 ** col('S09-A', g9, panel9); b = col('S01-A', g1, panel1)
        for x in a:
            ntot += 1
            if np.any(np.abs(b - x) / b < 0.006): nmatch += 1
    print(f'   S09-A [{panel9}] back-transformed values found in S01-A [{panel1}] (within 0.6%): {nmatch}/{ntot}')
# PBS group: S09-A PBS vs S01-A Sham
for panel9, panel1 in (('cols A-U|Ifnb1', '16h'), ('cols X-AS|Ifnb1', '72h')):
    print('   PBS back-transformed', np.round(10 ** col('S09-A', 'PBS', panel9), 3), ' vs S01-A Sham', col('S01-A', 'Sham', panel1))

print('\n=== 5. S01-F + S01-G (cDC1 + cDC2) ===')
for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']:
    print(f'   {g:12s}', np.round(col('S01-F', g) + col('S01-G', g), 1))

print('\n=== 6. S01-B vs S08-C shared values ===')
for g in ['AECII/PSLN-SRB', 'AECI/PSLN-SRB', 'AECII/FreeSRB', 'AECI/FreeSRB']: print('   S01-B', g, col('S01-B', g), 'mean', col('S01-B', g).mean().round(2))
for g in ['AECII-PSLN-SRB', 'AECII-PSLN-344-SRB', 'AECI-PSLN-SRB', 'AECI-PSLN-344-SRB']: print('   S08-C', g, col('S08-C', g), 'mean', col('S08-C', g).mean().round(2))

print('\n=== 7. S09-C duplicated rows ===')
w = tidy[tidy.block == 'S09-C']
for t in (10, 12, 14):
    a = w[(w.group == 'PSLN-212Y') & (w.time == t)].value.values; b = w[(w.group == 'PSLN-344Y') & (w.time == t)].value.values
    print(f'   day {t}: 212Y', a, '| 344Y', b, '| identical:', np.array_equal(a, b))

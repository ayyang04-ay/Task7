import pandas as pd, numpy as np, itertools
from parse_blocks import surv
vec = {}
for (b, g), d in surv.groupby(['block', 'group'], sort=False):
    vec[(b, g)] = tuple(sorted(zip(d.time.fillna(-1).astype(int), d.event.astype(int))))
print('identical (time,event) vectors with >=3 deaths, across different blocks/groups:')
for a, b in itertools.combinations(vec, 2):
    if vec[a] == vec[b] and sum(e for _, e in vec[a]) >= 3:
        print('  ', a, '==', b, [t for t, e in vec[a] if e == 1])
# whole-block identity
blocks = surv.block.unique()
def blockvec(b):
    d = surv[surv.block == b]
    return tuple((g, tuple(zip(x.time.fillna(-1).astype(int), x.event.astype(int)))) for g, x in d.groupby('group', sort=False))
print('\nwhole-block identity (same groups, same rows in same order):')
for a, b in itertools.combinations(blocks, 2):
    if blockvec(a) == blockvec(b):
        print('  ', a, '==', b)

"""
Parse adjuvant_program_dataset.xlsx into a tidy, cell-addressed long table.

Every observation keeps its sheet + cell address so that each number in the
report can be traced back to the workbook. Nothing is imputed, renamed or
re-ordered here; labels are kept exactly as printed.
"""
import openpyxl, pandas as pd, numpy as np
from openpyxl.utils import get_column_letter as gcl, column_index_from_string as cidx

XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
wb = openpyxl.load_workbook(XLSX, data_only=True)
rows = []

def add(block, sheet, group, col_letters, row_list, time_by_row=None, panel='', kind='value', scale='linear', units=''):
    ws = wb[sheet]
    for r in row_list:
        for j, cl in enumerate(col_letters):
            v = ws[f'{cl}{r}'].value
            t = None if time_by_row is None else time_by_row[r]
            rows.append(dict(block=block, sheet=sheet, panel=panel, group=group, time=t,
                             rep=j+1, cell=f'{cl}{r}', value=v, kind=kind, scale=scale, units=units))

def colrange(a, b):
    return [gcl(i) for i in range(cidx(a), cidx(b)+1)]

def add_wide_rows(block, sheet, first_row, last_row, start_col, groups, reps, gap=0, time_col=None, panel='', **kw):
    """groups laid out left-to-right, each spanning `reps` columns, one row per timepoint"""
    ws = wb[sheet]
    c0 = cidx(start_col)
    tb = None
    if time_col:
        tb = {r: ws[f'{time_col}{r}'].value for r in range(first_row, last_row+1)}
    for gi, g in enumerate(groups):
        cols = [gcl(c0 + gi*(reps+gap) + k) for k in range(reps)]
        add(block, sheet, g, cols, list(range(first_row, last_row+1)), time_by_row=tb, panel=panel, **kw)

def add_cols(block, sheet, first_row, last_row, start_col, groups, panel='', **kw):
    """one column per group, one row per animal"""
    ws = wb[sheet]
    c0 = cidx(start_col)
    for gi, g in enumerate(groups):
        cl = gcl(c0+gi)
        for k, r in enumerate(range(first_row, last_row+1)):
            rows.append(dict(block=block, sheet=sheet, panel=panel, group=g, time=None, rep=k+1,
                             cell=f'{cl}{r}', value=ws[f'{cl}{r}'].value, kind=kw.get('kind','value'),
                             scale=kw.get('scale','linear'), units=kw.get('units','')))

def add_rowgroups(block, sheet, rows_groups, start_col, nrep, panel='', **kw):
    """one row per group, replicates across columns"""
    ws = wb[sheet]
    c0 = cidx(start_col)
    for r, g in rows_groups:
        for k in range(nrep):
            cl = gcl(c0+k)
            rows.append(dict(block=block, sheet=sheet, panel=panel, group=g, time=None, rep=k+1,
                             cell=f'{cl}{r}', value=ws[f'{cl}{r}'].value, kind=kw.get('kind','value'),
                             scale=kw.get('scale','linear'), units=kw.get('units','')))

def hdr(sheet, cells):
    ws = wb[sheet]
    return [ws[c].value for c in cells]

# ---------------- S01 ----------------
g8 = hdr('S01', [f'A{r}' for r in range(3, 11)])
add_rowgroups('S01-A', 'S01', list(zip(range(3, 11), g8)), 'B', 5, panel='16h', units='fold vs untreated')
g8b = hdr('S01', [f'G{r}' for r in range(3, 11)])
add_rowgroups('S01-A', 'S01', list(zip(range(3, 11), g8b)), 'H', 5, panel='72h', units='fold vs untreated')
add_rowgroups('S01-B', 'S01', list(zip(range(14, 18), hdr('S01', [f'A{r}' for r in range(14, 18)]))), 'B', 5, units='%')
add_rowgroups('S01-C', 'S01', list(zip(range(20, 22), hdr('S01', ['A20', 'A21']))), 'B', 4, units='%')
add_wide_rows('S01-D', 'S01', 24, 28, 'B', hdr('S01', ['B23', 'G23', 'L23', 'Q23']), 5, time_col='A', units='%')
add_wide_rows('S01-E', 'S01', 30, 34, 'B', hdr('S01', ['B29', 'G29', 'L29', 'Q29', 'V29']), 5, time_col='A', units='%')
add_wide_rows('S01-F', 'S01', 36, 36, 'B', hdr('S01', ['B35', 'G35', 'L35', 'Q35', 'V35']), 5, units='%')
add_wide_rows('S01-G', 'S01', 38, 38, 'B', hdr('S01', ['B37', 'G37', 'L37', 'Q37', 'V37']), 5, units='%')

# ---------------- S02 ----------------
add_cols('S02-A', 'S02', 3, 7, 'A', hdr('S02', ['A2', 'B2', 'C2', 'D2']), units='%')
add_cols('S02-B', 'S02', 3, 7, 'F', hdr('S02', ['F2', 'G2', 'H2', 'I2']), units='%')
add_cols('S02-C', 'S02', 3, 7, 'K', hdr('S02', ['K2', 'L2', 'M2', 'N2', 'O2']), units='%')
add_cols('S02-D CD40', 'S02', 10, 14, 'A', hdr('S02', ['A9', 'B9', 'C9', 'D9']), units='%')
add_cols('S02-D CD86', 'S02', 10, 14, 'F', hdr('S02', ['F9', 'G9', 'H9', 'I9']), units='%')
add_cols('S02-E', 'S02', 10, 14, 'K', hdr('S02', ['K9', 'L9', 'M9', 'N9', 'O9']), units='%')
add_wide_rows('S02-F', 'S02', 17, 19, 'B', hdr('S02', ['B16', 'G16', 'L16']), 5, time_col='A', units='fold vs untreated')
add_cols('S02-G', 'S02', 22, 26, 'B', hdr('S02', ['B21', 'C21', 'D21']), units='%')
add_cols('S02-H', 'S02', 30, 34, 'B', hdr('S02', ['B29', 'C29', 'D29', 'E29', 'F29']), units='%')
add_cols('S02-I', 'S02', 30, 34, 'H', hdr('S02', ['H29', 'I29']), units='%')

# ---------------- S03 ----------------
g5 = hdr('S03', ['A2', 'B2', 'C2', 'D2', 'E2'])
add_cols('S03-A', 'S03', 3, 7, 'A', g5, units='reciprocal titre')
add_cols('S03-B', 'S03', 3, 7, 'G', hdr('S03', ['G2', 'H2', 'I2']), units='ratio')
add_cols('S03-C', 'S03', 3, 7, 'K', hdr('S03', ['K2', 'L2', 'M2', 'N2', 'O2']), units='reciprocal titre')
add_cols('S03-D', 'S03', 3, 7, 'Q', hdr('S03', ['Q2', 'R2', 'S2', 'T2', 'U2']), units='reciprocal titre')
add_cols('S03-E', 'S03', 10, 14, 'A', hdr('S03', ['A9', 'B9', 'C9', 'D9', 'E9']), units='reciprocal titre')
add_cols('S03-F', 'S03', 10, 14, 'G', hdr('S03', ['G9', 'H9', 'I9']), units='ratio')
add_cols('S03-G', 'S03', 10, 14, 'K', hdr('S03', ['K9', 'L9', 'M9', 'N9', 'O9']), units='reciprocal titre')
add_cols('S03-H', 'S03', 10, 14, 'Q', hdr('S03', ['Q9', 'R9', 'S9', 'T9', 'U9']), units='reciprocal titre')
add_cols('S03-K', 'S03', 17, 21, 'L', hdr('S03', ['L16', 'M16', 'N16', 'O16']), units='%')
add_rowgroups('S03-L', 'S03', list(zip(range(26, 29), hdr('S03', ['K26', 'K27', 'K28']))), 'L', 3, panel='Aicda', units='fold vs untreated')
add_rowgroups('S03-L', 'S03', list(zip(range(26, 29), hdr('S03', ['K26', 'K27', 'K28']))), 'O', 3, panel='E47', units='fold vs untreated')

# ---------------- S04 ----------------
g4 = hdr('S04', ['A2', 'A3', 'A4', 'A5'])
add_rowgroups('S04-A', 'S04', list(zip(range(2, 6), g4)), 'B', 5, panel=wb['S04']['B1'].value, units='%')
add_rowgroups('S04-A', 'S04', list(zip(range(2, 6), g4)), 'G', 5, panel=wb['S04']['G1'].value, units='%')
add_cols('S04-B Foxp3+ in CXCR5+', 'S04', 8, 12, 'A', hdr('S04', ['A7', 'B7', 'C7', 'D7']), units='%')
add_cols('S04-B Tfh:Tfr', 'S04', 15, 19, 'A', hdr('S04', ['A14', 'B14', 'C14', 'D14']), units='ratio')
add_cols('S04-C', 'S04', 22, 26, 'A', hdr('S04', ['A21', 'B21', 'C21', 'D21']), units='%')
add_cols('S04-D', 'S04', 29, 31, 'A', hdr('S04', ['A28', 'B28', 'C28', 'D28']), units='%')

# ---------------- S05 ----------------
for blk, r0 in (('S05-A', 3), ('S05-B', 8)):
    ws = wb['S05']
    tb = {r: ws[f'A{r}'].value for r in range(r0, r0+3)}
    hr = r0-1
    for g, cols in ((ws[f'B{hr}'].value, ['B', 'C']), (ws[f'E{hr}'].value, ['E', 'F']), (ws[f'H{hr}'].value, ['H', 'I'])):
        add(blk, 'S05', g, cols, list(range(r0, r0+3)), time_by_row=tb, units='%')
add_cols('S05-C', 'S05', 13, 15, 'A', hdr('S05', ['A12', 'B12', 'C12', 'D12']), units='%')
for blk, r0 in (('S05-D', 19), ('S05-E', 26), ('S05-F', 33), ('S05-G', 40), ('S05-H', 47), ('S05-I', 54)):
    add_cols(blk, 'S05', r0, r0+4, 'A', hdr('S05', [f'{c}{r0-1}' for c in 'ABCD']), units='%')

# ---------------- S07 ----------------
add_wide_rows('S07-A', 'S07', 3, 7, 'B', hdr('S07', ['B2', 'E2']), 3, time_col='A', units='cells x10^5')
add_cols('S07-B', 'S07', 10, 14, 'B', hdr('S07', ['B9', 'C9']), panel=wb['S07']['B8'].value, units='%')
add_cols('S07-B', 'S07', 10, 14, 'E', hdr('S07', ['E9', 'F9']), panel=wb['S07']['E8'].value, units='%')
# S07-C: both columns carry the same printed label; keep column letter in the group name so they stay distinct
add_cols('S07-C', 'S07', 16, 20, 'B', [f"{wb['S07']['B15'].value} [col B]", f"{wb['S07']['C15'].value} [col C]"], units='%')

# ---------------- S08 ----------------
add_wide_rows('S08-A', 'S08', 3, 7, 'B', hdr('S08', ['B2', 'E2', 'H2', 'K2']), 3, time_col='A', units='fold vs untreated')
add_wide_rows('S08-B', 'S08', 11, 11, 'A', hdr('S08', ['A10', 'D10', 'G10', 'J10', 'M10']), 3, units='%')
add_cols('S08-C', 'S08', 14, 18, 'A', hdr('S08', ['A13', 'B13', 'C13', 'D13']), units='%')
add_wide_rows('S08-D', 'S08', 21, 26, 'B', hdr('S08', ['B20', 'G20', 'L20', 'Q20', 'V20', 'AA20']), 5, time_col='A', kind='weight', units='% of day0')

# ---------------- S09-A (log10) ----------------
ws = wb['S09']
for panel, c0, hdrcells in (('cols A-U', 'B', ['B2', 'E2', 'H2', 'K2', 'N2', 'Q2', 'T2']),
                            ('cols X-AS', 'Y', ['Y2', 'AB2', 'AE2', 'AH2', 'AK2', 'AN2', 'AQ2'])):
    labcol = 'A' if panel == 'cols A-U' else 'X'
    for r in range(3, 10):
        analyte = ws[f'{labcol}{r}'].value
        for gi, g in enumerate(hdr('S09', hdrcells)):
            cols = [gcl(cidx(c0) + gi*3 + k) for k in range(3)]
            for k, cl in enumerate(cols):
                rows.append(dict(block='S09-A', sheet='S09', panel=f'{panel}|{analyte}', group=g, time=None, rep=k+1,
                                 cell=f'{cl}{r}', value=ws[f'{cl}{r}'].value, kind='value', scale='log10', units='log10 fold vs untreated'))

# ---------------- S10 ----------------
for analyte, c0 in (('Ifnb1', 'A'), ('Tnf', 'F'), ('Isg15', 'K')):
    add_cols('S10-A', 'S10', 3, 7, c0, hdr('S10', [f'{gcl(cidx(c0)+k)}2' for k in range(4)]), panel=analyte, units='fold vs untreated')

# ---------------- S11 ----------------
for blk, r0 in (('S11-A', 3), ('S11-B', 10), ('S11-D', 24)):
    add_wide_rows(blk, 'S11', r0, r0+4, 'B', hdr('S11', [f'{c}{r0-1}' for c in ('B', 'G', 'L', 'Q')]), 5, time_col='A', units='%')
add_cols('S11-C', 'S11', 17, 21, 'A', hdr('S11', ['A16', 'B16']), units='%')
add_cols('S11-E', 'S11', 31, 35, 'A', hdr('S11', ['A30', 'B30', 'C30', 'D30']), units='%')

# ---------------- S12 ----------------
add_cols('S12-A', 'S12', 3, 5, 'A', hdr('S12', ['A2', 'B2']), units='%')

# ---------------- S13 ----------------
for blk, c0 in (('S13-A', 'A'), ('S13-B', 'E'), ('S13-C', 'I'), ('S13-D', 'M')):
    add_cols(blk, 'S13', 3, 7, c0, hdr('S13', [f'{gcl(cidx(c0)+k)}2' for k in range(3)]), units='reciprocal titre')
add_cols('S13-H', 'S13', 53, 57, 'A', hdr('S13', ['A52', 'B52', 'C52', 'D52']), units='%')
add_cols('S13-I', 'S13', 53, 57, 'F', hdr('S13', ['F52', 'G52', 'H52', 'I52', 'J52']), units='reciprocal titre')
add_cols('S13-J', 'S13', 53, 57, 'L', hdr('S13', ['L52', 'M52', 'N52', 'O52', 'P52']), units='reciprocal titre')
add_wide_rows('S13-F', 'S13', 33, 40, 'B', hdr('S13', ['B32', 'I32', 'P32', 'W32', 'AD32']), 7, time_col='A', kind='weight', units='% of day0')
add_wide_rows('S13-G', 'S13', 43, 50, 'B', hdr('S13', ['B42', 'L42', 'V42']), 10, time_col='A', kind='weight', units='% of day0')

# ---------------- S14 ----------------
add_cols('S14-A H1N1', 'S14', 3, 7, 'A', hdr('S14', ['A2', 'B2', 'C2', 'D2']), units='%')
add_cols('S14-A H3N2', 'S14', 3, 7, 'F', hdr('S14', ['F2', 'G2', 'H2', 'I2']), units='%')

# ---------------- body-weight blocks on S09 / S15 ----------------
for blk, r0 in (('S09-C', 12), ('S09-E', 39), ('S09-G', 66)):
    add_wide_rows(blk, 'S09', r0, r0+7, 'G', hdr('S09', [f'{c}{r0-1}' for c in ('G', 'O', 'W')]), 8, time_col='F', kind='weight', units='% of day0')
for blk, r0, hc in (('S15-A', 3, ['B', 'I', 'P', 'W']), ('S15-B', 13, ['B', 'I', 'P', 'W']), ('S15-C', 23, ['B', 'I', 'P', 'W']),
                    ('S15-D', 33, ['B', 'I', 'P', 'W']), ('S15-E', 43, ['B', 'I', 'P', 'W', 'AD']), ('S15-F', 53, ['B', 'I', 'P', 'W', 'AD']),
                    ('S15-G', 63, ['B', 'I', 'P', 'W', 'AD'])):
    add_wide_rows(blk, 'S15', r0, r0+7, 'B', hdr('S15', [f'{c}{r0-1}' for c in hc]), 7, time_col='A', kind='weight', units='% of day0')
add_wide_rows('S15-I', 'S15', 72, 79, 'I', hdr('S15', ['I71', 'P71', 'W71']), 7, time_col='H', kind='weight', units='% of day0')
for blk, r0 in (('S15-J', 83), ('S15-K', 93), ('S15-M', 103), ('S15-O', 134)):
    add_wide_rows(blk, 'S15', r0, r0+7, 'I', hdr('S15', [f'{c}{r0-1}' for c in ('I', 'P', 'W', 'AD')]), 7, time_col='H', kind='weight', units='% of day0')

tidy = pd.DataFrame(rows)
tidy['group'] = tidy['group'].astype(str).str.strip()

# ---------------- time-to-event blocks ----------------
surv_rows = []
def add_surv(block, sheet, time_col, first_row, last_row, group_cols, hdr_row):
    ws = wb[sheet]
    for r in range(first_row, last_row+1):
        t = ws[f'{time_col}{r}'].value
        for cl in group_cols:
            e = ws[f'{cl}{r}'].value
            if e is not None:
                surv_rows.append(dict(block=block, sheet=sheet, group=str(ws[f'{cl}{hdr_row}'].value).strip(),
                                      time=t, event=e, time_cell=f'{time_col}{r}', event_cell=f'{cl}{r}'))

add_surv('S03-I', 'S03', 'A', 17, 51, list('BCDEF'), 16)
add_surv('S03-J', 'S03', 'G', 17, 46, list('HIJ'), 16)
add_surv('S06-A', 'S06', 'A', 3, 30, list('BCDE'), 2)
add_surv('S06-B', 'S06', 'G', 3, 30, list('HIJK'), 2)
add_surv('S06-C', 'S06', 'M', 3, 30, list('NOPQ'), 2)
add_surv('S06-D', 'S06', 'A', 34, 61, list('BCDE'), 33)
add_surv('S06-E (rows 34-68)', 'S06', 'G', 34, 68, list('HIJKL'), 33)
add_surv('S06-F (rows 34-68)', 'S06', 'M', 34, 68, list('NOPQR'), 33)
add_surv('S06-G', 'S06', 'A', 71, 105, list('BCDEF'), 70)
add_surv('S06-E (rows 71-105)', 'S06', 'G', 71, 98, list('HIJK'), 70)
add_surv('S06-F (rows 71-105)', 'S06', 'M', 71, 98, list('NOPQ'), 70)
add_surv('S09-B', 'S09', 'A', 12, 35, list('BCD'), 11)
add_surv('S09-D', 'S09', 'A', 39, 62, list('BCD'), 38)
add_surv('S09-F', 'S09', 'A', 66, 88, list('BCD'), 65)
add_surv('S13-E', 'S13', 'R', 3, 30, list('STUV'), 2)
add_surv('S15-H', 'S15', 'A', 73, 93, list('BCD'), 72)
add_surv('S15-L', 'S15', 'A', 103, 130, list('BCDE'), 102)
add_surv('S15-N', 'S15', 'A', 134, 161, list('BCDE'), 133)
surv = pd.DataFrame(surv_rows)

if __name__ == '__main__':
    tidy.to_csv('/tmp/outputs/analysis/tidy_values.csv', index=False)
    surv.to_csv('/tmp/outputs/analysis/tidy_survival.csv', index=False)
    print(tidy.shape, surv.shape)
    # completeness check: every numeric cell in the workbook must be captured exactly once
    captured = set(zip(tidy.sheet, tidy.cell)) | set(zip(surv.sheet, surv.time_cell)) | set(zip(surv.sheet, surv.event_cell))
    dup = tidy[tidy.duplicated(['sheet', 'cell'], keep=False)]
    print('duplicate captures:', len(dup))
    missing = []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for c in row:
                if isinstance(c.value, (int, float)) and (ws.title, c.coordinate) not in captured:
                    missing.append((ws.title, c.coordinate, c.value))
    print('numeric cells not captured:', len(missing))
    for m in missing: print('   ', m)
    none_vals = tidy[tidy.value.isna()]
    print('captured-but-empty cells:', len(none_vals))
    print(none_vals.groupby(['block', 'group']).size().to_string())

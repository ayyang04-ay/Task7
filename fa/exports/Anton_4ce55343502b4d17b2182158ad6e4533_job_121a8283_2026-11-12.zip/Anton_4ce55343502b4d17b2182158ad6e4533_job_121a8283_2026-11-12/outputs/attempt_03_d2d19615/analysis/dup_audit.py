import pandas as pd, numpy as np, itertools
from parse_blocks import tidy, surv
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 800); pd.set_option('display.max_columns', 50)

w = tidy[tidy.kind == 'weight'].copy()
w['time'] = w['time'].astype(float)
series = {}
for (blk, grp, rep), d in w.groupby(['block', 'group', 'rep'], sort=False):
    s = d.set_index('time').value
    series[(blk, grp, rep, d.cell.iloc[0].rstrip('0123456789'))] = s

keys = list(series)
res = []
for a, b in itertools.combinations(keys, 2):
    sa, sb = series[a], series[b]
    days = [d for d in sa.index if d in sb.index and d > 0]
    same = [d for d in days if sa[d] is not None and sb[d] is not None and not pd.isna(sa[d]) and not pd.isna(sb[d]) and abs(sa[d]-sb[d]) < 1e-9]
    both = [d for d in days if sa[d] is not None and sb[d] is not None and not pd.isna(sa[d]) and not pd.isna(sb[d])]
    if len(same) >= 3:
        res.append(dict(a_block=a[0], a_group=a[1], a_col=a[3], b_block=b[0], b_group=b[1], b_col=b[3], n_same=len(same), n_both=len(both), days_same=[int(x) for x in same]))
r = pd.DataFrame(res).sort_values(['a_block', 'b_block', 'a_col'])
print('animal-column pairs sharing >=3 identical same-day weights (day0 excluded):', len(r))
print(r.to_string())
r.to_csv('weight_duplicate_pairs.csv', index=False)

# summarise at block-group level
g = r.groupby(['a_block', 'a_group', 'b_block', 'b_group']).agg(n_animal_pairs=('n_same', 'size'), total_identical_values=('n_same', 'sum')).reset_index()
print(g.to_string())
g.to_csv('weight_duplicate_groups.csv', index=False)

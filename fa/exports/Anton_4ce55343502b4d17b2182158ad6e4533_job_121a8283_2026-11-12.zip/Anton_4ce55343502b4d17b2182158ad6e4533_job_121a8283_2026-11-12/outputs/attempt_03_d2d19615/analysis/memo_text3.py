exec(open('memo_text2.py').read())

add(f"""
### 4.3 What the next studies have to establish

Durations below are planning assumptions. Mice of 20 months or more are the rate-limiting reagent and should be reserved at approval.

**Table 5. Overview**

| Study | What it has to establish | Runs | Feeds |
|---|---|---|---|
| 0. Source-data audit | The file is sound, or which experiments must be repeated | Weeks 0–6 | Gate 0 |
| 1. Blinded confirmatory challenge with component controls | The effect replicates; Mn and cyclic dinucleotide are both needed; how it compares with an enhanced-vaccine stand-in; deaths are due to infection | Months 1–7 | Gate 1 |
| 2. Mediator of survival | Which of CD8 T cells, CD4 T cells, antibody, monocyte influx, interferon signalling and GM-CSF the survival benefit depends on | Months 2–7 | Gate 1; biomarker choice |
| 3. Dose, pharmacodynamics and biomarker bridging | Lowest effective dose and margin; marker-to-protection relation in individual animals; whether nasal and blood samples report the lung | Months 3–9 | Gate 1; clinical dose rationale |
| 4. Airway manganese safety | Whether Mn reaches and stays in olfactory bulb or brain; nasal and lung tolerance in aged animals; repeat dosing | Pilot months 2–8; GLP after Gate 2 | Gate 1; IND |
| 5. Translation | Activity with a licensed antigen, by a human-usable route, in ferrets, and on human aged-donor cells | Months 2–15 | Gate 2 |
| 6. CMC readiness | A characterised, stable, assayable product | Months 1–12 | Gate 2 |
| 7. First-in-human outline | Safety, dose and proof of mechanism in adults ≥65 | Not before month 27–30 | – |

**Study 0. Source-data audit (Gate 0)**

- *Has to establish:* for each of the 22 logged issues, whether it is a transcription error or real. Specifically: the true S06-D table; the group labels of S03-I/S13-F and S03-J/S13-G; the headers of S03-B, S03-F, S08-C and S07-C; the origin of S11-B and of the shared body-weight values; the identity of S08 rows 89–101 and of "PSLN-344/R848"; cause of death of the four untreated animals; Mn content per dose and the meaning of "20 µg".
- *Population:* none. Records: notebooks, instrument exports, animal-facility mortality logs.
- *Comparator:* workbook against raw records.
- *Endpoint:* a corrected, QA-signed file; this analysis re-run on it (scripts supplied in `analysis/`).
- *Timing:* 4–6 weeks, before any external disclosure.
- *Decision rule:* proceed if the pooled survival difference remains at least 40 points. Stop and escalate if any outcome, as opposed to a label, proves to have been altered.

**Study 1. Blinded confirmatory challenge study with component controls**

- *Has to establish:* (a) the Mn-dependent rescue replicates under randomisation, blinding and a pre-registered analysis; (b) Mn and the cyclic dinucleotide are each necessary; (c) where PSLN-344 stands against a stand-in for licensed enhanced vaccines; (d) deaths are due to infection.
- *Population:* mice of 20 months or more, both sexes, two strains (BALB/c and C57BL/6, both responsive in the present file [S15-L]); 7–8-week mice as reference. Eighteen per arm for survival, which gives about 90% power for 80% vs 25% survival (Fisher, two-sided 5%); six per arm per time point for virology and immunology; ten unchallenged age-matched animals per cohort with necropsy of every death. Scale: the day-14 cohort in one strain is 8 arms × 18 = 144 challenged animals plus satellites; the second strain and the day-60 cohort can follow if aged-animal supply is short.
- *Comparators:* vaccine + empty liposome; PSLN-212; **PSLN-344**; a Mn-only particle at matched Mn; PSLN-212 mixed with free Mn²⁺ at matched Mn; PSLN-212 given twice; an intramuscular high-dose or oil-in-water-emulsion-adjuvanted vaccine arm; young mice + PSLN-212. Antigen: the current whole-virion vaccine and, in parallel arms, a split antigen at matched HA.
- *Endpoints:* primary, survival to day 14 after a different-subtype challenge (H3N2 vaccine → 5× mLD50 PR8 H1N1) given 14 days after one dose. Key secondary: lung virus titre 3 and 6 days after challenge; body-weight area under the curve with one pre-declared rule for dead animals; clinical score; survival after a day-60 challenge in a second cohort; a matched-strain challenge arm.
- *Read-outs:* HAI and neutralisation against vaccine and challenge strains; IgG binding to challenge-strain antigens (cross-reactive antibody has never been measured); nasal-wash and lung-lavage IgA; lung and blood CD8 by tetramer and IFN-γ on days 7, 14 and 60; lung-resident memory CD8 with intravascular labelling.
- *Timing:* dose day 0; challenge day 14 (cohort A) and day 60 (cohort B); 14–21 days of observation. About 3 months in life, 6–7 months to report.
- *Decision rule:* pass if PSLN-344 survival is at least 70% and at least 40 points above PSLN-212 with a 95% interval excluding zero, in both strains, and PSLN-344 beats the Mn-only and Mn-admixture arms. If Mn alone or admixed Mn does as well, the product definition changes before any further spend.

**Study 2. What mediates survival**

- *Has to establish:* whether the survival benefit at day 3 and at day 14 depends on CD8 T cells, CD4 T cells, serum antibody, monocyte influx, interferon signalling or GM-CSF; and whether GM-CSF add-back rescues PSLN-212.
- *Population:* mice of 20 months or more, one strain, 12–15 per arm (89–94% power to detect a fall from 80% to 15% survival).
- *Comparators (all vaccine + PSLN-344 unless stated):* isotype control; anti-CD8 before challenge; anti-CD4 before challenge; both; the CCR2 antagonist around vaccination as in S07-B; anti-interferon-receptor antibody at vaccination; anti-GM-CSF at vaccination; PSLN-212 + recombinant GM-CSF as in S02-G; day-14 serum from PSLN-344 donors transferred into unvaccinated aged recipients; lung and lymph-node CD8 T cells transferred likewise.
- *Endpoints:* primary, survival. Secondary, lung virus titre and body weight.
- *Read-outs:* confirmation of each depletion or blockade by flow cytometry or ELISA; monocyte-derived dendritic cells and CD8 T cells in satellite animals.
- *Timing:* alongside Study 1; about 5–6 months.
- *Decision rule:* the arm or arms that remove at least half of the survival benefit define the on-path read-out to carry into Study 3 and the clinic. If serum alone transfers cross-subtype protection, antibody-breadth assays take priority over T-cell assays.

**Study 3. Dose, pharmacodynamics and biomarker bridging in the same animals**

- *Has to establish:* the lowest fully effective dose and its margin to reactogenicity; the relation between the early marker and later protection in individual animals; whether nasal and blood measurements report the lung response.
- *Population:* mice of 20 months or more; 12 per dose for challenge, 6 per dose per time point for tissue.
- *Comparators:* PSLN-344 at 0, 2.5, 5, 10, 20 and 40 µg (the *Ifnb1* response rises between 5 and 20 µg and is flat above [S08-A]); PSLN-212 at 20 and 40 µg; young mice + PSLN-212 at 20 µg.
- *Endpoints:* primary, survival by dose. Co-primary, the within-animal association between the 16–24 h marker and survival (logistic model and area under the ROC curve, declared in advance).
- *Read-outs:* in the challenge animals, without killing them: serum interferon-β or CXCL10, GM-CSF and CCL2 and whole-blood transcripts at 16–24 h and 72 h; blood monocyte phenotype on day 3; HAI, neutralisation and blood IFN-γ ELISpot on day 13; challenge on day 14. In satellite animals: nasal wash, lung lavage and lung tissue at 16 h, 72 h and day 4, to tie the accessible samples to lung *Ifnb1*, *Gm-csf*, *Ccl2* and lung monocyte and dendritic-cell counts. Tolerability: weight, temperature, lavage cell counts and protein, lung histology on days 1, 3, 7, 14 and 28.
- *Timing:* about 6 months, starting when Study 1 has its day-14 result.
- *Decision rule:* a dose of 20 µg or less with at least 70% survival and weight loss no worse than today's 20 µg data (mean lowest weight {n344[0]:.1f}%, worst animal {n344[1]:.1f}% [S08-D]). The marker goes to the clinic as a dose-selection tool only if at least one accessible-sample measurement rises with dose and separates survivors from non-survivors with an area under the curve of 0.8 or more; otherwise it goes as a mechanistic read-out only.

**Study 4. Airway manganese safety**

- *Has to establish:* whether Mn from the particle reaches the olfactory bulb or brain and persists; tolerance of the nose and of the aged lung; systemic cytokine exposure; the effect of repeat dosing. Inhaled Mn is a recognised neurotoxicant and travels along the olfactory nerve, and an intranasal influenza vaccine with a bacterial-toxin adjuvant was withdrawn after cases of facial palsy *[external]*; regulators will ask.
- *Population:* pilot in aged and young mice of both sexes, 6–8 per group per time point. GLP study in the species agreed with regulators, by the clinical route and device.
- *Comparators:* vehicle; PSLN-212; PSLN-344 at 1×, 3× and 10× the dose chosen in Study 3; intranasal Mn chloride at matched Mn as a positive control for uptake; cholera toxin as the positive control already used in S10-A.
- *Endpoints:* primary, Mn by inductively coupled plasma mass spectrometry (ICP-MS) in olfactory bulb, brain regions, lung, liver and blood at 24 h and days 7, 28 and 90, after one dose and after three; histopathology of nasal cavity including olfactory epithelium, olfactory bulb, brain, facial nerve and lung.
- *Read-outs:* olfactory and motor function tests; lung-lavage cytology; serum cytokines at 6–24 h; clinical pathology; weight and temperature; the S10-A central-nervous-system transcripts repeated as a time course from 6 h to day 7 with a wider panel.
- *Timing:* pilot 4–6 months (the day-90 necropsy sets the length). GLP study 9–12 months, after Gate 2.
- *Decision rule:* stop if Mn in olfactory bulb or brain is above vehicle at day 28 at three times the effective dose or less together with a histological or functional change, or if lung inflammation is unresolved at day 28.

**Study 5. Translation**

- *5a, deposition (mice ≥20 months; months 2–5).* Upper-airway-restricted dosing against the present dosing against intratracheal dosing. Comparators: PSLN-344, PSLN-212, sham by each route. Endpoints: lung and nasal *Ifnb1* at 16 h; survival after different-subtype challenge. Establishes whether deep-lung delivery is required.
- *5b, human cells (months 2–6).* Blood monocytes and mononuclear cells from at least 12 donors aged 65 or more and 12 aged 18–40, STING genotype recorded; lung-lavage macrophages where obtainable. Comparators: vehicle, PSLN-212, PSLN-344, Mn-only particle over five or six concentrations. Read-outs: interferon-β, CXCL10, GM-CSF, TNF and IL-6 protein at 6 and 24 h. Establishes whether the age-related ceiling and its rescue by Mn exist in human cells.
- *5c, ferret (months 8–15).* Adult ferrets, and aged ferrets if obtainable. Licensed split antigen with or without PSLN-344 through a clinical-type nasal or inhalation device. Comparators: antigen alone by the same route; PSLN-212; a licensed high-dose or adjuvanted vaccine intramuscularly. Challenge 28 days after dosing with a drifted and with a different-subtype human isolate. Primary endpoint: nasal-wash virus titre, area under the curve, days 1–7. Secondary: fever, weight, clinical score, HAI, neutralisation, nasal IgA. Read-outs: the Study 3 marker panel in nasal wash and blood at 24–72 h.
- *Decision rule:* activity with a licensed antigen and by a human-usable route, and virus shedding no worse than the licensed-vaccine arm.

**Study 6. CMC readiness (alongside)**

- *Has to establish:* particle size, polydispersity, charge and morphology (measured according to the annotation, absent from the file); Mn content and release; cyclic-dinucleotide loading with a specification (encapsulation is {ee344}% ± {ee344sd} over three preparations [S08-B]); a cell-based potency assay tied to the in-vivo *Ifnb1* response; stability of lyophilised material at −20 °C and 2–8 °C at 1, 3, 6 and 12 months; compatibility with licensed antigens.

**Study 7. First-in-human outline (only after Gates 1 and 2 and GLP toxicology)**

- *Population:* Part A, healthy adults 18–49 as sentinels, about 8 per dose. Part B, adults of 65 or more, the intended population, 25–30 per arm, stratified 65–74 and 75 or more. A 50–64 cohort is worth considering, because the Mn-free particle had already failed in 14-month mice [S06-E and S06-F, rows 71–105], roughly human middle age *[external]*. The first study excludes chronic lung disease needing daily treatment, neurological disease and any history of facial palsy.
- *Comparators:* licensed inactivated antigen alone by the same route; the same antigen with PSLN-344 at three dose levels; a licensed enhanced vaccine for this age group given intramuscularly.
- *Endpoints:* primary, solicited nasal, respiratory and systemic reactions on days 0–7, unsolicited events to day 28, serious events and events of special interest (facial palsy, change in sense of smell, wheeze, new neurological signs) to day 180; blood Mn. Secondary, HAI geometric mean titre, seroconversion and neutralisation on day 28 for each strain against the active control.
- *Read-outs:* the pharmacodynamic panel at 24 h and 72 h; circulating follicular helper T cells and plasmablasts on day 7; IFN-γ ELISpot to conserved internal proteins on days 14, 28 and 180; nasal IgA on day 28; antibody persistence on day 180.
- *Timing:* one dose; visits on days 0, 1, 3, 7, 14, 28, 90 and 180.

### 4.4 Gates and stop rules

| Gate | When | Pass criteria | Stop if |
|---|---|---|---|
| 0 | Week 6 | Issues reconciled or the affected experiments queued for repeat; pooled difference still ≥ 40 points on the corrected file | An outcome, not a label, was altered |
| 1 | Month 9–10 | Study 1 passes in both strains; Study 2 identifies at least one mediator whose removal takes away half or more of the benefit; Study 3 finds an effective dose ≤ 20 µg with acceptable weight loss; Study 4 pilot shows no Mn retention in olfactory bulb or brain with pathology and lung inflammation resolved by day 28 | Replication fails (PSLN-344 below 60% survival or less than 30 points above PSLN-212); Mn-only particle matches PSLN-344 (re-scope, do not proceed as is); neural Mn signal |
| 2 | Month 15 | Activity with a licensed split antigen; activity by a human-usable route; ferret shedding no worse than the licensed-vaccine arm; Mn-dependent enhancement in cells from donors of 65 or more; CMC specification and 6-month stability | Protection needs deep-lung deposition that a device cannot deliver safely; no activity with licensed antigen; no Mn effect in human aged cells |
""")

add(f"""
## 5. What I considered and ruled out

**Alternative explanations of the result**

| Hypothesis | Test in our data | Verdict |
|---|---|---|
| PSLN-344 is simply a stronger dose of the same agonist | Dose series: PSLN-212 at 40 µg ({d212_40}-fold) stays below PSLN-344 at 10 µg ({d344_10}-fold); plateaus {e212['emax']:.0f} vs {e344['emax']:.0f}, similar half-maximal dose [S08-A] | Ruled out. Mn raises the ceiling |
| Protection is an innate antiviral state from the STING agonist | PSLN-344 without antigen {SV('S15-H', '3d PSLN-344')}; with antigen {SV('S15-H', '3d Vaccine+PSLN-344')} [S15-H] | Ruled out |
| Protection is HAI or neutralising antibody to the vaccine strain | Cross-subtype protection in six experiments; protection at day 2–3; PSLN-212 arm with HAI ≥ 40 in {CNT('S03-C', 'PSLN-212', 40)} survived {SV('S03-I', 'PSLN-212')} [S03-C, S03-I, S06] | Ruled out as the driver; likely contributes against matched strains |
| A BALB/c peculiarity | C57BL/6 {SV('S15-L', 'PSLN-344')} vs {SV('S15-L', 'PSLN-212')}; outbred Swiss Webster {SV('S15-N', 'PSLN-344')} vs {SV('S15-N', 'PSLN-212')} [S15-L, S15-N] | Ruled out |
| It only works in animals that have never met influenza, or prior infection does the work | {imp['Naïve+PSLN-344']} unprimed and {imp['Imprinting+PSLN-344']} imprinted; with PSLN-212, imprinting helped only against the imprinting virus ({imp['Imprinting+PSLN-212']} vs PR8, {impP['Imprinting+PSLN-212']} vs H3N2) [S06-E, S06-F rows 71–105] | Ruled out |
| The result is produced by the data defects | Five analyses from "as printed" to "least favourable": {P_worst['rd']:.0f} to {P_all['rd']:.0f} points; nine unflagged comparisons alone {pl(P_clean)} (§2.1) | Ruled out |
| Better encapsulation of the agonist in PSLN-344 | {ee344}% vs {ee212}% [S08-B] | Ruled out |
| Mn improves delivery to the epithelium | S08-C conflicts with S01-B (D05) | Cannot be judged |
| PSLN-344 skews antibody toward IgG1 | S03-B as printed says so; recomputed from subclass titres it is the reverse ({q(q_h1, 'PSLN-344')} vs {q(q_h1, 'PSLN-212')}) [S13-A, S13-B] | Ruled out; label error (D04) |
| Protection wanes by day 60 | PSLN-344 deaths {p14_d}/{p14_n} at day 14, {p60_d}/{p60_n} at day 60, but {unt_d}/{unt_n} unchallenged controls also died [S06] | Not established either way |
| Restored dendritic-cell co-stimulation explains it | CD40 and CD86 reach only {pct_of('S02-D CD40', 'PSLN-344', 'PSLN-212(Y)')} and {pct_of('S02-D CD86', 'PSLN-344', 'PSLN-212(Y)')} of young while survival returns [S02-D] | Ruled out as a requirement |
| A lasting fall in follicular regulatory T cells explains it | Gone by day 30 ({A('S04-C', 'PSLN-344')}% vs sham {A('S04-C', 'Sham')}%) [S04-C] | Ruled out as a lasting effect |

**Alternative products and positions**

| Option | Evidence | Verdict |
|---|---|---|
| Advance PSLN-212 and leave out the Mn | Young mice {SV('S09-B', 'PSLN-212Y')}, {SV('S09-D', 'PSLN-212Y')}, {SV('S09-F', 'PSLN-212Y')}; aged mice {P_all['b']}/{P_all['n2']} [S09, Table 1] | Rejected for older adults. It is a young-adult adjuvant |
| Give PSLN-212 twice instead | After a boost, IgG is still {fold('S13-I', 'PSLN-344', 'PSLN-212', geo=True)} (H1N1) and {fold('S13-J', 'PSLN-344', 'PSLN-212', geo=True)} (H3N2) below PSLN-344; no challenge after boost [S13-I, S13-J] | Not supported; tested properly in Study 1 |
| Add GM-CSF to PSLN-212 instead of Mn | Raises the dendritic-cell-like population {fold('S02-G', 'PSLN-212+GM-CSF', 'PSLN-212')} [S02-G]; no protection data | Kept as a mechanistic tool (Study 2), not as a product |
| The cGAMP particle CMP-204 | Aged: *Ifnb1* {ifnCMP}-fold, IgG geometric mean {G('S03-A', 'CMP-204')}, survival {SV('S03-I', 'CMP-204')} as printed (D02); young {SV('S13-E', 'CMP-204(Y)')} [S01-A, S03-A, S03-I, S13-E] | Rejected for older adults |
| The TLR7/8 agonist R848, alone or combined | PSLN-R848 *Ifnb1* {ifnR}-fold; PSLN-212/R848 {ifn212R}-fold with *Tnf* {F9('Tnf', 'PSLN-212/R848')}-fold, *Il10* {F9('Il10', 'PSLN-212/R848')}-fold and progressive weight loss to {d10_r848[0]:.2f}% [S01-A, S09-A, S08-D] | Rejected on tolerability |
| PSLN-344 as a stand-alone antiviral prophylactic | {SV('S15-H', '3d PSLN-344')} [S15-H] | Rejected |
| PSLN-344 for young adults | No survival gain over PSLN-212 ({SV('S09-B', 'PSLN-344Y')} vs {SV('S09-B', 'PSLN-212Y')}) and a higher interferon response ({ifn344Y}- vs {ifnY}-fold) [S09, S01-A] | Rejected; the asset is specific to the aged host |

**Alternative recommendations**

- *Unconditional go to IND-enabling work.* Rejected. The integrity defects, the untested causal link and the thin airway-Mn safety data would each be found in diligence, and each can be closed for far less than a GLP and GMP programme costs.
- *No-go.* Rejected. The effect is the largest and most consistent thing in the file, it survives every sensitivity analysis, and the open questions are answerable with bounded experiments. Stopping now would discard the asset for reasons that are fixable.
- *Hold with no spend.* Rejected. Nothing resolves without the audit and the replication, and aged-animal lead times mean a hold costs a year.

**Analyses I chose not to rely on**

Group mean body-weight curves (two conventions for dead animals, re-used values); S06-D; S03-B and S03-F as printed; S07-C; S11-B; S08 rows 89–101; S05-A and S05-B beyond description (two animals, contradictory conditions); arithmetic means of titres; p-values from single 7-versus-7 experiments as stand-alone evidence.

## 6. If the committee decides to drop it

**What we would be dropping.** The only preparation in the file that gives aged animals young-like protection: {y_344[0]}/{y_344[1]} against {y_Y[0]}/{y_Y[1]} in young animals and {y_212[0]}/{y_212[1]} for the same particle without Mn, from one needle-free dose, across subtypes, within days, for at least two months. And the finding behind it: in the aged lung the interferon and GM-CSF response to a STING agonist is capped, not merely shifted, and Mn removes the cap. That is a finding about ageing and adjuvants that may reach beyond influenza.

**Why one might still drop it.** An airway product containing manganese for people over 65 will carry a heavy toxicology burden; the mechanism as shown depends on reaching the deep lung; the efficacy is in mice with a whole-virion antigen; the file needs an audit before it can support anything.

**What we would keep.** PSLN-212 as a young-adult adjuvant (8/8 in three experiments); the surfactant-biomimetic particle; the mechanistic read-outs.

**Minimum close-out to preserve value.** Complete Gate 0 regardless, because the same workbook underpins PSLN-212; retain characterised lots under stability; secure the Mn–ageing finding (patent or publication); keep the analysis scripts with the corrected file so that a partner can reproduce every number.
""")

# -------------------------------- appendices
di_tab = ['| ID | Severity | Where | Finding | Consequence | How handled |', '|---|---|---|---|---|---|']
for r in DI:
    di_tab.append(f'| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {r[5]} | {r[6]} |')
add(f"""
## Appendix A. Methods

- **Parsing.** Every sheet was read cell by cell. Each value keeps its sheet and cell address. All 6,819 numeric cells are assigned to a block, an axis (day or dose) or the unlabelled region S08!A89:D101; none is unassigned. Labels are kept exactly as printed.
- **Reductions.** Percentages, cell counts and linear fold-changes: arithmetic mean and SD of the per-animal values. Titres: geometric mean; HAI values printed as 0 set to 5. S09-A: mean of the stored log10 values, back-transformed. Survival: rows with event flag 0 over rows printed; a row with a flag but no day (S03!J46) counts as a survivor in the primary analysis and is dropped in the least-favourable one.
- **Tests.** The methods named in the annotation were used: one-way ANOVA with Tukey's test within a block (log10 scale for titres and fold-changes), and log-rank for time to event, the latter as an exact permutation test because groups are small. Welch intervals are given for ratios and differences, exact Mann–Whitney and Fisher tests as checks. Pooled survival: Mantel–Haenszel risk difference stratified by comparison with an exact stratified permutation p-value. No correction for multiplicity across blocks was applied; p-values are descriptive.
- **Body weight.** Per animal, the lowest recorded value. An animal is counted as dead if its cells go blank or its value is constant below 90% through day 14.
- **Dose–response.** Three-parameter Hill function with baseline fixed at 1, least squares on the 15 per-animal values of each preparation.
- **Defect search.** Stated n against observed n; paired survival and weight blocks against each other; every derived block recomputed from its sources; all pairs of blocks compared for repeated values in the same positions.
- **Precedence.** Where the workbook and the annotation disagree, the workbook as printed is the primary analysis and the alternative is a sensitivity analysis.
- **Limits of this analysis.** Only the compiled workbook and its annotation were available: no raw instrument files, protocols or randomisation records. Conclusions that a label or a table is wrong are inferences from internal consistency and are marked as such. Durations, sample sizes for future studies, gate thresholds and the regulatory context are my proposals and planning assumptions, not data.
- **Reproducibility.** Scripts are in `analysis/`; `render.sh` rebuilds every table, figure, the ledger and this memo from the workbook.

## Appendix B. Evidence ledger

`evidence_ledger.csv` has one row per number used in this memo: block, quantity, value, n, sheet and cells, and the reduction applied. It is sorted by block, so a number cited as [S01-A] is found under S01-A. Pooled and derived quantities are listed under "pooled survival", "body weight after challenge", "power calculation", "integrity checks" and "workbook". `analysis/verify_ledger.py` recomputes every simple entry (means, SDs, geometric means, survivor counts: 248 rows) straight from the workbook cells named in the ledger; all agree. `tidy_values.csv` and `tidy_survival.csv` in `analysis/` hold every parsed cell with its address.

## Appendix C. Data-integrity log

{chr(10).join(di_tab)}

![Figure 6](figures/fig6_integrity_examples.png)

*Figure 6. Four of the logged issues, shown from the workbook values: (a) D01, (b) D04, (c) D07, (d) D06.*

## Appendix D. Questions the committee is likely to ask

| Question | Answer | Where |
|---|---|---|
| Seven animals per arm. Is that enough? | Not in any one experiment. The case rests on 14 comparisons that all point the same way ({pl(P_all)}); 12 of the 14 are individually significant by exact log-rank. Study 1 repeats it blinded with 18 per arm. | §2.1 |
| The file has errors. Why believe the result? | Because it does not depend on the disputed entries: the nine comparisons with no flag give {pl(P_clean)}, and the least favourable reading of every count gives {pl(P_worst)}. We still do not show the file outside until the audit is closed. | §2.1, §3.1 |
| Is this just a bigger dose of the same agonist? | No. PSLN-212 at 40 µg ({d212_40}-fold *Ifnb1*) stays below PSLN-344 at 10 µg ({d344_10}-fold). Mn raises the ceiling. | §2.2 |
| Could the adjuvant alone be protecting, as an antiviral? | No. Without antigen it protected {SV('S15-H', '3d PSLN-344')}; with antigen {SV('S15-H', '3d Vaccine+PSLN-344')}. | §4.1 |
| Do we know how it protects? | In part. The steps from Mn to interferon and GM-CSF to monocyte-derived dendritic cells have intervention evidence. The step from CD8 T cells to survival has none yet. Study 2 supplies it. | §4.1 |
| Is it safe? | Too early to say. Weight loss averaged {100 - n344[0]:.1f}% and reversed by day 10, and central-nervous-system tissue showed no cholera-toxin-type signal, but there are five animals per group, no pathology and no Mn measurement. Study 4 has a stop rule. | §2.5, §4.3 |
| How does it compare with the enhanced vaccines older adults get now? | Unknown. It has never been tested against them. Studies 1 and 5 include such arms. | §3.2 |
| Will it work in people who have had influenza many times? | The one experiment on this says yes: {imp['Naïve+PSLN-344']} without and {imp['Imprinting+PSLN-344']} with a prior infection. | §2.3 |
| How long does protection last? | At least 60 days ({pl(P_d60)}). The apparent fall from day 14 cannot be separated from age-related deaths ({unt_d}/{unt_n} in unchallenged controls). | §2.3 |
| Why not the simpler PSLN-212? | It protects young mice ({SV('S09-B', 'PSLN-212Y')} in each of three experiments) and fails in aged ones ({P_all['b']}/{P_all['n2']}). | §5 |
| What is the biomarker, and can we use it in the clinic? | The early interferon-β/GM-CSF/monocyte–dendritic-cell response. After a bridging study, as a pharmacodynamic marker for dose selection. Not as a surrogate for protection. | §4.2 |
| What would make us stop? | Failed blinded replication; Mn alone matching PSLN-344; Mn retained in olfactory bulb or brain with pathology; a need for deep-lung delivery that no device can meet safely; no activity with a licensed antigen. | §4.4 |

## Appendix E. Kaplan–Meier curves

![Figure 7](figures/fig7_kaplan_meier.png)

*Figure 7. Survival curves rebuilt from the time-to-event tables for the twelve main experiments.*
""")

# ---------- forensic counts quoted in the text and the integrity log: recomputed here and written to the ledger ----------
_w = tidy[tidy.kind == 'weight'].copy(); _w['time'] = _w.time.astype(float)
def _grid(blk, g):
    d = _w[(_w.block == blk) & (_w.group == g) & (_w.time > 0)]
    return d.pivot(index='time', columns='rep', values='value').astype(float).values
def _same(A, B):
    m = (~np.isnan(A)) & (~np.isnan(B)); return int(((A == B) & m).sum()), int(m.sum())
def _best(A, B):
    if A.shape[1] == B.shape[1]: return _same(A, B)
    big, small = (A, B) if A.shape[1] > B.shape[1] else (B, A)
    return max((_same(big[:, o:o + small.shape[1]], small) for o in range(big.shape[1] - small.shape[1] + 1)), key=lambda x: x[0])
for (a, b, where) in [(('S15-C', 'PSLN-344'), ('S15-I', '3d Vaccine+PSLN-344'), 'S15!W24:AC30 vs S15!W73:AC79'),
                      (('S09-E', 'PSLN-344Y'), ('S15-M', 'PSLN-212(Y)'), 'S09!X40:AD46 vs S15!I104:O110'),
                      (('S15-A', 'PSLN-344'), ('S15-M', 'PSLN-344'), 'S15!W4:AC10 vs S15!AD104:AJ110')]:
    k, n = _best(_grid(*a), _grid(*b))
    reg('integrity checks', f'identical same-day weights, {a[0]} {a[1]} vs {b[0]} {b[1]}', f'{k} of {n}', where, 'count of cells with exactly equal values at the same animal position and day (day 0 excluded)', n)
_a = tidy[tidy.block == 'S11-A'].value.astype(float).values; _b = tidy[tidy.block == 'S11-B'].value.astype(float).values
reg('integrity checks', 'identical same-position cells, S11-A vs S11-B', f'{int((_a == _b).sum())} of {len(_a)}', 'S11!B3:U7 vs S11!B10:U14', 'count of cells with exactly equal values at the same position', len(_a))
_c = surv[surv.block == 'S06-C'][['time', 'event']].values; _d = surv[surv.block == 'S06-D'][['time', 'event']].values
reg('integrity checks', 'identical rows, S06-C vs S06-D', f'{int((_c == _d).all(axis=1).sum())} of {len(_c)}', 'S06!M3:Q30 vs S06!A34:E61', 'row-by-row comparison of (day, event flag) in the printed order', len(_c))
for blk, grp, lab in [('S13-F', 'PSLN-212', 'S13!P33:V40'), ('S15-C', 'PSLN-212', 'S15!P23:V30'), ('S15-D', 'PSLN-344', 'S15!W33:AC40'), ('S15-D', 'PSLN-212', 'S15!P33:V40'),
                      ('S15-D', 'PSLN-212(Y)', 'S15!B33:H40'), ('S15-E', 'PSLN-344', 'S15!W43:AC50'), ('S15-E', 'PSLN-212', 'S15!P43:V50'), ('S15-G', 'PSLN-344', 'S15!W63:AC70'), ('S15-M', 'PSLN-212(Y)', 'S15!I103:O110')]:
    d = wa[(wa.block == blk) & (wa.group == grp)]
    reg('integrity checks', f'survivors implied by the weight block, {blk} {grp}', f"{int((d.status == 'survivor').sum())}/{len(d)}", lab,
        'animals whose trajectory neither goes blank nor stays constant below 90% to day 14', len(d))
_lr = [float(SP[(SP.block == r[0]) & (((SP.g1 == r[5]) & (SP.g2 == r[6])) | ((SP.g1 == r[6]) & (SP.g2 == r[5])))].logrank_p_exact.iloc[0]) for r in rows1]
reg('integrity checks', 'comparisons in Table 1 with exact log-rank p < 0.05', f'{sum(p < 0.05 for p in _lr)} of {len(_lr)}', 'Table 1', 'count over the 14 comparisons', len(_lr))
_t2 = C[(((C.g1 == 'PSLN-212') & (C.g2 == 'PSLN-344')) | ((C.g1 == 'PSLN-344') & (C.g2 == 'PSLN-212')))]
reg('workbook', 'numeric cells; labelled blocks; sheets', '6,819; 101; 15', 'whole workbook', 'count of cells holding a number; count of cells whose text begins with a block label (Snn-X); sheet count', '')

MEMO = '\n\n'.join(M) + '\n'
# relative column widths for wide tables (pandoc uses the dash counts of the separator row)
WIDTHS = {
 '| Your question |': [9, 37, 4],
 '| Block (cells) | Host |': [15, 11, 17, 5, 5, 6, 6, 6, 9, 4],
 '| Analysis | PSLN-344 |': [44, 9, 9, 16],
 '| Block (cells) | Design |': [13, 36, 38],
 '| Read-out (aged mice unless stated) |': [27, 17, 6, 7, 7, 8, 7, 8, 9],
 '| Link | Evidence in the file |': [20, 38, 13, 10, 15],
 '| Candidate |': [23, 20, 20, 19, 15],
 '| Study | What it has to establish |': [20, 48, 12, 11],
 '| Gate | When |': [4, 8, 46, 32],
 '| Hypothesis |': [24, 52, 18],
 '| Option |': [24, 52, 18],
 '| ID | Severity |': [4, 6, 14, 40, 18, 18],
 '| Question | Answer | Where |': [22, 60, 8],
}
_lines = MEMO.split('\n')
for i in range(len(_lines) - 1):
    for key, w in WIDTHS.items():
        if _lines[i].startswith(key) and set(_lines[i + 1]) <= set('|-: '):
            assert _lines[i].count('|') - 1 == len(w), (key, _lines[i].count('|') - 1, len(w))
            _lines[i + 1] = '|' + '|'.join('-' * (n * 2) for n in w) + '|'
MEMO = '\n'.join(_lines)
open('/tmp/outputs/PSLN-344_recommendation.md', 'w').write(MEMO)
# two-page decision brief = section 1 of the memo, verbatim, plus Figure 1
_brief = MEMO.split('## 2. The evidence for advancing')[0].rstrip()
_brief = _brief.replace('# PSLN-344 — recommendation for the portfolio review', '# PSLN-344 — decision brief for the portfolio review')
_brief = _brief.replace('## 1. Recommendation', '## Recommendation')
_brief += '\n\n![Figure 1](figures/fig1_survival_head_to_head.png)\n\n*Survival after lethal challenge in every head-to-head experiment (left) and the difference between PSLN-344 and PSLN-212 (right). Section and appendix references point to the full memo, `PSLN-344_recommendation`.*\n'
open('/tmp/outputs/PSLN-344_decision_brief.md', 'w').write(_brief)
L = pd.DataFrame(LEDGER)
def bkey(b):
    m = re.match(r'S(\d\d)-([A-Z])', b)
    return (0, int(m.group(1)), m.group(2), b) if m else (1, 0, '', b)
L['_k'] = L.block.map(bkey)
L = L.sort_values('_k', kind='stable').drop(columns='_k').reset_index(drop=True)
L.insert(0, 'ledger_id', [f'L{i+1:03d}' for i in range(len(L))])
L['n'] = L['n'].map(lambda v: '' if (v == '' or pd.isna(v)) else str(int(float(v))))
L.to_csv('/tmp/outputs/evidence_ledger.csv', index=False)
print('memo words:', len(MEMO.split()), '| ledger rows:', len(L))

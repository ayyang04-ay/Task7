import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from decimal import Decimal, ROUND_HALF_UP
from parse_blocks import tidy

fig, axes = plt.subplots(1, 3, figsize=(16.5, 5.4), gridspec_kw=dict(width_ratios=[1.25, 1, 0.9], wspace=0.28))
# (a) S01-A
ax = axes[0]
d = tidy[tidy.block == 'S01-A'].copy(); d['value'] = d.value.astype(float)
order = ['Sham', 'CMP-204', 'PSLN-R848', 'PSLN-212', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']
names = ['Sham', 'CMP-204\n(cGAMP)', 'PSLN-\nR848', 'PSLN-\n212', 'PSLN-212\n/R848', 'PSLN-\n344', 'PSLN-212\nyoung', 'PSLN-344\nyoung']
cols = {'Sham': '0.55', 'CMP-204': '0.55', 'PSLN-R848': '0.55', 'PSLN-212': '#2166ac', 'PSLN-212/R848': '0.55', 'PSLN-344': '#b2182b', 'PSLN-212(Y)': '#1b7837', 'PSLN-344(Y)': '#7fbf7b'}
rng = np.random.default_rng(3)
for i, g in enumerate(order):
    for j, (p, mk) in enumerate((('16h', 'o'), ('72h', 's'))):
        x = d[(d.group == g) & (d.panel == p)].value.values
        xx = i + (-0.19 if j == 0 else 0.19)
        ax.bar(xx, x.mean(), width=0.34, color=cols[g], alpha=0.85 if j == 0 else 0.35, edgecolor='none')
        ax.scatter(xx + rng.uniform(-0.09, 0.09, len(x)), x, s=14, color='k', zorder=3, marker=mk, alpha=0.75)
        if j == 0: ax.text(xx, x.max() + 1.5, str(Decimal(repr(round(float(x.mean()), 9))).quantize(Decimal('0.1'), rounding=ROUND_HALF_UP)), ha='center', fontsize=8.2)
ax.set_xticks(range(len(order))); ax.set_xticklabels(names, fontsize=8.4)
ax.set_ylabel('Lung Ifnb1 (fold vs untreated)')
ax.set_title('a  Ifnb1 at 16 h (solid) and 72 h (pale): Mn lifts the aged\n   response to the young level, and it is transient  [S01-A, n=5]', fontsize=10, loc='left')
ax.axhline(d[(d.group == 'PSLN-212(Y)') & (d.panel == '16h')].value.mean(), color='#1b7837', ls=':', lw=1)
ax.axvspan(5.5, 7.5, color='#1b7837', alpha=0.05)
ax.text(6.5, 66, 'young mice', ha='center', color='#1b7837', fontsize=8.5)
ax.set_ylim(0, 70)

# (b) S08-A dose response
ax = axes[1]
d = tidy[tidy.block == 'S08-A'].copy(); d['value'] = d.value.astype(float); d['dose'] = d.time.astype(float)
def hill(x, emax, ed50, h): return 1 + (emax - 1) * x**h / (ed50**h + x**h)
sty = {'CMP-204': ('0.55', 'v', 'CMP-204 (cGAMP)'), 'PSLN-212': ('#2166ac', 'o', 'PSLN-212'), 'PSLN-344': ('#b2182b', 'o', 'PSLN-344'), 'PSLN-344/R848': ('#d6a24c', 'D', '"PSLN-344/R848"*')}
xs = np.logspace(0, np.log10(40), 100)
for g, (c, mk, lab) in sty.items():
    x = d[d.group == g].dose.values; y = d[d.group == g].value.values
    p, _ = curve_fit(hill, x, y, p0=[y.max(), 10, 2], bounds=([1, 0.5, 0.3], [500, 200, 8]))
    ax.plot(xs, hill(xs, *p), color=c, lw=1.6)
    ax.scatter(x, y, color=c, marker=mk, s=26, zorder=3, label=f'{lab}: plateau ≈ {p[0]:.0f}×, ED50 ≈ {p[1]:.0f} µg')
y0 = tidy[(tidy.block == 'S01-A') & (tidy.group == 'PSLN-212(Y)') & (tidy.panel == '16h')].value.astype(float)
ax.axhspan(y0.mean() - y0.std(ddof=1), y0.mean() + y0.std(ddof=1), color='#1b7837', alpha=0.12)
ax.text(1.05, y0.mean() + 0.5, 'young benchmark: PSLN-212 20 µg in young mice\n(S01-A, mean ± SD)', color='#1b7837', fontsize=7.8, va='center')
ax.set_xscale('log'); ax.set_xticks([1, 5, 10, 20, 40]); ax.set_xticklabels(['1', '5', '10', '20', '40'])
ax.set_xlabel('Adjuvant dose (µg per animal, intranasal)'); ax.set_ylabel('Lung Ifnb1 at 16 h (fold vs untreated)')
ax.legend(fontsize=7.8, frameon=False, loc='upper left', bbox_to_anchor=(0.0, 1.0))
ax.set_ylim(0, 88)
ax.set_title('b  Dose–response: Mn raises the ceiling, not the potency —\n   more PSLN-212 cannot substitute  [S08-A, n=3]', fontsize=10, loc='left')

# (c) Gm-csf S02-F
ax = axes[2]
d = tidy[tidy.block == 'S02-F'].copy(); d['value'] = d.value.astype(float)
tmap = {'16h': 16, '36h': 36, '72h': 72}
for g, c in (('Sham', '0.55'), ('PSLN-212', '#2166ac'), ('PSLN-344', '#b2182b')):
    x = d[d.group == g]
    m = x.groupby('time', sort=False).value.agg(['mean', 'std'])
    tt = [tmap[t] for t in m.index]
    ax.errorbar(tt, m['mean'], yerr=m['std'], color=c, marker='o', capsize=3, lw=1.6, label=g)
    ax.scatter([tmap[t] for t in x.time], x.value, color=c, s=10, alpha=0.5)
ax.set_xticks([16, 36, 72]); ax.set_xlabel('Hours after immunisation'); ax.set_ylabel('Lung Gm-csf (fold vs untreated)')
ax.legend(frameon=False, fontsize=8.5)
ax.set_title('c  GM-CSF transcript is induced only\n   when Mn is present  [S02-F, n=5, aged]', fontsize=10, loc='left')
for a in axes:
    for s in ('top', 'right'): a.spines[s].set_visible(False)
fig.text(0.01, 0.005, 'Bars/points: arithmetic mean of per-animal values; error bars SD. Curves: 3-parameter Hill fit to the 15 per-animal points of each preparation (baseline fixed at 1). Aged mice unless labelled young. *This label is printed in S08-A but the preparation is not defined in the annotation.', fontsize=7.8, color='0.3')
fig.subplots_adjust(left=0.05, right=0.99, top=0.86, bottom=0.13)
fig.savefig('/tmp/outputs/figures/fig2_innate_trigger.png', dpi=170)

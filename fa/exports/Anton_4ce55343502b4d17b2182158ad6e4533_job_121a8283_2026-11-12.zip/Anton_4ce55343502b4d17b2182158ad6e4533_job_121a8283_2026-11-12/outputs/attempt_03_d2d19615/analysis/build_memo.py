exec(open('build_report.py').read())

def r0(x): return f'{x:.0f}'
def pl(P): return f"{P['a']}/{P['n1']} vs {P['b']}/{P['n2']}"
def rd(P): return f"{P['rd']:.0f} points (95% CI {P['lo']:.0f}–{P['hi']:.0f})"

# ---------- S08-D per-animal lowest weights ----------
w8 = tidy[tidy.block == 'S08-D'].copy(); w8['value'] = w8.value.astype(float); w8['time'] = w8.time.astype(int)
def nadir8(g):
    d = w8[(w8.group == g) & (w8.time > 0) & w8.value.notna()]
    per = d.groupby('rep').value.min()
    reg('S08-D', f'lowest post-dose weight per animal, mean and minimum, {g}', f'{per.mean():.2f}; {per.min():.1f}', cellrange(d),
        'per animal: minimum of the day 2-10 values (% of own day-0 weight); then arithmetic mean and minimum over animals', len(per))
    return per.mean(), per.min()
def day10(g):
    d = w8[(w8.group == g) & (w8.time == 10) & w8.value.notna()]
    reg('S08-D', f'mean weight on day 10, {g}', round(d.value.mean(), 2), cellrange(d), 'arithmetic mean of the per-animal day-10 values', len(d))
    return d.value.mean(), len(d)
n344 = nadir8('PSLN-344'); nvac = nadir8('Vaccine'); n212 = nadir8('PSLN-212'); nr848 = nadir8('PSLN-212/R848'); ncmp = nadir8('CMP-204')
d10_344 = day10('PSLN-344'); d10_r848 = day10('PSLN-212/R848')

# ---------- restoration index ----------
RI = pd.read_csv('restoration_index.csv')

# ---------- recomputed IgG2a/IgG1 ----------
def ratio_re(num, den, g):
    a = sel(num, g).value.values; b = sel(den, g).value.values; q = a / b
    reg(f'{num}/{den}', f'IgG2a/IgG1 quotient recomputed per animal, mean, {g}', round(q.mean(), 2), f'{cellrange(sel(num, g))} ÷ {cellrange(sel(den, g))}',
        'per animal: IgG2a titre ÷ IgG1 titre (same row); arithmetic mean of the five quotients', len(q))
    return q.mean()
q_h1 = {g: ratio_re('S13-A', 'S13-B', g) for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
q_h3 = {g: ratio_re('S13-C', 'S13-D', g) for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}

# =====================================================================================
#  Table 1: survival, experiment by experiment
# =====================================================================================
rows1 = [
 ('S03-I', 'BALB/c ≥20 mo', 'H1N1+H3N2 → CA09 H1N1 (10× mLD50)', 'd14', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'a'),
 ('S03-J', 'BALB/c, aged by label', 'rgH5N1 → wild-type H5N1', 'd2', 'Sham', 'PSLN-212', 'PSLN-344', None, 'b'),
 ('S06-A', 'BALB/c ≥20 mo', 'H3N2 → PR8 H1N1 (5× mLD50)', 'd14', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', ''),
 ('S06-B', 'BALB/c ≥20 mo', 'H3N2 → PR8 H1N1 (5× mLD50)', 'd3', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', ''),
 ('S06-C', 'BALB/c ≥20 mo', 'H1N1+H3N2 → rgH5N1 (5× mLD50)', 'd14', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'c'),
 ('S06-E (rows 34-68)', 'BALB/c ≥20 mo', 'H3N2 → PR8 H1N1 (5× mLD50)', 'd60', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'd'),
 ('S06-F (rows 34-68)', 'BALB/c ≥20 mo', 'H1N1+H3N2 → rgH5N1 (5× mLD50)', 'd60', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'd'),
 ('S06-G', 'BALB/c ≥20 mo', 'H1N1 → Perth H3N2 (5× mLD50)', 'd60', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'd'),
 ('S06-E (rows 71-105)', 'BALB/c 14 mo, unprimed', 'H1N1+H3N2 → PR8 H1N1 (5× LD50)', 'n.s.', None, 'Naïve+PSLN-212', 'Naïve+PSLN-344', None, 'e'),
 ('S06-E (rows 71-105)', 'BALB/c 14 mo, PR8-imprinted', 'H1N1+H3N2 → PR8 H1N1 (5× LD50)', 'n.s.', None, 'Imprinting+PSLN-212', 'Imprinting+PSLN-344', None, 'e'),
 ('S06-F (rows 71-105)', 'BALB/c 14 mo, unprimed', 'H1N1+H3N2 → Perth H3N2 (5× LD50)', 'd14', None, 'Naïve+PSLN-212', 'Naïve+PSLN-344', None, 'e'),
 ('S06-F (rows 71-105)', 'BALB/c 14 mo, PR8-imprinted', 'H1N1+H3N2 → Perth H3N2 (5× LD50)', 'd14', None, 'Imprinting+PSLN-212', 'Imprinting+PSLN-344', None, 'e'),
 ('S15-L', 'C57BL/6 20 mo', 'H1N1+H3N2 → virus n.s.', 'n.s.', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'f'),
 ('S15-N', 'Swiss Webster 20 mo', 'H1N1+H3N2 → virus n.s.', 'n.s.', 'Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'f'),
]
t1 = ['| Block (cells) | Host | Vaccine → challenge virus | Challenge day | Sham | PSLN-212 | **PSLN-344** | Young, PSLN-212 | 344 vs 212, exact log-rank p | Note |',
      '|---|---|---|---|---|---|---|---|---|---|']
for blk, host, vc, day, gs, g2, g3, gy, fl in rows1:
    name = blk.replace(' (rows 34-68)', ', rows 34–68').replace(' (rows 71-105)', ', rows 71–105')
    t1.append(f"| {name} ({blockrange(blk)}) | {host} | {vc} | {day} | {SV(blk, gs) if gs else '–'} | {SV(blk, g2)} | **{SV(blk, g3)}** | {SV(blk, gy) if gy else '–'} | {LR(blk, g2, g3)} | {fl} |")
    FISH(blk, g2, g3)
t1.append(f"| **All 14 comparisons** | | | | {sh_all[0]}/{sh_all[1]} | **{P_all['b']}/{P_all['n2']} ({P_all['pb']:.0f}%)** | **{P_all['a']}/{P_all['n1']} ({P_all['pa']:.0f}%)** | {y_Y[0]}/{y_Y[1]} | exact stratified p = {sci(P_all['p'])} | |")
TABLE1 = '\n'.join(t1)

# other survival experiments
t1b = ['| Block (cells) | Design | Result (survivors/total) |', '|---|---|---|']
t1b.append(f"| S15-H ({blockrange('S15-H')}) | Aged BALB/c, rgH5N1 challenge 3 days after dosing: vaccine alone vs PSLN-344 alone vs both | vaccine alone {SV('S15-H', '3d Vaccine')}; PSLN-344 alone {SV('S15-H', '3d PSLN-344')}; vaccine + PSLN-344 **{SV('S15-H', '3d Vaccine+PSLN-344')}** (exact log-rank p = {LR('S15-H', '3d PSLN-344', '3d Vaccine+PSLN-344')} vs either single agent) |")
t1b.append(f"| S13-E ({blockrange('S13-E')}) | Young BALB/c, H1N1+H3N2 vaccine → CA09 H1N1 (10× mLD50) on day 14 | naïve {SV('S13-E', 'Naïve')}; sham {SV('S13-E', 'Sham')}; CMP-204 {SV('S13-E', 'CMP-204(Y)')}; PSLN-344 {SV('S13-E', 'PSLN-344(Y)')} |")
for b, dsc in yng:
    t1b.append(f"| {b} ({blockrange(b)}) | Young BALB/c, {dsc} | sham {SV(b, 'Sham')}; PSLN-212 {SV(b, 'PSLN-212Y')}; PSLN-344 {SV(b, 'PSLN-344Y')} |")
TABLE1B = '\n'.join(t1b)

# =====================================================================================
#  Table 2: immune read-outs
# =====================================================================================
def row2(label, blk, panel=None, time=None, geo=False, dec=1, sham=True, young='PSLN-212(Y)', note='', nopct=False):
    d = tidy[(tidy.block == blk)]
    if panel is not None: d = d[d.panel == panel]
    if time is not None: d = d[d.time.astype(str) == str(time)]
    rng = cellrange(d[d.value.notna()])
    if geo:
        f = lambda g: G(blk, g); ra = G(blk, 'PSLN-344', raw=True) / G(blk, 'PSLN-212', raw=True); ry = 100 * G(blk, 'PSLN-344', raw=True) / G(blk, young, raw=True)
    else:
        f = lambda g: A(blk, g, panel, time, dec=dec); ra = A(blk, 'PSLN-344', panel, time, raw=True) / A(blk, 'PSLN-212', panel, time, raw=True)
        ry = 100 * A(blk, 'PSLN-344', panel, time, raw=True) / A(blk, young, panel, time, raw=True) if young else None
    sh = f('Sham') if sham else '–'
    yv = f(young) if young else '–'
    p = PV(blk, 'PSLN-212', 'PSLN-344', panel, time, 'tukey')
    if nopct: return f"| {label} | {blk} ({rng}) | {sh} | {f('PSLN-212')} | **{f('PSLN-344')}** | {yv} | {ra:.1f}× | – | {p} |"
    return f"| {label} | {blk} ({rng}) | {sh} | {f('PSLN-212')} | **{f('PSLN-344')}** | {yv} | {ra:.1f}× | {ry:.0f}% | {p} |" if young else f"| {label} | {blk} ({rng}) | {sh} | {f('PSLN-212')} | **{f('PSLN-344')}** | – | {ra:.1f}× | – | {p} |"

t2 = ['| Read-out (aged mice unless stated) | Block (cells) | Sham | PSLN-212 | **PSLN-344** | Young, PSLN-212 | 344 ÷ 212 | 344 as % of young | p, 344 vs 212 (Tukey) |', '|---|---|---|---|---|---|---|---|---|']
t2.append('| *Innate trigger* | | | | | | | | |')
t2.append(row2('Lung Ifnb1, 16 h, fold', 'S01-A', '16h'))
t2.append(row2('Lung Ifnb1, 72 h, fold', 'S01-A', '72h', nopct=True))
t2.append(row2('Lung Gm-csf, 36 h, fold', 'S02-F', None, '36h', young=None))
t2.append(row2('Lung monocytes, day 4, %', 'S01-D', None, '4'))
t2.append('| *Dendritic cells* | | | | | | | | |')
t2.append(row2('Lung CD11b+ DC, day 4, %', 'S01-E', None, '4'))
t2.append(row2('Lung CCR7+ migratory CD11b+ DC, 72 h, %', 'S02-A'))
t2.append(row2('MLN DC carrying labelled ovalbumin, 36 h, %', 'S02-C', sham=False))
t2.append(row2('OT-I CD8 proliferation driven by MLN DC, %', 'S02-E', sham=False))
t2.append(row2('MLN DC CD40+, day 3, %', 'S02-D CD40'))
t2.append(row2('MLN DC CD86+, day 3, %', 'S02-D CD86'))
t2.append('| *B-cell help and antibody* | | | | | | | | |')
t2.append(row2('Germinal-centre B cells, day 7, %', 'S03-K', dec=2))
t2.append(row2('ICOS+ Tfh, day 7, %', 'S04-A', 'ICOS+CXCR5+PD1+', dec=2))
t2.append(row2('Foxp3+ among CXCR5+ CD4 (Tfr), day 7, % (lower = young pattern)', 'S04-B Foxp3+ in CXCR5+', nopct=True))
t2.append(row2('Foxp3+ among CXCR5+ CD4 (Tfr), day 30, % (lower = young pattern)', 'S04-C', nopct=True))
t2.append(row2('Serum IgG to H1N1, day 14, GMT', 'S03-A', geo=True))
t2.append(row2('HAI to H1N1, day 14, GMT', 'S03-C', geo=True))
t2.append(row2('Neutralising titre to H1N1, day 14, GMT', 'S03-D', geo=True))
t2.append(row2('Serum IgG to H3N2, day 14, GMT', 'S03-E', geo=True))
t2.append(row2('HAI to H3N2, day 14, GMT', 'S03-G', geo=True))
t2.append(row2('Neutralising titre to H3N2, day 14, GMT', 'S03-H', geo=True))
t2.append(row2('Serum IgG to H1N1, day 28 after day-14 boost, GMT', 'S13-I', geo=True))
t2.append(row2('Serum IgG to H3N2, day 28 after day-14 boost, GMT', 'S13-J', geo=True))
t2.append('| *CD8 T cells* | | | | | | | | |')
t2.append(row2('Lung Ki-67+ CD8, day 3, %', 'S05-D', dec=2))
t2.append(row2('Lung GZMB+ CD8, day 3, %', 'S05-E', dec=2))
t2.append(row2('MLN IFN-γ+ CD8 after H5N1 re-stimulation, day 14, %', 'S05-F', dec=2))
t2.append(row2('MLN IFN-γ+ CD8 after H5N1 re-stimulation, day 60, %', 'S05-G', dec=2))
t2.append(row2('MLN GZMB+ CD8, day 60, %', 'S05-H', dec=2))
t2.append(row2('Lung CD69+CD103+ resident-memory CD8, day 25, % (antigen ambiguous, D17)', 'S05-I', dec=2))
TABLE2 = '\n'.join(t2)

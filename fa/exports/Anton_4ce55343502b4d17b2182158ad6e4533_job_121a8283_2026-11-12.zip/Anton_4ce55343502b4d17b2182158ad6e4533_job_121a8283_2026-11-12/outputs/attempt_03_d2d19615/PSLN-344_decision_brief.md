# PSLN-344 — decision brief for the portfolio review

*Mn-complexed, pulmonary-surfactant-biomimetic liposomal STING agonist; intranasal adjuvant for inactivated influenza A vaccine in older adults.*

**Basis.** `adjuvant_program_dataset.xlsx` (15 sheets, 101 labelled blocks, 6,819 numeric cells; last modified 3 Sep 2026) and `adjuvant_program_annotation.pdf` (19 pages, 15 Sep 2026). Every numeric cell was parsed and is accounted for. A number in this memo is followed by the block it comes from in square brackets; the exact cells and the reduction applied are in `evidence_ledger.csv`, sorted by block (Appendix B). Where the workbook disagrees with itself, the printed value is the primary analysis and the alternative is shown alongside it. Statements that draw on knowledge from outside the file are marked *[external]*.

**Names.** PSLN-344 is the asset: the liposome carrying the cyclic dinucleotide CDN-1807, with Mn²⁺. PSLN-212 is the same particle without Mn. CMP-204 carries cGAMP in place of CDN-1807. PSLN-R848 and PSLN-212/R848 carry the TLR7/8 agonist R848, alone or with CDN-1807. "Sham" is vaccine with empty liposome. "Young" mice are 7–8 weeks old; "aged" mice are 20 months or older unless stated.

## Recommendation

**Advance PSLN-344 — conditionally.** Approve a gated confirmation-and-de-risking stage now (mouse, ferret and human-cell work; no GLP toxicology, no GMP scale-up). Commit to IND-enabling work only when the gates in §4.4 are met. Keep the present data file inside the company until the source-data audit (Gate 0) is closed.

### Answers at a glance

| Your question | Short answer | Detail |
|------------------|--------------------------------------------------------------------------|--------|
| Do we advance? | **Yes, conditionally.** In aged mice (14 months old in four comparisons, 20 months or older in the rest) one intranasal dose of vaccine with PSLN-344 left 85/101 animals alive after lethal challenge, against 13/101 with PSLN-212, the same particle without manganese: a difference of 71 points (95% CI 63–80) across 14 head-to-head comparisons, all 14 in the same direction. Taking the least favourable reading of every disputed count still gives 65 points (95% CI 55–74). | §2, §3 |
| What is actually driving the protection? | **The manganese, acting through an antigen-dependent adaptive response.** Mn lifts the ceiling of the aged lung's interferon-β response to the young-adult level and switches on GM-CSF; monocyte-derived dendritic cells and lung CD8 T cells follow. Adjuvant without antigen protects 0/7, so this is not an innate antiviral effect. Protection crosses subtypes and is present 2–3 days after dosing, so HAI antibody cannot be the driver. The link from CD8 T cells or dendritic cells to survival is inferred: no experiment removes them and then challenges. | §4.1 |
| Is there a biomarker of efficacy worth carrying forward? | **Yes, one: the early interferon-β → GM-CSF → CCL2/monocyte → dendritic-cell response.** It is the step that fails in aged animals, the step Mn repairs, it is dose-responsive, and its middle links have intervention support. | §4.2 |
| Could it go into patients, and in what role? | **Not as measured; yes after bridging.** Every read-out of that response in the file is lung or lymph-node tissue from terminal animals. The patient version is nasal-lining-fluid protein and nasal or blood transcripts at 16–72 h. **Role: pharmacodynamic marker for proof of mechanism and dose selection in Phase 1.** It is not a surrogate for protection. HAI is not one either for this product. | §4.2 |
| What must the next studies establish? | Six things, in order: the file is sound; the effect replicates blinded and needs both Mn and the cyclic dinucleotide; what mediates survival; the lowest effective dose and its margin; airway Mn is safe; it works with a licensed antigen, by a human-usable route, in a second species and on human aged cells. Endpoints, populations, comparators, read-outs and timing for each are in §4.3. | §4.3, §4.4 |
| What did I consider and rule out? | A dose or potency explanation; innate-only protection; HAI as the driver; a one-strain artefact; dependence on prior influenza exposure; an artefact of the data defects; the R848 and cGAMP alternatives; an unconditional go; a no-go. | §5 |

**How sure am I?** High that the recorded effect is large and depends on the Mn: it survives every re-reading of the file. Moderate that CD8 T cells primed by monocyte-derived dendritic cells are what mediates it: everything is consistent with that and nothing tests it. Unknown for translation to people and for the safety of Mn given by the airway: the file has no data on either.

### Why yes

1. **The effect is large and it repeats.** 85/101 (84%) vs 13/101 (13%) survivors; vaccine with empty liposome protected 1/73 [sheets S03, S06, S15; Table 1].
2. **It is attributable to the manganese, and more of the Mn-free particle cannot substitute.** PSLN-344 restores the 16-hour lung *Ifnb1* response of aged mice to the young-adult level (37.1-fold vs 37.6-fold; PSLN-212 in aged mice 16.6-fold) [S01-A]. Across dose, PSLN-212 plateaus near 16-fold and PSLN-344 near 53-fold at a similar half-maximal dose (9.5 vs 11.2 µg) [S08-A].
3. **The profile fits the indication.** One needle-free dose; protection across subtypes (H3N2 vaccine → H1N1 virus; H1N1+H3N2 → H5N1; H1N1 → H3N2); present within 2–3 days; still present at day 60 (14/21 vs 1/21); reproduced in C57BL/6 and outbred Swiss Webster mice (12/14 vs 2/14); indifferent to prior influenza infection (6/7 unprimed, 6/7 imprinted) [S06, S15].
4. **The biology is coherent and measurable.** Interferon-β, monocyte influx, dendritic-cell migration and priming, germinal-centre help, antibody and CD8 responses each reach 41–99% of the young-adult benchmark with PSLN-344 (Table 2, Figure 3).
5. **Nothing in the tolerability data argues for stopping.** Mean lowest body weight after dosing 96.4% of baseline, back to 99.8% by day 10 [S08-D]; *Ifnb1* back to 4.4-fold by 72 h [S01-A]; no cholera-toxin-type signal in the central nervous system at 36 h [S10-A].

### Why only conditionally

1. **The file has integrity problems.** Twenty-two issues are logged in Appendix C, from outright defects to missing documentation: one survival table duplicated row for row, group labels that conflict between paired blocks, rotated column headers, re-used body-weight values. None overturns the result in any sensitivity analysis (§2.1), but the file is not fit for a partner's or regulator's data room as it stands.
2. **The driver of protection is inferred, not shown.** No depletion, blockade or transfer experiment has survival as its read-out.
3. **Translation is untested.** Mice only; one efficacy dose (20 µg); formalin-inactivated whole-virion antigen; dosing that reaches the deep lung; no comparator that older adults actually receive; no virus titres, no mucosal IgA, no histopathology.
4. **The safety package is thin for an airway product that contains manganese.** Five animals per group, body weight and three central-nervous-system transcripts; no Mn measurement anywhere; Mn content per dose is not in the file.

### What approval commits us to

- **Gate 0, about 6 weeks, no animals:** reconcile the 22 logged issues against raw records.
- **Gate 1, about 9–10 months:** blinded replication with component controls; the experiment that shows what mediates survival; dose–response for protection with the biomarker read in the same animals; pilot airway-Mn safety.
- **Gate 2, about 15 months:** licensed antigen, human-usable route, ferret, human aged-donor cells. IND-enabling spend starts only after this.
- **Stop rules** are pre-set (§4.4). Durations and gate thresholds are my proposals, not data.

![Figure 1](figures/fig1_survival_head_to_head.png)

*Survival after lethal challenge in every head-to-head experiment (left) and the difference between PSLN-344 and PSLN-212 (right). Section and appendix references point to the full memo, `PSLN-344_recommendation`.*

# PSLN-344 portfolio review: what is in this folder

| File | What it is |
|---|---|
| `PSLN-344_recommendation.md` / `.docx` / `.html` | The memo: recommendation, evidence, weaknesses, forward view (driver of protection, biomarker, next studies, gates), what was ruled out, and appendices. The three formats have identical content; the HTML is self-contained, the DOCX is landscape. |
| `PSLN-344_decision_brief.md` / `.docx` | Section 1 of the memo on its own (recommendation, answers at a glance, why yes, why only conditionally, what approval commits us to) plus Figure 1. Same text as the memo. |
| `evidence_ledger.csv` | One row per number used in the memo: block, quantity, value, n, sheet and cell range, and the reduction applied. Sorted by block. |
| `data_integrity_log.csv` | The 22 issues found in the workbook (defects and documentation gaps): where, what, how detected, consequence, how handled. |
| `figures/` | The seven figures used in the memo (PNG). |
| `analysis/` | Scripts and intermediate tables. `render.sh` rebuilds everything from the workbook. `tidy_values.csv` and `tidy_survival.csv` hold every parsed cell with its address. `verify_ledger.py` recomputes the simple ledger entries directly from the workbook cells. |

Source data: `/tmp/world/filesystem/adjuvant_program_dataset.xlsx` and `adjuvant_program_annotation.pdf`. Nothing in the source files was modified.

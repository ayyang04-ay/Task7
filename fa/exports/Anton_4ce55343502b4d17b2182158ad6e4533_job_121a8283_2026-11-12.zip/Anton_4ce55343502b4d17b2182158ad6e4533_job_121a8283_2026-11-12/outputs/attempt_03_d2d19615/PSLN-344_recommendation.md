# PSLN-344 — recommendation for the portfolio review

*Mn-complexed, pulmonary-surfactant-biomimetic liposomal STING agonist; intranasal adjuvant for inactivated influenza A vaccine in older adults.*

**Basis.** `adjuvant_program_dataset.xlsx` (15 sheets, 101 labelled blocks, 6,819 numeric cells; last modified 3 Sep 2026) and `adjuvant_program_annotation.pdf` (19 pages, 15 Sep 2026). Every numeric cell was parsed and is accounted for. A number in this memo is followed by the block it comes from in square brackets; the exact cells and the reduction applied are in `evidence_ledger.csv`, sorted by block (Appendix B). Where the workbook disagrees with itself, the printed value is the primary analysis and the alternative is shown alongside it. Statements that draw on knowledge from outside the file are marked *[external]*.

**Names.** PSLN-344 is the asset: the liposome carrying the cyclic dinucleotide CDN-1807, with Mn²⁺. PSLN-212 is the same particle without Mn. CMP-204 carries cGAMP in place of CDN-1807. PSLN-R848 and PSLN-212/R848 carry the TLR7/8 agonist R848, alone or with CDN-1807. "Sham" is vaccine with empty liposome. "Young" mice are 7–8 weeks old; "aged" mice are 20 months or older unless stated.

## 1. Recommendation

**Advance PSLN-344 — conditionally.** Approve a gated confirmation-and-de-risking stage now (mouse, ferret and human-cell work; no GLP toxicology, no GMP scale-up). Commit to IND-enabling work only when the gates in §4.4 are met. Keep the present data file inside the company until the source-data audit (Gate 0) is closed.

### Answers at a glance

| Your question | Short answer | Detail |
|------------------|--------------------------------------------------------------------------|--------|
| Do we advance? | **Yes, conditionally.** In aged mice (14 months old in four comparisons, 20 months or older in the rest) one intranasal dose of vaccine with PSLN-344 left 85/101 animals alive after lethal challenge, against 13/101 with PSLN-212, the same particle without manganese: a difference of 71 points (95% CI 63–80) across 14 head-to-head comparisons, all 14 in the same direction. Taking the least favourable reading of every disputed count still gives 65 points (95% CI 55–74). | §2, §3 |
| What is actually driving the protection? | **The manganese, acting through an antigen-dependent adaptive response.** Mn lifts the ceiling of the aged lung's interferon-β response to the young-adult level and switches on GM-CSF; monocyte-derived dendritic cells and lung CD8 T cells follow. Adjuvant without antigen protects 0/7, so this is not an innate antiviral effect. Protection crosses subtypes and is present 2–3 days after dosing, so HAI antibody cannot be the driver. The link from CD8 T cells or dendritic cells to survival is inferred: no experiment removes them and then challenges. | §4.1 |
| Is there a biomarker of efficacy worth carrying forward? | **Yes, one: the early interferon-β → GM-CSF → CCL2/monocyte → dendritic-cell response.** It is the step that fails in aged animals, the step Mn repairs, it is dose-responsive, and its middle links have intervention support. | §4.2 |
| Could it go into patients, and in what role? | **Not as measured; yes after bridging.** Every read-out of that response in the file is lung or lymph-node tissue from terminal animals. The patient version is nasal-lining-fluid protein and nasal or blood transcripts at 16–72 h. **Role: pharmacodynamic marker for proof of mechanism and dose selection in Phase 1.** It is not a surrogate for protection. HAI is not one either for this product. | §4.2 |
| What must the next studies establish? | Six things, in order: the file is sound; the effect replicates blinded and needs both Mn and the cyclic dinucleotide; what mediates survival; the lowest effective dose and its margin; airway Mn is safe; it works with a licensed antigen, by a human-usable route, in a second species and on human aged cells. Endpoints, populations, comparators, read-outs and timing for each are in §4.3. | §4.3, §4.4 |
| What did I consider and rule out? | A dose or potency explanation; innate-only protection; HAI as the driver; a one-strain artefact; dependence on prior influenza exposure; an artefact of the data defects; the R848 and cGAMP alternatives; an unconditional go; a no-go. | §5 |

**How sure am I?** High that the recorded effect is large and depends on the Mn: it survives every re-reading of the file. Moderate that CD8 T cells primed by monocyte-derived dendritic cells are what mediates it: everything is consistent with that and nothing tests it. Unknown for translation to people and for the safety of Mn given by the airway: the file has no data on either.

### Why yes

1. **The effect is large and it repeats.** 85/101 (84%) vs 13/101 (13%) survivors; vaccine with empty liposome protected 1/73 [sheets S03, S06, S15; Table 1].
2. **It is attributable to the manganese, and more of the Mn-free particle cannot substitute.** PSLN-344 restores the 16-hour lung *Ifnb1* response of aged mice to the young-adult level (37.1-fold vs 37.6-fold; PSLN-212 in aged mice 16.6-fold) [S01-A]. Across dose, PSLN-212 plateaus near 16-fold and PSLN-344 near 53-fold at a similar half-maximal dose (9.5 vs 11.2 µg) [S08-A].
3. **The profile fits the indication.** One needle-free dose; protection across subtypes (H3N2 vaccine → H1N1 virus; H1N1+H3N2 → H5N1; H1N1 → H3N2); present within 2–3 days; still present at day 60 (14/21 vs 1/21); reproduced in C57BL/6 and outbred Swiss Webster mice (12/14 vs 2/14); indifferent to prior influenza infection (6/7 unprimed, 6/7 imprinted) [S06, S15].
4. **The biology is coherent and measurable.** Interferon-β, monocyte influx, dendritic-cell migration and priming, germinal-centre help, antibody and CD8 responses each reach 41–99% of the young-adult benchmark with PSLN-344 (Table 2, Figure 3).
5. **Nothing in the tolerability data argues for stopping.** Mean lowest body weight after dosing 96.4% of baseline, back to 99.8% by day 10 [S08-D]; *Ifnb1* back to 4.4-fold by 72 h [S01-A]; no cholera-toxin-type signal in the central nervous system at 36 h [S10-A].

### Why only conditionally

1. **The file has integrity problems.** Twenty-two issues are logged in Appendix C, from outright defects to missing documentation: one survival table duplicated row for row, group labels that conflict between paired blocks, rotated column headers, re-used body-weight values. None overturns the result in any sensitivity analysis (§2.1), but the file is not fit for a partner's or regulator's data room as it stands.
2. **The driver of protection is inferred, not shown.** No depletion, blockade or transfer experiment has survival as its read-out.
3. **Translation is untested.** Mice only; one efficacy dose (20 µg); formalin-inactivated whole-virion antigen; dosing that reaches the deep lung; no comparator that older adults actually receive; no virus titres, no mucosal IgA, no histopathology.
4. **The safety package is thin for an airway product that contains manganese.** Five animals per group, body weight and three central-nervous-system transcripts; no Mn measurement anywhere; Mn content per dose is not in the file.

### What approval commits us to

- **Gate 0, about 6 weeks, no animals:** reconcile the 22 logged issues against raw records.
- **Gate 1, about 9–10 months:** blinded replication with component controls; the experiment that shows what mediates survival; dose–response for protection with the biomarker read in the same animals; pilot airway-Mn safety.
- **Gate 2, about 15 months:** licensed antigen, human-usable route, ferret, human aged-donor cells. IND-enabling spend starts only after this.
- **Stop rules** are pre-set (§4.4). Durations and gate thresholds are my proposals, not data.

## 2. The evidence for advancing

### 2.1 Survival after lethal challenge

Table 1 lists every experiment in the file in which aged or middle-aged animals received vaccine with PSLN-344 or with PSLN-212 and were then challenged. "Sham" is vaccine with empty liposome. Each count is the number of rows whose event flag is 0 at the end of observation over all rows printed for the group.

**Table 1. Survivors / animals, head-to-head comparisons in aged and middle-aged mice**

| Block (cells) | Host | Vaccine → challenge virus | Challenge day | Sham | PSLN-212 | **PSLN-344** | Young, PSLN-212 | 344 vs 212, exact log-rank p | Note |
|------------------------------|----------------------|----------------------------------|----------|----------|------------|------------|------------|------------------|--------|
| S03-I (S03!A17:F51) | BALB/c ≥20 mo | H1N1+H3N2 → CA09 H1N1 (10× mLD50) | d14 | 0/7 | 0/7 | **7/7** | 7/7 | 0.0006 | a |
| S03-J (S03!G17:J46) | BALB/c, aged by label | rgH5N1 → wild-type H5N1 | d2 | 1/10 | 3/10 | **10/10** | – | 0.003 | b |
| S06-A (S06!A3:E30) | BALB/c ≥20 mo | H3N2 → PR8 H1N1 (5× mLD50) | d14 | 0/7 | 1/7 | **6/7** | 7/7 | 0.02 |  |
| S06-B (S06!G3:K30) | BALB/c ≥20 mo | H3N2 → PR8 H1N1 (5× mLD50) | d3 | 0/7 | 0/7 | **5/7** | 7/7 | 0.002 |  |
| S06-C (S06!M3:Q30) | BALB/c ≥20 mo | H1N1+H3N2 → rgH5N1 (5× mLD50) | d14 | 0/7 | 2/7 | **7/7** | 7/7 | 0.02 | c |
| S06-E, rows 34–68 (S06!G34:L68) | BALB/c ≥20 mo | H3N2 → PR8 H1N1 (5× mLD50) | d60 | 0/7 | 0/7 | **5/7** | 7/7 | 0.003 | d |
| S06-F, rows 34–68 (S06!M34:R68) | BALB/c ≥20 mo | H1N1+H3N2 → rgH5N1 (5× mLD50) | d60 | 0/7 | 1/7 | **5/7** | 7/7 | 0.01 | d |
| S06-G (S06!A71:F105) | BALB/c ≥20 mo | H1N1 → Perth H3N2 (5× mLD50) | d60 | 0/7 | 0/7 | **4/7** | 7/7 | 0.02 | d |
| S06-E, rows 71–105 (S06!G71:K98) | BALB/c 14 mo, unprimed | H1N1+H3N2 → PR8 H1N1 (5× LD50) | n.s. | – | 0/7 | **6/7** | – | 0.003 | e |
| S06-E, rows 71–105 (S06!G71:K98) | BALB/c 14 mo, PR8-imprinted | H1N1+H3N2 → PR8 H1N1 (5× LD50) | n.s. | – | 4/7 | **6/7** | – | 0.44 | e |
| S06-F, rows 71–105 (S06!M71:Q98) | BALB/c 14 mo, unprimed | H1N1+H3N2 → Perth H3N2 (5× LD50) | d14 | – | 0/7 | **6/7** | – | 0.002 | e |
| S06-F, rows 71–105 (S06!M71:Q98) | BALB/c 14 mo, PR8-imprinted | H1N1+H3N2 → Perth H3N2 (5× LD50) | d14 | – | 0/7 | **6/7** | – | 0.0006 | e |
| S15-L (S15!A103:E130) | C57BL/6 20 mo | H1N1+H3N2 → virus n.s. | n.s. | 0/7 | 0/7 | **6/7** | 6/7 | 0.003 | f |
| S15-N (S15!A134:E161) | Swiss Webster 20 mo | H1N1+H3N2 → virus n.s. | n.s. | 0/7 | 2/7 | **6/7** | 7/7 | 0.09 | f |
| **All 14 comparisons** | | | | 1/73 | **13/101 (13%)** | **85/101 (84%)** | 62/63 | exact stratified p = 1×10⁻²⁶ | |

n.s. = not stated in the annotation. Notes: **a** the paired weight block S13-F carries different group labels; under its labels the PSLN-212 arm is 3/7, not 0/7 (Appendix C, D02). **b** Stated n is 9, ten rows are present, one PSLN-344 row has no day; the paired weight block S13-G labels the comparator arms differently (D03). **c** S06-C is identical row for row to S06-D, which is annotated as the day-3 version of the same experiment; it is counted once and S06-D is omitted (D01). **d** In the same three experiments 4/21 untreated, unchallenged 20-month animals died during the observation window (D10). **e** Animals were 10 months old when infected with PR8 or given saline and were vaccinated 4 months later; imprinted animals are survivors of a 1× mLD50 infection. **f** Challenge virus, dose and day are not stated. The rgH5N1 challenge virus carries H5 and N1 of A/Vietnam/1203/2004 on a PR8 backbone, so it shares the N1 subtype with the H1N1 vaccine component.

![Figure 1](figures/fig1_survival_head_to_head.png)

*Figure 1. Survival by experiment (left) and difference between PSLN-344 and PSLN-212 with 95% intervals (right). "Bivalent" is the H1N1+H3N2 vaccine.*

**Pooled estimate and how far it bends.** Each row of Table 1 is one comparison; the pooled difference is a Mantel–Haenszel risk difference stratified by comparison.

| Analysis | PSLN-344 | PSLN-212 | Difference, points (95% CI) |
|----------------------------------------------------------------------------------------|------------------|------------------|--------------------------------|
| As printed, duplicate S06-D removed (14 comparisons) | 85/101 | 13/101 | 71 (63–80) |
| BALB/c ≥20 months only (7) | 39/49 | 4/49 | 71 (59–84) |
| Only comparisons with no integrity flag on either arm (9) | 52/63 | 8/63 | 70 (58–81) |
| Death counts taken from the paired weight blocks where they differ (14) | 87/101 | 16/101 | 70 (61–79) |
| Least favourable count in every comparison; S06-D entered from its weight block (15) | 88/107 | 19/108 | 65 (55–74) |

Three cautions belong next to these numbers. First, each experiment has 7 animals per arm (10 in S03-J), and a 7-versus-7 design has only about two-in-three power to reach p < 0.05 by Fisher's test even at the pooled survival rates; 12 of the 14 comparisons do reach p < 0.05 by the more sensitive exact log-rank test, and the two that do not are the imprinted arm in which PSLN-212 itself protected 4/7 and the Swiss Webster experiment (p = 0.09). The consistency across experiments carries the case, not any single p-value. Second, the experiments are not known to be independent of one another (shared controls or cohorts cannot be excluded from the file), so the pooled p-value is descriptive. Third, nothing in the file says the studies were randomised or blinded.

**Against the young-adult benchmark.** In the nine comparisons that include young mice given PSLN-212, aged mice given PSLN-344 survived 51/63 (81%) and the young mice 62/63 (98%) (Fisher p = 0.002); aged mice given PSLN-212 survived 6/63. PSLN-344 recovers most of the age gap, not all of it. The Mn-free particle is not inert in aged mice (9/73 against 1/73 for sham, Fisher p = 0.02); it simply falls far short of protecting them.

**Table 1b. Other challenge experiments**

| Block (cells) | Design | Result (survivors/total) |
|--------------------------|------------------------------------------------------------------------|----------------------------------------------------------------------------|
| S15-H (S15!A73:D93) | Aged BALB/c, rgH5N1 challenge 3 days after dosing: vaccine alone vs PSLN-344 alone vs both | vaccine alone 0/7; PSLN-344 alone 0/7; vaccine + PSLN-344 **6/7** (exact log-rank p = 0.0006 vs either single agent) |
| S13-E (S13!R3:V30) | Young BALB/c, H1N1+H3N2 vaccine → CA09 H1N1 (10× mLD50) on day 14 | naïve 0/7; sham 1/7; CMP-204 7/7; PSLN-344 7/7 |
| S09-B (S09!A12:D35) | Young BALB/c, H3N2 → PR8 H1N1, day 21 | sham 0/8; PSLN-212 8/8; PSLN-344 8/8 |
| S09-D (S09!A39:D62) | Young BALB/c, H1N1 → Perth H3N2, day 21 | sham 0/8; PSLN-212 8/8; PSLN-344 8/8 |
| S09-F (S09!A66:D88) | Young BALB/c, H1N1+H3N2 → rgH5N1, day 180 | sham 0/7; PSLN-212 8/8; PSLN-344 8/8 |

In young mice PSLN-344 adds nothing to survival over PSLN-212, and even the cGAMP particle CMP-204 is fully protective. The value of the Mn is specific to the aged host.

### 2.2 The benefit is the manganese, and it is not a dose effect

The annotation states that PSLN-344 and PSLN-212 differ in one respect: PSLN-344 incorporates Mn²⁺.

- **Same particle, same dose, different ceiling.** At 20 µg, lung *Ifnb1* at 16 h is 37.1-fold with PSLN-344 and 16.6-fold with PSLN-212 in aged mice, a ratio of 2.2× (95% CI 1.8–2.7); against young mice given PSLN-212 (37.6-fold) the ratio is 0.98× (95% CI 0.84–1.16) [S01-A, n = 5].
- **More PSLN-212 does not get there.** In the five-dose series, PSLN-212 at 40 µg gives 14.9-fold, below PSLN-344 at 10 µg (21.1-fold). A Hill fit puts the plateau at 15.6 (SE 1.3) for PSLN-212 and 52.8 (SE 3.9) for PSLN-344, with half-maximal doses of 9.5 and 11.2 µg [S08-A, n = 3 per dose; the block does not restate age and is read as aged from its labels]. Mn raises the maximum response; it does not make the agonist more potent.
- **GM-CSF transcript appears only with Mn.** Lung *Gm-csf* is 6.0-, 8.7- and 3.9-fold at 16, 36 and 72 h with PSLN-344, and 1.5-, 1.6- and 1.4-fold with PSLN-212 [S02-F, n = 5].
- **Not an encapsulation difference.** Encapsulation efficiency is 54.8% (SD 5.1) for PSLN-344 and 59.6% (SD 4.6) for PSLN-212 over three preparations each (Welch p = 0.29) [S08-B].

![Figure 2](figures/fig2_innate_trigger.png)

*Figure 2. (a) Lung Ifnb1 by preparation at 16 h and 72 h. (b) Dose–response. (c) Lung Gm-csf.*

What the file cannot tell us: whether the cyclic dinucleotide is needed once Mn is present (there is no Mn-only particle), whether Mn has to be built into the particle (there is no free-Mn admixture control), how much Mn is in a dose, and whether "20 µg of adjuvant" means cyclic-dinucleotide mass or particle mass (D21). Whether Mn changes delivery to the alveolar epithelium is also open, because the block that addresses it conflicts with an earlier block (D05).

### 2.3 The profile: breadth, speed, durability, host range

- **Breadth.** PSLN-344 protected when the challenge virus was a different subtype from the vaccine: H3N2 vaccine → PR8 H1N1 (6/7 at day 14) [S06-A]; H1N1+H3N2 vaccine → rgH5N1 (7/7) [S06-C]; H1N1 vaccine → Perth H3N2 (4/7 at day 60) [S06-G]. PSLN-212 in the same experiments: 1/7, 2/7, 0/7.
- **Speed.** Challenge 2 days after dosing with wild-type H5N1: 10/10 vs 3/10 [S03-J; the identity of the comparator arm is disputed, D03]. Challenge at 3 days with PR8: 5/7 vs 0/7 [S06-B]. Challenge at 3 days with rgH5N1: 6/7 with vaccine + PSLN-344, 0/7 with vaccine alone, 0/7 with PSLN-344 alone [S15-H].
- **Durability.** At the day-60 challenge, PSLN-344 14/21, PSLN-212 1/21, sham 0/21, young + PSLN-212 21/21 [S06-E and S06-F rows 34–68, S06-G]. PSLN-344 deaths were 1/21 at the day-14 challenges in aged BALB/c and 7/21 at day 60 (Fisher p = 0.045), which looks like waning. It may not be: 4/21 untreated animals that were never challenged died in the same windows (Fisher p = 0.48 against the PSLN-344 arms). The file cannot separate vaccine failure from age-related deaths at day 60. Nothing later than day 60 has been tested in aged mice; in young mice both particles still protected 8/8 at day 180 [S09-F].
- **Host range.** 20-month C57BL/6: 6/7 vs 0/7; 20-month outbred Swiss Webster: 6/7 vs 2/7 [S15-L, S15-N]. Fourteen-month BALB/c, with or without a PR8 infection four months earlier: PR8 challenge 6/7 and 6/7 with PSLN-344 vs 0/7 and 4/7 with PSLN-212; Perth H3N2 challenge 6/7 and 6/7 vs 0/7 and 0/7 [S06-E and S06-F, rows 71–105]. Older people have all met influenza before, so the indifference to imprinting matters. The same cohorts show that the Mn-free particle has already failed by 14 months of age (0/7 and 0/7 in unprimed animals), so the population that needs the Mn may begin well before old age.
- **Protection from death, not from illness.** Surviving aged animals given PSLN-344 fell to a mean lowest weight of 88.1% of baseline, survivors in the young benchmark to 90.6% [S13-F, S15-A to S15-G, S15-M, S15-O; descriptive only, see D07]. Immunity is not sterilising in either group, which is what a T-cell-weighted mechanism would look like.

### 2.4 What PSLN-344 restores in the aged immune response, and what it does not

**Table 2. Group means (arithmetic; geometric for titres), n = 5 per group**

| Read-out (aged mice unless stated) | Block (cells) | Sham | PSLN-212 | **PSLN-344** | Young, PSLN-212 | 344 ÷ 212 | 344 as % of young | p, 344 vs 212 (Tukey) |
|------------------------------------------------------|----------------------------------|------------|--------------|--------------|----------------|--------------|----------------|------------------|
| *Innate trigger* | | | | | | | | |
| Lung Ifnb1, 16 h, fold | S01-A (S01!B3:F10) | 1.0 | 16.6 | **37.1** | 37.6 | 2.2× | 99% | 0.0006 |
| Lung Ifnb1, 72 h, fold | S01-A (S01!H3:L10) | 1.0 | 3.4 | **4.4** | 1.6 | 1.3× | – | 0.94 |
| Lung Gm-csf, 36 h, fold | S02-F (S02!B18:P18) | 1.2 | 1.6 | **8.7** | – | 5.5× | – | 3×10⁻⁸ |
| Lung monocytes, day 4, % | S01-D (S01!B26:U26) | 10.4 | 16.7 | **30.6** | 32.2 | 1.8× | 95% | 2×10⁻⁵ |
| *Dendritic cells* | | | | | | | | |
| Lung CD11b+ DC, day 4, % | S01-E (S01!B32:Z32) | 4.8 | 8.3 | **18.9** | 21.4 | 2.3× | 88% | 0.007 |
| Lung CCR7+ migratory CD11b+ DC, 72 h, % | S02-A (S02!A3:D7) | 2.5 | 7.3 | **30.7** | 35.0 | 4.2× | 88% | 4×10⁻⁶ |
| MLN DC carrying labelled ovalbumin, 36 h, % | S02-C (S02!K3:O7) | – | 1.8 | **7.1** | 9.4 | 4.0× | 76% | 2×10⁻⁵ |
| OT-I CD8 proliferation driven by MLN DC, % | S02-E (S02!K10:O14) | – | 0.8 | **18.7** | 26.2 | 24.3× | 71% | 3×10⁻⁵ |
| MLN DC CD40+, day 3, % | S02-D CD40 (S02!A10:D14) | 4.0 | 5.6 | **11.2** | 38.7 | 2.0× | 29% | 0.16 |
| MLN DC CD86+, day 3, % | S02-D CD86 (S02!F10:I14) | 7.2 | 8.1 | **14.5** | 37.9 | 1.8× | 38% | 0.03 |
| *B-cell help and antibody* | | | | | | | | |
| Germinal-centre B cells, day 7, % | S03-K (S03!L17:O21) | 1.18 | 2.34 | **6.54** | 9.82 | 2.8× | 67% | 0.007 |
| ICOS+ Tfh, day 7, % | S04-A (S04!G2:K5) | 0.30 | 3.82 | **10.26** | 13.63 | 2.7× | 75% | 0.0002 |
| Foxp3+ among CXCR5+ CD4 (Tfr), day 7, % (lower = young pattern) | S04-B Foxp3+ in CXCR5+ (S04!A8:D12) | 22.6 | 26.7 | **10.8** | 7.1 | 0.4× | – | 0.0002 |
| Foxp3+ among CXCR5+ CD4 (Tfr), day 30, % (lower = young pattern) | S04-C (S04!A22:D26) | 13.9 | 18.0 | **14.0** | 7.4 | 0.8× | – | 0.14 |
| Serum IgG to H1N1, day 14, GMT | S03-A (S03!A3:E7) | 56 | 393 | **7,305** | 11,959 | 18.6× | 61% | 3×10⁻⁶ |
| HAI to H1N1, day 14, GMT | S03-C (S03!K3:O7) | 8 | 46 | **368** | 485 | 8.0× | 76% | 6×10⁻⁶ |
| Neutralising titre to H1N1, day 14, GMT | S03-D (S03!Q3:U7) | 52 | 418 | **3,840** | 6,686 | 9.2× | 57% | 0.0002 |
| Serum IgG to H3N2, day 14, GMT | S03-E (S03!A10:E14) | 52 | 426 | **5,701** | 13,855 | 13.4× | 41% | 0.0001 |
| HAI to H3N2, day 14, GMT | S03-G (S03!K10:O14) | 10 | 35 | **320** | 368 | 9.2× | 87% | 2×10⁻⁶ |
| Neutralising titre to H3N2, day 14, GMT | S03-H (S03!Q10:U14) | 40 | 276 | **2,533** | 4,411 | 9.2× | 57% | 3×10⁻⁵ |
| Serum IgG to H1N1, day 28 after day-14 boost, GMT | S13-I (S13!F53:J57) | 57 | 4,411 | **15,651** | 40,739 | 3.5× | 38% | 0.19 |
| Serum IgG to H3N2, day 28 after day-14 boost, GMT | S13-J (S13!L53:P57) | 101 | 1,086 | **12,435** | 43,472 | 11.5× | 29% | 3×10⁻⁵ |
| *CD8 T cells* | | | | | | | | |
| Lung Ki-67+ CD8, day 3, % | S05-D (S05!A19:D23) | 0.83 | 3.48 | **9.38** | 9.94 | 2.7× | 94% | 0.0008 |
| Lung GZMB+ CD8, day 3, % | S05-E (S05!A26:D30) | 0.99 | 2.99 | **5.69** | 9.61 | 1.9× | 59% | 0.0008 |
| MLN IFN-γ+ CD8 after H5N1 re-stimulation, day 14, % | S05-F (S05!A33:D37) | 0.67 | 1.50 | **6.36** | 9.18 | 4.2× | 69% | 6×10⁻⁸ |
| MLN IFN-γ+ CD8 after H5N1 re-stimulation, day 60, % | S05-G (S05!A40:D44) | 1.46 | 3.04 | **9.86** | 14.36 | 3.2× | 69% | 0.0008 |
| MLN GZMB+ CD8, day 60, % | S05-H (S05!A47:D51) | 0.60 | 1.02 | **4.11** | 5.55 | 4.0× | 74% | 0.0005 |
| Lung CD69+CD103+ resident-memory CD8, day 25, % (antigen ambiguous, D17) | S05-I (S05!A54:D58) | 0.58 | 1.00 | **3.96** | 6.04 | 4.0× | 66% | 3×10⁻⁷ |

Young = 7–8-week mice given PSLN-212. HAI values printed as 0 (below the 1:10 starting dilution) were set to 5 for geometric means. Tukey p-values come from a one-way ANOVA across all groups printed in the block, on log10 values for titres and fold-changes, raw values otherwise. Of the 28 contrasts in the table, 23 have Tukey p < 0.01; in 22 of those the two groups do not overlap at all (exact Mann–Whitney p = 0.008, the smallest value five against five can give) and in the other it is 0.016. Abbreviations: DC, dendritic cell; MLN, mediastinal lymph node; Tfh and Tfr, follicular helper and follicular regulatory T cells; GMT, geometric mean titre; HAI, haemagglutination inhibition; GZMB, granzyme B; OT-I, ovalbumin-specific CD8 T cells used to read out priming.

![Figure 3](figures/fig3_restoration_vs_young.png)

*Figure 3. PSLN-212 and PSLN-344 in aged mice as a percentage of the young-adult benchmark in the same block.*

Reading the table:

- **The pattern is restoration, not over-stimulation.** On every peak read-out in Table 2, PSLN-344 brings the aged response up to, or just short of, the young benchmark. Where aged animals exceed young ones it is in the tail of the response: residual *Ifnb1* at 72 h (4.4-fold vs 1.6-fold) and the items in §2.5.
- **Two things are not restored.** Co-stimulatory molecules on lymph-node dendritic cells stay far below young (CD40 11.2% vs 38.7%; CD86 14.5% vs 37.9%) [S02-D], and the fall in follicular regulatory T cells seen at day 7 is gone by day 30 (14.0% vs sham 13.9%, young 7.4%) [S04-C].
- **A boost narrows the antibody gap to PSLN-212 for one strain only.** After a day-14 boost, H1N1-binding IgG with PSLN-212 rises to a geometric mean of 4,411, 3.5× below PSLN-344; for H3N2 the gap is still 11.5× [S13-I, S13-J]. There is no challenge after a boost, so whether two doses of PSLN-212 would protect is unknown.
- **Antibody quality shifts toward IgG2a.** The IgG2a/IgG1 quotient recomputed animal by animal from the subclass titres is 2.14 with PSLN-344, 0.58 with PSLN-212 and 2.97 in young mice for H1N1, and 2.73, 0.51 and 2.89 for H3N2 [S13-A to S13-D]. The quotient blocks as printed (S03-B, S03-F) have their column headers rotated and would show the opposite (D04).
- **CD8 responses recognise viruses that were not in the vaccine.** IFN-γ-positive CD8 T cells after re-stimulation with H5N1 antigen: 6.36% vs 1.50% at day 14 and 9.86% vs 3.04% at day 60 [S05-F, S05-G]; after H1N1 or H3N2 re-stimulation 11.0% vs 3.1% and 9.9% vs 3.6% [S14-A].
- **Monocytes are steered away from a macrophage fate.** CD206-positive lung macrophages are 48.9% with PSLN-344, 71.5% with PSLN-212, 85.2% with sham and 35.5% in young mice [S11-E]; Ly6C⁺CCR2⁺ macrophage counts at day 5 are 3.4 ×10⁵ with PSLN-344 and 19.0 ×10⁵ with PSLN-212 [S07-A, n = 3]; lung regulatory T cells at day 7 are 2.99% vs 6.66% [S04-D, n = 3].

### 2.5 Tolerability so far

- **Body weight after dosing, no challenge.** Mean lowest weight 96.4% of baseline with PSLN-344 (worst animal 94.2%), 97.0% with PSLN-212, 98.2% with vaccine alone; PSLN-344 animals are back to 99.8% on day 10 [S08-D, n = 5].
- **The R848 combination was not tolerated.** PSLN-212/R848 animals lost weight progressively to a mean of 90.65% on day 10 in the four animals with a value; the fifth, at 88.3% on day 8, has none [S08-D]. Its lung cytokine pattern is *Tnf*- and *Il10*-dominated (202- and 179-fold at 16 h, against 40- and 7.3-fold for PSLN-344) [S09-A, n = 3].
- **The interferon signal is transient.** *Ifnb1* falls from 37.1-fold at 16 h to 4.4-fold at 72 h [S01-A].
- **Central nervous system.** At 36 h, transcripts in central-nervous-system tissue with vaccine + PSLN-344 relative to buffer: *Ifnb1* 1.30× (95% CI 0.84–2.01), *Tnf* 1.57× (95% CI 1.05–2.34), *Isg15* 1.16× (95% CI 0.79–1.72). The cholera-toxin positive control gives 5.5×, 3.4× and 2.7× [S10-A, n = 5]. The *Tnf* ratio is 1.20× (95% CI 0.77–1.87) against vaccine with empty liposome. So there is no cholera-toxin-type signal, but a rise in *Tnf* of up to about two-fold is not excluded (Welch p = 0.03, Tukey p = 0.12 against buffer).
- **An inflammatory tail in the aged lung.** In the panel that corresponds to 72 h (D13), *Tnf* is still 8.4-fold and *Il6* 7.2-fold with PSLN-344 in aged mice, against 0.5- and 3.1-fold in young mice given PSLN-212 [S09-A, n = 3]. Lung monocytes are still 18.4% at day 8 against 9.2% at baseline; young mice are back to 14.1% [S01-D]. Ly6C⁺CCR2⁺ macrophage counts are at baseline by day 30 (2.35 vs 1.95 ×10⁵) [S07-A, n = 3].

![Figure 4](figures/fig4_safety_reactogenicity.png)

*Figure 4. (a) Body weight after dosing. (b) Central-nervous-system transcripts at 36 h. (c) Lung monocytes over time. (d) Lung cytokine and chemokine transcripts.*

This is a reassuring start and no more than that: five animals per group, one dose level, one administration, no histopathology, no clinical pathology, no manganese measurement, and the neutrophil time course cannot be used (D06).

## 3. Weaknesses the committee should hear from us first

### 3.1 Data integrity

I checked every block against its stated n, against the blocks it is paired with, and against every other block for repeated values; I recomputed every derived quantity that can be recomputed. Twenty-two issues are logged with cells, evidence and handling in Appendix C (`data_integrity_log.csv`). The ones that change what we can claim:

- **A duplicated survival table (D01).** S06-C and S06-D are the same 28 rows. The day-3 rgH5N1 result therefore rests on S15-H (6/7), not on S06-D.
- **Conflicting group labels between a survival table and its weight block (D02, D03).** In the matched-strain experiment the PSLN-212 arm is 0/7 as printed in S03-I and 3/7 under the labels of S13-F. In the wild-type H5N1 experiment the comparator arm is PSLN-212 in S03-J and "Sham" in S13-G. PSLN-344 is 7/7 and 10/10 under every reading.
- **Rotated headers on the IgG2a/IgG1 blocks (D04).** Taken as printed, S03-B says PSLN-344 skews toward IgG1. The subclass titres say the opposite.
- **Body-weight values re-used across experiments (D07).** For example 40 of 49 values are shared between the PSLN-344 arms of S15-C and S15-I, and 32 of 49 between a BALB/c arm (S09-E) and a C57BL/6 arm (S15-M). I use weights descriptively only.
- **Unchallenged aged controls that die (D10).** 4 of 21 untreated 20-month animals that were never challenged died during the observation window. This limits what can be said about durability.
- **A near-copy of one cell-count block in another (D06)**, which removes the neutrophil data, and **one macrophage-transfer block with two identically labelled columns (D14)**, which removes that experiment.

How I handled them: the workbook as printed is the primary analysis; every alternative reading is carried as a sensitivity analysis (§2.1); blocks that cannot be interpreted are excluded and listed. The headline difference stays between 65 and 71 points under all of them. I cannot tell from the file whether these are transcription errors made when the workbook was assembled or something worse; only the raw records can. That is Gate 0.

### 3.2 Gaps in the evidence

- **No causal link to survival.** Every intervention experiment reads out a cell population, none reads out survival (§4.1).
- **One efficacy dose.** All challenge work used 20 µg, which sits at 83% of the fitted *Ifnb1* plateau [S08-A]. The lowest effective dose and the margin to reactogenicity are unknown.
- **No virology, no mucosal antibody, no pathology.** The file has no lung or nasal virus titres, no IgA, no histology.
- **No clinically relevant comparator.** The comparators are empty liposome, the Mn-free particle and a cGAMP particle. Nothing compares PSLN-344 with the enhanced vaccines older adults are given (high-dose, MF59-adjuvanted, recombinant) *[external]* or with intramuscular dosing.
- **Antigen.** Formalin-inactivated whole virus. Licensed seasonal vaccines are mostly split, subunit or recombinant; they carry less internal protein than whole virus, and recombinant vaccine carries none *[external]*. Cross-subtype CD8 responses may depend on the whole-virion format.
- **Route.** In mice the intranasal dose reaches alveolar macrophages and alveolar epithelium [S01-B, S01-C], and every mechanistic read-out is in lung. A human nasal spray does not deposit there *[external]*. Whether deep-lung delivery is required is untested.
- **Species and sex.** Three mouse strains; the annotation specifies female BALB/c.
- **Mechanism shown partly in the wrong host.** The surfactant-protein, interferon-receptor and CCR2→CD8 experiments were run in young animals or do not state age (D20).
- **Nothing on human cells.** Human STING is polymorphic and cyclic-dinucleotide potency differs between species *[external]*.
- **CMC.** Encapsulation 54.8% (lowest preparation 49.3%) over three preparations [S08-B]; size, charge and morphology are said to have been measured but are not in the file; no Mn content, no release data, no stability data.
- **Statistics.** Five to seven animals per group, many endpoints, no correction across blocks, no statement on randomisation or blinding.

## 4. Forward view

### 4.1 What is actually driving the protection

**Table 3. The chain from particle to survival, and the kind of evidence behind each link**

| Link | Evidence in the file | Kind of evidence | Host | Weakness |
|----------------------------------------|----------------------------------------------------------------------------|--------------------------|--------------------|------------------------------|
| Particle is taken up by alveolar macrophages through surfactant proteins A and D | Dye-positive alveolar macrophages 43.1% in wild-type, 12.7% in double knock-out [S01-C] | Genetic loss of function | Young knock-outs | n = 4; not done in aged mice |
| Cargo reaches alveolar epithelium | Dye-positive type II cells 15.8% with particle, 0.4% with free dye [S01-B] | Delivery | Aged | Later block on Mn and delivery conflicts (D05) |
| Gap junctions are needed for monocyte recruitment | Recruited monocytes 7.3% → 3.1% with carbenoxolone [S11-C] | Pharmacological block | Aged | Carbenoxolone is not selective |
| **Mn lifts the interferon ceiling** | *Ifnb1* 37.1 vs 16.6-fold; plateau 53 vs 16 [S01-A, S08-A] | Matched-particle comparison, dose series | Aged (S08-A by label) | No Mn-only control |
| **Mn switches on GM-CSF** | *Gm-csf* 8.7 vs 1.6-fold at 36 h [S02-F] | Matched-particle comparison | Aged (by label) | Transcript only; no young reference |
| Monocyte influx depends on CCR2 | Lung monocytes 9.9% → 3.3% with INCB3344 [S07-B] | Pharmacological block | Age not stated | Sampling day not stated |
| Monocytes need interferon signalling to become dendritic cells, and GM-CSF can partly stand in | Donor-derived monocyte-derived DCs 19.7% (wild-type marrow) → 2.1% (interferon-receptor-deficient marrow) → 12.4% with GM-CSF added back, 63% of wild-type [S02-H]. Monocyte influx itself is not clearly interferon-dependent: 21.3% vs 15.4% (Welch p = 0.12) [S12-A] | Genetic loss of function with add-back | Young (S12-A); not stated (S02-H) | n = 3 in S12-A |
| Supplying GM-CSF raises the dendritic-cell-like population under PSLN-212 | 5.9% → 13.8%; GM-CSF alone 1.5% [S02-G] | Gain of function | Aged by label | **No protection read-out**; no PSLN-344 reference arm |
| Lymph-node priming needs cell migration; lung priming does not | OT-I proliferation in lymph node 30.9% → 6.8% with pertussis toxin; in lung 59.0% → 55.1% [S05-C] | Pharmacological block | C57BL/6, age not stated | n = 3 |
| Blocking monocyte influx removes the lung effector CD8 response | Lung GZMB⁺ CD8 6.77% → 1.39% [S02-I] | Pharmacological block | **Young** | Not done in aged mice |
| CD8 effector, memory and lung-resident cells are restored | Table 2 [S05-D to S05-I, S14-A] | Matched-particle comparison | Aged | Association only |
| Antibody is restored | Table 2 [S03, S13] | Matched-particle comparison | Aged | Association only |
| **CD8 T cells, dendritic cells or antibody → survival** | **None** | **Not tested** | | **The open link** |

What the file does establish about the driver:

1. **It is the manganese.** Same particle, same dose, with and without Mn: 85/101 vs 13/101.
2. **It needs antigen.** PSLN-344 without vaccine, given 3 days before challenge, protected 0/7; vaccine without PSLN-344 protected 0/7; together 6/7 [S15-H]. An interferon-induced antiviral state on its own is ruled out as the cause of protection, even at day 3.
3. **It is not strain-specific antibody.** The vaccine and challenge strains differ in subtype in six of the eight aged BALB/c experiments, and protection is present 2–3 days after dosing. And where antibody should matter most it did not predict outcome: all five aged animals given PSLN-212 reached an H1N1 HAI titre of 40 or more (5/5; geometric mean 46) [S03-C], the conventional human threshold *[external]*, yet that arm survived 0/7 against the matched virus [S03-I; 3/7 under the S13-F labels]. Both arms that survived had every animal at 160 or above (5/5 and 5/5).
4. **What moves with protection is the interferon → GM-CSF → monocyte-derived dendritic cell → CD8 arm**, and the middle of that chain has loss- and gain-of-function support (Table 3).

So the most probable driver is Mn-restored priming of cross-reactive CD8 T cells by monocyte-derived dendritic cells in the lung, with restored antibody adding to protection against matched strains. "Most probable" is the honest strength of that statement. The file cannot distinguish CD8 T cells from cross-reactive non-neutralising antibody, which was never measured, and it contains no experiment that removes either and then challenges. Study 2 closes this.

### 4.2 Is there a biomarker of efficacy worth carrying forward?

**Table 4. Candidates**

| Candidate | Moves with Mn in aged mice (344 ÷ 212) | On the causal path? | Measurable in patients? | Verdict |
|----------------------------------------------|----------------------------------------|----------------------------------------|--------------------------------------|------------------------------|
| **Early interferon-β → GM-CSF → CCL2/monocyte → dendritic-cell response** (lung *Ifnb1* 16 h, *Gm-csf* 16–36 h, *Ccl2* 16 h, lung monocytes and CCR7⁺ dendritic cells day 3–4) | 2.2×, 5.5×, 77×, 1.8×, 4.2× [S01-A, S02-F, S09-A, S01-D, S02-A] | Yes for the middle links: interferon-receptor loss, GM-CSF add-back, CCR2 block [S02-H, S02-G, S07-B, S02-I] | Not as measured (lung tissue). As nasal-lining-fluid protein and nasal or blood transcripts: plausible, untested | **Carry forward as a pharmacodynamic marker** |
| HAI and neutralising titre | 8.0× and 9.2× [S03-C, S03-D] | Not for cross-subtype or day-2/3 protection; the 1:40 threshold mis-called the PSLN-212 arm | Yes; standard serum assays | Carry as the regulatory immunogenicity read-out, not as the efficacy marker |
| Cross-reactive CD8 (IFN-γ after re-stimulation with a virus not in the vaccine); lung-resident memory CD8 | 4.2× and 4.0× [S05-F, S05-I] | Plausible; untested | Blood ELISpot or intracellular staining yes; lung-resident cells no | Carry as an exploratory read-out; first in line for Study 2 |
| IgG2a/IgG1 quotient | 3.7× [S13-A, S13-B] | No evidence | Serum, but no clean human counterpart *[external]* | Do not carry |
| CD40, CD86 on lymph-node dendritic cells | 2.0×, 1.8×, but only 29% and 38% of young [S02-D] | Protection returned without them | No | Drop |
| Follicular regulatory T cells | Day 7 yes, day 30 no [S04-B, S04-C] | No evidence | No | Drop |
| Alveolar macrophage, NK, neutrophil percentages | No difference between PSLN-344 and PSLN-212 [S11-A, S11-D]; neutrophil block unusable (D06) | – | – | Drop |

**Verdict: yes, carry the early interferon-β/GM-CSF/monocyte–dendritic-cell response forward, as a pharmacodynamic marker.** Four reasons come from our data. It sits at the step that fails with age: PSLN-212 gives aged mice 44% of the young *Ifnb1* response and PSLN-344 gives 99% [S01-A]. It responds to dose between 5 and 20 µg (8.3-, 21.1- and 45.8-fold) and then flattens (50.2-fold at 40 µg) [S08-A]. Its middle links are the only part of the mechanism with intervention evidence. And it reads out within three days, which is when a dose-escalation study needs an answer. If the panel has to be cut to two analytes, they are GM-CSF, which is essentially off without Mn (1.6-fold, against 1.2-fold for sham) and on with it (8.7-fold) and which raises the dendritic-cell population when supplied from outside [S02-F, S02-G], and an interferon read-out, which is dose-responsive and restored to the young level [S01-A, S08-A].

**It is not a surrogate for protection, and the file gives three reasons.**

- No animal has both a biomarker and an outcome; every association is between group means, and there are only four or five groups. Every restored read-out is collinear with every other, so the data cannot rank one candidate above another.
- The relation is a step, not a slope (Figure 5a). Groups whose 16-hour *Ifnb1* was 16.6-fold or less survived 13/101 (PSLN-212, aged) and 1/73 (sham), with one exception, the cGAMP particle at 7.8-fold, which survived 3/7 in its single experiment; groups at 37.1-fold or more survived 85/101 (PSLN-344, aged) and 86/87 (PSLN-212, young). In young mice PSLN-344 raises *Ifnb1* further (50.7-fold) with no survival left to gain (31/31) [S01-A; Tables 1 and 1b]. The marker can say the pathway is engaged; it cannot say how much protection follows.
- The same pathway, pushed harder or for longer, is the reactogenicity signal (§2.5). The marker has to be read with an upper bound as well as a lower one.

![Figure 5](figures/fig5_biomarker_vs_survival.png)

*Figure 5. Group-level relation between (a) the early interferon response and survival and (b) HAI titre and survival against the matched virus. Different animals supplied the marker and the outcome. The CMP-204 and PSLN-212 survival values in panel b, and the CMP-204 point in panel a, are S03-I as printed (D02).*

**Could it go into patients?** Not in the form we measured. The patient-compatible form *[external, standard sampling methods]* is: nasal-lining-fluid protein (interferon-β or its stable surrogate CXCL10, GM-CSF, CCL2) at baseline, 16–24 h and 72 h; an interferon-stimulated-gene and monocyte transcript panel in nasal curettage and whole blood at the same times; blood monocyte phenotype on days 1–3. None of these has been measured in our animals. Study 3 has to show that nasal and blood measurements track the lung response and later protection in the same animals before the marker is used to make a clinical decision.

**In what role?** As a pharmacodynamic (response) biomarker. Phase 1: proof of mechanism in older adults and dose selection (choose the lowest dose that reaches the plateau of the marker without the prolonged *Tnf*/*Il6* tail, which makes the same panel a safety read-out). Phase 2: a response marker for comparing lots, devices and regimens. It should not be used as a surrogate endpoint or to select patients. HAI and neutralisation travel alongside as the immunogenicity read-outs regulators expect *[external]*, and a blood CD8 assay against conserved internal proteins as the exploratory read-out closest to the proposed mechanism.

### 4.3 What the next studies have to establish

Durations below are planning assumptions. Mice of 20 months or more are the rate-limiting reagent and should be reserved at approval.

**Table 5. Overview**

| Study | What it has to establish | Runs | Feeds |
|----------------------------------------|------------------------------------------------------------------------------------------------|------------------------|----------------------|
| 0. Source-data audit | The file is sound, or which experiments must be repeated | Weeks 0–6 | Gate 0 |
| 1. Blinded confirmatory challenge with component controls | The effect replicates; Mn and cyclic dinucleotide are both needed; how it compares with an enhanced-vaccine stand-in; deaths are due to infection | Months 1–7 | Gate 1 |
| 2. Mediator of survival | Which of CD8 T cells, CD4 T cells, antibody, monocyte influx, interferon signalling and GM-CSF the survival benefit depends on | Months 2–7 | Gate 1; biomarker choice |
| 3. Dose, pharmacodynamics and biomarker bridging | Lowest effective dose and margin; marker-to-protection relation in individual animals; whether nasal and blood samples report the lung | Months 3–9 | Gate 1; clinical dose rationale |
| 4. Airway manganese safety | Whether Mn reaches and stays in olfactory bulb or brain; nasal and lung tolerance in aged animals; repeat dosing | Pilot months 2–8; GLP after Gate 2 | Gate 1; IND |
| 5. Translation | Activity with a licensed antigen, by a human-usable route, in ferrets, and on human aged-donor cells | Months 2–15 | Gate 2 |
| 6. CMC readiness | A characterised, stable, assayable product | Months 1–12 | Gate 2 |
| 7. First-in-human outline | Safety, dose and proof of mechanism in adults ≥65 | Not before month 27–30 | – |

**Study 0. Source-data audit (Gate 0)**

- *Has to establish:* for each of the 22 logged issues, whether it is a transcription error or real. Specifically: the true S06-D table; the group labels of S03-I/S13-F and S03-J/S13-G; the headers of S03-B, S03-F, S08-C and S07-C; the origin of S11-B and of the shared body-weight values; the identity of S08 rows 89–101 and of "PSLN-344/R848"; cause of death of the four untreated animals; Mn content per dose and the meaning of "20 µg".
- *Population:* none. Records: notebooks, instrument exports, animal-facility mortality logs.
- *Comparator:* workbook against raw records.
- *Endpoint:* a corrected, QA-signed file; this analysis re-run on it (scripts supplied in `analysis/`).
- *Timing:* 4–6 weeks, before any external disclosure.
- *Decision rule:* proceed if the pooled survival difference remains at least 40 points. Stop and escalate if any outcome, as opposed to a label, proves to have been altered.

**Study 1. Blinded confirmatory challenge study with component controls**

- *Has to establish:* (a) the Mn-dependent rescue replicates under randomisation, blinding and a pre-registered analysis; (b) Mn and the cyclic dinucleotide are each necessary; (c) where PSLN-344 stands against a stand-in for licensed enhanced vaccines; (d) deaths are due to infection.
- *Population:* mice of 20 months or more, both sexes, two strains (BALB/c and C57BL/6, both responsive in the present file [S15-L]); 7–8-week mice as reference. Eighteen per arm for survival, which gives about 90% power for 80% vs 25% survival (Fisher, two-sided 5%); six per arm per time point for virology and immunology; ten unchallenged age-matched animals per cohort with necropsy of every death. Scale: the day-14 cohort in one strain is 8 arms × 18 = 144 challenged animals plus satellites; the second strain and the day-60 cohort can follow if aged-animal supply is short.
- *Comparators:* vaccine + empty liposome; PSLN-212; **PSLN-344**; a Mn-only particle at matched Mn; PSLN-212 mixed with free Mn²⁺ at matched Mn; PSLN-212 given twice; an intramuscular high-dose or oil-in-water-emulsion-adjuvanted vaccine arm; young mice + PSLN-212. Antigen: the current whole-virion vaccine and, in parallel arms, a split antigen at matched HA.
- *Endpoints:* primary, survival to day 14 after a different-subtype challenge (H3N2 vaccine → 5× mLD50 PR8 H1N1) given 14 days after one dose. Key secondary: lung virus titre 3 and 6 days after challenge; body-weight area under the curve with one pre-declared rule for dead animals; clinical score; survival after a day-60 challenge in a second cohort; a matched-strain challenge arm.
- *Read-outs:* HAI and neutralisation against vaccine and challenge strains; IgG binding to challenge-strain antigens (cross-reactive antibody has never been measured); nasal-wash and lung-lavage IgA; lung and blood CD8 by tetramer and IFN-γ on days 7, 14 and 60; lung-resident memory CD8 with intravascular labelling.
- *Timing:* dose day 0; challenge day 14 (cohort A) and day 60 (cohort B); 14–21 days of observation. About 3 months in life, 6–7 months to report.
- *Decision rule:* pass if PSLN-344 survival is at least 70% and at least 40 points above PSLN-212 with a 95% interval excluding zero, in both strains, and PSLN-344 beats the Mn-only and Mn-admixture arms. If Mn alone or admixed Mn does as well, the product definition changes before any further spend.

**Study 2. What mediates survival**

- *Has to establish:* whether the survival benefit at day 3 and at day 14 depends on CD8 T cells, CD4 T cells, serum antibody, monocyte influx, interferon signalling or GM-CSF; and whether GM-CSF add-back rescues PSLN-212.
- *Population:* mice of 20 months or more, one strain, 12–15 per arm (89–94% power to detect a fall from 80% to 15% survival).
- *Comparators (all vaccine + PSLN-344 unless stated):* isotype control; anti-CD8 before challenge; anti-CD4 before challenge; both; the CCR2 antagonist around vaccination as in S07-B; anti-interferon-receptor antibody at vaccination; anti-GM-CSF at vaccination; PSLN-212 + recombinant GM-CSF as in S02-G; day-14 serum from PSLN-344 donors transferred into unvaccinated aged recipients; lung and lymph-node CD8 T cells transferred likewise.
- *Endpoints:* primary, survival. Secondary, lung virus titre and body weight.
- *Read-outs:* confirmation of each depletion or blockade by flow cytometry or ELISA; monocyte-derived dendritic cells and CD8 T cells in satellite animals.
- *Timing:* alongside Study 1; about 5–6 months.
- *Decision rule:* the arm or arms that remove at least half of the survival benefit define the on-path read-out to carry into Study 3 and the clinic. If serum alone transfers cross-subtype protection, antibody-breadth assays take priority over T-cell assays.

**Study 3. Dose, pharmacodynamics and biomarker bridging in the same animals**

- *Has to establish:* the lowest fully effective dose and its margin to reactogenicity; the relation between the early marker and later protection in individual animals; whether nasal and blood measurements report the lung response.
- *Population:* mice of 20 months or more; 12 per dose for challenge, 6 per dose per time point for tissue.
- *Comparators:* PSLN-344 at 0, 2.5, 5, 10, 20 and 40 µg (the *Ifnb1* response rises between 5 and 20 µg and is flat above [S08-A]); PSLN-212 at 20 and 40 µg; young mice + PSLN-212 at 20 µg.
- *Endpoints:* primary, survival by dose. Co-primary, the within-animal association between the 16–24 h marker and survival (logistic model and area under the ROC curve, declared in advance).
- *Read-outs:* in the challenge animals, without killing them: serum interferon-β or CXCL10, GM-CSF and CCL2 and whole-blood transcripts at 16–24 h and 72 h; blood monocyte phenotype on day 3; HAI, neutralisation and blood IFN-γ ELISpot on day 13; challenge on day 14. In satellite animals: nasal wash, lung lavage and lung tissue at 16 h, 72 h and day 4, to tie the accessible samples to lung *Ifnb1*, *Gm-csf*, *Ccl2* and lung monocyte and dendritic-cell counts. Tolerability: weight, temperature, lavage cell counts and protein, lung histology on days 1, 3, 7, 14 and 28.
- *Timing:* about 6 months, starting when Study 1 has its day-14 result.
- *Decision rule:* a dose of 20 µg or less with at least 70% survival and weight loss no worse than today's 20 µg data (mean lowest weight 96.4%, worst animal 94.2% [S08-D]). The marker goes to the clinic as a dose-selection tool only if at least one accessible-sample measurement rises with dose and separates survivors from non-survivors with an area under the curve of 0.8 or more; otherwise it goes as a mechanistic read-out only.

**Study 4. Airway manganese safety**

- *Has to establish:* whether Mn from the particle reaches the olfactory bulb or brain and persists; tolerance of the nose and of the aged lung; systemic cytokine exposure; the effect of repeat dosing. Inhaled Mn is a recognised neurotoxicant and travels along the olfactory nerve, and an intranasal influenza vaccine with a bacterial-toxin adjuvant was withdrawn after cases of facial palsy *[external]*; regulators will ask.
- *Population:* pilot in aged and young mice of both sexes, 6–8 per group per time point. GLP study in the species agreed with regulators, by the clinical route and device.
- *Comparators:* vehicle; PSLN-212; PSLN-344 at 1×, 3× and 10× the dose chosen in Study 3; intranasal Mn chloride at matched Mn as a positive control for uptake; cholera toxin as the positive control already used in S10-A.
- *Endpoints:* primary, Mn by inductively coupled plasma mass spectrometry (ICP-MS) in olfactory bulb, brain regions, lung, liver and blood at 24 h and days 7, 28 and 90, after one dose and after three; histopathology of nasal cavity including olfactory epithelium, olfactory bulb, brain, facial nerve and lung.
- *Read-outs:* olfactory and motor function tests; lung-lavage cytology; serum cytokines at 6–24 h; clinical pathology; weight and temperature; the S10-A central-nervous-system transcripts repeated as a time course from 6 h to day 7 with a wider panel.
- *Timing:* pilot 4–6 months (the day-90 necropsy sets the length). GLP study 9–12 months, after Gate 2.
- *Decision rule:* stop if Mn in olfactory bulb or brain is above vehicle at day 28 at three times the effective dose or less together with a histological or functional change, or if lung inflammation is unresolved at day 28.

**Study 5. Translation**

- *5a, deposition (mice ≥20 months; months 2–5).* Upper-airway-restricted dosing against the present dosing against intratracheal dosing. Comparators: PSLN-344, PSLN-212, sham by each route. Endpoints: lung and nasal *Ifnb1* at 16 h; survival after different-subtype challenge. Establishes whether deep-lung delivery is required.
- *5b, human cells (months 2–6).* Blood monocytes and mononuclear cells from at least 12 donors aged 65 or more and 12 aged 18–40, STING genotype recorded; lung-lavage macrophages where obtainable. Comparators: vehicle, PSLN-212, PSLN-344, Mn-only particle over five or six concentrations. Read-outs: interferon-β, CXCL10, GM-CSF, TNF and IL-6 protein at 6 and 24 h. Establishes whether the age-related ceiling and its rescue by Mn exist in human cells.
- *5c, ferret (months 8–15).* Adult ferrets, and aged ferrets if obtainable. Licensed split antigen with or without PSLN-344 through a clinical-type nasal or inhalation device. Comparators: antigen alone by the same route; PSLN-212; a licensed high-dose or adjuvanted vaccine intramuscularly. Challenge 28 days after dosing with a drifted and with a different-subtype human isolate. Primary endpoint: nasal-wash virus titre, area under the curve, days 1–7. Secondary: fever, weight, clinical score, HAI, neutralisation, nasal IgA. Read-outs: the Study 3 marker panel in nasal wash and blood at 24–72 h.
- *Decision rule:* activity with a licensed antigen and by a human-usable route, and virus shedding no worse than the licensed-vaccine arm.

**Study 6. CMC readiness (alongside)**

- *Has to establish:* particle size, polydispersity, charge and morphology (measured according to the annotation, absent from the file); Mn content and release; cyclic-dinucleotide loading with a specification (encapsulation is 54.8% ± 5.1 over three preparations [S08-B]); a cell-based potency assay tied to the in-vivo *Ifnb1* response; stability of lyophilised material at −20 °C and 2–8 °C at 1, 3, 6 and 12 months; compatibility with licensed antigens.

**Study 7. First-in-human outline (only after Gates 1 and 2 and GLP toxicology)**

- *Population:* Part A, healthy adults 18–49 as sentinels, about 8 per dose. Part B, adults of 65 or more, the intended population, 25–30 per arm, stratified 65–74 and 75 or more. A 50–64 cohort is worth considering, because the Mn-free particle had already failed in 14-month mice [S06-E and S06-F, rows 71–105], roughly human middle age *[external]*. The first study excludes chronic lung disease needing daily treatment, neurological disease and any history of facial palsy.
- *Comparators:* licensed inactivated antigen alone by the same route; the same antigen with PSLN-344 at three dose levels; a licensed enhanced vaccine for this age group given intramuscularly.
- *Endpoints:* primary, solicited nasal, respiratory and systemic reactions on days 0–7, unsolicited events to day 28, serious events and events of special interest (facial palsy, change in sense of smell, wheeze, new neurological signs) to day 180; blood Mn. Secondary, HAI geometric mean titre, seroconversion and neutralisation on day 28 for each strain against the active control.
- *Read-outs:* the pharmacodynamic panel at 24 h and 72 h; circulating follicular helper T cells and plasmablasts on day 7; IFN-γ ELISpot to conserved internal proteins on days 14, 28 and 180; nasal IgA on day 28; antibody persistence on day 180.
- *Timing:* one dose; visits on days 0, 1, 3, 7, 14, 28, 90 and 180.

### 4.4 Gates and stop rules

| Gate | When | Pass criteria | Stop if |
|--------|----------------|--------------------------------------------------------------------------------------------|----------------------------------------------------------------|
| 0 | Week 6 | Issues reconciled or the affected experiments queued for repeat; pooled difference still ≥ 40 points on the corrected file | An outcome, not a label, was altered |
| 1 | Month 9–10 | Study 1 passes in both strains; Study 2 identifies at least one mediator whose removal takes away half or more of the benefit; Study 3 finds an effective dose ≤ 20 µg with acceptable weight loss; Study 4 pilot shows no Mn retention in olfactory bulb or brain with pathology and lung inflammation resolved by day 28 | Replication fails (PSLN-344 below 60% survival or less than 30 points above PSLN-212); Mn-only particle matches PSLN-344 (re-scope, do not proceed as is); neural Mn signal |
| 2 | Month 15 | Activity with a licensed split antigen; activity by a human-usable route; ferret shedding no worse than the licensed-vaccine arm; Mn-dependent enhancement in cells from donors of 65 or more; CMC specification and 6-month stability | Protection needs deep-lung deposition that a device cannot deliver safely; no activity with licensed antigen; no Mn effect in human aged cells |

## 5. What I considered and ruled out

**Alternative explanations of the result**

| Hypothesis | Test in our data | Verdict |
|------------------------------------------------|--------------------------------------------------------------------------------------------------------|------------------------------------|
| PSLN-344 is simply a stronger dose of the same agonist | Dose series: PSLN-212 at 40 µg (14.9-fold) stays below PSLN-344 at 10 µg (21.1-fold); plateaus 16 vs 53, similar half-maximal dose [S08-A] | Ruled out. Mn raises the ceiling |
| Protection is an innate antiviral state from the STING agonist | PSLN-344 without antigen 0/7; with antigen 6/7 [S15-H] | Ruled out |
| Protection is HAI or neutralising antibody to the vaccine strain | Cross-subtype protection in six experiments; protection at day 2–3; PSLN-212 arm with HAI ≥ 40 in 5/5 survived 0/7 [S03-C, S03-I, S06] | Ruled out as the driver; likely contributes against matched strains |
| A BALB/c peculiarity | C57BL/6 6/7 vs 0/7; outbred Swiss Webster 6/7 vs 2/7 [S15-L, S15-N] | Ruled out |
| It only works in animals that have never met influenza, or prior infection does the work | 6/7 unprimed and 6/7 imprinted; with PSLN-212, imprinting helped only against the imprinting virus (4/7 vs PR8, 0/7 vs H3N2) [S06-E, S06-F rows 71–105] | Ruled out |
| The result is produced by the data defects | Five analyses from "as printed" to "least favourable": 65 to 71 points; nine unflagged comparisons alone 52/63 vs 8/63 (§2.1) | Ruled out |
| Better encapsulation of the agonist in PSLN-344 | 54.8% vs 59.6% [S08-B] | Ruled out |
| Mn improves delivery to the epithelium | S08-C conflicts with S01-B (D05) | Cannot be judged |
| PSLN-344 skews antibody toward IgG1 | S03-B as printed says so; recomputed from subclass titres it is the reverse (2.14 vs 0.58) [S13-A, S13-B] | Ruled out; label error (D04) |
| Protection wanes by day 60 | PSLN-344 deaths 1/21 at day 14, 7/21 at day 60, but 4/21 unchallenged controls also died [S06] | Not established either way |
| Restored dendritic-cell co-stimulation explains it | CD40 and CD86 reach only 29% and 38% of young while survival returns [S02-D] | Ruled out as a requirement |
| A lasting fall in follicular regulatory T cells explains it | Gone by day 30 (14.0% vs sham 13.9%) [S04-C] | Ruled out as a lasting effect |

**Alternative products and positions**

| Option | Evidence | Verdict |
|------------------------------------------------|--------------------------------------------------------------------------------------------------------|------------------------------------|
| Advance PSLN-212 and leave out the Mn | Young mice 8/8, 8/8, 8/8; aged mice 13/101 [S09, Table 1] | Rejected for older adults. It is a young-adult adjuvant |
| Give PSLN-212 twice instead | After a boost, IgG is still 3.5× (H1N1) and 11.5× (H3N2) below PSLN-344; no challenge after boost [S13-I, S13-J] | Not supported; tested properly in Study 1 |
| Add GM-CSF to PSLN-212 instead of Mn | Raises the dendritic-cell-like population 2.4× [S02-G]; no protection data | Kept as a mechanistic tool (Study 2), not as a product |
| The cGAMP particle CMP-204 | Aged: *Ifnb1* 7.8-fold, IgG geometric mean 181, survival 3/7 as printed (D02); young 7/7 [S01-A, S03-A, S03-I, S13-E] | Rejected for older adults |
| The TLR7/8 agonist R848, alone or combined | PSLN-R848 *Ifnb1* 5.1-fold; PSLN-212/R848 24.3-fold with *Tnf* 202-fold, *Il10* 179-fold and progressive weight loss to 90.65% [S01-A, S09-A, S08-D] | Rejected on tolerability |
| PSLN-344 as a stand-alone antiviral prophylactic | 0/7 [S15-H] | Rejected |
| PSLN-344 for young adults | No survival gain over PSLN-212 (8/8 vs 8/8) and a higher interferon response (50.7- vs 37.6-fold) [S09, S01-A] | Rejected; the asset is specific to the aged host |

**Alternative recommendations**

- *Unconditional go to IND-enabling work.* Rejected. The integrity defects, the untested causal link and the thin airway-Mn safety data would each be found in diligence, and each can be closed for far less than a GLP and GMP programme costs.
- *No-go.* Rejected. The effect is the largest and most consistent thing in the file, it survives every sensitivity analysis, and the open questions are answerable with bounded experiments. Stopping now would discard the asset for reasons that are fixable.
- *Hold with no spend.* Rejected. Nothing resolves without the audit and the replication, and aged-animal lead times mean a hold costs a year.

**Analyses I chose not to rely on**

Group mean body-weight curves (two conventions for dead animals, re-used values); S06-D; S03-B and S03-F as printed; S07-C; S11-B; S08 rows 89–101; S05-A and S05-B beyond description (two animals, contradictory conditions); arithmetic means of titres; p-values from single 7-versus-7 experiments as stand-alone evidence.

## 6. If the committee decides to drop it

**What we would be dropping.** The only preparation in the file that gives aged animals young-like protection: 51/63 against 62/63 in young animals and 6/63 for the same particle without Mn, from one needle-free dose, across subtypes, within days, for at least two months. And the finding behind it: in the aged lung the interferon and GM-CSF response to a STING agonist is capped, not merely shifted, and Mn removes the cap. That is a finding about ageing and adjuvants that may reach beyond influenza.

**Why one might still drop it.** An airway product containing manganese for people over 65 will carry a heavy toxicology burden; the mechanism as shown depends on reaching the deep lung; the efficacy is in mice with a whole-virion antigen; the file needs an audit before it can support anything.

**What we would keep.** PSLN-212 as a young-adult adjuvant (8/8 in three experiments); the surfactant-biomimetic particle; the mechanistic read-outs.

**Minimum close-out to preserve value.** Complete Gate 0 regardless, because the same workbook underpins PSLN-212; retain characterised lots under stability; secure the Mn–ageing finding (patent or publication); keep the analysis scripts with the corrected file so that a partner can reproduce every number.

## Appendix A. Methods

- **Parsing.** Every sheet was read cell by cell. Each value keeps its sheet and cell address. All 6,819 numeric cells are assigned to a block, an axis (day or dose) or the unlabelled region S08!A89:D101; none is unassigned. Labels are kept exactly as printed.
- **Reductions.** Percentages, cell counts and linear fold-changes: arithmetic mean and SD of the per-animal values. Titres: geometric mean; HAI values printed as 0 set to 5. S09-A: mean of the stored log10 values, back-transformed. Survival: rows with event flag 0 over rows printed; a row with a flag but no day (S03!J46) counts as a survivor in the primary analysis and is dropped in the least-favourable one.
- **Tests.** The methods named in the annotation were used: one-way ANOVA with Tukey's test within a block (log10 scale for titres and fold-changes), and log-rank for time to event, the latter as an exact permutation test because groups are small. Welch intervals are given for ratios and differences, exact Mann–Whitney and Fisher tests as checks. Pooled survival: Mantel–Haenszel risk difference stratified by comparison with an exact stratified permutation p-value. No correction for multiplicity across blocks was applied; p-values are descriptive.
- **Body weight.** Per animal, the lowest recorded value. An animal is counted as dead if its cells go blank or its value is constant below 90% through day 14.
- **Dose–response.** Three-parameter Hill function with baseline fixed at 1, least squares on the 15 per-animal values of each preparation.
- **Defect search.** Stated n against observed n; paired survival and weight blocks against each other; every derived block recomputed from its sources; all pairs of blocks compared for repeated values in the same positions.
- **Precedence.** Where the workbook and the annotation disagree, the workbook as printed is the primary analysis and the alternative is a sensitivity analysis.
- **Limits of this analysis.** Only the compiled workbook and its annotation were available: no raw instrument files, protocols or randomisation records. Conclusions that a label or a table is wrong are inferences from internal consistency and are marked as such. Durations, sample sizes for future studies, gate thresholds and the regulatory context are my proposals and planning assumptions, not data.
- **Reproducibility.** Scripts are in `analysis/`; `render.sh` rebuilds every table, figure, the ledger and this memo from the workbook.

## Appendix B. Evidence ledger

`evidence_ledger.csv` has one row per number used in this memo: block, quantity, value, n, sheet and cells, and the reduction applied. It is sorted by block, so a number cited as [S01-A] is found under S01-A. Pooled and derived quantities are listed under "pooled survival", "body weight after challenge", "power calculation", "integrity checks" and "workbook". `analysis/verify_ledger.py` recomputes every simple entry (means, SDs, geometric means, survivor counts: 248 rows) straight from the workbook cells named in the ledger; all agree. `tidy_values.csv` and `tidy_survival.csv` in `analysis/` hold every parsed cell with its address.

## Appendix C. Data-integrity log

| ID | Severity | Where | Finding | Consequence | How handled |
|--------|------------|----------------------------|--------------------------------------------------------------------------------|------------------------------------|------------------------------------|
| D01 | High | S06-C vs S06-D (S06!M3:Q30 vs S06!A34:E61) | The two time-to-event tables are identical row for row (28 rows: same days, same flags, same order) although they are described as different experiments (challenge on day 14 vs day 3). The weight block paired with S06-D (S15-D) implies 2 deaths in the PSLN-344 arm and 2 in the young arm; the table shows none. | S06-D cannot be counted as an independent experiment. Day-3 protection against rgH5N1 rests on S15-H alone. | Counted once (as S06-C). S06-D appears only in the least-favourable sensitivity analysis, entered from its weight block (5/7 vs 2/7). |
| D02 | High | S03-I vs S13-F (S03!A17:F51 vs S13!B33:AJ40) | S13-F is annotated as "the animals of S03-I" but prints groups PSLN-212(Y), Sham, PSLN-212, PSLN-344, Naïve, where S03-I prints Sham, CMP-204, PSLN-212, PSLN-344, PSLN-212(Y). By death pattern the S13-F "PSLN-212" column (4 animals frozen, 3 recover) matches the S03-I "CMP-204" column (4 deaths, 3 survivors), and S13-F "Naïve" (all 7 gone by day 8) matches S03-I "PSLN-212" (7 deaths by day 6). In the nine other experiments that have both arms the PSLN-212 arm dies later than sham (later median day of death in 9 of 9); in S03-I as printed it does not (days 5-6 against 5-11), which favours the S13-F labels. | In the only matched-strain challenge the PSLN-212 arm is either 0/7 or 3/7 survivors. PSLN-344 is 7/7 under both readings. | Primary analysis uses S03-I as printed (0/7); sensitivity uses 3/7; S03-I is excluded from the "unflagged" subset. |
| D03 | High | S03-J vs S13-G (S03!G17:J46 vs S13!B43:AE50) | S13-G ("the animals of S03-J") prints PSLN-344, Sham, Naïve; S03-J prints Sham, PSLN-212, PSLN-344. S13-G "Naïve" (9 of 10 frozen) matches S03-J "Sham" (9 deaths); S13-G "Sham" (5 frozen, 1 still falling at day 14) resembles S03-J "PSLN-212" (7 deaths). Also: stated n = 9 but 10 rows per group; the last PSLN-344 row has a flag (J46 = 0) but no day (G46 blank); annotation says 22 days of observation, the latest day in the table is 21; challenge dose and animal age are not stated. | The comparator arm in the wild-type H5N1 experiment may be vaccine-only rather than PSLN-212. PSLN-344 is 10/10 (or 9/9) under every reading. | Primary as printed; excluded from the "unflagged" subset; 9/9 used in the least-favourable analysis. |
| D04 | Medium | S03-B and S03-F (S03!G3:I7, S03!G10:I14) vs S13-A to S13-D (S13!A3:O7) | The IgG2a/IgG1 quotients printed under "PSLN-212", "PSLN-344", "PSLN-212(Y)" equal, animal by animal, the quotients recomputed from the S13 titres for PSLN-212(Y), PSLN-212 and PSLN-344 respectively (agreement to within 0.1%). The headers are rotated by one position. | As printed, PSLN-344 would look IgG1-skewed (0.58). Recomputed, PSLN-344 is 2.1 (H1N1) and 2.7 (H3N2), PSLN-212 is 0.58 and 0.51. | Recomputed quotients from S13 are used; S03-B/F as printed are not. |
| D05 | Medium | S08-C vs S01-B (S08!A14:D18 vs S01!B14:F17) | As printed, S08-C gives 13.8% dye-positive type I cells for the Mn-free particle (S01-B gives 3.8% for the same condition) and a four-fold loss of type II delivery when Mn is added. Column A of S08-C shares three values with the S01-B type II row and column B shares two with the S01-B type I row. Swapping the headers of columns B and C reconciles the two blocks (type II 15.8 vs 13.8; type I 3.8 vs 3.0). | Whether Mn changes epithelial delivery cannot be read from this block. | Not used for any claim; flagged for source check. |
| D06 | Medium | S11-A vs S11-B (S11!B3:U7 vs S11!B10:U14) | 35 of 100 cells are identical in the same positions (replicates 1 and 2 of almost every group and day), and the group means differ by at most 2.5 points, although one block is alveolar macrophages and the other neutrophils. | The neutrophil time course, a reactogenicity readout, is not independent data. | S11-B not used. |
| D07 | Medium | Body-weight blocks on S09, S13, S15 | Values recur across nominally independent experiments: S15-C PSLN-344 vs S15-I "3d Vaccine+PSLN-344" share 40 of 49 post-baseline values (all 7 animals); S09-E PSLN-344Y (BALB/c) vs S15-M PSLN-212(Y) (C57BL/6) share 32 of 49; S15-A vs S15-M PSLN-344 share 16 of 49; S09-E and S09-G PSLN-212Y column N is identical on all 7 days; in S09-C the day-12 row is the same for PSLN-212Y and PSLN-344Y. In S15-C one PSLN-344 animal rises from 77.9% to 90.1% between days 12 and 14 (S15!Y29:Y30); in the otherwise identical S15-I column the animal stays at 77.9% and is the recorded death. | Weight blocks cannot serve as independent confirmation of the survival tables. The 7/7 for PSLN-344 in S06-C may be 6/7. | Weights used descriptively only (lowest weight per surviving animal); no inferential claim rests on them. S06-C PSLN-344 entered as 6/7 in the least-favourable analysis. |
| D08 | Medium | Survival tables vs paired weight blocks | Death counts implied by the weight blocks (blank or frozen trajectories) differ from the tables by one or two animals in several arms: S06-C/S15-C PSLN-212 (5 vs 6 deaths); S06-E rows 34-68/S15-E PSLN-212 (7 vs 6) and PSLN-344 (2 vs 1); S06-G/S15-G PSLN-344 (3 deaths on days 8-11 vs 2 after day 12); S15-L/S15-M young arm (1 vs 0); S09-F Sham has 7 rows, S09-G has 8 animals. | Each survival count carries roughly ±1 animal of uncertainty. | Tables are primary; two sensitivity analyses (weight-implied counts; least-favourable counts). |
| D09 | Medium | Weight blocks: two conventions for dead animals | Dead animals are left blank in some groups (Sham, Naïve, single-agent arms) and carried forward at their last weight to day 14 in others (PSLN-212, PSLN-344, Untreated, some young animals). | Group mean curves after day 4-6 are not comparable between arms. | Group means over time are not used; per-animal lowest weight and survivor-only summaries are. |
| D10 | Medium | Untreated arms of S06-E and S06-F (rows 34-68) and S06-G | These 20-month animals received no vaccine, adjuvant or virus, yet 1/7, 0/7 and 3/7 died during the 14-day window (4/21). | Deaths in vaccinated arms at the day-60 challenge cannot all be attributed to infection; apparent waning is confounded. | Reported explicitly; durability claims limited to the contrast with PSLN-212 and Sham. |
| D11 | Low | Stated n vs observations | S03-J states 9, has 10; S05-A and S05-B state 3, have 2; S13-E states 5, has 7; S08-D PSLN-212/R848 has 4 values at day 10 (W26 blank); S09-F Sham has 7 rows against n = 8 (the annotation places the short group in S09-B, where the workbook has 8). | Minor; denominators differ from labels. | Observed counts used throughout. |
| D12 | Low | Sheet S06 block labels | Labels S06-E and S06-F are each used twice (rows 34-68 and rows 71-105) for different experiments. | Risk of mis-citation. | Always cited with the row range. |
| D13 | Medium | S09-A (S09!B3:V9 and S09!Y3:AS9) | Both panels are labelled "16h"; values are log10, not linear. Back-transformed Ifnb1 values of the first panel reproduce S01-A 16 h animals (18 of 18) and those of the second reproduce S01-A 72 h animals (18 of 18). The first group is labelled PBS here but carries the values of the S01-A "Sham" animals. | The second panel is in all likelihood 72 h. Control identity (buffer vs empty liposome) is ambiguous. | Second panel treated as 72 h and labelled as an inference; all S09-A values back-transformed. |
| D14 | Medium | S07-C (S07!B15:C20) | Both columns carry the same printed label ("Ly6C-CD206+ MΦ"). | The direction of the macrophage-transfer effect on lung Tregs cannot be assigned. | Not used. |
| D15 | Low | S08 rows 89-101 (S08!A89:D101) | Thirteen rows of numbers (14 in column A; 0 in column C for 6 rows and in column D for 7 rows) with no label, header or annotation. | Uninterpretable. | Excluded. |
| D16 | Low | S08-A group "PSLN-344/R848" | This preparation is not defined in the annotation (only PSLN-212/R848 is). | Identity unknown. | Shown as printed, not interpreted. |
| D17 | Medium | S05-A, S05-B (and S05-I by reference) | Conditions are contradictory (ovalbumin immunisation in one sentence, bivalent vaccine in the next; an NP366-374 tetramer readout; a sham group is mentioned but absent) and there are 2 animals per group against a stated 3. | Antigen-specific CD8 kinetics are descriptive at best. | Not used for inference; S05-I reported with the caveat. |
| D18 | Low | Under-specified blocks | Not stated: adjuvant and age of the "PTX" group (S02-C, S02-E); challenge virus, dose and day (S15-L, S15-N); challenge day (S06-E rows 71-105); sampling day (S07-B, S11-E, S13-H, S14-A); age (S02-G, S02-H, S07-A, S07-B, S08-A; read as aged from the label convention only). S10-A is annotated "mean with SD" but holds five per-animal values per group. | Limits interpretation of those blocks. | Stated where relevant. |
| D19 | Low | S08-B | Encapsulation is defined as absorbance of CDN-1807 at 260 nm but is also reported for CMP-204 (cGAMP cargo) and PSLN-R848 (no cyclic dinucleotide). | Measurand undefined for two of five preparations; PSLN-344 vs PSLN-212 comparison unaffected. | Only PSLN-212 and PSLN-344 compared. |
| D20 | Low | Mechanism blocks run outside the target host | S01-C uses 7-8-week knock-outs; S02-I and S12-A are young animals; S02-H does not state age. | Several mechanistic links are shown in young animals and inferred for aged ones. | Flagged in the evidence chain. |
| D21 | Medium | Dose definition | "20 micrograms of adjuvant per animal" is not defined as cyclic-dinucleotide mass or particle mass, and the Mn content per dose appears nowhere in the file. | Cyclic-dinucleotide dose may not be identical between PSLN-212 and PSLN-344; Mn exposure cannot be calculated. | Flagged as a CMC and toxicology gap. |
| D22 | Low | S08-A CMP-204 at 1 µg vs S02-F Sham at 16 h (S08!B3:D3 vs S02!L17:P17) | The three CMP-204 values at 1 µg (1.02, 1.05, 0.93) are three of the five sham values in a block that measures a different transcript. | None for any conclusion (both sets sit at baseline); coincidence not excluded. | Noted for the audit. |

![Figure 6](figures/fig6_integrity_examples.png)

*Figure 6. Four of the logged issues, shown from the workbook values: (a) D01, (b) D04, (c) D07, (d) D06.*

## Appendix D. Questions the committee is likely to ask

| Question | Answer | Where |
|--------------------------------------------|------------------------------------------------------------------------------------------------------------------------|----------------|
| Seven animals per arm. Is that enough? | Not in any one experiment. The case rests on 14 comparisons that all point the same way (85/101 vs 13/101); 12 of the 14 are individually significant by exact log-rank. Study 1 repeats it blinded with 18 per arm. | §2.1 |
| The file has errors. Why believe the result? | Because it does not depend on the disputed entries: the nine comparisons with no flag give 52/63 vs 8/63, and the least favourable reading of every count gives 88/107 vs 19/108. We still do not show the file outside until the audit is closed. | §2.1, §3.1 |
| Is this just a bigger dose of the same agonist? | No. PSLN-212 at 40 µg (14.9-fold *Ifnb1*) stays below PSLN-344 at 10 µg (21.1-fold). Mn raises the ceiling. | §2.2 |
| Could the adjuvant alone be protecting, as an antiviral? | No. Without antigen it protected 0/7; with antigen 6/7. | §4.1 |
| Do we know how it protects? | In part. The steps from Mn to interferon and GM-CSF to monocyte-derived dendritic cells have intervention evidence. The step from CD8 T cells to survival has none yet. Study 2 supplies it. | §4.1 |
| Is it safe? | Too early to say. Weight loss averaged 3.6% and reversed by day 10, and central-nervous-system tissue showed no cholera-toxin-type signal, but there are five animals per group, no pathology and no Mn measurement. Study 4 has a stop rule. | §2.5, §4.3 |
| How does it compare with the enhanced vaccines older adults get now? | Unknown. It has never been tested against them. Studies 1 and 5 include such arms. | §3.2 |
| Will it work in people who have had influenza many times? | The one experiment on this says yes: 6/7 without and 6/7 with a prior infection. | §2.3 |
| How long does protection last? | At least 60 days (14/21 vs 1/21). The apparent fall from day 14 cannot be separated from age-related deaths (4/21 in unchallenged controls). | §2.3 |
| Why not the simpler PSLN-212? | It protects young mice (8/8 in each of three experiments) and fails in aged ones (13/101). | §5 |
| What is the biomarker, and can we use it in the clinic? | The early interferon-β/GM-CSF/monocyte–dendritic-cell response. After a bridging study, as a pharmacodynamic marker for dose selection. Not as a surrogate for protection. | §4.2 |
| What would make us stop? | Failed blinded replication; Mn alone matching PSLN-344; Mn retained in olfactory bulb or brain with pathology; a need for deep-lung delivery that no device can meet safely; no activity with a licensed antigen. | §4.4 |

## Appendix E. Kaplan–Meier curves

![Figure 7](figures/fig7_kaplan_meier.png)

*Figure 7. Survival curves rebuilt from the time-to-event tables for the twelve main experiments.*

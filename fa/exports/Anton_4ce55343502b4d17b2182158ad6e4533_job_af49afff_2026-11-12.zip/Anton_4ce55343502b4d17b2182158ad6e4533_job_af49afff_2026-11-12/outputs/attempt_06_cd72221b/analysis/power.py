import numpy as np
from scipy import stats
def fisher_power(p1,p0,n1,n0,alpha,sims=20000,rng=np.random.default_rng(1)):
    a=rng.binomial(n1,p1,sims); c=rng.binomial(n0,p0,sims)
    cache={}; hit=0
    for x,y in zip(a,c):
        k=(x,y)
        if k not in cache: cache[k]=stats.fisher_exact([[x,n1-x],[y,n0-y]])[1]
        hit+=cache[k]<alpha
    return hit/sims
print('Confirmatory superiority, PSLN-344 vs PSLN-212 (survival), two-sided alpha=0.025 (2 challenge models, Bonferroni):')
for p1,p0 in [(0.70,0.20),(0.60,0.25),(0.80,0.15)]:
    for n in [8,10,12,15,20]:
        print(f'  true {p1:.0%} vs {p0:.0%}  n/group={n:2d}  power={fisher_power(p1,p0,n,n,0.025):.2f}')
print('\nBenchmark comparison (PSLN-344 IN vs squalene-emulsion IM), alpha=0.05, assumed 70% vs 40%:')
for n in [20,30,40,50]:
    print(f'  n/group={n}  power={fisher_power(0.70,0.40,n,n,0.05):.2f}')
# sex-stratified: n per sex per group to see within-sex effect consistency (interaction not powered)
print('\nWithin-sex estimate at n=10/sex/group: 95%% CI half-width for a 70%% vs 20%% difference ~ +/- %.0f pp'%(100*1.96*np.sqrt(.7*.3/10+.2*.8/10)))
# correlate study: AUC precision (Hanley-McNeil) for n events / n non-events
def hm_se(auc,na,nn):
    q1=auc/(2-auc); q2=2*auc**2/(1+auc)
    return np.sqrt((auc*(1-auc)+(na-1)*(q1-auc**2)+(nn-1)*(q2-auc**2))/(na*nn))
print('\nCorrelate study: power to show marker AUC > 0.5 (one-sided 0.025) and CI half-width:')
for auc in [0.70,0.75,0.80]:
    for k in [20,30,40]:
        se=hm_se(auc,k,k); z=(auc-0.5)/se; pw=stats.norm.cdf(z-1.96)
        print(f'  true AUC {auc:.2f}, {k} deaths + {k} survivors: SE={se:.3f}, power={pw:.2f}, 95% CI +/- {1.96*se:.2f}')

from statsmodels.stats.power import TTestIndPower
tt=TTestIndPower()
print('\nContinuous endpoint: lung viral titre (log10 PFU/g), assumed SD 0.6-0.8 log10, two-sided alpha 0.05, power 0.9:')
for diff in [0.5,0.75,1.0]:
    for sd in [0.6,0.8]:
        n=tt.solve_power(effect_size=diff/sd,alpha=0.05,power=0.9)
        print(f'  detect {diff} log10 difference, SD {sd}: n/group = {np.ceil(n):.0f}')

print('\nCurrent design, n=7/group, alpha 0.05:')
for p1,p0 in [(0.85,0.15),(0.80,0.20),(0.70,0.20)]:
    print(f'  true {p1:.0%} vs {p0:.0%}: power {fisher_power(p1,p0,7,7,0.05):.2f}')

#!/usr/bin/env bash
# Re-runs the full PSLN-344 analysis from the raw workbook.
# Inputs : /tmp/world/filesystem/adjuvant_program_dataset.xlsx (+ annotation PDF, read manually)
# Working: /tmp/work (created); outputs written to /tmp/outputs
# Env    : micromamba env "singlecell" (pandas, openpyxl, scipy, statsmodels, matplotlib)
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /tmp/work /tmp/outputs/figures
cp "$HERE"/*.py /tmp/work/
cd /tmp/work
PY="micromamba run -n singlecell python"
$PY extract.py                 # 1. workbook -> tidy per-animal tables with cell provenance
$PY audit_surv.py              # 2. integrity audit: duplicate survival data
$PY audit_bw.py                # 3. body-weight exact matches
$PY audit_bw2.py               # 4. fractional-part / integer-offset analysis
$PY audit_bw3.py               # 5. same-day concentration vs opportunity baseline
$PY audit_bw_vs_surv.py        # 6. weight vs survival reconciliation (rule >=3)
$PY audit_bw_vs_surv2.py       # 7. ... and rule >=2 sensitivity
$PY audit_cont.py              # 8. continuous blocks: derived/duplicated/label checks
$PY audit_n.py                 # 9. stated vs observed n
$PY survival_analysis.py       # 10. per-experiment + pooled survival (tiers T0-T3)
$PY surv_forest_data.py        # 11. Newcombe CIs, survival restoration index
$PY continuous_analysis.py     # 12. immunogenicity contrasts, Holm/BH, restoration index
$PY mech_analysis.py           # 13. mechanistic perturbations, CNS, dose-response
$PY cyto_safety.py             # 14. cytokine profiles, S09-A relabel check, S08-D tolerability
$PY extra_stats.py             # 15. heterogeneity, durability, T4 tier, young, imprinting
$PY power.py                   # 16. design power calculations
$PY figures.py                 # 17. figures 1-6
$PY fig_mechanism.py           # 18. figure 7
$PY build_ledger.py            # 19. evidence ledger (xlsx)
$PY make_tables.py             # 20. report tables (markdown)
echo "done"

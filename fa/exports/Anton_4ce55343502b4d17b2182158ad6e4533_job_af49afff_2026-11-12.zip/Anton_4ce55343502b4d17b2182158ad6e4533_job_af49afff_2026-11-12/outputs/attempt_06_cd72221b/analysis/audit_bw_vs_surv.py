import pandas as pd, numpy as np
B=pd.read_csv('tidy_bodyweight.csv'); S=pd.read_csv('tidy_survival.csv')
def implied(d):
    d=d.sort_values('day'); obs=d[d.value.notna()]
    days=list(obs.day); vals=list(obs.value)
    maxday=d.day.max()
    if days[-1]<maxday: return 'dead (values stop after d%d)'%days[-1], days[-1]
    # frozen tail (LOCF): >=3 identical consecutive values ending at last day
    k=1
    while k<len(vals) and abs(vals[-1-k]-vals[-1])<1e-9: k+=1
    if k>=3: return 'dead (frozen at %.2f from d%d)'%(vals[-1],days[-k]), days[-k]
    return 'alive',None
pairs=[('S15-A','S06-A',{}),('S15-B','S06-B',{}),('S15-C','S06-C',{}),('S15-D','S06-D',{}),('S15-E','S06-E',{}),
       ('S15-F','S06-F',{}),('S15-G','S06-G',{}),('S15-I','S15-H',{}),
       ('S15-J',"S06-E' (imprinting, rows 71-98)",{'Naive+PSLN-212':'Naïve+PSLN-212','Naive+PSLN-344':'Naïve+PSLN-344'}),
       ('S15-K',"S06-F' (imprinting, rows 71-98)",{'Naive+PSLN-212':'Naïve+PSLN-212','Naive+PSLN-344':'Naïve+PSLN-344'}),
       ('S15-M','S15-L',{}),('S15-O','S15-N',{}),('S09-C','S09-B',{'PSLN-212Y':'PSLN-212Y','PSLN-344Y':'PSLN-344Y'}),
       ('S09-E','S09-D',{}),('S09-G','S09-F',{}),('S13-F','S03-I',{}),('S13-G','S03-J',{})]
rows=[]
for bwb,svb,mp in pairs:
    bb=B[B.block==bwb]; ss=S[S.block==svb]
    for g,d in bb.groupby('group',sort=False):
        res=[implied(a) for _,a in d.groupby('animal')]
        n=len(res); alive=sum(r[0]=='alive' for r in res)
        frozen=sum('frozen' in r[0] for r in res)
        gs=mp.get(g,g)
        s=ss[ss.group==gs]
        sv_n=len(s); sv_alive=int((s.event==0).sum()) if sv_n else None
        rows.append(dict(bw_block=bwb,surv_block=svb,group=g,bw_n=n,bw_alive=alive,bw_deaths_by_LOCF=frozen,
                         surv_n=sv_n if sv_n else 'group absent',surv_alive=sv_alive,
                         consistent=(sv_n==n and sv_alive==alive)))
T=pd.DataFrame(rows)
pd.set_option('display.width',250)
print(T.to_string(index=False))
T.to_csv('bw_vs_surv.csv',index=False)
print('\nInconsistent rows:',(~T.consistent).sum(),'of',len(T))

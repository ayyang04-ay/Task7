# PSLN-344 analysis: reproducibility package

Run `bash run_all.sh` (requires the micromamba env `singlecell`). It rebuilds every number, figure and the evidence
ledger from `/tmp/world/filesystem/adjuvant_program_dataset.xlsx`. A clean-room rerun reproduces the ledger exactly.

| Script | Purpose |
|---|---|
| `extract.py` | Explicit cell-coordinate registry for every block. Writes tidy per-animal tables with the source cell of each value (`data/tidy_*.csv`). Group labels are kept as printed |
| `audit_*.py` | Integrity audit: duplicate survival data; body-weight exact matches and fractional-part/integer-offset reuse; weight vs survival reconciliation under two dead-animal rules; derived and label-rotated blocks; stated vs observed n |
| `survival_analysis.py`, `surv_forest_data.py`, `extra_stats.py` | Per-experiment survival (Clopper-Pearson, Fisher, log-rank, Newcombe). Pooled Mantel-Haenszel risk difference and stratified log-rank across sensitivity tiers T0-T4. Heterogeneity; durability; background mortality |
| `continuous_analysis.py` | Group summaries (geometric or arithmetic means); contrasts with Welch CI and exact permutation p; Holm (13 key readouts) and BH; restoration index with bootstrap CI. The only label correction applied (S03-B/F) is explicit in the code |
| `mech_analysis.py`, `cyto_safety.py` | Mechanistic perturbation contrasts, CNS safety, dose-response, cytokine profiles, S09-A relabel check, post-vaccination weights |
| `power.py` | Design power and precision for the proposed studies |
| `figures.py`, `fig_mechanism.py` | Figures 1-7 |
| `build_ledger.py`, `make_tables.py` | Evidence ledger (xlsx) and report tables |

`audit_outputs/` holds the raw audit evidence: exact body-weight matches (`bw_exact_pairs.csv`), fractional-part pairs
(`bw_fraction_pairs.csv`), and weight vs survival reconciliation (`bw_vs_surv*.csv`).

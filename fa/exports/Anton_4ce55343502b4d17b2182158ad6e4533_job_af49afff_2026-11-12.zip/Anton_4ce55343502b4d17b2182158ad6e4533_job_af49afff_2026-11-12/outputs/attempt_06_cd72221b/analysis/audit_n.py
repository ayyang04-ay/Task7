import pandas as pd, re
R=pd.read_csv('tidy_continuous.csv'); S=pd.read_csv('tidy_survival.csv'); B=pd.read_csv('tidy_bodyweight.csv')
# stated n from the annotation PDF (per block), and from the workbook header label
stated={'S01-A 16h':5,'S01-A 72h':5,'S01-B':5,'S01-C':4,'S01-D':5,'S01-E':5,'S01-F':5,'S01-G':5,'S02-A':5,'S02-B':5,'S02-C':5,
'S02-D CD40':5,'S02-D CD86':5,'S02-E':5,'S02-F':5,'S02-G':5,'S02-H':5,'S02-I':5,'S03-A':5,'S03-B':5,'S03-C':5,'S03-D':5,'S03-E':5,
'S03-F':5,'S03-G':5,'S03-H':5,'S03-K':5,'S03-L Aicda':3,'S03-L E47':3,'S04-A ICOSlo':5,'S04-A ICOShi':5,'S04-B Foxp3':5,'S04-B Tfh:Tfr':5,
'S04-C':5,'S04-D':3,'S05-A':3,'S05-B':3,'S05-C':3,'S05-D':5,'S05-E':5,'S05-F':5,'S05-G':5,'S05-H':5,'S05-I':5,'S07-A':3,'S07-B mono':5,
'S07-B Ly6C+Mphi':5,'S07-C':5,'S08-A':3,'S08-B':3,'S08-C':5,'S09-A panel 1 (cols A-U)':3,'S09-A panel 2 (cols X-AS)':3,'S10-A Ifnb1':5,
'S10-A Tnf':5,'S10-A Isg15':5,'S11-A':5,'S11-B':5,'S11-C':5,'S11-D':5,'S11-E':5,'S12-A':3,'S13-A':5,'S13-B':5,'S13-C':5,'S13-D':5,
'S13-H':5,'S13-I':5,'S13-J':5,'S14-A H1N1':5,'S14-A H3N2':5,
'S03-I':7,'S03-J':9,'S06-A':7,'S06-B':7,'S06-C':7,'S06-D':7,'S06-E':7,'S06-F':7,'S06-G':7,"S06-E' (imprinting, rows 71-98)":7,
"S06-F' (imprinting, rows 71-98)":7,'S09-B':8,'S09-D':8,'S09-F':8,'S13-E':5,'S15-H':7,'S15-L':7,'S15-N':7}
rows=[]
for blk,n in stated.items():
    if blk in set(R.block):
        d=R[R.block==blk]
        c=d.groupby(['group','tp'],dropna=False).size()
        obs=sorted(set(c.values))
    else:
        d=S[S.block==blk]; obs=sorted(set(d.groupby('group').size().values))
    if obs!=[n]:
        rows.append((blk,n,obs))
for r in rows: print(f'{r[0]:35s} stated n={r[1]}  observed per-group/timepoint n={r[2]}')

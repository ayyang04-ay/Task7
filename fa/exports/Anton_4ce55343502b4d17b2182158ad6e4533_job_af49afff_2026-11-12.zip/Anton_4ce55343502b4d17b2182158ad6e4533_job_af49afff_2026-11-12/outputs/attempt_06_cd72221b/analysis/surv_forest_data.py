import pandas as pd, numpy as np
from statsmodels.stats.proportion import confint_proportions_2indep
S=pd.read_csv('tidy_survival.csv'); S['group']=S.group.str.replace('Naïve','Naive')
flags={'S03-I':'weights (S13-F) conflict; S13-F has "Naive" not CMP-204','S03-J':'stated n=9 vs 10; 1 day value missing; S13-G groups mismatch',
       'S06-C':'identical to S06-D','S06-D':'identical to S06-C (duplicate)','S06-E':'survivor count conflicts with S15-E',
       'S06-G':'survivor count conflicts with S15-G; untreated 3/7 died','S15-L':'young-arm survivor count conflicts with S15-M',
       'S06-A':'','S06-B':'','S06-F':'','S15-N':''}
rows=[]
for blk,comp in [(b,c) for b in ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-D','S06-E','S06-F','S06-G','S15-L','S15-N'] for c in ['PSLN-212','Sham','PSLN-212(Y)']]+\
    [("S06-E' (imprinting, rows 71-98)",'Naive+PSLN-212'),("S06-F' (imprinting, rows 71-98)",'Naive+PSLN-212'),
     ("S06-E' (imprinting, rows 71-98)",'Imprinting+PSLN-212'),("S06-F' (imprinting, rows 71-98)",'Imprinting+PSLN-212'),('S15-H','3d Vaccine'),('S15-H','3d PSLN-344')]:
    d=S[S.block==blk]
    trt={'Naive+PSLN-212':'Naive+PSLN-344','Imprinting+PSLN-212':'Imprinting+PSLN-344','3d Vaccine':'3d Vaccine+PSLN-344','3d PSLN-344':'3d Vaccine+PSLN-344'}.get(comp,'PSLN-344')
    a=d[d.group==trt]; b=d[d.group==comp]
    if len(a)==0 or len(b)==0: continue
    sa,na=int((a.event==0).sum()),len(a); sb,nb=int((b.event==0).sum()),len(b)
    lo,hi=confint_proportions_2indep(sa,na,sb,nb,method='newcomb',compare='diff')
    rows.append(dict(block=blk,treatment=trt,comparator=comp,surv_trt=f'{sa}/{na}',surv_cmp=f'{sb}/{nb}',rd=100*(sa/na-sb/nb),lo=100*lo,hi=100*hi,flag=flags.get(blk,'')))
F=pd.DataFrame(rows); F.to_csv('surv_forest.csv',index=False)
pd.set_option('display.width',220); print(F.to_string(index=False,float_format=lambda x:f'{x:.0f}'))
# survival restoration by setting (aged PSLN-344 vs aged PSLN-212 vs young PSLN-212(Y))
sets={'homologous d14 (S03-I)':['S03-I'],'heterosubtypic d14 (S06-A,S06-C)':['S06-A','S06-C'],'heterosubtypic d3 (S06-B)':['S06-B'],
      'heterosubtypic d60 (S06-E,F,G)':['S06-E','S06-F','S06-G'],'other strains (S15-L C57BL/6, S15-N SW)':['S15-L','S15-N']}
print()
for k,bl in sets.items():
    d=S[S.block.isin(bl)]
    f=lambda g:(int((d[d.group==g].event==0).sum()),int((d.group==g).sum()))
    s344,s212,sy,ssh=f('PSLN-344'),f('PSLN-212'),f('PSLN-212(Y)'),f('Sham')
    p=lambda t:t[0]/t[1]
    ri=(p(s344)-p(s212))/(p(sy)-p(s212))
    print(f'{k:45s} Sham {ssh[0]}/{ssh[1]}  PSLN-212 {s212[0]}/{s212[1]}  PSLN-344 {s344[0]}/{s344[1]}  young {sy[0]}/{sy[1]}  survival RI={ri:.2f}')
U=S[(S.group=='Untreated')]; P=S[S.block.isin(['S06-E','S06-F','S06-G'])&(S.group=='PSLN-344')]
from scipy.stats import fisher_exact
print('\nd60 experiments: PSLN-344 survivors %d/%d vs untreated-unchallenged survivors %d/%d, Fisher p=%.2f'%((P.event==0).sum(),len(P),(U.event==0).sum(),len(U),fisher_exact([[(P.event==0).sum(),P.event.sum()],[(U.event==0).sum(),U.event.sum()]])[1]))

"""
Extract every block of adjuvant_program_dataset.xlsx into tidy per-animal records,
keeping the source cell coordinate of every value (provenance for the evidence ledger).

Block coordinates were read manually from the workbook and cross-checked against
adjuvant_program_annotation.pdf. Group labels are kept AS PRINTED; corrections
(e.g. S03-B/F label rotation) are applied downstream and documented, never here.
"""
import openpyxl, json, re
import pandas as pd
from openpyxl.utils import column_index_from_string as ci, get_column_letter as gl

WB = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
wb = openpyxl.load_workbook(WB, data_only=True)

recs = []      # continuous per-animal values
surv = []      # time-to-event rows
bw = []        # body weight rows


def v(ws, r, c):
    return ws.cell(row=r, column=c).value


def cols(a, b):
    return list(range(ci(a), ci(b) + 1))


def add(sheet, block, group, value, r, c, tp=None, analyte=None, extra=None):
    if value is None:
        return
    d = dict(sheet=sheet, block=block, group=group, tp=tp, analyte=analyte,
             value=float(value), cell=f"{sheet}!{gl(c)}{r}")
    if extra:
        d.update(extra)
    recs.append(d)


# ---------- generic readers ----------
def groups_in_rows(sheet, block, rows, label_col, val_cols, tp=None, analyte=None):
    ws = wb[sheet]
    for r in rows:
        g = str(v(ws, r, ci(label_col))).strip()
        for k, c in enumerate(cols(*val_cols)):
            add(sheet, block, g, v(ws, r, c), r, c, tp, analyte, dict(animal=k + 1))


def groups_in_cols(sheet, block, header_row, gcols, rows, tp=None, analyte=None, labels=None):
    ws = wb[sheet]
    for j, c in enumerate(cols(*gcols)):
        g = labels[j] if labels else str(v(ws, header_row, c)).strip()
        for k, r in enumerate(rows):
            add(sheet, block, g, v(ws, r, c), r, c, tp, analyte, dict(animal=k + 1))


def time_by_group_spans(sheet, block, rows, tp_col, spans, tp_override=None):
    """rows = timepoint rows; spans = list of (group, first_col, last_col)"""
    ws = wb[sheet]
    for i, r in enumerate(rows):
        tp = tp_override[i] if tp_override else v(ws, r, ci(tp_col))
        for g, a, b in spans:
            for k, c in enumerate(cols(a, b)):
                add(sheet, block, g, v(ws, r, c), r, c, tp, None, dict(animal=k + 1))


def survival(sheet, block, rows, day_col, gcols, labels=None, header_row=None):
    ws = wb[sheet]
    for c_i, c in enumerate(cols(*gcols)):
        g = labels[c_i] if labels else str(v(ws, header_row, c)).strip()
        k = 0
        for r in rows:
            ev = v(ws, r, c)
            if ev is None:
                continue
            k += 1
            day = v(ws, r, ci(day_col))
            surv.append(dict(sheet=sheet, block=block, group=g, animal=k,
                             time=(None if day is None else float(day)), event=int(ev),
                             cell_event=f"{sheet}!{gl(c)}{r}", cell_time=f"{sheet}!{day_col}{r}"))


def bodyweight(sheet, block, rows, day_col, spans):
    ws = wb[sheet]
    for r in rows:
        day = v(ws, r, ci(day_col))
        for g, a, b in spans:
            for k, c in enumerate(cols(a, b)):
                val = v(ws, r, c)
                bw.append(dict(sheet=sheet, block=block, group=g, animal=k + 1, day=day,
                               value=(None if val is None else float(val)), cell=f"{sheet}!{gl(c)}{r}"))


# ================= S01 =================
S01A_groups = None
groups_in_rows('S01', 'S01-A 16h', range(3, 11), 'A', ('B', 'F'), tp='16h', analyte='Ifnb1')
groups_in_rows('S01', 'S01-A 72h', range(3, 11), 'G', ('H', 'L'), tp='72h', analyte='Ifnb1')
groups_in_rows('S01', 'S01-B', range(14, 18), 'A', ('B', 'F'), tp='16h')
groups_in_rows('S01', 'S01-C', range(20, 22), 'A', ('B', 'E'), tp='16h')
sp4 = [('Sham', 'B', 'F'), ('PSLN-212', 'G', 'K'), ('PSLN-344', 'L', 'P'), ('PSLN-212(Y)', 'Q', 'U')]
sp5 = sp4 + [('PSLN-344(Y)', 'V', 'Z')]
time_by_group_spans('S01', 'S01-D', range(24, 29), 'A', sp4)
time_by_group_spans('S01', 'S01-E', range(30, 35), 'A', sp5)
time_by_group_spans('S01', 'S01-F', [36], 'A', sp5, tp_override=['72h'])
time_by_group_spans('S01', 'S01-G', [38], 'A', sp5, tp_override=['72h'])

# ================= S02 =================
groups_in_cols('S02', 'S02-A', 2, ('A', 'D'), range(3, 8), tp='72h')
groups_in_cols('S02', 'S02-B', 2, ('F', 'I'), range(3, 8), tp='72h')
groups_in_cols('S02', 'S02-C', 2, ('K', 'O'), range(3, 8), tp='36h')
groups_in_cols('S02', 'S02-D CD40', 9, ('A', 'D'), range(10, 15), tp='d3')
groups_in_cols('S02', 'S02-D CD86', 9, ('F', 'I'), range(10, 15), tp='d3')
groups_in_cols('S02', 'S02-E', 9, ('K', 'O'), range(10, 15), tp='72h+3d coculture')
time_by_group_spans('S02', 'S02-F', range(17, 20), 'A',
                    [('PSLN-344', 'B', 'F'), ('PSLN-212', 'G', 'K'), ('Sham', 'L', 'P')])
groups_in_cols('S02', 'S02-G', 21, ('B', 'D'), range(22, 27), tp='d5')
groups_in_cols('S02', 'S02-H', 29, ('B', 'F'), range(30, 35), tp='d3')
groups_in_cols('S02', 'S02-I', 29, ('H', 'I'), range(30, 35), tp='d5')

# ================= S03 =================
for blk, hdr, gc, rows, tp in [('S03-A', 2, ('A', 'E'), range(3, 8), 'd14'), ('S03-B', 2, ('G', 'I'), range(3, 8), 'd14'),
                               ('S03-C', 2, ('K', 'O'), range(3, 8), 'd14'), ('S03-D', 2, ('Q', 'U'), range(3, 8), 'd14'),
                               ('S03-E', 9, ('A', 'E'), range(10, 15), 'd14'), ('S03-F', 9, ('G', 'I'), range(10, 15), 'd14'),
                               ('S03-G', 9, ('K', 'O'), range(10, 15), 'd14'), ('S03-H', 9, ('Q', 'U'), range(10, 15), 'd14')]:
    groups_in_cols('S03', blk, hdr, gc, rows, tp=tp)
survival('S03', 'S03-I', range(17, 52), 'A', ('B', 'F'), header_row=16)
survival('S03', 'S03-J', range(17, 47), 'G', ('H', 'J'), header_row=16)
groups_in_cols('S03', 'S03-K', 16, ('L', 'O'), range(17, 22), tp='d7')
groups_in_rows('S03', 'S03-L Aicda', range(26, 29), 'K', ('L', 'N'), tp='d5', analyte='Aicda')
groups_in_rows('S03', 'S03-L E47', range(26, 29), 'K', ('O', 'Q'), tp='d5', analyte='E47')

# ================= S04 =================
groups_in_rows('S04', 'S04-A ICOSlo', range(2, 6), 'A', ('B', 'F'), tp='d7', analyte='ICOS-low Tfh')
groups_in_rows('S04', 'S04-A ICOShi', range(2, 6), 'A', ('G', 'K'), tp='d7', analyte='ICOS-high Tfh')
groups_in_cols('S04', 'S04-B Foxp3', 7, ('A', 'D'), range(8, 13), tp='d7')
groups_in_cols('S04', 'S04-B Tfh:Tfr', 14, ('A', 'D'), range(15, 20), tp='d7')
groups_in_cols('S04', 'S04-C', 21, ('A', 'D'), range(22, 27), tp='d30')
groups_in_cols('S04', 'S04-D', 28, ('A', 'D'), range(29, 32), tp='d7')

# ================= S05 =================
sp3 = [('PSLN-212', 'B', 'C'), ('PSLN-344', 'E', 'F'), ('PSLN-212Y', 'H', 'I')]
time_by_group_spans('S05', 'S05-A', range(3, 6), 'A', sp3)
time_by_group_spans('S05', 'S05-B', range(8, 11), 'A', sp3)
groups_in_cols('S05', 'S05-C', 12, ('A', 'D'), range(13, 16), tp='d4')
for blk, hdr, tp in [('S05-D', 18, 'd3'), ('S05-E', 25, 'd3'), ('S05-F', 32, 'd14'), ('S05-G', 39, 'd60'),
                     ('S05-H', 46, 'd60'), ('S05-I', 53, 'd25')]:
    groups_in_cols('S05', blk, hdr, ('A', 'D'), range(hdr + 1, hdr + 6), tp=tp)

# ================= S06 (survival) =================
survival('S06', 'S06-A', range(3, 31), 'A', ('B', 'E'), header_row=2)
survival('S06', 'S06-B', range(3, 31), 'G', ('H', 'K'), header_row=2)
survival('S06', 'S06-C', range(3, 31), 'M', ('N', 'Q'), header_row=2)
survival('S06', 'S06-D', range(34, 69), 'A', ('B', 'E'), header_row=33)
survival('S06', 'S06-E', range(34, 69), 'G', ('H', 'L'), header_row=33)
survival('S06', 'S06-F', range(34, 69), 'M', ('N', 'R'), header_row=33)
survival('S06', 'S06-G', range(71, 106), 'A', ('B', 'F'), header_row=70)
survival('S06', "S06-E' (imprinting, rows 71-98)", range(71, 106), 'G', ('H', 'K'), header_row=70)
survival('S06', "S06-F' (imprinting, rows 71-98)", range(71, 106), 'M', ('N', 'Q'), header_row=70)

# ================= S07 =================
time_by_group_spans('S07', 'S07-A', range(3, 8), 'A', [('PSLN-212', 'B', 'D'), ('PSLN-344', 'E', 'G')])
groups_in_cols('S07', 'S07-B mono', 9, ('B', 'C'), range(10, 15), tp='unstated')
groups_in_cols('S07', 'S07-B Ly6C+Mphi', 9, ('E', 'F'), range(10, 15), tp='unstated')
groups_in_cols('S07', 'S07-C', 15, ('B', 'C'), range(16, 21), tp='d4 post-transfer',
               labels=['col B "Ly6C-CD206+ MPhi"', 'col C "Ly6C-CD206+ MPhi"'])

# ================= S08 =================
time_by_group_spans('S08', 'S08-A', range(3, 8), 'A',
                    [('CMP-204', 'B', 'D'), ('PSLN-212', 'E', 'G'), ('PSLN-344', 'H', 'J'), ('PSLN-344/R848', 'K', 'M')])
ws = wb['S08']
for g, a, b in [('CMP-204', 'A', 'C'), ('PSLN-212', 'D', 'F'), ('PSLN-R848', 'G', 'I'), ('PSLN-212/R848', 'J', 'L'),
                ('PSLN-344', 'M', 'O')]:
    for k, c in enumerate(cols(a, b)):
        add('S08', 'S08-B', g, v(ws, 11, c), 11, c, None, None, dict(animal=k + 1))
groups_in_cols('S08', 'S08-C', 13, ('A', 'D'), range(14, 19), tp='16h')
bodyweight('S08', 'S08-D', range(21, 27), 'A',
           [('PSLN-212(Y)', 'B', 'F'), ('CMP-204', 'G', 'K'), ('PSLN-212', 'L', 'P'), ('PSLN-344', 'Q', 'U'),
            ('PSLN-212/R848', 'V', 'Z'), ('Vaccine', 'AA', 'AE')])

# ================= S09 =================
ws = wb['S09']
p1 = [('PBS', 'B', 'D'), ('CMP-204', 'E', 'G'), ('PSLN-212', 'H', 'J'), ('PSLN-R848', 'K', 'M'), ('PSLN-212/R848', 'N', 'P'),
      ('PSLN-344', 'Q', 'S'), ('PSLN-212(y)', 'T', 'V')]
p2 = [('PBS', 'Y', 'AA'), ('CMP-204', 'AB', 'AD'), ('PSLN-212', 'AE', 'AG'), ('PSLN-R848', 'AH', 'AJ'),
      ('PSLN-212/R848', 'AK', 'AM'), ('PSLN-344', 'AN', 'AP'), ('PSLN-212(y)', 'AQ', 'AS')]
for blk, spans, acol in [('S09-A panel 1 (cols A-U)', p1, 'A'), ('S09-A panel 2 (cols X-AS)', p2, 'X')]:
    for r in range(3, 10):
        an = v(ws, r, ci(acol))
        for g, a, b in spans:
            for k, c in enumerate(cols(a, b)):
                add('S09', blk, g, v(ws, r, c), r, c, 'label says 16h', an, dict(animal=k + 1, scale='log10'))
survival('S09', 'S09-B', range(12, 36), 'A', ('B', 'D'), header_row=11)
bodyweight('S09', 'S09-C', range(12, 20), 'F', [('PSLN-212Y', 'G', 'N'), ('Sham', 'O', 'V'), ('PSLN-344Y', 'W', 'AD')])
survival('S09', 'S09-D', range(39, 63), 'A', ('B', 'D'), header_row=38)
bodyweight('S09', 'S09-E', range(39, 47), 'F', [('PSLN-212Y', 'G', 'N'), ('Sham', 'O', 'V'), ('PSLN-344Y', 'W', 'AD')])
survival('S09', 'S09-F', range(66, 89), 'A', ('B', 'D'), header_row=65)
bodyweight('S09', 'S09-G', range(66, 74), 'F', [('PSLN-212Y', 'G', 'N'), ('Sham', 'O', 'V'), ('PSLN-344Y', 'W', 'AD')])

# ================= S10 =================
for an, a, b in [('Ifnb1', 'A', 'D'), ('Tnf', 'F', 'I'), ('Isg15', 'K', 'N')]:
    groups_in_cols('S10', 'S10-A ' + an, 2, (a, b), range(3, 8), tp='36h', analyte=an)

# ================= S11 =================
sp11 = [('Vaccine', 'B', 'F'), ('PSLN-212', 'G', 'K'), ('PSLN-344', 'L', 'P'), ('PSLN-212(Y)', 'Q', 'U')]
time_by_group_spans('S11', 'S11-A', range(3, 8), 'A', sp11)
time_by_group_spans('S11', 'S11-B', range(10, 15), 'A', sp11)
groups_in_cols('S11', 'S11-C', 16, ('A', 'B'), range(17, 22), tp='d3')
time_by_group_spans('S11', 'S11-D', range(24, 29), 'A', sp11)
groups_in_cols('S11', 'S11-E', 30, ('A', 'D'), range(31, 36), tp='unstated')

# ================= S12 =================
groups_in_cols('S12', 'S12-A', 2, ('A', 'B'), range(3, 6), tp='d3')

# ================= S13 =================
for blk, gc in [('S13-A', ('A', 'C')), ('S13-B', ('E', 'G')), ('S13-C', ('I', 'K')), ('S13-D', ('M', 'O'))]:
    groups_in_cols('S13', blk, 2, gc, range(3, 8), tp='d14')
survival('S13', 'S13-E', range(3, 31), 'R', ('S', 'V'), header_row=2)
bodyweight('S13', 'S13-F', range(33, 41), 'A',
           [('PSLN-212(Y)', 'B', 'H'), ('Sham', 'I', 'O'), ('PSLN-212', 'P', 'V'), ('PSLN-344', 'W', 'AC'), ('Naive', 'AD', 'AJ')])
bodyweight('S13', 'S13-G', range(43, 51), 'A', [('PSLN-344', 'B', 'K'), ('Sham', 'L', 'U'), ('Naive', 'V', 'AE')])
groups_in_cols('S13', 'S13-H', 52, ('A', 'D'), range(53, 58), tp='unstated')
groups_in_cols('S13', 'S13-I', 52, ('F', 'J'), range(53, 58), tp='d28 (boost d14)')
groups_in_cols('S13', 'S13-J', 52, ('L', 'P'), range(53, 58), tp='d28 (boost d14)')

# ================= S14 =================
groups_in_cols('S14', 'S14-A H1N1', 2, ('A', 'D'), range(3, 8), tp='unstated')
groups_in_cols('S14', 'S14-A H3N2', 2, ('F', 'I'), range(3, 8), tp='unstated')

# ================= S15 =================
sp15 = [('PSLN-212(Y)', 'B', 'H'), ('Sham', 'I', 'O'), ('PSLN-212', 'P', 'V'), ('PSLN-344', 'W', 'AC')]
sp15u = sp15 + [('Untreated', 'AD', 'AJ')]
bodyweight('S15', 'S15-A', range(3, 11), 'A', sp15)
bodyweight('S15', 'S15-B', range(13, 21), 'A', sp15)
bodyweight('S15', 'S15-C', range(23, 31), 'A', sp15)
bodyweight('S15', 'S15-D', range(33, 41), 'A', sp15)
bodyweight('S15', 'S15-E', range(43, 51), 'A', sp15u)
bodyweight('S15', 'S15-F', range(53, 61), 'A', sp15u)
bodyweight('S15', 'S15-G', range(63, 71), 'A', sp15u)
survival('S15', 'S15-H', range(73, 94), 'A', ('B', 'D'), header_row=72)
bodyweight('S15', 'S15-I', range(72, 80), 'H',
           [('3d Vaccine', 'I', 'O'), ('3d PSLN-344', 'P', 'V'), ('3d Vaccine+PSLN-344', 'W', 'AC')])
spJ = [('Naive+PSLN-212', 'I', 'O'), ('Imprinting+PSLN-212', 'P', 'V'), ('Naive+PSLN-344', 'W', 'AC'),
       ('Imprinting+PSLN-344', 'AD', 'AJ')]
bodyweight('S15', 'S15-J', range(83, 91), 'H', spJ)
bodyweight('S15', 'S15-K', range(93, 101), 'H', spJ)
survival('S15', 'S15-L', range(103, 131), 'A', ('B', 'E'), header_row=102)
bodyweight('S15', 'S15-M', range(103, 111), 'H',
           [('PSLN-212(Y)', 'I', 'O'), ('Sham', 'P', 'V'), ('PSLN-212', 'W', 'AC'), ('PSLN-344', 'AD', 'AJ')])
survival('S15', 'S15-N', range(134, 162), 'A', ('B', 'E'), header_row=133)
bodyweight('S15', 'S15-O', range(134, 142), 'H',
           [('PSLN-212(Y)', 'I', 'O'), ('Sham', 'P', 'V'), ('PSLN-212', 'W', 'AC'), ('PSLN-344', 'AD', 'AJ')])

# Orphan region S08 rows 89-101 (no label) - recorded for the audit only
ws = wb['S08']
orphan = [dict(cell=f"S08!{gl(c)}{r}", value=v(ws, r, c)) for r in range(89, 102) for c in range(1, 5) if v(ws, r, c) is not None]

R = pd.DataFrame(recs)
S = pd.DataFrame(surv)
B = pd.DataFrame(bw)
R.to_csv('/tmp/work/tidy_continuous.csv', index=False)
S.to_csv('/tmp/work/tidy_survival.csv', index=False)
B.to_csv('/tmp/work/tidy_bodyweight.csv', index=False)
json.dump(orphan, open('/tmp/work/orphan_S08.json', 'w'), indent=1, default=str)
print('continuous records', len(R), 'blocks', R.block.nunique())
print('survival records', len(S), 'blocks', S.block.nunique())
print('bodyweight records', len(B), 'blocks', B.block.nunique())
print(S.groupby(['block', 'group'], sort=False).agg(n=('event', 'size'), deaths=('event', 'sum')).to_string())

import pandas as pd, numpy as np, itertools, collections, random
B = pd.read_csv('tidy_bodyweight.csv'); B=B[B.value.notna()]
B['traj']=B.block+' | '+B.group+' #'+B.animal.astype(str)
X=B[B.day!=0].copy()
# ---- null model for same-day exact matches: compare trajectories after shifting day labels (different-day positions)
def count_pairs(X, shift=False):
    T={t:dict(zip(d.day,d.value.round(6))) for t,d in X.groupby('traj')}
    keys=list(T); cnt=collections.Counter()
    for a,b in itertools.combinations(keys,2):
        da,db=T[a],T[b]
        if shift:
            days=sorted(set(da)); m=0
            for d in days:
                # compare a at day d with b at day d+2 (off-position null)
                if (d+2) in db and da[d]==db[d+2]: m+=1
        else:
            m=sum(1 for d in da if d in db and da[d]==db[d])
        cnt[m]+=1
    return cnt
obs=count_pairs(X); null=count_pairs(X,shift=True)
print('pairs by # same-day exact matches (observed):', sorted(obs.items()))
print('pairs by # exact matches at OFFSET days (null):', sorted(null.items()))

# ---- fractional-part / integer-offset analysis for long-decimal values
def ndec(x):
    s=repr(float(x))
    return len(s.split('.')[1]) if '.' in s else 0
L=X[X.value.map(ndec)>=4].copy()
L['frac']=(L.value-np.floor(L.value)).round(5)
L['ipart']=np.floor(L.value).astype(int)
hits=[]
for f,d in L.groupby('frac'):
    if len(d)<2: continue
    for (i,a),(j,b) in itertools.combinations(d.iterrows(),2):
        if a.traj!=b.traj:
            hits.append(dict(frac=f,v1=a.value,v2=b.value,offset=round(b.value-a.value,6),day1=a.day,day2=b.day,
                             cell1=a.cell,cell2=b.cell,traj1=a.traj,traj2=b.traj))
H=pd.DataFrame(hits)
print('\nlong-decimal cells:',len(L),' pairs sharing fractional part (5 dp) in different trajectories:',len(H))
print(' of which exact equal values:',(H.offset==0).sum(),' integer-offset (non-zero):',((H.offset!=0)&((H.offset-H.offset.round()).abs()<1e-6)).sum())
H.to_csv('bw_fraction_pairs.csv',index=False)
pd.set_option('display.width',250)
print(H[H.offset!=0].sort_values(['frac'])[['v1','v2','offset','day1','day2','cell1','cell2','traj1','traj2']].to_string(index=False))

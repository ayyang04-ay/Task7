"""
Continuous readouts: group summaries + pre-specified contrasts.
Scale: titres / qPCR fold-changes / ratios -> log10 (geometric means, ratio estimates);
percentages -> linear (difference in means). Tests: Welch t (CI) + exact permutation test
on the mean difference (all C(n1+n2,n1) relabelings). Holm within the pre-specified key family;
BH-FDR across everything. Restoration index RI = (344 - 212)/(212Y - 212) on analysis scale.
"""
import pandas as pd, numpy as np, itertools, warnings
from scipy import stats
from statsmodels.stats.multitest import multipletests
warnings.filterwarnings('ignore')
rng = np.random.default_rng(20260915)

R = pd.read_csv('/tmp/work/tidy_continuous.csv')

# ---- label corrections documented in the audit (applied ONLY here, explicitly) ----
# S03-B / S03-F: printed labels are rotated relative to the S13 subclass titres they were computed from
# (S03-B "PSLN-344" == S13 PSLN-212 quotient, etc.). S13 labels are consistent with total IgG (S03-A/E),
# so S13 labels are taken as correct.
rot = {'PSLN-212': 'PSLN-212(Y)', 'PSLN-344': 'PSLN-212', 'PSLN-212(Y)': 'PSLN-344'}
m = R.block.isin(['S03-B', 'S03-F'])
R.loc[m, 'group_corrected'] = R.loc[m, 'group'].map(rot)
R['group_used'] = R.group_corrected.fillna(R.group)

# HAI values of 0 = below the lowest dilution tested (1:10) -> impute 5 (half the LOD) for GMT
hai = R.block.isin(['S03-C', 'S03-G']) & (R.value == 0)
R.loc[hai, 'value'] = 5.0
R.loc[hai, 'imputed'] = 'HAI <1:10 set to 5'

READOUTS = [
 # block, name, scale, tp filter, analyte filter, family ('key' = primary family for Holm)
 ('S01-A 16h', 'Lung Ifnb1 16 h (fold vs untreated)', 'log', None, None, 'key'),
 ('S01-A 72h', 'Lung Ifnb1 72 h (fold)', 'log', None, None, 'supp'),
 ('S02-F', 'Lung Gm-csf 16 h (fold)', 'log', '16h', None, 'supp'),
 ('S02-F', 'Lung Gm-csf 36 h (fold)', 'log', '36h', None, 'supp'),
 ('S02-F', 'Lung Gm-csf 72 h (fold)', 'log', '72h', None, 'supp'),
 ('S01-F', 'Lung cDC1 % (72 h)', 'lin', None, None, 'supp'),
 ('S01-G', 'Lung cDC2 % (72 h)', 'lin', None, None, 'supp'),
 ('S02-A', 'Lung CCR7+ migratory CD11b+ DC % (72 h)', 'lin', None, None, 'key'),
 ('S02-B', 'MLN CD11b+CD103- DC % (72 h)', 'lin', None, None, 'supp'),
 ('S02-C', 'MLN AF647-OVA+ DC % (36 h)', 'lin', None, None, 'supp'),
 ('S02-D CD40', 'MLN CD11b+ DC CD40+ % (d3)', 'lin', None, None, 'supp'),
 ('S02-D CD86', 'MLN CD11b+ DC CD86+ % (d3)', 'lin', None, None, 'supp'),
 ('S02-E', 'OT-I priming by sorted MLN DC, % divided', 'lin', None, None, 'supp'),
 ('S03-A', 'Serum IgG anti-CA09 d14 (titre)', 'log', None, None, 'key'),
 ('S03-C', 'HAI anti-CA09 d14 (titre)', 'log', None, None, 'key'),
 ('S03-D', 'Neutralising Ab anti-CA09 d14 (titre)', 'log', None, None, 'key'),
 ('S03-E', 'Serum IgG anti-Aichi H3N2 d14 (titre)', 'log', None, None, 'key'),
 ('S03-G', 'HAI anti-Aichi d14 (titre)', 'log', None, None, 'key'),
 ('S03-H', 'Neutralising Ab anti-Aichi d14 (titre)', 'log', None, None, 'key'),
 ('S03-B', 'IgG2a/IgG1 anti-CA09 (labels corrected per S13)', 'log', None, None, 'supp'),
 ('S03-F', 'IgG2a/IgG1 anti-Aichi (labels corrected per S13)', 'log', None, None, 'supp'),
 ('S13-A', 'IgG2a anti-CA09 d14 (titre)', 'log', None, None, 'supp'),
 ('S13-B', 'IgG1 anti-CA09 d14 (titre)', 'log', None, None, 'supp'),
 ('S13-C', 'IgG2a anti-Aichi d14 (titre)', 'log', None, None, 'supp'),
 ('S13-D', 'IgG1 anti-Aichi d14 (titre)', 'log', None, None, 'supp'),
 ('S13-I', 'Serum IgG anti-CA09 d28 post-boost (titre)', 'log', None, None, 'supp'),
 ('S13-J', 'Serum IgG anti-Aichi d28 post-boost (titre)', 'log', None, None, 'supp'),
 ('S13-H', 'MLN IgG+ of B220+ % (time not stated)', 'lin', None, None, 'supp'),
 ('S03-K', 'MLN germinal-centre B % (d7)', 'lin', None, None, 'key'),
 ('S03-L Aicda', 'MLN B-cell Aicda (fold, d5)', 'log', None, None, 'supp'),
 ('S03-L E47', 'MLN B-cell E47 (fold, d5)', 'log', None, None, 'supp'),
 ('S04-A ICOShi', 'MLN ICOS-high Tfh % (d7)', 'lin', None, None, 'key'),
 ('S04-A ICOSlo', 'MLN ICOS-low Tfh % (d7)', 'lin', None, None, 'supp'),
 ('S04-B Foxp3', 'MLN Tfr (Foxp3+ of CXCR5+ICOShi) % (d7)', 'lin', None, None, 'supp'),
 ('S04-C', 'MLN Tfr % (d30)', 'lin', None, None, 'supp'),
 ('S04-D', 'Lung Treg % (d7)', 'lin', None, None, 'supp'),
 ('S05-D', 'Lung Ki-67+ CD8 % (d3)', 'lin', None, None, 'supp'),
 ('S05-E', 'Lung GZMB+ CD8 % (d3)', 'lin', None, None, 'supp'),
 ('S05-F', 'MLN IFN-g+ CD8, H5N1 restim, % (d14)', 'lin', None, None, 'key'),
 ('S05-G', 'MLN IFN-g+ CD8, H5N1 restim, % (d60)', 'lin', None, None, 'key'),
 ('S05-H', 'MLN GZMB+ CD8 % (d60)', 'lin', None, None, 'supp'),
 ('S05-I', 'Lung CD69+CD103+ TRM CD8 % (d25)', 'lin', None, None, 'key'),
 ('S14-A H1N1', 'MLN IFN-g+ CD8, CA09 restim, % (time n.s.)', 'lin', None, None, 'supp'),
 ('S14-A H3N2', 'MLN IFN-g+ CD8, Aichi restim, % (time n.s.)', 'lin', None, None, 'supp'),
 ('S11-E', 'Lung CD206+ macrophages % (time n.s.)', 'lin', None, None, 'supp'),
 ('S11-D', 'Lung NK % (d4)', 'lin', '4', None, 'supp'),
]

ARMS = ['Sham', 'Vaccine', 'PBS', 'CMP-204', 'PSLN-R848', 'PSLN-212/R848', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']


def tr(x, scale):
    return np.log10(x) if scale == 'log' else x


def perm_p(a, b):
    """exact two-sided permutation p for difference in means"""
    a = np.asarray(a); b = np.asarray(b); pool = np.r_[a, b]; n1 = len(a)
    obs = abs(a.mean() - b.mean()); cnt = 0; tot = 0
    for idx in itertools.combinations(range(len(pool)), n1):
        m = np.zeros(len(pool), bool); m[list(idx)] = True
        d = abs(pool[m].mean() - pool[~m].mean()); tot += 1
        cnt += d >= obs - 1e-12
    return cnt / tot


def welch(a, b):
    a = np.asarray(a); b = np.asarray(b)
    d = a.mean() - b.mean()
    va, vb = a.var(ddof=1) / len(a), b.var(ddof=1) / len(b)
    se = np.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(a) - 1) + vb ** 2 / (len(b) - 1)) if se > 0 else np.inf
    tcrit = stats.t.ppf(0.975, df)
    p = 2 * stats.t.sf(abs(d / se), df) if se > 0 else 0.0
    return d, d - tcrit * se, d + tcrit * se, p


def boot_ri(a344, a212, a212y, B=10000):
    out = []
    for _ in range(B):
        x = rng.choice(a344, len(a344)).mean(); y = rng.choice(a212, len(a212)).mean(); z = rng.choice(a212y, len(a212y)).mean()
        if abs(z - y) > 1e-9:
            out.append((x - y) / (z - y))
    return np.percentile(out, [2.5, 97.5])


summ = []; cons = []
for blk, name, scale, tpf, anf, fam in READOUTS:
    d = R[R.block == blk]
    if tpf is not None:
        d = d[d.tp.astype(str) == tpf]
    groups = {g: x.value.values for g, x in d.groupby('group_used')}
    cells = {g: f"{x.cell.iloc[0]}:{x.cell.iloc[-1].split('!')[1]}" for g, x in d.groupby('group_used')}
    for g in [a for a in ARMS if a in groups] + [a for a in groups if a not in ARMS]:
        v = groups[g]; t = tr(v, scale)
        row = dict(block=blk, readout=name, scale=scale, group=g, n=len(v), cells=cells[g],
                   mean=v.mean(), sd=v.std(ddof=1), median=np.median(v), min=v.min(), max=v.max())
        if scale == 'log':
            gm = 10 ** t.mean(); lo, hi = 10 ** (t.mean() + np.array([-1, 1]) * stats.t.ppf(.975, len(t) - 1) * t.std(ddof=1) / np.sqrt(len(t)))
            row.update(geo_mean=gm, gm_ci_lo=lo, gm_ci_hi=hi)
        summ.append(row)
    for a, b in [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212(Y)'), ('PSLN-212', 'PSLN-212(Y)'),
                 ('PSLN-344', 'CMP-204'), ('PSLN-344', 'Vaccine'), ('PSLN-344(Y)', 'PSLN-212(Y)')]:
        if a in groups and b in groups:
            ta, tb = tr(groups[a], scale), tr(groups[b], scale)
            dd, lo, hi, pw = welch(ta, tb)
            pp = perm_p(ta, tb)
            row = dict(block=blk, readout=name, scale=scale, family=fam, contrast=f'{a} vs {b}', n_a=len(ta), n_b=len(tb),
                       welch_p=pw, perm_p=pp)
            if scale == 'log':
                row.update(effect='ratio of geometric means', estimate=10 ** dd, ci_lo=10 ** lo, ci_hi=10 ** hi)
            else:
                row.update(effect='difference in means (percentage points)', estimate=dd, ci_lo=lo, ci_hi=hi)
            if (a, b) == ('PSLN-344', 'PSLN-212') and 'PSLN-212(Y)' in groups:
                y = tr(groups['PSLN-212(Y)'], scale)
                ri = (ta.mean() - tb.mean()) / (y.mean() - tb.mean())
                blo, bhi = boot_ri(ta, tb, y)
                row.update(restoration_index=ri, RI_boot_lo=blo, RI_boot_hi=bhi)
            cons.append(row)

SU = pd.DataFrame(summ); CO = pd.DataFrame(cons)
# multiplicity: Holm within the key family for the primary contrast (PSLN-344 vs PSLN-212), BH across all contrasts
key = (CO.family == 'key') & (CO.contrast == 'PSLN-344 vs PSLN-212')
CO.loc[key, 'holm_p_key_family'] = multipletests(CO.loc[key, 'welch_p'], method='holm')[1]
CO['bh_q_all'] = multipletests(CO.welch_p, method='fdr_bh')[1]
SU.to_csv('/tmp/work/cont_summary.csv', index=False); CO.to_csv('/tmp/work/cont_contrasts.csv', index=False)
pd.set_option('display.width', 260); pd.set_option('display.max_colwidth', 48)
k = CO[CO.contrast == 'PSLN-344 vs PSLN-212'][['readout', 'family', 'estimate', 'ci_lo', 'ci_hi', 'welch_p', 'perm_p', 'holm_p_key_family', 'restoration_index', 'RI_boot_lo', 'RI_boot_hi']]
print(k.to_string(index=False, float_format=lambda x: f'{x:.3g}'))

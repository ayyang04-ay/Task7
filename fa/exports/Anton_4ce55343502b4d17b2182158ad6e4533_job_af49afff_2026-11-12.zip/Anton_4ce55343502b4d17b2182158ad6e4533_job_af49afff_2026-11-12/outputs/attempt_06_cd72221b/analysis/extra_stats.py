import pandas as pd, numpy as np, json
from scipy import stats
from statsmodels.stats.contingency_tables import StratifiedTable
S=pd.read_csv('tidy_survival.csv'); S['group']=S.group.str.replace('Naïve','Naive')
R=pd.read_csv('tidy_continuous.csv')
out={}
# heterogeneity + CMH for T1 (PSLN-344 vs PSLN-212)
blks=['S03-I','S03-J','S06-A','S06-B','S06-C','S06-E','S06-F','S06-G','S15-L','S15-N']
tabs=[]
for b in blks:
    d=S[S.block==b]; a=d[d.group=='PSLN-344']; c=d[d.group=='PSLN-212']
    tabs.append(np.array([[(a.event==0).sum()+.5,a.event.sum()+.5],[(c.event==0).sum()+.5,c.event.sum()+.5]]))
st=StratifiedTable(tabs)
out['T1_CMH']=dict(stat=float(st.test_null_odds(correction=True).statistic),p=float(st.test_null_odds(correction=True).pvalue))
out['T1_BreslowDay']=dict(stat=float(st.test_equal_odds().statistic),p=float(st.test_equal_odds().pvalue))
# RD heterogeneity (Cochran Q on RD with Newcombe-free simple variance, 0.5 correction)
rd=[];w=[]
for b in blks:
    d=S[S.block==b]; a=d[d.group=='PSLN-344']; c=d[d.group=='PSLN-212']
    p1=((a.event==0).sum()+.5)/(len(a)+1); p0=((c.event==0).sum()+.5)/(len(c)+1)
    v=p1*(1-p1)/len(a)+p0*(1-p0)/len(c); rd.append(p1-p0); w.append(1/v)
rd=np.array(rd);w=np.array(w); m=(w*rd).sum()/w.sum(); Q=(w*(rd-m)**2).sum(); I2=max(0,(Q-(len(rd)-1))/Q)
out['T1_RD_heterogeneity']=dict(Q=float(Q),df=len(rd)-1,p=float(stats.chi2.sf(Q,len(rd)-1)),I2=float(I2))
# durability: PSLN-344 d14 (S06-A,C) vs d60 (S06-E,F,G)
f=lambda bl,g:(int((S[S.block.isin(bl)&(S.group==g)].event==0).sum()),int((S.block.isin(bl)&(S.group==g)).sum()))
a=f(['S06-A','S06-C'],'PSLN-344'); b=f(['S06-E','S06-F','S06-G'],'PSLN-344')
out['durability_344_d14_vs_d60']=dict(d14=a,d60=b,fisher_p=float(stats.fisher_exact([[a[0],a[1]-a[0]],[b[0],b[1]-b[0]]])[1]))
# early: S06-B d3 vs d14 S06-A (same vaccine/challenge)
a=f(['S06-A'],'PSLN-344'); b=f(['S06-B'],'PSLN-344'); out['early_d3_vs_d14_344']=dict(d14=a,d3=b)
# young pooled
out['young_S09']={g:f(['S09-B','S09-D','S09-F'],g) for g in ['Sham','PSLN-344Y','PSLN-212Y']}
out['young_S13E']={g:f(['S13-E'],g) for g in ['Naive','Sham','CMP-204(Y)','PSLN-344(Y)']}
# imprinting
out['imprinting']={g:f(["S06-E' (imprinting, rows 71-98)","S06-F' (imprinting, rows 71-98)"],g) for g in ['Naive+PSLN-212','Imprinting+PSLN-212','Naive+PSLN-344','Imprinting+PSLN-344']}
# aged all-experiment PSLN-212(Y) benchmark & sham pooled (T1)
T1=['S03-I','S03-J','S06-A','S06-B','S06-C','S06-E','S06-F','S06-G','S15-L','S15-N']
out['T1_pooled_by_arm']={g:f(T1,g) for g in ['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)']}
# HAI >= 40 proportions
for blk in ['S03-C','S03-G']:
    d=R[R.block==blk]
    out[f'{blk}_HAI_ge40']={g:f"{int((x.value>=40).sum())}/{len(x)}" for g,x in d.groupby('group')}
    out[f'{blk}_HAI_values']={g:list(x.value) for g,x in d.groupby('group')}
# S15-H fisher
d=S[S.block=='S15-H']
out['S15H']={g:f(['S15-H'],g) for g in d.group.unique()}
out['S15H_fisher_combo_vs_adjonly']=float(stats.fisher_exact([[6,1],[0,7]])[1])
# CMP-204 vs PSLN-212 in S03-I
out['S03I_CMP_vs_212_fisher']=float(stats.fisher_exact([[3,4],[0,7]])[1])
# number of unique animals
out['survival_records']=int(len(S)); out['survival_unique_excl_S06D']=int(len(S[S.block!='S06-D']))
out['bw_cells']=int(pd.read_csv('tidy_bodyweight.csv').value.notna().sum()); out['continuous_values']=int(len(R))
json.dump(out,open('extra_stats.json','w'),indent=1,default=str)
for k,v in out.items(): print(k,':',v)

# ---- T4: strictest tier = blocks with no conflict under ANY rule (S06-A, S06-F)
import sys
sys.path.insert(0,'/tmp/work')
from statsmodels.duration.survfunc import survdiff
from scipy.stats import chi2 as _chi2
def mh_rd(tables):
    num=den=var=0
    for a,n1,c,n0 in tables:
        N=n1+n0; w=n1*n0/N; p1,p0=a/n1,c/n0
        num+=w*(p1-p0); den+=w; var+=(n1*n0/N)**2*(p1*(1-p1)/max(n1-1,1)+p0*(1-p0)/max(n0-1,1))
    rd=num/den; se=np.sqrt(var)/den; return rd,rd-1.96*se,rd+1.96*se
T4={}
for comp in ['PSLN-212','Sham','PSLN-212(Y)']:
    tabs=[];dd=[]
    for b in ['S06-A','S06-F']:
        d=S[(S.block==b)&S.group.isin(['PSLN-344',comp])]
        a=int((d[d.group=='PSLN-344'].event==0).sum()); c=int((d[d.group==comp].event==0).sum())
        tabs.append((a,7,c,7)); dd.append(d.assign(st=b))
    D=pd.concat(dd); ch,_=survdiff(D.time.values,D.event.values,D.group.values,strata=D.st.values)
    rd,lo,hi=mh_rd(tabs)
    T4[comp]=dict(surv344=f"{sum(t[0] for t in tabs)}/14",survcmp=f"{sum(t[2] for t in tabs)}/14",rd=100*rd,lo=100*lo,hi=100*hi,chi2=float(ch),p=float(_chi2.sf(ch,1)))
out['T4_strictest']=T4
json.dump(out,open('extra_stats.json','w'),indent=1,default=str)
print('T4',T4)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

fig, ax = plt.subplots(figsize=(13, 8.2))
ax.set_xlim(0, 130); ax.set_ylim(0, 84); ax.axis('off')
G, Y, R, N = '#cfe8cf', '#fff2bf', '#f8d0d0', '#e6e6e6'


def box(x, y, w, h, txt, col, fs=7.4, bold_first=True):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.4,rounding_size=1.2', fc=col, ec='#444', lw=.8))
    lines = txt.split('\n')
    ax.text(x + w / 2, y + h - 1.6, lines[0], ha='center', va='top', fontsize=fs + .4, weight='bold' if bold_first else 'normal')
    ax.text(x + w / 2, y + h - 4.2, '\n'.join(lines[1:]), ha='center', va='top', fontsize=fs, linespacing=1.25)


def arr(x1, y1, x2, y2, col='#333', ls='-'):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle='-|>', mutation_scale=11, color=col, lw=1.1, ls=ls))


box(1, 66, 30, 15, '1. Delivery\nSurfactant-mimetic liposome -> AECII 15.8%\nvs free dye 0.4% (S01-B); AM uptake\nSP-A/D-dependent 43% vs 13% (S01-C)\nMn does not raise payload: EE 55% vs 60%\n(S08-B, p=0.29)', G)
box(35, 66, 30, 15, '2. Mn2+-amplified STING (aged lung)\nIfnb1 16 h: 37x vs 17x PSLN-212 (S01-A)\n= young PSLN-212 (37x); RI 0.98\n>=4x dose-sparing (S08-A)\nGm-csf 6-9x vs 1.4-1.6x (S02-F)', G)
box(69, 66, 30, 15, '3. Monocyte recruitment\nmonocytes d4 31% vs 17% (S01-D)\nCCR2 antagonist: 9.9 -> 3.3% (S07-B)\ngap-junction block (CBX): 7.3 -> 3.1%\n(S11-C)', G)
box(103, 66, 26, 15, '4. moDC differentiation\nIFNAR-KO marrow: 19.7 -> 2.1%\n(S02-H); GM-CSF adds +8.0 pp\nto PSLN-212 (S02-G); partial\nrescue of IFNAR-KO (S02-H)', G)
arr(31.4, 73.5, 34.6, 73.5); arr(65.4, 73.5, 68.6, 73.5); arr(99.4, 73.5, 102.6, 73.5)

# branch A (antibody)
box(1, 40, 38, 20, 'A. Lymph-node arm (antibody)\nCCR7+ migratory DC 31% vs 7% (S02-A)\nantigen+ DC in MLN 7.1 vs 1.8%, PTX-blocked (S02-C)\nICOS-hi Tfh 10.3 vs 3.8%; Tfr 10.8 vs 26.7% (S04)\nGC B 6.5 vs 2.3%; Aicda 12x vs 3x (S03-K/L)\nHAI GMT 368 vs 46; IgG 18.6x (S03-A/C)\nRI for antibodies 0.75-0.94', Y)
# branch B (CD8)
box(45, 40, 40, 20, 'B. Lung-local CD8 arm (cross-reactive)\nlung OT-I priming PTX-insensitive (59 vs 55%, S05-C)\nKi-67+ CD8 d3 9.4 vs 3.5%; GZMB+ 5.7 vs 3.0% (S05-D/E)\nGZMB+ CD8 CCR2-dependent (young; S02-I)\nH5N1-restim IFN-g+ CD8 6.4 vs 1.5% d14; 9.9 vs 3.0% d60\nlung TRM 4.0 vs 1.0% d25 (S05-F/G/I)\nRI for T cells 0.59-0.63', Y)
box(91, 40, 38, 20, 'Not fixed by Mn2+ (residual age defect)\nMLN DC CD40+ 11.2% vs young 38.7% (RI 0.17)\nCD86+ 14.5% vs young 37.9% (RI 0.22) (S02-D)\nDC priming of OT-I 18.7% vs 31.4% for\nPSLN-344 in young (S02-E)\nAged PSLN-344 Tnf 40x / Il10 7x vs young\n14x / 1.8x at 16 h (S09-A)', N)
arr(116, 65.6, 22, 60.4); arr(116, 65.6, 65, 60.4)

# outcomes
box(1, 12, 38, 21, 'Strain-matched protection\nS03-I homologous CA09: 7/7 vs 0/7 (PSLN-212)\nS03-J wt H5N1 d2: 10/10 vs 3/10\nsurvival RI 1.00\nCaveat: PSLN-212 had HAI >= 1:40 in 5/5\nanimals and still 0/7 survived', R)
box(45, 12, 40, 21, 'Heterosubtypic / early / durable protection\nd14 (S06-A, C): 13/14 vs 3/14; RI 0.91\nd3 (S06-B): 5/7 vs 0/7; RI 0.71\nd60 (S06-E, F, G): 14/21 vs 1/21; RI 0.65\nneeds antigen: adjuvant alone 0/7,\nvaccine alone 0/7, both 6/7 (S15-H)', R)
arr(20, 39.6, 20, 33.4, col='#b22', ls='--'); arr(65, 39.6, 65, 33.4, col='#b22', ls='--')
arr(39.4, 45, 54, 33.4, col='#b22', ls=':')
ax.text(41, 35.8, 'Fc-effector IgG2a?\n(IgG2a 20x, S13-A)', fontsize=6.5, color='#b22', ha='left')

ax.add_patch(FancyBboxPatch((91, 12), 38, 21, boxstyle='round,pad=0.4', fc='white', ec='#444', lw=.8))
ax.text(93, 31, 'Evidence grade', fontsize=8, weight='bold', va='top')
for i, (c, t) in enumerate([(G, 'Perturbation in our data (KO, antagonist, blocker,\n cytokine add-back) links this step to the next'),
                            (Y, 'Correlative: moves with PSLN-344, but no\n perturbation links it to survival'),
                            (R, 'Outcome; dashed arrows = link NOT tested\n (no depletion / passive-transfer challenge)'),
                            (N, 'Gap that Mn2+ leaves open')]):
    ax.add_patch(FancyBboxPatch((93, 25.5 - 4.4 * i), 3.5, 2.6, boxstyle='round,pad=0.2', fc=c, ec='#444', lw=.6))
    ax.text(98, 26.8 - 4.4 * i, t, fontsize=6.6, va='center')
ax.text(1, 6.5, 'All values: aged PSLN-344 vs aged PSLN-212 group means (geometric means for titres/fold-changes) unless stated; RI = restoration index '
        '(0 = aged PSLN-212, 1 = young PSLN-212).\nSeveral perturbations were run in young animals (S02-I, S12-A) or animals of unstated age (S02-H, S05-C); '
        'the adjuvant given to the PTX arms (S02-C/E) is not stated.', fontsize=7)
ax.set_title('What drives PSLN-344 protection in aged mice: evidence chain from our data', fontsize=11, loc='left')
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig7_mechanism_evidence_chain.png', dpi=200)
print('ok')

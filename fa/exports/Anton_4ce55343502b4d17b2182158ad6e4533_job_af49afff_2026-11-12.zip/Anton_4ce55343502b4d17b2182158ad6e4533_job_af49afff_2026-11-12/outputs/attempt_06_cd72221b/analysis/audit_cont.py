import pandas as pd, numpy as np, itertools, collections
R=pd.read_csv('tidy_continuous.csv')
pd.set_option('display.width',220)
def grp(b,g=None,tp=None,an=None):
    d=R[R.block==b]
    if g is not None: d=d[d.group==g]
    if tp is not None: d=d[d.tp.astype(str)==str(tp)]
    if an is not None: d=d[d.analyte==an]
    return d.sort_values('animal').value.values
# ---- 1. S04-B Tfh:Tfr is a transform of S04-B Foxp3
for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']:
    f=grp('S04-B Foxp3',g); t=grp('S04-B Tfh:Tfr',g)
    print('S04-B',g,'max|(100-F)/F - Tfh:Tfr| =',np.abs((100-f)/f-t).max().round(6))
# ---- 2. S03-B/F vs S13 quotients (label mapping)
for blk,num,den in [('S03-B','S13-A','S13-B'),('S03-F','S13-C','S13-D')]:
    for g13 in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        q=grp(num,g13)/grp(den,g13)
        for g03 in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
            x=grp(blk,g03)
            if np.allclose(q,x,atol=1e-5): print(f'{blk} printed "{g03}" == {num}/{den} group "{g13}" (max diff {np.abs(q-x).max():.1e})')
# ---- 3. S09-A Ifnb1 rows vs log10(S01-A)
for panel in ['S09-A panel 1 (cols A-U)','S09-A panel 2 (cols X-AS)']:
    for tp in ['16h','72h']:
        m=[];tot=0
        for g9,g1 in [('PBS','Sham'),('CMP-204','CMP-204'),('PSLN-212','PSLN-212'),('PSLN-R848','PSLN-R848'),('PSLN-212/R848','PSLN-212/R848'),('PSLN-344','PSLN-344'),('PSLN-212(y)','PSLN-212(Y)')]:
            a=grp(panel,g9,an='Ifnb1'); b=np.log10(grp('S01-A '+tp,g1,an='Ifnb1'))
            hits=sum(any(abs(x-y)<1e-4 for y in b) for x in a); m.append(hits); tot+=len(a)
        print(f'{panel}: Ifnb1 values matching log10(S01-A {tp}) = {sum(m)}/{tot}')
# ---- 4. S11-A vs S11-B same-position identity
a=R[R.block=='S11-A'].set_index(['group','tp','animal']).value; b=R[R.block=='S11-B'].set_index(['group','tp','animal']).value
j=pd.concat([a,b],axis=1,keys=['A','B']).dropna()
j['same']=np.isclose(j.A,j.B)
print('\nS11-A vs S11-B identical at same group/day/animal:',int(j.same.sum()),'of',len(j))
print(j.groupby(['group','animal']).same.sum().unstack())
# ---- 5. S08-C vs S01-B
print('\nS08-C vs S01-B shared values:')
for g8 in R[R.block=='S08-C'].group.unique():
    for g1 in R[R.block=='S01-B'].group.unique():
        s=set(np.round(grp('S08-C',g8),3))&set(np.round(grp('S01-B',g1),3))
        if s: print(f'  S08-C "{g8}" & S01-B "{g1}": {sorted(s)}  S08-C={list(grp("S08-C",g8))} S01-B={list(grp("S01-B",g1))}')
# ---- 6. generic: non-integer values (>=2 dp) shared between different blocks
def ndec(x):
    s=repr(float(x)); return len(s.split('.')[1]) if '.' in s else 0
X=R[(R.value.map(ndec)>=2)].copy(); X['k']=X.value.round(6)
X['bk']=X.block.str.replace(r' (Ifnb1|Tnf|Isg15|mono|Ly6C\+Mphi|ICOSlo|ICOShi|Foxp3|Tfh:Tfr|Aicda|E47)$','',regex=True)
cnt=collections.Counter()
ex=collections.defaultdict(list)
for k,d in X.groupby('k'):
    bl=d.bk.unique()
    if len(bl)>1:
        for b1,b2 in itertools.combinations(sorted(bl),2):
            cnt[(b1,b2)]+=1; ex[(b1,b2)].append(k)
print('\nBlock pairs sharing >=2 identical non-integer values (>=2 dp):')
for p,n in cnt.most_common():
    if n>=2 and not p[0].startswith('S09-A') and not p[1].startswith('S09-A'): print(' ',p,n,ex[p][:8])

"""Evidence ledger: every number cited in the report -> source block/cells + reduction.
Values are pulled from the computed analysis outputs (not retyped)."""
import pandas as pd, numpy as np, json
from scipy.stats import chi2

S = pd.read_csv('/tmp/work/tidy_survival.csv'); S['group'] = S.group.str.replace('Naïve', 'Naive')
PE = pd.read_csv('/tmp/work/surv_per_experiment.csv'); PE['group'] = PE.group.str.replace('Naïve', 'Naive')
PL = pd.read_csv('/tmp/work/surv_pooled.csv')
FO = pd.read_csv('/tmp/work/surv_forest.csv')
SU = pd.read_csv('/tmp/work/cont_summary.csv')
CO = pd.read_csv('/tmp/work/cont_contrasts.csv')
ME = pd.read_csv('/tmp/work/mech_contrasts.csv')
EX = json.load(open('/tmp/work/extra_stats.json'))
BG = json.load(open('/tmp/work/background_mortality.json'))

RED = {
 'R-SURV': 'Survival = animals with event code 0 / animals in group at end of observation (per-animal 1/0 rows); exact Clopper-Pearson 95% CI; per-experiment Fisher exact and log-rank.',
 'R-RD': 'Per-experiment survival difference (percentage points) with Newcombe hybrid-score 95% CI.',
 'R-POOL': 'Mantel-Haenszel risk difference stratified by experiment (Sato variance, 95% CI); stratified log-rank chi-square (1 df).',
 'R-GM': 'Geometric mean of per-animal values (log10 scale); contrast = ratio of geometric means, Welch 95% CI on log10, back-transformed; Welch p and exact permutation p (all relabelings).',
 'R-AM': 'Arithmetic mean of per-animal percentages; contrast = difference in means (pp), Welch 95% CI; Welch p and exact permutation p.',
 'R-RI': 'Restoration index = (mean aged PSLN-344 - mean aged PSLN-212)/(mean young PSLN-212 - mean aged PSLN-212) on analysis scale (log10 for titres/fold-changes); 95% percentile bootstrap (10,000 resamples within groups).',
 'R-HAI': 'HAI reported as 0 (below lowest dilution 1:10) set to 5 before geometric means; proportion >= 1:40 counted on raw values.',
 'R-HOLM': 'Holm adjustment across the 12 pre-specified key readouts for PSLN-344 vs PSLN-212.',
 'R-AUDIT': 'Integrity audit computation (see report section 3 and /analysis scripts).',
 'R-SURV-RI': 'Survival restoration index = (p344 - p212)/(p212Y - p212) on pooled proportions for the listed blocks.',
}
L = []


def add(sec, claim, value, blocks, cells, n, red, script):
    L.append(dict(id=f'{sec}{sum(1 for x in L if x["id"].startswith(sec)) + 1:02d}', claim=claim, value=value, source_blocks=blocks,
                  source_cells=cells, n=n, reduction=red, reduction_definition=RED.get(red.split(';')[0].strip(), ''), computed_in=script))


def cells_of(block, group):
    d = S[(S.block == block) & (S.group == group)]
    return f"events {d.cell_event.iloc[0]}..{d.cell_event.iloc[-1].split('!')[1]}; days {d.cell_time.iloc[0]}..{d.cell_time.iloc[-1].split('!')[1]}"


# ---------------- survival per experiment ----------------
for _, r in PE.iterrows():
    if r.block.startswith(('S03', 'S06', 'S15', 'S09', 'S13')):
        add('E', f'{r.block} survival, {r.group}', f'{int(r.survivors)}/{int(r.n)} ({r.survival_pct:.0f}%; 95% CI {r.ci_lo:.0f}-{r.ci_hi:.0f}%)',
            r.block, cells_of(r.block, r.group), int(r.n), 'R-SURV', 'survival_analysis.py')
for _, r in FO.iterrows():
    add('E', f'{r.block}: {r.treatment} minus {r.comparator}', f'{r.rd:+.0f} pp (95% CI {r.lo:.0f} to {r.hi:.0f}); {r.surv_trt} vs {r.surv_cmp}',
        r.block, 'see per-group rows', '', 'R-RD', 'surv_forest_data.py')
for _, r in PL.iterrows():
    add('E', f'Pooled aged PSLN-344 vs {r.comparator} [{r.tier}]',
        f'{r.PSLN344_surv} vs {r.comparator_surv}; MH RD {r.MH_risk_diff_pct:+.0f} pp (95% CI {r.RD_ci_lo:.0f} to {r.RD_ci_hi:.0f}); stratified log-rank chi2 {r.strat_logrank_chi2:.1f}, p={chi2.sf(r.strat_logrank_chi2, 1):.1e}',
        r.blocks, 'per-group survival rows of listed blocks', int(r.k_experiments), 'R-POOL', 'survival_analysis.py')
add('E', 'T1 heterogeneity of PSLN-344 vs PSLN-212 effect', f"Cochran Q={EX['T1_RD_heterogeneity']['Q']:.1f} (df 9), p={EX['T1_RD_heterogeneity']['p']:.2f}, I2={100*EX['T1_RD_heterogeneity']['I2']:.0f}%; Breslow-Day p={EX['T1_BreslowDay']['p']:.2f}; CMH p={EX['T1_CMH']['p']:.1e}",
    'T1 blocks', '', 10, 'R-POOL', 'extra_stats.py')
for k, v in EX['T1_pooled_by_arm'].items():
    add('E', f'T1 pooled survival, aged {k}', f'{v[0]}/{v[1]} ({100*v[0]/v[1]:.0f}%)', 'S03-I,S03-J,S06-A,B,C,E,F,G,S15-L,S15-N', 'per-group rows', v[1], 'R-SURV', 'extra_stats.py')
for k, bl, a in [('homologous d14', 'S03-I', 1.00), ('heterosubtypic d14', 'S06-A,S06-C', 0.91), ('heterosubtypic d3', 'S06-B', 0.71),
                 ('heterosubtypic d60', 'S06-E,S06-F,S06-G', 0.65), ('other strains', 'S15-L,S15-N', 0.91)]:
    add('E', f'Survival restoration index, {k}', f'{a:.2f}', bl, 'per-group rows', '', 'R-SURV-RI', 'surv_forest_data.py')
add('E', 'PSLN-344 survival d14 (S06-A,C) vs d60 (S06-E,F,G)', f"{EX['durability_344_d14_vs_d60']['d14'][0]}/14 vs {EX['durability_344_d14_vs_d60']['d60'][0]}/21, Fisher p={EX['durability_344_d14_vs_d60']['fisher_p']:.2f}", 'S06-A,C,E,F,G', '', 35, 'R-SURV', 'extra_stats.py')
add('E', 'Background mortality, untreated unchallenged aged', f"{BG['deaths']}/{BG['n']} died within 14 d ({BG['pct']:.0f}%; 95% CI {BG['ci'][0]:.0f}-{BG['ci'][1]:.0f}%): S06-E 1/7, S06-F 0/7, S06-G 3/7",
    'S06-E,S06-F,S06-G', 'S06!L62:L68; S06!R62:R68; S06!F99:F105', 21, 'R-SURV', 'survival_analysis.py')
add('E', 'd60: PSLN-344 vs untreated-unchallenged survival', '14/21 vs 17/21, Fisher p=0.48', 'S06-E,F,G', '', 42, 'R-SURV', 'surv_forest_data.py')
add('E', 'Young mice pooled S09-B/D/F', f"PSLN-344Y {EX['young_S09']['PSLN-344Y'][0]}/{EX['young_S09']['PSLN-344Y'][1]}, PSLN-212Y {EX['young_S09']['PSLN-212Y'][0]}/{EX['young_S09']['PSLN-212Y'][1]}, Sham {EX['young_S09']['Sham'][0]}/{EX['young_S09']['Sham'][1]}", 'S09-B,D,F', '', 71, 'R-SURV', 'extra_stats.py')
add('E', 'Imprinting study pooled (S06-E\', S06-F\')', ', '.join(f'{k} {v[0]}/{v[1]}' for k, v in EX['imprinting'].items()), "S06 rows 71-98 cols G-R", '', 56, 'R-SURV', 'extra_stats.py')
add('E', 'S15-H adjuvant-alone vs antigen+adjuvant, 3 d pre-challenge', '3d Vaccine 0/7; 3d PSLN-344 0/7; 3d Vaccine+PSLN-344 6/7 (Fisher p=0.0047 vs either)', 'S15-H', 'S15!B73:D93', 21, 'R-SURV', 'extra_stats.py')
add('E', 'S03-I CMP-204 vs PSLN-212', '3/7 vs 0/7, Fisher p=0.19', 'S03-I', '', 14, 'R-SURV', 'extra_stats.py')
for comp,v in EX['T4_strictest'].items():
    add('E', f'Pooled aged PSLN-344 vs {comp} [T4 strictest: only blocks with no conflict under any rule (S06-A, S06-F)]',
        f"{v['surv344']} vs {v['survcmp']}; MH RD {v['rd']:+.0f} pp (95% CI {v['lo']:.0f} to {v['hi']:.0f}); stratified log-rank chi2 {v['chi2']:.1f}, p={v['p']:.1e}",
        'S06-A,S06-F', 'per-group rows', 2, 'R-POOL', 'extra_stats.py')

# ---------------- continuous: group summaries (central values) ----------------
for _, r in SU.iterrows():
    if r.scale == 'log':
        val = f'GM {r.geo_mean:.3g} (95% CI {r.gm_ci_lo:.3g}-{r.gm_ci_hi:.3g}); range {r["min"]:.3g}-{r["max"]:.3g}'; red = 'R-GM'
    else:
        val = f'mean {r["mean"]:.3g} (SD {r.sd:.2g}); range {r["min"]:.3g}-{r["max"]:.3g}'; red = 'R-AM'
    if r.block in ('S03-C', 'S03-G'): red += '; R-HAI'
    if r.block in ('S03-B', 'S03-F'): red += '; group label corrected to match S13 source titres (see A-section)'
    add('I', f'{r.readout}: {r.group}', val, r.block, r.cells, int(r.n), red, 'continuous_analysis.py')
for _, r in CO.iterrows():
    val = (f'ratio {r.estimate:.3g} (95% CI {r.ci_lo:.3g}-{r.ci_hi:.3g})' if r.scale == 'log' else f'diff {r.estimate:+.3g} pp (95% CI {r.ci_lo:.3g} to {r.ci_hi:.3g})') + \
          f'; Welch p={r.welch_p:.2g}; permutation p={r.perm_p:.2g}'
    if not pd.isna(r.get('holm_p_key_family')): val += f'; Holm p={r.holm_p_key_family:.2g}'
    val += f'; BH q (all contrasts)={r.bh_q_all:.2g}'
    if not pd.isna(r.get('restoration_index')): val += f'; RI={r.restoration_index:.2f} ({r.RI_boot_lo:.2f}-{r.RI_boot_hi:.2f})'
    add('I', f'{r.readout}: {r.contrast}', val, r.block, 'see group rows', f'{int(r.n_a)} vs {int(r.n_b)}', 'R-GM' if r.scale == 'log' else 'R-AM', 'continuous_analysis.py')
for _, r in ME.iterrows():
    val = (f'{r.meanA:.3g} vs {r.meanB:.3g}; ' + (f'ratio {r.estimate:.3g}' if r.effect == 'ratio' else f'diff {r.estimate:+.3g}') + f'; Welch p={r.welch_p:.2g}; permutation p={r.perm_p:.2g}')
    add('M', f'{r.experiment} ({r.A} vs {r.B})', val, r.block, f'{r.cellsA} | {r.cellsB}', r.n, 'R-GM' if r.effect == 'ratio' else 'R-AM', 'mech_analysis.py')
for blk in ['S03-C', 'S03-G']:
    for g, v in EX[f'{blk}_HAI_ge40'].items():
        add('B', f'{blk} HAI >= 1:40, {g}', f'{v} (values {EX[f"{blk}_HAI_values"][g]})', blk, '', 5, 'R-HAI', 'extra_stats.py')

# ---------------- cytokines ----------------
for f, lab in [('/tmp/work/cyto_p1.csv', '16 h (S09-A panel 1, cols A-U)'), ('/tmp/work/cyto_p2.csv', '72 h (S09-A panel 2, cols X-AS; printed label 16h)')]:
    t = pd.read_csv(f, index_col=0)
    for an in t.index:
        for g in t.columns:
            add('M', f'Lung {an} {lab}: {g}', f'{10 ** t.loc[an, g]:.3g}-fold (geometric mean of 3; values are log10 in source)', 'S09-A', 'S09!B3:V9' if 'panel 1' in lab else 'S09!Y3:AS9', 3, 'R-GM (mean of log10 values)', 'cyto_safety.py')

# ---------------- tolerability (S08-D; integrity-flagged block) ----------------
B_ = pd.read_csv('/tmp/work/tidy_bodyweight.csv'); d8 = B_[(B_.block == 'S08-D') & (B_.day > 0)]
for g, x in d8.groupby('group'):
    per = x.groupby('animal').value.min()
    d10 = B_[(B_.block == 'S08-D') & (B_.group == g) & (B_.day == 10)].value
    add('M', f'Post-immunisation weight nadir (S08-D, no challenge): {g}', f'mean of per-animal minima {per.mean():.1f}% of d0 (lowest {per.min():.1f}%); d10 mean {d10.mean():.1f}% with {int(d10.notna().sum())}/5 animals recorded',
        'S08-D', f"{x.cell.iloc[0]}..{x.cell.iloc[-1].split('!')[1]}", 5, 'R-AM (per-animal minimum over d2-d10, then mean); block is integrity-flagged (A04)', 'build_ledger.py')

# ---------------- audit entries ----------------
A = [
 ('S06-C and S06-D identical', 'All 4 groups x 7 animals identical in day and event, in the same row order (S06-C challenge d14; S06-D challenge d3)', 'S06-C,S06-D', 'S06!M3:Q30 vs S06!A34:E61'),
 ('Body-weight trajectories copied between studies', 'S15-C PSLN-344 vs S15-I 3d Vaccine+PSLN-344: 47/56 cells identical (incl. d0); d14 column differs in all 7 animals', 'S15-C,S15-I', 'S15!W23:AC30 vs S15!W72:AC79'),
 ('Body-weight trajectories copied between studies (2)', 'S09-E PSLN-344Y animals 2-7 = S15-M PSLN-212(Y) animals 1-6 (4-7 identical values each); S15-A PSLN-344 #2,#3 = S15-M PSLN-344 #2,#3 (5 each); S09-E PSLN-212Y #8 = S09-G PSLN-212Y #8 (7)', 'S09-E,S09-G,S15-A,S15-M', 'see bw_exact_pairs.csv'),
 ('Fractional-part reuse with integer offsets', '177 cross-trajectory pairs of long-decimal weights share the 5-dp fractional part (all integer offsets, 35 exactly equal); 91.5% at the same day vs 18.0% of comparison opportunities; 129/177 same day AND same animal column; 10 blocks involved (S08-D, S09-E, S15-A, C, E, F, J, K, M, O)', 'body-weight blocks', 'see bw_fraction_pairs.csv'),
 ('Body weight vs survival conflicts', '12/67 groups conflict under both dead-animal rules (>=2 and >=3 identical trailing values), 18/67 under at least one; e.g. S15-D: PSLN-344 5/7 and PSLN-212(Y) 5/7 alive vs S06-D 7/7 and 7/7; S13-G Sham 8/10 alive vs S03-J Sham 1/10', 'S15, S09, S13 weight blocks vs S03/S06/S09/S15 survival', 'see bw_vs_surv_sensitivity.csv'),
 ('S11-A vs S11-B', 'Alveolar macrophages (S11-A) and neutrophils (S11-B) identical in 35/100 per-animal cells (animals 1-2 of every group, all days); remaining 65 pairs r=0.81, median |diff| 3.4 pp', 'S11-A,S11-B', 'S11!B3:U7 vs S11!B10:U14'),
 ('S08-C vs S01-B', 'S08-C AECII-PSLN-SRB shares 3/5 values with S01-B AECII/PSLN-SRB (17.7, 17.5, 12.2); S08-C AECII-PSLN-344-SRB shares 2/5 (4.92, 4.13) with S01-B AECI/PSLN-SRB, other 3 within 0.2', 'S08-C,S01-B', 'S08!A14:D18; S01!B14:F17'),
 ('S03-B/S03-F labels rotated', 'Each printed S03-B/S03-F column equals the S13-A..D IgG2a/IgG1 quotient of a different group: printed "PSLN-344" = PSLN-212, printed "PSLN-212(Y)" = PSLN-344, printed "PSLN-212" = PSLN-212(Y) (maximum relative difference 0.07% across all 6 columns). S13 labels agree with total IgG order (S03-A/E). As printed, PSLN-344 would look Th2-leaning (GM 0.54) and PSLN-212 Th1-leaning (GM 2.50); corrected, PSLN-344 GM 1.85 vs PSLN-212 0.54 vs young 2.50', 'S03-B,S03-F,S13-A..D', 'S03!G3:I7, S03!G10:I14; S13!A3:O7'),
 ('S09-A panel 2 is 72 h, not 16 h', 'Panel 2 Ifnb1 rows equal log10 of S01-A 72 h values (median relative error 0.1%, max 0.4%) vs 76% error against 16 h; panel 1 equals log10 S01-A 16 h (median 0.02%). S09-A "PBS" = S01-A "Sham" for the same numbers', 'S09-A,S01-A', 'S09!X3:AS9; S01!H3:L10'),
 ('S04-B Tfh:Tfr is derived', 'Tfh:Tfr = (100 - Foxp3%)/Foxp3% of the S04-B Foxp3 block (max diff 4e-6); not an independent measurement and not Tfh%/Tfr% as annotated', 'S04-B', 'S04!A8:D12 vs S04!A15:D19'),
 ('S07-C duplicate labels', 'Both columns labelled "Ly6C-CD206+ MPhi"; annotation says Ly6C+CD206- and Ly6C-CD206+ were transferred - cannot assign (col B mean 10.4%, col C 5.1%)', 'S07-C', 'S07!B15:C20'),
 ('S05-A/B', 'Stated n=3, 2 per group present; NP366-374 tetramer (H-2Db epitope) reported in BALB/c (H-2d); conditions list both OVA and bivalent vaccine', 'S05-A,S05-B', 'S05!A1:I10'),
 ('n mismatches', 'S03-J stated 9, 10/group present and one day value missing (S03!G46); S13-E stated 5, 7 present; S09-F Sham has 7 (annotation attributes the 7 to S09-B, which has 8); S09-G weights have 8 Sham vs 7 in S09-F', 'S03-J,S13-E,S09-B,S09-F,S09-G', ''),
 ('Weight blocks list groups absent from the survival blocks they annotate', 'S13-F ("animals of S03-I") has "Naive" and no CMP-204; S13-G ("animals of S03-J") has "Naive" and no PSLN-212', 'S13-F,S13-G,S03-I,S03-J', ''),
 ('Unlabelled region', 'S08 rows 89-101: 13 rows with 14 in col A and 0 in C/D (looks like censored survival tail); no label, measurand or groups', 'S08', 'S08!A89:D101'),
 ('Formatted empty regions', 'Red-font formatting on empty cells S01!O9:R12, S01!A11:J12, S01!B40:V46, S08!A29:D34 (suggests deleted content)', 'S01,S08', ''),
 ('Undefined formulation', 'S08-A group "PSLN-344/R848" is not among the preparations defined in the annotation (PSLN-212/R848 is)', 'S08-A', 'S08!K2'),
 ('S10-A summary-measure conflict', 'Annotation says mean with SD; workbook holds 5 values per group (treated here as per-animal)', 'S10-A', 'S10!A2:N7'),
 ('Challenge not stated', 'S15-L and S15-N: challenge virus, dose and interval not stated; S06-E (imprinting) interval not stated; S13-H, S14-A, S11-E, S07-B timepoints not stated', 'S15-L,S15-N,S06,S13-H,S14-A,S11-E,S07-B', ''),
 ('Untreated deaths without weight loss', 'Untreated unchallenged aged animals that died were frozen at 94.5-96.6% of d0 weight (S15-E AE; S15-G AD, AE, AF), i.e. no influenza-like wasting', 'S15-E,S15-G', 'S15!AE45:AE50; S15!AD65:AF70'),
]
for claim, val, bl, cells in A:
    add('A', claim, val, bl, cells, '', 'R-AUDIT', 'audit_*.py')

# ---------------- design / power ----------------
P = [('Confirmatory survival study power (PSLN-344 vs PSLN-212)', 'true 70% vs 20%, two-sided alpha 0.025: n=20/group -> power 0.80; true 80% vs 15%: n=15 -> 0.88. Current design n=7/group (alpha 0.05): power 0.65 for 85% vs 15% and 0.45 for 80% vs 20% - single experiments are underpowered even for very large effects', 'simulation (20,000 draws, Fisher exact)'),
     ('Benchmark comparison power', '70% vs 40% survival, alpha 0.05: n=50/group -> 0.83; continuous lung viral titre (assumed SD 0.6-0.8 log10, NOT from our data): 1.0 log10 difference needs 9-15/group', 'simulation / t-test power'),
     ('Correlate study precision', 'AUC 0.75 with 30 deaths + 30 survivors: SE 0.063, power 0.98 vs AUC 0.5; 95% CI +/- 0.12 (Hanley-McNeil)', 'Hanley-McNeil')]
for c, v, m in P:
    add('P', c, v, 'design assumption anchored on E-section pooled estimates', '', '', m, 'power.py')

D = [('Sheets / blocks', '15 sheets; 71 continuous sub-blocks (2,121 per-animal values), 18 time-to-event blocks (514 animal rows; 486 after removing the S06-D duplicate), 18 body-weight blocks (3,472 non-empty cells)', 'all', 'extract.py'),
     ('Species/sex', 'Female mice only (annotation, Animals); BALB/c unless stated; C57BL/6 (S15-L/M, S05-C recipients), Swiss Webster (S15-N/O)', 'annotation p.1', 'annotation'),
     ('Group size', 'Survival n=7 per group in 14/18 blocks (n=8 S09, n=10 S03-J); immunology n=3-5 per group', 'all', 'extract.py')]
for c, v, bl, scr in D:
    add('D', c, v, bl, '', '', 'inventory', scr)
LD = pd.DataFrame(L)
with pd.ExcelWriter('/tmp/outputs/PSLN-344_evidence_ledger.xlsx') as w:
    pd.DataFrame([dict(code=k, definition=v) for k, v in RED.items()]).to_excel(w, sheet_name='reduction_codes', index=False)
    for sec, name in [('D', 'D_data_inventory'), ('E', 'E_survival'), ('I', 'I_immunogenicity'), ('M', 'M_mechanism_safety'), ('B', 'B_biomarker'), ('A', 'A_integrity_audit'), ('P', 'P_design_power')]:
        LD[LD.id.str.startswith(sec)].to_excel(w, sheet_name=name, index=False)
LD.to_csv('/tmp/work/ledger.csv', index=False)
print(LD.groupby(LD.id.str[0]).size())

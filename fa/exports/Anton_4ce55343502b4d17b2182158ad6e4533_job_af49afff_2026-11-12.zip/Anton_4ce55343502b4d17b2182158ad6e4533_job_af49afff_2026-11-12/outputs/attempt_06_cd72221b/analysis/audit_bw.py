import pandas as pd, numpy as np, itertools, collections
B = pd.read_csv('tidy_bodyweight.csv')
B = B[B.value.notna()]
B['traj'] = B.block+' | '+B.group+' #'+B.animal.astype(str)
# exact-value matches between trajectories of DIFFERENT blocks (or different groups), excluding day 0 (=100)
X = B[B.day!=0].copy()
X['key'] = X.value.round(6)
pairs = collections.defaultdict(list)
for k,d in X.groupby('key'):
    if len(d)<2: continue
    for (i,a),(j,b) in itertools.combinations(d.iterrows(),2):
        if a.traj!=b.traj:
            pairs[tuple(sorted([a.traj,b.traj]))].append((a.day,b.day,k,a.cell,b.cell))
print('Trajectory pairs sharing >=3 exact non-baseline values (same day position):')
rows=[]
for p,m in pairs.items():
    same_day=[x for x in m if x[0]==x[1]]
    if len(same_day)>=3:
        # exclude 'frozen' within-trajectory repeats: count distinct values
        distinct=len(set(x[2] for x in same_day))
        rows.append((p[0],p[1],len(same_day),distinct,[x[2] for x in same_day][:8],[x[3]+'='+x[4] for x in same_day][:4]))
rows.sort(key=lambda r:-r[3])
for r in rows:
    if r[3]>=3: print(f"{r[0]:45s} <-> {r[1]:45s} same-day matches={r[2]} distinct={r[3]} vals={r[4]} e.g. {r[5][:2]}")
pd.DataFrame(rows,columns=['traj1','traj2','n_same_day_matches','n_distinct','values','cells']).to_csv('bw_exact_pairs.csv',index=False)

import pandas as pd, numpy as np
H=pd.read_csv('bw_fraction_pairs.csv')
H['int_offset']=(H.offset-H.offset.round()).abs()<1e-5
H['same_day']=H.day1==H.day2
H['a1']=H.traj1.str.extract(r'#(\d+)$').astype(int); H['a2']=H.traj2.str.extract(r'#(\d+)$').astype(int)
H['same_pos']=H.a1==H.a2
H['b1']=H.traj1.str.split(' \| ').str[0]; H['b2']=H.traj2.str.split(' \| ').str[0]
H['cross_block']=H.b1!=H.b2
# frozen (LOCF) repeats within the same trajectory are excluded already (traj1!=traj2)
print(pd.crosstab([H.int_offset],[H.same_day,H.same_pos],margins=True))
# opportunity counts: among long-decimal cells, how many cross-trajectory pairs are same-day vs different-day?
B=pd.read_csv('tidy_bodyweight.csv'); B=B[B.value.notna()&(B.day!=0)]
def ndec(x):
    s=repr(float(x)); return len(s.split('.')[1]) if '.' in s else 0
L=B[B.value.map(ndec)>=4].copy(); L['traj']=L.block+'|'+L.group+'#'+L.animal.astype(str)
import itertools
tot=same=0
for (i,a),(j,b) in itertools.combinations(L.iterrows(),2):
    if a.traj==b.traj: continue
    tot+=1; same+= (a.day==b.day)
print('\nlong-decimal cells',len(L),'cross-trajectory pairs',tot,'same-day share of opportunities %.3f'%(same/tot))
hits=H[~H.offset.eq(0)|True]
print('share of fractional-part matches that are same-day: %.3f'%(H.same_day.mean()))
print('blocks involved in cross-block fractional matches:', sorted(set(H[H.cross_block].b1)|set(H[H.cross_block].b2)))
print('number of cross-block pairs:',H.cross_block.sum(),' exact-equal cross-block:',(H.cross_block&(H.offset.abs()<1e-5)).sum())

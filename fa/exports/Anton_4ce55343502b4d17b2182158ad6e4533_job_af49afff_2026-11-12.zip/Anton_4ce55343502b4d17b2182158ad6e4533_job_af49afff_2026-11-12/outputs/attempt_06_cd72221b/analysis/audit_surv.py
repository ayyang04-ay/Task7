import pandas as pd, itertools
S = pd.read_csv('tidy_survival.csv')
# signature of each group = sorted list of (time,event)
sig = {}
for (b,g),d in S.groupby(['block','group'],sort=False):
    sig[(b,g)] = tuple(sorted(zip(d.time.fillna(-1), d.event)))
# 1. whole-block identity
blocks = S.block.unique()
for b1,b2 in itertools.combinations(blocks,2):
    g1=[g for (b,g) in sig if b==b1]; g2=[g for (b,g) in sig if b==b2]
    if g1==g2 and all(sig[(b1,g)]==sig[(b2,g)] for g in g1):
        print('IDENTICAL BLOCKS:', b1, b2)
# 2. group-level identity for groups with >=2 deaths (all-survivor groups trivially match)
print('\nIdentical non-trivial group signatures across different blocks:')
items=[(k,s) for k,s in sig.items() if sum(e for _,e in s)>=2]
for (k1,s1),(k2,s2) in itertools.combinations(items,2):
    if k1[0]!=k2[0] and s1==s2:
        print(' ',k1,'==',k2, [t for t,e in s1 if e==1])

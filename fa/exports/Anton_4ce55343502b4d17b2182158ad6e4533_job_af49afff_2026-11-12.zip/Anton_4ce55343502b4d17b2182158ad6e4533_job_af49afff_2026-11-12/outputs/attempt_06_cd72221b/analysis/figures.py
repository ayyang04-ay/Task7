import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import os
OUT = '/tmp/outputs/figures'; os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150})
C = {'Sham': '#9e9e9e', 'PSLN-212': '#4a90d9', 'PSLN-344': '#d62728', 'PSLN-212(Y)': '#2ca02c', 'CMP-204': '#ff7f0e'}

# ------------------------------------------------------------------ Fig 1 survival forest
F = pd.read_csv('/tmp/work/surv_forest.csv')
P = pd.read_csv('/tmp/work/surv_pooled.csv')
fig, axes = plt.subplots(1, 2, figsize=(11, 5.6), gridspec_kw=dict(width_ratios=[1.25, 1]))
order = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N']
desc = {'S03-I': 'S03-I  homologous CA09, d14', 'S03-J': 'S03-J  wt H5N1, d2 (homol. HA)', 'S06-A': 'S06-A  H3 vax -> PR8, d14',
        'S06-B': 'S06-B  H3 vax -> PR8, d3', 'S06-C': 'S06-C  bivalent -> rgH5N1, d14', 'S06-D': 'S06-D  bivalent -> rgH5N1, d3',
        'S06-E': 'S06-E  H3 vax -> PR8, d60', 'S06-F': 'S06-F  bivalent -> rgH5N1, d60', 'S06-G': 'S06-G  H1 vax -> Perth H3, d60',
        'S15-L': 'S15-L  C57BL/6 (challenge n.s.)', 'S15-N': 'S15-N  Swiss Webster (challenge n.s.)'}
for ax, comp, title in [(axes[0], 'PSLN-212', 'Aged: PSLN-344 minus PSLN-212 (the Mn2+ contribution)'),
                        (axes[1], 'PSLN-212(Y)', 'Aged PSLN-344 minus YOUNG PSLN-212 (age gap left)')]:
    ticks = []; labs = []
    for k_, b in enumerate(order):
        y = -k_
        r = F[(F.block == b) & (F.comparator == comp)]
        fl = ''
        rr = F[(F.block == b) & (F.comparator == 'PSLN-212')].iloc[0]
        fl = rr.flag if isinstance(rr.flag, str) and rr.flag.strip() else ''
        ticks.append(y); labs.append(desc[b] + ('  [dup]' if b == 'S06-D' else ('  [!]' if fl else '')))
        if r.empty:
            ax.text(0, y, 'no young arm', fontsize=7, color='grey', va='center', ha='center'); continue
        r = r.iloc[0]
        col = '#b0b0b0' if b == 'S06-D' else ('#e69500' if fl else 'k')
        ax.plot([r.lo, r.hi], [y, y], color=col, lw=1.6)
        ax.plot(r.rd, y, 's', color=col, ms=6)
        ax.text(104 if comp == 'PSLN-212' else 44, y, f"{r.surv_trt} vs {r.surv_cmp}", va='center', fontsize=7.5)
    y = -len(order) - 0.6
    for tier, lab in [('T1', 'Pooled T1 (excl. S06-D duplicate)'), ('T3', 'Pooled T3 (only conflict-free blocks)')]:
        r = P[(P.comparator == comp) & P.tier.str.startswith(tier)].iloc[0]
        ax.fill([r.RD_ci_lo, r.MH_risk_diff_pct, r.RD_ci_hi, r.MH_risk_diff_pct], [y, y + .3, y, y - .3], color=C['PSLN-344'])
        ax.text(104 if comp == 'PSLN-212' else 44, y, f"{r.PSLN344_surv.split()[0]} vs {r.comparator_surv.split()[0]}", va='center', fontsize=7.5, weight='bold')
        ticks.append(y); labs.append(lab); y -= 1
    ax.axvline(0, color='grey', ls='--', lw=.8)
    ax.set_yticks(ticks); ax.set_yticklabels(labs, fontsize=7.5)
    ax.set_xlabel('Survival difference, percentage points')
    ax.set_title(title, fontsize=9.5, loc='left')
    ax.set_xlim((-40, 125) if comp == 'PSLN-212' else (-80, 62))
axes[1].set_yticklabels([])
fig.text(0.01, 0.005, 'Squares: per-experiment difference with Newcombe 95% CI. Diamonds: Mantel-Haenszel pooled difference, 95% CI.\nOrange = block with an integrity conflict (see audit); grey = exact duplicate (S06-D = S06-C). Source: S03, S06, S15 survival blocks (per-animal 1/0 rows).', fontsize=7)
plt.tight_layout(rect=(0, 0.04, 1, 1)); plt.savefig(f'{OUT}/fig1_survival_forest.png', dpi=200); plt.close()

# ------------------------------------------------------------------ Fig 2 immunogenicity panels
R = pd.read_csv('/tmp/work/tidy_continuous.csv')
R.loc[R.block.isin(['S03-C', 'S03-G']) & (R.value == 0), 'value'] = 5
panels = [('S01-A 16h', 'Lung Ifnb1, 16 h\n(fold; S01-A)', 'log'), ('S02-A', 'CCR7+ migratory DC %, 72 h\n(S02-A)', 'lin'),
          ('S04-A ICOShi', 'ICOS-hi Tfh %, d7\n(S04-A)', 'lin'), ('S03-K', 'GC B cells %, d7\n(S03-K)', 'lin'),
          ('S03-C', 'HAI anti-CA09, d14 (S03-C)\ndotted = 1:40; <1:10 plotted at 5', 'log'), ('S03-A', 'IgG titre anti-CA09, d14\n(S03-A)', 'log'),
          ('S05-F', 'IFN-g+ CD8 % (H5N1 restim), d14\n(S05-F)', 'lin'), ('S05-I', 'Lung TRM CD8 %, d25\n(S05-I)', 'lin')]
arms = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
fig, axes = plt.subplots(2, 4, figsize=(11, 5.6))
for ax, (b, t, sc) in zip(axes.flat, panels):
    d = R[R.block == b]
    for i, a in enumerate(arms):
        v = d[d.group == a].value.values
        if len(v) == 0: continue
        x = i + np.linspace(-.12, .12, len(v))
        ax.scatter(x, v, s=14, color=C[a], zorder=3)
        c = 10 ** np.log10(v).mean() if sc == 'log' else v.mean()
        ax.plot([i - .25, i + .25], [c, c], color='k', lw=1.5)
    if sc == 'log': ax.set_yscale('log')
    if b == 'S03-C': ax.axhline(40, ls=':', color='grey')
    ax.set_xticks(range(4)); ax.set_xticklabels(['Sham', '212', '344', '212\nyoung'], fontsize=7.5)
    ax.set_title(t, fontsize=8)
fig.suptitle('Aged mice (Sham, PSLN-212, PSLN-344) vs young PSLN-212: per-animal values, bar = mean (linear) or geometric mean (log)', fontsize=9)
plt.tight_layout(); plt.savefig(f'{OUT}/fig2_immunogenicity.png', dpi=200); plt.close()

# ------------------------------------------------------------------ Fig 3 restoration index
CO = pd.read_csv('/tmp/work/cont_contrasts.csv')
k = CO[(CO.contrast == 'PSLN-344 vs PSLN-212') & CO.restoration_index.notna()].copy()
keep = ['Lung Ifnb1 16 h (fold vs untreated)', 'HAI anti-Aichi d14 (titre)', 'HAI anti-CA09 d14 (titre)', 'Serum IgG anti-CA09 d14 (titre)',
        'Lung CCR7+ migratory CD11b+ DC % (72 h)', 'Neutralising Ab anti-CA09 d14 (titre)', 'Serum IgG anti-Aichi H3N2 d14 (titre)',
        'Lung cDC1 % (72 h)', 'OT-I priming by sorted MLN DC, % divided', 'MLN ICOS-high Tfh % (d7)', 'MLN IFN-g+ CD8, H5N1 restim, % (d14)',
        'MLN IFN-g+ CD8, H5N1 restim, % (d60)', 'Lung CD69+CD103+ TRM CD8 % (d25)', 'MLN germinal-centre B % (d7)', 'Lung GZMB+ CD8 % (d3)',
        'MLN CD11b+ DC CD86+ % (d3)', 'MLN CD11b+ DC CD40+ % (d3)']
k = k[k.readout.isin(keep)].sort_values('restoration_index')
fig, ax = plt.subplots(figsize=(8.5, 5.6))
ys = np.arange(len(k))
ax.hlines(ys, k.RI_boot_lo, k.RI_boot_hi, color='#555')
ax.plot(k.restoration_index, ys, 'o', color=C['PSLN-344'])
ax.set_yticks(ys); ax.set_yticklabels([f"{r} [{b}]" for r, b in zip(k.readout, k.block)], fontsize=7.5)
for x, lab, ls in [(1.0, 'survival RI, homologous d14 (S03-I) = 1.00', '-'), (0.91, 'survival RI, heterosubtypic d14 (S06-A, C) = 0.91', '--'),
                  (0.71, 'survival RI, heterosubtypic d3 (S06-B) = 0.71', '-.'), (0.65, 'survival RI, heterosubtypic d60 (S06-E, F, G) = 0.65', ':')]:
    ax.axvline(x, ls=ls, lw=.9, color='grey', label=lab)
ax.legend(fontsize=6.5, loc='lower right', frameon=True)
ax.axvline(0, color='k', lw=.6)
ax.set_xlabel('Restoration index = (aged PSLN-344 - aged PSLN-212) / (young PSLN-212 - aged PSLN-212)\n(log scale for titres/fold-changes; 95% bootstrap interval, 10,000 resamples)')
ax.set_title('How much of the age gap does Mn2+ close?\n0 = no better than PSLN-212 in aged mice; 1 = young PSLN-212 level', fontsize=9, loc='left')
ax.set_xlim(-0.2, 1.6)
plt.tight_layout(); plt.savefig(f'{OUT}/fig3_restoration_index.png', dpi=200); plt.close()

# ------------------------------------------------------------------ Fig 4 integrity audit
B = pd.read_csv('/tmp/work/tidy_bodyweight.csv')
S = pd.read_csv('/tmp/work/tidy_survival.csv')
fig, axes = plt.subplots(1, 4, figsize=(13, 3.6))
ax = axes[0]
c = B[(B.block == 'S15-C') & (B.group == 'PSLN-344')]; i = B[(B.block == 'S15-I') & (B.group == '3d Vaccine+PSLN-344')]
for a in range(1, 8):
    x = c[c.animal == a].sort_values('day'); y = i[i.animal == a].sort_values('day')
    ax.plot(x.day, x.value, '-', color='#4a90d9', lw=2.2, alpha=.6, label='S15-C PSLN-344 (rgH5N1, d14 challenge)' if a == 1 else None)
    ax.plot(y.day, y.value, '--', color='#d62728', lw=1, label='S15-I Vaccine+PSLN-344 (3 d study)' if a == 1 else None)
ax.set_title('(a) Two different studies, same animals?\n47/56 cells identical; only d14 differs', fontsize=8)
ax.set_xlabel('day post challenge'); ax.set_ylabel('% of d0 weight'); ax.legend(fontsize=6, loc='lower left')
ax = axes[1]
from statsmodels.duration.survfunc import SurvfuncRight
for blk, ls, lw in [('S06-C', '-', 3), ('S06-D', '--', 1.2)]:
    for g in ['Sham', 'PSLN-212', 'PSLN-344']:
        d = S[(S.block == blk) & (S.group == g)]
        sf = SurvfuncRight(d.time.values, d.event.values)
        t = np.r_[0, sf.surv_times, 14]; s = np.r_[1, sf.surv_prob, sf.surv_prob[-1] if len(sf.surv_prob) else 1]
        ax.step(t, s * 100, where='post', ls=ls, lw=lw, color=C[g], alpha=.7 if blk == 'S06-C' else 1,
                label=f'{blk} {g}')
ax.set_title('(b) S06-C (challenge d14) vs S06-D (challenge d3):\nidentical in every group and row', fontsize=8)
ax.set_xlabel('day'); ax.set_ylabel('% surviving'); ax.legend(fontsize=5.5, ncol=2)
ax = axes[2]
a = R[R.block == 'S11-A'].set_index(['group', 'tp', 'animal']).value; b = R[R.block == 'S11-B'].set_index(['group', 'tp', 'animal']).value
j = pd.concat([a, b], axis=1, keys=['A', 'B']).dropna(); same = np.isclose(j.A, j.B)
ax.scatter(j.A[~same], j.B[~same], s=10, color='grey', label=f'different ({(~same).sum()})')
ax.scatter(j.A[same], j.B[same], s=14, color='#d62728', label=f'identical ({same.sum()})')
ax.plot([10, 55], [10, 55], 'k:', lw=.7)
ax.set_xlabel('S11-A alveolar macrophages %'); ax.set_ylabel('S11-B neutrophils %')
ax.set_title('(c) Two different cell types,\nsame per-animal values in 35/100 cells', fontsize=8); ax.legend(fontsize=6)
ax = axes[3]
ax.bar([0, 1], [18.0, 91.5], color=['#9e9e9e', '#d62728'])
ax.set_xticks([0, 1]); ax.set_xticklabels(['expected if\nindependent', 'observed'], fontsize=7.5)
ax.set_ylabel('% of matching pairs at the same day')
ax.set_title('(d) 177 body-weight values share 5-dp\nfractions across groups/studies (integer offsets)', fontsize=8)
for x, v in [(0, 18.0), (1, 91.5)]: ax.text(x, v + 2, f'{v:.1f}%', ha='center')
ax.set_ylim(0, 105)
plt.tight_layout(); plt.savefig(f'{OUT}/fig4_integrity_audit.png', dpi=200); plt.close()

# ------------------------------------------------------------------ Fig 5 dose-response + cytokines
fig, axes = plt.subplots(1, 3, figsize=(12.5, 3.8), gridspec_kw=dict(width_ratios=[1, 1.25, 1.25]))
ax = axes[0]
d = R[R.block == 'S08-A']
for g, col in [('CMP-204', C['CMP-204']), ('PSLN-212', C['PSLN-212']), ('PSLN-344', C['PSLN-344']), ('PSLN-344/R848', '#8c564b')]:
    x = d[d.group == g].copy(); x['tp'] = x.tp.astype(float); m = x.groupby('tp').value.apply(lambda v: 10 ** np.log10(v).mean()).sort_index()
    ax.plot(m.index, m.values, 'o-', color=col, label=g + (' (formulation undefined)' if 'R848' in g else ''))
    ax.scatter(x.tp, x.value, s=6, color=col, alpha=.5)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xticks([1, 5, 10, 20, 40]); ax.set_xticklabels([1, 5, 10, 20, 40])
ax.set_xlabel('adjuvant dose, ug per mouse'); ax.set_ylabel('lung Ifnb1, fold (16 h)'); ax.legend(fontsize=6)
ax.set_title('(a) S08-A dose-response: PSLN-344 10 ug (21x)\n> PSLN-212 40 ug (15x) -> >=4-fold dose-sparing', fontsize=8)
for ax, f, t in [(axes[1], '/tmp/work/cyto_p1.csv', '(b) S09-A panel 1: 16 h (log10 fold, n=3)'),
                 (axes[2], '/tmp/work/cyto_p2.csv', '(c) S09-A panel 2: printed "16h", Ifnb1 rows = S01-A 72 h')]:
    t_ = pd.read_csv(f, index_col=0).loc[['Ifnb1', 'Ccl2', 'Ccl3', 'Ccl5', 'Il6', 'Tnf', 'Il10']]
    im = ax.imshow(t_.values, cmap='Reds', vmin=-0.5, vmax=3.2, aspect='auto')
    ax.set_xticks(range(t_.shape[1])); ax.set_xticklabels(['PBS', 'CMP-204', 'PSLN-R848', 'PSLN-212', '212/R848', 'PSLN-344', '212 young'], rotation=40, ha='right', fontsize=7)
    ax.set_yticks(range(7)); ax.set_yticklabels(t_.index, fontsize=7.5)
    for (yy, xx), v in np.ndenumerate(t_.values): ax.text(xx, yy, f'{10**v:.0f}' if 10 ** v >= 10 else f'{10**v:.1f}', ha='center', va='center', fontsize=6)
    ax.set_title(t, fontsize=8)
plt.colorbar(im, ax=axes[2], fraction=.04, label='log10 fold')
plt.tight_layout(); plt.savefig(f'{OUT}/fig5_dose_cytokines.png', dpi=200); plt.close()

# ------------------------------------------------------------------ Fig 6 early protection + background mortality
fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.5))
ax = axes[0]
for g, col in [('3d Vaccine', '#9e9e9e'), ('3d PSLN-344', '#ff7f0e'), ('3d Vaccine+PSLN-344', '#d62728')]:
    d = S[(S.block == 'S15-H') & (S.group == g)]
    sf = SurvfuncRight(d.time.values, d.event.values)
    t = np.r_[0, sf.surv_times, 14]; s = np.r_[1, sf.surv_prob, sf.surv_prob[-1]]
    ax.step(t, 100 * s, where='post', color=col, lw=2, label=f"{g} ({int((d.event==0).sum())}/{len(d)})")
ax.set_title('(a) S15-H: given 3 d before VN04 rgH5N1 challenge (aged)\nadjuvant alone does NOT protect; antigen + adjuvant does', fontsize=8)
ax.set_xlabel('day post challenge'); ax.set_ylabel('% surviving'); ax.legend(fontsize=7)
ax = axes[1]
labs = ['S06-E', 'S06-F', 'S06-G']
u = [S[(S.block == b) & (S.group == 'Untreated')].event.sum() for b in labs]
p = [S[(S.block == b) & (S.group == 'PSLN-344')].event.sum() for b in labs]
x = np.arange(3)
ax.bar(x - .18, u, .36, color='#9e9e9e', label='Untreated, unchallenged aged (n=7 each)')
ax.bar(x + .18, p, .36, color=C['PSLN-344'], label='PSLN-344, challenged (n=7 each)')
ax.set_xticks(x); ax.set_xticklabels(labs); ax.set_ylabel('deaths within 14 d'); ax.legend(fontsize=7)
ax.set_title('(b) Background mortality: 4/21 (19%) unchallenged aged mice died;\nPSLN-344 d60 deaths 7/21 (Fisher p=0.48 vs untreated)', fontsize=8)
plt.tight_layout(); plt.savefig(f'{OUT}/fig6_early_protection_background.png', dpi=200); plt.close()
print('figures written')

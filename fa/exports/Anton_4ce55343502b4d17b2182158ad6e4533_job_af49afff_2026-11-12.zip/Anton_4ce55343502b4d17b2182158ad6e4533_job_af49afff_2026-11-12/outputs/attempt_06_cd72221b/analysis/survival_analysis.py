"""
Survival analyses for PSLN-344.
Per experiment: final survival (exact CI), Fisher exact, log-rank.
Pooled: Mantel-Haenszel risk difference (stratified by experiment) + stratified log-rank,
under pre-defined sensitivity tiers driven by the integrity audit.
"""
import pandas as pd, numpy as np, json
from scipy import stats
from statsmodels.duration.survfunc import survdiff
from statsmodels.stats.contingency_tables import StratifiedTable
from statsmodels.stats.proportion import proportion_confint

S = pd.read_csv('/tmp/work/tidy_survival.csv')
S['group'] = S.group.str.replace('Naïve', 'Naive')
# one PSLN-344 animal in S03-J has no day value (S03!J46, G46 empty). It is censored (0);
# assign the block's censoring time (21 d) for time-to-event; final-survival analyses unaffected.
miss = S.time.isna()
S.loc[miss, 'time'] = 21.0
S.loc[miss, 'note'] = 'day missing in source (S03!G46); set to 21 = block censoring time'

meta = {  # experiment descriptors (from annotation)
 'S03-I': dict(age='aged', strain='BALB/c', vaccine='bivalent', challenge='CA09 H1N1 10xLD50 (homologous)', day=14, kind='homologous'),
 'S03-J': dict(age='aged', strain='BALB/c', vaccine='rgH5N1', challenge='wt VN04 H5N1 (homologous HA)', day=2, kind='homologous-early'),
 'S06-A': dict(age='aged', strain='BALB/c', vaccine='Aichi H3N2', challenge='PR8 H1N1 5xLD50', day=14, kind='heterosubtypic'),
 'S06-B': dict(age='aged', strain='BALB/c', vaccine='Aichi H3N2', challenge='PR8 H1N1 5xLD50', day=3, kind='heterosubtypic-early'),
 'S06-C': dict(age='aged', strain='BALB/c', vaccine='bivalent', challenge='rgH5N1 5xLD50', day=14, kind='heterosubtypic'),
 'S06-D': dict(age='aged', strain='BALB/c', vaccine='bivalent', challenge='rgH5N1 5xLD50', day=3, kind='heterosubtypic-early'),
 'S06-E': dict(age='aged', strain='BALB/c', vaccine='Aichi H3N2', challenge='PR8 H1N1 5xLD50', day=60, kind='heterosubtypic-durable'),
 'S06-F': dict(age='aged', strain='BALB/c', vaccine='bivalent', challenge='rgH5N1 5xLD50', day=60, kind='heterosubtypic-durable'),
 'S06-G': dict(age='aged', strain='BALB/c', vaccine='CA09 H1N1', challenge='Perth H3N2 5xLD50', day=60, kind='heterosubtypic-durable'),
 "S06-E' (imprinting, rows 71-98)": dict(age='14 mo (imprinting study)', strain='BALB/c', vaccine='bivalent', challenge='PR8 H1N1 5xLD50', day=None, kind='heterologous'),
 "S06-F' (imprinting, rows 71-98)": dict(age='14 mo (imprinting study)', strain='BALB/c', vaccine='bivalent', challenge='Perth H3N2 5xLD50', day=14, kind='heterologous'),
 'S15-H': dict(age='aged', strain='BALB/c', vaccine='bivalent', challenge='VN04 rgH5N1 5xLD50', day=3, kind='heterosubtypic-early'),
 'S15-L': dict(age='aged', strain='C57BL/6', vaccine='bivalent', challenge='not stated', day=None, kind='not stated'),
 'S15-N': dict(age='aged', strain='Swiss Webster', vaccine='bivalent', challenge='not stated', day=None, kind='not stated'),
 'S09-B': dict(age='young', strain='BALB/c', vaccine='Aichi H3N2', challenge='PR8 H1N1 5xLD50', day=21, kind='heterosubtypic'),
 'S09-D': dict(age='young', strain='BALB/c', vaccine='CA09 H1N1', challenge='Perth H3N2 5xLD50', day=21, kind='heterosubtypic'),
 'S09-F': dict(age='young', strain='BALB/c', vaccine='bivalent', challenge='VN04 rgH5N1 5xLD50', day=180, kind='heterosubtypic-durable'),
 'S13-E': dict(age='young', strain='BALB/c', vaccine='as S03-I', challenge='CA09 H1N1 10xLD50', day=14, kind='homologous'),
}


def cp(k, n):
    lo, hi = proportion_confint(k, n, method='beta')
    return lo, hi


def logrank(d, g1, g2, strata=None):
    x = d[d.group.isin([g1, g2])]
    if x[x.group == g1].event.sum() + x[x.group == g2].event.sum() == 0:
        return np.nan, np.nan
    if strata is None:
        chi2, p = survdiff(x.time.values, x.event.values, x.group.values)
    else:
        chi2, p = survdiff(x.time.values, x.event.values, x.group.values, strata=x[strata].values)
    return chi2, p


# ---------------- per-experiment table ----------------
rows = []
for blk, d in S.groupby('block', sort=False):
    for g, x in d.groupby('group', sort=False):
        n = len(x); surv = int((x.event == 0).sum())
        lo, hi = cp(surv, n)
        deaths = x[x.event == 1].time
        rows.append(dict(block=blk, group=g, n=n, survivors=surv, survival_pct=100 * surv / n, ci_lo=100 * lo, ci_hi=100 * hi,
                         median_death_day=(deaths.median() if len(deaths) else np.nan),
                         source=f"{x.cell_event.iloc[0]}..{x.cell_event.iloc[-1]}; days {x.cell_time.iloc[0]}..{x.cell_time.iloc[-1]}",
                         **{k: v for k, v in meta.get(blk, {}).items()}))
PE = pd.DataFrame(rows)

# contrasts per experiment
contr = []
pairs_aged = [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212(Y)'), ('PSLN-212', 'Sham'),
              ('CMP-204', 'Sham'), ('PSLN-344', 'CMP-204'), ('PSLN-344', 'Untreated'),
              ('Naive+PSLN-344', 'Naive+PSLN-212'), ('Imprinting+PSLN-344', 'Imprinting+PSLN-212'),
              ('Imprinting+PSLN-212', 'Naive+PSLN-212'), ('Imprinting+PSLN-344', 'Naive+PSLN-344'),
              ('3d Vaccine+PSLN-344', '3d Vaccine'), ('3d Vaccine+PSLN-344', '3d PSLN-344'),
              ('PSLN-344Y', 'Sham'), ('PSLN-212Y', 'Sham'), ('PSLN-344Y', 'PSLN-212Y'),
              ('PSLN-344(Y)', 'Sham'), ('CMP-204(Y)', 'Sham'), ('Sham', 'Naive')]
for blk, d in S.groupby('block', sort=False):
    gs = set(d.group)
    for a, b in pairs_aged:
        if a in gs and b in gs:
            xa, xb = d[d.group == a], d[d.group == b]
            sa, na = int((xa.event == 0).sum()), len(xa)
            sb, nb = int((xb.event == 0).sum()), len(xb)
            _, pf = stats.fisher_exact([[sa, na - sa], [sb, nb - sb]])
            chi2, plr = logrank(d, a, b)
            contr.append(dict(block=blk, comparison=f'{a} vs {b}', surv_a=f'{sa}/{na}', surv_b=f'{sb}/{nb}',
                              risk_diff_pct=100 * (sa / na - sb / nb), fisher_p=pf, logrank_chi2=chi2, logrank_p=plr))
CT = pd.DataFrame(contr)

# ---------------- pooled analyses (aged BALB/c + other strains), PSLN-344 vs comparator ----------------
aged_blocks = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N']
tiers = {
    'T0 all aged experiments as printed (incl. S06-D duplicate)': aged_blocks,
    'T1 primary: exclude S06-D (exact duplicate of S06-C)': [b for b in aged_blocks if b != 'S06-D'],
    'T2 exclude both S06-C and S06-D (cannot tell which copy is genuine)': [b for b in aged_blocks if b not in ('S06-C', 'S06-D')],
    'T3 exclude every block with a robust survival/weight or annotation conflict (S03-I, S03-J, S06-C, S06-D, S06-E, S06-G, S15-L)':
        [b for b in aged_blocks if b not in ('S03-I', 'S03-J', 'S06-C', 'S06-D', 'S06-E', 'S06-G', 'S15-L')],
}


def mh_rd(tables):
    """Mantel-Haenszel risk difference (survival) with Greenland-Robins variance.
    tables: list of (a=surv_trt, n1, c=surv_ctl, n0)"""
    num = 0; den = 0; var_num = 0
    for a, n1, c, n0 in tables:
        N = n1 + n0
        w = n1 * n0 / N
        p1, p0 = a / n1, c / n0
        num += w * (p1 - p0); den += w
        # Sato (1989) variance estimator components
        var_num += (n1 * n0 / N) ** 2 * (p1 * (1 - p1) / max(n1 - 1, 1) + p0 * (1 - p0) / max(n0 - 1, 1))
    rd = num / den
    se = np.sqrt(var_num) / den
    return rd, rd - 1.96 * se, rd + 1.96 * se


pool = []
for comp in ['PSLN-212', 'Sham', 'PSLN-212(Y)']:
    for tname, blks in tiers.items():
        tabs = []; dd = []
        for b in blks:
            d = S[(S.block == b) & S.group.isin(['PSLN-344', comp])]
            if set(d.group) != {'PSLN-344', comp}:
                continue
            a = int((d[d.group == 'PSLN-344'].event == 0).sum()); n1 = (d.group == 'PSLN-344').sum()
            c = int((d[d.group == comp].event == 0).sum()); n0 = (d.group == comp).sum()
            tabs.append((a, n1, c, n0)); dd.append(d.assign(stratum=b))
        if not tabs:
            continue
        D = pd.concat(dd)
        chi2, p = logrank(D, 'PSLN-344', comp, strata='stratum')
        rd, lo, hi = mh_rd(tabs)
        # MH odds ratio for survival (add 0.5 continuity only if needed for zero cells)
        st = StratifiedTable([np.array([[a + .5, n1 - a + .5], [c + .5, n0 - c + .5]]) for a, n1, c, n0 in tabs])
        tot_a = sum(t[0] for t in tabs); tot_n1 = sum(t[1] for t in tabs); tot_c = sum(t[2] for t in tabs); tot_n0 = sum(t[3] for t in tabs)
        pool.append(dict(comparator=comp, tier=tname, k_experiments=len(tabs), PSLN344_surv=f'{tot_a}/{tot_n1} ({100*tot_a/tot_n1:.0f}%)',
                         comparator_surv=f'{tot_c}/{tot_n0} ({100*tot_c/tot_n0:.0f}%)', MH_risk_diff_pct=100 * rd,
                         RD_ci_lo=100 * lo, RD_ci_hi=100 * hi, MH_OR_survival_cc=st.oddsratio_pooled,
                         OR_ci=str(tuple(np.round(st.oddsratio_pooled_confint(), 1))), strat_logrank_chi2=chi2, strat_logrank_p=p,
                         blocks=', '.join(b for b in blks if b in set(D.stratum))))
PL = pd.DataFrame(pool)

# background mortality in untreated (unchallenged) aged animals
U = S[S.group == 'Untreated']
bg = dict(deaths=int(U.event.sum()), n=len(U), pct=100 * U.event.mean(), ci=tuple(100 * np.array(cp(int(U.event.sum()), len(U)))),
          by_block=U.groupby('block').event.agg(['sum', 'size']).to_dict())

# young: PSLN-344Y vs PSLN-212Y (ceiling) summary
Y = S[S.block.isin(['S09-B', 'S09-D', 'S09-F'])]

with pd.ExcelWriter('/tmp/work/survival_results.xlsx') as w:
    PE.to_excel(w, sheet_name='per_experiment', index=False)
    CT.to_excel(w, sheet_name='contrasts', index=False)
    PL.to_excel(w, sheet_name='pooled', index=False)
PE.to_csv('/tmp/work/surv_per_experiment.csv', index=False)
CT.to_csv('/tmp/work/surv_contrasts.csv', index=False)
PL.to_csv('/tmp/work/surv_pooled.csv', index=False)
json.dump(bg, open('/tmp/work/background_mortality.json', 'w'), indent=1, default=str)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 60)
print(PE[['block', 'group', 'n', 'survivors', 'survival_pct', 'ci_lo', 'ci_hi', 'median_death_day']].to_string(index=False))
print(CT[CT.comparison.str.startswith(('PSLN-344 vs', 'Naive+', 'Imprinting+', '3d', 'PSLN-344Y', 'CMP'))].to_string(index=False))
print(PL.drop(columns=['blocks']).to_string(index=False))
print('background', bg)

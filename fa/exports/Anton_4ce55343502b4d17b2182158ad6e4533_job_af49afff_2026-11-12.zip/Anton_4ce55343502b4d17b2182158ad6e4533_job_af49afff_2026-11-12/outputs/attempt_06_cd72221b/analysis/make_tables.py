import pandas as pd, numpy as np
L=pd.read_csv('ledger.csv'); SU=pd.read_csv('cont_summary.csv'); CO=pd.read_csv('cont_contrasts.csv')
PE=pd.read_csv('surv_per_experiment.csv'); FO=pd.read_csv('surv_forest.csv')
def lid(pat):
    d=L[L.claim==pat]; return d.id.iloc[0] if len(d) else '?'
def fmt(x,sc):
    if sc=='log': return f'{x:,.0f}' if x>=100 else (f'{x:.1f}' if x>=10 else f'{x:.2f}')
    return f'{x:.1f}'
# ---------------- immunogenicity table ----------------
rows=['Lung Ifnb1 16 h (fold vs untreated)','Lung CCR7+ migratory CD11b+ DC % (72 h)','Serum IgG anti-CA09 d14 (titre)','HAI anti-CA09 d14 (titre)',
      'Neutralising Ab anti-CA09 d14 (titre)','Serum IgG anti-Aichi H3N2 d14 (titre)','HAI anti-Aichi d14 (titre)','Neutralising Ab anti-Aichi d14 (titre)',
      'MLN germinal-centre B % (d7)','MLN ICOS-high Tfh % (d7)','MLN IFN-g+ CD8, H5N1 restim, % (d14)','MLN IFN-g+ CD8, H5N1 restim, % (d60)','Lung CD69+CD103+ TRM CD8 % (d25)']
out=['| Readout [block] | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | PSLN-344 vs PSLN-212 (95% CI) | Holm p | RI (95% CI) | PSLN-344 vs young, p | Ledger |','|---|---|---|---|---|---|---|---|---|---|']
for r in rows:
    s=SU[SU.readout==r]; sc=s.scale.iloc[0]; blk=s.block.iloc[0]
    cen=lambda g: (s[s.group==g].geo_mean.iloc[0] if sc=='log' else s[s.group==g]['mean'].iloc[0]) if (s.group==g).any() else np.nan
    c=CO[(CO.readout==r)&(CO.contrast=='PSLN-344 vs PSLN-212')].iloc[0]
    y=CO[(CO.readout==r)&(CO.contrast=='PSLN-344 vs PSLN-212(Y)')].iloc[0]
    eff=(f'{c.estimate:.1f}x ({c.ci_lo:.1f}-{c.ci_hi:.1f})' if sc=='log' else f'+{c.estimate:.1f} pp ({c.ci_lo:.1f} to {c.ci_hi:.1f})')
    yv=(f'{y.estimate:.2f}x, p={y.welch_p:.2g}' if sc=='log' else f'{y.estimate:+.1f} pp, p={y.welch_p:.2g}')
    out.append(f"| {r} [{blk}] | {fmt(cen('Sham'),sc)} | {fmt(cen('PSLN-212'),sc)} | **{fmt(cen('PSLN-344'),sc)}** | {fmt(cen('PSLN-212(Y)'),sc)} | {eff} | {c.holm_p_key_family:.2g} | {c.restoration_index:.2f} ({c.RI_boot_lo:.2f}-{c.RI_boot_hi:.2f}) | {yv} | {lid(r+': PSLN-344 vs PSLN-212')} |")
open('tab_immuno.md','w').write('\n'.join(out)+'\n')
# ---------------- survival table ----------------
desc={'S03-I':'Bivalent -> CA09 H1N1 10xLD50 (homologous), d14','S03-J':'rgH5N1 vaccine -> wild-type VN04 H5N1 (BSL-3), d2','S06-A':'Aichi H3N2 -> PR8 H1N1, d14',
'S06-B':'Aichi H3N2 -> PR8 H1N1, d3','S06-C':'Bivalent -> rgH5N1, d14','S06-D':'Bivalent -> rgH5N1, d3 (DUPLICATE of S06-C)','S06-E':'Aichi H3N2 -> PR8 H1N1, d60',
'S06-F':'Bivalent -> rgH5N1, d60','S06-G':'CA09 H1N1 -> Perth H3N2, d60','S15-L':'C57BL/6, bivalent (challenge not stated)','S15-N':'Swiss Webster, bivalent (challenge not stated)'}
flag={'S03-I':'paired weight block (S13-F) conflicts; lists a Naive group','S03-J':'stated n 9 vs 10; 1 day value missing; weight block (S13-G) conflicts','S06-A':'none found','S06-B':'weights differ by 1 under one dead-animal rule only','S06-C':'identical to S06-D','S06-D':'exact duplicate of S06-C; excluded','S06-E':'weights: PSLN-212 1 vs 0 and PSLN-344 6 vs 5 survivors','S06-F':'none found','S06-G':'weights: PSLN-344 7 (or 5) vs 4 survivors; 3/7 untreated died','S15-L':'weights: young arm 7 vs 6 survivors','S15-N':'weights differ by 1 under one dead-animal rule only'}
out=['| Block | Vaccine -> challenge, interval | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | 344 minus 212, pp (95% CI) | Integrity note |','|---|---|---|---|---|---|---|---|']
for b in ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-D','S06-E','S06-F','S06-G','S15-L','S15-N']:
    p=PE[PE.block==b].set_index('group')
    g=lambda x: f"{int(p.loc[x,'survivors'])}/{int(p.loc[x,'n'])}" if x in p.index else '-'
    f=FO[(FO.block==b)&(FO.comparator=='PSLN-212')].iloc[0]
    out.append(f"| {b} | {desc[b]} | {g('Sham')} | {g('PSLN-212')} | **{g('PSLN-344')}** | {g('PSLN-212(Y)')} | {f.rd:+.0f} ({f.lo:.0f} to {f.hi:.0f}) | {flag.get(b,'none found')} |")
open('tab_surv.md','w').write('\n'.join(out)+'\n')
print(open('tab_immuno.md').read()); print(open('tab_surv.md').read())

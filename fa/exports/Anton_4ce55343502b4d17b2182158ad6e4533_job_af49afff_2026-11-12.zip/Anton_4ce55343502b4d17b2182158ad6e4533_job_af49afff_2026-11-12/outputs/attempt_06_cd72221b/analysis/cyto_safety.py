import pandas as pd, numpy as np
R=pd.read_csv('tidy_continuous.csv'); B=pd.read_csv('tidy_bodyweight.csv')
pd.set_option('display.width',250)
order=['PBS','CMP-204','PSLN-R848','PSLN-212','PSLN-212/R848','PSLN-344','PSLN-212(y)']
for blk,lab in [('S09-A panel 1 (cols A-U)','16 h'),('S09-A panel 2 (cols X-AS)','label says 16 h; Ifnb1 rows = log10 of S01-A 72 h')]:
    d=R[R.block==blk]
    t=d.groupby(['analyte','group']).value.mean().unstack()[order]
    print(f'\n{blk} [{lab}] mean log10 fold (n=3); fold in brackets')
    print(t.round(2).astype(str)+' ('+(10**t).round(1).astype(str)+'x)')
    t.to_csv(f"cyto_{'p1' if 'panel 1' in blk else 'p2'}.csv")
# check panel-2 Ifnb1 vs S01-A 72h on linear scale (relative error)
p2=R[(R.block=='S09-A panel 2 (cols X-AS)')&(R.analyte=='Ifnb1')]
s72=R[R.block=='S01-A 72h']; s16=R[R.block=='S01-A 16h']
mp={'PBS':'Sham','PSLN-212(y)':'PSLN-212(Y)'}
def best(v,pool): return min(abs(10**v-x)/x for x in pool)
e72=[best(r.value,s72[s72.group==mp.get(r.group,r.group)].value.values) for _,r in p2.iterrows()]
e16=[best(r.value,s16[s16.group==mp.get(r.group,r.group)].value.values) for _,r in p2.iterrows()]
print('\nS09-A panel 2 Ifnb1: median rel. error vs nearest S01-A 72h value %.4f (max %.3f); vs 16h %.3f'%(np.median(e72),np.max(e72),np.median(e16)))
p1=R[(R.block=='S09-A panel 1 (cols A-U)')&(R.analyte=='Ifnb1')]
e16b=[best(r.value,s16[s16.group==mp.get(r.group,r.group)].value.values) for _,r in p1.iterrows()]
print('S09-A panel 1 Ifnb1: median rel. error vs nearest S01-A 16h value %.4f (max %.3f)'%(np.median(e16b),np.max(e16b)))
# S08-D post-immunisation weights (tolerability; integrity-flagged)
d=B[B.block=='S08-D']
nad=d[d.day>0].groupby(['group','animal']).value.min().groupby('group').agg(['mean','min','count'])
d10=d[d.day==10].groupby('group').value.agg(['mean','count'])
print('\nS08-D nadir % of d0 (per-animal minimum, d2-d10):\n',nad.round(1)); print('d10 mean, count:\n',d10.round(1))

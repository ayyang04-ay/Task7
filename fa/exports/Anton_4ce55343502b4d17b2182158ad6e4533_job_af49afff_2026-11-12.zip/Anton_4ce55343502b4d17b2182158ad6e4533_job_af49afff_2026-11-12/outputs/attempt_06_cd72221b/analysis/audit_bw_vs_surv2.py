import pandas as pd, numpy as np
exec(open('audit_bw_vs_surv.py').read().split("pairs=[")[0])  # reuse loaders + implied()
B=pd.read_csv('tidy_bodyweight.csv'); S=pd.read_csv('tidy_survival.csv')
def implied2(d,kmin):
    d=d.sort_values('day'); obs=d[d.value.notna()]; days=list(obs.day); vals=list(obs.value)
    if days[-1]<d.day.max(): return False
    k=1
    while k<len(vals) and abs(vals[-1-k]-vals[-1])<1e-9: k+=1
    return not (k>=kmin)
src=open('audit_bw_vs_surv.py').read()
pairs=eval('['+src.split('pairs=[')[1].split(']\nrows')[0]+']')
out=[]
for bwb,svb,mp in pairs:
    bb=B[B.block==bwb]; ss=S[S.block==svb]
    for g,d in bb.groupby('group',sort=False):
        s=ss[ss.group==mp.get(g,g)]
        a3=sum(implied2(a,3) for _,a in d.groupby('animal')); a2=sum(implied2(a,2) for _,a in d.groupby('animal'))
        sv=int((s.event==0).sum()) if len(s) else None
        out.append(dict(bw=bwb,surv=svb,group=g,n_bw=d.animal.nunique(),n_surv=len(s) if len(s) else None,
                        alive_rule3=a3,alive_rule2=a2,surv_alive=sv))
T=pd.DataFrame(out)
T['incons_rule3']=(T.alive_rule3!=T.surv_alive)|(T.n_bw!=T.n_surv)
T['incons_rule2']=(T.alive_rule2!=T.surv_alive)|(T.n_bw!=T.n_surv)
T['robust']=T.incons_rule3&T.incons_rule2
print(T[T.incons_rule3|T.incons_rule2].to_string(index=False))
print('\nrobustly inconsistent groups:',T.robust.sum(),' inconsistent under either rule:',(T.incons_rule3|T.incons_rule2).sum(),' of',len(T))
T.to_csv('bw_vs_surv_sensitivity.csv',index=False)
# S15-C PSLN-344 vs S15-I Vaccine+PSLN-344 side by side
c=B[(B.block=='S15-C')&(B.group=='PSLN-344')].pivot(index='day',columns='animal',values='value')
i=B[(B.block=='S15-I')&(B.group=='3d Vaccine+PSLN-344')].pivot(index='day',columns='animal',values='value')
print('\nS15-C PSLN-344 (cols W-AC rows 23-30):\n',c.to_string()); print('\nS15-I 3d Vaccine+PSLN-344 (cols W-AC rows 72-79):\n',i.to_string())
print('\nCells identical:',int((np.isclose(c.values,i.values)).sum()),'of',c.size)

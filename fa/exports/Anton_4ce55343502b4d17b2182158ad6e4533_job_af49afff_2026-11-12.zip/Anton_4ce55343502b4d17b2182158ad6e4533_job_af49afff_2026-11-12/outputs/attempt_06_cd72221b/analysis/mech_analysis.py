import pandas as pd, numpy as np, itertools
from scipy import stats
exec(open('continuous_analysis.py').read().split("READOUTS = [")[0].split("R = pd.read_csv")[0])  # imports only
R=pd.read_csv('/tmp/work/tidy_continuous.csv')
def g(b,grp,tp=None,an=None):
    d=R[(R.block==b)&(R.group==grp)]
    if tp is not None: d=d[d.tp.astype(str)==str(tp)]
    if an is not None: d=d[d.analyte==an]
    return d.value.values, (d.cell.iloc[0]+':'+d.cell.iloc[-1].split('!')[1] if len(d) else '')
def perm_p(a,b):
    a=np.asarray(a);b=np.asarray(b);pool=np.r_[a,b];n1=len(a);obs=abs(a.mean()-b.mean());c=t=0
    for idx in itertools.combinations(range(len(pool)),n1):
        m=np.zeros(len(pool),bool);m[list(idx)]=True;t+=1;c+=abs(pool[m].mean()-pool[~m].mean())>=obs-1e-12
    return c/t
rows=[]
def comp(label,b,a_grp,b_grp,scale='lin',tp=None,an=None,note=''):
    a,ca=g(b,a_grp,tp,an); bb,cb=g(b,b_grp,tp,an)
    ta,tb=(np.log10(a),np.log10(bb)) if scale=='log' else (a,bb)
    t,p=stats.ttest_ind(ta,tb,equal_var=False)
    est=10**(ta.mean()-tb.mean()) if scale=='log' else ta.mean()-tb.mean()
    rows.append(dict(experiment=label,block=b,A=a_grp,B=b_grp,n=f'{len(a)} vs {len(bb)}',meanA=a.mean(),meanB=bb.mean(),
                     effect=('ratio' if scale=='log' else 'diff'),estimate=est,welch_p=p,perm_p=perm_p(ta,tb),cellsA=ca,cellsB=cb,note=note))
comp('SP-A/D dependence of AM uptake','S01-C','WT','SPA/D')
comp('Liposome vs free dye, AECII uptake','S01-B','AECII/PSLN-SRB','AECII/FreeSRB')
comp('Liposome vs free dye, AECI uptake','S01-B','AECI/PSLN-SRB','AECI/FreeSRB')
comp('AECII vs AECI targeting (PSLN-SRB)','S01-B','AECII/PSLN-SRB','AECI/PSLN-SRB')
comp('Mn effect on AECII uptake (S08-C; integrity flag)','S08-C','AECII-PSLN-344-SRB','AECII-PSLN-SRB')
comp('Encapsulation efficiency PSLN-344 vs PSLN-212','S08-B','PSLN-344','PSLN-212')
comp('PTX blocks antigen+ DC in MLN','S02-C','PSLN-344(Y)','PTX',note='adjuvant in PTX arm not stated')
comp('PTX blocks DC priming of OT-I','S02-E','PSLN-344(Y)','PTX',note='adjuvant in PTX arm not stated')
comp('PSLN-344 aged vs young, antigen+ DC','S02-C','PSLN-344','PSLN-344(Y)')
comp('PSLN-344 aged vs young, DC priming','S02-E','PSLN-344','PSLN-344(Y)')
comp('GM-CSF boosts moDC with PSLN-212','S02-G','PSLN-212+GM-CSF','PSLN-212')
comp('IFNAR needed for moDC (no cDC precursors)','S02-H','WT w/o cDC','IFN w/o cDC')
comp('IFNAR needed for moDC (with cDC precursors)','S02-H','WT w/ cDC','IFN w/ cDC')
comp('GM-CSF partly rescues IFNAR-KO moDC','S02-H','GMCSF','IFN w/o cDC')
comp('GM-CSF rescue vs WT','S02-H','GMCSF','WT w/o cDC')
comp('CCR2 antagonist reduces GZMB+ CD8 (young)','S02-I','PSLN-344(Y)','PSLN-344(Y)+INCB3344')
comp('CCR2 antagonist reduces monocytes','S07-B mono','PSLN-344','PSLN-344+INCB3344')
comp('CCR2 antagonist reduces Ly6C+ macrophages','S07-B Ly6C+Mphi','PSLN-344','PSLN-344+INCB3344')
comp('Gap-junction blocker CBX reduces monocytes','S11-C','CBX-','CBX+')
comp('IFNAR-/- BM: infiltrating monocytes (young)','S12-A','WT to WT','IFNAR-/- to WT')
comp('OT-I proliferation lung: PTX effect','S05-C','Lung','Lung+PTX')
comp('OT-I proliferation MLN: PTX effect','S05-C','MLN','MLN+PTX')
comp('Ly6C+CCR2+ macrophages d5 (x1e5)','S07-A','PSLN-344','PSLN-212',tp=5)
comp('Ly6C+CCR2+ macrophages d10 (x1e5)','S07-A','PSLN-344','PSLN-212',tp=10)
comp('CNS Ifnb1 36h: PSLN-344 vs PBS','S10-A Ifnb1','PSLN-344','PBS',scale='log')
comp('CNS Ifnb1 36h: PSLN-344 vs Sham','S10-A Ifnb1','PSLN-344','Sham',scale='log')
comp('CNS Ifnb1 36h: CT vs PBS','S10-A Ifnb1','CT','PBS',scale='log')
comp('CNS Tnf 36h: PSLN-344 vs PBS','S10-A Tnf','PSLN-344','PBS',scale='log')
comp('CNS Tnf 36h: PSLN-344 vs Sham','S10-A Tnf','PSLN-344','Sham',scale='log')
comp('CNS Tnf 36h: CT vs PBS','S10-A Tnf','CT','PBS',scale='log')
comp('CNS Isg15 36h: PSLN-344 vs PBS','S10-A Isg15','PSLN-344','PBS',scale='log')
comp('CNS Isg15 36h: CT vs PBS','S10-A Isg15','CT','PBS',scale='log')
comp('CNS Isg15 36h: CT vs PSLN-344','S10-A Isg15','CT','PSLN-344',scale='log')
for tp in [0,2,4,6,8]:
    comp(f'Lung monocytes d{tp}','S01-D','PSLN-344','PSLN-212',tp=tp)
    comp(f'Lung CD11b+ DC d{tp}','S01-E','PSLN-344','PSLN-212',tp=tp)
for dose in [1,5,10,20,40]:
    comp(f'Ifnb1 dose {dose} ug: PSLN-344 vs PSLN-212','S08-A','PSLN-344','PSLN-212',scale='log',tp=dose)
M=pd.DataFrame(rows); M.to_csv('/tmp/work/mech_contrasts.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',50)
print(M[['experiment','n','meanA','meanB','effect','estimate','welch_p','perm_p','note']].to_string(index=False,float_format=lambda x:f'{x:.3g}'))

---
title: "PSLN-344 portfolio review: recommendation, evidence and forward plan"
subtitle: "Mn²⁺-coordinated surfactant-biomimetic liposomal STING agonist (CDN-1807), intranasal adjuvant for inactivated influenza A vaccine in older adults"
---

**Evidence base.** `adjuvant_program_dataset.xlsx` (15 sheets) and `adjuvant_program_annotation.pdf` (19 pp), treated as the only source of truth. Bracketed IDs such as [E111] point to rows of **`PSLN-344_evidence_ledger.xlsx`**. For every number used here, the ledger gives the source sheet, block and cell range, the n, and the reduction that was applied. Reduction codes (R-SURV, R-GM, R-AM, R-POOL, R-RI, R-HAI) are defined in Appendix A. Anything that is *not* from our data is boxed and labelled "External context".

---

# 1. Recommendation

> **Advance PSLN-344, conditionally.** Fund a gated confirmation stage of about 9 months. Do **not** fund IND-enabling work (GLP toxicology, GMP manufacture, clinical operations) until Gate 0 (source-data verification, weeks 0–6) and Gate 1 (independent replication plus translational de-risking, ~month 9) have been passed.

**The case in five points**

1. **The efficacy signal is large, consistent and aimed at the right problem.** In aged mice, adding Mn²⁺ turns an adjuvant that fails into one that protects. PSLN-212 (no Mn²⁺) gave 9/73 survivors (12%); PSLN-344 gave 61/73 (84%). That is a Mantel–Haenszel difference of **+71 percentage points (95% CI 60 to 83)**, stratified log-rank p = 9×10⁻²⁰. It spans 10 independent challenge experiments with no between-experiment heterogeneity (I² = 0%) [E111, E122].
   - Restricting to the four experiments with no *robust* integrity conflict gives 22/28 vs 4/28: **+64 pp (43 to 85)**, p = 1.5×10⁻⁷ [E113].
   - Restricting to the two with no conflict of any kind gives 11/14 vs 2/14: +64 pp (34 to 95), p = 2×10⁻⁴ [E140].
   - Against vaccine plus empty liposome ("Sham"), the result is 61/73 vs 1/73 [E115].
2. **The gain is attributable to Mn²⁺, and it acts where ageing breaks the response.**
   - PSLN-344 and PSLN-212 carry the same CDN-1807 in the same lipids (annotation, Materials). PSLN-344 does not carry more of it: encapsulation is 54.8% vs 59.6%, p = 0.29 [M06].
   - In aged lung, Mn²⁺ restores IFN-β induction to the young level: 37× for PSLN-344 vs 17× for PSLN-212, against 37× in young animals; restoration index 0.98 [I194].
   - It closes 75–94% of the age gap (log scale) in HAI, neutralising and IgG antibody, and about 60% of the gap in cross-reactive CD8 T cells. All 13 pre-specified key immune readouts improve (Holm p ≤ 0.01; Table 2).
3. **The data package is not yet fit to carry development money.** The following are documented in Section 3, and anyone who checks the workbook can find them:
   - One survival experiment is an exact duplicate of another, presented as a different study (S06-D = S06-C) [A01].
   - Body-weight values were copied between studies. Fractional parts are reused at integer offsets across ten blocks. One copied group is 47/56 cells identical, and its final day differs in a way that matches each study's own survival table [A02–A05].
   - One flow block is one-third identical to a block reporting a different cell population [A06].
   - Several blocks have rotated or mislabelled groups or timepoints [A08, A09, A11].
   - 4 of 21 unchallenged, untreated aged controls died within 14 days [E134].
4. **The translational risks are untested, not refuted.**
   - Intranasal Mn²⁺ reaching the olfactory tract or CNS has exactly one readout: CNS transcripts at 36 h, n = 5 per group [M25–M33].
   - Human STING activity of CDN-1807 is unknown.
   - No arm benchmarks against a licensed older-adult strategy.
   - All animals are female.
   - No experiment links any immune mechanism to survival.
5. **The open questions are cheap and quick to answer relative to the value at stake.** A source-data audit takes weeks; the confirmation package takes about 9 months. The pre-agreed kill criteria below make this a real decision point, not a deferral.

**Why not an unconditional "yes".** Development-stage spending would rest on a dataset that cannot yet be shown to partners or regulators. The survival result is robust to every exclusion we could make. But the body-weight data show a copy-and-edit pattern that ordinary transcription error does not explain. Until source records are checked, that pattern puts the provenance of the whole workbook in question. There is also no comparator against what older adults already receive, and no evidence yet that the intranasal Mn²⁺ component is safe for the olfactory route.

**Why not "no".** Dropping now gives up the strongest age-specific efficacy signal in the dataset, and it does so on grounds that can be checked quickly. The problems concentrate in body-weight blocks and in individual mechanistic blocks. The primary survival tables and the antibody and T-cell blocks show no duplication under the same tests. The survival effect survives the exclusion of every block with any conflict: +64 pp, p = 2×10⁻⁴ [E140].

**Decision requested**

| Gate | When | Pass (all required) | Kill (any one) |
|---|---|---|---|
| **0. Source-data verification** (independent QA) | weeks 0–6 | Primary survival blocks and key immunogenicity blocks traceable to raw records (≥95% of audited values match); the S06-C/D duplication, the body-weight copying and the label errors explained and corrected | Primary survival data not traceable, or shown to have been altered |
| **1. Confirmation and de-risking** (Studies 1–7, Section 7) | ~month 9 | Blinded independent replication: PSLN-344 minus PSLN-212 ≥ 30 pp, 95% CI excluding 0, in both challenge models, same direction in both sexes. CDN-1807 active on human STING, with Mn²⁺ potentiation ≥2× in human cells. No Mn²⁺ persistence in olfactory bulb or brain at 28 d, and no olfactory or histological finding at 1× dose. PSLN-344 not worse than the clinical benchmark arm | Replication effect < 30 pp or CI including 0. No human STING activity. Persistent CNS Mn²⁺ or neurological or olfactory signal. Benchmark superior on both survival and lung viral load |
| **2. IND-enabling** | months 9–24 | GLP toxicology including nasal, olfactory and CNS histopathology; GMP lot; ferret or aged-NHP bridging | — |

**The forward view in brief** (detail in Sections 4–8)

- **What drives protection.**
  - Mn²⁺-amplified STING signalling restores, in the aged lung, the IFN-β response (to the young level) and GM-CSF induction.
  - These feed an IFNAR-dependent, CCR2-dependent monocyte → moDC programme.
  - That programme restores the antibody arm almost to young level and the cross-reactive CD8 T-cell arm about 60% [I194, I206, M12, M17; Table 2].
  - Protection needs antigen [E138]. Most of the challenge models are heterosubtypic, where HAI cannot be the mechanism.
  - Cross-reactive CD8 T cells are the leading candidate, with Fc-effector antibody as the alternative. Neither has been tested as necessary.
- **Biomarker.** Carry forward:
  - the early nasal type-I IFN/ISG response as a *pharmacodynamic, dose-selection and age-bridging* marker for Phase 1;
  - the conserved-antigen CD8 IFN-γ response as a *candidate correlate* of heterosubtypic protection, to be validated individually in animals;
  - HAI, kept as the *regulatory* anchor. In our data the ≥1:40 threshold did not predict survival [B02].
- **Role in patients.** An intranasal adjuvant for inactivated influenza antigen in adults ≥65. Its differentiation would be restoring young-like HAI plus breadth and speed. It is not a stand-alone prophylactic and not a young-adult product.
- **What we would be dropping.** The only formulation in the dataset that reliably protects aged animals, and a reusable Mn²⁺-STING principle. The reasons for dropping would be the Gate 0 and Gate 1 kill triggers above.

---

# 2. The efficacy case

## 2.1 Survival in aged mice

**Table 1. Survival (survivors/n) at end of observation: 14 days after challenge, 21 days for S03-J. Aged = 20 months unless stated; "Sham" = vaccine + empty liposome (annotation). Sources: per-animal 1/0 rows of S03, S06 and S15. Reduction R-SURV; differences R-RD.**

| Block | Vaccine -> challenge, interval | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | 344 minus 212, pp (95% CI) | Integrity note |
|---|---|---|---|---|---|---|---|
| S03-I | Bivalent -> CA09 H1N1 10xLD50 (homologous), d14 | 0/7 | 0/7 | **7/7** | 7/7 | +100 (50 to 100) | paired weight block (S13-F) conflicts; lists a Naive group |
| S03-J | rgH5N1 vaccine -> wild-type VN04 H5N1 (BSL-3), d2 | 1/10 | 3/10 | **10/10** | - | +70 (29 to 89) | stated n 9 vs 10; 1 day value missing; weight block (S13-G) conflicts |
| S06-A | Aichi H3N2 -> PR8 H1N1, d14 | 0/7 | 1/7 | **6/7** | 7/7 | +71 (19 to 88) | none found |
| S06-B | Aichi H3N2 -> PR8 H1N1, d3 | 0/7 | 0/7 | **5/7** | 7/7 | +71 (21 to 92) | weights differ by 1 under one dead-animal rule only |
| S06-C | Bivalent -> rgH5N1, d14 | 0/7 | 2/7 | **7/7** | 7/7 | +71 (21 to 92) | identical to S06-D |
| S06-D | Bivalent -> rgH5N1, d3 (DUPLICATE of S06-C) | 0/7 | 2/7 | **7/7** | 7/7 | +71 (21 to 92) | exact duplicate of S06-C; excluded |
| S06-E | Aichi H3N2 -> PR8 H1N1, d60 | 0/7 | 0/7 | **5/7** | 7/7 | +71 (21 to 92) | weights: PSLN-212 1 vs 0 and PSLN-344 6 vs 5 survivors |
| S06-F | Bivalent -> rgH5N1, d60 | 0/7 | 1/7 | **5/7** | 7/7 | +57 (6 to 81) | none found |
| S06-G | CA09 H1N1 -> Perth H3N2, d60 | 0/7 | 0/7 | **4/7** | 7/7 | +57 (9 to 84) | weights: PSLN-344 7 (or 5) vs 4 survivors; 3/7 untreated died |
| S15-L | C57BL/6, bivalent (challenge not stated) | 0/7 | 0/7 | **6/7** | 6/7 | +86 (34 to 97) | weights: young arm 7 vs 6 survivors |
| S15-N | Swiss Webster, bivalent (challenge not stated) | 0/7 | 2/7 | **6/7** | 7/7 | +57 (6 to 81) | weights differ by 1 under one dead-animal rule only |

**Pooled (Mantel–Haenszel, stratified by experiment; R-POOL).** The sensitivity tiers come from the integrity audit:

| Tier | Experiments | PSLN-344 | PSLN-212 | Difference, pp (95% CI) | Stratified log-rank | Ledger |
|---|---|---|---|---|---|---|
| T0: everything as printed (double-counts S06-C/D) | 11 | 68/80 | 11/80 | +71 (60 to 82) | p = 2×10⁻²¹ | E110 |
| **T1 (primary): S06-D removed** | 10 | **61/73 (84%)** | **9/73 (12%)** | **+71 (60 to 83)** | **p = 9×10⁻²⁰** | E111 |
| T2: both S06-C and S06-D removed | 9 | 54/66 | 7/66 | +71 (59 to 83) | p = 4×10⁻¹⁸ | E112 |
| T3: only blocks with no robust conflict (S06-A, S06-B, S06-F, S15-N) | 4 | 22/28 | 4/28 | +64 (43 to 85) | p = 1.5×10⁻⁷ | E113 |
| T4: only blocks with no conflict under any rule (S06-A, S06-F) | 2 | 11/14 | 2/14 | +64 (34 to 95) | p = 2.1×10⁻⁴ | E140 |

There is no heterogeneity across experiments: Cochran Q = 4.7 on 9 df, p = 0.86, I² = 0%; Breslow–Day p = 0.95 [E122]. Against Sham, T1 gives 61/73 vs 1/73, +82 pp (73 to 91) [E115]. Figure 1 shows the forest plot.

![Figure 1. Survival differences by experiment and pooled. Left: the Mn²⁺ contribution (PSLN-344 minus PSLN-212, aged). Right: the remaining age gap (aged PSLN-344 minus young PSLN-212).](figures/fig1_survival_forest.png)

## 2.2 How far the effect generalises

- **Strains.** The effect reproduces in C57BL/6 (S15-L: 6/7 vs 0/7) and Swiss Webster (S15-N: 6/7 vs 2/7) [E65, E66, E69, E70], not only BALB/c.
- **Challenge type.** It covers homologous CA09 (S03-I), wild-type H5N1 under BSL-3 (S03-J), and three heterosubtypic pairings: H3 vaccine → H1 challenge (S06-A, B, E), H1+H3 → H5 (S06-C, D, F) and H1 → H3 (S06-G).
- **Speed.** Protection is present when challenge comes 2–3 days after a single dose: S03-J 10/10 vs 3/10, S06-B 5/7 vs 0/7 (Table 1).
- **Early protection needs antigen.** Given 3 days before VN04 rgH5N1 challenge, vaccine alone and PSLN-344 alone each gave 0/7, while vaccine plus PSLN-344 gave 6/7 (Fisher p = 0.0047 against either) [E138] (Figure 6a).
- **Pre-existing immunity does not blunt it.** Mice infected with PR8 at 10 months and vaccinated 4 months later:

  | Arm | Survival [E137] |
  |---|---|
  | Naive + PSLN-344 | 12/14 |
  | Imprinted + PSLN-344 | 12/14 |
  | Naive + PSLN-212 | 0/14 |
  | Imprinted + PSLN-212 | 4/14 |

  PSLN-212 already fails at about 14 months of age.
- **The benefit is age-specific.** In young mice, PSLN-344 and PSLN-212 both give 24/24 against Sham 0/23 (S09-B/D/F, including a day-180 H5N1 challenge) [E136]. Mn²⁺ adds nothing in the young because there is nothing left to add.

## 2.3 What it does not do

- **It does not fully restore aged animals to young.** Pooled, aged PSLN-344 reaches 51/63 against young PSLN-212 at 62/63: −17 pp (−28 to −7) [E119]. The shortfall sits in early and late heterosubtypic settings; the survival restoration index is defined in Appendix A (R-SURV-RI).

  | Setting | Blocks | Survival restoration index | Ledger |
  |---|---|---|---|
  | Homologous, day 14 | S03-I | 1.00 | E128 |
  | Heterosubtypic, day 14 | S06-A, C | 0.91 | E129 |
  | Heterosubtypic, day 3 | S06-B | 0.71 | E130 |
  | Heterosubtypic, day 60 | S06-E, F, G | 0.65 | E131 |
- **Durability is only partly characterised.** PSLN-344 survival was 13/14 at day 14 (S06-A, C) and 14/21 at day 60 (S06-E, F, G); p = 0.11 [E133]. Aged animals have no day-180 data; the only day-180 challenge used young mice (S09-F).
- **Aged controls die without challenge.** 4 of 21 untreated, unvaccinated, unchallenged 20-month controls died within 14 days (19%, 95% CI 5–42%) [E134]. They died at 94–97% of baseline weight, not with influenza-like wasting [A20].
  - At day 60, PSLN-344 survival (14/21) cannot be distinguished from survival of *unchallenged* controls (17/21, p = 0.48) [E135].
  - So the day-60 gap to young may be colony mortality, not vaccine failure, and the current data cannot separate the two.
  - Background deaths do not bias the PSLN-344 vs PSLN-212 comparison, because both arms are exposed equally; the bias is toward the null. They do cap achievable survival in aged arms.
- **Each experiment is small.** Most arms have n = 7. A single experiment can only detect very large effects, so the case rests on replication across experiments, not on any one of them.

![Figure 6. (a) Early protection requires antigen (S15-H). (b) Deaths within 14 days in unchallenged, untreated aged controls vs challenged PSLN-344 animals in the day-60 experiments.](figures/fig6_early_protection_background.png)

## 2.4 Immunogenicity: what Mn²⁺ restores

**Table 2. Aged mice unless "young"; n = 5 per group. Titres and fold-changes are geometric means (R-GM); percentages are arithmetic means (R-AM). HAI below 1:10 was set to 5 (R-HAI). RI = restoration index (R-RI): 0 = aged PSLN-212 level, 1 = young PSLN-212 level.**

| Readout [block] | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | PSLN-344 vs PSLN-212 (95% CI) | Holm p | RI (95% CI) | PSLN-344 vs young, p | Ledger |
|---|---|---|---|---|---|---|---|---|---|
| Lung Ifnb1 16 h (fold vs untreated) [S01-A 16h] | 0.94 | 16.5 | **36.9** | 37.5 | 2.2x (1.8-2.7) | 0.00012 | 0.98 (0.84-1.14) | 0.98x, p=0.82 | I194 |
| Lung CCR7+ migratory CD11b+ DC % (72 h) [S02-A] | 2.5 | 7.3 | **30.7** | 35.0 | +23.4 pp (13.8 to 33.0) | 0.0093 | 0.84 (0.60-1.11) | -4.3 pp, p=0.33 | I222 |
| Serum IgG anti-CA09 d14 (titre) [S03-A] | 55.7 | 393 | **7,305** | 11,959 | 18.6x (9.1-37.9) | 0.00016 | 0.86 (0.72-0.99) | 0.61x, p=0.11 | I246 |
| HAI anti-CA09 d14 (titre) [S03-C] | 7.58 | 45.9 | **368** | 485 | 8.0x (3.9-16.4) | 0.0026 | 0.88 (0.67-1.12) | 0.76x, p=0.4 | I251 |
| Neutralising Ab anti-CA09 d14 (titre) [S03-D] | 52.2 | 418 | **3,840** | 6,686 | 9.2x (3.1-27.2) | 0.0093 | 0.80 (0.52-1.07) | 0.57x, p=0.27 | I256 |
| Serum IgG anti-Aichi H3N2 d14 (titre) [S03-E] | 52.4 | 426 | **5,701** | 13,855 | 13.4x (6.1-29.6) | 0.0007 | 0.75 (0.59-0.91) | 0.41x, p=0.039 | I261 |
| HAI anti-Aichi d14 (titre) [S03-G] | 10.0 | 34.8 | **320** | 368 | 9.2x (4.2-20.2) | 0.0016 | 0.94 (0.75-1.13) | 0.87x, p=0.61 | I266 |
| Neutralising Ab anti-Aichi d14 (titre) [S03-H] | 39.6 | 276 | **2,533** | 4,411 | 9.2x (3.8-22.1) | 0.0026 | 0.80 (0.58-1.06) | 0.57x, p=0.18 | I271 |
| MLN germinal-centre B % (d7) [S03-K] | 1.2 | 2.3 | **6.5** | 9.8 | +4.2 pp (2.3 to 6.1) | 0.0093 | 0.56 (0.36-0.88) | -3.3 pp, p=0.076 | I308 |
| MLN ICOS-high Tfh % (d7) [S04-A ICOShi] | 0.3 | 3.8 | **10.3** | 13.6 | +6.4 pp (2.6 to 10.3) | 0.0093 | 0.66 (0.41-0.94) | -3.4 pp, p=0.078 | I316 |
| MLN IFN-g+ CD8, H5N1 restim, % (d14) [S05-F] | 0.7 | 1.5 | **6.4** | 9.2 | +4.9 pp (3.6 to 6.1) | 0.0012 | 0.63 (0.52-0.75) | -2.8 pp, p=0.0016 | I344 |
| MLN IFN-g+ CD8, H5N1 restim, % (d60) [S05-G] | 1.5 | 3.0 | **9.9** | 14.4 | +6.8 pp (3.4 to 10.3) | 0.0093 | 0.60 (0.39-0.86) | -4.5 pp, p=0.038 | I348 |
| Lung CD69+CD103+ TRM CD8 % (d25) [S05-I] | 0.6 | 1.0 | **4.0** | 6.0 | +3.0 pp (2.2 to 3.7) | 0.00068 | 0.59 (0.48-0.70) | -2.1 pp, p=0.00068 | I356 |

With n = 5 vs 5, the smallest possible exact permutation p is 0.0079. 12 of the 13 PSLN-344 vs PSLN-212 contrasts reach that floor, meaning every PSLN-344 animal exceeded every PSLN-212 animal. The exception is CA09 neutralising antibody, p = 0.016 (ledger I-rows).

**The pattern across Table 2:**

- **Antibody is restored to young-like levels.** HAI, neutralising antibody and anti-CA09 IgG in aged PSLN-344 are statistically indistinguishable from young PSLN-212 (e.g. HAI 0.76× young, p = 0.40) [I253].
- **T-cell readouts are not.** They stay significantly below young: cross-reactive IFN-γ⁺ CD8 at d14 −2.8 pp (p = 0.0016); lung TRM −2.1 pp (p = 0.0007) [I346, I358].

**Supporting readouts (PSLN-344 vs PSLN-212, aged)**

| Readout | PSLN-344 | PSLN-212 | Effect (95% CI) | Ledger |
|---|---|---|---|---|
| Post-boost IgG d28, anti-CA09 (GMT) | 15,651 | 4,411 | 3.5× (1.5–8.4) | I294 |
| Post-boost IgG d28, anti-Aichi (GMT) | 12,435 | 1,086 | 11.5× (4.1–32.4) | I299 |
| MLN B-cell Aicda, d5 (fold; n = 3) | 11.6× | 3.3× | 3.5× (1.8–6.9) | I312 |
| MLN Tfr (Foxp3⁺ of CXCR5⁺ICOS^hi), d7 | 10.8% | 26.7% | −15.9 pp (−24.0 to −7.7) | I324 |
| Lung Treg, d7 (n = 3) | 3.0% | 6.7% | −3.7 pp (−4.5 to −2.8) | I332 |
| Lung cDC1, 72 h | 37.5% | 22.8% | +14.7 pp (6.1 to 23.3) | I212 |
| DC priming of OT-I cells (% divided) | 18.7% | 0.8% | +17.9 pp (14.4 to 21.4) | I242 |

- Aicda (S03-L) and lung Treg (S04-D) have n = 3 per group; for n = 3 vs 3 the smallest possible permutation p is 0.10.
- **IgG subclass skew depends on correcting mislabelled groups.** After correcting the rotated group labels in S03-B/F (Section 3, finding 8), PSLN-344 is Th1-skewed: IgG2a/IgG1 geometric mean 1.85 vs 0.54 for PSLN-212 and 2.50 for young [I276]. Read as printed, the same block would suggest the opposite.

![Figure 2. Key readouts, per animal.](figures/fig2_immunogenicity.png)

![Figure 3. Restoration index by readout, set against the survival restoration index by challenge setting.](figures/fig3_restoration_index.png)

## 2.5 Why the active ingredient is Mn²⁺

- **Same payload and carrier.** PSLN-212 and PSLN-344 differ only in Mn²⁺ (annotation, Materials). CDN encapsulation is not higher in PSLN-344 (54.8% vs 59.6%, p = 0.29) [M06].
- **Not explained by more uptake.** The only Mn²⁺ comparison of alveolar-cell uptake (S08-C) points the other way: 3.8% vs 15.8% of AECII [M05]. That block shares values with S01-B [A07] and is not relied on.
- **Dose-sparing.** At 10 µg, PSLN-344 induces more lung Ifnb1 (21×) than PSLN-212 does at 40 µg (15×), i.e. at least 4-fold dose-sparing. At 1 µg the two do not differ (1.38× vs 1.36×) [M44, M46, M48] (Figure 5a).
- **Mn²⁺-specific GM-CSF induction.** Lung Gm-csf is 4.2–5.4× higher with PSLN-344 than with PSLN-212 at 16–36 h [I206, I208]. GM-CSF alone raises monocyte-derived DC numbers when added to PSLN-212 (+8.0 pp) [M11].

## 2.6 Tolerability and safety signals in the data

- **Weight after vaccination (no challenge; S08-D).**

  | Arm | Mean per-animal nadir (% of d0) | Note | Ledger |
  |---|---|---|---|
  | Vaccine alone | 98.2% | — | M152 |
  | PSLN-344 | 96.4% | lowest animal 94.2% | M151 |
  | PSLN-212/R848 | 90.0% | one animal missing by day 10 | M150 |

  S08-D is implicated in the body-weight copying pattern [A04], so these values are indicative only.
- **CNS at 36 h (S10-A).** PSLN-344 did not differ from empty-liposome vehicle for Ifnb1 (1.14×, p = 0.57) or Tnf (1.2×, p = 0.36). Against PBS it showed a small Tnf elevation (1.57×, p = 0.033), which the vehicle shares. The cholera-toxin positive control induced Ifnb1 5.5×, Tnf 3.4× and Isg15 2.7× [M25–M33].
- **Inflammatory quality in aged lung (S09-A).** At 16 h, aged PSLN-344 reproduces the young chemokine and IFN-β profile. It carries more Tnf (40× vs 14×) and Il10 (7.3× vs 1.8×) than young PSLN-212 [M96, M97, M82, M83]. At 72 h it still shows Tnf 8.4× and Il6 7.2×, where the young response has resolved (Tnf 0.5×, Il6 3.1×) [M145, M146, M138, M139]. Lung Ifnb1 at 72 h is 2.85× the young level [I202] (Figure 5; the 72 h panel is S09-A panel 2, relabelled per finding 9). This prolonged inflammatory tail in aged animals is the reactogenicity signal to design the clinic around.
- **What does not exist:** lung or nasal histopathology, systemic cytokines, Mn²⁺ tissue levels, repeat-dose data, male animals.

![Figure 5. (a) Dose-response of lung Ifnb1 (S08-A). (b, c) Lung cytokine transcripts at 16 h and 72 h (S09-A).](figures/fig5_dose_cytokines.png)

---

# 3. Data-integrity audit: what the committee will find if it checks

Every block was extracted with cell-level provenance and tested four ways:

- exact duplication within and across blocks;
- reuse of fractional parts in computed values;
- consistency between each survival table and its paired body-weight table;
- cross-checks between the workbook and the annotation.

**Table 3. Findings, ordered by consequence.**

| # | Finding | Evidence | Consequence and handling |
|---|---|---|---|
| 1 | **Duplicate survival experiment** [A01] | S06-C (challenge at d14) and S06-D (challenge at d3) are identical in every group, animal and row order (28 animals) | At most one is genuine. S06-D excluded from the primary analysis (T1); both excluded in T2 (effect unchanged) |
| 2 | **Body-weight group copied between studies** [A02] | S15-C PSLN-344 vs S15-I "3d Vaccine+PSLN-344": 47/56 cells identical. Day 14 differs in all 7 animals: one animal frozen at 77.9% in S15-I (matching that study's day-12 death) but shown at 90.1% in S15-C (matching that study's 7/7 survival) | Body weights are not independent evidence. Not used for efficacy |
| 3 | **Body-weight trajectories reused across strains and studies** [A03] | S09-E young BALB/c PSLN-344 animals 2–7 equal S15-M young C57BL/6 PSLN-212 animals 1–6 (4–7 identical values each). S15-A PSLN-344 #2–3 equal S15-M PSLN-344 #2–3 | As above |
| 4 | **Fractional-part reuse at integer offsets** [A04] | 177 pairs of long-decimal weights in different groups or studies share the same 5-decimal fractional part, offset by whole numbers (e.g. 96.52941176 / 99.52941176; 88.423077 / 94.423077 / 87.423077 / 89.423077 / 92.423077). 91.5% fall on the same day against 18.0% expected if coincidental; 129/177 share both day and animal column. Involves S08-D, S09-E, S15-A, C, E, F, J, K, M, O (Figure 4d) | Not explainable by transcription error; the pattern is consistent with values having been copied and then edited. The workbook cannot establish the cause. **Refer to QA as a formal data-integrity review before any external use** |
| 5 | **Weight and survival tables disagree** [A05] | 12 of 67 groups disagree under both dead-animal rules, 18 under at least one. E.g. S15-D shows PSLN-344 and young PSLN-212 at 5/7 each, where S06-D reports 7/7 each. S13-G Sham 5–8/10 alive, depending on the rule, vs S03-J Sham 1/10 | Survival tables used as primary. Affected blocks excluded in tiers T3 and T4 (effect +64 pp in both) |
| 6 | **Flow block copied** [A06] | S11-A (alveolar macrophages) and S11-B (neutrophils) identical in 35/100 per-animal cells (animals 1–2 of every group, every day); the rest correlate at r = 0.81 | S11-A and S11-B not used |
| 7 | **Uptake block overlaps another** [A07] | S08-C shares 3/5 values with S01-B, and its "AECII-PSLN-344" column resembles S01-B's AECI column | S08-C not used |
| 8 | **Rotated labels** [A08] | Each of the six S03-B/F IgG2a/IgG1 columns equals the S13-A–D quotient of a *different* group (maximum relative difference 0.07%). S13 labels agree with total IgG (S03-A/E) | Corrected to S13 labels. As printed, the block would invert the Th1/Th2 conclusion |
| 9 | **Mislabelled timepoint** [A09] | S09-A panel 2 is printed "16h", but its Ifnb1 rows are log10 of the S01-A **72 h** values (median error 0.1%, vs 76% against 16 h). The same numbers are labelled "Sham" in S01-A and "PBS" in S09-A | Treated as 72 h |
| 10 | **Derived block presented as a measurement** [A10] | S04-B "Tfh:Tfr" = (100 − Foxp3%)/Foxp3% of the adjacent block | Not counted as corroboration |
| 11 | **Unassignable labels** [A11] | S07-C: both columns labelled "Ly6C⁻CD206⁺ MΦ" although two populations were transferred | Macrophage → Treg claim not used |
| 12 | **Method and strain inconsistency** [A12] | S05-A/B: 2 animals per group (3 stated); NP366-374 tetramer reported in BALB/c; conditions list both ovalbumin and bivalent vaccine | Not used |
| 13 | **n mismatches** [A13] | S03-J: 9 stated, 10 present, one day value missing. S13-E: 5 stated, 7 present. The 7-animal Sham group is in S09-F, not S09-B as annotated | Data used as present; noted |
| 14 | **Groups that do not exist in the parent study** [A14] | S13-F ("animals of S03-I") lists "Naive" and no CMP-204. S13-G ("animals of S03-J") lists "Naive" and no PSLN-212 | S13-F/G not used |
| 15 | **Background mortality** [E134, A20] | 4/21 untreated, unchallenged aged controls died within 14 d, without weight loss | Caps achievable survival; confounds the day-60 gap to young |
| 16 | **Undocumented content** [A15–A19] | Unlabelled survival-like region (S08 rows 89–101). Red-formatted empty cells (S01, S08). Undefined "PSLN-344/R848". S10-A described as mean ± SD but holding 5 per-animal values. Challenge virus, dose and timing not stated for S15-L/N | Noted; S15-L/N used with caveat |

**What survives the audit.**

- The primary survival tables: their conclusion is unchanged across tiers T0–T4.
- The antibody, germinal-centre, Tfh and CD8 blocks behind Table 2. Blocks S03-A/C/D/E/G/H, S03-K, S04-A, S05-D–I, S13-A–D/I/J and S14-A show no duplication under the same tests.

Not finding duplication is not the same as verification, which is why Gate 0 comes first.

![Figure 4. Integrity audit: (a) a body-weight group copied between two studies; (b) S06-C and S06-D identical; (c) S11-A vs S11-B; (d) fractional-part reuse concentrated on the same day.](figures/fig4_integrity_audit.png)

---

# 4. What is actually driving protection

**Short answer.**

- Mn²⁺ amplifies STING signalling in the aged lung. This restores a type-I-IFN / GM-CSF → monocyte-derived DC programme that ageing blunts.
- That programme feeds two effector arms:
  - a **lymph-node antibody arm**, restored almost to young level (RI 0.75–0.94; Table 2);
  - a **lung-local, cross-reactive CD8 T-cell arm**, about 60% restored (RI 0.59–0.63) [I344, I348, I356].
- Protection depends on antigen.
- In most of our challenge models the protection cannot be HAI antibody. The best-supported candidate is cross-reactive CD8 T cells; non-neutralising Fc-effector antibody is the alternative.
- **No experiment has yet tested whether any of these is necessary for survival.**

**The evidence chain** (Figure 7). Green steps in the figure are supported by a perturbation in our data; yellow steps are correlative only.

1. **Delivery.** Surfactant-mimetic liposomes reach AECII cells: 15.8% vs 0.4% for free dye [M02]. Alveolar-macrophage uptake depends on SP-A/D: 43% in wild-type vs 13% in *Sftpa1⁻/⁻Sftpd⁻/⁻* mice [M01].
2. **Mn²⁺-amplified STING.** Ifnb1 rises 2.2× over PSLN-212 and reaches the young level [I194]; the effect is dose-sparing [M46, M48]. Gm-csf rises 4–5× [I206, I208].
3. **Monocyte recruitment.** Lung monocytes at day 4: 31% vs 17% [M38]. Recruitment is CCR2-dependent (INCB3344: 9.9% → 3.3%) [M17] and gap-junction-dependent (carbenoxolone: 7.3% → 3.1%) [M19].
4. **moDC differentiation** is IFNAR-dependent (IFNAR-KO marrow: 19.7% → 2.1%) [M12] and GM-CSF-responsive. Adding GM-CSF to PSLN-212 gives +8.0 pp [M11]; GM-CSF partly rescues IFNAR-KO (12.4% vs 2.1%) [M14]. In the same period PSLN-212 accumulates Ly6C⁺CCR2⁺ macrophages, which PSLN-344 does not: 19.0 vs 3.4 ×10⁵ at day 5 (n = 3) [M23].
5. **Arm A, antibody.**
   - Migratory CCR7⁺ DCs: 31% vs 7% [I222].
   - Antigen-bearing DCs in MLN: 7.1% vs 1.8%; blocked by pertussis toxin [I230, M07].
   - Tfh up and Tfr down (Table 2; [I324]); germinal-centre B cells and Aicda up.
   - HAI and neutralising antibody reach young-like levels.
6. **Arm B, CD8.**
   - Proliferation of transferred OT-I cells in lung is unaffected by pertussis toxin (59% vs 55%, p = 0.57), whereas in MLN it falls from 31% to 7% (n = 3) [M21, M22]. That is consistent with CD8 priming inside the lung that does not need Gi-dependent DC migration. Pertussis toxin also affects T-cell trafficking, so this is supportive evidence, not proof.
   - At day 3: Ki-67⁺ CD8 9.4% vs 3.5%; GZMB⁺ CD8 5.7% vs 3.0% [I336, I340].
   - GZMB⁺ CD8 depends on CCR2 (shown in young mice; 6.8% → 1.4%) [M16].
   - Cross-reactive IFN-γ⁺ CD8 after H5N1 restimulation at days 14 and 60, and lung TRM at day 25, are restored about 60% [I344, I348, I356].

**Why the protection in most of our models cannot be HAI antibody**

- Of the 10 independent aged experiments in Table 1, 6 are heterosubtypic (S06-A, B, C, E, F, G), 2 are homologous (S03-I, S03-J), and 2 do not state the challenge (S15-L/N). The 3-day study (S15-H) and both imprinting challenges are also heterosubtypic or antigenically distant.
- In the heterosubtypic pairings, antibody to the vaccine HA cannot inhibit the challenge virus's HA: H3 vaccine → H1 challenge; H1 → H3; H1+H3 → H5.
- Even in the homologous model, the conventional human HAI threshold of ≥1:40 did not predict survival. PSLN-212 animals had HAI ≥ 1:40 in 5/5, yet 0/7 survived homologous challenge [B02, Table 1].

**Why the protection is not simply innate**

- PSLN-344 without antigen gave 0/7 at 3 days (S15-H) [E138]. An antigen-independent antiviral state is therefore *not sufficient*.
- It may still contribute.
- S15-H does not rule out antigen-*enhanced* innate synergy, because inactivated virus carries its own PAMPs. Study 1 includes a PSLN-344 + irrelevant-antigen arm to settle this.

**Why CD8 T cells are the leading candidate for heterosubtypic protection**

- Cross-reactive IFN-γ⁺ CD8 T cells are present by day 14 and persist to day 60 [I344, I348].
- Priming can happen in the lung itself [M21].
- The survival restoration pattern mirrors the immune restoration pattern:
  - strain-matched protection (survival RI 1.00) tracks antibody (RI 0.75–0.94);
  - early and day-60 heterosubtypic protection (RI 0.71, 0.65) track the T-cell arm (RI 0.59–0.63) [E128–E131; Figure 3].
- This is consistent with CD8 T cells being rate-limiting, but it is not proof.
- **The alternative, Fc-effector antibody, is equally undecided by our data.** IgG2a rises 19.7× [I282]. For the H5N1 challenges, anti-N1 antibody from the CA09 component is also possible. We have no NA-inhibition data.

**What Mn²⁺ does not fix.**

- DC costimulation: MLN DC CD40⁺ is 11.2% vs 38.7% in young (RI 0.17); CD86⁺ is 14.5% vs 37.9% (RI 0.22) [I234, I238].
- Aged DCs from PSLN-344 mice prime OT-I cells less well than young PSLN-344 DCs: 18.7% vs 31.4% [M10].
- The prolonged inflammatory tail described in Section 2.6.

This is the most likely ceiling on T-cell restoration, and the obvious target for a next-generation formulation.

**What is not established.**

- No depletion, passive-transfer or knockout challenge experiment.
- Several perturbations were run in young animals (S02-I, S12-A) or animals of unstated age (S02-H, S05-C).
- The adjuvant given to the pertussis-toxin arms (S02-C/E) is not stated.
- The macrophage → Treg link (S07-C) cannot be read because of its labels.

![Figure 7. Evidence chain for the mechanism of protection, graded by evidence type.](figures/fig7_mechanism_evidence_chain.png)

---

# 5. Is there a biomarker of efficacy worth carrying forward?

Yes: two are worth carrying forward, in different roles, and a third should be kept as the regulatory anchor. **None is yet validated as a correlate of protection.** In our data, immunology and challenge were always done in different animals, so every biomarker–protection link is group-level.

**Table 4. Candidate biomarkers.**

| Candidate | Does it track protection in our data? | Mechanistic position | Discriminates dose or formulation? | Data quality | Measurable in people? | Verdict |
|---|---|---|---|---|---|---|
| **Early mucosal type-I IFN (lung Ifnb1 at 16 h)** | Group level, partly. Aged PSLN-344 equals young (RI 0.98) [I194]. But CMP-204 (7.7× [I02]) gave 3/7 survival while PSLN-212 (16.5× [I05]) gave 0/7 (p = 0.19) [E139]. PSLN-212/R848 reached 24× [I04] with Il10 179× and Tnf 202× [M81, M95] and was the worst tolerated | Upstream; IFNAR needed for moDC [M12] | **Yes.** Dose-graded from 1 to 40 µg with plateau at 20–40 µg [M44–M48]; separates formulations (S01-A) | Good (S01-A, S08-A; S09-A consistent after relabelling) | Yes: nasal ISG / IFN-β, blood ISG, CXCL10 | **Carry forward as pharmacodynamic / target-engagement biomarker** for dose selection and age-bridging. Not an efficacy surrogate |
| Lung Gm-csf at 16–36 h | Mn²⁺-specific (4–5× vs PSLN-212) [I206, I208]; no young comparator; no survival link | Needed for the moDC step [M11, M14] | Yes (Mn²⁺) | One block, n = 5 | Nasal GM-CSF protein feasible | Secondary PD marker |
| **Cross-reactive IFN-γ⁺ CD8** (heterologous restimulation; d14, d60) | Tracks heterosubtypic survival across arms. At d14: Sham 0.7%, PSLN-212 1.5%, PSLN-344 6.4%, young 9.2% [I344], against H5N1-challenge survival of 0/14, 3/14, 12/14 and 14/14 (S06-C, F). Durable to d60 [I348] | Candidate effector for most of the efficacy claim | Partly (RI 0.6) | Good | Yes: PBMC ELISpot or ICS to conserved NP/M1 peptides | **Carry forward as candidate correlate of heterosubtypic protection.** Validate in Study 3 before using for decisions |
| **HAI / neutralising antibody** | Homologous only. In S03-I, PSLN-344 (GMT 368) and young (GMT 485) both 7/7; **PSLN-212 5/5 ≥ 1:40 yet 0/7** [B02] | Effector for strain-matched challenge | Yes | Good | Standard; the licensure currency | **Keep as regulatory anchor.** Do not assume the ≥1:40 threshold; re-derive it |
| Lung TRM CD8 | Tracks [I356] | Tissue effector | Partly | Good | Only by BAL or nasal sampling | Animal validation marker; exploratory nasal sampling in people |
| Tfh / Tfr | Tracks [I316, I324] | Intermediate | Yes | Tfh:Tfr is a transform of Foxp3% [A10] | cTfh at d7 in blood | Exploratory only |
| IgG2a/IgG1 | Tracks after correction [I276] | Fc function | Yes | Source block label-rotated [A08] | Human subclasses differ | Drop |
| Body weight, alveolar macrophages / neutrophils, NP366 tetramer, CD206⁺ macrophages | — | — | — | Integrity-compromised [A02–A06, A12] or timepoint not stated | — | Drop |

**Could it go into patients, and in what role?**

- **Early nasal IFN/ISG response (16–24 h).** In Phase 1, use it as a *pharmacodynamic and dose-selection endpoint* and as an *age-bridging test*.
  - The question it answers: does intranasal PSLN-344 produce, in adults ≥65, a nasal ISG response at least equal to the response in 18–49-year-olds at the same dose? That mirrors the mouse result in which Mn²⁺ brought aged IFN-β to the young level [I194].
  - It is cheap, fast (24 h), non-invasive and needs small n, so it can be an early go/no-go.
  - Blood ISG score or CXCL10 should run alongside as a systemic safety marker.
  - It should **not** be used to select patients or as a surrogate for efficacy; there is no data for either.
- **Conserved-antigen CD8 IFN-γ response.** In Phase 1/2, use it as an *exploratory immunogenicity endpoint* (PBMC at d14–28). It is promoted to a decision endpoint only if Study 3 shows it predicts survival at the individual level, with AUC ≥ 0.75.
- **HAI and microneutralisation.** Use them as the *regulatory immunogenicity endpoints* for strain-matched protection, benchmarked against a licensed older-adult vaccine.

> **External context (not from our data):** Human STING is polymorphic, and common variants respond differently to cyclic dinucleotides. The murine-selective STING agonist DMXAA failed in people. STING genotype should therefore be recorded in Phase 1 as a possible response modifier, and human-cell activity of CDN-1807 must be shown before first-in-human (Study 4).

---

# 6. Could PSLN-344 go into patients, and in what role?

**Potentially yes**, as an intranasal adjuvant co-administered with an inactivated influenza A antigen for adults ≥65. That is only after Gates 0 and 1 and a GLP package that covers the nasal cavity, olfactory tract and CNS.

**What our data support as its differentiating role**

1. **Restoring strain-matched immunogenicity in older adults to young-adult levels.** HAI RI 0.88–0.94 [I251, I266], with survival restored fully for homologous challenge [E128].
2. **Breadth.** Heterosubtypic protection in aged mice: 13/14 at day 14 against 3/14 for PSLN-212 (S06-A, C). HA antibodies cannot underwrite this claim, so it needs a non-HAI correlate (Section 5).
3. **Speed.** Protection 2–3 days after a single dose [S03-J, S06-B, E138]. This is relevant to outbreak response and pandemic preparedness.
4. **Unaffected by prior exposure.** It works in imprinted animals [E137], as older adults always are.

**Roles the data rule out**

- A stand-alone, antigen-free intranasal prophylactic (0/7 [E138]).
- A product for young adults, where it adds nothing (24/24 vs 24/24 [E136]).
- An R848 combination (IL-10/TNF-dominated, worst tolerated [M150]).
- Any intramuscular claim: the intramuscular route was never tested.

**First indication.** Both options are consistent with the data; the choice is strategic.

- **Option (a), seasonal.** Seasonal inactivated antigen in ≥65-year-olds against a licensed enhanced vaccine. This is the program's stated target population. It must show non-inferior HAI plus a mucosal or T-cell advantage.
- **Option (b), pre-pandemic H5.** H5 antigen in older adults. Our early-protection and wild-type H5N1 data are strongest here [S03-J, E138].
- **Recommendation:** design Phase 1 with seasonal antigen and keep an H5 cohort as an option.

**Clinical risks to design around**

- **Olfactory and CNS exposure to Mn²⁺.** Our data hold only one 36-h transcript readout.
- **A prolonged inflammatory tail in aged lung** (Tnf and Il6 still raised at 72 h; S09-A).
- **Systemic IFN-related adverse events.**
- **STING-genotype non-response.**

> **External context (not from our data):** Manganese is transported along olfactory neurons to the brain. An intranasal inactivated influenza vaccine adjuvanted with *E. coli* heat-labile toxin was withdrawn after cases of facial-nerve (Bell's) palsy. Both history points make nasal, olfactory and CNS safety a gating item for any intranasal adjuvant.

---

# 7. What the next studies must establish

Timing is in months from approval. Aged mice (20–22 months) must be sourced with 6–8 weeks' lead time. The power numbers come from simulation anchored on our pooled estimates, deliberately shrunk [P01–P03].

**Gate 0: source-data verification (weeks 0–6)**

| | |
|---|---|
| Must establish | The efficacy data are traceable and unaltered |
| Population / scope | All 18 survival blocks. Raw weight records behind S08-D, S09, S13-F/G and S15. FCS files for S11-A/B, S01-B, S08-C, S05-A/B (tetramer, strain), S07-C. ELISA and HAI plate records for S03/S13. qPCR run files for S01-A and S09-A. Randomisation and cage records |
| Who | Independent QA; not the generating team |
| Readouts | Share of audited values matching source; explanation for findings 1–16 (Table 3) |
| Go / kill | Go if ≥95% of primary-block values match and the duplications are explained and corrected. Kill if primary survival data are untraceable or altered |

**Study 1: independent, blinded confirmation with a clinical benchmark (months 1–8)**

| | |
|---|---|
| Must establish | PSLN-344 beats PSLN-212 reproducibly in aged mice of both sexes, and how it compares with what older adults already receive |
| Design | Randomised; formulations coded; weighing and euthanasia decisions blinded; humane endpoint pre-registered; SAP pre-registered; run by an independent lab or CRO. Dead animals are recorded as dead, never carried forward |
| Population | 20–22-month BALB/c and C57BL/6, **10 male + 10 female per arm per challenge model**; young (8–10-week) reference arm; age-matched untreated unchallenged controls to measure background mortality |
| Arms / comparators | Vaccine + empty liposome; + PSLN-212 20 µg; + PSLN-344 10 µg; + PSLN-344 20 µg; **benchmark: the same antigen given intramuscularly with a squalene emulsion, and/or an intramuscular high-dose arm**; PSLN-344 + irrelevant antigen (ovalbumin), which tests the antigen-dependence seen in S15-H; young + PSLN-212; untreated |
| Challenges | Homologous CA09 10×LD50 at d14; heterosubtypic (bivalent → rgH5N1, or Aichi → PR8) at d14. Optional d3 and d60/d180 cohorts for speed and durability |
| Primary endpoint | 14-day survival |
| Key secondary | Lung viral titre at d3 and d5 (satellite, n = 5 per arm per time); weight-loss AUC; clinical score |
| Pre-challenge readouts (same animals) | Serum HAI, MN, IgG and IgG subclass at d13; nasal wash and BAL IgA (satellite); blood CD8 ICS, using NP147 tetramer for BALB/c and NP366 for C57BL/6 |
| Power | n = 20 per arm gives 0.80 for 70% vs 20% at two-sided α = 0.025 [P01]. Survival alone is underpowered against an active benchmark (70% vs 40% needs 50 per arm [P02]), so lung viral titre is the benchmark endpoint: a 1 log10 difference needs 9–15 per arm, with the SD *assumed*, not from our data |
| Timing | Day-14 readouts ~month 6; day-60 ~month 8; day-180 ~month 12, outside Gate 1 |
| Go / kill | Go if PSLN-344 minus PSLN-212 ≥ 30 pp with CI excluding 0 in both models, the same direction in both sexes, **and** PSLN-344 non-inferior to the benchmark on lung viral titre (upper 95% CI of the difference < 0.5 log10). Kill if the difference is < 30 pp or its CI includes 0, or if the benchmark is superior on both survival and viral titre |

**Study 2: what is necessary for protection (months 2–8)**

| | |
|---|---|
| Must establish | Whether heterosubtypic protection depends on CD8 T cells, and whether strain-matched protection is antibody-mediated. This turns Section 4 from inference into evidence |
| Design | Aged mice given PSLN-344 20 µg + vaccine. Before challenge: anti-CD8β, anti-CD4, anti-CD20 or isotype. Passive transfer of immune serum from PSLN-344-vaccinated aged donors into naive aged recipients. FTY720 during challenge, to separate TRM from circulating cells. At vaccination: IFNAR-blocking antibody, anti-GM-CSF, INCB3344. Outcomes are survival and viral load, not cell counts |
| Population | Aged BALB/c and C57BL/6, both sexes, n = 10–12 per arm |
| Comparators | Isotype-treated PSLN-344; PSLN-212; Sham |
| Readouts | Survival; lung viral titre at d5; depletion confirmed by flow cytometry |
| Timing | Months 2–8 |
| Decision use | Picks the correlate that goes to the clinic (CD8 vs antibody) |

**Study 3: individual-level biomarker validation (months 2–9, partly nested in Study 1)**

| | |
|---|---|
| Must establish | Whether the early PD marker and pre-challenge immune markers predict *individual* survival |
| Design | PSLN-344 dose titration at 1, 5, 10 and 20 µg (S08-A shows graded Ifnb1 across this range) to spread responses. Non-terminal serial sampling in the same animals: nasal lavage ISG / IFN-β and Csf2 at 16–24 h; blood at d13 (HAI, MN, CD8 ICS); then heterosubtypic challenge sized for ~50% mortality |
| Population | About 120 aged mice (30 per dose), both sexes |
| Analysis | Logistic regression and ROC AUC per marker; mediation of the dose effect through the marker |
| Precision | 30 deaths + 30 survivors gives AUC 0.75 ± 0.12 (95% CI) [P03] |
| Go | A marker with AUC ≥ 0.75 and lower CI bound > 0.6 becomes the Phase 1/2 candidate correlate |

**Study 4: human translatability in vitro (months 1–4)**

| | |
|---|---|
| Must establish | CDN-1807 activates human STING, including common variant alleles, and Mn²⁺ potentiates it as in mouse (2.2× [I194]). The aged → young restoration has a human-cell analogue |
| Design | PBMC, monocyte-derived DCs and air–liquid-interface nasal epithelium from donors aged 20–40 and ≥70, STING-genotyped. Arms: PSLN-344, PSLN-212, free CDN-1807, MnCl₂, empty liposome |
| Readouts | IFN-β, ISG score, CXCL10, GM-CSF; cytotoxicity (LDH); Mn²⁺ uptake |
| Go / kill | Kill if there is no human STING activity or Mn²⁺ potentiation is below 2× |

**Study 5: intranasal Mn²⁺, CNS and local safety, non-GLP (months 1–7)**

| | |
|---|---|
| Must establish | Mn²⁺ from PSLN-344 does not accumulate in olfactory bulb or brain, and causes no olfactory, neurological or nasal injury. CNS IFN / ISG stays at vehicle level at all times, not only at 36 h (S10-A) |
| Design | Aged and young mice, both sexes. Single and repeat (prime–boost, 14 d apart) intranasal dosing at 1× and 3× the intended dose |
| Comparators | PBS; empty liposome; PSLN-212 (no Mn²⁺); equimolar MnCl₂; cholera toxin as CNS-inflammation positive control, as in S10-A |
| Readouts | ICP-MS Mn in olfactory bulb, brain regions, lung, liver and blood at 1, 7 and 28 d; Mn-enhanced T1 MRI in a subset; olfactory behaviour (buried-food test); CNS Ifnb1/Isg15/Tnf at 6 h, 36 h and 7 d; histopathology of nasal cavity, olfactory epithelium and bulb, trigeminal ganglion / facial nerve, and lung; systemic cytokines at 6–24 h |
| Go / kill | Kill if olfactory-bulb Mn stays above vehicle at 28 d, or if there is any neurobehavioural or histological finding at 1× |

**Study 6: contribution of each component (months 1–5)**

| | |
|---|---|
| Must establish | Whether CDN-1807 is needed at all, and whether free Mn²⁺ is enough. This matters for product definition, CMC and IP |
| Arms (aged) | PSLN-344; Mn-liposome without CDN; PSLN-212 + equimolar free MnCl₂; PSLN-212; empty liposome; Mn-content titration (0.25× to 2×) |
| Readouts | Ifnb1/ISG at 16 h, Gm-csf at 36 h, HAI and CD8 IFN-γ at d14; survival in a subset |
| Decision | If Mn-liposome without CDN gives ≥80% of the PSLN-344 effect, simplify the product |

**Study 7: CMC (months 0–9)**

| | |
|---|---|
| Must establish | Reproducible manufacture to specification, with data. Size, PDI, zeta potential and TEM are described in the annotation's methods, but no such data are in the workbook |
| Readouts | Encapsulation (currently ~55% [M06]; set a target); Mn²⁺ and CDN content; endotoxin; sterility; lyophilised stability at −20 °C, 2–8 °C and 25 °C over 3–6 months |

**After Gate 1 (months 9–24)**

- GLP repeat-dose toxicology by the intranasal route, including nasal, olfactory-bulb and CNS histopathology, in rodent plus a second species.
- Safety pharmacology.
- Ferret or aged-NHP immunogenicity and challenge bridging, which also bridges the PD biomarker.
- GMP lot, then IND/CTA.

**Phase 1 outline (from ~month 24)**

| | |
|---|---|
| Design | Randomised, observer-blind, sentinel-dosed dose escalation |
| Populations | Cohort A: 18–49 years. Cohort B: 65–85 years |
| Arms | Inactivated antigen + PSLN-344 intranasally at 2–3 dose levels; antigen intranasally alone; **licensed enhanced intramuscular vaccine for older adults as active comparator** |
| Size | About 20–30 per arm |
| Safety endpoints | Solicited nasal and systemic reactions d0–7. Adverse events of special interest: facial-nerve palsy; smell loss, tested with a validated smell test at baseline, d7, d28 and d180; neurological examination. Blood Mn |
| PD endpoints | Nasal ISG / IFN-β at 16–24 h; serum CXCL10 |
| Immunogenicity endpoints | HAI and MN at d28 and d180; nasal IgA at d28; cTfh at d7; CD8 IFN-γ ELISpot to conserved NP/M1 at d14–28 |
| Exploratory | STING genotype |
| Decision | Nasal ISG response in ≥65-year-olds ≥ that in 18–49-year-olds; HAI non-inferior to the comparator; acceptable safety |

---

# 8. If we drop it: what we would be dropping, and why

**What we would be dropping**

1. **The only formulation in the dataset that reliably protects aged animals.** Survival rises from 12% to 84% over the parent formulation [E111], with full restoration for strain-matched challenge and 0.91 for day-14 heterosubtypic challenge [E128, E129].
2. **A reusable principle: Mn²⁺ potentiation of STING.** It restores the aged IFN-β response to the young level [I194] and spares dose at least 4-fold [M46, M48], so it could be applied to other mucosal antigens.
3. **A mechanism map and two biomarker candidates.** The map runs IFN-I/GM-CSF → moDC → lung CD8/TRM plus Tfh/germinal centre. The biomarkers are the early nasal ISG (PD) and cross-reactive CD8 (correlate candidate). It also identifies what Mn²⁺ does *not* fix: DC costimulation [I234, I238].
4. **Two capabilities that strain-matched HA antibody cannot deliver.** Heterosubtypic breadth, and protection within days of a single dose.

**Why we would drop it** (any one is sufficient, and each is a Gate 0 or Gate 1 kill trigger)

- Source verification fails: the survival data cannot be traced, or were altered.
- The effect does not replicate under blinding, or does not hold in males.
- CDN-1807 is inactive on human STING, or Mn²⁺ does not potentiate it in human cells.
- Mn²⁺ reaches and persists in olfactory bulb or CNS, or causes olfactory or neurological findings.
- A licensed strategy (squalene emulsion or high-dose, intramuscular) matches it on survival and viral load in aged mice, which would leave no differentiation to fund.

**What to preserve if it is dropped**

- The verified data archive.
- The nasal-ISG PD assay.
- The finding that the aged defect has two parts: upstream innate sensing, which Mn²⁺ corrects, and downstream DC costimulation, which it does not. That finding is the starting point for any successor.

---

# 9. What was considered and ruled out

**Alternative formulations in the dataset**

| Formulation | Evidence | Verdict |
|---|---|---|
| CMP-204 (cGAMP liposome) | Aged Ifnb1 7.7× [I02]; anti-CA09 IgG 181 and HAI 23 [I63, I68] vs 7,305 and 368 for PSLN-344; 3/7 survival (S03-I). Works in young (7/7, S13-E) | Inferior in aged; ruled out |
| PSLN-R848 (TLR7/8) | Ifnb1 4.3–4.6× [M72, I03] but Tnf 130× and Il10 29× at 16 h [M93, M79] | Wrong cytokine quality; ruled out |
| PSLN-212/R848 | Ifnb1 24× [I04], but Il10 179× and Tnf 202× [M81, M95], still 45× and 50× at 72 h [M130, M144]. Worst tolerated: nadir 90.0%, one animal missing by d10 [M150] | Ruled out |
| "PSLN-344/R848" (S08-A) | Not a defined preparation; lower Ifnb1 than PSLN-344 at every dose ≥ 5 µg | Not pursued |
| PSLN-212 (parent) | 12% aged survival [E125] | Fails in aged; the reason PSLN-344 exists |

**Alternative explanations for the efficacy**

| Explanation | Test in our data | Verdict |
|---|---|---|
| More CDN payload | Encapsulation 55% vs 60%, p = 0.29 [M06] | Ruled out |
| More uptake | The only comparison (S08-C) shows lower uptake, and that block is flagged | Not supported |
| Non-specific innate antiviral state | Adjuvant alone 0/7 at 3 d [E138] | Ruled out as sufficient; not as a contributor |
| HAI antibody as the sole mechanism | 6 of 10 independent aged experiments in Table 1 heterosubtypic, plus S15-H and the imprinting study; PSLN-212 ≥ 1:40 yet 0/7 | Ruled out |
| Strain artefact | C57BL/6 and Swiss Webster replicate | Ruled out |
| Prior immunity abolishing benefit | Imprinted 12/14 [E137] | Ruled out |
| One experiment driving the pooled effect | I² = 0%; T3 gives +64 pp [E122, E113] | Ruled out |
| The duplicate inflating the result | T1 and T2 match T0 | Ruled out |
| Background mortality creating the difference | Affects both arms equally and biases toward the null. It does confound the gap to young | Ruled out for 344 vs 212; flagged for the gap to young |

**Analyses considered and rejected**

- **Morbidity (weight-loss) endpoints.** Rejected because of integrity findings 2–5.
- **S03-B/F as printed.** Rejected: it would invert the Th1/Th2 conclusion.
- **S09-A panel 2 as 16 h.** Rejected: it is 72 h data.
- **S04-B Tfh:Tfr as independent corroboration.** Rejected: it is a transform of Foxp3%.
- **Pooling S06-C and S06-D as two experiments.** Rejected: they are the same data.
- **Cox models.** Rejected as too few events per stratum; stratified log-rank and Mantel–Haenszel were used instead.
- **Ranking biomarkers by arm-level correlation with survival.** Rejected: with 4–5 arms and every readout moving together, this would "validate" everything. Replaced by the individual-level design in Study 3.
- **Intramuscular or systemic use, and any claim about males.** Rejected: neither was tested.

---

# 10. Anticipated challenges from the committee

**"n = 7 per group is underpowered."** Each experiment on its own is. The pooled effect across 10 independent experiments is +71 pp with I² = 0% [E111, E122]. The most conservative subsets still give +64 pp: four experiments, p = 1.5×10⁻⁷ [E113]; two experiments, p = 2×10⁻⁴ [E140]. Study 1 is powered properly at 20 per arm.

**"The effect is huge; why not just advance?"** Because finding 4 (Table 3) has to be explained by QA before this dataset can be shown to a partner or a regulator. There is also no benchmark against licensed older-adult products and no Mn²⁺/olfactory safety data. Gate 0 costs weeks, not months.

**"The integrity problems are serious; why not drop it?"**

- The problems are concentrated in body weights and in specific mechanistic blocks.
- The survival tables and the immunogenicity blocks pass the same tests.
- The survival conclusion holds when every conflicted block is removed.
- Dropping an asset with this effect size on grounds that can be verified in six weeks is the more expensive error.

**"Is this just an innate IFN effect that won't translate?"** No. Early protection needed antigen [E138]. The innate step does, however, need to be shown on human STING (Study 4).

**"Did the label correction create the Th1 story?"** The correction only affects the derived IgG2a/IgG1 ratios. The IgG2a and IgG1 titres themselves (S13-A–D), together with total IgG, HAI and MN, are separate blocks and agree with the corrected reading.

**"Do aged PSLN-344 mice match young mice?"** For antibody, yes (statistically indistinguishable). For T cells and early or late heterosubtypic survival, no [E119, I346, I358]. The claim we can defend is "restores most of the age gap", not "makes old mice young".

---

# Appendix A. Methods

**Extraction.**

- Each block was read with explicit cell coordinates, checked against the annotation.
- It was stored as per-animal records carrying the source cell for every value: 2,121 continuous values, 514 survival rows (486 after removing the S06-D duplicate), and 3,472 body-weight cells [D01].
- Group labels were kept as printed; the only corrections are those in Table 3.

**Reduction codes.**

- **R-SURV:** survivors / n at end of observation; Clopper–Pearson 95% CI; Fisher exact and log-rank per experiment.
- **R-RD:** survival difference with Newcombe 95% CI.
- **R-POOL:** Mantel–Haenszel risk difference stratified by experiment (Sato variance) and stratified log-rank. Heterogeneity by Cochran Q and Breslow–Day.
- **R-GM:** geometric mean of per-animal values. Contrasts are ratios of geometric means with Welch 95% CI on log10, plus Welch p and exact permutation p over all relabelings.
- **R-AM:** the same on the linear scale, for percentages.
- **R-HAI:** HAI recorded as 0 (below 1:10) set to 5.
- **R-RI:** restoration index (344 − 212)/(212Y − 212) on the analysis scale, with 95% percentile bootstrap (10,000 resamples).
- **R-SURV-RI:** the same for pooled survival proportions.

**Multiplicity.** Holm across the 13 pre-specified key readouts for PSLN-344 vs PSLN-212 (the rows of Table 2). Benjamini–Hochberg across all contrasts is reported in the ledger.

**Audit methods.**

- **Exact duplication:** of survival groups (sorted day/event signatures) and of continuous blocks (position-matched values).
- **Body-weight analysis:**
  - exact same-day matches between trajectories;
  - fractional-part matches among long-decimal values, tested against an opportunity baseline (the share of possible comparisons falling on the same day).
- **Weight–survival reconciliation:** an animal was counted dead if its values stop before day 14, or if its trailing values are identical (LOCF). Two rules were used, ≥2 and ≥3 identical trailing values; "robust" means in conflict under both.
- **Label cross-checks:** derived-quotient matching (S03-B/F vs S13) and log-transform matching (S09-A vs S01-A).

**Software.** Python 3.11: pandas 2.3, SciPy 1.17, statsmodels 0.15, openpyxl 3.1, matplotlib 3.11. All scripts are in `analysis/` and rerun end-to-end from the workbook.

**Limitations of this analysis.**

- Group-level inference only, because immunology and challenge used different animals.
- Small n.
- Timepoints not stated for some blocks.
- The integrity audit detects copying but cannot prove authenticity.

# Appendix B. Deliverables

| File | Content |
|---|---|
| `PSLN-344_portfolio_review.md` / `.docx` | This document |
| `PSLN-344_evidence_ledger.xlsx` | Every number: source cells, n, reduction (sheets D, E, I, M, B, A, P, plus reduction codes) |
| `figures/` | Figures 1–7 |
| `analysis/` | Extraction, audit, statistics and figure scripts; tidy per-animal data with cell provenance; audit outputs (duplicate pairs, fractional-part pairs, weight–survival reconciliation) |

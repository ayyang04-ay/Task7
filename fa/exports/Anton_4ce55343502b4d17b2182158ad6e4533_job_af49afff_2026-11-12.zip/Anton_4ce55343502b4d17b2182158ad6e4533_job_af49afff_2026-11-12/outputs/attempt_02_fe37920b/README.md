# PSLN-344 portfolio review — deliverables

**Start here:** `PSLN-344_portfolio_memo.docx` (or the `.html` / `.md` versions of the same memo).

| Path | What it is |
|---|---|
| `PSLN-344_portfolio_memo.docx` / `.html` / `.md` | The committee memo: recommendation; face-value evidence; integrity findings; anticipated challenges; forward view (what drives protection, biomarker, patient role, next studies with endpoints, populations, comparators, read-outs and timing); options considered and ruled out; methods. |
| `PSLN-344_evidence_workbook.xlsx` | Every number in the memo, traceable:<br>- *Evidence_register* (E01–E81): statement, value, source block, cell range, reduction, statistic, integrity flags.<br>- *QC_log* (QC-01–QC-23).<br>- Full survival and immunology statistics, Tukey (raw vs log), restoration indices.<br>- Body-weight reuse and weight-vs-survival checks.<br>- Block catalogue.<br>- Tidy per-animal data with source cells. |
| `figures/` | Fig 1–7 used in the memo. |
| `analysis/` | Reproducible pipeline. `run_all.sh` runs `01_extract.py` → `06_evidence.py` on the source workbook in the `chem` environment. |
| `tables/` | All intermediate CSV outputs. |

Source data: `adjuvant_program_dataset.xlsx` and `adjuvant_program_annotation.pdf`. Both are treated as ground truth for values; inconsistencies *within* them are reported, not corrected silently.

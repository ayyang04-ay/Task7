---
title: "PSLN-344 (Mn²⁺ surfactant-biomimetic liposomal STING agonist) — Portfolio review: recommendation, evidence case and forward plan"
subtitle: "Intranasal adjuvant for inactivated influenza vaccine in older adults"
date: "Prepared from the program data files: adjuvant_program_dataset.xlsx (15 sheets, 108 data blocks) and adjuvant_program_annotation.pdf (19 pp.)"
---

# 1. Recommendation

**Do not advance PSLN-344 into development (IND-enabling work) on the current data package.** Hold it at research stage. Fund one fixed-scope confirm-or-kill phase of about 9 months, with go/no-go criteria agreed in advance (Section 5.4). Re-review only against those criteria. If the committee needs a binary answer today, the answer is **no**.

I give three reasons, in order of weight.

1. **The package fails a basic data-integrity screen, and the failures touch the efficacy endpoints.** A committee cannot fund development on records that cannot yet be traced to primary data.
   - One survival experiment is an animal-for-animal copy of another: S06-D, the day-3 H5N1 challenge, is identical to S06-C, the day-14 challenge, in 28/28 animals (QC-01).
   - Animal-level body-weight trajectories recur across experiments that are presented as independent, including different mouse strains and different viruses. Weights recorded to 5–8 decimals reappear exactly, or keep the same decimal digits with a changed integer part. 22 trajectory pairs would each occur by chance with p ≤ 1.1 × 10⁻⁹ (QC-03).
   - In 12 survival experiments, animals recorded as dead keep changing weight (QC-04).
   - Two different lung cell populations share per-animal values (QC-02).
   - The group labels on two antibody-ratio blocks are rotated, which reverses their biological reading (QC-06).

2. **Even taken at face value, the package does not answer the questions that decide development.**
   - There is no benchmark against anything older adults can already get (no licensed-class adjuvant, no high-dose antigen).
   - There is no neurosafety work on intranasal Mn²⁺.
   - There is no second species.
   - There is no test of which immune arm actually protects.
   - In aged mice, protection at day 60 is significantly below young mice (14/21 vs 21/21, p = 0.009) [E11].

3. **It is not a kill.** At face value the effect is large, consistent, and tied to the one stated difference between PSLN-344 and its parent PSLN-212 (Mn²⁺).
   - Aged-mouse survival is 83% vs 12% across 8 experiments (49/59 vs 7/59; Mantel–Haenszel risk difference 71 points, 95% CI 59–83) [E01].
   - The immunology is coherent with that effect.
   - Verifying the core claim costs a small fraction of IND-enabling spend and about two to three quarters of time. That is cheap relative to what the asset would be worth if the claim holds.

| | What it would take to say **yes** |
|---|---|
| **G0 (month 2)** | Pivotal survival and immunogenicity records reconcile to primary data; QC-01 to QC-06 are explained. |
| **G1 (month ~7)** | An independent, blinded, randomised replication in aged mice of both sexes: PSLN-344 ≥ 70% survival and superior to PSLN-212, in homologous and fully heterosubtypic challenge. |
| **G2 (month ~7)** | PSLN-344 beats a licensed-class benchmark (squalene oil-in-water i.m., or high-dose antigen i.m.) on lung virus titre in heterosubtypic challenge. |
| **G3 (month ~8)** | No olfactory-bulb or striatal Mn accumulation and no neuropathology at 1–3× the intended dose. |
| **G4 (month ~8)** | The Mn effect reproduces in cells from older human donors and across common STING variants. |

**How to read the numbers.** Every number below carries:

- its source block and cell range;
- how it was reduced;
- an evidence ID (E##) and, where relevant, an integrity ID (QC##). Both resolve in `PSLN-344_evidence_workbook.xlsx` (sheets *Evidence_register* and *QC_log*).

Reduction conventions:

- **Survival:** status at end of observation, survivors/N, exact 95% CI.
- **Pooled survival:** Mantel–Haenszel, stratified by experiment.
- **Titres and qPCR fold-changes:** geometric mean (GM). Contrasts are GM ratios (GMR) with a Welch 95% CI on log₁₀ values. HAI recorded as 0 (<1:10) is set to 5.
- **Flow percentages:** arithmetic means, Welch difference with 95% CI.
- **All contrasts:** also given an exact Mann–Whitney p (n = 5 vs 5, so the minimum is 0.008).
- **Other labels:** "Aged" means ≥ 20 months and "young" 7–8 weeks, female BALB/c unless stated. *PSLN-212* is the identical liposome without Mn²⁺. *Sham* is vaccine plus empty liposome.

---

# 2. The case for the asset, stated at face value

## 2.1 Protection in aged mice

*See Fig 1, Fig 2, and E01–E09.*

**Table 1. Survival to end of observation, aged BALB/c.** Status 1/0 per animal as recorded.

| Experiment (block, cells) | Vaccine → challenge virus, day after vaccination | Sham | PSLN-212 | PSLN-344 | Young PSLN-212 |
|---|---|---|---|---|---|
| S03-I (S03!A16:F51) | Bivalent (CA09 + Aichi) → CA09 10× mLD50, d14 (homologous to the CA09 component) | 0/7 | 0/7 | **7/7** | 7/7 |
| S03-J (S03!G16:J46) | rgH5N1 → wild-type VN04 H5N1, d2 (22-d follow-up) | 1/10 | 3/10 | **10/10** | – |
| S06-A (S06!A2:E30) | Aichi H3N2 → PR8 H1N1, d14 | 0/7 | 1/7 | **6/7** | 7/7 |
| S06-B (S06!G2:K30) | Aichi H3N2 → PR8 H1N1, d3 | 0/7 | 0/7 | **5/7** | 7/7 |
| S06-C (S06!M2:Q30) | Bivalent → rgH5N1, d14 | 0/7 | 2/7 | **7/7** | 7/7 |
| *S06-D (S06!A33:E68)* | *Bivalent → rgH5N1, d3 — identical to S06-C; excluded* | *0/7* | *2/7* | *7/7* | *7/7* |
| S06-E (S06!G33:L68) | Aichi H3N2 → PR8 H1N1, d60 | 0/7 | 0/7 | **5/7** | 7/7 |
| S06-F (S06!M33:R68) | Bivalent → rgH5N1, d60 | 0/7 | 1/7 | **5/7** | 7/7 |
| S06-G (S06!A70:F105) | CA09 H1N1 → Perth H3N2, d60 | 0/7 | 0/7 | **4/7** | 7/7 |
| **Pooled, primary set (8 experiments; S06-D excluded)** | | **1/59 (2%)** | **7/59 (12%)** | **49/59 (83%)** | 49/49 |

Pooled results for the primary set (E01–E03):

- **PSLN-344 vs PSLN-212:** risk difference 71 percentage points (95% CI 59–83) and Mantel–Haenszel risk ratio of death 0.19. The exact stratified test gives p = 3.5 × 10⁻¹⁶. The effect is homogeneous across experiments (Breslow–Day p = 0.95) [E01].
- **PSLN-344 vs Sham:** risk difference 81 points (95% CI 71–91) [E02].

Per-experiment results (E09):

- PSLN-344 beats PSLN-212 in 8/8 experiments.
- Log-rank p ≤ 0.015 in every experiment.
- The weakest single result is S06-G, 4/7 vs 0/7 (Fisher p = 0.07).

**Without Mn²⁺ the same particle barely works in aged mice.** PSLN-212 vs Sham is 7/59 vs 1/59 (exact stratified p = 0.055) [E03]. It delays death but rarely prevents it: median day of death is 6.0 (IQR 6–10), against 5.5 (4–6.8) for Sham [E04].

**Robustness (E05–E08).** The result holds when:

- the other-strain experiments are added: 61/73 vs 9/73, risk difference 71 (60–82) [E05];
- the S03-J animal with a missing time value is counted as a death: 48/59, risk difference 69 (57–82) [E06];
- S03-J is dropped entirely: 39/49 vs 4/49 [E07];
- the test is restricted to mice infection-naive at vaccination, vaccinated at 14 months: 12/14 vs 0/14 [E08].

**The value is entirely in the aged indication.** In young mice PSLN-344 adds nothing: PSLN-212 already protects 100%. The results are 8/8 vs 8/8 in S09-B, S09-D and S09-F (the last with challenge at day 180), and 7/7 for both PSLN-344 and the cGAMP liposome CMP-204 in S13-E [E13].

## 2.2 Antibody responses, day 14

*See Fig 3 and E20–E28.*

| Readout (block, cells) | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | PSLN-344 ÷ PSLN-212, GMR (95% CI) | PSLN-344 ÷ young, GMR (95% CI) |
|---|---|---|---|---|---|---|
| IgG anti-CA09, GM (S03!A2:E7) | 56 | 393 | **7,305** | 11,959 | 18.6 (9.1–37.9) | 0.61 (0.32–1.16) |
| IgG anti-Aichi, GM (S03!A9:E14) | 52 | 426 | **5,701** | 13,855 | 13.4 (6.1–29.6) | 0.41 (0.18–0.94) |
| HAI anti-CA09, GMT (S03!K2:O7) | 8 | 46 | **368** | 485 | 8.0 (3.9–16.4) | 0.76 (0.36–1.58) |
| HAI anti-Aichi, GMT (S03!K9:O14) | 10 | 35 | **320** | 368 | 9.2 (4.2–20.2) | 0.87 (0.47–1.61) |
| Neutralising anti-CA09, GMT (S03!Q2:U7) | 52 | 418 | **3,840** | 6,686 | 9.2 (3.1–27.2) | 0.57 (0.19–1.70) |
| Neutralising anti-Aichi, GMT (S03!Q9:U14) | 40 | 276 | **2,533** | 4,411 | 9.2 (3.8–22.1) | 0.57 (0.24–1.38) |

*The CIs in this table are unadjusted Welch intervals. With Tukey adjustment across the five groups (log₁₀ scale):*

- *every day-14 PSLN-344 vs PSLN-212 contrast is significant (p ≤ 0.0002);*
- *no day-14 PSLN-344 vs young contrast is (p ≥ 0.33).*

*So at day 14, aged PSLN-344 antibody responses are not statistically different from young. With n = 5 per group this is absence of evidence of a gap, not proof of equivalence (`Tukey_HSD`).*

**Th1 skew.** PSLN-344 restores the Th1-type (IgG2a-dominant) antibody profile. The IgG2a/IgG1 ratios below are re-derived per animal from the subclass titres in S13-A/B and S13-C/D, because the printed S03-B and S03-F labels are rotated (QC-06) [E27].

| IgG2a/IgG1 ratio, GM | PSLN-344 | PSLN-212 | Young PSLN-212 | PSLN-344 ÷ PSLN-212, GMR (95% CI) |
|---|---|---|---|---|
| Anti-CA09 | 1.85 | 0.54 | 2.50 | 3.4 (1.6–7.4) |
| Anti-Aichi | 2.30 | 0.46 | 2.79 | 4.95 (2.10–11.65) |

**After a day-14 boost the age gap re-opens.** At day 28 (S13!F52:P57) [E28], PSLN-344 IgG relative to young is:

- 0.29× for Aichi (Welch 95% CI 0.11–0.76; Tukey-adjusted p = 0.03);
- 0.38× for CA09 (0.15–0.99; Tukey p = 0.45, not significant after adjustment).

## 2.3 Cellular and innate immunity: what Mn²⁺ fixes and what it does not

*See Fig 4 and E30–E54, E80.*

To summarise, for each aged-mouse readout, how far PSLN-344 moves it toward young-mouse levels, I computed a **restoration index**:

- R = [aged PSLN-344 − aged PSLN-212] ÷ [young PSLN-212 − aged PSLN-212];
- R is computed on log₁₀ per-animal values, with a bootstrap 95% CI;
- R = 0 means no rescue; R = 1 means the young level.

**Fully or nearly fully restored (R ≈ 0.88–1.0): the innate trigger, antigen transport and HAI.**

- Lung *Ifnb1* at 16 h (S01!A3:F10) [E50]:
  - GM fold over untreated: 36.9 (PSLN-344) vs 16.5 (PSLN-212) vs 37.5 (young PSLN-212).
  - GMR vs PSLN-212 = 2.23 (1.85–2.69); GMR vs young = 0.98 (0.84–1.16).
  - R = 0.98.
- Monocytes at day 4 (S01-D) [E46]: 30.6% vs 16.7% vs 32.2%.
- CCR7⁺ migratory DC (S02!A2:D7) [E40]: 30.7% vs 7.3% vs 35.0%; R = 0.90.
- Antigen-bearing MLN DC (S02!K2:O7) [E41]: 7.1% vs 1.8% vs 9.4%.
- OT-I priming by MLN DC (S02!K9:O14) [E44]: 18.7% vs 0.8% vs 26.2%; R = 0.91.
- HAI titres: R = 0.88–0.94.

**Partly restored (R ≈ 0.55–0.86): germinal-centre, IgG magnitude and CD8 memory outputs.**

- GC B cells (S03!L16:O21) [E30]: 6.5% vs 2.3% vs 9.8%.
- ICOS-high Tfh (S04!A2:K5) [E31]: 10.3% vs 3.8% vs 13.6%.
- IgG: R = 0.75–0.86.
- Lung GZMB⁺ CD8 at day 3 (S05!A25:D30) [E35]: 5.7% vs 3.0% vs 9.6%; R = 0.55.
- rgH5N1-restimulated IFN-γ⁺ CD8 in MLN [E36–E37]:
  - day 14: 6.4% vs 1.5% vs 9.2%;
  - day 60: 9.9% vs 3.0% vs 14.4%.
- Lung CD69⁺CD103⁺ CD8 (total tissue-resident memory, TRM) at day 25 (S05!A53:D58) [E38]: 4.0% vs 1.0% vs 6.0%.
- Boosted IgG: R = 0.57–0.66.

**Largely not restored (R ≈ 0.35): DC costimulation in the lymph node.**

- CD40⁺ MLN DC (S02!A9:D14) [E42]: 11.2% vs 5.6%, against 38.7% in young.
- CD86⁺ MLN DC (S02!F9:I14) [E43]: 14.5% vs 8.1%, against 37.9% in young.

**Regulatory populations fall.**

- Follicular regulatory T cells (Tfr, S04!A7:D12) [E32]: 10.8% vs 26.7% (young 7.1%).
- Lung Treg, n = 3 (S04!A28:D31) [E33]: 3.0% vs 6.7%.
- CD206⁺ macrophages (S11!A30:D35) [E47]: 48.9% vs 71.5%.

**Inflammation overshoots the young profile.** At 16 h, PSLN-344 exceeds young PSLN-212 by 2.9× for *Tnf* and 4.0× for *Il10*. It exceeds PSLN-212 by 77× for *Ccl2* and 6.5× for *Il6* (S09-A left panel, n = 3) [E54]. At 72 h, *Ifnb1* is still 2.85× the young level (1.47–5.51) [E51].

## 2.4 Other supporting points

**Dose-sparing.** In the *Ifnb1* dose–response (S08!B3:M7; n = 3; age not stated) [E52]:

- PSLN-344 at about 6.8 µg matches PSLN-212 at 20 µg, roughly 2.9× dose-sparing;
- the response plateaus between 20 and 40 µg (+9%).

**Formulation.** Encapsulation efficiency is the same for both particles: 54.8% (PSLN-344) vs 59.6% (PSLN-212), p = 0.29 (S08!A11:O11) [E70]. So the Mn effect is not explained by delivering more CDN.

**Early tolerability.**

- Post-vaccination weight nadir (S08!B21:AE26) [E72]:
  - PSLN-344 96.4% vs vaccine alone 98.2% (difference −1.8 points, p = 0.065);
  - PSLN-212/R848 90.0% (p = 0.02), with one animal missing at day 10.
- CNS transcripts at 36 h (S10!A2:N7) [E71]:
  - *Ifnb1* and *Isg15* are not induced by PSLN-344; cholera toxin induces *Ifnb1* 5.4×;
  - *Tnf* is 1.57× vs PBS (p = 0.03) but not different from Sham (1.20×, p = 0.36).

---

# 3. Why this package cannot carry an advancement decision

## 3.1 Data-integrity findings

*See Fig 5. Full log in `QC_log`: 4 critical, 8 major, 11 minor findings.*

| ID | Severity | Finding | Where | Consequence for the decision |
|---|---|---|---|---|
| QC-01 | Critical | Two different experiments contain identical per-animal survival data in all four groups (28/28 animals). | S06!M3:Q30 vs S06!A34:E61 | The day-3 rgH5N1 "rapid protection" result has no independent data. |
| QC-02 | Critical | Alveolar-macrophage (S11-A) and neutrophil (S11-B) percentages are identical for replicate animals 1–2 in 34/40 group × day cells; replicates 3–5 differ (1/60 identical). | S11!B3:U14 | Two different cell types cannot share per-animal values. |
| QC-03 | Critical | Body-weight trajectories recur across "independent" experiments. Examples: S09-E (young BALB/c, Perth) = S15-M (C57BL/6); S15-A PSLN-344 (aged BALB/c) = S15-M PSLN-344 (C57BL/6); S08-D (unchallenged) ↔ S15-F; S15-C ↔ S15-I. Some values match to 8 decimals with only the integer part altered (98.98780488 → 92.98780488). 22 pairs each have chance p ≤ 1.1 × 10⁻⁹; all survive Bonferroni correction across 126,048 comparisons. | S08-D, S09-E/G, S15-A/C/F/I/J/M | Directly implicates the other-strain studies (S15-L/N) and the antigen-requirement study (S15-H). Body weight cannot corroborate anything. |
| QC-04 | Critical | Animals recorded as dead continue to change weight. | 12 survival blocks, including every primary experiment | Survival and weight records for the same animals disagree; either may be wrong. |
| QC-05 | Major | Weight blocks annotated as "animals of S03-I / S03-J" contain a Naive group those experiments never had. In S13-F, all 7 PSLN-212 animals are weighed to day 10, although S03-I records all dead by day 6. | S13!B33:AJ50 vs S03 | The homologous and wild-type H5N1 survival results have no consistent supporting records. |
| QC-06 | Major | The printed IgG2a/IgG1 group labels are rotated relative to the subclass titres they are computed from; S13 labels are corroborated by total IgG. | S03!G2:I14 vs S13!A2:O7 | As printed, PSLN-344 looks Th2-skewed (0.54); corrected, it is Th1-skewed (1.85) [E27]. |
| QC-08 | Major | The right-hand S09-A cytokine panel is labelled 16 h but reproduces the 72 h values of S01-A. | S09!X2:AS9 | Kinetics would be misread. |
| QC-09 | Major | The same formulation, cell type, time and age gives type-I epithelial uptake of 3.8% (S01-B) vs 13.8% (S08-C), and values are shared between the two blocks. | S01!A14:F17, S08!A13:D18 | The "Mn reduces epithelial uptake" claim is unusable. |
| QC-10 | Major | 4/21 aged animals that were unvaccinated, unadjuvanted and *unchallenged* died within 14 days. In S06-G, PSLN-344 survival (4/7) equals unchallenged survival (4/7). | S06!L62, F99:F101 | Either colony health is poor or groups are mislabelled [E15]. |
| QC-14, 17, 18 | Major | Other design and labelling problems: (a) both macrophage-transfer groups carry the same label; (b) an H-2Db tetramer (NP366) was used in H-2d BALB/c mice, with n = 2 observed vs 3 stated; (c) OT-I cells were primed by DCs from donors of unstated strain. | S07-C; S05-A/B; S02-E | Those blocks are excluded or caveated. |

**What this does and does not mean.**

- The file cannot tell us whether these patterns come from assembly errors, template reuse, or manipulation.
- Some patterns are not typical transcription slips: a whole survival experiment duplicated, and high-precision animal values recycled with single-digit edits.
- Either way, the records must be reconciled to primary data before anyone relies on them. If a regulator found these patterns in an IND package, the consequences would extend beyond this asset.

**What survives.**

- The antibody, germinal-centre, CD8 and DC blocks (S02, S03-A/C/D/E/G/H/K, S04-A, S05-D to S05-I, S13-A to S13-D/I/J, S14) showed no copying or duplication in my screens. The exceptions are the label problems in QC-06 and QC-17/18.
- Immunogenicity, however, is not the efficacy claim. In the same regimen as S03-I, PSLN-212 reached HAI ≥ 1:40 in 5/5 aged mice, yet 0/7 survived homologous challenge [E26].

## 3.2 Development gaps that remain even if every record is genuine

1. **No benchmark.** Every comparison is against the company's own parent particle, a sham, or young mice. Nothing compares PSLN-344 with what older adults can already receive: squalene oil-in-water adjuvant, high-dose antigen, or recombinant HA. This is the first question a development committee will ask.
2. **Intranasal Mn²⁺ neurosafety is unmeasured.**
   - S10-A contains three CNS transcripts at a single 36 h time point, with no olfactory bulb, no Mn tissue levels, no histology and no repeat dosing [E71].
   - *External context:* inhaled or intranasal Mn is transported along the olfactory pathway into the brain. An intranasal influenza vaccine (virosomal plus heat-labile toxin, 2000–01) was withdrawn over facial-nerve palsy. The target population is the one most exposed to neurodegenerative risk.
3. **Delivery.** The mechanism runs through alveolar macrophages: uptake is 43.1% in wild-type vs 12.7% in SP-A/SP-D-deficient mice (S01!A20:E21) [E60].
   - *External context:* mouse intranasal instillation reaches the lower airway, whereas a human nasal spray largely does not.
   - The product concept (nasal spray vs inhaled aerosol) is therefore undefined.
4. **Durability and breadth in aged mice are incomplete** (Fig 6) [E10–E11].
   - Survival by challenge interval: 20/21 at day 14 vs 14/21 at day 60 (p = 0.045). The comparison is partly confounded by the virus mix; virus-matched it is 13/14 vs 10/14 (p = 0.33).
   - At day 60, aged PSLN-344 is below young PSLN-212 (14/21 vs 21/21, p = 0.009).
   - There are no aged data beyond day 60; young data run to day 180.
5. **Mechanism of protection is untested.** No depletion, passive-transfer or knockout *challenge* experiment links any immune arm to survival (Section 5.1).
6. **Study design.** Throughout the package:
   - female only;
   - one experiment per condition;
   - n = 5–7 per group, and 2–3 for several mechanistic blocks;
   - no stated randomisation, blinding or humane-endpoint criteria;
   - key conditions missing (challenge virus, dose and day for S15-L/N; age for S02-G/H and S08-A).
7. **Chemistry, manufacturing and controls (CMC).**
   - Encapsulation is only about 55% [E70].
   - Particle size, zeta potential and TEM are described in the annotation but absent from the workbook.
   - One formulation in the dose–response (PSLN-344/R848) is undefined.
   - Encapsulation "of CDN-1807" is reported for two formulations that contain no CDN-1807 (QC-20).
8. **Human relevance.** There are no human-cell data, and no data across human STING variants.

---

# 4. Anticipated challenges and responses

**"83% vs 12% across eight experiments cannot all be artefact."**
It may not be, which is why I am recommending verification rather than termination. But one of the experiments is a copy, the weight records for all eight contradict the survival records, and we do not yet know which records are primary.

**"Advance and audit in parallel."**
IND-enabling spend (GLP toxicology, GMP manufacturing) is the largest step-up in cost; the audit plus a blinded replication is a small fraction of it. If the audit fails, the parallel spend is lost and we carry regulatory exposure. If it passes, we lose about two quarters.

**"The antibody data alone are strong — HAI is restored to young levels."**

- HAI ≥ 1:40 in 5/5 PSLN-212 mice coincided with 0/7 survival in the same regimen [E26].
- The asset's differentiating claim is protection against *mismatched* strains. Its strongest heterosubtypic data (71% survival, S06-A/B/E/G) cannot be explained by HA-inhibiting antibody [E10].
- Immunogenicity is necessary but not sufficient.

**"The platform obviously works — look at the young mice."**
In young mice PSLN-212, PSLN-344 and even CMP-204 all give 100% [E13]. The young data cannot distinguish the asset from its parent. The entire value sits in the aged data, which is exactly where the integrity problems sit.

**"Other strains replicate it."**
S15-L (C57BL/6) and S15-N (Swiss Webster) state no challenge virus, dose or day. Their weight blocks contain BALB/c trajectories (QC-03, QC-21). They cannot be presented as independent replication.

**"The safety data are clean."**

- The only CNS data are three transcripts at 36 h.
- The Mn-specific risk, olfactory transport, has not been measured.
- In the lung, *Tnf* is 2.9× and *Il10* 4.0× the young level at 16 h, and *Ifnb1* is still 2.85× young at 72 h [E51, E54]. That is a reactogenicity flag for a frail population.

**"Are we killing it?"**
No. We are declining to fund development until the core claim survives an audit and an independent replication, and until we know it beats what patients already get.

---

# 5. Forward view

## 5.1 What is actually driving the protection?

**Established at face value**

1. *Mn²⁺ is the active ingredient.* The annotation states Mn²⁺ is the only difference between PSLN-344 and PSLN-212, encapsulation is equal [E70], and survival is 83% vs 12% [E01]. *One caveat to confirm: the annotation doses "20 µg of adjuvant" per animal without saying whether that is CDN or total particle mass.*
2. *Protection needs the antigen.* PSLN-344 given alone 3 days before rgH5N1 gives 0/7 survival; vaccine alone gives 0/7; the two together give 6/7 (S15!A72:D93) [E12]. This argues against a non-specific antiviral state. *Caveat: the weight data for this experiment are recycled from S15-C (QC-03).*
3. *It is an age-specific rescue.* In young mice there is no increment over PSLN-212 [E13].

**The best-supported model**

- Mn²⁺ restores the aged innate trigger to young levels. The chain runs through:
  - alveolar-macrophage uptake, which depends on SP-A/SP-D [E60];
  - type-I IFN (R = 0.98) [E50];
  - GM-CSF: *Gm-csf* is 5.4× PSLN-212 at 36 h [E53];
  - recruitment of monocytes that become DCs, which needs IFNAR signalling. Without IFNAR in the bone marrow, moDCs fall to 2.1% vs 19.7%, and GM-CSF rescues them to 12.4% [E62–E63]. Adding GM-CSF to PSLN-212 raises these cells 5.9% → 13.8% [E61];
  - DC migration and priming: R = 0.90–0.91. Blocking migration with pertussis toxin abolishes MLN priming: OT-I 2.6% vs 18.7%, and in vivo in the MLN 6.8% vs 30.9% [E68–E69].
- That restored trigger drives two adaptive arms: antibody (R 0.75–0.94) and CD8/TRM (R 0.55–0.97; the memory-phase read-outs 0.76–0.82).

**Where protection is complete, and where it is only partial, points to which arm matters** (Fig 6) [E10–E11].

- **Complete:** when the challenge virus shares HA and NA with the vaccine (17/17), and at day 14 (20/21).
- **Partial:** when it shares no HA or NA subtype (20/28, 71%; trend p = 0.013), and at day 60 (14/21).
- *Caveat:* these two factors overlap, because two of the four fully heterosubtypic experiments were day-60 challenges. Restricted to early challenges (day 3 and day 14), fully heterosubtypic survival is 11/14 vs 17/17 homologous (Fisher p = 0.08). The gradient is suggestive, not proven; S1 separates the two factors.
- Those are the settings where protection must come from non-neutralising and cellular immunity and from memory. These are also the outputs that Mn²⁺ only partly restores: GC, Tfh, CD8 effector/memory, TRM and boosted IgG (R 0.55–0.82). Lymph-node DC costimulation is restored only about a third of the way (CD40/CD86, R 0.35–0.38) [E80].

**Inference (not yet tested)**

- Strain-matched antibody (HAI GMT about 320–370) is probably sufficient for homologous protection [E22–E23].
- Heterosubtypic and durable protection most plausibly depends on cross-reactive CD8 T cells and TRM against conserved internal proteins. Anti-N1 antibody may add to H5N1 protection, since the bivalent vaccine contains N1.
- The residual age gap at day 60 is most plausibly a memory-quality deficit that Mn²⁺ does not fix.

**What is unknown.** None of this has been tested causally:

- no CD8 or CD4 depletion before challenge;
- no passive serum transfer;
- no IFNAR, CCR2 or GM-CSF blockade with a survival read-out.

The CCR2 antagonist experiment, which showed GZMB⁺ CD8 at 1.4% vs 6.8% [E64], was done in *young* mice only, without challenge.

## 5.2 Is there a biomarker of efficacy worth carrying forward?

**One is worth carrying forward, but as a pharmacodynamic marker, not an efficacy surrogate: early type-I IFN / interferon-stimulated gene (ISG) induction.**

Why this one (Fig 7):

1. It is the earliest Mn²⁺-dependent signal: a 2.2× increase over PSLN-212 within 16 h [E50].
2. It is fully age-restoring: aged PSLN-344 equals young PSLN-212 (GMR 0.98) [E50].
3. It is dose-responsive, gives about 2.9× dose-sparing, and plateaus at 20–40 µg [E52]. That makes it the natural dose-finding read-out.
4. It is mechanistically upstream: IFNAR signalling is needed for the moDC arm [E62].

Why it is not an efficacy surrogate:

- It is transient: back to about 4× by 72 h [E51].
- It is the same pathway that drives reactogenicity: *Il6*, *Ccl2* and *Tnf* [E54].
- No experiment links it to outcome animal by animal.
- The cGAMP liposome CMP-204 had lower *Ifnb1* (7.7×) than PSLN-212 (16.5×) but no worse homologous survival: 3/7 vs 0/7 (not significant) [E26, E50].

**Could it go into patients, and in what role?**

- It can be measured: a nasal-swab or blood ISG score, and serum CXCL10, at 24 h after dosing.
- Role in Phase 1 (older adults): a pharmacodynamic / target-engagement biomarker, used for
  - dose selection;
  - confirming that the Mn²⁺ amplification translates to humans;
  - as a go/no-go read-out;
  - as a safety covariate.
- Human STING variants should be genotyped and used to stratify the analysis.
- It should not be used as a surrogate endpoint.

**Efficacy correlates to validate, not yet carry forward**

- **HAI / microneutralisation (MN).** *External context:* HAI is the regulatory immunogenicity endpoint for inactivated influenza vaccines. It keeps that role. But in aged mice the conventional 1:40 level did not protect [E26], and HAI cannot account for the heterosubtypic claim.
- **Cross-reactive CD8 IFN-γ response** to conserved NP/M1. This is the candidate correlate for the breadth claim [E36–E37].
- **Nasal IgA.** It was not measured anywhere in the package. That is a gap for an intranasal product and should be added to every next study.

**Deprioritised**

- Circulating Tfh as the lead marker. It is only partly restored in mice (R = 0.75). *External context:* in humans it predicts vaccine response less well in older adults.
- DC CD40/CD86. These are only about a third restored, even in mice that are protected [E42–E43].

## 5.3 Could PSLN-344 go into patients, and in what role?

**Not yet.** If G0–G4 are passed, the defensible role is:

- an intranasal or inhaled adjuvant for inactivated or split influenza vaccine;
- in adults aged 65 and over;
- positioned on breadth (protection against drifted and heterosubtypic strains) and on mucosal delivery;
- benchmarked against squalene-adjuvanted and high-dose vaccines.

It is not a young-adult product [E13], and not a stand-alone prophylactic: the adjuvant alone gives 0/7 [E12].

A pandemic rapid-response use (protection 2–3 days after vaccination) is attractive but currently unsupportable:

- the day-3 H5N1 experiment is the duplicated S06-D (QC-01);
- the 3-day antigen-requirement study has recycled weights (QC-03);
- S03-J (10/10 vs 3/10 at day 2) has count and missing-value anomalies (QC-11, QC-12).

It should be re-tested in the confirmatory study.

## 5.4 What the next studies must establish

Studies are in priority order. G0, S1, S4a, S5 and S7 run in parallel from month 0–2.

### G0 — Forensic data audit (weeks 0–8)

- **Must establish:** that the pivotal records trace to primary data, and the root cause of QC-01 to QC-06.
- **Scope:**
  - S03-I, S03-J, S06-A to S06-G, S15-H/L/N survival;
  - all body-weight blocks;
  - S11-A/B;
  - S03-B/F labels;
  - the Untreated deaths;
  - the orphan data at S08 rows 89–101.
- **Comparator:** primary records — animal-room and death/euthanasia logs, scale print-outs, cage cards, randomisation sheets, FCS files, ELISA plate reads, qPCR Ct files.
- **Read-out:** reconciliation rate per block; root cause.
- **Go:** the pivotal survival blocks reconcile with no unexplained duplication. **Otherwise stop** (asset terminated; data-governance review).

### S1 — Independent, blinded, randomised confirmatory efficacy in aged mice (CRO; months 2–9; durability to month 12)

- **Must establish:**
  - that the PSLN-344 over PSLN-212 effect is real;
  - whether PSLN-344 beats what older adults can already get.
- **Population:**
  - BALB/c and C57BL/6 aged 20–22 months, **both sexes**, health-screened;
  - young (8–10 week) reference groups;
  - unchallenged aged sentinels to measure background mortality.
- **Arms** (all with inactivated vaccine unless stated):
  1. sham liposome;
  2. PSLN-212;
  3. PSLN-344 at 20 µg;
  4. PSLN-344 at 7 µg (dose-sparing, from E52);
  5. free MnCl₂ at matched Mn dose, alone and mixed with PSLN-212 (does co-formulation matter?);
  6. squalene oil-in-water adjuvant given i.m. (licensed-class benchmark);
  7. 4× HA antigen i.m. (high-dose benchmark);
  8. PSLN-344 without antigen (innate / trained-immunity control).
- **Challenges:**
  - homologous (CA09) and fully heterosubtypic (Aichi vaccine → PR8) at day 14, reproducing S03-I and S06-A exactly, with the same virus stocks and mLD50;
  - durability cohorts at day 90 and day 180 (no aged data currently exist beyond day 60).
- **Endpoints:**
  - *Primary (vs PSLN-212):* survival to day 14 post-challenge, with a pre-registered humane endpoint.
  - *Co-primary (vs benchmarks):* lung virus titre at day 5 (log₁₀ TCID₅₀) in the heterosubtypic challenge, using separate cohorts.
  - *Secondary:* weight-loss AUC and clinical score.
  - *Per animal, before challenge:* HAI, MN and IgG (day 13); nasal-wash IgA; blood ISG score at 24 h.
- **Sample size** [E81]:
  - 12 per group gives 89% power for 80% vs 15% survival;
  - 12–19 per group for a 0.75–1.0 log₁₀ difference in lung titre;
  - 45 per group would be needed if survival vs benchmark were primary.
- **Scale (indicative):**
  - the core confirmation (arms 1–3, both sexes, two challenges) is about 150 aged mice;
  - the full design, including benchmarks, dose, free-Mn, titre cohorts and the C57BL/6 repeat of arms 1–3 and 6, is about 600;
  - aged-mouse supply is the rate-limiting step, so it should be ordered when G0 starts.
- **Read-outs:**
  - months 6–7 (day-14 challenges) — feeds G1/G2;
  - month 9 (day 90);
  - month 12 (day 180).
- **Go:**
  - PSLN-344 ≥ 70% survival and superior to PSLN-212 (p < 0.05) in both challenges and both sexes;
  - ≥ 0.5 log₁₀ lower lung titre than the benchmarks in heterosubtypic challenge;
  - sentinel mortality ≤ 10%.

### S2 — Mechanism of protection (months 4–10)

- **Must establish:** which arm is necessary and which is sufficient. This decides the clinical correlate and the label claim.
- **Population:** aged BALB/c vaccinated with PSLN-344 (young reference).
- **Interventions vs comparators:**
  - anti-CD8β or anti-CD4 depletion before challenge, vs isotype;
  - passive transfer of immune serum from PSLN-344-vaccinated aged donors into naive aged recipients, vs naive serum;
  - FTY720 during challenge (resident vs recruited T cells);
  - IFNAR-blocking antibody at vaccination;
  - CCR2 antagonist at vaccination, now with challenge;
  - **PSLN-212 + GM-CSF** (does GM-CSF substitute for Mn²⁺?) vs PSLN-344 + anti-GM-CSF.
- **Endpoints:** survival and lung titre, in homologous and fully heterosubtypic challenge.
- **n:** 10–12 per group.
- **Interpretation rule:**
  - if CD8 depletion abolishes heterosubtypic protection, CD8 IFN-γ becomes the breadth biomarker;
  - if serum transfer protects homologous challenge only, HAI/MN becomes the strain-matched correlate.

### S3 — Correlates and dose–response (months 4–12; can share cohorts with S1)

- **Must establish:** whether early IFN/ISG, or any later marker, predicts protection animal by animal.
- **Population:** about 75 aged BALB/c mice (both sexes) given PSLN-344 at 0, 1, 3, 7 or 20 µg with vaccine, about 15 per dose. The dose titration is there to create a spread of responses and outcomes.
- **Comparators:**
  - 0 µg (vaccine + sham liposome);
  - PSLN-212 at 20 µg (n = 15);
  - young PSLN-212 reference (n = 10).
- **Read-outs (per animal):**
  - blood ISG score and serum CXCL10 at 24 h;
  - HAI, MN and nasal IgA at day 13;
  - blood NP147 (H-2Kd) tetramer⁺ CD8 at day 13;
  - then heterosubtypic challenge at day 14; survival, weight-loss AUC.
- **Analysis:** logistic regression of survival on each marker; ROC area under the curve (AUC).
- **Go:** a marker with AUC ≥ 0.8 becomes the efficacy biomarker candidate for humans.

### S4 — Intranasal Mn and STING safety (4a non-GLP, months 2–7; 4b GLP, months 12–20, only after G1)

- **Must establish:** no CNS Mn accumulation or neuropathology, and tolerable repeat-dose inflammation.
- **Population:** aged and young rats and mice, both sexes.
- **Arms:**
  - vehicle;
  - PSLN-344 at 1×, 3× and 10× the intended human-equivalent dose;
  - free MnCl₂ at matched Mn;
  - cholera toxin as a positive control for neural inflammation.
- **Endpoints:**
  - ICP-MS Mn in olfactory bulb, striatum, cortex, cerebellum, lung, liver and blood, at days 1, 7 and 28, after single and three doses;
  - Mn-sensitive MRI;
  - histopathology of the nasal cavity, olfactory epithelium and bulb, and the trigeminal and facial nerves;
  - neurobehaviour: open field, rotarod, olfactory test;
  - serum IL-6, TNF and CXCL10;
  - temperature and weight.
- **Go:** no Mn increase over vehicle in the olfactory bulb or striatum at 1–3×; no neuropathology.

### S5 — Human translational, ex vivo (months 2–8)

- **Must establish:** that the Mn amplification and the aged-to-young rescue occur in human cells.
- **Material:**
  - monocytes and moDCs from donors aged ≥ 65 vs 20–40 (about 20 each);
  - human alveolar macrophages;
  - nasal epithelial air–liquid interface cultures;
  - cell lines expressing the STING R232, H232, HAQ and AQ variants.
- **Arms:** PSLN-344, PSLN-212, free CDN-1807 ± MnCl₂, cGAMP, vehicle.
- **Read-outs:** IFN-β, CXCL10, ISG score, IL-6/TNF, CD40/CD86, viability, Mn uptake.
- **Go:**
  - PSLN-344 ≥ 2× PSLN-212 in cells from older donors;
  - active in the HAQ and H232 variants.

### S6 — Second species and human-relevant delivery (months 8–20)

**Ferret (months 8–14)**

- **Must establish:** protection in a second species.
- **Population:** adult ferrets, about 8 per arm (aged ferret colonies are not generally available; this is a stated limitation).
- **Arms:** PSLN-344 i.n. + vaccine, vs squalene-adjuvanted i.m., high-dose i.m., and vaccine alone.
- **Challenge:** homologous and drifted.
- **Read-outs:** nasal-wash viral shedding AUC, clinical score, HAI, nasal IgA.

**Aged rhesus macaque (months 12–20)**

- **Must establish:** deposition, to choose the device.
- **Population:** aged rhesus macaques (≥ 18 years), about 6 per arm.
- **Comparison:** nasal spray vs nebulised aerosol, against licensed adjuvanted vaccine i.m.
- **Read-outs:**
  - scintigraphic deposition;
  - HAI, MN, BAL and nasal IgA, T cells;
  - clinical, cytokine and neurological/olfactory safety.

### S7 — CMC (months 0–9)

- **Must establish:** a reproducible, characterised product.
- **Comparators:** PSLN-212 made in parallel; pre-set release specifications.
- **Read-outs:**
  - size, polydispersity, zeta potential and TEM (none are in the current workbook);
  - Mn and CDN loading, and free fractions;
  - encapsulation (target > 80%);
  - stability over 6–12 months at −20 °C and 2–8 °C;
  - three batches.

### Clinical (not before about month 20, after G0–G4 and S4b)

- **Design:** Phase 1, randomised and observer-blind.
- **Population:** adults 18–49 as a low-dose sentinel cohort, then adults 65–85.
- **Arms:**
  - licensed split vaccine i.n. + PSLN-344 at three dose levels;
  - split vaccine i.n. alone;
  - licensed adjuvanted or high-dose vaccine i.m. as benchmark.
- **Endpoints:**
  - *Safety:* solicited nasal and systemic reactions (days 0–7); adverse events (days 0–28); facial-nerve palsy as an adverse event of special interest for 6 months; smell-identification testing at baseline, day 7 and day 28; blood Mn.
  - *Pharmacodynamics:* nasal and blood ISG score and CXCL10 at 24 h.
  - *Immunogenicity:* HAI/MN geometric mean titre and seroconversion at day 28; nasal IgA; NP/M1 IFN-γ ELISpot at day 14; 6-month durability.

**Timeline and decision points**

| Month | 0–2 | 2–4 | 4–6 | 6–8 | 8–10 | 10–12 | 12–20 |
|---|---|---|---|---|---|---|---|
| G0 audit | ■ **G0** | | | | | | |
| S1 confirmatory efficacy | | ■ | ■ | ■ **G1/G2** | ■ (d90) | ■ (d180) | |
| S2 mechanism / S3 correlates | | | ■ | ■ | ■ | ■ | |
| S4a Mn safety (non-GLP) | | ■ | ■ | ■ **G3** | | | |
| S5 human ex vivo | | ■ | ■ | ■ **G4** | | | |
| S6 ferret / NHP | | | | | ■ | ■ | ■ |
| S7 CMC | ■ | ■ | ■ | ■ | ■ | | |
| **Re-review** | | | | | **■ month ~9–10: advance to IND-enabling (S4b GLP tox, GMP) only if G0–G4 pass** | | |

## 5.5 If we drop it: what we are dropping, and why

**What we would be dropping**

- A mechanistically anchored concept: a Mn²⁺-amplified STING agonist in a surfactant-mimetic particle.
- At face value, it:
  - restores the aged innate-to-adaptive cascade to young levels at the trigger steps (R ≈ 0.9–1.0);
  - gives about 3× dose-sparing;
  - converts a failing parent particle (12% survival) into 83% survival in aged mice, including 71% against fully heterosubtypic strains [E01, E10, E52, E80].

**Why we would be dropping it**

- Its core records cannot be verified as they stand (QC-01 to QC-06).
- It has never been benchmarked against what patients can already get.
- Its Mn/intranasal safety is unknown.
- Its breadth and durability advantage in aged mice is incomplete (day 60 below young).

**What we would keep, whatever is decided**

1. The finding that the aged deficit lies partly *downstream* of the innate trigger: lymph-node DC costimulation is barely rescued (R ≈ 0.35), and memory only partly. This is a design target for any older-adult adjuvant.
2. Early IFN/ISG as a pharmacodynamic biomarker framework.
3. The integrity findings themselves, as a data-governance action across the adjuvant portfolio.

---

# 6. What I considered and ruled out

| Option / hypothesis | Verdict | Why (data) |
|---|---|---|
| Advance now to IND-enabling | **Ruled out** | Integrity findings touch the pivotal endpoints (QC-01 to QC-04); no benchmark; no Mn neurosafety. |
| Advance with a parallel audit | **Ruled out** | Spend-at-risk and regulatory exposure before we know the records are primary; the audit takes about 2 months. |
| Terminate now | **Ruled out** | Large, consistent, Mn-specific face-value effect (E01, E09); coherent mechanism (E50–E53, E80); verification is cheap. |
| Hold with gated confirm-or-kill | **Recommended** | Buys decisive evidence on reality, benchmark, safety and mechanism for a fraction of development cost. |
| Count S06-D as independent evidence of day-3 H5N1 protection | Ruled out | Exact copy of S06-C (QC-01); excluded from pooling. |
| Use body weight to corroborate survival | Ruled out | Recycled trajectories; disagree with survival records (QC-03 to QC-05). |
| Read S03-B/S03-F as printed (PSLN-344 Th2-skewed) | Ruled out | Labels rotated; re-derived ratios show Th1 skew (QC-06, E27). |
| Count Tfh:Tfr as separate evidence | Ruled out | Equals (100 − Foxp3%)/Foxp3% of S04-B to 6 decimals (QC-07). |
| Treat S09-A right panel as 16 h data | Ruled out | Reproduces S01-A 72 h (QC-08). |
| Use S11-A/B myeloid kinetics, S05-A/B tetramer kinetics, S07-C transfer, S08 rows 89–101 | Ruled out | Copied values; MHC-mismatched epitope with n = 2; duplicate labels; unlabelled data (QC-02, 14, 16, 17). |
| Present S15-L/N as strain replication | Downgraded | Challenge not stated; weight blocks carry BALB/c trajectories (QC-03, QC-21). |
| Analyse titres on the raw scale (the annotation's ANOVA/Tukey) | Replaced by log₁₀ | Titres are log-normal, and a raw-scale ANOVA is dominated by the high-variance young group. On raw values, 3 of the 7 antibody PSLN-344 vs PSLN-212 contrasts that are significant on log₁₀ lose Tukey significance (S03-D, S03-E, S13-J), and 2 PSLN-344 vs young contrasts gain it (S03-E, S13-I). No contrast reverses direction. Log₁₀ Tukey, Welch and exact Mann–Whitney agree (workbook sheets *Tukey_raw_vs_log*, *Tukey_HSD*, *Immunology_contrasts*). |
| Mechanism = non-specific innate antiviral state | Not supported | Adjuvant alone 0/7 at 3 days (E12); trained immunity at later times remains untested (S1 arm 8). |
| Mechanism = more CDN delivered | Ruled out | Equal encapsulation, 54.8% vs 59.6%, p = 0.29 (E70). |
| Mechanism = better epithelial targeting | Not supported | The block that suggests it contradicts S01-B (QC-09). |
| Mechanism = HA-inhibiting antibody explains all of the protection | Ruled out | It cannot explain 71% survival against strains sharing no HA or NA subtype with the vaccine (E10). For homologous challenge, the conventional 1:40 level was not enough (PSLN-212: 5/5 at ≥ 1:40, 0/7 survived; E26), although PSLN-344's roughly 8-fold higher titres may be. |
| Mechanism = Treg/Tfr suppression lifted | Open | Tfr and lung Treg fall (E32–E33), but the evidence is correlational only; S07-C, the one transfer test, is uninterpretable. |
| Background colony mortality explains the effect | Ruled out as explanation; a problem in its own right | Mortality is non-differential and cannot create a PSLN-344 vs PSLN-212 gap, but 4/21 unchallenged deaths undermine model validity (QC-10). |
| HAI as the efficacy biomarker | Not sufficient | 1:40 did not protect aged mice (E26); it cannot explain breadth. |
| DC CD40/CD86 as a biomarker | Ruled out | About a third restored (R ≈ 0.35), yet day-14 protection is about 94% restored (E42–E43, E80). |
| Early IFN/ISG as a pharmacodynamic biomarker | **Carry forward** | Earliest Mn-dependent signal; dose-responsive; age-restoring (E50–E52). |
| Advance the parent PSLN-212 instead (no Mn, simpler CMC and safety) | Ruled out | 7/59 (12%) aged survival, not different from Sham's 1/59 (exact p = 0.055) (E03). |
| Switch to the cGAMP liposome CMP-204 | Ruled out | Weaker on every aged read-out: *Ifnb1* 7.7× vs 36.9×; IgG GM 181 vs 7,305; HAI GMT 23 vs 368; S03-I survival 3/7 vs 7/7 (E50, S03!A2:O7, E26). |
| Young-adult indication | Ruled out | No increment over PSLN-212 (E13). |
| Stand-alone prophylactic or post-exposure use | Ruled out | Adjuvant alone 0/7 (E12). |
| Pandemic rapid-response positioning | Deferred | Supporting blocks are flagged (QC-01, 03, 11, 12); re-test in S1. |
| R848 combinations (PSLN-344/R848, PSLN-212/R848) | Deprioritised | Lower *Ifnb1* than PSLN-344 (29.0 vs 45.5-fold at 20 µg, E52); 90.0% weight nadir with PSLN-212/R848 (E72). |

---

# Appendix A — Methods

**Extraction.**

- All 108 blocks were extracted cell by cell into tidy tables with the source cell of every value (`analysis/01_extract.py`; `Tidy_values`, `Tidy_survival`).
- Block identities, units, time points and stated n come from the annotation.
- Where the workbook re-uses a label, the second instance is marked with a prime (S06-E′, S06-F′).

**Integrity screens** (`02_qc.py`):

1. stated vs observed n;
2. identical per-animal sequences across survival blocks;
3. value identity at matched positions across blocks;
4. exact repeats and shared fractional parts among values with ≥ 4 decimals;
5. trajectory-level matching of informative body-weight values (last-observation-carried-forward values removed), tested against the empirical cross-block match rate (0.88% per day), binomial, Bonferroni-corrected across 126,048 pairs;
6. body-weight vs survival concordance;
7. re-derivation of ratio blocks from their components;
8. annotation vs workbook conditions.

**Survival** (`03_survival.py`):

- Per group: survivors/N with Clopper–Pearson 95% CI.
- Per experiment: log-rank (statsmodels `survdiff`) and two-sided Fisher.
- Pooled:
  - Mantel–Haenszel risk difference (Sato variance) and risk ratio;
  - exact conditional test (convolution of within-stratum hypergeometrics);
  - stratified log-rank;
  - Breslow–Day homogeneity.
- Analysis sets were defined before pooling: primary, plus sensitivity sets S1–S4 and subgroups.
- S03-J's censored animal without a time value was censored at end of follow-up; worst case in S2.

**Immunology** (`04_immunology.py`):

- Log₁₀ scale for titres, fold-changes and ratios; linear scale for percentages.
- Welch two-sample contrasts with 95% CI.
- Exact Mann–Whitney.
- Tukey HSD across all groups per block (the stated method, applied on the analysis scale). A raw-scale version is reported for comparison; it disagrees for some titre contrasts but never in direction (*Tukey_raw_vs_log*).
- Pairwise Welch p-values are unadjusted. Where Tukey adjustment changes significance, the memo does not claim significance; for example, MLN DC CD40 PSLN-344 vs PSLN-212 has Welch p = 0.011 but Tukey p = 0.16.
- Restoration index with 4,000 bootstrap resamples of animals within groups.
- IgG2a/IgG1 ratios were re-derived from S13-A to S13-D.

**Power** (`06_evidence.py`, E81): simulation of the two-sided Fisher test (4,000 trials) and two-sample t power.

**Software:** Python 3.11, pandas, SciPy, statsmodels, matplotlib, openpyxl and xlsxwriter. All scripts run end to end from the source workbook.

**Limits of this analysis.** Group-level inference only: no animal has both immune read-outs and an outcome. Groups are n = 5–7 and there is one experiment per condition. Statements labelled *external context* are general scientific or regulatory background, not company data.

# Appendix B — Figures

![Fig 1. Survival by experiment (face value). Left: survivors/N with exact 95% CI. Right: PSLN-344 minus PSLN-212 with Newcombe CI; pooled Mantel–Haenszel estimate. S06-D is shown faded: it is an exact copy of S06-C.](figures/fig1_survival_forest.png)

![Fig 2. Kaplan–Meier curves for the aged-mouse challenge experiments and the 3-day antigen-requirement study. "Untreated" = unvaccinated, unchallenged aged controls (note deaths in S06-E and S06-G).](figures/fig2_km_curves.png)

![Fig 3. Day-14 antibody responses, per animal; bars are geometric means.](figures/fig3_antibody.png)

![Fig 4. Restoration index: how completely PSLN-344 rescues each aged readout toward young levels.](figures/fig4_restoration_index.png)

![Fig 5. Integrity findings QC-01, QC-02, QC-03, QC-06.](figures/fig5_integrity.png)

![Fig 6. Aged PSLN-344 protection by antigenic relationship and by challenge interval. The two factors are partly confounded.](figures/fig6_gradient.png)

![Fig 7. Type-I IFN dose–response and age restoration: the candidate pharmacodynamic biomarker.](figures/fig7_ifn_biomarker.png)

# Appendix C — Deliverables

| File | Content |
|---|---|
| `PSLN-344_portfolio_memo.docx` / `.html` / `.md` | This memo |
| `PSLN-344_evidence_workbook.xlsx` | Evidence register (E01–E81), QC log (QC-01–QC-23), all survival and immunology statistics, restoration indices, trajectory-reuse and weight-vs-survival checks, block catalogue, tidy per-animal data with source cells |
| `figures/fig1…fig7.png` | Figures |
| `analysis/01_extract.py … 06_evidence.py` | Reproducible pipeline (run in order) |
| `tables/*.csv` | All intermediate tables |

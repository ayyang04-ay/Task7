"""05_figures.py -- figures for the portfolio memo (all data from tidy tables; see captions in memo)."""
import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from statsmodels.stats.proportion import proportion_confint, confint_proportions_2indep
from statsmodels.duration.survfunc import SurvfuncRight
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150})
T = '/tmp/outputs/tables/'; F = '/tmp/outputs/figures/'
s = pd.read_csv(T + 'tidy_survival.csv'); v = pd.read_csv(T + 'tidy_values.csv')
COL = {'Sham': '#8c8c8c', 'PSLN-212': '#4a90c2', 'PSLN-344': '#d2492a', 'PSLN-212(Y)': '#2e8b57', 'CMP-204': '#b58900', 'Vaccine': '#8c8c8c'}

def surv(b, g):
    d = s[(s.block == b) & (s.group == g)].copy()
    d.loc[d.time.isna(), 'time'] = d.time.max()
    return d

# ---------------- Fig 1: forest plot ----------------
blocks = [('S03-I', 'Homologous CA09 (10x), d14'), ('S03-J', 'Homologous wt H5N1, d2 (22 d obs)'),
          ('S06-A', 'Aichi vacc -> PR8, d14'), ('S06-B', 'Aichi vacc -> PR8, d3'), ('S06-C', 'Bivalent -> rgH5N1, d14'),
          ('S06-D', 'Bivalent -> rgH5N1, d3  [EXACT COPY of S06-C]'), ('S06-E', 'Aichi vacc -> PR8, d60'),
          ('S06-F', 'Bivalent -> rgH5N1, d60'), ('S06-G', 'CA09 vacc -> Perth H3N2, d60'),
          ('S15-L', 'C57BL/6 (challenge not stated)'), ('S15-N', 'Swiss Webster (challenge not stated)')]
fig, (ax, ax2) = plt.subplots(1, 2, figsize=(11, 6.2), gridspec_kw={'width_ratios': [1.5, 1]}, sharey=True)
yl = []
for i, (b, lab) in enumerate(blocks):
    y = len(blocks) - i
    for k, g in enumerate(['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']):
        d = surv(b, g)
        if len(d) == 0: continue
        n = len(d); x = (d.event == 0).sum(); lo, hi = proportion_confint(x, n, method='beta')
        off = (k - 1.5) * 0.16
        ax.errorbar(100 * x / n, y + off, xerr=[[100 * (x / n - lo)], [100 * (hi - x / n)]], fmt='o', color=COL[g],
                    ms=4.5, lw=1, alpha=0.35 if b == 'S06-D' else 1)
    d1, d0 = surv(b, 'PSLN-344'), surv(b, 'PSLN-212')
    x1, n1, x0, n0 = (d1.event == 0).sum(), len(d1), (d0.event == 0).sum(), len(d0)
    lo, hi = confint_proportions_2indep(x1, n1, x0, n0, method='newcomb', compare='diff')
    ax2.errorbar(100 * (x1 / n1 - x0 / n0), y, xerr=[[100 * (x1 / n1 - x0 / n0 - lo)], [100 * (hi - (x1 / n1 - x0 / n0))]],
                 fmt='s', color='k', ms=4, alpha=0.35 if b == 'S06-D' else 1)
    yl.append((y, f'{b}: {lab}'))
pooled = pd.read_csv(T + 'survival_pooled.csv')
pr = pooled[(pooled.analysis_set.str.startswith('PRIMARY')) & (pooled.comparator == 'PSLN-212')].iloc[0]
import re
_m = re.match(r'(-?\d+) \(95% CI (-?\d+) to (-?\d+)\)', pr.MH_risk_difference_pct); rd, rlo, rhi = map(float, _m.groups())
ax2.errorbar(rd, 0, xerr=[[rd - rlo], [rhi - rd]], fmt='D', color='#d2492a', ms=7)
yl.append((0, 'POOLED (primary set, MH; S06-D excluded)'))
ax.set_yticks([t for t, _ in yl]); ax.set_yticklabels([l for _, l in yl])
ax.set_xlabel('Survival to end of observation, % (exact 95% CI)'); ax.set_xlim(-5, 105)
ax2.axvline(0, color='grey', lw=0.8); ax2.set_xlabel('PSLN-344 minus PSLN-212 (aged), % points\n(Newcombe 95% CI; pooled = Mantel-Haenszel)')
ax.legend(handles=[Line2D([], [], marker='o', ls='', color=COL[g], label=g + (' (young reference)' if '(Y)' in g else ' (aged)')) for g in COL if g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']],
          loc='lower left', bbox_to_anchor=(0, -0.22), ncol=4, frameon=False)
fig.suptitle('Fig 1. Survival after influenza challenge in aged mice, per experiment (face value, as recorded)', x=0.01, ha='left', fontsize=10)
fig.subplots_adjust(left=0.36, right=0.98, wspace=0.06, bottom=0.16, top=0.93); plt.savefig(F + 'fig1_survival_forest.png', bbox_inches='tight'); plt.close()

# ---------------- Fig 2: KM curves ----------------
kmb = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G', 'S15-H']
fig, axs = plt.subplots(3, 3, figsize=(11, 8.5), sharey=True)
for ax, b in zip(axs.flat, kmb):
    for g in s[s.block == b].group.unique():
        d = surv(b, g)
        sf = SurvfuncRight(d.time.values, d.event.values)
        t = np.r_[0, sf.surv_times, d.time.max()]; p = np.r_[1, sf.surv_prob, sf.surv_prob[-1] if len(sf.surv_prob) else 1]
        c = COL.get(g, {'Untreated': '#000000', '3d Vaccine': '#8c8c8c', '3d PSLN-344': '#e6a817', '3d Vaccine+PSLN-344': '#d2492a'}.get(g, 'k'))
        off = 1.5 if g == 'PSLN-212(Y)' else 0
        ax.step(t, 100 * p + off, where='post', color=c, lw=1.6, ls='--' if g == 'Untreated' else '-', label=f'{g} ({(d.event==0).sum()}/{len(d)})')
    TT = {'S03-I': 'Bivalent vacc -> CA09 10x mLD50 at d14 (homologous)', 'S03-J': 'rgH5N1 vacc -> wt VN04 H5N1 at d2 (22 d obs)',
          'S06-A': 'Aichi H3N2 vacc -> PR8 H1N1 at d14', 'S06-B': 'Aichi H3N2 vacc -> PR8 H1N1 at d3', 'S06-C': 'Bivalent vacc -> rgH5N1 at d14',
          'S06-E': 'Aichi H3N2 vacc -> PR8 H1N1 at d60', 'S06-F': 'Bivalent vacc -> rgH5N1 at d60', 'S06-G': 'CA09 H1N1 vacc -> Perth H3N2 at d60',
          'S15-H': 'Given 3 d before rgH5N1 (antigen requirement)'}
    ax.set_title(f'{b}: ' + TT[b], fontsize=8)
    ax.legend(fontsize=6.5, frameon=False, loc='lower left'); ax.set_ylim(-3, 105)
for ax in axs[:, 0]: ax.set_ylabel('% surviving')
for ax in axs[-1, :]: ax.set_xlabel('days after challenge')
fig.suptitle('Fig 2. Kaplan-Meier curves, aged-mouse challenge experiments (Untreated = unchallenged, unvaccinated aged controls)', x=0.01, ha='left', fontsize=10)
plt.tight_layout(); plt.savefig(F + 'fig2_km_curves.png', bbox_inches='tight'); plt.close()

# ---------------- Fig 3: antibody titres ----------------
ab = [('S03-A', 'IgG anti-CA09 (endpoint)'), ('S03-C', 'HAI anti-CA09'), ('S03-D', 'Neutralising anti-CA09'),
      ('S03-E', 'IgG anti-Aichi (endpoint)'), ('S03-G', 'HAI anti-Aichi'), ('S03-H', 'Neutralising anti-Aichi')]
order = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
fig, axs = plt.subplots(2, 3, figsize=(11, 6.5))
for ax, (b, lab) in zip(axs.flat, ab):
    for i, g in enumerate(order):
        x = v[(v.block == b) & (v.group == g)].value.values.astype(float)
        if b in ('S03-C', 'S03-G'): x = np.where(x < 10, 5, x)
        jit = np.linspace(-0.15, 0.15, len(x))
        ax.scatter(i + jit, x, color=COL[g], s=16, zorder=3)
        gm = np.exp(np.log(x).mean()); ax.hlines(gm, i - 0.3, i + 0.3, color='k', lw=1.5)
        ax.text(i + 0.32, gm, f'{gm:,.0f}', ha='left', va='center', fontsize=6.5, color='#333333')
    ax.set_yscale('log'); ax.set_xlim(-0.5, len(order) - 0.1); ax.set_xticks(range(len(order))); ax.set_xticklabels([o.replace('PSLN-212(Y)', '212 young').replace('PSLN-', '') for o in order], fontsize=8)
    ax.set_title(f'{b}: {lab}, day 14', fontsize=8.5)
    if b in ('S03-C', 'S03-G'): ax.axhline(40, ls=':', color='grey'); ax.text(4.4, 42, '1:40', fontsize=7, color='grey')
fig.suptitle('Fig 3. Day-14 antibody responses (aged unless "young"); bars = geometric mean; HAI <1:10 plotted at 5', x=0.01, ha='left', fontsize=10)
plt.tight_layout(); plt.savefig(F + 'fig3_antibody.png', bbox_inches='tight'); plt.close()

# ---------------- Fig 4: restoration index ----------------
R = pd.read_csv(T + 'restoration_index.csv')
stage = {'Ifnb1 lung 16 h': 'Innate', 'Lung monocytes d4 (peak)': 'Innate', 'Ccl2 lung 16 h (S09-A)': 'Innate', 'Il6 lung 16 h (S09-A)': 'Innate',
         'Lung cDC1 72 h': 'DC / antigen transport', 'Lung CD11b+ DC d4 (peak)': 'DC / antigen transport', 'Lung CCR7+ migratory DC 72 h': 'DC / antigen transport',
         'MLN antigen+ DC 36 h': 'DC / antigen transport', 'MLN CD11b+ DC 72 h': 'DC / antigen transport', 'MLN DC CD40+ d3': 'DC / antigen transport',
         'MLN DC CD86+ d3': 'DC / antigen transport', 'OT-I priming by MLN DC': 'DC / antigen transport',
         'Tfh ICOS-hi d7': 'GC / antibody', 'MLN GC B d7': 'GC / antibody', 'Tfr d7 (falls)': 'GC / antibody', 'HAI CA09 d14': 'GC / antibody',
         'HAI Aichi d14': 'GC / antibody', 'IgG CA09 d14': 'GC / antibody', 'IgG Aichi d14': 'GC / antibody', 'Neut CA09 d14': 'GC / antibody',
         'IgG2a/IgG1 CA09 (re-derived)': 'GC / antibody', 'IgG CA09 d28 boosted': 'GC / antibody', 'IgG Aichi d28 boosted': 'GC / antibody', 'Tfr d30': 'GC / antibody',
         'Lung Ki-67+ CD8 d3': 'CD8 / memory', 'Lung GZMB+ CD8 d3': 'CD8 / memory', 'MLN IFNg+ CD8 d14 (H5N1 restim)': 'CD8 / memory',
         'MLN IFNg+ CD8 d60 (H5N1 restim)': 'CD8 / memory', 'Lung TRM CD8 d25': 'CD8 / memory', 'MLN GZMB+ CD8 d60': 'CD8 / memory',
         'Lung Treg d7 (falls)': 'Regulatory', 'Lung CD206+ macrophages (falls)': 'Regulatory'}
R = R[R.readout.isin(stage)].copy(); R['stage'] = R.readout.map(stage)
sorder = ['Innate', 'DC / antigen transport', 'GC / antibody', 'CD8 / memory', 'Regulatory']
R['so'] = R.stage.map({k: i for i, k in enumerate(sorder)}); R = R.sort_values(['so', 'R'], ascending=[True, False])
fig, ax = plt.subplots(figsize=(8.5, 10))
ys = []; y = 0; prev = None; heads = []
for r in R.itertuples():
    if r.stage != prev:
        y -= 1.2; heads.append((y + 0.55, r.stage)); prev = r.stage
    ys.append(y); y -= 1
ys = np.array(ys)
for yy, r in zip(ys, R.itertuples()):
    ax.plot([r.R_lo, r.R_hi], [yy, yy], color='k', lw=1)
    ax.plot(r.R, yy, 'o', color='#d2492a' if r.R >= 0.8 else ('#e6a817' if r.R >= 0.5 else '#4a90c2'), ms=5)
ax.set_yticks(ys); ax.set_yticklabels([f'{r.readout}  [{r.block}]' for r in R.itertuples()], fontsize=7.5)
for yy, st in heads:
    ax.text(-0.38, yy, st.upper(), fontsize=8, fontweight='bold', color='#444444', va='center')
hl = []
for x, lab, c in [(0.94, 'survival rescue, d14 challenge (0.94)', '#2e8b57'), (0.70, 'survival rescue, fully heterosubtypic (0.70)', '#b58900'), (0.65, 'survival rescue, d60 challenge (0.65)', '#7b3294')]:
    ax.axvline(x, color=c, ls='--', lw=1); hl.append(Line2D([], [], color=c, ls='--', label=lab))
ax.axvline(0, color='grey', lw=0.8); ax.axvline(1, color='grey', lw=0.8)
ax.legend(handles=hl, fontsize=7, frameon=False, loc='upper center', bbox_to_anchor=(0.4, -0.075), ncol=2, title='reference: same index computed on pooled survival proportions (linear; orientation only)', title_fontsize=7)
ax.set_xlim(-0.4, 1.55); ax.set_ylim(ys.min() - 1, 0.5)
ax.set_xlabel('Restoration index R = [aged PSLN-344 - aged PSLN-212] / [young PSLN-212 - aged PSLN-212]\n(mean of log10 per-animal values; 0 = no rescue, 1 = young level; bootstrap 95% CI)')
fig.text(0.01, -0.06, 'Red R>=0.8, amber 0.5-0.8, blue <0.5. Not plotted: Tnf and Il10 at 16 h (S09-A) - young mice are below aged PSLN-212, so R is undefined;\naged PSLN-344 exceeds young PSLN-212 by 2.9x (Tnf) and 4.0x (Il10) - an inflammatory overshoot, not a rescue.', fontsize=7.5, color='#333333')
fig.suptitle('Fig 4. How completely Mn2+ (PSLN-344) rescues each aged-mouse readout toward young-mouse levels', x=0.01, ha='left', fontsize=10)
plt.tight_layout(); plt.savefig(F + 'fig4_restoration_index.png', bbox_inches='tight'); plt.close()

# ---------------- Fig 5: integrity ----------------
fig, axs = plt.subplots(2, 2, figsize=(11, 8))
ax = axs[0, 0]
for k, (b, mk) in enumerate([('S06-C', 'o'), ('S06-D', 'x')]):
    for j, g in enumerate(['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']):
        d = surv(b, g).sort_values('time')
        ax.scatter(d.time + (0.12 if b == 'S06-D' else -0.12), np.full(len(d), j) + np.linspace(-0.3, 0.3, len(d)), marker=mk, color=COL[g], s=22)
ax.set_yticks(range(4)); ax.set_yticklabels(['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']); ax.set_xlabel('day of death / censoring (o = S06-C d14 challenge, x = S06-D d3 challenge)')
ax.set_title('QC-01: S06-C and S06-D are identical, animal for animal (28/28)', fontsize=8.5)
ax = axs[0, 1]
A = v[v.block == 'S11-A']; B = v[v.block == 'S11-B']; m = A.merge(B, on=['group', 'time', 'replicate'])
for rep, c in [(1, '#d2492a'), (2, '#e6a817'), (3, '#4a90c2'), (4, '#4a90c2'), (5, '#4a90c2')]:
    mm = m[m.replicate == rep]; ax.scatter(mm.value_x, mm.value_y, s=14, color=c, label=f'replicate {rep}' if rep <= 3 else None)
ax.plot([10, 55], [10, 55], color='grey', lw=0.8); ax.set_xlabel('S11-A alveolar macrophages, %'); ax.set_ylabel('S11-B neutrophils, %')
ax.legend(fontsize=7, frameon=False); ax.set_title('QC-02: replicates 1-2 identical across two cell types (34/40 cells)', fontsize=8.5)
ax = axs[1, 0]
def traj(b, g, rep):
    d = v[(v.block == b) & (v.group == g) & (v.replicate == rep)].copy(); d['time'] = d.time.astype(float); return d.sort_values('time')
for (b, g, rep, c, ls, mk, lab) in [('S09-E', 'PSLN-344Y', 2, '#2e8b57', '-', 'o', 'S09-E PSLN-344Y #2: young BALB/c, Perth H3N2 (cells X39:X46)'),
                                     ('S15-M', 'PSLN-212(Y)', 1, '#d2492a', '--', 'x', 'S15-M PSLN-212(Y) #1: young C57BL/6 (cells I103:I110)'),
                                     ('S15-A', 'PSLN-344', 3, '#4a90c2', '-', 'o', 'S15-A PSLN-344 #3: aged BALB/c, PR8 (cells Y3:Y10)'),
                                     ('S15-M', 'PSLN-344', 3, '#b58900', '--', 'x', 'S15-M PSLN-344 #3: aged C57BL/6 (cells AF103:AF110)')]:
    d = traj(b, g, rep); ax.plot(d.time, d.value, ls, marker=mk, ms=5, color=c, label=lab, lw=1.3)
ax.annotate('98.98780488 vs 92.98780488\n(one digit differs)', xy=(4, 93.2), xytext=(5.2, 96.6), fontsize=7, arrowprops=dict(arrowstyle='->', lw=0.7))
ax.annotate('82.95798 vs 84.95798', xy=(8.1, 84.3), xytext=(10.4, 83.6), fontsize=7, arrowprops=dict(arrowstyle='->', lw=0.7))
ax.set_xlabel('day after challenge'); ax.set_ylabel('% of day-0 weight'); ax.legend(fontsize=6.5, frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.16), ncol=1)
ax.set_title('QC-03: the same animal trajectories appear in different experiments/strains', fontsize=8.5)
ax = axs[1, 1]
lab = ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
printed = [np.exp(np.log(v[(v.block == 'S03-B') & (v.group == g)].value).mean()) for g in lab]
der = [np.exp(np.log(v[(v.block == 'S13-A') & (v.group == g)].value.values / v[(v.block == 'S13-B') & (v.group == g)].value.values).mean()) for g in lab]
x = np.arange(3); ax.bar(x - 0.18, printed, 0.36, color='#cccccc', label='S03-B as printed'); ax.bar(x + 0.18, der, 0.36, color=[COL[g] for g in lab], label='re-derived S13-A / S13-B')
ax.set_xticks(x); ax.set_xticklabels(['aged PSLN-212', 'aged PSLN-344', 'young PSLN-212']); ax.set_ylabel('IgG2a / IgG1 (geometric mean)')
ax.axhline(1, color='grey', lw=0.8); ax.legend(fontsize=7, frameon=False); ax.set_title('QC-06: S03-B group labels rotated; the correction reverses the Th1/Th2 reading', fontsize=8.5)
fig.suptitle('Fig 5. Data-integrity findings that bear on the decision', x=0.01, ha='left', fontsize=10)
plt.tight_layout(); plt.savefig(F + 'fig5_integrity.png', bbox_inches='tight'); plt.close()

# ---------------- Fig 6: gradient ----------------
def tally(bl, g):
    d = s[s.block.isin(bl) & (s.group == g)]; return int((d.event == 0).sum()), len(d)
cats = [('Homologous\n(S03-I, S03-J)', ['S03-I', 'S03-J']), ('N1 shared\n(S06-C, S06-F)', ['S06-C', 'S06-F']),
        ('Fully heterosubtypic\n(S06-A,-B,-E,-G)', ['S06-A', 'S06-B', 'S06-E', 'S06-G'])]
times = [('d2-3\n(S03-J, S06-B)', ['S03-J', 'S06-B']), ('d14\n(S03-I, S06-A, S06-C)', ['S03-I', 'S06-A', 'S06-C']), ('d60\n(S06-E,-F,-G)', ['S06-E', 'S06-F', 'S06-G'])]
fig, axs = plt.subplots(1, 2, figsize=(11, 4.2), sharey=True)
for ax, cc, ttl in [(axs[0], cats, 'By antigenic relationship of challenge virus to vaccine'), (axs[1], times, 'By interval from vaccination to challenge')]:
    for i, (lab, bl) in enumerate(cc):
        for k, g in enumerate(['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']):
            x, n = tally(bl, g)
            if n == 0: continue
            lo, hi = proportion_confint(x, n, method='beta')
            ax.bar(i + (k - 1) * 0.26, 100 * x / n, 0.24, color=COL[g], yerr=[[100 * (x / n - lo)], [100 * (hi - x / n)]], capsize=2, error_kw={'lw': 0.8})
            ax.text(i + (k - 1) * 0.26, 100 * hi + 2, f'{x}/{n}', ha='center', fontsize=6.5, rotation=90, va='bottom')
    ax.set_xticks(range(len(cc))); ax.set_xticklabels([c[0] for c in cc], fontsize=8); ax.set_title(ttl, fontsize=9)
axs[0].set_ylabel('% surviving (exact 95% CI)')
axs[0].legend(handles=[plt.Rectangle((0, 0), 1, 1, color=COL[g]) for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']], labels=['aged PSLN-212', 'aged PSLN-344', 'young PSLN-212'], fontsize=7.5, frameon=False, loc='upper center', bbox_to_anchor=(1.0, -0.16), ncol=3)
axs[0].set_ylim(0, 122)
fig.suptitle('Fig 6. Aged PSLN-344 protection: complete when HA/NA matched or early; partial when fully heterosubtypic (trend p=0.013) or at d60 (vs young p=0.009).\nThe two factors overlap (2 of the 4 fully heterosubtypic experiments are d60 challenges); at d3/d14 only: 11/14 vs 17/17 homologous, p=0.08.', x=0.01, ha='left', fontsize=9)
fig.subplots_adjust(left=0.06, right=0.99, wspace=0.08, bottom=0.2, top=0.82); plt.savefig(F + 'fig6_gradient.png', bbox_inches='tight'); plt.close()

# ---------------- Fig 7: IFN dose-response and kinetics ----------------
fig, axs = plt.subplots(1, 2, figsize=(11, 4))
d = v[v.block == 'S08-A'].copy(); d['dose'] = d.time.astype(float)
for g, c in [('CMP-204', COL['CMP-204']), ('PSLN-212', COL['PSLN-212']), ('PSLN-344', COL['PSLN-344']), ('PSLN-344/R848', '#7b3294')]:
    dd = d[d.group == g]; gm = dd.groupby('dose').value.apply(lambda x: np.exp(np.log(x).mean()))
    axs[0].scatter(dd.dose * np.exp(np.random.default_rng(0).normal(0, 0.03, len(dd))), dd.value, color=c, s=10, alpha=0.6)
    axs[0].plot(gm.index, gm.values, '-o', color=c, label=g, ms=3)
axs[0].set_xscale('log'); axs[0].set_yscale('log'); axs[0].set_xlabel('dose per mouse, ug (S08-A; age not stated)'); axs[0].set_ylabel('lung Ifnb1, fold vs untreated (16 h)')
axs[0].legend(fontsize=7.5, frameon=False); axs[0].set_title('Dose-response: ~3x dose-sparing vs PSLN-212; plateau 20-40 ug', fontsize=9)
ax = axs[1]
grp = ['Sham', 'CMP-204', 'PSLN-R848', 'PSLN-212', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']
for j, (b, mk) in enumerate([('S01-A_16h', 'o'), ('S01-A_72h', 's')]):
    for i, g in enumerate(grp):
        x = v[(v.block == b) & (v.group == g)].value.values
        ax.scatter(np.full(len(x), i + (j - 0.5) * 0.3), x, marker=mk, s=12, color=COL.get(g.replace('(Y)', '(Y)'), '#555555') if g in COL else ('#2e8b57' if '(Y)' in g else '#555555'))
        ax.hlines(np.exp(np.log(x).mean()), i + (j - 0.5) * 0.3 - 0.12, i + (j - 0.5) * 0.3 + 0.12, color='k')
ax.set_yscale('log'); ax.set_xticks(range(len(grp))); ax.set_xticklabels([g.replace('PSLN-', '') for g in grp], rotation=35, fontsize=7.5)
ax.set_ylabel('lung Ifnb1 fold (o = 16 h, s = 72 h)'); ax.set_title('S01-A: aged PSLN-344 = young PSLN-212 at 16 h (GMR 0.98)', fontsize=9)
fig.suptitle('Fig 7. The earliest Mn2+-dependent signal: type-I IFN induction (candidate pharmacodynamic biomarker)', x=0.01, ha='left', fontsize=10)
plt.tight_layout(); plt.savefig(F + 'fig7_ifn_biomarker.png', bbox_inches='tight'); plt.close()
print('figures written')

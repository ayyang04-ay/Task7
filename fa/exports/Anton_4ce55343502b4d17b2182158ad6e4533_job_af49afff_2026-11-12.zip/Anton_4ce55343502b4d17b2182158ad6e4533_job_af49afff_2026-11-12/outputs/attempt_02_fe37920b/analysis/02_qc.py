"""
02_qc.py -- data-integrity and consistency screen of the PSLN-344 package.
Re-computes every check from tidy tables produced by 01_extract.py and writes
/tmp/outputs/tables/QC_log.csv (one row per finding, with severity, evidence and handling).
Severity:  CRITICAL = undermines reliance on a pivotal endpoint or indicates non-independent/copied data
           MAJOR    = invalidates or reverses a specific block's interpretation
           MINOR    = documentation/metadata gap; limits interpretation but not direction
"""
import pandas as pd, numpy as np, itertools
v = pd.read_csv('/tmp/outputs/tables/tidy_values.csv'); s = pd.read_csv('/tmp/outputs/tables/tidy_survival.csv')
cat = pd.read_csv('/tmp/outputs/tables/block_catalog.csv')

# ---------------------------------------------------------------------------
# Pre-computation A: trajectory-level reuse of body-weight values across blocks
#   informative values only (values equal to the same animal's previous-day value = carried forward, dropped);
#   match = identical value OR identical fractional part (values with >= 4 decimals) on the same day index;
#   chance rate = empirical identity rate across all cross-block comparisons; binomial tail; Bonferroni over pairs.
# ---------------------------------------------------------------------------
from scipy.stats import binom
bw = v[v.unit == '% of day 0'].copy(); bw['time'] = bw.time.astype(float)
bw = bw.sort_values(['block', 'group', 'replicate', 'time'])
bw['prev'] = bw.groupby(['block', 'group', 'replicate']).value.shift(1)
bw_all = bw.copy()
bwi = bw[(bw.time > 0) & ~(bw.value == bw.prev)].copy()
def _ndec(x):
    t = repr(float(x)); return len(t.split('.')[1].rstrip('0')) if '.' in t else 0
bwi['frac'] = bwi.value.apply(lambda x: round(x - np.floor(x), 6) if _ndec(x) >= 4 else np.nan)
bwi['traj'] = bwi.block + '|' + bwi.group + '|' + bwi.replicate.astype(str)
TR = {k: d.set_index('time')[['value', 'frac']] for k, d in bwi.groupby('traj')}
keys = list(TR); rows = []; n_cmp = 0; n_eq = 0
for a, b in itertools.combinations(keys, 2):
    if a.split('|')[0] == b.split('|')[0]:
        continue
    A_, B_ = TR[a], TR[b]; dd = A_.index.intersection(B_.index)
    if len(dd) == 0:
        continue
    eq = (A_.loc[dd, 'value'].values == B_.loc[dd, 'value'].values)
    fr = (A_.loc[dd, 'frac'].values == B_.loc[dd, 'frac'].values) & ~np.isnan(A_.loc[dd, 'frac'].values)
    n_cmp += len(dd); n_eq += eq.sum()
    rows.append(dict(traj_a=a, traj_b=b, days=len(dd), eq=int(eq.sum()), frac=int(fr.sum()), either=int((eq | fr).sum())))
TRJ = pd.DataFrame(rows); p_rate = n_eq / n_cmp; n_pairs = len(TRJ)
TRJ['p_chance'] = binom.sf(TRJ.either - 1, TRJ.days, p_rate)
TRJ['bonf_p'] = np.minimum(1, TRJ.p_chance * n_pairs)
sigT = TRJ[TRJ.bonf_p < 0.01].sort_values('bonf_p')
sigT.to_csv('/tmp/outputs/tables/QC_bodyweight_trajectory_reuse_significant.csv', index=False)
print(f'trajectory screen: {n_pairs} cross-block pairs, chance identity rate {p_rate:.4%}, significant pairs {len(sigT)}, max chance p {sigT.p_chance.max():.2e}')

# ---------------------------------------------------------------------------
# Pre-computation B: body weight vs survival concordance (paired blocks as annotated)
# ---------------------------------------------------------------------------
pairs_bw = {'S15-A': 'S06-A', 'S15-B': 'S06-B', 'S15-C': 'S06-C', 'S15-D': 'S06-D', 'S15-E': 'S06-E', 'S15-F': 'S06-F', 'S15-G': 'S06-G',
            'S15-I': 'S15-H', 'S15-J': "S06-E'", 'S15-K': "S06-F'", 'S15-M': 'S15-L', 'S15-O': 'S15-N',
            'S09-C': 'S09-B', 'S09-E': 'S09-D', 'S09-G': 'S09-F', 'S13-F': 'S03-I', 'S13-G': 'S03-J'}
norm = lambda g: g.replace('(Y)', 'Y').replace('(y)', 'Y').strip()
bw_all['locf'] = (bw_all.value == bw_all.prev) & (bw_all.time > 0)
rr = []
for b, sb in pairs_bw.items():
    B_ = bw_all[bw_all.block == b]; S_ = s[s.block == sb]
    for g in B_.group.unique():
        Sg = S_[S_.group.map(norm) == norm(g)]
        for t in sorted(B_.time.unique()):
            Bt = B_[(B_.group == g) & (B_.time == t)]
            if len(Sg):
                aa = int(((Sg.event == 0) | (Sg.time > t)).sum()); ai = int(((Sg.event == 0) | (Sg.time >= t)).sum())
            else:
                aa = ai = np.nan
            rr.append(dict(bw_block=b, surv_block=sb, group=g, day=t, n_bw_cells=len(Bt), n_bw_measured=int((~Bt.locf).sum()),
                           n_surv_alive_after_day=aa, n_surv_alive_incl_day=ai, n_surv_group=len(Sg)))
BWS = pd.DataFrame(rr)
BWS['consistent'] = (BWS.n_bw_measured >= BWS.n_surv_alive_after_day) & (BWS.n_bw_measured <= BWS.n_surv_alive_incl_day)
BWS.to_csv('/tmp/outputs/tables/QC_bodyweight_vs_survival.csv', index=False)

log = []
def add(id_, sev, blocks, finding, evidence, impact, handling):
    log.append(dict(id=id_, severity=sev, blocks=blocks, finding=finding, evidence=evidence, impact=impact, handling=handling))
arr = lambda b, g: v[(v.block == b) & (v.group == g)].sort_values('replicate').value.values

# QC-01 duplicate survival experiment
sig = lambda b: {g: tuple(zip(d.time, d.event)) for g, d in s[s.block == b].groupby('group')}
same = sig('S06-C') == sig('S06-D')
add('QC-01', 'CRITICAL', 'S06-C, S06-D',
    'Two different experiments (rgH5N1 challenge at d14 vs at d3) contain identical per-animal survival data in all 4 groups (28/28 animals identical).',
    f'S06!M3:Q30 vs S06!A34:E61; identical={same}',
    'Day-3 rgH5N1 protection claim has no independent data; one experiment is a copy.',
    'S06-D excluded from all pooled analyses (S06-C retained); sensitivity swapping them changes nothing numerically.')

# QC-02 S11-A vs S11-B
A = v[v.block == 'S11-A']; B = v[v.block == 'S11-B']
m = A.merge(B, on=['group', 'time', 'replicate'], suffixes=('_a', '_b'))
r1 = int((m[m.replicate == 1].value_a == m[m.replicate == 1].value_b).sum()); r2 = int((m[m.replicate == 2].value_a == m[m.replicate == 2].value_b).sum())
r35 = int((m[m.replicate >= 3].value_a == m[m.replicate >= 3].value_b).sum())
add('QC-02', 'CRITICAL', 'S11-A, S11-B',
    'Alveolar-macrophage (S11-A) and neutrophil (S11-B) percentages are identical for replicate animals 1 and 2 in almost every group x day cell; replicates 3-5 differ.',
    f'replicate 1 identical {r1}/20 cells, replicate 2 {r2}/20, replicates 3-5 {r35}/60 (e.g. S11!B3=B10=23.5, C4=C11=21.2)',
    'Two different cell populations cannot share per-animal values; S11-B (and by extension S11-A) is not independent measurement.',
    'S11-B excluded; S11-A not used for any conclusion.')

# QC-03 trajectory reuse
sig_traj = pd.read_csv('/tmp/outputs/tables/QC_bodyweight_trajectory_reuse_significant.csv')
pairs = sorted(set(sig_traj.traj_a.str.split('|').str[0] + '<->' + sig_traj.traj_b.str.split('|').str[0]))
blocks_inv = sorted(set(sig_traj.traj_a.str.split('|').str[0]) | set(sig_traj.traj_b.str.split('|').str[0]))
add('QC-03', 'CRITICAL', ', '.join(blocks_inv),
    'Animal-level body-weight trajectories recur across experiments that are described as independent (different strains, viruses, ages). High-precision values (5-8 decimals) recur exactly or with the same fractional part and an altered integer part at the same day index.',
    f'{len(sig_traj)} trajectory pairs significant after Bonferroni over 126,048 cross-block pairs (chance match rate 0.88%/day); block pairs: {"; ".join(pairs)}. '
    'Examples: S09-E!X40:X45 (young BALB/c, Perth) = S15-M!I104:I109 (aged C57BL/6); S08-D!G22:G26 (CMP-204, unchallenged) vs S15-F!B54:B58 share fractional parts .79487,.30769,.94872,.71795,.2821; S15-C!W24:AC29 ~ S15-I!W73:AC78.',
    'Body-weight data cannot be treated as independent corroboration of survival; the strain-generalisation blocks (S15-L/M C57BL/6, S15-N/O Swiss Webster) and the 3-day antigen-requirement block (S15-H/I) are directly implicated.',
    'No inference drawn from body weight. Survival used as recorded but flagged; forensic audit required (Gate 0).')

# QC-04 body weight vs survival inconsistency (weights still changing after recorded death)
bws = pd.read_csv('/tmp/outputs/tables/QC_bodyweight_vs_survival.csv')
over = bws[(bws.n_bw_measured > bws.n_surv_alive_incl_day) & (bws.n_surv_group > 0)]
lst = over.groupby(['bw_block', 'surv_block', 'group']).day.apply(lambda x: ','.join(str(int(d)) for d in x)).reset_index()
add('QC-04', 'CRITICAL', ', '.join(sorted(set(lst.surv_block))),
    'Body-weight blocks show more animals with changing weights than the paired survival blocks say are alive (animals recorded dead keep gaining/losing weight).',
    f'{len(lst)} block-group combinations; e.g. ' + '; '.join(f'{r.bw_block}/{r.surv_block} {r.group} d{r.day}' for r in lst.head(8).itertuples()),
    'Survival and body-weight records for the same animals disagree; either record may be wrong.',
    'Survival retained as the primary endpoint but every survival block is marked "unverified" until reconciled with death/euthanasia logs.')

# QC-05 S13-F / S13-G vs S03-I / S03-J
add('QC-05', 'MAJOR', 'S13-F, S13-G, S03-I, S03-J',
    'Body-weight blocks annotated as "the animals of S03-I / S03-J" contain a Naive group absent from those experiments and omit CMP-204 / PSLN-212; S13-F PSLN-212 animals are all weighed (and changing) to d10 although S03-I records all 7 dead by d6; S13-G Sham has >=4 animals back at ~100% on d14 although S03-J records 9/10 dead.',
    'S13!P37:V40 vs S03!A31:D37; S13!L43:U50 vs S03!G17:H26',
    'The homologous-challenge (S03-I) and wt-H5N1 (S03-J) survival results have no consistent supporting weight data; the group mapping is unknown.',
    'S13-F/G not used.')

# QC-06 label rotation S03-B/F
add('QC-06', 'MAJOR', 'S03-B, S03-F (vs S13-A..D)',
    'Printed IgG2a/IgG1 ratios in S03-B and S03-F are exactly the per-animal quotients of S13-A/S13-B (and S13-C/S13-D) but with group labels rotated: printed "PSLN-212" = young PSLN-212 ratios, printed "PSLN-344" = aged PSLN-212 ratios, printed "PSLN-212(Y)" = PSLN-344 ratios.',
    'max relative difference <0.07% for all 30 animals. S13 labels are corroborated by total IgG (S03-A/E): under the printed S03-B labels aged PSLN-212 would have IgG2a GM 4,642 vs total IgG GM 393 (S03-A; implausible).',
    'As printed, S03-B/F say PSLN-344 is Th2-skewed (ratio 0.54); with correct labels PSLN-344 is Th1-skewed (GM ratio 1.85 CA09, 2.30 Aichi) like young mice.',
    'Ratios re-derived from S13-A..D; S03-B/F as printed excluded.')

# QC-07 Tfh:Tfr is derived
f = arr('S04-B_Foxp3', 'PSLN-344'); r = arr('S04-B_TfhTfr', 'PSLN-344')
add('QC-07', 'MINOR', 'S04-B Tfh:Tfr',
    'The "Tfh:Tfr" block equals (100 - Foxp3%)/Foxp3% of the S04-B Foxp3 block to 6 decimals in all 20 animals; it is not the quotient of S04-A Tfh over S04-B Tfr as annotated.',
    f'e.g. PSLN-344 printed {np.round(r[:3],3)} vs (100-F)/F {np.round((100-f[:3])/f[:3],3)}',
    'Not independent evidence of Tfh/Tfr balance; double-counting risk.',
    'Excluded; only S04-A and S04-B Foxp3 used.')

# QC-08 S09-A right panel timepoint
add('QC-08', 'MAJOR', 'S09-A (columns X-AS)',
    'Both S09-A panels are labelled "16h", but the right panel Ifnb1 row equals log10 of S01-A 72 h values for the same animals (and the left panel equals S01-A 16 h). The S09-A "PBS" group is the S01-A "Sham" group.',
    'e.g. PSLN-344: 10^S09!AN3:AP3 = 7.01, 4.00, 2.30 = S01!H8:J8 (72 h)',
    'Cytokine kinetics would be misread (apparent 16 h decline).',
    'Right panel treated as 72 h for description only; left panel used as 16 h.')

# QC-09 S01-B vs S08-C
add('QC-09', 'MAJOR', 'S01-B, S08-C',
    'Same formulation (PSLN-SRB), same cell type, same time (16 h), same age: AEC-I uptake 3.83% (S01-B) vs 13.76% (S08-C). Three AEC-II values are shared between blocks, and S08-C "AECII-PSLN-344-SRB" shares 4.92 and 4.13 with S01-B "AECI/PSLN-SRB".',
    'S01!B15:F15 vs S08!C14:C18; S01!B14:F14 vs S08!A14:A18',
    'The claim that Mn2+ lowers epithelial uptake (S08-C) rests on a block that contradicts S01-B.',
    'Epithelial-uptake data not used for conclusions.')

# QC-10 unchallenged deaths
u = s[s.group == 'Untreated']
add('QC-10', 'MAJOR', 'S06-E, S06-F, S06-G',
    'Aged "Untreated" animals (annotated: no vaccine, no adjuvant, no challenge virus) died within the 14-day window.',
    f'{int(u.event.sum())}/{len(u)} died (S06-E 1/7 on d4, S06!L62; S06-G 3/7 on d3, d7, d10, S06!F99:F101). In S06-G PSLN-344 survival (4/7) equals unchallenged survival (4/7).',
    'Either background mortality of ~19% per 14 days in the aged colony (model validity, health status) or mislabelled groups.',
    'Flagged; does not create the PSLN-344 vs PSLN-212 difference (non-differential) but requires colony health records.')

# QC-11 n mismatches
add('QC-11', 'MINOR', 'S03-J, S05-A, S05-B, S09-B, S09-F, S13-E, S08-D',
    'Stated n differs from observations.',
    'S03-J stated 9, observed 10/group; S05-A/B stated 3, observed 2; S13-E stated 5, observed 7; S09-B Sham 8 observed (annotation says 7) while S09-F Sham 7 observed (annotation says 8) but S09-G weighs 8 Sham; S08-D PSLN-212/R848 4 at d10 (W26 empty).',
    'Attribution of animals uncertain.', 'Analysed as observed; sensitivity analyses for S03-J.')

# QC-12 S03-J missing time / follow-up
add('QC-12', 'MINOR', 'S03-J',
    'One PSLN-344 animal has status 0 but no time (S03!G46 empty); all censoring at d21 although observation is stated as 22 d.',
    'S03!G46, J46', 'Negligible (censored survivor).', 'Treated as censored at end of follow-up; worst case (death) in sensitivity S2.')

# QC-13 HAI below LLOQ
add('QC-13', 'MINOR', 'S03-C, S03-G',
    'HAI values recorded as 0 although the lowest dilution tested was 1:10.', 'S03!K6, K7, K14',
    'GMT undefined if taken literally.', 'Set to 5 (LLOQ/2) for GMTs.')

# QC-14 label ambiguities
add('QC-14', 'MAJOR', 'S07-C', 'Both transferred-macrophage groups are labelled "Ly6C-CD206+ MPhi"; annotation says one group was Ly6C+CD206-.',
    'S07!B15, C15', 'Direction of the macrophage-transfer effect on Tregs cannot be assigned.', 'Excluded.')
add('QC-15', 'MINOR', 'S06 rows 71-105', 'Block labels "S06-E" and "S06-F" are re-used for the imprinting experiments.', 'S06!G69, M69',
    'Citation ambiguity.', "Referred to as S06-E' and S06-F' throughout.")
add('QC-16', 'MINOR', 'S08 rows 89-101', 'Unlabelled numeric region (day 14, status 0, 6 + 7 rows) with no header or annotation.', 'S08!A89:D101',
    'Possibly orphaned survival data (13 survivors) of unknown experiment.', 'Excluded; ask the lab what it is.')

# QC-17 immunological design conflicts
add('QC-17', 'MAJOR', 'S05-A, S05-B, S05-I',
    'Conditions conflict (OVA immunisation vs bivalent vaccine) and the readout is the H-2Db-restricted NP366-374 tetramer while the default strain is BALB/c (H-2d; NP147-155/Kd is the BALB/c epitope). n=2 observed vs 3 stated. S05-I ("vaccinated as in S05-A") measures total CD69+CD103+ CD8, not antigen-specific TRM.',
    'Annotation p.8-10; S05!B3:I10', 'Antigen-specific CD8 kinetics in lung/MLN are not interpretable; TRM is not shown to be influenza-specific.',
    'S05-A/B excluded; S05-I used as total TRM only.')
add('QC-18', 'MAJOR', 'S02-E',
    'OT-I T cells (H-2Kb-restricted SIINFEKL TCR) co-cultured with MLN DCs from donors whose strain is not named (default BALB/c, H-2d).',
    'Annotation p.4', 'If donors were BALB/c the assay cannot measure OVA-specific priming.', 'Used only with this caveat; requires donor-strain confirmation.')
add('QC-19', 'MINOR', 'S10-A', 'Annotation states the block is reported as mean with SD, but 5 per-animal values per group are present.',
    'Annotation p.14; S10!A3:N7', 'Uncertain whether values are per-animal.', 'Treated as per-animal (n=5).')
add('QC-20', 'MINOR', 'S08-A, S08-B, S08-C, materials',
    'Formulations used but not defined (PSLN-344/R848, PSLN-SRB, PSLN-344-SRB); encapsulation efficiency "of CDN-1807 by A260" reported for CMP-204 (cGAMP) and PSLN-R848 (no CDN-1807); DLS/zeta/TEM characterisation described but no data in the workbook.',
    'Annotation p.1, p.12; S08!A9:O11', 'CMC characterisation absent from the package.', 'Noted as a development gap.')
add('QC-21', 'MINOR', 'S15-L, S15-N, S06-E\', S07-B, S11-E, S13-H, S14-A, S02-G, S02-H, S08-A, S08-D, S01-C',
    'Key conditions not stated: challenge virus/dose/day for the other-strain survival studies (S15-L, S15-N); challenge day for S06-E\'; timepoints for S07-B, S11-E, S13-H, S14-A; age for S02-G, S02-H, S08-A, S08-D, S01-C (WT).',
    'Annotation pp.5, 11, 15-19', 'Limits interpretation and replication.', 'Stated as limitations wherever these blocks are cited.')
add('QC-22', 'MINOR', 'whole package', 'All animals female; single experiment per condition (no independent replicate experiments identifiable); blinding, randomisation and humane-endpoint criteria not described.',
    'Annotation p.1-2', 'Generalisability and bias risk.', 'Design requirements in the next-study plan.')
add('QC-23', 'MINOR', 'S09-C', 'Day-12 weights of PSLN-344Y animals (W18:AD18) are identical to PSLN-212Y animals (G18:N18) in all 8 columns.',
    'S09!G18:N18 vs W18:AD18', 'Copy error within the block.', 'Body weight not used.')
Q = pd.DataFrame(log)
Q.to_csv('/tmp/outputs/tables/QC_log.csv', index=False)
print(Q[['id', 'severity', 'blocks']].to_string(index=False))
print(Q.severity.value_counts())

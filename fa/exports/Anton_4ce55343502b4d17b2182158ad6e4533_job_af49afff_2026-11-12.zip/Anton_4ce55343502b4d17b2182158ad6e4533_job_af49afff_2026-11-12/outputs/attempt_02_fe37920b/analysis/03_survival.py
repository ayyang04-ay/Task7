"""
03_survival.py -- per-experiment and pooled survival analysis (aged-mouse challenge studies).

Reductions:
 * Each time-to-event block: one row per animal (days, status 1 = death, 0 = censored) as stored.
 * Per group: survivors/N at end of observation, Clopper-Pearson exact 95% CI.
 * Pairwise per block: log-rank test (statsmodels survdiff) and two-sided Fisher exact on survivors/N.
 * Pooled (stratified by experiment = block):
     - Mantel-Haenszel risk difference in survival (Sato variance) and MH risk ratio of death;
     - exact stratified (conditional) test: sum of survivors in arm 1 vs convolution of hypergeometrics;
     - stratified log-rank (survdiff with strata);
     - Breslow-Day homogeneity test of the OR via statsmodels StratifiedTable (0.5 continuity added to all
       cells of every stratum only for that test).
Analysis sets are defined in the SETS dict BEFORE any pooled statistic is computed.
"""
import pandas as pd, numpy as np, json
from scipy import stats
from statsmodels.duration.survfunc import survdiff
from statsmodels.stats.contingency_tables import StratifiedTable
from statsmodels.stats.proportion import proportion_confint

s = pd.read_csv('/tmp/outputs/tables/tidy_survival.csv')

def cp(k, n):
    lo, hi = proportion_confint(k, n, alpha=0.05, method='beta')
    return lo, hi

def grp(block, group, worst_case_missing=False):
    d = s[(s.block == block) & (s.group == group)].copy()
    if d.time.isna().any():
        # S03-J PSLN-344 animal 10: status 0 with no time (cell G46 empty)
        if worst_case_missing:
            d.loc[d.time.isna(), 'event'] = 1
            d.loc[d.time.isna(), 'time'] = 1.0
        else:
            d.loc[d.time.isna(), 'time'] = d.time.max()   # censored at end of follow-up
    return d

def logrank(d1, d0):
    t = np.r_[d1.time, d0.time]; e = np.r_[d1.event, d0.event]; g = np.r_[np.ones(len(d1)), np.zeros(len(d0))]
    if e.sum() == 0:
        return np.nan, 1.0
    chi, p = survdiff(t, e, g)
    return chi, p

# ------------- per-block table -------------
rows = []
for b in s.block.unique():
    for g in s[s.block == b].group.unique():
        d = grp(b, g)
        n = len(d); surv = int((d.event == 0).sum()); lo, hi = cp(surv, n)
        md = d[d.event == 1].time.median() if (d.event == 1).any() else np.nan
        rows.append(dict(block=b, group=g, age=d.age.iloc[0], n=n, survivors=surv, deaths=n - surv,
                         survival_pct=round(100 * surv / n, 1), ci95_lo=round(100 * lo, 1), ci95_hi=round(100 * hi, 1),
                         median_day_of_death_among_deaths=md, conditions=d.conditions.iloc[0],
                         cells=f"{d.cell_time.iloc[0]}:{d.cell_status.iloc[-1]}"))
per_group = pd.DataFrame(rows)
per_group.to_csv('/tmp/outputs/tables/survival_per_group.csv', index=False)

# pairwise within block
pairs = []
for b in s.block.unique():
    gs = list(s[s.block == b].group.unique())
    cand = [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-212', 'Sham'), ('PSLN-344', 'PSLN-212(Y)'),
            ('Naïve+PSLN-344', 'Naïve+PSLN-212'), ('Imprinting+PSLN-344', 'Imprinting+PSLN-212'),
            ('Imprinting+PSLN-212', 'Naïve+PSLN-212'), ('Imprinting+PSLN-344', 'Naïve+PSLN-344'),
            ('3d Vaccine+PSLN-344', '3d Vaccine'), ('3d Vaccine+PSLN-344', '3d PSLN-344'), ('3d PSLN-344', '3d Vaccine'),
            ('PSLN-344Y', 'Sham'), ('PSLN-212Y', 'Sham'), ('PSLN-344Y', 'PSLN-212Y'),
            ('PSLN-344(Y)', 'Sham'), ('CMP-204(Y)', 'Sham'), ('CMP-204', 'PSLN-212'), ('CMP-204', 'Sham'),
            ('PSLN-344', 'Untreated'), ('Sham', 'Naïve'), ('PSLN-344(Y)', 'CMP-204(Y)')]
    for a, c in cand:
        if a in gs and c in gs:
            d1, d0 = grp(b, a), grp(b, c)
            chi, p_lr = logrank(d1, d0)
            k1, n1 = int((d1.event == 0).sum()), len(d1); k0, n0 = int((d0.event == 0).sum()), len(d0)
            p_f = stats.fisher_exact([[k1, n1 - k1], [k0, n0 - k0]])[1]
            pairs.append(dict(block=b, arm=a, comparator=c, surv_arm=f'{k1}/{n1}', surv_comp=f'{k0}/{n0}',
                              diff_pct=round(100 * (k1 / n1 - k0 / n0), 1), logrank_chi2=None if np.isnan(chi) else round(chi, 2),
                              logrank_p=p_lr, fisher_p=p_f))
pairwise = pd.DataFrame(pairs)
pairwise.to_csv('/tmp/outputs/tables/survival_pairwise_by_block.csv', index=False)

# ------------- analysis sets (defined before pooling) -------------
SETS = {
 'PRIMARY: aged BALB/c, all blocks with 344 & 212 arms, S06-D excluded (exact copy of S06-C)':
     ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G'],
 'S1: primary + other strains (S15-L C57BL/6, S15-N Swiss Webster; challenge conditions not stated)':
     ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N'],
 'S2: primary, S03-J missing-time PSLN-344 animal counted as a death (worst case)': 'WORST',
 'S3: primary minus S03-J (stated n 9 vs 10 observed; missing time)':
     ['S03-I', 'S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G'],
 'S4: naive-at-vaccination middle-aged (S06-E\', S06-F\'; Naive arms only)': 'IMPRINT',
 'SUB-a: homologous challenge (S03-I, S03-J)': ['S03-I', 'S03-J'],
 'SUB-b: heterosubtypic, N1 shared with vaccine (bivalent -> rgH5N1: S06-C, S06-F)': ['S06-C', 'S06-F'],
 'SUB-c: fully heterosubtypic, no HA/NA subtype shared (S06-A, S06-B, S06-E, S06-G)': ['S06-A', 'S06-B', 'S06-E', 'S06-G'],
 'SUB-d: challenge <=3 d after vaccination (S03-J d2, S06-B d3)': ['S03-J', 'S06-B'],
 'SUB-e: challenge at d14 (S03-I, S06-A, S06-C)': ['S03-I', 'S06-A', 'S06-C'],
 'SUB-f: challenge at d60 (S06-E, S06-F, S06-G)': ['S06-E', 'S06-F', 'S06-G'],
}

def strata_tables(blocks, arm1, arm0, worst=False, arm_map=None):
    out = []
    for b in blocks:
        a1 = arm_map[b][0] if arm_map else arm1; a0 = arm_map[b][1] if arm_map else arm0
        d1, d0 = grp(b, a1, worst), grp(b, a0, worst)
        out.append((b, d1, d0))
    return out

def mh_rd(tabs):
    # survival as the 'event' of interest for RD; Sato (1989) variance
    num = den = 0; P = Q = 0
    for b, d1, d0 in tabs:
        n1, n0 = len(d1), len(d0); N = n1 + n0
        a = (d1.event == 0).sum(); c = (d0.event == 0).sum()
        num += (a * n0 - c * n1) / N; den += n1 * n0 / N
    rd = num / den
    for b, d1, d0 in tabs:
        n1, n0 = len(d1), len(d0); N = n1 + n0
        a = (d1.event == 0).sum(); c = (d0.event == 0).sum()
        P += (n1 ** 2 * c - n0 ** 2 * a + n1 * n0 * (n0 - n1) / 2) / N ** 2
        Q += (a * (n0 - c) + c * (n1 - a)) / (2 * N)
    var = (rd * P + Q) / den ** 2
    se = np.sqrt(var)
    return rd, rd - 1.96 * se, rd + 1.96 * se

def mh_rr_death(tabs):
    num = den = 0
    for b, d1, d0 in tabs:
        n1, n0 = len(d1), len(d0); N = n1 + n0
        x1 = d1.event.sum(); x0 = d0.event.sum()
        num += x1 * n0 / N; den += x0 * n1 / N
    return num / den

def exact_stratified(tabs):
    # T = total survivors in arm1; null: hypergeometric within each stratum given margins
    dist = np.array([1.0]); tobs = 0
    for b, d1, d0 in tabs:
        n1, n0 = len(d1), len(d0); a = int((d1.event == 0).sum()); c = int((d0.event == 0).sum()); m = a + c
        ks = np.arange(0, n1 + 1)
        pmf = stats.hypergeom.pmf(ks, n1 + n0, m, n1)
        dist = np.convolve(dist, pmf); tobs += a
    p_upper = dist[tobs:].sum()
    # two-sided by doubling the smaller tail (conservative)
    p_lower = dist[:tobs + 1].sum()
    return tobs, min(1.0, 2 * min(p_upper, p_lower)), p_upper

def strat_logrank(tabs):
    t = []; e = []; g = []; st = []
    for i, (b, d1, d0) in enumerate(tabs):
        t += list(d1.time) + list(d0.time); e += list(d1.event) + list(d0.event)
        g += [1] * len(d1) + [0] * len(d0); st += [i] * (len(d1) + len(d0))
    chi, p = survdiff(np.array(t), np.array(e), np.array(g), strata=np.array(st))
    return chi, p

def breslow_day(tabs):
    tbl = []
    for b, d1, d0 in tabs:
        a = (d1.event == 0).sum(); bb = (d1.event == 1).sum(); c = (d0.event == 0).sum(); d = (d0.event == 1).sum()
        tbl.append(np.array([[a, bb], [c, d]], dtype=float) + 0.5)
    st = StratifiedTable(tbl)
    bd = st.test_equal_odds()
    return st.oddsratio_pooled, bd.pvalue

res = []
for name, spec in SETS.items():
    worst = False; arm_map = None
    if spec == 'WORST':
        blocks = SETS[list(SETS)[0]]; worst = True
    elif spec == 'IMPRINT':
        blocks = ["S06-E'", "S06-F'"]; arm_map = {b: ('Naïve+PSLN-344', 'Naïve+PSLN-212') for b in blocks}
    else:
        blocks = spec
    for arm1, arm0 in [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-212', 'Sham')]:
        if arm_map and arm1 != 'PSLN-344' or (arm_map and arm0 != 'PSLN-212'):
            continue
        tabs = strata_tables(blocks, arm1, arm0, worst, arm_map)
        k1 = sum((d1.event == 0).sum() for _, d1, _ in tabs); n1 = sum(len(d1) for _, d1, _ in tabs)
        k0 = sum((d0.event == 0).sum() for _, _, d0 in tabs); n0 = sum(len(d0) for _, _, d0 in tabs)
        rd, lo, hi = mh_rd(tabs)
        rr = mh_rr_death(tabs)
        tobs, p2, p1 = exact_stratified(tabs)
        chi, plr = strat_logrank(tabs)
        orp, pbd = breslow_day(tabs)
        per_block = '; '.join(f"{b}: {int((d1.event==0).sum())}/{len(d1)} vs {int((d0.event==0).sum())}/{len(d0)}" for b, d1, d0 in tabs)
        l1, h1 = cp(k1, n1); l0, h0 = cp(k0, n0)
        res.append(dict(analysis_set=name, arm=arm1 if not arm_map else 'Naïve+PSLN-344', comparator=arm0 if not arm_map else 'Naïve+PSLN-212',
                        n_experiments=len(blocks),
                        arm_survival=f'{k1}/{n1} ({100*k1/n1:.0f}%, 95% CI {100*l1:.0f}-{100*h1:.0f})',
                        comp_survival=f'{k0}/{n0} ({100*k0/n0:.0f}%, 95% CI {100*l0:.0f}-{100*h0:.0f})',
                        MH_risk_difference_pct=f'{100*rd:.0f} (95% CI {100*lo:.0f} to {100*hi:.0f})',
                        MH_RR_death=round(rr, 3), reduction_in_death_risk_pct=round(100 * (1 - rr), 0),
                        exact_stratified_p_two_sided=p2, stratified_logrank_chi2=round(chi, 1), stratified_logrank_p=plr,
                        breslow_day_homogeneity_p=round(pbd, 3), per_block=per_block))
pooled = pd.DataFrame(res)
pooled.to_csv('/tmp/outputs/tables/survival_pooled.csv', index=False)
pd.set_option('display.width', 300); pd.set_option('display.max_colwidth', 200); pd.set_option('display.max_rows', 200)
print(per_group[['block', 'group', 'age', 'n', 'survivors', 'survival_pct', 'ci95_lo', 'ci95_hi']].to_string(index=False))
print()
print(pairwise.to_string(index=False))
print()
for r in res:
    print(json.dumps(r, default=str, ensure_ascii=False, indent=1))

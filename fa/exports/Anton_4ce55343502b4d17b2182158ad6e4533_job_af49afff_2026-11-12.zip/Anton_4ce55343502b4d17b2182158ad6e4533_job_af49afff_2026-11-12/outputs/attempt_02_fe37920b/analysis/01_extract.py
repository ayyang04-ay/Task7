"""
01_extract.py  --  Extract every block of adjuvant_program_dataset.xlsx into tidy,
cell-traceable tables.

Outputs (in /tmp/outputs/tables/):
  tidy_values.csv    one row per per-animal numeric value (non-survival blocks)
  tidy_survival.csv  one row per animal for time-to-event blocks
  block_catalog.csv  one row per block: sheet, range, stated n, observed n per group

Every value carries the source cell coordinate so the committee can check it.
Block IDs follow the workbook labels; where the workbook re-uses a label
(S06 rows 71-105 re-use "S06-E"/"S06-F") the second instance is suffixed with "'"
(S06-E', S06-F') -- this is flagged in the QC log.
"""
import openpyxl, re, pandas as pd
from openpyxl.utils import column_index_from_string as ci, get_column_letter as gl

SRC = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
wb = openpyxl.load_workbook(SRC, data_only=True)

rows_val, rows_surv, catalog = [], [], []

def cell(ws, col, row):
    return ws[f'{col}{row}'].value

def age_of(group):
    g = group.strip()
    if g.endswith('(Y)') or g.endswith('(y)') or g.endswith('Y') and g.startswith('PSLN'):
        return 'young'
    return 'aged'

def col_range(c1, c2):
    return [gl(i) for i in range(ci(c1), ci(c2) + 1)]

def add_block_meta(block, sheet, rng, stated_n, measurand, unit, timepoint, notes=''):
    catalog.append(dict(block=block, sheet=sheet, range=rng, stated_n=stated_n,
                        measurand=measurand, unit=unit, timepoint=timepoint, notes=notes))

def wide_groups(block, sheet, groups, rows, stated_n, measurand, unit, timepoint,
                time_col=None, time_label=None, age_override=None, notes=''):
    """groups: list of (group_name, first_col, last_col); rows: list of data rows.
    If time_col is given, each row is a timepoint read from time_col."""
    ws = wb[sheet]
    cols_all = []
    for g, c1, c2 in groups:
        for c in col_range(c1, c2):
            cols_all.append(c)
            for r in rows:
                v = cell(ws, c, r)
                if v is None or isinstance(v, str):
                    continue
                t = cell(ws, time_col, r) if time_col else timepoint
                rows_val.append(dict(block=block, sheet=sheet, group=g.strip(),
                                     age=(age_override or {}).get(g, age_of(g)),
                                     time=t, replicate=col_range(c1, c2).index(c) + 1,
                                     value=float(v), cell=f'{c}{r}',
                                     measurand=measurand, unit=unit))
    rng = f'{min(cols_all, key=ci)}{min(rows)}:{max(cols_all, key=ci)}{max(rows)}'
    add_block_meta(block, sheet, rng, stated_n, measurand, unit, timepoint, notes)

def col_groups(block, sheet, header_row, cols, rows, stated_n, measurand, unit, timepoint,
               notes='', age_override=None, names=None):
    """Each group is one column; header in header_row; replicates down rows."""
    ws = wb[sheet]
    for k, c in enumerate(cols):
        g = names[k] if names else str(cell(ws, c, header_row)).strip()
        for i, r in enumerate(rows):
            v = cell(ws, c, r)
            if v is None or isinstance(v, str):
                continue
            rows_val.append(dict(block=block, sheet=sheet, group=g,
                                 age=(age_override or {}).get(g, age_of(g)),
                                 time=timepoint, replicate=i + 1, value=float(v),
                                 cell=f'{c}{r}', measurand=measurand, unit=unit))
    add_block_meta(block, sheet, f'{cols[0]}{header_row}:{cols[-1]}{rows[-1]}', stated_n,
                   measurand, unit, timepoint, notes)

def row_groups(block, sheet, label_col, c1, c2, rows, stated_n, measurand, unit, timepoint,
               notes='', names=None, age_override=None):
    """Each group is one row; label in label_col; replicates across columns c1..c2."""
    ws = wb[sheet]
    for k, r in enumerate(rows):
        g = names[k] if names else str(cell(ws, label_col, r)).strip()
        for j, c in enumerate(col_range(c1, c2)):
            v = cell(ws, c, r)
            if v is None or isinstance(v, str):
                continue
            rows_val.append(dict(block=block, sheet=sheet, group=g,
                                 age=(age_override or {}).get(g, age_of(g)),
                                 time=timepoint, replicate=j + 1, value=float(v),
                                 cell=f'{c}{r}', measurand=measurand, unit=unit))
    add_block_meta(block, sheet, f'{label_col}{rows[0]}:{c2}{rows[-1]}', stated_n,
                   measurand, unit, timepoint, notes)

def survival(block, sheet, day_col, group_cols, header_row, first_row, last_row, stated_n,
             conditions, age_override=None):
    ws = wb[sheet]
    for c in group_cols:
        g = str(cell(ws, c, header_row)).strip()
        k = 0
        for r in range(first_row, last_row + 1):
            s = cell(ws, c, r)
            if s is None:
                continue
            k += 1
            d = cell(ws, day_col, r)
            rows_surv.append(dict(block=block, sheet=sheet, group=g,
                                  age=(age_override or {}).get(g, age_of(g)),
                                  animal=k, time=(None if d is None else float(d)),
                                  event=int(s), cell_time=f'{day_col}{r}', cell_status=f'{c}{r}',
                                  conditions=conditions))
    add_block_meta(block, sheet, f'{day_col}{header_row}:{group_cols[-1]}{last_row}', stated_n,
                   'time to event (death)', 'days', 'post-challenge', conditions)

# ---------------- S01 ----------------
row_groups('S01-A_16h', 'S01', 'A', 'B', 'F', range(3, 11), 5, 'Ifnb1 mRNA, total lung', 'fold vs untreated (linear)', '16 h')
row_groups('S01-A_72h', 'S01', 'G', 'H', 'L', range(3, 11), 5, 'Ifnb1 mRNA, total lung', 'fold vs untreated (linear)', '72 h')
row_groups('S01-B', 'S01', 'A', 'B', 'F', range(14, 18), 5, 'SRB+ alveolar epithelial cells', '%', '16 h',
           age_override={g: 'aged' for g in ['AECII/PSLN-SRB', 'AECI/PSLN-SRB', 'AECII/FreeSRB', 'AECI/FreeSRB']})
row_groups('S01-C', 'S01', 'A', 'B', 'E', range(20, 22), 4, 'DiD+ alveolar macrophages', '%', '16 h',
           notes='age not stated; WT vs Sftpa1-/-Sftpd-/- (7-8 wk per general annotation)',
           age_override={'WT': 'unstated', 'SPA/D': 'young'})
S01D_groups = [('Sham', 'B', 'F'), ('PSLN-212', 'G', 'K'), ('PSLN-344', 'L', 'P'), ('PSLN-212(Y)', 'Q', 'U')]
wide_groups('S01-D', 'S01', S01D_groups, range(24, 29), 5, 'Lung monocytes CD11b+Ly6C+', '%', 'day', time_col='A')
S01E_groups = S01D_groups + [('PSLN-344(Y)', 'V', 'Z')]
wide_groups('S01-E', 'S01', S01E_groups, range(30, 35), 5, 'Lung CD11b+ DC', '%', 'day', time_col='A')
wide_groups('S01-F', 'S01', S01E_groups, [36], 5, 'Lung cDC1 (XCR1+)', '%', '72 h')
wide_groups('S01-G', 'S01', S01E_groups, [38], 5, 'Lung cDC2 (CD172a+)', '%', '72 h')

# ---------------- S02 ----------------
col_groups('S02-A', 'S02', 2, list('ABCD'), range(3, 8), 5, 'Lung migratory CCR7+ CD11b+ DC', '%', '72 h')
col_groups('S02-B', 'S02', 2, list('FGHI'), range(3, 8), 5, 'MLN CD11b+CD103- DC', '%', '72 h')
col_groups('S02-C', 'S02', 2, list('KLMNO'), range(3, 8), 5, 'MLN DC AF647-OVA+', '%', '36 h',
           age_override={'PTX': 'aged?'})
col_groups('S02-D_CD40', 'S02', 9, list('ABCD'), range(10, 15), 5, 'CD40+ of MLN CD11b+ DC', '%', 'day 3')
col_groups('S02-D_CD86', 'S02', 9, list('FGHI'), range(10, 15), 5, 'CD86+ of MLN CD11b+ DC', '%', 'day 3')
col_groups('S02-E', 'S02', 9, list('KLMNO'), range(10, 15), 5, 'OT-I proliferation with MLN CD11b+ DC', '%', 'DC 72 h; 3 d co-culture',
           age_override={'PTX': 'aged?'})
S02F_groups = [('PSLN-344', 'B', 'F'), ('PSLN-212', 'G', 'K'), ('Sham', 'L', 'P')]
wide_groups('S02-F', 'S02', S02F_groups, range(17, 20), 5, 'Gm-csf mRNA, lung', 'fold vs untreated (linear)', 'h', time_col='A')
col_groups('S02-G', 'S02', 21, list('BCD'), range(22, 27), 5, 'Lung Ly6C+CD11c+MHCII+ (moDC-like)', '%', 'day 5',
           notes='age not stated', age_override={'GM-CSF': 'unstated', 'PSLN-212': 'unstated', 'PSLN-212+GM-CSF': 'unstated'})
col_groups('S02-H', 'S02', 29, list('BCDEF'), range(30, 35), 5, 'CD45.2+ moDC (BM chimera)', '%', 'day 3',
           notes='age not stated', age_override={g: 'unstated' for g in ['WT w/o cDC', 'WT w/ cDC', 'IFN w/o cDC', 'IFN w/ cDC', 'GMCSF']})
col_groups('S02-I', 'S02', 29, list('HI'), range(30, 35), 5, 'Lung GZMB+ CD8 T', '%', 'day 5',
           age_override={'PSLN-344(Y)': 'young', 'PSLN-344(Y)+INCB3344': 'young'})

# ---------------- S03 ----------------
col_groups('S03-A', 'S03', 2, list('ABCDE'), range(3, 8), 5, 'Serum IgG anti-CA09 H1N1', 'endpoint titre', 'day 14')
col_groups('S03-B', 'S03', 2, list('GHI'), range(3, 8), 5, 'IgG2a/IgG1 ratio anti-CA09', 'ratio', 'day 14')
col_groups('S03-C', 'S03', 2, list('KLMNO'), range(3, 8), 5, 'HAI anti-CA09 H1N1', 'reciprocal titre (LLOQ 10)', 'day 14')
col_groups('S03-D', 'S03', 2, list('QRSTU'), range(3, 8), 5, 'Neutralising Ab anti-CA09 H1N1', 'reciprocal titre', 'day 14')
col_groups('S03-E', 'S03', 9, list('ABCDE'), range(10, 15), 5, 'Serum IgG anti-Aichi H3N2', 'endpoint titre', 'day 14')
col_groups('S03-F', 'S03', 9, list('GHI'), range(10, 15), 5, 'IgG2a/IgG1 ratio anti-Aichi', 'ratio', 'day 14')
col_groups('S03-G', 'S03', 9, list('KLMNO'), range(10, 15), 5, 'HAI anti-Aichi H3N2', 'reciprocal titre (LLOQ 10)', 'day 14')
col_groups('S03-H', 'S03', 9, list('QRSTU'), range(10, 15), 5, 'Neutralising Ab anti-Aichi H3N2', 'reciprocal titre', 'day 14')
survival('S03-I', 'S03', 'A', list('BCDEF'), 16, 17, 51, 7,
         'aged BALB/c; bivalent vaccine (CA09 H1N1 + Aichi H3N2; vaccinated as in S03-A) i.n.; 10x mLD50 CA09 H1N1 at d14; homologous to the CA09 component; obs 14 d')
survival('S03-J', 'S03', 'G', list('HIJ'), 16, 17, 46, 9,
         'aged BALB/c; rgH5N1 vaccine i.n.; wild-type VN04 H5N1 at d2; obs 22 d')
col_groups('S03-K', 'S03', 16, list('LMNO'), range(17, 22), 5, 'MLN GC B (CXCR5+GL7+)', '%', 'day 7')
row_groups('S03-L_Aicda', 'S03', 'K', 'L', 'N', range(26, 29), 3, 'Aicda mRNA, MLN B', 'fold vs untreated (linear)', 'day 5')
row_groups('S03-L_E47', 'S03', 'K', 'O', 'Q', range(26, 29), 3, 'E47 mRNA, MLN B', 'fold vs untreated (linear)', 'day 5')

# ---------------- S04 ----------------
row_groups('S04-A_ICOSlo', 'S04', 'A', 'B', 'F', range(2, 6), 5, 'Tfh CXCR5+PD1+ ICOS-low', '%', 'day 7')
row_groups('S04-A_ICOShi', 'S04', 'A', 'G', 'K', range(2, 6), 5, 'Tfh CXCR5+PD1+ ICOS-high', '%', 'day 7')
col_groups('S04-B_Foxp3', 'S04', 7, list('ABCD'), range(8, 13), 5, 'Tfr Foxp3+ of CXCR5+ICOShi', '%', 'day 7')
col_groups('S04-B_TfhTfr', 'S04', 14, list('ABCD'), range(15, 20), 5, 'Tfh:Tfr ratio', 'ratio', 'day 7')
col_groups('S04-C', 'S04', 21, list('ABCD'), range(22, 27), 5, 'Tfr Foxp3+ of CXCR5+ICOShi', '%', 'day 30')
col_groups('S04-D', 'S04', 28, list('ABCD'), range(29, 32), 3, 'Lung Treg CD4+Foxp3+', '%', 'day 7')

# ---------------- S05 ----------------
S05A_groups = [('PSLN-212', 'B', 'C'), ('PSLN-344', 'E', 'F'), ('PSLN-212Y', 'H', 'I')]
wide_groups('S05-A', 'S05', S05A_groups, range(3, 6), 3, 'Lung NP366 tetramer+ CD8', '%', 'day', time_col='A')
wide_groups('S05-B', 'S05', S05A_groups, range(8, 11), 3, 'MLN NP366 tetramer+ CD8', '%', 'day', time_col='A')
col_groups('S05-C', 'S05', 12, list('ABCD'), range(13, 16), 3, 'OT-I proliferation in vivo', '%', 'day 4',
           age_override={g: 'unstated' for g in ['Lung', 'Lung+PTX', 'MLN', 'MLN+PTX']})
col_groups('S05-D', 'S05', 18, list('ABCD'), range(19, 24), 5, 'Lung Ki-67+ CD8 T', '%', 'day 3')
col_groups('S05-E', 'S05', 25, list('ABCD'), range(26, 31), 5, 'Lung GZMB+ CD8 T', '%', 'day 3')
col_groups('S05-F', 'S05', 32, list('ABCD'), range(33, 38), 5, 'MLN IFNg+ CD8 (rgH5N1 restim)', '%', 'day 14')
col_groups('S05-G', 'S05', 39, list('ABCD'), range(40, 45), 5, 'MLN IFNg+ CD8 (rgH5N1 restim)', '%', 'day 60')
col_groups('S05-H', 'S05', 46, list('ABCD'), range(47, 52), 5, 'MLN GZMB+ CD8', '%', 'day 60')
col_groups('S05-I', 'S05', 53, list('ABCD'), range(54, 59), 5, 'Lung TRM CD8 (CD69+CD103+)', '%', 'day 25')

# ---------------- S06 (survival) ----------------
c6 = 'aged BALB/c (20 mo+); vaccinated once i.n.; obs 14 d'
survival('S06-A', 'S06', 'A', list('BCDE'), 2, 3, 30, 7, c6 + '; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 at d14; heterosubtypic')
survival('S06-B', 'S06', 'G', list('HIJK'), 2, 3, 30, 7, c6 + '; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 at d3; heterosubtypic')
survival('S06-C', 'S06', 'M', list('NOPQ'), 2, 3, 30, 7, c6 + '; bivalent vaccine; 5x mLD50 rgH5N1 at d14; heterosubtypic (HA)')
survival('S06-D', 'S06', 'A', list('BCDE'), 33, 34, 68, 7, c6 + '; bivalent vaccine; 5x mLD50 rgH5N1 at d3; heterosubtypic (HA)')
survival('S06-E', 'S06', 'G', list('HIJKL'), 33, 34, 68, 7, c6 + '; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 at d60; heterosubtypic',
         age_override={'Untreated': 'aged-unchallenged'})
survival('S06-F', 'S06', 'M', list('NOPQR'), 33, 34, 68, 7, c6 + '; bivalent vaccine; 5x mLD50 rgH5N1 at d60; heterosubtypic (HA)',
         age_override={'Untreated': 'aged-unchallenged'})
survival('S06-G', 'S06', 'A', list('BCDEF'), 70, 71, 105, 7, c6 + '; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 at d60; heterosubtypic',
         age_override={'Untreated': 'aged-unchallenged'})
imp = {g: 'middle-aged (14 mo at vaccination)' for g in ['Naïve+PSLN-212', 'Imprinting+PSLN-212', 'Naïve+PSLN-344', 'Imprinting+PSLN-344']}
survival("S06-E'", 'S06', 'G', list('HIJK'), 70, 71, 98, 7,
         'BALB/c infected at 10 mo with 1x mLD50 PR8 or saline; 4 mo later bivalent vaccine; 5x LD50 PR8 H1N1 (timing not stated)', age_override=imp)
survival("S06-F'", 'S06', 'M', list('NOPQ'), 70, 71, 98, 7,
         'BALB/c infected at 10 mo with 1x mLD50 PR8 or saline; 4 mo later bivalent vaccine; 5x LD50 Perth H3N2 at d14', age_override=imp)

# ---------------- S07 ----------------
wide_groups('S07-A', 'S07', [('PSLN-212', 'B', 'D'), ('PSLN-344', 'E', 'G')], range(3, 8), 3,
            'Lung Ly6C+CCR2+ macrophages', 'cells x10^5', 'day', time_col='A')
col_groups('S07-B_mono', 'S07', 9, list('BC'), range(10, 15), 5, 'Lung CD11b+Ly6C+ monocytes', '%', 'not stated')
col_groups('S07-B_Ly6Cmac', 'S07', 9, list('EF'), range(10, 15), 5, 'Lung Ly6C+ macrophages', '%', 'not stated')
col_groups('S07-C', 'S07', 15, list('BC'), range(16, 21), 5, 'Lung Treg after macrophage transfer', '%', 'day 4 post-transfer',
           names=['Ly6C-CD206+ MPhi [col B]', 'Ly6C-CD206+ MPhi [col C]'],
           age_override={'Ly6C-CD206+ MPhi [col B]': 'aged', 'Ly6C-CD206+ MPhi [col C]': 'aged'})

# ---------------- S08 ----------------
wide_groups('S08-A', 'S08', [('CMP-204', 'B', 'D'), ('PSLN-212', 'E', 'G'), ('PSLN-344', 'H', 'J'), ('PSLN-344/R848', 'K', 'M')],
            range(3, 8), 3, 'Lung Ifnb1 mRNA (dose-response)', 'fold vs untreated (linear)', 'dose_ug', time_col='A',
            age_override={g: 'unstated' for g in ['CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-344/R848']})
wide_groups('S08-B', 'S08', [('CMP-204', 'A', 'C'), ('PSLN-212', 'D', 'F'), ('PSLN-R848', 'G', 'I'), ('PSLN-212/R848', 'J', 'L'), ('PSLN-344', 'M', 'O')],
            [11], 3, 'Encapsulation efficiency', '%', 'n/a',
            age_override={g: 'n/a' for g in ['CMP-204', 'PSLN-212', 'PSLN-R848', 'PSLN-212/R848', 'PSLN-344']})
col_groups('S08-C', 'S08', 13, list('ABCD'), range(14, 19), 5, 'SRB+ alveolar epithelial cells', '%', '16 h',
           age_override={g: 'aged' for g in ['AECII-PSLN-SRB', 'AECII-PSLN-344-SRB', 'AECI-PSLN-SRB', 'AECI-PSLN-344-SRB']})
wide_groups('S08-D', 'S08', [('PSLN-212(Y)', 'B', 'F'), ('CMP-204', 'G', 'K'), ('PSLN-212', 'L', 'P'), ('PSLN-344', 'Q', 'U'),
                             ('PSLN-212/R848', 'V', 'Z'), ('Vaccine', 'AA', 'AE')], range(21, 27), 5,
            'Body weight after vaccination (reactogenicity)', '% of day 0', 'day', time_col='A',
            notes='age of non-(Y) groups not stated')

# ---------------- S09 ----------------
S09A_L = [('PBS', 'B', 'D'), ('CMP-204', 'E', 'G'), ('PSLN-212', 'H', 'J'), ('PSLN-R848', 'K', 'M'),
          ('PSLN-212/R848', 'N', 'P'), ('PSLN-344', 'Q', 'S'), ('PSLN-212(y)', 'T', 'V')]
S09A_R = [('PBS', 'Y', 'AA'), ('CMP-204', 'AB', 'AD'), ('PSLN-212', 'AE', 'AG'), ('PSLN-R848', 'AH', 'AJ'),
          ('PSLN-212/R848', 'AK', 'AM'), ('PSLN-344', 'AN', 'AP'), ('PSLN-212(y)', 'AQ', 'AS')]
ws = wb['S09']
for label, groups, acol in [('S09-A_left', S09A_L, 'A'), ('S09-A_right', S09A_R, 'X')]:
    for r in range(3, 10):
        analyte = ws[f'{acol}{r}'].value
        for g, c1, c2 in groups:
            for j, c in enumerate(col_range(c1, c2)):
                v = ws[f'{c}{r}'].value
                rows_val.append(dict(block=label, sheet='S09', group=g, age=age_of(g), time=analyte,
                                     replicate=j + 1, value=float(v), cell=f'{c}{r}',
                                     measurand='Lung cytokine/chemokine mRNA (analyte in time col)',
                                     unit='log10 fold vs untreated'))
    add_block_meta(label, 'S09', f'{acol}2:{groups[-1][2]}9', 3, 'Lung cytokine/chemokine mRNA panel',
                   'log10 fold', 'labelled 16 h (both panels)')
survival('S09-B', 'S09', 'A', list('BCD'), 11, 12, 35, 8, 'young BALB/c; Aichi H3N2 vaccine; 5x mLD50 PR8 H1N1 at d21; heterosubtypic')
wide_groups('S09-C', 'S09', [('PSLN-212Y', 'G', 'N'), ('Sham', 'O', 'V'), ('PSLN-344Y', 'W', 'AD')], range(12, 20), 8,
            'Body weight post-challenge (animals of S09-B)', '% of day 0', 'day', time_col='F',
            age_override={'Sham': 'young', 'PSLN-212Y': 'young', 'PSLN-344Y': 'young'})
survival('S09-D', 'S09', 'A', list('BCD'), 38, 39, 62, 8, 'young BALB/c; CA09 H1N1 vaccine; 5x mLD50 Perth H3N2 at d21; heterosubtypic')
wide_groups('S09-E', 'S09', [('PSLN-212Y', 'G', 'N'), ('Sham', 'O', 'V'), ('PSLN-344Y', 'W', 'AD')], range(39, 47), 8,
            'Body weight post-challenge (animals of S09-D)', '% of day 0', 'day', time_col='F',
            age_override={'Sham': 'young', 'PSLN-212Y': 'young', 'PSLN-344Y': 'young'})
survival('S09-F', 'S09', 'A', list('BCD'), 65, 66, 88, 8, 'young BALB/c; bivalent vaccine; 5x mLD50 VN04 rgH5N1 at d180; heterosubtypic (HA)')
wide_groups('S09-G', 'S09', [('PSLN-212Y', 'G', 'N'), ('Sham', 'O', 'V'), ('PSLN-344Y', 'W', 'AD')], range(66, 74), 8,
            'Body weight post-challenge (animals of S09-F)', '% of day 0', 'day', time_col='F',
            age_override={'Sham': 'young', 'PSLN-212Y': 'young', 'PSLN-344Y': 'young'})
# fix age for young survival groups in S09 (Sham in S09 are young)
for r in rows_surv:
    if r['block'] in ('S09-B', 'S09-D', 'S09-F'):
        r['age'] = 'young'

# ---------------- S10 ----------------
col_groups('S10-A_Ifnb1', 'S10', 2, list('ABCD'), range(3, 8), 5, 'CNS Ifnb1 mRNA', 'fold vs untreated (linear)', '36 h')
col_groups('S10-A_Tnf', 'S10', 2, list('FGHI'), range(3, 8), 5, 'CNS Tnf mRNA', 'fold vs untreated (linear)', '36 h')
col_groups('S10-A_Isg15', 'S10', 2, list('KLMN'), range(3, 8), 5, 'CNS Isg15 mRNA', 'fold vs untreated (linear)', '36 h')

# ---------------- S11 ----------------
S11g = [('Vaccine', 'B', 'F'), ('PSLN-212', 'G', 'K'), ('PSLN-344', 'L', 'P'), ('PSLN-212(Y)', 'Q', 'U')]
wide_groups('S11-A', 'S11', S11g, range(3, 8), 5, 'Lung alveolar macrophages', '%', 'day', time_col='A')
wide_groups('S11-B', 'S11', S11g, range(10, 15), 5, 'Lung neutrophils', '%', 'day', time_col='A')
col_groups('S11-C', 'S11', 16, list('AB'), range(17, 22), 5, 'Lung recruited monocytes (CBX)', '%', 'day 3')
wide_groups('S11-D', 'S11', S11g, range(24, 29), 5, 'Lung NK cells', '%', 'day', time_col='A')
col_groups('S11-E', 'S11', 30, list('ABCD'), range(31, 36), 5, 'Lung CD206+ macrophages', '%', 'not stated')

# ---------------- S12 ----------------
col_groups('S12-A', 'S12', 2, list('AB'), range(3, 6), 3, 'Infiltrating CD45.2+ monocytes (BM chimera)', '%', 'day 3',
           age_override={'WT to WT': 'young', 'IFNAR-/- to WT': 'young'})

# ---------------- S13 ----------------
col_groups('S13-A', 'S13', 2, list('ABC'), range(3, 8), 5, 'Serum IgG2a anti-CA09', 'endpoint titre', 'day 14')
col_groups('S13-B', 'S13', 2, list('EFG'), range(3, 8), 5, 'Serum IgG1 anti-CA09', 'endpoint titre', 'day 14')
col_groups('S13-C', 'S13', 2, list('IJK'), range(3, 8), 5, 'Serum IgG2a anti-Aichi', 'endpoint titre', 'day 14')
col_groups('S13-D', 'S13', 2, list('MNO'), range(3, 8), 5, 'Serum IgG1 anti-Aichi', 'endpoint titre', 'day 14')
survival('S13-E', 'S13', 'R', list('STUV'), 2, 3, 30, 5,
         'young BALB/c; bivalent vaccine (vaccinated as in S03-I); 10x mLD50 CA09 at d14; homologous to the CA09 component; obs 14 d',
         age_override={'Naïve': 'young', 'Sham': 'young', 'CMP-204(Y)': 'young', 'PSLN-344(Y)': 'young'})
wide_groups('S13-F', 'S13', [('PSLN-212(Y)', 'B', 'H'), ('Sham', 'I', 'O'), ('PSLN-212', 'P', 'V'), ('PSLN-344', 'W', 'AC'), ('Naïve', 'AD', 'AJ')],
            range(33, 41), 7, 'Body weight post-challenge (annotated: animals of S03-I)', '% of day 0', 'day', time_col='A')
wide_groups('S13-G', 'S13', [('PSLN-344', 'B', 'K'), ('Sham', 'L', 'U'), ('Naïve', 'V', 'AE')], range(43, 51), 10,
            'Body weight post-challenge (annotated: animals of S03-J)', '% of day 0', 'day', time_col='A')
col_groups('S13-H', 'S13', 52, list('ABCD'), range(53, 58), 5, 'MLN B220+ IgG+', '%', 'not stated')
col_groups('S13-I', 'S13', 52, list('FGHIJ'), range(53, 58), 5, 'Serum IgG anti-CA09 (boosted)', 'endpoint titre', 'day 28 (boost d14)')
col_groups('S13-J', 'S13', 52, list('LMNOP'), range(53, 58), 5, 'Serum IgG anti-Aichi (boosted)', 'endpoint titre', 'day 28 (boost d14)')

# ---------------- S14 ----------------
col_groups('S14-A_H1N1', 'S14', 2, list('ABCD'), range(3, 8), 5, 'MLN IFNg+ CD8 (CA09 restim)', '%', 'not stated')
col_groups('S14-A_H3N2', 'S14', 2, list('FGHI'), range(3, 8), 5, 'MLN IFNg+ CD8 (Aichi restim)', '%', 'not stated')

# ---------------- S15 ----------------
S15g4 = [('PSLN-212(Y)', 'B', 'H'), ('Sham', 'I', 'O'), ('PSLN-212', 'P', 'V'), ('PSLN-344', 'W', 'AC')]
S15g5 = S15g4 + [('Untreated', 'AD', 'AJ')]
bw = 'Body weight post-challenge'
wide_groups('S15-A', 'S15', S15g4, range(3, 11), 7, bw + ' (Aichi vacc; PR8 d14) [pairs S06-A]', '% of day 0', 'day', time_col='A')
wide_groups('S15-B', 'S15', S15g4, range(13, 21), 7, bw + ' (Aichi vacc; PR8 d3) [pairs S06-B]', '% of day 0', 'day', time_col='A')
wide_groups('S15-C', 'S15', S15g4, range(23, 31), 7, bw + ' (bivalent; rgH5N1 d14) [pairs S06-C]', '% of day 0', 'day', time_col='A')
wide_groups('S15-D', 'S15', S15g4, range(33, 41), 7, bw + ' (bivalent; rgH5N1 d3) [pairs S06-D]', '% of day 0', 'day', time_col='A')
wide_groups('S15-E', 'S15', S15g5, range(43, 51), 7, bw + ' (Aichi; PR8 d60) [pairs S06-E]', '% of day 0', 'day', time_col='A',
            age_override={'Untreated': 'aged-unchallenged'})
wide_groups('S15-F', 'S15', S15g5, range(53, 61), 7, bw + ' (bivalent; rgH5N1 d60) [pairs S06-F]', '% of day 0', 'day', time_col='A',
            age_override={'Untreated': 'aged-unchallenged'})
wide_groups('S15-G', 'S15', S15g5, range(63, 71), 7, bw + ' (CA09; Perth d60) [pairs S06-G]', '% of day 0', 'day', time_col='A',
            age_override={'Untreated': 'aged-unchallenged'})
survival('S15-H', 'S15', 'A', list('BCD'), 72, 73, 93, 7,
         'aged BALB/c; bivalent vaccine and/or PSLN-344 i.n. 3 d before 5x mLD50 VN04 rgH5N1',
         age_override={'3d Vaccine': 'aged', '3d PSLN-344': 'aged', '3d Vaccine+PSLN-344': 'aged'})
wide_groups('S15-I', 'S15', [('3d Vaccine', 'I', 'O'), ('3d PSLN-344', 'P', 'V'), ('3d Vaccine+PSLN-344', 'W', 'AC')], range(72, 80), 7,
            bw + ' (animals of S15-H)', '% of day 0', 'day', time_col='H',
            age_override={'3d Vaccine': 'aged', '3d PSLN-344': 'aged', '3d Vaccine+PSLN-344': 'aged'})
impg = [('Naïve+PSLN-212', 'I', 'O'), ('Imprinting+PSLN-212', 'P', 'V'), ('Naïve+PSLN-344', 'W', 'AC'), ('Imprinting+PSLN-344', 'AD', 'AJ')]
wide_groups('S15-J', 'S15', impg, range(83, 91), 7, bw + " (imprinting; PR8) [pairs S06-E']", '% of day 0', 'day', time_col='H', age_override=imp)
wide_groups('S15-K', 'S15', impg, range(93, 101), 7, bw + " (imprinting; Perth) [pairs S06-F']", '% of day 0', 'day', time_col='H', age_override=imp)
survival('S15-L', 'S15', 'A', list('BCDE'), 102, 103, 130, 7,
         'aged C57BL/6 (20 mo); bivalent vaccine i.n.; challenge virus/dose/timing NOT STATED')
S15g4_right = [('PSLN-212(Y)', 'I', 'O'), ('Sham', 'P', 'V'), ('PSLN-212', 'W', 'AC'), ('PSLN-344', 'AD', 'AJ')]
wide_groups('S15-M', 'S15', S15g4_right, range(103, 111), 7, bw + ' (C57BL/6) [pairs S15-L]', '% of day 0', 'day', time_col='H')
survival('S15-N', 'S15', 'A', list('BCDE'), 133, 134, 161, 7,
         'aged Swiss Webster (20 mo); bivalent vaccine i.n.; challenge virus/dose/timing NOT STATED')
wide_groups('S15-O', 'S15', S15g4_right, range(134, 142), 7, bw + ' (Swiss Webster) [pairs S15-N]', '% of day 0', 'day', time_col='H')

# ---------------- orphan region ----------------
ws = wb['S08']
orph = []
for r in range(89, 102):
    orph.append(dict(row=r, A=ws[f'A{r}'].value, C=ws[f'C{r}'].value, D=ws[f'D{r}'].value))
pd.DataFrame(orph).to_csv('/tmp/outputs/tables/S08_orphan_region_rows89_101.csv', index=False)
add_block_meta('S08-orphan', 'S08', 'A89:D101', None, 'UNLABELLED', 'unknown', 'unknown',
               'no label/header; looks like censored time-to-event (day 14, status 0): 6 + 7 rows; excluded')

vals = pd.DataFrame(rows_val)
surv = pd.DataFrame(rows_surv)
cat = pd.DataFrame(catalog)

# observed n per group
obs = vals.groupby(['block', 'group', 'time'], dropna=False).size().reset_index(name='n_obs')
obs_s = surv.groupby(['block', 'group']).size().reset_index(name='n_obs')
vals.to_csv('/tmp/outputs/tables/tidy_values.csv', index=False)
surv.to_csv('/tmp/outputs/tables/tidy_survival.csv', index=False)
cat.to_csv('/tmp/outputs/tables/block_catalog.csv', index=False)
obs.to_csv('/tmp/outputs/tables/observed_n_values.csv', index=False)
obs_s.to_csv('/tmp/outputs/tables/observed_n_survival.csv', index=False)
print(len(vals), 'values;', len(surv), 'animals in survival blocks;', len(cat), 'blocks')

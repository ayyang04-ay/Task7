#!/usr/bin/env bash
# Re-runs the full PSLN-344 analysis from the source workbook. Requires the `chem` micromamba env
# (pandas, scipy, statsmodels, openpyxl, xlsxwriter, matplotlib).
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p ../tables ../figures
for s in 01_extract.py 02_qc.py 03_survival.py 04_immunology.py 05_figures.py 06_evidence.py; do
  echo "== $s"; micromamba run -n chem python "$s" > /dev/null
done
echo "done: tables/, figures/, PSLN-344_evidence_workbook.xlsx regenerated"

"""
04_immunology.py -- group summaries, pairwise contrasts and Tukey HSD for every non-survival,
non-body-weight block; restoration index for aged PSLN-344.

Conventions / reductions
 * Titres (endpoint, HAI, neutralisation), qPCR fold-changes and ratios: analysed on log10 scale;
   summary = geometric mean (GM); contrast = GM ratio (GMR) with Welch 95% CI on log10 values.
 * HAI values recorded as 0 (below the stated lowest dilution 1:10) are set to 5 (= LLOQ/2) before
   log transformation -- standard convention; sensitivity with 10 reported for key numbers.
 * S09-A values are already log10; analysed as given.
 * Percentages / counts: arithmetic mean +/- SD; contrast = mean difference (Welch 95% CI) and ratio of means.
 * Every contrast also gets an exact two-sided Mann-Whitney U p (n=5 vs 5 -> minimum p = 0.0079).
 * Tukey HSD (statsmodels pairwise_tukeyhsd) across all groups in the block at the same timepoint
   (the stated method in the annotation), on the analysis scale above.
 * Blocks excluded from inference (see QC log): S11-B (copied from S11-A), S05-A/S05-B (n=2 vs stated 3;
   contradictory conditions; H-2Db epitope in BALB/c), S07-C (both groups carry the same label),
   S03-B/S03-F as printed (group labels rotated; ratios re-derived from S13-A..D instead),
   S04-B Tfh:Tfr (arithmetic transform of S04-B Foxp3), S09-A right panel (labelled 16 h but = 72 h data).
"""
import pandas as pd, numpy as np, itertools, warnings
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
warnings.filterwarnings('ignore')
v = pd.read_csv('/tmp/outputs/tables/tidy_values.csv')
v = v[v.unit != '% of day 0'].copy()

LOG_UNITS = ('endpoint titre', 'reciprocal titre', 'reciprocal titre (LLOQ 10)', 'fold vs untreated (linear)', 'ratio')
EXCLUDE = {'S11-B': 'copied from S11-A (replicates 1-2 identical)',
           'S05-A': 'n=2 vs stated 3; OVA vs bivalent conflict; NP366 (H-2Db) in BALB/c',
           'S05-B': 'n=2 vs stated 3; OVA vs bivalent conflict; NP366 (H-2Db) in BALB/c',
           'S07-C': 'both groups labelled Ly6C-CD206+',
           'S03-B': 'group labels rotated vs S13-A/B (use derived ratio)',
           'S03-F': 'group labels rotated vs S13-C/D (use derived ratio)',
           'S04-B_TfhTfr': '= (100-Foxp3)/Foxp3 of S04-B_Foxp3; not independent',
           'S09-A_right': 'labelled 16 h but reproduces S01-A 72 h values'}

# derived IgG2a/IgG1 ratios from S13 (per animal, same replicate index)
der = []
for a2, g1, name in [('S13-A', 'S13-B', 'DERIVED_IgG2a/IgG1_CA09'), ('S13-C', 'S13-D', 'DERIVED_IgG2a/IgG1_Aichi')]:
    A = v[v.block == a2].set_index(['group', 'replicate']).value
    B = v[v.block == g1].set_index(['group', 'replicate']).value
    r = (A / B).reset_index()
    for _, x in r.iterrows():
        der.append(dict(block=name, sheet='S13', group=x.group, age='young' if '(Y)' in x.group else 'aged', time='day 14',
                        replicate=x.replicate, value=x.value, cell=f'{a2}/{g1} rep {x.replicate}',
                        measurand=f'IgG2a/IgG1 ratio ({name.split("_")[-1]}) re-derived from {a2}/{g1}', unit='ratio'))
v = pd.concat([v, pd.DataFrame(der)], ignore_index=True)

def is_log(unit):
    return unit in LOG_UNITS
def prep(vals, unit, block):
    x = np.asarray(vals, float)
    if block in ('S03-C', 'S03-G'):
        x = np.where(x < 10, 5.0, x)
    if block.startswith('S09-A'):
        return x, True  # already log10
    if is_log(unit):
        return np.log10(x), True
    return x, False

def welch_ci(x, y):
    nx, ny = len(x), len(y)
    mx, my = x.mean(), y.mean(); vx, vy = x.var(ddof=1), y.var(ddof=1)
    se = np.sqrt(vx / nx + vy / ny)
    df = (vx / nx + vy / ny) ** 2 / ((vx / nx) ** 2 / (nx - 1) + (vy / ny) ** 2 / (ny - 1)) if se > 0 else np.inf
    tcrit = stats.t.ppf(0.975, df) if np.isfinite(df) else 1.96
    d = mx - my
    p = 2 * stats.t.sf(abs(d / se), df) if se > 0 else np.nan
    return d, d - tcrit * se, d + tcrit * se, p

summ, contr, tuk = [], [], []
CONTRASTS = [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-212', 'Sham'), ('PSLN-344', 'PSLN-212(Y)'),
             ('PSLN-212(Y)', 'PSLN-212'), ('PSLN-344(Y)', 'PSLN-212(Y)'), ('PSLN-344', 'CMP-204'), ('CMP-204', 'Sham'),
             ('PSLN-344', 'PBS'), ('PSLN-344', 'Vaccine'), ('PSLN-212', 'Vaccine'), ('PSLN-212Y', 'PSLN-212'),
             ('PSLN-344', 'PSLN-212Y'), ('CT', 'PBS'), ('CT', 'Sham'), ('PSLN-344', 'CT'), ('Sham', 'PBS'),
             ('SPA/D', 'WT'), ('PTX', 'PSLN-344'), ('PSLN-344', 'PTX'), ('PSLN-212+GM-CSF', 'PSLN-212'),
             ('PSLN-344(Y)+INCB3344', 'PSLN-344(Y)'), ('PSLN-344+INCB3344', 'PSLN-344'), ('CBX+', 'CBX-'),
             ('IFNAR-/- to WT', 'WT to WT'), ('IFN w/o cDC', 'WT w/o cDC'), ('GMCSF', 'IFN w/o cDC'),
             ('IFN w/ cDC', 'WT w/ cDC'), ('Lung+PTX', 'Lung'), ('MLN+PTX', 'MLN'), ('PSLN-344/R848', 'PSLN-344'),
             ('PSLN-212/R848', 'PSLN-212'), ('AECII-PSLN-344-SRB', 'AECII-PSLN-SRB'), ('AECI-PSLN-344-SRB', 'AECI-PSLN-SRB'),
             ('AECII/PSLN-SRB', 'AECII/FreeSRB'), ('AECI/PSLN-SRB', 'AECI/FreeSRB'), ('PSLN-344', 'PSLN-R848'),
             ('PSLN-344', 'PSLN-212/R848')]

for (b, t), d in v.groupby(['block', 'time'], dropna=False, sort=False):
    unit = d.unit.iloc[0]
    groups = list(dict.fromkeys(d.group))
    data = {}
    for g in groups:
        x, lg = prep(d[d.group == g].sort_values('replicate').value.values, unit, b)
        data[g] = x
        raw = d[d.group == g].value.values
        summ.append(dict(block=b, time=t, group=g, age=d[d.group == g].age.iloc[0], n=len(x), scale='log10' if lg else 'linear',
                         mean=raw.mean(), sd=raw.std(ddof=1) if len(raw) > 1 else np.nan, median=np.median(raw),
                         geo_mean=(10 ** x.mean()) if lg and not b.startswith('S09-A') else np.nan,
                         mean_log10=x.mean() if lg else np.nan,
                         min=raw.min(), max=raw.max(), cells=','.join(d[d.group == g].cell),
                         measurand=d.measurand.iloc[0], unit=unit, excluded=EXCLUDE.get(b, '')))
    for a, c in CONTRASTS:
        if a in data and c in data and len(data[a]) > 1 and len(data[c]) > 1:
            x, y = data[a], data[c]
            diff, lo, hi, p = welch_ci(x, y)
            try:
                pmw = stats.mannwhitneyu(x, y, alternative='two-sided', method='exact').pvalue
            except Exception:
                pmw = np.nan
            lg = (is_log(unit) or b.startswith('S09-A'))
            rec = dict(block=b, time=t, arm=a, comparator=c, n_arm=len(x), n_comp=len(y), scale='log10' if lg else 'linear',
                       welch_p=p, mannwhitney_exact_p=pmw, excluded=EXCLUDE.get(b, ''), measurand=d.measurand.iloc[0])
            if lg:
                rec.update(GMR=10 ** diff, GMR_lo=10 ** lo, GMR_hi=10 ** hi)
            else:
                rec.update(mean_diff=diff, diff_lo=lo, diff_hi=hi, ratio_of_means=(x.mean() / y.mean()) if y.mean() != 0 else np.nan)
            contr.append(rec)
    # Tukey HSD across all groups
    if len(groups) >= 3 and all(len(data[g]) > 1 for g in groups):
        allx = np.concatenate([data[g] for g in groups]); lab = np.concatenate([[g] * len(data[g]) for g in groups])
        try:
            th = pairwise_tukeyhsd(allx, lab)
            for row in th.summary().data[1:]:
                tuk.append(dict(block=b, time=t, group1=row[0], group2=row[1], meandiff=row[2], p_adj=row[3], reject=row[6],
                                scale='log10' if (is_log(unit) or b.startswith('S09-A')) else 'linear'))
        except Exception as e:
            pass

S = pd.DataFrame(summ); C = pd.DataFrame(contr); T = pd.DataFrame(tuk)
S.to_csv('/tmp/outputs/tables/immunology_group_summary.csv', index=False)
C.to_csv('/tmp/outputs/tables/immunology_contrasts.csv', index=False)
T.to_csv('/tmp/outputs/tables/immunology_tukey.csv', index=False)

# ---------------- restoration index ----------------
# R = [f(aged 344) - f(aged 212)] / [f(young 212) - f(aged 212)], f = mean of log10(values)
# (for S09-A values are already log10; for % data f = log10 of per-animal values as well, so R is on ratio scale)
RB = {  # block: (time selector, label)
 'S01-A_16h': (None, 'Ifnb1 lung 16 h'), 'S01-A_72h': (None, 'Ifnb1 lung 72 h'),
 'S01-D': (4, 'Lung monocytes d4 (peak)'), 'S01-E': (4, 'Lung CD11b+ DC d4 (peak)'),
 'S01-F': (None, 'Lung cDC1 72 h'), 'S01-G': (None, 'Lung cDC2 72 h (falls)'),
 'S02-A': (None, 'Lung CCR7+ migratory DC 72 h'), 'S02-B': (None, 'MLN CD11b+ DC 72 h'),
 'S02-C': (None, 'MLN antigen+ DC 36 h'), 'S02-D_CD40': (None, 'MLN DC CD40+ d3'), 'S02-D_CD86': (None, 'MLN DC CD86+ d3'),
 'S02-E': (None, 'OT-I priming by MLN DC'),
 'S03-K': (None, 'MLN GC B d7'), 'S04-A_ICOShi': (None, 'Tfh ICOS-hi d7'), 'S04-A_ICOSlo': (None, 'Tfh ICOS-lo d7'),
 'S04-B_Foxp3': (None, 'Tfr d7 (falls)'), 'S04-C': (None, 'Tfr d30'), 'S04-D': (None, 'Lung Treg d7 (falls)'),
 'S03-A': (None, 'IgG CA09 d14'), 'S03-E': (None, 'IgG Aichi d14'), 'S03-C': (None, 'HAI CA09 d14'), 'S03-G': (None, 'HAI Aichi d14'),
 'S03-D': (None, 'Neut CA09 d14'), 'S03-H': (None, 'Neut Aichi d14'),
 'S13-A': (None, 'IgG2a CA09 d14'), 'S13-B': (None, 'IgG1 CA09 d14'), 'S13-C': (None, 'IgG2a Aichi d14'), 'S13-D': (None, 'IgG1 Aichi d14'),
 'DERIVED_IgG2a/IgG1_CA09': (None, 'IgG2a/IgG1 CA09 (re-derived)'), 'DERIVED_IgG2a/IgG1_Aichi': (None, 'IgG2a/IgG1 Aichi (re-derived)'),
 'S13-H': (None, 'MLN IgG+ B220+'), 'S13-I': (None, 'IgG CA09 d28 boosted'), 'S13-J': (None, 'IgG Aichi d28 boosted'),
 'S05-D': (None, 'Lung Ki-67+ CD8 d3'), 'S05-E': (None, 'Lung GZMB+ CD8 d3'), 'S05-F': (None, 'MLN IFNg+ CD8 d14 (H5N1 restim)'),
 'S05-G': (None, 'MLN IFNg+ CD8 d60 (H5N1 restim)'), 'S05-H': (None, 'MLN GZMB+ CD8 d60'), 'S05-I': (None, 'Lung TRM CD8 d25'),
 'S14-A_H1N1': (None, 'MLN IFNg+ CD8 (CA09 restim)'), 'S14-A_H3N2': (None, 'MLN IFNg+ CD8 (Aichi restim)'),
 'S11-A': (4, 'Lung alveolar macrophages d4'), 'S11-D': (4, 'Lung NK d4'), 'S11-E': (None, 'Lung CD206+ macrophages (falls)'),
 'S09-A_left': ('*', 'cytokine panel 16 h'),
}
rng = np.random.default_rng(20260915)
rest = []
def logv(b, g, t):
    d = v[(v.block == b) & (v.group == g)]
    if t is not None and t != '*':
        d = d[d.time.astype(str) == str(t)]
    x = d.sort_values('replicate').value.values.astype(float)
    if b in ('S03-C', 'S03-G'):
        x = np.where(x < 10, 5.0, x)
    if b.startswith('S09-A'):
        return x
    return np.log10(x)
for b, (t, lab) in RB.items():
    times = [t]
    if t == '*':
        times = list(v[v.block == b].time.unique())
    for tt in times:
        yg = 'PSLN-212(y)' if b.startswith('S09') else 'PSLN-212(Y)'
        try:
            a344 = logv(b, 'PSLN-344', tt); a212 = logv(b, 'PSLN-212', tt); y212 = logv(b, yg, tt)
            sh = logv(b, 'Sham', tt) if 'Sham' in set(v[v.block == b].group) else logv(b, 'PBS', tt) if 'PBS' in set(v[v.block == b].group) else logv(b, 'Vaccine', tt) if 'Vaccine' in set(v[v.block == b].group) else np.array([])
        except Exception:
            continue
        if len(a344) == 0 or len(a212) == 0 or len(y212) == 0:
            continue
        R = (a344.mean() - a212.mean()) / (y212.mean() - a212.mean())
        boots = []
        for _ in range(4000):
            A = rng.choice(a344, len(a344)); B = rng.choice(a212, len(a212)); Y = rng.choice(y212, len(y212))
            den = Y.mean() - B.mean()
            if abs(den) > 1e-9:
                boots.append((A.mean() - B.mean()) / den)
        lo, hi = np.percentile(boots, [2.5, 97.5])
        label = lab if t != '*' else f'{tt} lung 16 h (S09-A)'
        gap_log = y212.mean() - a212.mean()
        rest.append(dict(block=b, readout=label, time=tt, R=R, R_lo=lo, R_hi=hi,
                         fold_344_vs_212=10 ** (a344.mean() - a212.mean()), fold_young_vs_aged212=10 ** gap_log,
                         fold_344_vs_young=10 ** (a344.mean() - y212.mean()),
                         direction='up' if gap_log > 0 else 'down',
                         n=(len(a344), len(a212), len(y212)), excluded=EXCLUDE.get(b, '')))
Rdf = pd.DataFrame(rest)
Rdf.to_csv('/tmp/outputs/tables/restoration_index.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300)
print(Rdf[['readout', 'R', 'R_lo', 'R_hi', 'fold_344_vs_212', 'fold_young_vs_aged212', 'fold_344_vs_young', 'direction']].round(2).to_string(index=False))

# ---------------- sensitivity: the annotation's stated method on the raw scale ----------------
# one-way ANOVA + Tukey HSD on untransformed values vs Tukey on the analysis scale (log10 for titres/fold)
rows = []
for b in ['S01-A_16h', 'S03-A', 'S03-C', 'S03-D', 'S03-E', 'S03-G', 'S03-H', 'S13-I', 'S13-J', 'S03-K', 'S04-A_ICOShi',
          'S05-D', 'S05-E', 'S05-F', 'S05-G', 'S05-I', 'S02-A', 'S02-C', 'S02-E', 'S02-D_CD40', 'S02-D_CD86']:
    d = v[v.block == b].copy()
    if b in ('S03-C', 'S03-G'):
        d.loc[d.value < 10, 'value'] = 5
    th = pairwise_tukeyhsd(d.value.values, d.group.values)
    res = pd.DataFrame(th.summary().data[1:], columns=th.summary().data[0])
    for a, c in [('PSLN-212', 'PSLN-344'), ('PSLN-344', 'PSLN-212(Y)'), ('PSLN-212', 'Sham'), ('PSLN-344', 'Sham')]:
        r = res[((res.group1 == a) & (res.group2 == c)) | ((res.group1 == c) & (res.group2 == a))]
        t = T[(T.block == b) & (((T.group1 == a) & (T.group2 == c)) | ((T.group1 == c) & (T.group2 == a)))]
        if len(r) and len(t):
            rows.append(dict(block=b, contrast=f'{a} vs {c}', raw_tukey_p_adj=float(r['p-adj'].iloc[0]), raw_reject=bool(r['reject'].iloc[0]),
                             analysis_scale=t.scale.iloc[0], analysis_scale_tukey_p_adj=float(t.p_adj.iloc[0]),
                             analysis_scale_reject=bool(t.reject.iloc[0]),
                             raw_meandiff_sign=np.sign(float(r['meandiff'].iloc[0])), analysis_meandiff_sign=np.sign(float(t.meandiff.iloc[0]))))
TR = pd.DataFrame(rows); TR['agree'] = TR.raw_reject == TR.analysis_scale_reject
TR.to_csv('/tmp/outputs/tables/tukey_raw_vs_analysis_scale.csv', index=False)
print('raw vs analysis-scale Tukey agreement:', int(TR.agree.sum()), '/', len(TR), '; direction flips:', int((TR.raw_meandiff_sign != TR.analysis_meandiff_sign).sum()))

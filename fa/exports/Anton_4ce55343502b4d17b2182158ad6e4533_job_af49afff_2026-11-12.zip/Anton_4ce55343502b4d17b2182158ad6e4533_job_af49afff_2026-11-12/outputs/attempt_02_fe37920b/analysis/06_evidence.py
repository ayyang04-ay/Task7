"""06_evidence.py -- build the evidence register (every number cited in the memo) from computed tables,
and assemble the Excel evidence workbook."""
import pandas as pd, numpy as np, re
from scipy import stats
T = '/tmp/outputs/tables/'
v = pd.read_csv(T + 'tidy_values.csv'); s = pd.read_csv(T + 'tidy_survival.csv')
S = pd.read_csv(T + 'immunology_group_summary.csv'); C = pd.read_csv(T + 'immunology_contrasts.csv')
P = pd.read_csv(T + 'survival_pooled.csv'); PG = pd.read_csv(T + 'survival_per_group.csv'); PW = pd.read_csv(T + 'survival_pairwise_by_block.csv')
R = pd.read_csv(T + 'restoration_index.csv'); cat = pd.read_csv(T + 'block_catalog.csv')
_c = cat.set_index('block')
rng = lambda b: (f"{_c.sheet[b]}!{_c.range[b]}" if b in _c.index else '')
def gm(b, g, t=None):
    r = S[(S.block == b) & (S.group == g)]
    if t is not None: r = r[r.time.astype(str) == str(t)]
    r = r.iloc[0]; return r.geo_mean if not np.isnan(r.geo_mean) else r['mean']
def mn(b, g, t=None):
    r = S[(S.block == b) & (S.group == g)]
    if t is not None: r = r[r.time.astype(str) == str(t)]
    return r.iloc[0]['mean']
def con(b, a, c, t=None):
    r = C[(C.block == b) & (C.arm == a) & (C.comparator == c)]
    if t is not None: r = r[r.time.astype(str) == str(t)]
    r = r.iloc[0]
    if r.scale == 'log10': return f"GMR {r.GMR:.2f} (95% CI {r.GMR_lo:.2f}-{r.GMR_hi:.2f}); Welch p={r.welch_p:.2g}; Mann-Whitney exact p={r.mannwhitney_exact_p:.3f}"
    return f"difference {r.mean_diff:+.2f} (95% CI {r.diff_lo:.2f} to {r.diff_hi:.2f}); ratio {r.ratio_of_means:.2f}; Welch p={r.welch_p:.2g}; Mann-Whitney exact p={r.mannwhitney_exact_p:.3f}"
def pool(setprefix, comp):
    r = P[P.analysis_set.str.startswith(setprefix) & (P.comparator == comp)].iloc[0]; return r
def sv(b, g):
    r = PG[(PG.block == b) & (PG.group == g)].iloc[0]; return f"{r.survivors}/{r.n}"
def pw(b, a, c):
    r = PW[(PW.block == b) & (PW.arm == a) & (PW.comparator == c)].iloc[0]; return r
E = []
def add(i, section, statement, value, blocks, cells, reduction, stat, qc=''):
    E.append(dict(id=i, memo_section=section, statement=statement, value=value, source_blocks=blocks, cells=cells,
                  reduction=reduction, statistic=stat, integrity_flags=qc))
SURVRED = 'Per animal: status at end of observation (0 = censored survivor); survivors/N per group; exact (Clopper-Pearson) 95% CI'
POOLRED = SURVRED + '; stratified by experiment: Mantel-Haenszel risk difference (Sato variance), MH risk ratio of death, exact conditional (hypergeometric-convolution) test, stratified log-rank, Breslow-Day homogeneity'
prim = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G']
pc = '; '.join(f'{b} {rng(b)}' for b in prim)
r = pool('PRIMARY', 'PSLN-212')
add('E01', 'Efficacy', 'Aged BALB/c: PSLN-344 vs PSLN-212 survival, pooled over 8 experiments (S06-D excluded as exact copy of S06-C)',
    f"{r.arm_survival} vs {r.comp_survival}; MH risk difference {r.MH_risk_difference_pct} percentage points; MH risk ratio of death {r.MH_RR_death:.2f}",
    ', '.join(prim), pc, POOLRED, f"exact stratified p={r.exact_stratified_p_two_sided:.1e}; stratified log-rank p={r.stratified_logrank_p:.1e}; Breslow-Day p={r.breslow_day_homogeneity_p}", 'QC-01, QC-03, QC-04, QC-10, QC-11, QC-12')
r = pool('PRIMARY', 'Sham')
add('E02', 'Efficacy', 'Aged: PSLN-344 vs Sham (vaccine + empty liposome), pooled', f"{r.arm_survival} vs {r.comp_survival}; MH RD {r.MH_risk_difference_pct}",
    ', '.join(prim), pc, POOLRED, f"exact stratified p={r.exact_stratified_p_two_sided:.1e}", 'as E01')
r = P[P.analysis_set.str.startswith('PRIMARY') & (P.arm == 'PSLN-212') & (P.comparator == 'Sham')].iloc[0]
add('E03', 'Efficacy', 'Aged: PSLN-212 (no Mn) vs Sham, pooled -- PSLN-212 delays death but rarely prevents it',
    f"{r.arm_survival} vs {r.comp_survival}; MH RD {r.MH_risk_difference_pct}", ', '.join(prim), pc, POOLRED,
    f"exact stratified p={r.exact_stratified_p_two_sided:.3f} (survival); stratified log-rank p={r.stratified_logrank_p:.1e} (time to death)", 'as E01')
dd = s[s.block.isin(prim) & (s.event == 1)]
md = {g: (dd[dd.group == g].time.median(), dd[dd.group == g].time.quantile(.25), dd[dd.group == g].time.quantile(.75), len(dd[dd.group == g])) for g in ['Sham', 'PSLN-212', 'PSLN-344']}
add('E04', 'Efficacy', 'Day of death among animals that died (primary set)', '; '.join(f"{g}: median d{m[0]:.1f} (IQR {m[1]:.1f}-{m[2]:.1f}), {m[3]} deaths" for g, m in md.items()),
    ', '.join(prim), pc, 'Median and IQR of recorded day of death, animals with status 1', 'descriptive', 'as E01')
for k, pre in [('E05', 'S1:'), ('E06', 'S2:'), ('E07', 'S3:'), ('E08', 'S4:')]:
    r = P[P.analysis_set.str.startswith(pre) & (P.comparator.isin(['PSLN-212', 'Naïve+PSLN-212']))].iloc[0]
    _bl = [x.split(':')[0].strip() for x in r.per_block.split(';')]
    add(k, 'Efficacy - sensitivity', r.analysis_set + ' | per block: ' + r.per_block, f"{r.arm_survival} vs {r.comp_survival}; MH RD {r.MH_risk_difference_pct}", ', '.join(_bl), '; '.join(f'{b} {rng(b)}' for b in _bl), POOLRED,
        f"exact stratified p={r.exact_stratified_p_two_sided:.1e}; Breslow-Day p={r.breslow_day_homogeneity_p}", 'QC-03 (S15-M/O body weights recycled), QC-21 (S15-L/N challenge not stated)' if k == 'E05' else '')
# per-block smallest/largest
rows = []
for b in prim:
    q = pw(b, 'PSLN-344', 'PSLN-212'); rows.append(f"{b}: {q.surv_arm} vs {q.surv_comp} (log-rank p={q.logrank_p:.2g}; Fisher p={q.fisher_p:.2g})")
add('E09', 'Efficacy', 'Per-experiment PSLN-344 vs PSLN-212 (aged): direction favours PSLN-344 in 8/8', '; '.join(rows), ', '.join(prim), pc, SURVRED + '; log-rank (statsmodels survdiff); two-sided Fisher exact', 'per block', 'as E01')
# gradient
def tally(bl, g):
    d = s[s.block.isin(bl) & (s.group == g)]; return int((d.event == 0).sum()), len(d)
h, n1, f = tally(['S03-I', 'S03-J'], 'PSLN-344'), tally(['S06-C', 'S06-F'], 'PSLN-344'), tally(['S06-A', 'S06-B', 'S06-E', 'S06-G'], 'PSLN-344')
add('E10', 'Mechanism - what drives protection', 'Aged PSLN-344 survival by antigenic relationship of challenge virus to vaccine (homologous / N1 shared / no HA-NA subtype shared)',
    f"{h[0]}/{h[1]} (100%) / {n1[0]}/{n1[1]} (86%) / {f[0]}/{f[1]} (71%); PSLN-212 3/17, 3/14, 1/28", 'S03-I, S03-J | S06-C, S06-F | S06-A, S06-B, S06-E, S06-G',
    '; '.join(f'{b} {rng(b)}' for b in ['S03-I', 'S03-J', 'S06-C', 'S06-F', 'S06-A', 'S06-B', 'S06-E', 'S06-G']),
    SURVRED + '; classification by vaccine/challenge subtype as annotated', 'Cochran-Armitage trend z=-2.50, p=0.013; homologous vs fully heterosubtypic Fisher p=0.017; restricted to d3/d14 challenges 17/17 vs 11/14, Fisher p=0.081 (antigenic distance and challenge timing partly confounded)', 'as E01')
add('E11', 'Efficacy - durability', 'Aged PSLN-344 survival: challenge at d14 vs d60, and vs young PSLN-212',
    'd14 20/21 (95%) vs d60 14/21 (67%), Fisher p=0.045 (virus-matched PR8+H5N1 only: 13/14 vs 10/14, p=0.33); at d60 aged PSLN-344 14/21 vs young PSLN-212 21/21, p=0.009; at d14 20/21 vs 21/21, p=1.0; all blocks with a young arm 39/49 vs 49/49, p=0.0012',
    'S03-I, S06-A, S06-C (d14); S06-E, S06-F, S06-G (d60)', '; '.join(f'{b} {rng(b)}' for b in ['S03-I', 'S06-A', 'S06-C', 'S06-E', 'S06-F', 'S06-G']), SURVRED, 'two-sided Fisher exact on pooled counts', 'as E01')
q1 = pw('S15-H', '3d Vaccine+PSLN-344', '3d Vaccine'); q2 = pw('S15-H', '3d Vaccine+PSLN-344', '3d PSLN-344')
add('E12', 'Mechanism - what drives protection', 'Antigen requirement: aged mice given vaccine alone, PSLN-344 alone, or both 3 d before rgH5N1',
    f"vaccine+PSLN-344 {q1.surv_arm} vs vaccine alone {q1.surv_comp} vs PSLN-344 alone {q2.surv_comp}", 'S15-H', rng('S15-H'), SURVRED,
    f"log-rank p={q1.logrank_p:.1g} and {q2.logrank_p:.1g}; Fisher p={q1.fisher_p:.3f}", 'QC-03 (S15-I weights for the combination group recycled from S15-C)')
add('E13', 'Efficacy - age specificity', 'Young mice: PSLN-344 adds nothing over PSLN-212 (ceiling)',
    f"S09-B {sv('S09-B','PSLN-344Y')} vs {sv('S09-B','PSLN-212Y')}; S09-D {sv('S09-D','PSLN-344Y')} vs {sv('S09-D','PSLN-212Y')}; S09-F (d180) {sv('S09-F','PSLN-344Y')} vs {sv('S09-F','PSLN-212Y')}; S13-E PSLN-344(Y) {sv('S13-E','PSLN-344(Y)')} = CMP-204(Y) {sv('S13-E','CMP-204(Y)')}",
    'S09-B, S09-D, S09-F, S13-E', '; '.join(f'{b} {rng(b)}' for b in ['S09-B', 'S09-D', 'S09-F', 'S13-E']), SURVRED, 'descriptive', 'QC-11 (Sham n mismatches)')
add('E14', 'Efficacy', 'Pre-existing immunity (infection at 10 mo; vaccinated at 14 mo)',
    f"PR8 challenge: Naive+PSLN-212 {sv(chr(83)+'06-E'+chr(39),'Naïve+PSLN-212')}, Imprinting+PSLN-212 {sv(chr(83)+'06-E'+chr(39),'Imprinting+PSLN-212')}, Naive+PSLN-344 {sv(chr(83)+'06-E'+chr(39),'Naïve+PSLN-344')}, Imprinting+PSLN-344 {sv(chr(83)+'06-E'+chr(39),'Imprinting+PSLN-344')}; Perth: {sv(chr(83)+'06-F'+chr(39),'Naïve+PSLN-212')}, {sv(chr(83)+'06-F'+chr(39),'Imprinting+PSLN-212')}, {sv(chr(83)+'06-F'+chr(39),'Naïve+PSLN-344')}, {sv(chr(83)+'06-F'+chr(39),'Imprinting+PSLN-344')}",
    "S06-E', S06-F' (rows 71-105)", f"S06!G70:K98; S06!M70:Q98", SURVRED, 'descriptive; PR8 imprinting is homologous to the PR8 challenge', 'QC-15, QC-21 (challenge day not stated for PR8)')
u = s[s.group == 'Untreated']
add('E15', 'Integrity', 'Unchallenged, unvaccinated aged controls that died within 14 d', f"{int(u.event.sum())}/{len(u)} (S06-E 1/7; S06-F 0/7; S06-G 3/7)", 'S06-E, S06-F, S06-G',
    'S06!L62:L68, R62:R68, F99:F105', 'count of status 1', 'descriptive', 'QC-10')
# immunogenicity
def gmline(b, groups=('PSLN-344', 'PSLN-212', 'PSLN-212(Y)', 'Sham')):
    out = []
    for g in groups:
        try: out.append(f"{g} {gm(b, g):,.0f}")
        except Exception: pass
    return '; '.join(out)
ABRED = 'Per-animal titres, log10; geometric mean (GM); GM ratio with Welch 95% CI on log10; HAI <1:10 set to 5'
for i, (b, lab) in enumerate([('S03-A', 'Serum IgG anti-CA09, d14'), ('S03-E', 'Serum IgG anti-Aichi, d14'), ('S03-C', 'HAI anti-CA09, d14'),
                              ('S03-G', 'HAI anti-Aichi, d14'), ('S03-D', 'Neutralising anti-CA09, d14'), ('S03-H', 'Neutralising anti-Aichi, d14')]):
    add(f'E2{i}', 'Immunogenicity', lab + ' (aged unless Y)', 'GM: ' + gmline(b), b, rng(b), ABRED,
        f"344 vs 212: {con(b,'PSLN-344','PSLN-212')} | 344 vs young 212: {con(b,'PSLN-344','PSLN-212(Y)')}", 'QC-13' if b in ('S03-C', 'S03-G') else '')
hai = {g: (v[(v.block == 'S03-C') & (v.group == g)].value >= 40).sum() for g in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
hai2 = {g: (v[(v.block == 'S03-G') & (v.group == g)].value >= 40).sum() for g in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
add('E26', 'Biomarker', 'Animals with HAI >= 1:40 at d14 (CA09 / Aichi), and homologous CA09 survival in the same regimen (S03-I)',
    '; '.join(f"{g}: {hai[g]}/5 / {hai2[g]}/5" for g in hai) + f" | S03-I survival: Sham {sv('S03-I','Sham')}, CMP-204 {sv('S03-I','CMP-204')}, PSLN-212 {sv('S03-I','PSLN-212')}, PSLN-344 {sv('S03-I','PSLN-344')}, PSLN-212(Y) {sv('S03-I','PSLN-212(Y)')}",
    'S03-C, S03-G, S03-I', f"{rng('S03-C')}; {rng('S03-G')}; {rng('S03-I')}", 'count of per-animal HAI >= 40; group-level comparison only (different animals)', 'descriptive', '')
add('E27', 'Immunogenicity', 'IgG2a/IgG1 ratio (Th1 skew), re-derived per animal from subclass titres',
    f"CA09: PSLN-344 {gm('DERIVED_IgG2a/IgG1_CA09','PSLN-344'):.2f}, PSLN-212 {gm('DERIVED_IgG2a/IgG1_CA09','PSLN-212'):.2f}, young {gm('DERIVED_IgG2a/IgG1_CA09','PSLN-212(Y)'):.2f}; Aichi: {gm('DERIVED_IgG2a/IgG1_Aichi','PSLN-344'):.2f}, {gm('DERIVED_IgG2a/IgG1_Aichi','PSLN-212'):.2f}, {gm('DERIVED_IgG2a/IgG1_Aichi','PSLN-212(Y)'):.2f} (geometric means)",
    'S13-A/S13-B, S13-C/S13-D (not S03-B/S03-F as printed)', f"{rng('S13-A')}, {rng('S13-B')}, {rng('S13-C')}, {rng('S13-D')}",
    'Per-animal quotient IgG2a/IgG1 (same replicate index), log10, GM', f"CA09 344 vs 212: {con('DERIVED_IgG2a/IgG1_CA09','PSLN-344','PSLN-212')}", 'QC-06')
add('E28', 'Immunogenicity', 'Serum IgG after boost (d28; boost d14)', f"CA09 GM: {gmline('S13-I')}; Aichi GM: {gmline('S13-J')}", 'S13-I, S13-J', f"{rng('S13-I')}; {rng('S13-J')}", ABRED,
    f"CA09 344 vs young: {con('S13-I','PSLN-344','PSLN-212(Y)')}; Aichi 344 vs young: {con('S13-J','PSLN-344','PSLN-212(Y)')}", '')
PCT = 'Per-animal % (flow); arithmetic mean; Welch difference with 95% CI; exact Mann-Whitney'
for k, b, lab in [('E30', 'S03-K', 'MLN germinal-centre B cells, d7'), ('E31', 'S04-A_ICOShi', 'ICOS-high Tfh, d7'), ('E32', 'S04-B_Foxp3', 'Tfr (Foxp3+ of CXCR5+ICOShi), d7'),
                  ('E33', 'S04-D', 'Lung Treg, d7 (n=3)'), ('E34', 'S05-D', 'Lung Ki-67+ CD8, d3'), ('E35', 'S05-E', 'Lung GZMB+ CD8, d3'),
                  ('E36', 'S05-F', 'MLN IFN-g+ CD8 after rgH5N1 restimulation, d14'), ('E37', 'S05-G', 'MLN IFN-g+ CD8 after rgH5N1 restimulation, d60'),
                  ('E38', 'S05-I', 'Lung CD69+CD103+ CD8 (total TRM), d25'), ('E39', 'S14-A_H1N1', 'MLN IFN-g+ CD8 after CA09 restimulation (timepoint not stated)'),
                  ('E40', 'S02-A', 'Lung CCR7+ migratory CD11b+ DC, 72 h'), ('E41', 'S02-C', 'MLN DC carrying AF647-OVA, 36 h'), ('E42', 'S02-D_CD40', 'CD40+ MLN CD11b+ DC, d3'),
                  ('E43', 'S02-D_CD86', 'CD86+ MLN CD11b+ DC, d3'), ('E44', 'S02-E', 'OT-I proliferation with MLN CD11b+ DC (donor strain not stated)'), ('E45', 'S01-F', 'Lung cDC1, 72 h'),
                  ('E47', 'S11-E', 'Lung CD206+ macrophages (timepoint not stated)')]:
    add(k, 'Immunology', lab, 'means: ' + '; '.join(f"{g} {mn(b,g):.2f}" for g in ['PSLN-344', 'PSLN-212', 'PSLN-212(Y)', 'Sham'] if len(S[(S.block == b) & (S.group == g)])),
        b, rng(b), PCT, f"344 vs 212: {con(b,'PSLN-344','PSLN-212')}", {'S02-E': 'QC-18', 'S05-I': 'QC-17', 'S04-D': 'n=3'}.get(b, ''))
add('E46', 'Immunology', 'Lung CD11b+Ly6C+ monocytes, d4 (peak)', 'means: ' + '; '.join(f"{g} {mn('S01-D',g,4):.1f}" for g in ['PSLN-344', 'PSLN-212', 'PSLN-212(Y)', 'Sham']),
    'S01-D', rng('S01-D'), PCT, f"344 vs 212 at d4: {con('S01-D','PSLN-344','PSLN-212',4)}", '')
# innate
add('E50', 'Biomarker / innate', 'Lung Ifnb1 at 16 h (no vaccine)', 'GM fold: ' + '; '.join(f"{g} {gm('S01-A_16h',g):.1f}" for g in ['Sham', 'CMP-204', 'PSLN-R848', 'PSLN-212', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']),
    'S01-A (16 h)', rng('S01-A_16h'), 'Per-animal fold vs untreated, log10; geometric mean; GMR Welch 95% CI', f"344 vs 212: {con('S01-A_16h','PSLN-344','PSLN-212')} | 344 vs young 212: {con('S01-A_16h','PSLN-344','PSLN-212(Y)')}", '')
add('E51', 'Biomarker / innate', 'Lung Ifnb1 at 72 h', 'GM fold: ' + '; '.join(f"{g} {gm('S01-A_72h',g):.2f}" for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']),
    'S01-A (72 h)', rng('S01-A_72h'), 'as E50', f"344 vs young 212: {con('S01-A_72h','PSLN-344','PSLN-212(Y)')}", '')
dd = v[v.block == 'S08-A'].copy(); dd['dose'] = dd.time.astype(float)
g8 = dd.groupby(['group', 'dose']).value.apply(lambda x: np.exp(np.log(x).mean())).unstack(0)
add('E52', 'Biomarker / innate', 'Ifnb1 dose-response (1-40 ug; age not stated; n=3)', 'GM fold PSLN-344 1/5/10/20/40 ug: ' + ', '.join(f"{x:.1f}" for x in g8['PSLN-344']) + '; PSLN-212: ' + ', '.join(f"{x:.1f}" for x in g8['PSLN-212']) + '; PSLN-344 dose matching PSLN-212 at 20 ug = 6.8 ug (~2.9x dose-sparing); 20 -> 40 ug adds 9%',
    'S08-A', rng('S08-A'), 'Per-animal fold, geometric mean per dose; log-log linear interpolation between doses', 'descriptive', 'QC-20 (PSLN-344/R848 undefined), QC-21 (age not stated)')
add('E53', 'Mechanism', 'Lung Gm-csf mRNA (bivalent vaccine + adjuvant)', '; '.join(f"{t}: PSLN-344 {gm('S02-F','PSLN-344',t):.2f}, PSLN-212 {gm('S02-F','PSLN-212',t):.2f}, Sham {gm('S02-F','Sham',t):.2f}" for t in ['16h', '36h', '72h']),
    'S02-F', rng('S02-F'), 'as E50', f"36 h 344 vs 212: {con('S02-F','PSLN-344','PSLN-212','36h')}", 'age not stated (aged by default)')
add('E54', 'Biomarker / innate', 'Lung cytokine mRNA at 16 h (log10 fold; n=3)', 'PSLN-344 vs PSLN-212 fold: Il6 6.5x, Ccl2 77x, Ccl3 27x, Ccl5 7.6x, Tnf 2.6x, Il10 2.0x; PSLN-344 vs young PSLN-212: Tnf 2.9x, Il10 4.0x',
    'S09-A left panel', rng('S09-A_left'), 'Mean of per-animal log10 values; fold = 10^(difference of means)', 'see restoration_index.csv', 'QC-08 (right panel mislabelled; left panel = same animals as S01-A)')
# interventions
for k, b, a, c, lab, qc in [('E60', 'S01-C', 'SPA/D', 'WT', 'Alveolar-macrophage uptake of PSLN-344-composition liposomes: SP-A/SP-D-deficient vs WT', 'QC-21 (WT age not stated)'),
                            ('E61', 'S02-G', 'PSLN-212+GM-CSF', 'PSLN-212', 'Recombinant GM-CSF added to PSLN-212: lung Ly6C+CD11c+MHCII+ cells, d5', 'QC-21 (age not stated)'),
                            ('E62', 'S02-H', 'IFN w/o cDC', 'WT w/o cDC', 'Ifnar-/- vs WT bone marrow (cDC precursors removed): donor moDC after PSLN-344 vaccine, d3', 'QC-21 (age not stated)'),
                            ('E63', 'S02-H', 'GMCSF', 'IFN w/o cDC', 'GM-CSF (i.t.) rescues moDC from Ifnar-/- marrow', 'QC-21'),
                            ('E64', 'S02-I', 'PSLN-344(Y)+INCB3344', 'PSLN-344(Y)', 'CCR2 antagonist: lung GZMB+ CD8 d5 (YOUNG mice only)', 'young only'),
                            ('E65', 'S07-B_mono', 'PSLN-344+INCB3344', 'PSLN-344', 'CCR2 antagonist: lung CD11b+Ly6C+ monocytes', 'QC-21 (timepoint not stated)'),
                            ('E66', 'S11-C', 'CBX+', 'CBX-', 'Gap-junction blocker carbenoxolone: recruited lung monocytes d3', ''),
                            ('E67', 'S12-A', 'IFNAR-/- to WT', 'WT to WT', 'Ifnar-/- vs WT marrow: infiltrating monocytes d3 (young; n=3)', 'underpowered'),
                            ('E68', 'S02-E', 'PTX', 'PSLN-344', 'Pertussis toxin (migration block): OT-I priming by MLN DC', 'QC-18; PTX-group formulation not stated'),
                            ('E69', 'S05-C', 'MLN+PTX', 'MLN', 'Pertussis toxin: in-vivo OT-I proliferation in MLN (lung unaffected: 55.1 vs 59.0)', 'n=3; age not stated'),
                            ('E70', 'S08-B', 'PSLN-344', 'PSLN-212', 'Encapsulation efficiency of CDN-1807 (n=3 preparations)', 'QC-20')]:
    add(k, 'Mechanism / CMC', lab, f"{a} {mn(b,a):.2f} vs {c} {mn(b,c):.2f}", b, rng(b), PCT.replace('(flow)', ''), con(b, a, c), qc)
# safety
add('E71', 'Safety', 'CNS transcripts 36 h after intranasal vaccine (aged)', f"Ifnb1 GM: PBS {gm('S10-A_Ifnb1','PBS'):.2f}, Sham {gm('S10-A_Ifnb1','Sham'):.2f}, PSLN-344 {gm('S10-A_Ifnb1','PSLN-344'):.2f}, cholera toxin {gm('S10-A_Ifnb1','CT'):.2f}; Tnf: {gm('S10-A_Tnf','PBS'):.2f}, {gm('S10-A_Tnf','Sham'):.2f}, {gm('S10-A_Tnf','PSLN-344'):.2f}, {gm('S10-A_Tnf','CT'):.2f}; Isg15: {gm('S10-A_Isg15','PBS'):.2f}, {gm('S10-A_Isg15','Sham'):.2f}, {gm('S10-A_Isg15','PSLN-344'):.2f}, {gm('S10-A_Isg15','CT'):.2f}",
    'S10-A', 'S10!A2:N7', 'as E50', f"Tnf PSLN-344 vs PBS: {con('S10-A_Tnf','PSLN-344','PBS')}; vs Sham: {con('S10-A_Tnf','PSLN-344','Sham')}; CT vs PBS Ifnb1: {con('S10-A_Ifnb1','CT','PBS')}", 'QC-19')
add('E72', 'Safety', 'Post-vaccination body-weight nadir (reactogenicity; d2-d10)', 'per-animal minimum, mean: Vaccine 98.2, PSLN-212 97.0, PSLN-344 96.4, CMP-204 95.9, PSLN-212/R848 90.0 (one animal missing at d10)',
    'S08-D', rng('S08-D'), 'Per-animal minimum % of d0 over d2-d10; group mean; Welch vs Vaccine', 'PSLN-344 vs vaccine -1.8 points, p=0.065; PSLN-212/R848 -8.2, p=0.020', 'QC-03 (S08-D CMP-204 trajectories recur in S15-F)')
# restoration
def rr(lbl):
    x = R[R.readout == lbl].iloc[0]; return f"{x.R:.2f} ({x.R_lo:.2f}-{x.R_hi:.2f})"
add('E80', 'Mechanism - restoration profile', 'Restoration index R (0 = no rescue of aged PSLN-212, 1 = young PSLN-212 level)',
    '; '.join(f"{l}: {rr(l)}" for l in ['Ifnb1 lung 16 h', 'OT-I priming by MLN DC', 'Lung CCR7+ migratory DC 72 h', 'HAI CA09 d14', 'IgG CA09 d14', 'MLN GC B d7', 'Tfh ICOS-hi d7', 'Lung TRM CD8 d25', 'MLN IFNg+ CD8 d14 (H5N1 restim)', 'Lung GZMB+ CD8 d3', 'IgG CA09 d28 boosted', 'MLN DC CD40+ d3', 'MLN DC CD86+ d3']),
    'see restoration_index.csv', 'blocks as listed', 'R = [mean log10(aged 344) - mean log10(aged 212)] / [mean log10(young 212) - mean log10(aged 212)]; 4,000 bootstrap resamples of animals within groups', 'survival analogue (linear): d14 0.94, fully heterosubtypic 0.70, d60 0.65', '')
add('E81', 'Forward plan', 'Sample-size anchors for next studies', 'n=12/group gives 89% power for 80% vs 15% survival; 45/group for 80% vs 50%; 12/group for a 1.0 log10 lung-titre difference (SD 0.8); 25/group for 70% vs 100% (d60 age gap)',
    'design assumption', '-', 'Simulation (4,000 trials) of two-sided Fisher exact at alpha 0.05; two-sample t power', 'planning', '')
EV = pd.DataFrame(E); EV.to_csv(T + 'evidence_register.csv', index=False)
print(EV[['id', 'statement', 'value']].to_string(max_colwidth=110))

# ---------------- Excel evidence workbook ----------------
import xlsxwriter
out = '/tmp/outputs/PSLN-344_evidence_workbook.xlsx'
sheets = [('README', None), ('Evidence_register', EV), ('QC_log', pd.read_csv(T + 'QC_log.csv')),
          ('Survival_pooled', P), ('Survival_per_group', PG), ('Survival_pairwise', PW),
          ('Immunology_summary', S), ('Immunology_contrasts', C), ('Tukey_HSD', pd.read_csv(T + 'immunology_tukey.csv')),
          ('Restoration_index', R), ('Tukey_raw_vs_log', pd.read_csv(T + 'tukey_raw_vs_analysis_scale.csv')), ('BW_trajectory_reuse', pd.read_csv(T + 'QC_bodyweight_trajectory_reuse_significant.csv')),
          ('BW_vs_survival', pd.read_csv(T + 'QC_bodyweight_vs_survival.csv')), ('Block_catalog', cat),
          ('Tidy_values', v), ('Tidy_survival', s)]
readme = [
 ['PSLN-344 evidence workbook (companion to PSLN-344_portfolio_memo)'],
 ['Source data: adjuvant_program_dataset.xlsx (15 sheets) and adjuvant_program_annotation.pdf (19 pp.)'],
 ['Every number cited in the memo carries an evidence ID (E##) -> sheet Evidence_register gives statement, value, source block(s), cell range(s), reduction and statistic.'],
 ['Integrity findings carry QC IDs (QC-##) -> sheet QC_log.'],
 ['Tidy_values / Tidy_survival hold every extracted per-animal value with its source cell, so any summary can be recomputed.'],
 ['Block naming: workbook labels are used; the second use of "S06-E"/"S06-F" (rows 71-105, imprinting) is written S06-E\' / S06-F\'.'],
 ['Conventions: titres, qPCR fold-changes and ratios are summarised as geometric means and compared on log10 (GM ratio, Welch 95% CI); HAI recorded as 0 (<1:10) set to 5; flow percentages as arithmetic means (Welch difference); every contrast also has an exact Mann-Whitney p; survival = status at end of observation, exact 95% CI; pooled survival = Mantel-Haenszel stratified by experiment.'],
 ['Scripts: analysis/01_extract.py, 02_qc.py, 03_survival.py, 04_immunology.py, 05_figures.py, 06_evidence.py (run in that order).'],
]
wb = xlsxwriter.Workbook(out)
hdr = wb.add_format({'bold': True, 'bg_color': '#DDDDDD', 'text_wrap': True, 'valign': 'top', 'border': 1})
wrap = wb.add_format({'text_wrap': True, 'valign': 'top'})
for name, df in sheets:
    ws = wb.add_worksheet(name[:31])
    if df is None:
        for i, row in enumerate(readme):
            ws.write(i, 0, row[0], wrap)
        ws.set_column(0, 0, 160)
        continue
    df = df.copy()
    for j, c in enumerate(df.columns):
        ws.write(0, j, str(c), hdr)
    for i, row in enumerate(df.itertuples(index=False), start=1):
        for j, val in enumerate(row):
            if isinstance(val, float) and (np.isnan(val) or np.isinf(val)):
                ws.write_blank(i, j, None)
            elif isinstance(val, (int, float, np.integer, np.floating)):
                ws.write_number(i, j, float(val))
            else:
                ws.write(i, j, str(val), wrap if len(str(val)) > 40 else None)
    widths = {'statement': 60, 'value': 70, 'cells': 45, 'reduction': 55, 'statistic': 60, 'finding': 70, 'evidence': 70, 'impact': 50, 'handling': 45,
              'per_block': 70, 'conditions': 50, 'analysis_set': 55, 'measurand': 40, 'cells_': 40}
    for j, c in enumerate(df.columns):
        ws.set_column(j, j, widths.get(c, 14))
    ws.freeze_panes(1, 0)
    ws.autofilter(0, 0, len(df), len(df.columns) - 1)
wb.close()
print('workbook written:', out)

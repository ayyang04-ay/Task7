# PSLN-344 — Portfolio Review: Recommendation, Evidence and Forward View

**Asset.** PSLN-344 is a Mn²⁺-coordinated, pulmonary-surfactant-biomimetic liposome (DPPC/DPPG/DPPE-PEG2000/cholesterol) encapsulating the STING agonist CDN-1807. It is an intranasal adjuvant for inactivated influenza A vaccine in older adults. Its internal comparator, PSLN-212, is the identical liposome without Mn²⁺.

**Evidence base.** Two files, used as the sole ground truth:
- `adjuvant_program_dataset.xlsx`: 15 sheets, parsed into 107 analysable blocks, 5,593 per-animal measurements and 514 animal-level survival records.
- `adjuvant_program_annotation.pdf`: 19 pp.

Where general scientific or regulatory knowledge is used, it is marked *external context*. No claim about PSLN-344 rests on it.

**How to check any number.**
- Each number names its block (e.g. S06-B). Key numbers also give worksheet cells (e.g. `S06!J17:J23`).
- `PSLN-344_evidence_ledger.xlsx` has one row per quantity (283 in total): cells, n, the reduction applied and an integrity grade. It also holds the per-animal tidy data with cell addresses, every contrast, the survival analyses and the audit tables.
- Reductions and statistics are defined in Appendix A.
- "PSLN-212(Y)" / "young" = 7–8-week-old mice given the non-Mn formulation, the benchmark for what the adjuvant achieves without immunosenescence. All other groups are aged (≥20 months) unless stated.

---

## 1. Recommendation

**Do not advance PSLN-344 into IND-enabling development at this review.**

I do not recommend terminating it today either:
- Put it on hold and fund only a 4–6-week independent source-data audit (Gate 0).
- If Gate 0 fails, terminate.
- If Gate 0 passes, fund one pre-registered, blinded confirmatory study in aged mice (Gate 1, ~9 months) before any other spend.

**Reason 1 — If the data are genuine, the biology is strong.**

In aged mice, adding Mn²⁺ to the same liposome (single intranasal dose, bivalent inactivated vaccine, day 14) gives:

| Readout (block) | PSLN-344 | PSLN-212 | Effect (95% CI) |
|---|---|---|---|
| Serum IgG vs CA09, GMT (S03-A) | 7,305 | 393 | 18.6× (9.11–37.9) |
| HAI vs CA09, GMT (S03-C) | 368 | 45.9 | 8.00× (3.91–16.4) |
| Cross-reactive IFN-γ⁺ CD8 T cells, % (S05-F) | 6.36 | 1.50 | +4.85 pp (3.63–6.07) |

- Across 27 readouts that have a young benchmark, PSLN-344 closes a median 0.75 (IQR 0.62–0.84) of the age-related deficit (Fig. 1).
- As printed, 46/56 aged BALB/c mice survive challenge with PSLN-344 versus 6/56 with PSLN-212, across eight studies. The risk difference is 71.4 percentage points (95% CI 55.3–81.1).

**Reason 2 — The protection evidence, which is what an adjuvant decision rests on, cannot be certified.**

The challenge dataset contains four kinds of problem (Section 3):
- **Re-used weight data.** Body-weight trajectories recur across independent experiments. 18 animal pairs share ≥4 identical changing values, against 0 of 131,784 pairs when the days are deliberately mis-aligned. There are also integer-offset copies of 5–8-decimal values.
- **Contradictory records.** Survival records contradict the weight records of the same animals.
- **A non-independent replication.** The "three-strain replication" re-uses one template.
- **Deaths without challenge.** Unchallenged, unvaccinated aged controls died (4/21; S06-E, S06-G).

These may be compilation errors, and no single one proves the effect is false. But an IND package cannot be built on them without the source records.

**Reason 3 — Even if the data are clean, three translational gaps block a clinical plan.**
- **Delivery.** The proposed mechanism is alveolar: uptake depends on surfactant proteins and alveolar epithelium (S01-B, S01-C). Mouse intranasal instillation delivers much of the dose to the lower airways, whereas a human nasal spray deposits in the nose (*external context*).
- **Inflammation.** In aged lungs given PSLN-344, Tnf and Il10 transcripts at 72 h are still 17.8× and 36.6× the young level (S09-A, 72 h panel). This is an ageing feature that Mn²⁺ does not correct (Fig. 4).
- **Manganese.** There are no data on Mn disposition, including olfactory or CNS exposure.

There is also no licensed-vaccine benchmark, no lung viral-load data, and every animal was female.

**What would change this recommendation.** Advance only if all three of the following hold:
1. Gate 0 traces every flagged item to a clerical cause and recovers the primary records.
2. Gate 1 reproduces a survival benefit over PSLN-212 of ≥40 percentage points in aged mice of both sexes and two strains, with ≥1 log₁₀ less lung virus than unadjuvanted vaccine.
3. Protection survives nasal-restricted delivery, or an inhaled product with acceptable lung safety is in view.

**What we drop if we stop (as printed).**
- The only formulation in our data that repairs aged-lung antigen presentation (monocyte → moDC differentiation, CD11b⁺ DC migration, CD8 priming).
- Heterosubtypic protection in aged animals that starts within 3 days and lasts to day 60.
- A candidate pharmacodynamic biomarker set (airway CCL2 / IFN-β / GM-CSF).

Whatever the decision, one mechanistic hypothesis should be kept as platform knowledge: the aged-lung bottleneck that Mn²⁺ relieves may be GM-CSF- and type-I-IFN-licensed monocyte → moDC differentiation (S02-G, S02-H; Sections 5–6).

**Answers to the committee's questions, by section.**

| Question | Short answer | Section |
|---|---|---|
| Do we advance? | No, not to IND-enabling. Hold for a 4–6-week source-data audit; terminate if it fails; otherwise one confirmatory aged-mouse study before re-presenting. | 1, 3 |
| What is driving protection? | Durable cross-subtype protection is most consistent with cross-reactive CD8 T-cell immunity (effector and lung-resident memory), primed through a Mn²⁺-restored monocyte → moDC / CD11b⁺ DC axis. An early day-2–3 phase needs antigen plus adjuvant, but its nature is unresolved. Antibody explains only the strain-matched result. Causality is untested. | 5 |
| Is there a biomarker of efficacy? | None established. Carry a two-tier hypothesis: an early airway PD panel (CCL2, IFN-β/ISG, GM-CSF with 72 h resolution) and the day-14 cross-reactive IFN-γ⁺ CD8 response as candidate efficacy correlate. | 6 |
| Could it go into patients, and in what role? | Not yet. If the gates are passed: a mucosal adjuvant with inactivated or split antigen for adults ≥65, for breadth and speed (pandemic/pre-pandemic use or add-on to licensed IM vaccine). The biomarkers can be measured in people: PD for dose selection, CD8 for early go/no-go. | 6, 7 |
| What must the next studies establish? | Data integrity; confirmed aged heterosubtypic protection with viral load in both sexes against PSLN-212 and a standard-of-care benchmark; the causal arm of immunity; deliverability and Mn/lung safety; biomarker linkage. | 8 |
| What was considered and ruled out? | 21 options and interpretations, with the evidence for each | 9 |

---

## 2. The strongest case for PSLN-344, as printed

### 2.1 Immunogenicity in aged animals

Table 1 compares PSLN-344 with PSLN-212 in aged BALB/c. The liposome and CDN-1807 are the same; only Mn²⁺ differs. The young benchmark is shown alongside.
- n = 5 per arm unless noted. Group values are geometric means for folds and titres and arithmetic means for percentages.
- Effects are ratios of geometric means (×) or differences in percentage points (pp).
- Restoration fraction = (PSLN-344 − PSLN-212) / (young − PSLN-212): 0 means no rescue of the aged deficit, 1 means the young level.
- Cells for every entry are in the ledger.

| Readout | Block | Sham / vaccine | PSLN-212 aged | **PSLN-344 aged** | PSLN-212 young | PSLN-344 vs PSLN-212: effect (95% CI) | p (Welch; exact MWU) | Restoration fraction |
|---|---|---|---|---|---|---|---|---|
| **Innate, lung** | | | | | | | | |
| Ifnb1, 16 h (fold) | S01-A 16h | 0.94 | 16.5 | **36.9** | 37.5 | 2.23× (1.85 to 2.69) | <0.001; 0.008 | 0.980 |
| Ifnb1, 72 h (fold) | S01-A 72h | 0.98 | 3.41 | **4.17** | 1.46 | 1.22× (0.750 to 1.99) | 0.334; 0.222 | -0.235 |
| Ccl2, 16 h (fold; n=3) | S09-A left | 1.00 | 7.63 | **590** | 1,391 | 77.4× (16.7 to 357) | 0.002; 0.100 | 0.835 |
| Ccl3, 16 h (fold; n=3) | S09-A left | 1.00 | 1.12 | **29.8** | 57.3 | 26.7× (9.96 to 71.6) | <0.001; 0.100 | 0.834 |
| Il6, 16 h (fold; n=3) | S09-A left | 1.00 | 5.57 | **36.1** | 60.3 | 6.48× (1.60 to 26.2) | 0.021; 0.100 | 0.784 |
| Gm-csf, 36 h (fold) | S02-F | 1.20 | 1.59 | **8.52** | – | 5.36× (3.93 to 7.32) | <0.001; 0.008 | n/a |
| Monocytes CD11b⁺Ly6C⁺, day 4 (%) | S01-D | 10.4 | 16.7 | **30.6** | 32.2 | +13.8 pp (8.13 to 19.5) | 0.002; 0.008 | 0.893 |
| **Dendritic cells** | | | | | | | | |
| cDC1 XCR1⁺, 72 h (%) | S01-F | 17.9 | 22.8 | **37.5** | 43.4 | +14.7 pp (6.12 to 23.3) | 0.006; 0.008 | 0.714 |
| Migratory CCR7⁺ CD11b⁺ DC, lung, 72 h (%) | S02-A | 2.54 | 7.28 | **30.7** | 35.0 | +23.4 pp (13.8 to 33.0) | 0.002; 0.008 | 0.844 |
| Antigen⁺ DC in MLN, 36 h (%) | S02-C | – | 1.77 | **7.09** | 9.39 | +5.32 pp (3.59 to 7.05) | <0.001; 0.008 | 0.698 |
| OT-I proliferation driven by MLN CD11b⁺ DC (%) | S02-E | – | 0.77 | **18.7** | 26.2 | +17.9 pp (14.4 to 21.4) | <0.001; 0.008 | 0.702 |
| CD40⁺ of MLN CD11b⁺ DC, day 3 (%) | S02-D CD40 | 3.96 | 5.56 | **11.2** | 38.7 | +5.65 pp (1.98 to 9.31) | 0.011; 0.008 | 0.170 |
| CD86⁺ of MLN CD11b⁺ DC, day 3 (%) | S02-D CD86 | 7.18 | 8.13 | **14.5** | 37.9 | +6.41 pp (2.97 to 9.85) | 0.003; 0.008 | 0.215 |
| **CD8 T cells** | | | | | | | | |
| Lung Ki-67⁺ CD8, day 3 (%) | S05-D | 0.83 | 3.48 | **9.38** | 9.94 | +5.90 pp (3.57 to 8.23) | <0.001; 0.008 | 0.913 |
| Lung GZMB⁺ CD8, day 3 (%) | S05-E | 0.99 | 2.99 | **5.69** | 9.61 | +2.70 pp (1.46 to 3.94) | 0.001; 0.008 | 0.408 |
| MLN IFN-γ⁺ CD8, heterologous (rgH5N1) restim, day 14 (%) | S05-F | 0.67 | 1.50 | **6.36** | 9.18 | +4.85 pp (3.63 to 6.07) | <0.001; 0.008 | 0.632 |
| Same, day 60 (%) | S05-G | 1.46 | 3.04 | **9.86** | 14.4 | +6.82 pp (3.39 to 10.3) | 0.003; 0.008 | 0.603 |
| Lung TRM CD69⁺CD103⁺ CD8, day 25 (%) | S05-I | 0.58 | 1.00 | **3.96** | 6.04 | +2.96 pp (2.18 to 3.74) | <0.001; 0.008 | 0.588 |
| MLN IFN-γ⁺ CD8, CA09 restim (%; day n.s.) | S14-A H1N1 | 0.82 | 3.14 | **11.0** | 13.7 | +7.88 pp (4.59 to 11.2) | <0.001; 0.008 | 0.746 |
| **Tfh / germinal centre** | | | | | | | | |
| ICOS-hi Tfh, day 7 (%) | S04-A ICOShi | 0.30 | 3.82 | **10.3** | 13.6 | +6.44 pp (2.57 to 10.3) | 0.009; 0.008 | 0.656 |
| Tfr, day 7 (%) | S04-B Tfr | 22.6 | 26.7 | **10.8** | 7.12 | -15.9 pp (-24.0 to -7.69) | 0.005; 0.008 | 0.812 |
| Tfr, day 30 (%) | S04-C | 13.9 | 18.0 | **14.0** | 7.40 | -4.04 pp (-9.21 to 1.13) | 0.109; 0.151 | 0.380 |
| GC B cells, day 7 (%) | S03-K | 1.18 | 2.34 | **6.54** | 9.82 | +4.20 pp (2.33 to 6.08) | 0.002; 0.008 | 0.562 |
| **Antibody (single dose, day 14)** | | | | | | | | |
| IgG anti-CA09 (GMT) | S03-A | 55.7 | 393 | **7,305** | 11,959 | 18.6× (9.11 to 37.9) | <0.001; 0.008 | 0.856 |
| HAI anti-CA09 (GMT) | S03-C | 7.58 | 45.9 | **368** | 485 | 8.00× (3.91 to 16.4) | <0.001; 0.008 | 0.882 |
| Neutralising anti-CA09 (GMT) | S03-D | 52.2 | 418 | **3,840** | 6,686 | 9.19× (3.10 to 27.2) | 0.002; 0.016 | 0.800 |
| IgG anti-Aichi (GMT) | S03-E | 52.4 | 426 | **5,701** | 13,855 | 13.4× (6.07 to 29.6) | <0.001; 0.008 | 0.745 |
| HAI anti-Aichi (GMT) | S03-G | 10.0 | 34.8 | **320** | 368 | 9.19× (4.18 to 20.2) | <0.001; 0.008 | 0.941 |
| Neutralising anti-Aichi (GMT) | S03-H | 39.6 | 276 | **2,533** | 4,411 | 9.19× (3.83 to 22.1) | <0.001; 0.008 | 0.800 |
| **Aged-lung milieu** | | | | | | | | |
| CD206⁺ macrophages (%; time n.s.) | S11-E | 85.2 | 71.5 | **48.9** | 35.5 | -22.5 pp (-34.5 to -10.6) | 0.002; 0.008 | 0.628 |
| Lung Treg, day 7 (%; n=3) | S04-D | 5.88 | 6.66 | **2.99** | 1.78 | -3.67 pp (-4.54 to -2.81) | <0.001; 0.100 | 0.752 |

![Fig. 1](figures/fig1_immunogenicity_effects.png)

*Figure 1. Effect of Mn²⁺ in aged animals (A: Hedges' g, PSLN-344 vs PSLN-212; group values on the right) and the fraction of the aged deficit closed (B). Blocks in brackets.*

*Check under the annotation's stated method.* Using one-way ANOVA with Tukey across all arms of each block, the PSLN-344 vs PSLN-212 contrast stays significant for every Table 1 readout with three exceptions: CD40 (Tukey-adjusted p 0.16), day-30 Tfr (0.14) and 72 h Ifnb1 (0.94). The memo does not rely on any of those three as a positive effect. All Tukey pairs are in the ledger (*Tukey* sheet).

*Note on Ifnb1 at 72 h.* In young animals IFN-β has resolved by 72 h, so the young value is the lower one. The negative restoration fraction means PSLN-344 moves *away* from the young profile at that timepoint (Section 4).

What the table shows:

**(a) Mn²⁺ corrects the aged innate defect rather than simply adding inflammation.**
- At 16 h, Ifnb1 rises from 16.5× to 36.9× (S01-A). That equals the young value (37.5×; ratio 0.984, 95% CI 0.837–1.16).
- Downstream, Ccl2 rises 77.4× and Gm-csf 5.36× at 36 h.
- It is not a payload effect. PSLN-344 carries no more CDN-1807: encapsulation efficiency is 54.8% vs 59.6% (S08-B).
- It is dose-sparing. PSLN-344 at 10 µg (21.0×) exceeds PSLN-212 at 40 µg (14.7×) (S08-A; age not stated).

**(b) Antigen-presentation function recovers even where surface markers do not.**
- DC-driven OT-I proliferation rises from 0.766% to 18.7% (young 26.2%; S02-E).
- Yet CD40 and CD86 on MLN CD11b⁺ DC close only 0.170 and 0.215 of the deficit (S02-D).

**(c) Antibody quality improves.**
- Recomputed per animal from the primary subclass titres (S13-A–D), IgG2a/IgG1 rises 3.40× against CA09 (95% CI 1.57–7.37) and 4.95× against Aichi (2.10–11.7). That is the young (Th1-type) ratio.
- The printed quotient blocks S03-B/S03-F say the opposite because their labels are rotated (finding A7).

**(d) Cellular memory is durable and cross-reactive.**
- IFN-γ⁺ CD8 T cells recalled by a heterologous virus (rgH5N1) are 9.86% vs 3.04% at day 60 (S05-G).
- Lung resident-memory CD8 (TRM) cells are 3.96% vs 1.00% at day 25 (S05-I).

**(e) In young animals Mn²⁺ adds little.** Ifnb1 rises only 1.34× (S01-A), and survival is identical (Section 2.2). The value proposition is specific to older adults.

### 2.2 Protection, as printed (Table 2, Fig. 2)

Table 2. Aged-animal challenge studies, survivors/n at end of follow-up (14 days; S03-J 21 days). The integrity grade comes from the audit in Section 3.

| Block | Vaccine → challenge, timing | Sham | PSLN-212 | **PSLN-344** | PSLN-212 young | Untreated (no challenge) | 344 vs 212: Fisher p; log-rank p | Integrity |
|---|---|---|---|---|---|---|---|---|
| S03-I | Bivalent → CA09 10×LD50 (homologous), d14 | 0/7 | 0/7 | **7/7** | 7/7 | – | <0.001; <0.001 | major |
| S06-A | Aichi H3N2 → PR8 H1N1, d14 | 0/7 | 1/7 | **6/7** | 7/7 | – | 0.029; 0.008 | moderate |
| S06-B | Aichi H3N2 → PR8 H1N1, d3 | 0/7 | 0/7 | **5/7** | 7/7 | – | 0.021; <0.001 | minor |
| S06-C | Bivalent → rgH5N1, d14 | 0/7 | 2/7 | **7/7** | 7/7 | – | 0.021; 0.007 | moderate |
| S06-D | Bivalent → rgH5N1, d3 | 0/7 | 2/7 | **7/7** | 7/7 | – | 0.021; 0.007 | major |
| S06-E | Aichi H3N2 → PR8 H1N1, d60 | 0/7 | 0/7 | **5/7** | 7/7 | 6/7 | 0.021; 0.002 | moderate |
| S06-F | Bivalent → rgH5N1, d60 | 0/7 | 1/7 | **5/7** | 7/7 | 7/7 | 0.103; 0.009 | moderate |
| S06-G | CA09 H1N1 → Perth H3N2, d60 | 0/7 | 0/7 | **4/7** | 7/7 | 4/7 | 0.070; 0.015 | major |
| S03-J | rgH5N1 vacc → WT VN04 H5N1, d2 (age n.s.) | 1/10 | 3/10 | **10/10** | – | – | 0.003; 0.001 | major |
| S15-L | C57BL/6, bivalent (challenge n.s.) | 0/7 | 0/7 | **6/7** | 6/7 | – | 0.005; 0.001 | major |
| S15-N | Swiss Webster, bivalent (challenge n.s.) | 0/7 | 2/7 | **6/7** | 7/7 | – | 0.103; 0.056 | major |

![Fig. 2](figures/fig2_survival_by_block.png)

*Figure 2. Survival by study as printed, with the integrity grade of each study.*

**Pooled across the eight aged BALB/c studies, stratified by study:**

| Analysis | PSLN-344 survivors | PSLN-212 survivors | Mantel-Haenszel OR for survival | p |
|---|---|---|---|---|
| All eight studies | 46/56 (82.1%) | 6/56 (10.7%) | 25.6 | CMH <0.001 |
| Excluding studies graded major | 28/35 | 4/35 | — | risk difference 68.6 pp (95% CI 47.0–80.7) |
| Least-affected study only (S06-B) | 5/7 | 0/7 | — | Fisher 0.021 |

The protection pattern, as printed, has four properties:
- **Heterosubtypic.** The vaccine and challenge viruses share neither HA nor NA subtype (S06-A/B/E/G).
- **Early.** Protection is present 3 days after vaccination (S06-B: 5/7 vs 0/7).
- **Durable.** Protection persists to day 60 (S06-E: 5/7 vs 0/7; S06-F: 5/7 vs 1/7).
- **Robust to prior infection.** In animals imprinted by earlier PR8 infection, survival after Perth H3N2 challenge is 6/7 vs 0/7 (S06-F′).

In young animals the non-Mn formulation already protects completely: S09-B, S09-D and S09-F each show 8/8 vs 8/8. Even cGAMP liposomes do so (S13-E: 7/7 vs sham 1/7).

### 2.3 Tolerability and CNS

**Body weight after immunisation (no challenge; S08-D).**
- Nadir with PSLN-344 was 96.4% of baseline vs 98.2% with vaccine alone: a difference of -1.80 pp (95% CI -3.74 to 0.143).
- The R848 combination was worse (-8.24 pp), and one animal was missing at day 10.

**CNS transcripts at 36 h (S10-A).**
- PSLN-344 did not raise brain Ifnb1 or Isg15 relative to PBS: 1.30× (95% CI 0.842–2.01) and 1.16× (0.787–1.72).
- The cholera-toxin positive control did: 5.54× and 2.70×.
- Tnf was marginally higher than PBS (1.57×, 95% CI 1.05–2.34; exact p 0.056) but not higher than the empty-liposome sham (1.20×). This is a watch item, not a finding.
- The block covers one timepoint, transcripts only, and no Mn measurement.

---

## 3. Why the package cannot carry an advance decision

I audited every block against its annotation, against the other blocks, and against itself. Table 3 summarises the findings; Appendix B gives the full cell-level evidence for each. The supporting outputs are in the ledger (sheets *Audit_register*, *Dup_weights*, *Survival_vs_weight*). Fig. 3 illustrates four of the findings.

Table 3. Audit findings (summary).

| ID | Severity | Finding (blocks) | Headline evidence | Consequence |
|---|---|---|---|---|
| A1 | Critical | Body-weight trajectories re-used across independent experiments. (S15-A, S15-C, S15-F, S15-I, S15-J, S15-M, S15-O, S09-C, S09-E, S09-G, S08-D) | 18 animal pairs share ≥4 identical changing weights (mis-aligned-day null: 0/131,784); integer-offset copies of 5–8-decimal values. E.g. S15-I "vaccine + PSLN-344" d2–d12 = S15-C PSLN-344 (S15!X73:AC78 = S15!X24:AC29) | Weight records attributed to these studies are not independent records of those animals. Because survival and weight are the same animals, the survival blocks paired with them (S06-A, S06-C, S06-F, S15-H, S06-E', S15-L, S15-N, S09-B/D/F) inherit the provenance question. |
| A2 | Critical | The three-strain replication reuses one template. (S06-A/S15-A, S15-L/S15-M, S15-N/S15-O) | PSLN-344 animal #5 has the same trajectory (85.1% carried forward) and a day-8 death in BALB/c, C57BL/6 and Swiss Webster (S15!AA6:AA10, AH106:AH110, AH137:AH141) | The C57BL/6 and Swiss Webster results cannot be counted as independent replication. |
| A3 | Critical | Survival records contradict the weight records of the same animals. (S06-D/S15-D, S06-G/S15-G, S03-I/S13-F, S03-J/S13-G, S06-E/S15-E, S06-C/S15-C, S15-L/S15-M, S09-F/S09-G) | S06-D PSLN-344: 0/7 deaths vs two flat-lined weight records (S15!W37:W40, AC37:AC40). S03-I PSLN-212: 7/7 dead by d6 vs weights changing to d10 and 3 recovering (S13!T40:V40) | For S03-I, S03-J, S06-D and S06-G the printed survival cannot be taken at face value. These include the homologous, wild-type H5N1 and day-3 headline results. |
| A4 | Major | Unchallenged, unvaccinated aged controls died. (S06-E, S06-G (Untreated)) | Untreated 1/7 (S06!L62) and 3/7 (S06!F99:F101) died. S06-G PSLN-344 4/7 = untreated 4/7 | Background mortality of this size confounds every aged survival comparison and raises a colony-health question. S06-G cannot support a durability claim. |
| A5 | Major | Neutrophil block duplicates the alveolar-macrophage block. (S11-A, S11-B) | 35/100 cells identical at the same position, 34 of them in animal columns 1–2; unrelated block pairs 0–1/100 | Both blocks excluded. |
| A6 | Major | The PSLN-344 epithelial-uptake block re-uses values from the PSLN-SRB block. (S08-C vs S01-B) | 3 of 5 AECII values shared (S01!B14, C14, F14 = S08!A14, A15, A17); the PSLN-344 column contains S01-B AECI values | Excluded. No reliable evidence on how Mn2+ changes cellular targeting. |
| A7 | Major (labelling) | IgG2a/IgG1 quotient blocks carry rotated group labels. (S03-B, S03-F vs S13-A..D) | S03 quotients equal the S13 titre ratios with group labels rotated (max diff ≤2e-3) | As printed, PSLN-344 looks Th2 (IgG1)-skewed. From the primary titres it restores the young IgG2a/IgG1 ratio. Sections 2 and 5 use S13-derived ratios. |
| A8 | Moderate (labelling) | Right-hand S09-A panel labelled "16h" is the 72 h timepoint. (S09-A (columns X-AS)) | 21/21 values equal S01-A 72 h | Treated as 72 h. It shows TNF and IL-10 persisting in aged lungs. |
| A9 | Moderate | Both columns labelled "Ly6C-CD206+ MPhi". (S07-C) | S07!B15 and S07!C15 carry the same label | Excluded. The macrophage-to-Treg link is untested. |
| A10 | Moderate | Tetramer blocks under-populated and internally contradictory. (S05-A, S05-B) | 2 values per group vs stated n=3; OVA vs bivalent vaccine in the annotation | Excluded. |
| A11 | Moderate | Derived or complementary quantities presented as separate results. (S04-B Tfh:Tfr, S01-F/S01-G) | Tfh:Tfr = (100 − Foxp3)/Foxp3 exactly; cDC1 + cDC2 ≈ 96–99% | Each pair counted once. |
| A12 | Minor | Control and preparation identities ambiguous. (S01-A vs S09-A; S08-A; S08-B; S02-C/E) | S01-A "Sham" = S09-A "PBS"; "PSLN-344/R848" undefined; EE by CDN A260 for an R848-only liposome | Affects comparator interpretation only. No decision claim rests on these blocks alone. |
| A13 | Minor | Stated n and row counts disagree; duplicate identifiers and vectors. (S03-J, S13-E, S09-B, S09-F, S06-C/S06-D, S06 block IDs) | S03-J n 9 vs 10, time cell blank (S03!G46); S13-E n 5 vs 7; S06-C and S06-D PSLN-212 vectors identical | Minor individually. Together they indicate the workbook was compiled by hand without reconciliation. |
| A14 | Design gap | Information needed to interpret blocks is missing. (various) | No viral load, histopathology, BAL, Mn or repeat-dose data; female only; CCR2 → CD8 link in young only | Limits the mechanism and translation claims. |
| A15 | Minor | Dead animals are recorded sometimes as blanks and sometimes as last-value-carried-forward. (S13-G, S15-* (mixed)) | Blank vs carried-forward conventions mixed within S15-M | Group mean weight curves are not comparable. Weights were used only animal by animal, to reconstruct fate. |

![Fig. 3](figures/fig3_integrity_examples.png)

*Figure 3. Integrity examples. (a) Weights of "vaccine + PSLN-344, challenge at day 3" (S15-I) coincide with those of a different study (S15-C). (b) The single PSLN-344 death has the same trajectory in three "independent" strains. (c) Neutrophil and alveolar-macrophage blocks share 35% of values. (d) Two PSLN-344 animals flat-line in S15-D, yet the same animals' survival block (S06-D) records no deaths.*

### 3.1 What survives the audit

The findings cluster in the protection data and the blocks that sit beside them. That is the worst place for them, because protection is what an adjuvant decision rests on.

**No integrity issue was found** in the blocks behind most of Table 1:
- Antibody titres: S03-A, C, D, E, G, H; S13-A–D, H–J.
- CD8: S05-C–I; S14-A.
- Dendritic cells: S02-A–F.
- Innate: S01-A, S01-D–G, S09-A (left panel), S08-A.
- Tfh/GC: S04-A, S04-C, S04-D; S03-K, S03-L.
- Mechanistic perturbations: S02-G–I, S07-B, S11-C, S12-A.

This rests on a position-wise scan of every pair of immunology blocks, the same test that caught S11-A/B. Outside S11, the only elevated agreement is between HAI against CA09 and against Aichi (17/25 positions identical) and between the two neutralisation blocks (8/25). That is expected: titres are discrete two-fold steps, and the same animal responds to both antigens of the bivalent vaccine. No group vector recurs across blocks.

Even so, these blocks come from the same compilation, so Gate 0 should sample them too.

**Protection.**
- No survival block is untouched. Only S06-B and S06-F′ are graded minor.
- The as-printed effect is large enough to survive sensible exclusions: 68.6 pp when the major-graded studies are dropped.
- However, its provenance is shared with weight records that are demonstrably not independent (A1–A3).
- The committee should therefore treat protection as **plausible but unverified**, not as established.

---

## 4. Translational gaps that remain even if the data are clean

1. **Delivery and deposition.**
   - The mechanism the data describe is alveolar: PSLN uptake by type II alveolar epithelial cells is 15.8% vs 0.378% for free dye (S01-B), and macrophage uptake falls from 43.1% to 12.7% without surfactant proteins A/D (S01-C).
   - *External context:* anaesthetised intranasal instillation in mice deposits much of the dose in the lower airways. A human nasal spray deposits in the nasal cavity.
   - Whether PSLN-344 works with nasal-restricted delivery is untested. If it does not, the product becomes an inhaled adjuvant for older adults, which is a much higher safety bar.
2. **Inflammation resolution in aged lungs.**
   - At 72 h, aged lungs still express Tnf (8.44× vs 0.475× in young; 17.8×) and Il10 (4.16× vs 0.114×). Ifnb1 stays raised (2.85× young; S01-A 72 h).
   - The TNF/IL-10 persistence is an ageing feature also seen with PSLN-212 (Tnf 11.0× and Il10 36.8× young).
   - On top of that, Mn²⁺ adds persistent Il6 (3.85×, 95% CI 1.36–10.9) and Ccl2 (5.24×, 2.32–11.8) compared with PSLN-212 at 72 h; Tnf shows a trend (1.62×, p 0.052). All n = 3.
   - There is no histopathology, BAL or later timepoint to show resolution. For a product for older adults, reactogenicity and lung injury are the first questions a regulator will ask.
   ![Fig. 4](figures/fig4_cytokine_16h_vs_72h.png)

   *Figure 4. Lung transcripts at 16 h and 72 h (S09-A; the right-hand panel is the 72 h timepoint, finding A8). The young profile resolves TNF and IL-10 by 72 h; the aged profile does not, with or without Mn²⁺.*
3. **Manganese.**
   - No Mn measurement in any tissue. No repeat-dose data, although an annual vaccine implies repeated dosing.
   - The only CNS readout is one 36 h transcript panel.
   - *External context:* inhaled or intranasal Mn can reach the brain via olfactory pathways, and intranasal adjuvants have a facial-nerve-palsy precedent (LT-adjuvanted intranasal influenza vaccine).
4. **No benchmark an older adult can already receive.** The comparators are sham, PSLN-212, cGAMP liposome and R848 variants. There is nothing representing high-dose or oil-in-water-adjuvanted intramuscular vaccine, or LAIV.
5. **Endpoints and population.**
   - Protection is read only as death or weight loss after 5–10× LD₅₀ mouse-adapted challenge. There is no lung viral titre or transmission endpoint.
   - Every animal was female.
   - Durability in aged animals is shown only to day 60, and S06-G, the cleanest day-60 heterosubtypic study, is confounded (A4).

---

## 5. What is driving the protection

### 5.1 The mechanistic chain the data support

Table 4. Mechanistic chain. "Perturbed?" asks whether any block removes the link and measures the consequence.

| Link | Evidence (PSLN-344 vs PSLN-212 aged unless stated) | Perturbed? | In aged animals? |
|---|---|---|---|
| 1. Mn²⁺ amplifies STING output | Ifnb1 16 h 36.9 vs 16.5 (= young) (S01-A); dose-sparing (S08-A); not payload (S08-B) | No (no STING-deficient or Mn-only arm) | Yes |
| 2. Chemokine / GM-CSF output | Ccl2 77.4×, Ccl3 26.7×, Il6 6.48× at 16 h (S09-A); Gm-csf 4.21× at 16 h, 5.36× at 36 h (S02-F) | No | Yes |
| 3. Monocyte recruitment | Day-4 monocytes 30.6% vs 16.7% (young 32.2%) (S01-D). CCR2 antagonist 9.86 → 3.26% (S07-B). Gap-junction blocker 7.28 → 3.08% (S11-C). IFNAR not required for recruitment (21.3 vs 15.4%, p 0.120; S12-A) | **Yes**: CCR2, gap junctions | CBX yes; CCR2 age not stated |
| 4. Monocyte → moDC differentiation | Donor moDC 19.7% (WT) vs 2.09% (Ifnar⁻/⁻), restored to 12.4% by GM-CSF (S02-H). GM-CSF added to PSLN-212: 5.86 → 13.8% (S02-G) | **Yes**: IFNAR, GM-CSF | Age not stated |
| 5. DC migration and antigen carriage to MLN | CCR7⁺ CD11b⁺ DC 30.7% vs 7.28% (S02-A). Antigen⁺ MLN DC 7.09% vs 1.77%, PTX arm 2.36% (S02-C) | **Yes**: Gαi (PTX); adjuvant in PTX arm not stated | Yes |
| 6. Priming of CD8 T cells | MLN DC-driven OT-I proliferation 18.7% vs 0.766% (S02-E). In vivo, PTX blocks MLN priming (30.9 → 6.83%) but not lung priming (59.0 → 55.1%) (S05-C) | Yes (PTX) | Age not stated (C57BL/6 recipients) |
| 7. CD8 effector / memory | Lung Ki-67⁺ 9.38 vs 3.48% and GZMB⁺ 5.69 vs 2.99% at day 3. Heterologous IFN-γ⁺ 6.36 vs 1.50% (d14) and 9.86 vs 3.04% (d60). TRM 3.96 vs 1.00%. CCR2 blockade: lung GZMB⁺ CD8 6.77 → 1.39% (S02-I) | CCR2 → GZMB⁺ CD8 **in young only** | Readouts yes; perturbation no |
| 8. Tfh / GC / antibody | ICOS-hi Tfh 10.3 vs 3.82%. Tfr 10.8 vs 26.7% at d7, but 14.0 vs 18.0% at d30 (young 7.40%). GC B 6.54 vs 2.34%. IgG 13–19×, HAI 8–9× (S03, S04) | No | Yes |
| 9. Protection | Antigen-dependent at day 3: vaccine + PSLN-344 6/7; vaccine alone 0/7; PSLN-344 alone 0/7 (S15-H; flagged A1). Heterosubtypic and durable (S06) | No depletion or transfer experiment anywhere | — |

### 5.2 Inference

**The best-supported driver of the durable, cross-subtype protection is a cross-reactive cellular response.** That is CD8 effector and resident-memory T cells, primed through the restored monocyte → moDC / CD11b⁺ DC axis. Antibody contributes, but can account only for the strain-matched result. Underneath sits an early phase (days 2–3) that needs antigen plus adjuvant, but whose nature is unresolved (see "Two phases" below). Four observations lead there:
1. **HA-neutralising antibody cannot explain the breadth.**
   - The vaccine-strain HAI titres in Table 1 cannot act on viruses of another HA subtype. Yet PSLN-344 protects as well against HA/NA-mismatched challenge (Aichi → PR8, S06-A: 6/7) as against matched challenge.
   - Cross-reactive N1 antibody could contribute to protection against rgH5N1 after the bivalent vaccine, because CA09 shares the N1 subtype (S06-C/D/F). But protection is just as strong in the H3N2 → H1N1 setting, where neither HA nor NA is shared. NA matching is therefore not required.
   - In S03-I, cGAMP liposomes with *lower* HAI than PSLN-212 survived better (3/7 vs 0/7). That study is flagged (A3), so this is suggestive only.
2. **The early protection needs antigen.** Neither antigen nor PSLN-344 alone protected at day 3 (S15-H, flagged). So the early effect is not a non-specific antiviral state.
3. **The one measured readout that is both cross-reactive and durable is CD8.** IFN-γ⁺ CD8 T cells recalled by a heterologous virus are present at day 14 and day 60, and lung TRM at day 25. Early lung CD8 activation (Ki-67⁺, GZMB⁺ at day 3) matches the timing of the day-3 protection.
4. **CCR2 links the two.** CCR2 blockade removes both the monocyte influx and (in young mice) the lung GZMB⁺ CD8 response.

**Two phases, not one.** Protection at day 3 is nearly as strong as at day 14 (S06-B 5/7 vs S06-A 6/7). Resident memory, measured at day 25, cannot explain that.
- **Early phase (days 2–3).** Needs antigen plus PSLN-344 (S15-H, flagged). Coincides with the IFN-β/chemokine burst and early CD8 activation. Whether it is antigen-*specific* or simply needs the inactivated virus as a co-stimulus is the single most important mechanistic unknown. The irrelevant-antigen arm of Study 1 is designed to answer it.
- **Durable phase (days 14–60).** Best matched by cross-reactive CD8 memory, plus antibody for matched strains.

**What the data cannot tell us.**
- No block depletes CD8 or CD4 T cells, transfers serum, or blocks CCR2/IFNAR/GM-CSF *and then challenges*. Necessity and sufficiency are therefore untested.
- The CCR2 → CD8 link was shown only in young animals.
- Almost every readout moves in the same rank order (sham, then PSLN-212, then PSLN-344, then young). Group-level correlation therefore cannot pick the driver; animal-level linkage and perturbation can (Study 2, Section 8).

**What is *not* driving it.**
- Extra CDN payload (S08-B).
- A non-specific innate antiviral state (S15-H, flagged).
- Better epithelial uptake. The only relevant block (S08-C) points the other way and is unreliable (A6).
- Full "rejuvenation" of the aged lung. CD40/CD86, day-30 Tfr and 72 h TNF/IL-10 all stay far from young values.

---

## 6. Is there a biomarker of efficacy worth carrying forward?

**Short answer: no biomarker of efficacy is established, but two candidates are worth carrying into the confirmatory work.** Establishing one needs pre-challenge measurement in the same animals that are challenged, within-arm prediction of outcome, and a perturbation test. The workbook has none of these.

Table 5. Candidate biomarkers, scored on the criteria that matter for a clinical programme.

| Candidate (block) | PSLN-344 vs PSLN-212, aged | Reaches young level? | On a perturbation-tested path? | Relevant to heterosubtypic protection? | When | Measurable in people? | Verdict |
|---|---|---|---|---|---|---|---|
| **Airway CCL2** (S09-A, 16 h) | 77.4× (95% CI 16.7–357), n=3 | RF 0.835 | Yes: CCR2 → monocytes (S07-B) → lung GZMB⁺ CD8 (S02-I, young) | Indirect | 16 h | Nasal lining fluid, serum | **Carry: lead PD marker** |
| **IFN-β / ISG** (S01-A, S08-A) | 2.23× (1.85–2.69) | Yes (RF 0.980) | Yes: IFNAR needed for moDC (S02-H); dose-responsive (S08-A) | Indirect | 16 h; resolution at 72 h | Nasal swab ISG, blood ISG score | **Carry: target engagement; pair with 72 h resolution** |
| **GM-CSF** (S02-F) | 4.21× (16 h), 5.36× (36 h) | No young arm | Yes: GM-CSF restores moDC (S02-H, S02-G) | Indirect | 16–36 h | Nasal fluid (low abundance) | **Carry: the Mn-specific PD marker** |
| **Cross-reactive IFN-γ⁺ CD8** (S05-F/G, S14-A) | +4.85 pp (3.63–6.07); durable to d60 | Partly (RF 0.632) | CCR2-dependent (young) | **Direct**: recalled by heterologous virus | Day 14 onward | PBMC IFN-γ ELISpot / ICS to conserved NP/M1 (*external context*: routine) | **Carry: candidate efficacy correlate, to be validated** |
| ICOS-hi Tfh (S04-A) | +6.44 pp | RF 0.656 | No | Antibody arm | Day 7 | Blood cTfh | Secondary |
| HAI / neutralising titre (S03) | 8.00–9.19× | RF 0.80–0.94 | No | Matched strains only | Day 14+ | Yes | Keep as regulatory immunogenicity endpoint only |
| Lung TRM (S05-I) | +2.96 pp | RF 0.588 | No | High | Day 25 | BAL only | Animal mechanism only |
| CD40 / CD86 on MLN DC (S02-D) | +5.65 / +6.41 pp | RF 0.170 / 0.215 | No | Protection occurs while these stay far below young | Day 3 | No | Drop |
| Tfh:Tfr (S04-B) | Derived from Tfr (A11) | Tfr not normalised at d30 | No | — | Day 7 | Blood | Drop |
| CD206⁺ macrophages / lung Treg (S11-E, S04-D) | -22.5 / -3.67 pp | RF 0.628 / 0.752 | Link untestable (S07-C unreadable, A9) | — | Timepoint not stated | BAL only | Drop for now |

**Recommendation: a two-tier biomarker hypothesis.**
- **Tier 1: early pharmacodynamic panel.** Airway CCL2 + IFN-β/ISG + GM-CSF at 16–36 h, read together with 72 h resolution of TNF/IL-6/IL-10.
  - It is the largest and most Mn-specific separation in the data.
  - It is dose-responsive.
  - It sits upstream of the only perturbation-tested links.
- **Tier 2: candidate efficacy correlate.** The day-14 cross-reactive IFN-γ⁺ CD8 response. It is the only readout that is both cross-reactive and durable, which matches what distinguishes PSLN-344's protection.
- The two tiers map onto the two phases of protection in Section 5.2: Tier 1 onto the early antigen-plus-adjuvant phase, Tier 2 onto durable cross-reactive memory.

**Could it go into patients, and in what role?** Yes. Both tiers can be measured in people: nasal lining fluid, nasal-swab transcripts, blood ISG score, and PBMC ELISpot.
- Tier 1 serves dose and regimen selection in a first-in-human study. It tests whether the Mn-specific biology translates to older adults and acts as a safety guardrail on resolution.
- Tier 2 serves as an early go/no-go immunogenicity endpoint in Phase 1b/2, *after* Study 2 shows that CD8 T cells are necessary for protection in aged animals.
- Neither tier should be used for patient enrichment or as a surrogate endpoint. HAI stays the regulatory immunogenicity endpoint for matched strains.
- If Study 2 instead shows antibody transfer protects, Tier 2 switches to antibody-based markers.

---

## 7. Could PSLN-344 go into patients, and in what role?

**Not now.** It needs Gate 0 (data integrity), Gate 1 (confirmed aged efficacy, including viral load and both sexes), the delivery and Mn-safety work in Study 3, and GLP toxicology.

**If it gets there, the defensible role is narrow.** It would be a mucosal adjuvant co-administered with inactivated or split antigen in adults ≥65. It would be positioned on breadth (heterosubtypic), speed of onset (≤3 days) and durable cellular memory. Two settings fit:
1. A **pandemic / pre-pandemic (e.g., H5) vaccine** for older adults, where strain mismatch and speed matter most.
2. A **mucosal add-on to the licensed intramuscular seasonal vaccine**, to add cross-reactive T-cell and mucosal protection.

It is *not* supported as:
- A stand-alone antiviral prophylactic: PSLN-344 without antigen gave 0/7 survival (S15-H).
- A product for younger adults: Mn²⁺ adds no survival benefit in young animals (8/8 vs 8/8, S09-B/D/F).
- A replacement for high-dose or adjuvanted intramuscular vaccines on HAI grounds. There is no head-to-head data.

---

## 8. Next studies: what each must establish

Table 6. The next studies, in gate order.

| Study and timing | Must establish | Population | Comparators | Endpoints / readouts | Go / no-go |
|---|---|---|---|---|---|
| **Gate 0: source-data and colony-health audit** (weeks 0–6; independent QA) | Every flagged item (A1–A15) traces to primary records and is clerical. Survival reconciles with facility death/euthanasia logs. The aged colony was healthy. | The workbook: all protection and weight blocks, S11-A/B, S08-C/S01-B, S03-B/F, S07-C, S05-A/B; plus a random 10% of all other cells | Raw instrument files (FCS/FlowJo workspaces, qPCR runs, ELISA reads), daily weighing and health logs (IACUC PCL-26-0417), sentinel serology and necropsy reports | Share of flagged items resolved; concordance rate on the random sample | **Go** only if all duplications are explained and originals recovered. **Otherwise terminate.** The protection package would be void, and the immunogenicity data come from the same compilation, so a full restart would be needed that the evidence does not justify. |
| **Study 1: confirmatory heterosubtypic protection** (months 2–9; aged-cohort procurement is rate-limiting, so order at the start of Gate 0 and cancel if it fails; pre-registered, randomised, blinded, ARRIVE-compliant; read out at ~month 9, re-present at ~month 10) | PSLN-344 protects aged animals against HA/NA-mismatched virus better than PSLN-212. It reduces lung virus. It holds in both sexes and two strains. It is not inferior to an older-adult benchmark. | ≥20-month BALB/c and C57BL/6, both sexes, health-screened; young (8–10 wk) reference arm | **Primary:** vaccine + PSLN-212. **Key secondary:** benchmark vaccine + squalene oil-in-water emulsion IM and/or high-dose antigen IM (the older-adult standard of care in nonclinical form). **Controls:** vaccine alone; vaccine + Mn-only liposome (no CDN; isolates Mn); PSLN-344 without antigen; irrelevant antigen + PSLN-344 (tests antigen specificity of early protection) | **Primary:** 14-day survival after heterosubtypic challenge at day 28 (blinded humane-endpoint scoring). **Key secondary:** lung viral titre on days 3 and 5 (satellite animals); weight-loss AUC; a day-3 and a day-90 challenge cohort. **Linkage, same animals before challenge:** serum HAI/MN/IgG, blood strain-appropriate NP tetramer/ICS, nasal-wash IgA. **n:** 16/arm gives 90% power for 80% vs 20% survival (23/arm for 75% vs 25%). Benchmark comparison powered on lung titre: 15/arm for 1 log₁₀. | **Go:** PSLN-344 survival ≥70% and ≥40 pp above PSLN-212 (lower 95% CI > 0) in each strain; ≥1 log₁₀ lung-titre reduction vs vaccine alone; not inferior to benchmark on titre (margin 0.5 log₁₀). |
| **Study 2: mechanism of protection (causal)** (months 3–10, alongside Study 1) | Which arm of immunity is necessary and sufficient in aged animals, and whether the monocyte → moDC axis is needed *for protection* | Aged mice given PSLN-344 + vaccine, challenged at day 28 | Anti-CD8β and anti-CD4 vs isotype (before challenge); FTY720 during challenge (resident vs recirculating T cells); immune-serum transfer into naive aged mice; INCB3344, anti-GM-CSF or anti-IFNAR during priming only | Survival, lung viral titre, weight AUC; depletion confirmed by flow cytometry; titres, CD8 recall, TRM. n = 12–16/arm. | Decides which Tier-2 marker goes into the clinic (CD8 vs antibody). If no arm is necessary, the mechanism claim is dropped. |
| **Study 3: delivery translation and safety** (mouse months 3–8; aged ferret or NHP months 8–18) | Whether protection needs deep-lung deposition. Whether aged-lung inflammation resolves. Whether Mn reaches olfactory bulb or brain. Whether repeat (annual-type) dosing is tolerated. | Aged mice: 5 µL/nostril awake (nasal-restricted) vs 50 µL anaesthetised (lung). Then aged ferrets or NHPs with device-relevant delivery (nasal spray vs nebulised). | PSLN-212, vehicle, Mn-only liposome, cholera toxin (CNS / facial-nerve positive control) | Protection by deposition route. Lung histopathology on days 1, 3, 7, 14. BAL cells and protein. TNF/IL-6/IL-10 resolution by day 7. Mn by ICP-MS in olfactory bulb, brain, blood and lung (24 h, 7 d, 28 d; single and 3 doses). CNS ISG. Trigeminal / facial-nerve histology. | **Go:** protection at clinically achievable deposition; histopathology resolved by day 14; no brain Mn above vehicle; no CNS inflammation. |
| **Study 4: biomarker bridging** (months 3–12, embedded in Studies 1–3) | Whether Tier-1 PD (BAL / nasal CCL2, IFN-β, GM-CSF at 16–36 h) predicts the day-14 CD8 response and protection in individual animals. The minimum PD-active dose. Whether the same PD is measurable in ferret or NHP nasal samples. | Satellite animals from Studies 1–3; dose range 1–40 µg (as S08-A) | PSLN-212; dose levels | Within-arm ROC AUC for protection; dose–PD curve; cross-species PD concordance | Qualifies the panel as the Phase 1 PD endpoint. |
| **Only then: IND-enabling, then first-in-human** (≥ month 18) | GLP repeat-dose toxicology (intranasal/inhaled, two species, local tolerance, CNS/olfactory); CMC (Mn content specification, lyophilised stability with 2.5% trehalose). Phase 1: adults 18–49 with sentinel dosing, then ≥65. | Healthy adults, then older adults | Placebo; licensed enhanced vaccine for older adults (high-dose or adjuvanted, IM) | Solicited nasal, local and systemic reactions days 0–7; spirometry if inhaled; blood Mn; Tier-1 PD at 6–24 h; HAI/MN day 28; nasal IgA; cross-reactive CD8 ELISpot days 14/28/180; cTfh day 7 | Standard Phase 1 stopping rules |

---

## 9. Considered and ruled out

Table 7. Options and interpretations considered.

| Considered | Why it was on the table | Why it was ruled out (evidence) |
|---|---|---|
| **Advance to IND-enabling now** | Large, coherent effects as printed | Protection data not certifiable (A1–A4); translational gaps (Section 4) |
| **Terminate today** | Integrity findings are serious | Most of the immunogenicity evidence has no detected issue. Gate 0 costs weeks. Termination becomes the recommendation if Gate 0 fails. |
| Advance PSLN-212 instead | Simpler, no Mn | Aged survival 0–30% in every study (Table 2) |
| Dose-escalate PSLN-212 | Could match PSLN-344 | Ifnb1 plateaus at 14.7× at 40 µg, below PSLN-344 at 10 µg (21.0×) (S08-A) |
| R848 combinations | Higher innate output | Weight nadir -8.24 pp vs vaccine (S08-D); Tnf 202× and Il10 179× at 16 h (S09-A); no aged efficacy data |
| cGAMP liposome (CMP-204) | Natural ligand | Weaker Ifnb1 (7.68× vs PSLN-212 16.5× at 16 h, S01-A; 7.25× at 20 µg, S08-A) and antibodies (S03); 3/7 aged survival (S03-I, flagged) |
| Position for all adults | Larger market | No Mn benefit in young animals (S09-B/D/F; S01-A: 1.34× only) |
| Stand-alone (antigen-free) prophylactic | Rapid innate protection | PSLN-344 alone: 0/7 survival at day 3 (S15-H) |
| HA-neutralising antibody as the driver | Large HAI gains | Cannot act on HA-mismatched challenge viruses, where protection is equal (Section 5.2) |
| Larger CDN payload as explanation | — | Encapsulation efficiency 54.8% vs 59.6% (S08-B) |
| Better epithelial targeting as explanation | Biomimetic design | S08-C shows lower uptake with PSLN-344 and re-uses S01-B values (A6) |
| "Full rejuvenation" narrative | Many readouts at young levels | CD40/CD86 RF 0.170/0.215; Tfr at d30 14.0% vs young 7.40%; TNF and IL-10 unresolved at 72 h |
| S03-B/S03-F as printed (PSLN-344 Th2-skewed) | Printed result | Labels rotated against the source titres (A7) |
| S09-A right panel as a 16 h replicate | Printed label | Reproduces the 72 h data exactly (A8) |
| Tfh:Tfr, and cDC1 plus cDC2, as extra evidence | Printed as separate panels | Derived or complementary (A11) |
| Tetramer (S05-A/B), macrophage transfer (S07-C), PSLN-344 uptake (S08-C), S11-A/B, unlabelled S08 rows 89–101 | Printed data | Excluded (A5, A6, A9, A10; the S08 rows have no label, units or groups) |
| Three-strain survival as independent replication | Printed claim | Template re-use (A2) |
| S06-G as proof of day-60 durability | Printed result | Unchallenged controls survive as often as PSLN-344 (4/7 vs 4/7) (A4) |
| Mean weight-loss curves as efficacy evidence | Standard readout | Mixed dead-animal conventions and copied trajectories (A1, A15). Weights used only animal by animal, to audit survival. |
| Pooling survival as if all animals were independent | Larger n | Analysed stratified by study (CMH); sensitivity analyses exclude flagged studies |
| CD40/CD86, Tfh:Tfr, MLN- or lung-only readouts, HAI as biomarkers of breadth | Available readouts | Section 6 |

---

## Appendix A. Reductions and statistics

- **Per-animal values** were read exactly as stored in the cells. The annotation states that stored values are per-animal and that group means are computed downstream. Every value keeps its worksheet cell address in the ledger (*Tidy_observations*, *Tidy_survival*).
- **Titres** (ELISA endpoint, HAI, neutralisation) were log₂-transformed. HAI entries of 0 were treated as below the 1:10 limit of detection and set to 5. Groups are geometric mean titres. Contrasts are ratios of GMTs with Welch 95% CIs on the log scale.
- **qPCR folds and ratios** were log-transformed and reported as geometric means and ratios. S09-A is supplied as log₁₀, so it was averaged on that scale and back-transformed.
- **Percentages and counts** were summarised as arithmetic means, with differences and Welch 95% CIs.
- **p-values** are Welch t and exact two-sided Mann–Whitney. With n = 5 vs 5 the smallest possible exact Mann–Whitney p is 0.008. One-way ANOVA with Tukey HSD (the method stated in the annotation) was run for every block with ≥3 arms and is in the ledger (*Tukey*); see the check under Table 1. The conclusions rest on effect sizes and their consistency, not on any single p-value.
- **Restoration fraction** = (PSLN-344 − PSLN-212)/(PSLN-212(Y) − PSLN-212), computed on the analysis scale.
- **Survival.**
  - Survivors = rows with event code 0 at the end of follow-up.
  - Per-study tests: Fisher exact (two-sided) and log-rank.
  - Pooling: stratified by study, using the Mantel–Haenszel odds ratio (0.5 added to cells for estimation), the CMH test and a conditional permutation test.
  - Risk differences carry Newcombe 95% CIs.
  - The one S03-J row with an event code but no time was treated as censored at day 21 and flagged.
- **Integrity grading of survival studies.**
  - *Major:* an unresolved contradiction with the same animals' weight record, or a duplication touching the key arms.
  - *Moderate:* a companion weight record involved in cross-experiment duplication, or a count mismatch.
  - *Minor:* annotation or count discrepancies only.
- **Duplicate detection.**
  - Every animal weight trajectory was compared with every other one from a different block/group.
  - A match counted only when the value at the same day was identical *and* had changed from that animal's previous day, so that carried-forward death values were excluded.
  - The empirical null repeated the scan with days shifted by ±2 and ±4.
  - Integer-offset copies: identical fractional parts (≥4 decimals) with different integer parts.
  - Non-weight blocks: compared position by position against unrelated blocks of the same shape.
- **Dead-animal fate from weights:** a blank before day 14, or ≥2 identical trailing values ≤90% (or ≥3 identical trailing values).

## Appendix B. Audit findings: full evidence

**A1 (Critical): Body-weight trajectories re-used across independent experiments.** Blocks: S15-A, S15-C, S15-F, S15-I, S15-J, S15-M, S15-O, S09-C, S09-E, S09-G, S08-D.

*Evidence.* 18 animal pairs share >=4 identical informative (day-to-day changing) weights at the same day; with days deliberately mis-aligned the same scan finds 0 of 131,784 pairs (empirical null). Further pairs match with identical 5-8-decimal fractional parts but different integer parts (integer-offset copies). Examples: S15-I "3d Vaccine+PSLN-344" animals #2-#7 = S15-C PSLN-344 #2-#7 on d2-d12 (S15!X24:AC29 vs S15!X73:AC78); S15-M PSLN-212(Y) (C57BL/6) #1-#6 = S09-E PSLN-344(Y) (BALB/c, Perth study) #2-#7 (e.g. S09!X40 = S15!I104 = 99.81707317); S15-M PSLN-344 #2/#3 = S15-A PSLN-344 #2/#3 with d2/d8 shifted by whole numbers (S15!X4 98.45455 vs S15!AE104 99.45455); S08-D CMP-204 (unchallenged, post-immunisation) #1/#3/#4/#5 vs S15-F PSLN-212(Y) (post-challenge): fractional parts identical on 4-5 days (S08!G22 97.79487 vs S15!B54 99.79487); S09-E PSLN-212(Y) #8 = S09-G PSLN-212(Y) #8 on all 7 post-challenge days, although they are different studies (Perth H3N2 at day 21 vs rgH5N1 at day 180).

*Consequence.* Weight records attributed to these studies are not independent records of those animals. Because survival and weight are the same animals, the survival blocks paired with them (S06-A, S06-C, S06-F, S15-H, S06-E', S15-L, S15-N, S09-B/D/F) inherit the provenance question. *Resolution:* Trace each trajectory to the facility weighing log / ELN; identify which block is original.

**A2 (Critical): The three-strain replication reuses one template.** Blocks: S06-A/S15-A, S15-L/S15-M, S15-N/S15-O.

*Evidence.* In BALB/c (S15-A), C57BL/6 (S15-M) and Swiss Webster (S15-O) the single PSLN-344 death is animal #5 in each, with d4 89.7-89.8% then 85.1% carried forward to d14 (S15!AA5:AA10; S15!AH105:AH110; S15!AH136:AH141) and death recorded on day 8 in all three (S06!D17, S15!D117, S15!D148). Challenge virus, dose and timing are not stated for S15-L/S15-N (annotation p.19).

*Consequence.* The C57BL/6 and Swiss Webster results cannot be counted as independent replication. *Resolution:* Source records for S15-L/N; statement of challenge strain and timing.

**A3 (Critical): Survival records contradict the weight records of the same animals.** Blocks: S06-D/S15-D, S06-G/S15-G, S03-I/S13-F, S03-J/S13-G, S06-E/S15-E, S06-C/S15-C, S15-L/S15-M, S09-F/S09-G.

*Evidence.* S06-D: PSLN-344 0/7 deaths, but two PSLN-344 weight records flat-line from d8 (S15!W37:W40 = 79.5; S15!AC37:AC40 = 85.2) and two PSLN-212(Y) records likewise (S15!F37:F40; S15!G38:G40). S06-G: PSLN-344 deaths recorded on d8, d9, d11 (S06!A85:A87) while only two PSLN-344 weight records stop changing, both after d12 (S15!W69:W70, S15!Z69:Z70). S03-I vs S13-F ("the animals of S03-I"): group sets differ (CMP-204 vs Naive); PSLN-212 7/7 dead by d6 (S03!A31:A37) whereas S13-F PSLN-212 weights change to d10 and 3/7 recover to 95-99% (S13!T40:V40). S03-J vs S13-G ("the animals of S03-J"): group sets differ (PSLN-212 vs Naive); Sham 9/10 dead incl. d3 and d4 (S03!G17:G18), but no S13-G Sham record stops before d8 and 4-5 recover (S13!L50, M50, O50, P50). Count mismatches also in S06-E (PSLN-344 2 vs 1; PSLN-212 7 vs 6), S06-C (PSLN-212 5 vs 6), S15-L (PSLN-212(Y) 1 vs 0), S09-F (Sham 7 rows vs 8 weight records).

*Consequence.* For S03-I, S03-J, S06-D and S06-G the printed survival cannot be taken at face value. These include the homologous, wild-type H5N1 and day-3 headline results. *Resolution:* Reconcile against facility death/euthanasia logs.

**A4 (Major): Unchallenged, unvaccinated aged controls died.** Blocks: S06-E, S06-G (Untreated).

*Evidence.* Untreated (no vaccine, adjuvant or virus): 1/7 died in S06-E (S06!L62, day 4) and 3/7 in S06-G (S06!F99:F101, days 7, 3, 10); 4/21 in 14 days. In S06-G PSLN-344 survival (4/7) equals that of unchallenged controls (4/7).

*Consequence.* Background mortality of this size confounds every aged survival comparison and raises a colony-health question. S06-G cannot support a durability claim. *Resolution:* Sentinel serology, necropsy and husbandry records for the aged colony.

**A5 (Major): Neutrophil block duplicates the alveolar-macrophage block.** Blocks: S11-A, S11-B.

*Evidence.* 35/100 per-animal cells of S11-B (neutrophils) equal S11-A (alveolar macrophages) at the same group/day/animal position. 34 of the 35 fall in animal columns 1-2 (34/40). Unrelated same-shaped block pairs (S11-A vs S11-D, S11-B vs S11-D): 0/100 and 1/100. The annotation states the two blocks were harvested differently.

*Consequence.* Both blocks excluded. *Resolution:* FlowJo workspaces for S11.

**A6 (Major): The PSLN-344 epithelial-uptake block re-uses values from the PSLN-SRB block.** Blocks: S08-C vs S01-B.

*Evidence.* S08-C AECII/PSLN-SRB shares 17.7, 17.5 and 12.2 with S01-B (S01!B14, C14, F14 = S08!A14, A15, A17). S08-C "AECII-PSLN-344-SRB" contains 4.92 and 4.13, the S01-B AECI/PSLN-SRB values (S01!B15, D15 = S08!B14, B17). The same formulation, dose and time give AECI uptake of 3.8% in S01-B and 13.8% in S08-C.

*Consequence.* Excluded. No reliable evidence on how Mn2+ changes cellular targeting. *Resolution:* Raw cytometry.

**A7 (Major (labelling)): IgG2a/IgG1 quotient blocks carry rotated group labels.** Blocks: S03-B, S03-F vs S13-A..D.

*Evidence.* Per-animal IgG2a/IgG1 computed from S13 titres reproduces S03-B/S03-F exactly (max diff <=2e-3), but S13 "PSLN-212" appears under S03 "PSLN-344", S13 "PSLN-344" under S03 "PSLN-212(Y)", and S13 "PSLN-212(Y)" under S03 "PSLN-212". The S13 labelling agrees with the total-IgG ranking in S03-A/E.

*Consequence.* As printed, PSLN-344 looks Th2 (IgG1)-skewed. From the primary titres it restores the young IgG2a/IgG1 ratio. Sections 2 and 5 use S13-derived ratios. *Resolution:* Correct S03-B/F labels.

**A8 (Moderate (labelling)): Right-hand S09-A panel labelled "16h" is the 72 h timepoint.** Blocks: S09-A (columns X-AS).

*Evidence.* 10^value reproduces the S01-A 72 h Ifnb1 values for all 7 groups (21/21 matches, 0/21 with 16 h).

*Consequence.* Treated as 72 h. It shows TNF and IL-10 persisting in aged lungs. *Resolution:* Relabel.

**A9 (Moderate): Both columns labelled "Ly6C-CD206+ MPhi".** Blocks: S07-C.

*Evidence.* S07!B15 and S07!C15 carry the same label although the annotation describes Ly6C+CD206- vs Ly6C-CD206+ transfers.

*Consequence.* Excluded. The macrophage-to-Treg link is untested. *Resolution:* Relabel from source.

**A10 (Moderate): Tetramer blocks under-populated and internally contradictory.** Blocks: S05-A, S05-B.

*Evidence.* Stated n=3, 2 values per group. The annotation gives both OVA immunisation and bivalent vaccine. External context (not from our data): NP366-374 is an H-2Db (C57BL/6) epitope, while the animals are BALB/c (H-2d).

*Consequence.* Excluded. *Resolution:* Clarify strain, immunogen and tetramer.

**A11 (Moderate): Derived or complementary quantities presented as separate results.** Blocks: S04-B Tfh:Tfr, S01-F/S01-G.

*Evidence.* Tfh:Tfr = (100 - Foxp3%)/Foxp3% of S04-B exactly (max abs diff 4e-6). cDC1 (S01-F) and cDC2 (S01-G) are complementary fractions (group sums 95.6-98.6%).

*Consequence.* Each pair counted once. *Resolution:* None needed.

**A12 (Minor): Control and preparation identities ambiguous.** Blocks: S01-A vs S09-A; S08-A; S08-B; S02-C/E.

*Evidence.* The same values are labelled "Sham" in S01-A and "PBS" in S09-A (S01!B3 1.84 = 10^S09!B3). "PSLN-344/R848" (S08-A) is not a defined preparation. S08-B measures EE "by A260 of CDN-1807" for PSLN-R848, which contains no CDN-1807. The adjuvant given to the PTX arm is not stated (S02-C/E).

*Consequence.* Affects comparator interpretation only. No decision claim rests on these blocks alone. *Resolution:* Clarify.

**A13 (Minor): Stated n and row counts disagree; duplicate identifiers and vectors.** Blocks: S03-J, S13-E, S09-B, S09-F, S06-C/S06-D, S06 block IDs.

*Evidence.* S03-J stated n 9 vs 10 rows per group; the last PSLN-344 row has an event code and no time (S03!G46 blank); follow-up stated as 22 d but censoring is at 21. S13-E stated n 5 vs 7 rows. The annotation puts the 7-row Sham in S09-B (it has 8) rather than S09-F (it has 7). S06-C and S06-D PSLN-212 survival vectors are identical (5, 8, 10, 10, 12, 14c, 14c; S06!M10:M16 = S06!A41:A47). "One death on day 8, six survivors" recurs in five PSLN-344 groups. S06 uses the labels S06-E and S06-F twice.

*Consequence.* Minor individually. Together they indicate the workbook was compiled by hand without reconciliation. *Resolution:* Reconcile.

**A14 (Design gap): Information needed to interpret blocks is missing.** Blocks: various.

*Evidence.* Timepoint not stated: S11-E, S13-H, S14-A, S07-B. Challenge not stated: S15-L, S15-N. Age not stated: S03-J, S07-B, S08-A, S02-G, S02-H. The only CCR2-to-CD8 link (S02-I) and the IFNAR monocyte block (S12-A) are in young animals. All animals are female. There are no lung viral titres, histopathology, BAL protein, manganese biodistribution or repeat-dose data anywhere in the workbook.

*Consequence.* Limits the mechanism and translation claims. *Resolution:* Addressed by the next studies (Section 8).

**A15 (Minor): Dead animals are recorded sometimes as blanks and sometimes as last-value-carried-forward.** Blocks: S13-G, S15-* (mixed).

*Evidence.* Example: S15-M uses blanks for Sham and carried-forward values for PSLN-212 within the same block.

*Consequence.* Group mean weight curves are not comparable. Weights were used only animal by animal, to reconstruct fate. *Resolution:* None needed for this analysis.


## Appendix C. Files delivered

| File | Contents |
|---|---|
| `PSLN-344_recommendation.md` / `.pdf` | This memo |
| `PSLN-344_evidence_ledger.xlsx` | One row per number (ID, cells, n, reduction, grade); per-animal tidy data with cell addresses; all contrasts; Tukey; survival (per-group, pairwise, pooled); audit register; duplicate-trajectory pairs; survival-vs-weight reconciliation; block register |
| `figures/fig1–fig4` | Immunogenicity effects; survival by study; integrity examples; 16 h vs 72 h cytokines |
| `analysis_code/` | Parser (`parse.py`: every block mapped to exact cell ranges), statistics, audit, figures, registry and renderer, all re-runnable |

# Analysis code for the PSLN-344 portfolio recommendation

All inputs are read from `/tmp/world/filesystem/adjuvant_program_dataset.xlsx`. Intermediate outputs go to `/tmp/work/`.
Two micromamba environments are used: `singlecell` (has openpyxl) and `core` (has lifelines / statsmodels / reportlab).

| Step | Command | Output |
|---|---|---|
| 1. Parse the workbook | `mm singlecell python -c "import parse as P; P.DF.to_csv('/tmp/work/tidy_observations.csv',index=False); P.SV.to_csv('/tmp/work/tidy_survival.csv',index=False); P.BL.to_csv('/tmp/work/block_metadata.csv')"` | Per-animal tidy data with the exact cell address of every value. `parse.py` hard-codes each block's cell ranges, taken from the annotation and checked against the sheet layout. |
| 2. Block statistics | `mm core python stats_blocks.py` | Group summaries, contrasts C1–C5 (C1 = PSLN-344 vs PSLN-212 aged; C2 vs sham; C3 vs young; C4 age deficit; C5 Mn effect in young), restoration fractions, ANOVA/Tukey |
| 3. Survival | `mm core python stats_surv.py` | Per-group counts, Fisher / log-rank per pair, stratified MH/CMH pooling, sensitivity sets |
| 4. Mechanism, safety, recomputed ratios | `mm core python stats_extra.py` | Perturbation contrasts, CNS, 72 h persistence, IgG2a/IgG1 recomputed from S13 titres, weight nadir |
| 5. Audit | `mm singlecell python audit_dups.py; mm singlecell python audit_dups2.py; mm singlecell python audit_dups3.py; mm singlecell python audit_survw.py; mm core python audit_register.py` | Duplicate weight trajectories (incl. integer-offset copies), non-weight coincidences, survival-vs-weight reconciliation, audit register |
| 6. Figures | `mm core python figures.py` | `figures/fig1-fig4` |
| 7. Number registry | `mm core python numbers_registry.py` | `numbers.json` and `ledger_numbers.csv`. Every number used in the memo, with cells, n and reduction |
| 8. Memo | `mm core python render.py memo_template.md PSLN-344_recommendation.md` then `mm core python md2pdf.py PSLN-344_recommendation.md PSLN-344_recommendation.pdf` | Memo. Numbers are substituted from the registry and never typed by hand. |
| 9. Ledger workbook | `mm singlecell python build_ledger.py` | `PSLN-344_evidence_ledger.xlsx` |
| 10. Independent check | `mm singlecell python independent_check.py` | Recomputes 30 headline numbers straight from raw cell ranges, bypassing the parser. All match. |

The empirical null for duplicate detection (days shifted by ±2 and ±4) was run interactively; its logic matches `audit_dups2.py` with a day offset. Result: 0 of 131,784 pairs reach ≥4 identical informative values when days are mis-aligned.

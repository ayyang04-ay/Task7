import pandas as pd, numpy as np, scipy.stats as st, sys
sys.path.insert(0,'/tmp/work/lib')
from stats_blocks import welch_ci, hedges_g, mwu, DF
out=[]
def v(b,g,k=''):
    x=DF[(DF.block==b)&(DF.group==g)&(DF.key.astype(str)==k)].sort_values('rep'); return x.value.values, (x.cell.iloc[0]+'..'+x.cell.iloc[-1]) if len(x) else ''
def add(label,b,ga,gb,k='',log=False,note=''):
    a,ca=v(b,ga,k); c,cc=v(b,gb,k)
    A=np.log2(a) if log else a; C=np.log2(c) if log else c
    d,lo,hi,p=welch_ci(A,C)
    if log: eff,elo,ehi=2**d,2**lo,2**hi; ma,mb=2**A.mean(),2**C.mean()
    else: eff,elo,ehi=d,lo,hi; ma,mb=A.mean(),C.mean()
    out.append(dict(analysis=label,block=b,key=k,A=ga,B=gb,A_cells=ca,B_cells=cc,nA=len(a),nB=len(c),A_summary=ma,B_summary=mb,
                    effect=eff,ci_lo=elo,ci_hi=ehi,effect_type='ratio of GMs' if log else 'difference of means',p_welch=p,p_mwu=mwu(A,C),note=note))
# ---- IgG2a/IgG1 recomputed from S13 primary titres (labels as in S13) ----
for a,b,lab in [('S13-A','S13-B','CA09'),('S13-C','S13-D','Aichi')]:
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        x,_=v(a,g); y,_=v(b,g)
        DF.loc[len(DF)]=dict(block=f'IgG2a/IgG1 {lab} (S13 derived)',sheet='S13',group=g,key='',rep=0,cell=f'{a}/{b}',value=np.nan)
    r={g:(v(a,g)[0]/v(b,g)[0]) for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']}
    for ga,gb in [('PSLN-344','PSLN-212'),('PSLN-344','PSLN-212(Y)')]:
        A,C=np.log2(r[ga]),np.log2(r[gb]); d,lo,hi,p=welch_ci(A,C)
        out.append(dict(analysis=f'IgG2a/IgG1 ratio {lab}, recomputed per animal from S13 titres',block=f'{a}/{b}',key='',A=ga,B=gb,
                        A_cells='',B_cells='',nA=5,nB=5,A_summary=2**A.mean(),B_summary=2**C.mean(),effect=2**d,ci_lo=2**lo,ci_hi=2**hi,
                        effect_type='ratio of GMs',p_welch=p,p_mwu=mwu(A,C),note='S03-B/F group labels are rotated vs these titres; S13 labels agree with S03-A/E total IgG ranking'))
# ---- mechanism perturbations ----
add('CCR2 antagonist: lung monocytes','S07-B_mono','PSLN-344+INCB3344','PSLN-344',note='age not stated')
add('CCR2 antagonist: lung Ly6C+ macrophages','S07-B_LyMac','PSLN-344+INCB3344','PSLN-344',note='age not stated')
add('CCR2 antagonist: lung GZMB+ CD8 (young)','S02-I','PSLN-344(Y)+INCB3344','PSLN-344(Y)',note='YOUNG animals only')
add('Gap-junction blocker CBX: recruited monocytes','S11-C','CBX+','CBX-',note='aged, CA09 + PSLN-344')
add('IFNAR-/- BM: donor moDC (no cDC precursors)','S02-H','IFN w/o cDC','WT w/o cDC',note='age not stated')
add('IFNAR-/- BM: donor moDC (with cDC precursors)','S02-H','IFN w/ cDC','WT w/ cDC')
add('IFNAR-/- BM + GM-CSF vs IFNAR-/- BM','S02-H','GMCSF','IFN w/o cDC',note='GM-CSF group = IFNAR-/- BM minus cDC precursors + i.t. GM-CSF')
add('IFNAR-/- BM: monocyte infiltration (young, n=3)','S12-A','IFNAR-/- to WT','WT to WT',note='young')
add('GM-CSF added to PSLN-212: moDC-like cells','S02-G','PSLN-212+GM-CSF','PSLN-212',note='age not stated')
add('PTX: MLN DCs carrying antigen','S02-C','PTX','PSLN-344',note='adjuvant in PTX arm not stated')
add('PTX: DC-driven OT-I proliferation','S02-E','PTX','PSLN-344',note='adjuvant in PTX arm not stated')
add('PTX: OT-I proliferation in MLN','S05-C','MLN+PTX','MLN',note='PSLN-344 + OVA; C57BL/6 recipients')
add('PTX: OT-I proliferation in lung','S05-C','Lung+PTX','Lung')
add('SP-A/D knockout: AM uptake of liposome','S01-C','SPA/D','WT',note='young KO vs WT')
add('PSLN-SRB vs free SRB: AECII uptake','S01-B','AECII/PSLN-SRB','AECII/FreeSRB')
add('PSLN-344-SRB vs PSLN-SRB: AECII uptake (S08-C, flagged)','S08-C','AECII-PSLN-344-SRB','AECII-PSLN-SRB',note='block shares values with S01-B')
add('Encapsulation efficiency 344 vs 212','S08-B','PSLN-344','PSLN-212')
add('Gm-csf 16h 344 vs 212','S02-F','PSLN-344','PSLN-212','16h',log=True)
add('Gm-csf 36h 344 vs 212','S02-F','PSLN-344','PSLN-212','36h',log=True)
# ---- CNS safety ----
for an in ['Ifnb1','Tnf','Isg15']:
    add(f'CNS {an}: PSLN-344 vs PBS','S10-A_'+an,'PSLN-344','PBS',log=True)
    add(f'CNS {an}: PSLN-344 vs Sham','S10-A_'+an,'PSLN-344','Sham',log=True)
    add(f'CNS {an}: cholera toxin vs PBS','S10-A_'+an,'CT','PBS',log=True)
# ---- 72 h lung persistence (S01-A 72h; S09-A right block = 72 h) ----
add('Ifnb1 72h: 344 aged vs 212(Y)','S01-A_72h','PSLN-344','PSLN-212(Y)',log=True)
add('Ifnb1 72h: 344 aged vs 344(Y)','S01-A_72h','PSLN-344','PSLN-344(Y)',log=True)
add('Ifnb1 72h: 212 aged vs 212(Y)','S01-A_72h','PSLN-212','PSLN-212(Y)',log=True)
E=pd.DataFrame(out)
# S09-A right (log10 given): 344 vs Y and 212 vs Y at 72h
rows=[]
for an in ['Ifnb1','Il6','Ccl2','Ccl3','Ccl5','Tnf','Il10']:
    for blk,tp in [('S09-A_left','16 h'),('S09-A_right','72 h (block labelled 16 h)')]:
        for ga,gb in [('PSLN-344','PSLN-212(Y)'),('PSLN-344','PSLN-212'),('PSLN-212','PSLN-212(Y)')]:
            a,ca=v(blk,ga,an); c,cc=v(blk,gb,an); d,lo,hi,p=welch_ci(a,c)
            rows.append(dict(analysis=f'{an} {tp}: {ga} vs {gb}',block=blk,key=an,A=ga,B=gb,A_cells=ca,B_cells=cc,nA=3,nB=3,
                             A_summary=10**a.mean(),B_summary=10**c.mean(),effect=10**d,ci_lo=10**lo,ci_hi=10**hi,effect_type='ratio of GMs (log10 data)',p_welch=p,p_mwu=mwu(a,c),note=''))
E=pd.concat([E,pd.DataFrame(rows)])
# ---- tolerability: S08-D weight nadir per animal ----
W=DF[DF.block=='S08-D'].copy(); W['day']=W.key.str.replace('d','').astype(float)
nad=W[W.day>0].groupby(['group','rep']).value.min().reset_index()
nads=nad.groupby('group').value.agg(['count','mean','std','min']).reset_index()
nads.to_csv('/tmp/work/s08d_nadir.csv',index=False)
for g in ['PSLN-344','PSLN-212','PSLN-212/R848','CMP-204','PSLN-212(Y)']:
    a=nad[nad.group==g].value.values; c=nad[nad.group=='Vaccine'].value.values; d,lo,hi,p=welch_ci(a,c)
    E.loc[len(E)]=dict(analysis=f'Post-immunisation weight nadir (d2-d10): {g} vs vaccine alone',block='S08-D',key='nadir',A=g,B='Vaccine',A_cells='',B_cells='',
                       nA=len(a),nB=len(c),A_summary=a.mean(),B_summary=c.mean(),effect=d,ci_lo=lo,ci_hi=hi,effect_type='difference of means (% of d0)',p_welch=p,p_mwu=mwu(a,c),
                       note='CMP-204 column of S08-D is integer-offset-copied into S15-F (audit)')
E.to_csv('/tmp/work/extra_contrasts.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',70)
print(E[['analysis','A_summary','B_summary','effect','ci_lo','ci_hi','p_welch','p_mwu','note']].round(4).to_string())
print(nads.round(2))

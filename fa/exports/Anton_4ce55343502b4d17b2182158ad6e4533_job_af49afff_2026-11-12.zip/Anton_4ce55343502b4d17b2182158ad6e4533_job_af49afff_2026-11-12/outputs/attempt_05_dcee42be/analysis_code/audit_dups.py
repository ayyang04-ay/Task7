import sys; sys.path.insert(0,'/tmp/work/lib')
import parse as P, pandas as pd, numpy as np, itertools, collections
df=P.DF.copy()

# ---------- (1) Animal-level weight trajectories: identical values at the same day ----------
W = df[df.block.isin([b for b,m in P.BLOCKS.items() if m['kind']=='weight'])].copy()
W['day']=W.key.str.replace('d','').astype(float)
traj = {}
for (b,g,r),d in W.groupby(['block','group','rep']):
    traj[(b,g,r)] = dict(zip(d.day, zip(d.value, d.cell)))
keys=list(traj)
pairs=[]
for a,b in itertools.combinations(keys,2):
    ta,tb=traj[a],traj[b]
    same=[(day,ta[day][0],ta[day][1],tb[day][1]) for day in ta if day in tb and day>0 and abs(ta[day][0]-tb[day][0])<1e-9]
    # same fractional part with integer offset (only for values with >=3 decimals)
    frac=[(day,ta[day][0],tb[day][0],ta[day][1],tb[day][1]) for day in ta if day in tb and day>0
          and abs(ta[day][0]-tb[day][0])>1e-9 and abs((ta[day][0]%1)-(tb[day][0]%1))<1e-6
          and len(str(ta[day][0]).split('.')[-1])>=3]
    if len(same)>=3 or len(frac)>=1:
        pairs.append(dict(A=f'{a[0]}|{a[1]}|#{a[2]}',B=f'{b[0]}|{b[1]}|#{b[2]}',n_identical_days=len(same),
                          identical_days=[int(x[0]) for x in same], n_offset_copies=len(frac),
                          offset_examples='; '.join(f'd{int(x[0])}: {x[1]} ({x[3]}) vs {x[2]} ({x[4]})' for x in frac[:3]),
                          identical_examples='; '.join(f'd{int(x[0])}: {x[1]} ({x[2]} = {x[3]})' for x in same[:3])))
PW=pd.DataFrame(pairs)
# exclude within-animal LOCF artefacts (same animal) - not possible here since pairs are distinct animals
PW['cross_block']=PW.A.str.split('|').str[0]!=PW.B.str.split('|').str[0]
PW=PW.sort_values(['cross_block','n_identical_days','n_offset_copies'],ascending=False)
PW.to_csv('/tmp/work/dup_weight_pairs.csv',index=False)
print('weight-trajectory pairs flagged:',len(PW),' cross-block:',PW.cross_block.sum())
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',120)
print(PW[['A','B','n_identical_days','identical_days','n_offset_copies']].head(60).to_string())

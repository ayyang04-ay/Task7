import pandas as pd
HEADS={'A1': '18 animal pairs share ≥4 identical changing weights (mis-aligned-day null: 0/131,784); integer-offset copies of 5–8-decimal values. E.g. S15-I "vaccine + PSLN-344" d2–d12 = S15-C PSLN-344 (S15!X73:AC78 = S15!X24:AC29)', 'A2': 'PSLN-344 animal #5 has the same trajectory (85.1% carried forward) and a day-8 death in BALB/c, C57BL/6 and Swiss Webster (S15!AA6:AA10, AH106:AH110, AH137:AH141)', 'A3': 'S06-D PSLN-344: 0/7 deaths vs two flat-lined weight records (S15!W37:W40, AC37:AC40). S03-I PSLN-212: 7/7 dead by d6 vs weights changing to d10 and 3 recovering (S13!T40:V40)', 'A4': 'Untreated 1/7 (S06!L62) and 3/7 (S06!F99:F101) died. S06-G PSLN-344 4/7 = untreated 4/7', 'A5': '35/100 cells identical at the same position, 34 of them in animal columns 1–2; unrelated block pairs 0–1/100', 'A6': '3 of 5 AECII values shared (S01!B14, C14, F14 = S08!A14, A15, A17); the PSLN-344 column contains S01-B AECI values', 'A7': 'S03 quotients equal the S13 titre ratios with group labels rotated (max diff ≤2e-3)', 'A8': '21/21 values equal S01-A 72 h', 'A9': 'S07!B15 and S07!C15 carry the same label', 'A10': '2 values per group vs stated n=3; OVA vs bivalent vaccine in the annotation', 'A11': 'Tfh:Tfr = (100 − Foxp3)/Foxp3 exactly; cDC1 + cDC2 ≈ 96–99%', 'A12': 'S01-A "Sham" = S09-A "PBS"; "PSLN-344/R848" undefined; EE by CDN A260 for an R848-only liposome', 'A13': 'S03-J n 9 vs 10, time cell blank (S03!G46); S13-E n 5 vs 7; S06-C and S06-D PSLN-212 vectors identical', 'A14': 'No viral load, histopathology, BAL, Mn or repeat-dose data; female only; CCR2 → CD8 link in young only', 'A15': 'Blank vs carried-forward conventions mixed within S15-M'}
F=[
dict(id='A1',severity='Critical',area='Protection (weights)',blocks='S15-A, S15-C, S15-F, S15-I, S15-J, S15-M, S15-O, S09-C, S09-E, S09-G, S08-D',
 finding='Body-weight trajectories re-used across independent experiments.',
 evidence=('18 animal pairs share >=4 identical informative (day-to-day changing) weights at the same day; with days deliberately mis-aligned the same scan finds 0 of 131,784 pairs (empirical null). '
           'Further pairs match with identical 5-8-decimal fractional parts but different integer parts (integer-offset copies). Examples: S15-I "3d Vaccine+PSLN-344" animals #2-#7 = S15-C PSLN-344 #2-#7 on d2-d12 (S15!X24:AC29 vs S15!X73:AC78); '
           'S15-M PSLN-212(Y) (C57BL/6) #1-#6 = S09-E PSLN-344(Y) (BALB/c, Perth study) #2-#7 (e.g. S09!X40 = S15!I104 = 99.81707317); S15-M PSLN-344 #2/#3 = S15-A PSLN-344 #2/#3 with d2/d8 shifted by whole numbers (S15!X4 98.45455 vs S15!AE104 99.45455); '
           'S08-D CMP-204 (unchallenged, post-immunisation) #1/#3/#4/#5 vs S15-F PSLN-212(Y) (post-challenge): fractional parts identical on 4-5 days (S08!G22 97.79487 vs S15!B54 99.79487); '
           'S09-E PSLN-212(Y) #8 = S09-G PSLN-212(Y) #8 on all 7 post-challenge days, although they are different studies (Perth H3N2 at day 21 vs rgH5N1 at day 180).'),
 impact='Weight records attributed to these studies are not independent records of those animals. Because survival and weight are the same animals, the survival blocks paired with them (S06-A, S06-C, S06-F, S15-H, S06-E\', S15-L, S15-N, S09-B/D/F) inherit the provenance question.',
 resolution='Trace each trajectory to the facility weighing log / ELN; identify which block is original.'),
dict(id='A2',severity='Critical',area='Protection (replication across strains)',blocks='S06-A/S15-A, S15-L/S15-M, S15-N/S15-O',
 finding='The three-strain replication reuses one template.',
 evidence=('In BALB/c (S15-A), C57BL/6 (S15-M) and Swiss Webster (S15-O) the single PSLN-344 death is animal #5 in each, with d4 89.7-89.8% then 85.1% carried forward to d14 (S15!AA5:AA10; S15!AH105:AH110; S15!AH136:AH141) and death recorded on day 8 in all three (S06!D17, S15!D117, S15!D148). '
           'Challenge virus, dose and timing are not stated for S15-L/S15-N (annotation p.19).'),
 impact='The C57BL/6 and Swiss Webster results cannot be counted as independent replication.',
 resolution='Source records for S15-L/N; statement of challenge strain and timing.'),
dict(id='A3',severity='Critical',area='Protection (survival vs weight)',blocks='S06-D/S15-D, S06-G/S15-G, S03-I/S13-F, S03-J/S13-G, S06-E/S15-E, S06-C/S15-C, S15-L/S15-M, S09-F/S09-G',
 finding='Survival records contradict the weight records of the same animals.',
 evidence=('S06-D: PSLN-344 0/7 deaths, but two PSLN-344 weight records flat-line from d8 (S15!W37:W40 = 79.5; S15!AC37:AC40 = 85.2) and two PSLN-212(Y) records likewise (S15!F37:F40; S15!G38:G40). '
           'S06-G: PSLN-344 deaths recorded on d8, d9, d11 (S06!A85:A87) while only two PSLN-344 weight records stop changing, both after d12 (S15!W69:W70, S15!Z69:Z70). '
           'S03-I vs S13-F ("the animals of S03-I"): group sets differ (CMP-204 vs Naive); PSLN-212 7/7 dead by d6 (S03!A31:A37) whereas S13-F PSLN-212 weights change to d10 and 3/7 recover to 95-99% (S13!T40:V40). '
           'S03-J vs S13-G ("the animals of S03-J"): group sets differ (PSLN-212 vs Naive); Sham 9/10 dead incl. d3 and d4 (S03!G17:G18), but no S13-G Sham record stops before d8 and 4-5 recover (S13!L50, M50, O50, P50). '
           'Count mismatches also in S06-E (PSLN-344 2 vs 1; PSLN-212 7 vs 6), S06-C (PSLN-212 5 vs 6), S15-L (PSLN-212(Y) 1 vs 0), S09-F (Sham 7 rows vs 8 weight records).'),
 impact='For S03-I, S03-J, S06-D and S06-G the printed survival cannot be taken at face value. These include the homologous, wild-type H5N1 and day-3 headline results.',
 resolution='Reconcile against facility death/euthanasia logs.'),
dict(id='A4',severity='Major',area='Model / colony health',blocks='S06-E, S06-G (Untreated)',
 finding='Unchallenged, unvaccinated aged controls died.',
 evidence='Untreated (no vaccine, adjuvant or virus): 1/7 died in S06-E (S06!L62, day 4) and 3/7 in S06-G (S06!F99:F101, days 7, 3, 10); 4/21 in 14 days. In S06-G PSLN-344 survival (4/7) equals that of unchallenged controls (4/7).',
 impact='Background mortality of this size confounds every aged survival comparison and raises a colony-health question. S06-G cannot support a durability claim.',
 resolution='Sentinel serology, necropsy and husbandry records for the aged colony.'),
dict(id='A5',severity='Major',area='Innate cell kinetics',blocks='S11-A, S11-B',
 finding='Neutrophil block duplicates the alveolar-macrophage block.',
 evidence='35/100 per-animal cells of S11-B (neutrophils) equal S11-A (alveolar macrophages) at the same group/day/animal position. 34 of the 35 fall in animal columns 1-2 (34/40). Unrelated same-shaped block pairs (S11-A vs S11-D, S11-B vs S11-D): 0/100 and 1/100. The annotation states the two blocks were harvested differently.',
 impact='Both blocks excluded.',
 resolution='FlowJo workspaces for S11.'),
dict(id='A6',severity='Major',area='Targeting',blocks='S08-C vs S01-B',
 finding='The PSLN-344 epithelial-uptake block re-uses values from the PSLN-SRB block.',
 evidence='S08-C AECII/PSLN-SRB shares 17.7, 17.5 and 12.2 with S01-B (S01!B14, C14, F14 = S08!A14, A15, A17). S08-C "AECII-PSLN-344-SRB" contains 4.92 and 4.13, the S01-B AECI/PSLN-SRB values (S01!B15, D15 = S08!B14, B17). The same formulation, dose and time give AECI uptake of 3.8% in S01-B and 13.8% in S08-C.',
 impact='Excluded. No reliable evidence on how Mn2+ changes cellular targeting.',
 resolution='Raw cytometry.'),
dict(id='A7',severity='Major (labelling)',area='Antibody quality',blocks='S03-B, S03-F vs S13-A..D',
 finding='IgG2a/IgG1 quotient blocks carry rotated group labels.',
 evidence='Per-animal IgG2a/IgG1 computed from S13 titres reproduces S03-B/S03-F exactly (max diff <=2e-3), but S13 "PSLN-212" appears under S03 "PSLN-344", S13 "PSLN-344" under S03 "PSLN-212(Y)", and S13 "PSLN-212(Y)" under S03 "PSLN-212". The S13 labelling agrees with the total-IgG ranking in S03-A/E.',
 impact='As printed, PSLN-344 looks Th2 (IgG1)-skewed. From the primary titres it restores the young IgG2a/IgG1 ratio. Sections 2 and 5 use S13-derived ratios.',
 resolution='Correct S03-B/F labels.'),
dict(id='A8',severity='Moderate (labelling)',area='Cytokines',blocks='S09-A (columns X-AS)',
 finding='Right-hand S09-A panel labelled "16h" is the 72 h timepoint.',
 evidence='10^value reproduces the S01-A 72 h Ifnb1 values for all 7 groups (21/21 matches, 0/21 with 16 h).',
 impact='Treated as 72 h. It shows TNF and IL-10 persisting in aged lungs.',
 resolution='Relabel.'),
dict(id='A9',severity='Moderate',area='Mechanism',blocks='S07-C',
 finding='Both columns labelled "Ly6C-CD206+ MPhi".',
 evidence='S07!B15 and S07!C15 carry the same label although the annotation describes Ly6C+CD206- vs Ly6C-CD206+ transfers.',
 impact='Excluded. The macrophage-to-Treg link is untested.',
 resolution='Relabel from source.'),
dict(id='A10',severity='Moderate',area='CD8 specificity',blocks='S05-A, S05-B',
 finding='Tetramer blocks under-populated and internally contradictory.',
 evidence='Stated n=3, 2 values per group. The annotation gives both OVA immunisation and bivalent vaccine. External context (not from our data): NP366-374 is an H-2Db (C57BL/6) epitope, while the animals are BALB/c (H-2d).',
 impact='Excluded.',
 resolution='Clarify strain, immunogen and tetramer.'),
dict(id='A11',severity='Moderate',area='Double counting',blocks='S04-B Tfh:Tfr, S01-F/S01-G',
 finding='Derived or complementary quantities presented as separate results.',
 evidence='Tfh:Tfr = (100 - Foxp3%)/Foxp3% of S04-B exactly (max abs diff 4e-6). cDC1 (S01-F) and cDC2 (S01-G) are complementary fractions (group sums 95.6-98.6%).',
 impact='Each pair counted once.',
 resolution='None needed.'),
dict(id='A12',severity='Minor',area='Definitions / controls',blocks='S01-A vs S09-A; S08-A; S08-B; S02-C/E',
 finding='Control and preparation identities ambiguous.',
 evidence='The same values are labelled "Sham" in S01-A and "PBS" in S09-A (S01!B3 1.84 = 10^S09!B3). "PSLN-344/R848" (S08-A) is not a defined preparation. S08-B measures EE "by A260 of CDN-1807" for PSLN-R848, which contains no CDN-1807. The adjuvant given to the PTX arm is not stated (S02-C/E).',
 impact='Affects comparator interpretation only. No decision claim rests on these blocks alone.',
 resolution='Clarify.'),
dict(id='A13',severity='Minor',area='Counts / annotation',blocks='S03-J, S13-E, S09-B, S09-F, S06-C/S06-D, S06 block IDs',
 finding='Stated n and row counts disagree; duplicate identifiers and vectors.',
 evidence=('S03-J stated n 9 vs 10 rows per group; the last PSLN-344 row has an event code and no time (S03!G46 blank); follow-up stated as 22 d but censoring is at 21. '
           'S13-E stated n 5 vs 7 rows. The annotation puts the 7-row Sham in S09-B (it has 8) rather than S09-F (it has 7). '
           'S06-C and S06-D PSLN-212 survival vectors are identical (5, 8, 10, 10, 12, 14c, 14c; S06!M10:M16 = S06!A41:A47). '
           '"One death on day 8, six survivors" recurs in five PSLN-344 groups. S06 uses the labels S06-E and S06-F twice.'),
 impact='Minor individually. Together they indicate the workbook was compiled by hand without reconciliation.',
 resolution='Reconcile.'),
dict(id='A14',severity='Design gap',area='Design',blocks='various',
 finding='Information needed to interpret blocks is missing.',
 evidence=('Timepoint not stated: S11-E, S13-H, S14-A, S07-B. Challenge not stated: S15-L, S15-N. Age not stated: S03-J, S07-B, S08-A, S02-G, S02-H. '
           'The only CCR2-to-CD8 link (S02-I) and the IFNAR monocyte block (S12-A) are in young animals. All animals are female. '
           'There are no lung viral titres, histopathology, BAL protein, manganese biodistribution or repeat-dose data anywhere in the workbook.'),
 impact='Limits the mechanism and translation claims.',
 resolution='Addressed by the next studies (Section 8).'),
dict(id='A15',severity='Minor',area='Weights convention',blocks='S13-G, S15-* (mixed)',
 finding='Dead animals are recorded sometimes as blanks and sometimes as last-value-carried-forward.',
 evidence='Example: S15-M uses blanks for Sham and carried-forward values for PSLN-212 within the same block.',
 impact='Group mean weight curves are not comparable. Weights were used only animal by animal, to reconstruct fate.',
 resolution='None needed for this analysis.'),
]
for f in F: f['headline']=HEADS[f['id']]
A=pd.DataFrame(F); A.to_csv('/tmp/work/audit_register.csv',index=False); print(len(A))

import sys; sys.path.insert(0,'/tmp/work/lib')
import parse as P, pandas as pd, numpy as np, itertools
df=P.DF.copy()
C=df[df.block.isin([b for b,m in P.BLOCKS.items() if m['kind'] in ('cont',)])].copy()
# exclude derived blocks and dilution-series titre blocks
C=C[~C.block.isin(['S04-B_TfhTfr'])]
vecs={}
for (b,g,k),d in C.groupby(['block','group','key']):
    vecs[(b,g,k)]=list(zip(d.rep,d.value,d.cell))
rows=[]
def informative(v):
    s=repr(float(v))
    # require >=3 significant digits, exclude round numbers
    digits=s.replace('.','').lstrip('0').rstrip('0')
    return len(digits)>=3
for a,b in itertools.combinations(vecs,2):
    if a==b: continue
    va,vb=vecs[a],vecs[b]
    shared=[]
    used=set()
    for ra,x,ca in va:
        if not informative(x): continue
        for rb,y,cb in vb:
            if (rb,cb) in used: continue
            if abs(x-y)<1e-9:
                shared.append((x,ca,cb,ra==rb)); used.add((rb,cb)); break
    if len(shared)>=2:
        rows.append(dict(A=f'{a[0]} | {a[1]} | {a[2]}',B=f'{b[0]} | {b[1]} | {b[2]}',n_shared=len(shared),
                         n_same_position=sum(s[3] for s in shared),n_A=len(va),n_B=len(vb),
                         values='; '.join(f'{s[0]} [{s[1]}]=[{s[2]}]' for s in shared[:6])))
R=pd.DataFrame(rows).sort_values('n_shared',ascending=False)
R.to_csv('/tmp/work/dup_cont_pairs.csv',index=False)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',250)
print(R.to_string())

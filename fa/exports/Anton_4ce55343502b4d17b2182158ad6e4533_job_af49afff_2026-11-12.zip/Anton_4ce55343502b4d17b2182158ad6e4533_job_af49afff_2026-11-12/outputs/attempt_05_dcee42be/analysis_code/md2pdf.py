import re, os, sys
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.units import cm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle, Image, KeepTogether, HRFlowable, NextPageTemplate, PageBreak)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
FD='/opt/conda/envs/core/lib/python3.11/site-packages/matplotlib/mpl-data/fonts/ttf/'
pdfmetrics.registerFont(TTFont('DV',FD+'DejaVuSans.ttf')); pdfmetrics.registerFont(TTFont('DV-B',FD+'DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I',FD+'DejaVuSans-Oblique.ttf')); pdfmetrics.registerFont(TTFont('DV-BI',FD+'DejaVuSans-BoldOblique.ttf'))
pdfmetrics.registerFont(TTFont('DVM',FD+'DejaVuSansMono.ttf'))
addMapping('DV',0,0,'DV'); addMapping('DV',1,0,'DV-B'); addMapping('DV',0,1,'DV-I'); addMapping('DV',1,1,'DV-BI')
ss=getSampleStyleSheet()
BODY=ParagraphStyle('body',parent=ss['Normal'],fontName='DV',fontSize=8.6,leading=11.4,spaceAfter=4)
TITLE=ParagraphStyle('title',parent=BODY,fontName='DV-B',fontSize=15,leading=19,spaceAfter=8,textColor=colors.HexColor('#12355b'))
H1=ParagraphStyle('h1',parent=BODY,fontName='DV-B',fontSize=12,leading=15,spaceBefore=10,spaceAfter=5,textColor=colors.HexColor('#12355b'))
H2=ParagraphStyle('h2',parent=BODY,fontName='DV-B',fontSize=10,leading=13,spaceBefore=7,spaceAfter=4,textColor=colors.HexColor('#1f4e79'))
CAP=ParagraphStyle('cap',parent=BODY,fontName='DV-I',fontSize=7.6,leading=9.6,textColor=colors.HexColor('#333333'),spaceAfter=6)
CELL=ParagraphStyle('cell',parent=BODY,fontSize=6.7,leading=8.2,spaceAfter=0)
CELLH=ParagraphStyle('cellh',parent=CELL,fontName='DV-B')
BUL=ParagraphStyle('bul',parent=BODY,leftIndent=12,bulletIndent=3,spaceAfter=2)
BUL2=ParagraphStyle('bul2',parent=BODY,leftIndent=24,bulletIndent=15,spaceAfter=2)
def inline(s):
    s=s.replace('&','&amp;').replace('<','&lt;').replace('>','&gt;')
    s=re.sub(r'`([^`]+)`',r'<font face="DVM" size="7.6">\1</font>',s)
    s=re.sub(r'\*\*\*([^*]+)\*\*\*',r'<b><i>\1</i></b>',s)
    s=re.sub(r'\*\*([^*]+)\*\*',r'<b>\1</b>',s)
    s=re.sub(r'(?<![\w*])\*([^*\n]+?)\*(?![\w*])',r'<i>\1</i>',s)
    return s
def table_flow(lines,avail):
    rows=[[c.strip() for c in l.strip().strip('|').split('|')] for l in lines]
    rows=[r for r in rows if not all(re.fullmatch(r':?-{2,}:?',c) for c in r)]
    ncol=max(len(r) for r in rows)
    rows=[r+['']*(ncol-len(r)) for r in rows]
    # width heuristic
    import math
    w=[]
    for j in range(ncol):
        tot=sum(len(r[j]) for r in rows); longest=max((max((len(x) for x in r[j].split()),default=0)) for r in rows)
        w.append(max(math.sqrt(tot+1)*1.0, longest*0.55, 3.0))
    s=sum(w); widths=[avail*x/s for x in w]
    data=[]
    for i,r in enumerate(rows):
        st=CELLH if i==0 else CELL
        data.append([Paragraph(inline(c),st) for c in r])
    t=Table(data,colWidths=widths,repeatRows=1)
    style=[('GRID',(0,0),(-1,-1),0.3,colors.HexColor('#9aa9b8')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dbe7f3')),
           ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),2.5),('RIGHTPADDING',(0,0),(-1,-1),2.5),('TOPPADDING',(0,0),(-1,-1),1.5),('BOTTOMPADDING',(0,0),(-1,-1),1.5)]
    for i,r in enumerate(rows):
        if i>0 and r[0].startswith('**') and all(c=='' for c in r[1:]):
            style.append(('SPAN',(0,i),(-1,i))); style.append(('BACKGROUND',(0,i),(-1,i),colors.HexColor('#f0f4f8')))
    t.setStyle(TableStyle(style))
    return t
def build(md_path,pdf_path,base_dir):
    lines=open(md_path).read().split('\n')
    doc=BaseDocTemplate(pdf_path,pagesize=A4,leftMargin=1.5*cm,rightMargin=1.5*cm,topMargin=1.6*cm,bottomMargin=1.5*cm,
                        title='PSLN-344 portfolio review recommendation',author='Portfolio analysis')
    fr=Frame(doc.leftMargin,doc.bottomMargin,doc.width,doc.height,id='f')
    def onpage(c,d):
        c.saveState(); c.setFont('DV',7); c.setFillColor(colors.HexColor('#555555'))
        c.drawString(1.5*cm,A4[1]-1.0*cm,'PSLN-344 — portfolio review recommendation (grounded in adjuvant_program_dataset.xlsx / annotation.pdf)')
        c.drawRightString(A4[0]-1.5*cm,1.0*cm,f'page {d.page}'); c.restoreState()
    doc.addPageTemplates([PageTemplate(id='p',frames=[fr],onPage=onpage)])
    avail=doc.width
    story=[]; i=0
    while i<len(lines):
        l=lines[i]; s=l.strip()
        if not s: i+=1; continue
        if s.startswith('|'):
            tl=[]
            while i<len(lines) and lines[i].strip().startswith('|'): tl.append(lines[i]); i+=1
            story.append(table_flow(tl,avail)); story.append(Spacer(1,5)); continue
        m=re.match(r'!\[[^\]]*\]\(([^)]+)\)',s)
        if m:
            p=os.path.join(base_dir,m.group(1))
            from reportlab.lib.utils import ImageReader
            ir=ImageReader(p); iw,ih=ir.getSize(); wd=avail; ht=wd*ih/iw
            if ht>20*cm: ht=20*cm; wd=ht*iw/ih
            story.append(Image(p,width=wd,height=ht)); i+=1; continue
        if s=='---': story.append(HRFlowable(width='100%',thickness=0.5,color=colors.HexColor('#9aa9b8'),spaceBefore=4,spaceAfter=4)); i+=1; continue
        if s.startswith('# '): story.append(Paragraph(inline(s[2:]),TITLE)); i+=1; continue
        if s.startswith('## '): story.append(Paragraph(inline(s[3:]),H1)); i+=1; continue
        if s.startswith('### '): story.append(Paragraph(inline(s[4:]),H2)); i+=1; continue
        if re.match(r'^- ',l):
            story.append(Paragraph(inline(re.sub(r'^\s*- ','',l)),BUL,bulletText='•')); i+=1; continue
        if re.match(r'^\s{2,}- ',l):
            story.append(Paragraph(inline(re.sub(r'^\s*- ','',l)),BUL2,bulletText='–')); i+=1; continue
        m=re.match(r'^\s*(\d+)\. (.*)',l)
        if m:
            story.append(Paragraph(inline(m.group(2)),BUL,bulletText=m.group(1)+'.')); i+=1; continue
        if s.startswith('*') and s.endswith('*') and not s.startswith('**'):
            story.append(Paragraph(inline(s),CAP)); i+=1; continue
        # paragraph: merge consecutive non-special lines
        buf=[s]; i+=1
        while i<len(lines) and lines[i].strip() and not re.match(r'^(\s*[-|#!]|\s*\d+\. |---)',lines[i]):
            buf.append(lines[i].strip()); i+=1
        story.append(Paragraph(inline(' '.join(buf)),BODY))
    doc.build(story)
if __name__=='__main__':
    build(sys.argv[1],sys.argv[2],os.path.dirname(sys.argv[1]))
    print('pdf written')

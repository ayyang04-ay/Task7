"""
Parser for adjuvant_program_dataset.xlsx.
Every observation is stored with sheet, block id, group, sub-key (timepoint/analyte/day),
replicate index and the exact cell address, so every downstream number is traceable.
"""
import openpyxl
from openpyxl.utils import column_index_from_string as cidx, get_column_letter as cl
import pandas as pd

XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
_wb = openpyxl.load_workbook(XLSX, data_only=True)

def cell(sheet, addr):
    return _wb[sheet][addr].value

def _num(v):
    if v is None: return None
    if isinstance(v, (int, float)): return float(v)
    try: return float(str(v).strip())
    except: return None

RECS = []   # list of dicts (numeric observations)
BLOCKS = {} # block metadata

def add_block(bid, sheet, kind, measurand, units, timepoint, stated_n, note='', age=''):
    BLOCKS[bid] = dict(block=bid, sheet=sheet, kind=kind, measurand=measurand, units=units,
                       timepoint=timepoint, stated_n=stated_n, note=note, age=age)

def rec(bid, group, key, rep, sheet, addr, value=None):
    v = _num(cell(sheet, addr)) if value is None else value
    if v is None: return
    RECS.append(dict(block=bid, sheet=sheet, group=group, key=key, rep=rep, cell=f'{sheet}!{addr}', value=v))

def cols(a, b):
    return [cl(i) for i in range(cidx(a), cidx(b)+1)]

# ---------- simple column blocks: header row of groups, values rows below -------------
def col_block(bid, sheet, hdr_row, first_col, last_col, r0, r1, key='', groups=None):
    for c in cols(first_col, last_col):
        g = groups[c] if groups else cell(sheet, f'{c}{hdr_row}')
        if g is None: continue
        g = str(g).strip()
        for i, r in enumerate(range(r0, r1+1)):
            rec(bid, g, key, i+1, sheet, f'{c}{r}')

# ---------- row blocks: group name in col A (or given), values across columns ----------
def row_block(bid, sheet, rows, gcol, c0, c1, key=''):
    for r in rows:
        g = str(cell(sheet, f'{gcol}{r}')).strip()
        for i, c in enumerate(cols(c0, c1)):
            rec(bid, g, key, i+1, sheet, f'{c}{r}')

# ---------- time-course blocks: groups occupy column spans, one row per day --------------
def span_block(bid, sheet, spans, rows, daycol, key_prefix='', fixed_key=None):
    """spans: list of (group, c0, c1)"""
    for r in rows:
        d = cell(sheet, f'{daycol}{r}')
        key = fixed_key if fixed_key is not None else f'{key_prefix}{d}'
        for g, c0, c1 in spans:
            for i, c in enumerate(cols(c0, c1)):
                rec(bid, g, key, i+1, sheet, f'{c}{r}')

# ---------- survival: one row per animal; group columns hold 1/0 ---------------------------
SURV = []
def surv_block(bid, sheet, daycol, gcols, r0, r1):
    for r in range(r0, r1+1):
        d = _num(cell(sheet, f'{daycol}{r}'))
        for c in gcols:
            e = cell(sheet, f'{c}{r}')
            if e is None: continue
            g = str(cell(sheet, f'{c}{hdr_rows[bid]}')).strip()
            SURV.append(dict(block=bid, sheet=sheet, group=g, time=d, event=int(e),
                             cell_time=f'{sheet}!{daycol}{r}', cell_event=f'{sheet}!{c}{r}'))
hdr_rows = {}

# =========================== S01 ===========================
add_block('S01-A_16h','S01','cont','Ifnb1 qPCR, total lung','fold vs untreated (linear)','16 h post dose (no vaccine)',5,age='aged unless (Y)')
row_block('S01-A_16h','S01',range(3,11),'A','B','F')
add_block('S01-A_72h','S01','cont','Ifnb1 qPCR, total lung','fold vs untreated (linear)','72 h post dose (no vaccine)',5,age='aged unless (Y)')
row_block('S01-A_72h','S01',range(3,11),'G','H','L')
add_block('S01-B','S01','cont','SRB+ alveolar epithelial cells (PSLN-SRB vs free SRB)','%','16 h',5,age='aged')
row_block('S01-B','S01',range(14,18),'A','B','F')
add_block('S01-C','S01','cont','DiD+ alveolar macrophages (WT vs Sftpa1/Sftpd KO)','%','16 h',4,age='young (KO 7-8 wk)')
row_block('S01-C','S01',range(20,22),'A','B','E')
add_block('S01-D','S01','cont','Lung monocytes CD11b+Ly6C+','%','days 0-8 post immunisation',5)
span_block('S01-D','S01',[('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U')],range(24,29),'A','d')
add_block('S01-E','S01','cont','Lung CD11b+ DCs','%','days 0-8 post immunisation',5)
span_block('S01-E','S01',[('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U'),('PSLN-344(Y)','V','Z')],range(30,35),'A','d')
add_block('S01-F','S01','cont','Lung cDC1 (XCR1+)','%','72 h',5)
span_block('S01-F','S01',[('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U'),('PSLN-344(Y)','V','Z')],[36],'A','',fixed_key='')
add_block('S01-G','S01','cont','Lung cDC2 (CD172a+)','%','72 h',5)
span_block('S01-G','S01',[('Sham','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U'),('PSLN-344(Y)','V','Z')],[38],'A','',fixed_key='')

# =========================== S02 ===========================
add_block('S02-A','S02','cont','Lung migratory CCR7+ CD11b+ DCs','%','72 h',5)
col_block('S02-A','S02',2,'A','D',3,7)
add_block('S02-B','S02','cont','MLN CD11b+CD103- DCs','%','72 h',5)
col_block('S02-B','S02',2,'F','I',3,7)
add_block('S02-C','S02','cont','MLN DCs carrying AF647-OVA','%','36 h',5)
col_block('S02-C','S02',2,'K','O',3,7)
add_block('S02-D_CD40','S02','cont','CD40+ of MLN CD11b+ DCs','%','day 3',5)
col_block('S02-D_CD40','S02',9,'A','D',10,14)
add_block('S02-D_CD86','S02','cont','CD86+ of MLN CD11b+ DCs','%','day 3',5)
col_block('S02-D_CD86','S02',9,'F','I',10,14)
add_block('S02-E','S02','cont','OT-I proliferation driven by sorted MLN CD11b+ DCs','%','DC harvest 72 h; 3 d co-culture',5)
col_block('S02-E','S02',9,'K','O',10,14)
add_block('S02-F','S02','cont','Gm-csf qPCR, lung','fold vs untreated (linear)','16/36/72 h',5)
span_block('S02-F','S02',[('PSLN-344','B','F'),('PSLN-212','G','K'),('Sham','L','P')],range(17,20),'A','')
add_block('S02-G','S02','cont','Lung Ly6C+CD11c+MHCII+ moDC-like cells','%','day 5',5,age='not stated')
col_block('S02-G','S02',21,'B','D',22,26)
add_block('S02-H','S02','cont','Donor CD45.2+ moDCs in BM chimeras (WT vs Ifnar-/-)','%','day 3',5,age='not stated')
col_block('S02-H','S02',29,'B','F',30,34)
add_block('S02-I','S02','cont','Lung GZMB+ CD8 (CCR2 antagonist INCB3344)','%','day 5',5,age='young')
col_block('S02-I','S02',29,'H','I',30,34)

# =========================== S03 ===========================
for bid, c0, c1, r_h, r0, r1, meas, unit in [
    ('S03-A','A','E',2,3,7,'Serum IgG anti-CA09 (ELISA)','reciprocal endpoint titre'),
    ('S03-B','G','I',2,3,7,'IgG2a/IgG1 quotient anti-CA09','ratio'),
    ('S03-C','K','O',2,3,7,'HAI anti-CA09 (LOD 1:10)','reciprocal titre'),
    ('S03-D','Q','U',2,3,7,'Neutralising titre anti-CA09','reciprocal titre'),
    ('S03-E','A','E',9,10,14,'Serum IgG anti-Aichi (ELISA)','reciprocal endpoint titre'),
    ('S03-F','G','I',9,10,14,'IgG2a/IgG1 quotient anti-Aichi','ratio'),
    ('S03-G','K','O',9,10,14,'HAI anti-Aichi (LOD 1:10)','reciprocal titre'),
    ('S03-H','Q','U',9,10,14,'Neutralising titre anti-Aichi','reciprocal titre')]:
    add_block(bid,'S03','titre' if 'titre' in unit else 'cont',meas,unit,'day 14 (single IN dose, bivalent)',5)
    col_block(bid,'S03',r_h,c0,c1,r0,r1)
add_block('S03-K','S03','cont','MLN GC B cells (CXCR5+GL7+)','%','day 7',5)
col_block('S03-K','S03',16,'L','O',17,21)
add_block('S03-L_Aicda','S03','cont','Aicda qPCR in MLN B cells','fold vs untreated','day 5',3)
row_block('S03-L_Aicda','S03',range(26,29),'K','L','N')
add_block('S03-L_E47','S03','cont','E47 qPCR in MLN B cells','fold vs untreated','day 5',3)
row_block('S03-L_E47','S03',range(26,29),'K','O','Q')

# =========================== S04 ===========================
add_block('S04-A_ICOSlo','S04','cont','MLN Tfh CXCR5+PD1+ ICOS-lo','%','day 7',5)
row_block('S04-A_ICOSlo','S04',range(2,6),'A','B','F')
add_block('S04-A_ICOShi','S04','cont','MLN Tfh CXCR5+PD1+ ICOS-hi','%','day 7',5)
row_block('S04-A_ICOShi','S04',range(2,6),'A','G','K')
add_block('S04-B_Tfr','S04','cont','MLN Tfr (Foxp3+ in CXCR5+ICOShi)','%','day 7',5)
col_block('S04-B_Tfr','S04',7,'A','D',8,12)
add_block('S04-B_TfhTfr','S04','cont','Tfh:Tfr quotient','ratio','day 7',5)
col_block('S04-B_TfhTfr','S04',14,'A','D',15,19)
add_block('S04-C','S04','cont','MLN Tfr (Foxp3+ in CXCR5+ICOShi)','%','day 30',5)
col_block('S04-C','S04',21,'A','D',22,26)
add_block('S04-D','S04','cont','Lung Treg CD4+Foxp3+','%','day 7',3)
col_block('S04-D','S04',28,'A','D',29,31)

# =========================== S05 ===========================
add_block('S05-A','S05','cont','Lung NP366-374 tetramer+ CD8','%','days 3/5/7',3)
span_block('S05-A','S05',[('PSLN-212','B','C'),('PSLN-344','E','F'),('PSLN-212(Y)','H','I')],range(3,6),'A','d')
add_block('S05-B','S05','cont','MLN NP366-374 tetramer+ CD8','%','days 3/5/7',3)
span_block('S05-B','S05',[('PSLN-212','B','C'),('PSLN-344','E','F'),('PSLN-212(Y)','H','I')],range(8,11),'A','d')
add_block('S05-C','S05','cont','OT-I proliferation in vivo (PSLN-344 + OVA, +/- PTX)','%','day 4',3,age='not stated (C57BL/6 CD45.1 recipients)')
col_block('S05-C','S05',12,'A','D',13,15)
for bid, hr, r0, r1, meas, tp in [('S05-D',18,19,23,'Lung Ki-67+ CD8','day 3'),('S05-E',25,26,30,'Lung GZMB+ CD8','day 3'),
                                  ('S05-F',32,33,37,'MLN IFN-g+ CD8 (rgH5N1 restim)','day 14'),('S05-G',39,40,44,'MLN IFN-g+ CD8 (rgH5N1 restim)','day 60'),
                                  ('S05-H',46,47,51,'MLN GZMB+ CD8','day 60'),('S05-I',53,54,58,'Lung TRM CD69+CD103+ CD8','day 25')]:
    add_block(bid,'S05','cont',meas,'%',tp,5)
    col_block(bid,'S05',hr,'A','D',r0,r1)

# =========================== S06 (survival) ===========================
def surv(bid, sheet, daycol, gcols, hdr, r0, r1, **meta):
    hdr_rows[bid] = hdr
    add_block(bid, sheet, 'surv', meta.get('meas','time to death'), 'days', meta.get('tp',''), meta.get('n',None), note=meta.get('note',''), age=meta.get('age','aged'))
    surv_block(bid, sheet, daycol, gcols, r0, r1)

surv('S06-A','S06','A',list('BCDE'),2,3,30,tp='Aichi H3N2 vacc; 5xLD50 PR8 H1N1 at d14',n=7)
surv('S06-B','S06','G',list('HIJK'),2,3,30,tp='Aichi H3N2 vacc; 5xLD50 PR8 H1N1 at d3',n=7)
surv('S06-C','S06','M',list('NOPQ'),2,3,30,tp='bivalent vacc; 5xLD50 rgH5N1 at d14',n=7)
surv('S06-D','S06','A',list('BCDE'),33,34,61,tp='bivalent vacc; 5xLD50 rgH5N1 at d3',n=7)
surv('S06-E','S06','G',list('HIJKL'),33,34,68,tp='Aichi H3N2 vacc; 5xLD50 PR8 H1N1 at d60',n=7)
surv('S06-F','S06','M',list('NOPQR'),33,34,68,tp='bivalent vacc; 5xLD50 rgH5N1 at d60',n=7)
surv('S06-G','S06','A',list('BCDEF'),70,71,105,tp='CA09 H1N1 vacc; 5xLD50 Perth H3N2 at d60',n=7)
surv("S06-E'(imprint)",'S06','G',list('HIJK'),70,71,98,tp='PR8-imprinted (10 mo) vs naive; bivalent vacc at 14 mo; 5xLD50 PR8',n=7,age='14 mo at vaccination')
surv("S06-F'(imprint)",'S06','M',list('NOPQ'),70,71,98,tp='PR8-imprinted vs naive; bivalent vacc; 5xLD50 Perth H3N2 at d14',n=7,age='14 mo at vaccination')

# =========================== S07 ===========================
add_block('S07-A','S07','cont','Lung Ly6C+CCR2+ macrophages','count x1e5','days 0-30',3)
span_block('S07-A','S07',[('PSLN-212','B','D'),('PSLN-344','E','G')],range(3,8),'A','d')
add_block('S07-B_mono','S07','cont','Lung CD11b+Ly6C+ monocytes (+/- INCB3344)','%','not stated',5,age='not stated')
col_block('S07-B_mono','S07',9,'B','C',10,14)
add_block('S07-B_LyMac','S07','cont','Lung Ly6C+ macrophages (+/- INCB3344)','%','not stated',5,age='not stated')
col_block('S07-B_LyMac','S07',9,'E','F',10,14)
add_block('S07-C','S07','cont','Recipient lung Treg after macrophage transfer','%','day 4 after transfer',5)
col_block('S07-C','S07',15,'B','C',16,20, groups={'B':'col B "Ly6C-CD206+ MPhi"','C':'col C "Ly6C-CD206+ MPhi"'})

# =========================== S08 ===========================
add_block('S08-A','S08','cont','Ifnb1 qPCR dose-response (1-40 ug)','fold vs untreated','16 h',3,age='not stated')
span_block('S08-A','S08',[('CMP-204','B','D'),('PSLN-212','E','G'),('PSLN-344','H','J'),('PSLN-344/R848','K','M')],range(3,8),'A','dose')
add_block('S08-B','S08','cont','Encapsulation efficiency (A260 of CDN-1807)','%','n/a',3)
span_block('S08-B','S08',[('CMP-204','A','C'),('PSLN-212','D','F'),('PSLN-R848','G','I'),('PSLN-212/R848','J','L'),('PSLN-344','M','O')],[11],'A','',fixed_key='')
add_block('S08-C','S08','cont','SRB+ alveolar epithelial cells (PSLN-SRB vs PSLN-344-SRB)','%','16 h',5,age='aged')
col_block('S08-C','S08',13,'A','D',14,18)
add_block('S08-D','S08','weight','Body weight after immunisation (no challenge)','% of d0','days 0-10 post immunisation',5)
span_block('S08-D','S08',[('PSLN-212(Y)','B','F'),('CMP-204','G','K'),('PSLN-212','L','P'),('PSLN-344','Q','U'),('PSLN-212/R848','V','Z'),('Vaccine','AA','AE')],range(21,27),'A','d')

# =========================== S09 ===========================
grpsA = [('PBS','B','D'),('CMP-204','E','G'),('PSLN-212','H','J'),('PSLN-R848','K','M'),('PSLN-212/R848','N','P'),('PSLN-344','Q','S'),('PSLN-212(Y)','T','V')]
grpsB = [('PBS','Y','AA'),('CMP-204','AB','AD'),('PSLN-212','AE','AG'),('PSLN-R848','AH','AJ'),('PSLN-212/R848','AK','AM'),('PSLN-344','AN','AP'),('PSLN-212(Y)','AQ','AS')]
add_block('S09-A_left','S09','cont','Lung cytokine qPCR panel (log10 fold)','log10 fold','labelled 16 h',3)
add_block('S09-A_right','S09','cont','Lung cytokine qPCR panel (log10 fold)','log10 fold','labelled 16 h (see audit: matches S01-A 72 h)',3)
for r in range(3,10):
    an = cell('S09', f'A{r}')
    for g,c0,c1 in grpsA:
        for i,c in enumerate(cols(c0,c1)): rec('S09-A_left', g, an, i+1, 'S09', f'{c}{r}')
    an2 = cell('S09', f'X{r}')
    for g,c0,c1 in grpsB:
        for i,c in enumerate(cols(c0,c1)): rec('S09-A_right', g, an2, i+1, 'S09', f'{c}{r}')
surv('S09-B','S09','A',list('BCD'),11,12,35,tp='young; Aichi vacc; 5xLD50 PR8 at d21',n=8,age='young')
surv('S09-D','S09','A',list('BCD'),38,39,62,tp='young; CA09 vacc; 5xLD50 Perth H3N2 at d21',n=8,age='young')
surv('S09-F','S09','A',list('BCD'),65,66,88,tp='young; bivalent vacc; 5xLD50 rgH5N1 at d180',n=8,age='young')
W9 = [('PSLN-212(Y)','G','N'),('Sham','O','V'),('PSLN-344(Y)','W','AD')]
for bid, rows in [('S09-C',range(12,20)),('S09-E',range(39,47)),('S09-G',range(66,74))]:
    add_block(bid,'S09','weight','Body weight after challenge','% of d0','days 0-14 post challenge',8,age='young')
    span_block(bid,'S09',W9,rows,'F','d')

# =========================== S10 ===========================
add_block('S10-A_Ifnb1','S10','cont','CNS Ifnb1 qPCR','fold vs untreated','36 h',5,age='aged')
col_block('S10-A_Ifnb1','S10',2,'A','D',3,7)
add_block('S10-A_Tnf','S10','cont','CNS Tnf qPCR','fold vs untreated','36 h',5,age='aged')
col_block('S10-A_Tnf','S10',2,'F','I',3,7)
add_block('S10-A_Isg15','S10','cont','CNS Isg15 qPCR','fold vs untreated','36 h',5,age='aged')
col_block('S10-A_Isg15','S10',2,'K','N',3,7)

# =========================== S11 ===========================
G11 = [('Vaccine','B','F'),('PSLN-212','G','K'),('PSLN-344','L','P'),('PSLN-212(Y)','Q','U')]
add_block('S11-A','S11','cont','Lung alveolar macrophages','%','days 0-8',5)
span_block('S11-A','S11',G11,range(3,8),'A','d')
add_block('S11-B','S11','cont','Lung neutrophils','%','days 0-8',5)
span_block('S11-B','S11',G11,range(10,15),'A','d')
add_block('S11-C','S11','cont','Lung recruited monocytes +/- carbenoxolone','%','day 3',5)
col_block('S11-C','S11',16,'A','B',17,21)
add_block('S11-D','S11','cont','Lung NK cells','%','days 0-8',5)
span_block('S11-D','S11',G11,range(24,29),'A','d')
add_block('S11-E','S11','cont','Lung CD206+ macrophages','%','NOT STATED',5)
col_block('S11-E','S11',30,'A','D',31,35)

# =========================== S12 ===========================
add_block('S12-A','S12','cont','Donor CD45.2+ monocytes infiltrating (WT vs Ifnar-/- BM)','%','day 3',3,age='young')
col_block('S12-A','S12',2,'A','B',3,5)

# =========================== S13 ===========================
for bid, c0, c1, meas in [('S13-A','A','C','Serum IgG2a anti-CA09'),('S13-B','E','G','Serum IgG1 anti-CA09'),
                          ('S13-C','I','K','Serum IgG2a anti-Aichi'),('S13-D','M','O','Serum IgG1 anti-Aichi')]:
    add_block(bid,'S13','titre',meas,'reciprocal endpoint titre','day 14',5)
    col_block(bid,'S13',2,c0,c1,3,7)
surv('S13-E','S13','R',list('STUV'),2,3,30,tp='young; as S03-I; 10xLD50 CA09 at d14',n=5,age='young')
add_block('S13-F','S13','weight','Body weight after challenge (stated: animals of S03-I)','% of d0','days 0-14',7)
span_block('S13-F','S13',[('PSLN-212(Y)','B','H'),('Sham','I','O'),('PSLN-212','P','V'),('PSLN-344','W','AC'),('Naive','AD','AJ')],range(33,41),'A','d')
add_block('S13-G','S13','weight','Body weight after challenge (stated: animals of S03-J)','% of d0','days 0-14',10)
span_block('S13-G','S13',[('PSLN-344','B','K'),('Sham','L','U'),('Naive','V','AE')],range(43,51),'A','d')
add_block('S13-H','S13','cont','IgG+ of MLN B220+ cells','%','NOT STATED',5)
col_block('S13-H','S13',52,'A','D',53,57)
add_block('S13-I','S13','titre','Serum IgG anti-CA09 after boost','reciprocal endpoint titre','day 28 (boost d14)',5)
col_block('S13-I','S13',52,'F','J',53,57)
add_block('S13-J','S13','titre','Serum IgG anti-Aichi after boost','reciprocal endpoint titre','day 28 (boost d14)',5)
col_block('S13-J','S13',52,'L','P',53,57)

# =========================== S14 ===========================
add_block('S14-A_H1N1','S14','cont','MLN IFN-g+ CD8 (CA09 restim)','%','NOT STATED',5)
col_block('S14-A_H1N1','S14',2,'A','D',3,7)
add_block('S14-A_H3N2','S14','cont','MLN IFN-g+ CD8 (Aichi restim)','%','NOT STATED',5)
col_block('S14-A_H3N2','S14',2,'F','I',3,7)

# =========================== S15 ===========================
W15 = [('PSLN-212(Y)','B','H'),('Sham','I','O'),('PSLN-212','P','V'),('PSLN-344','W','AC')]
W15u = W15 + [('Untreated','AD','AJ')]
for bid, rows, spans, tp in [('S15-A',range(3,11),W15,'weights of S06-A'),('S15-B',range(13,21),W15,'weights of S06-B'),
                         ('S15-C',range(23,31),W15,'weights of S06-C'),('S15-D',range(33,41),W15,'weights of S06-D'),
                         ('S15-E',range(43,51),W15u,'weights of S06-E'),('S15-F',range(53,61),W15u,'weights of S06-F'),
                         ('S15-G',range(63,71),W15u,'weights of S06-G')]:
    add_block(bid,'S15','weight','Body weight after challenge','% of d0',tp,7)
    span_block(bid,'S15',spans,rows,'A','d')
surv('S15-H','S15','A',list('BCD'),72,73,93,tp='vaccine alone / PSLN-344 alone / both, 3 d before 5xLD50 rgH5N1',n=7)
add_block('S15-I','S15','weight','Body weight after challenge (animals of S15-H)','% of d0','days 0-14',7)
span_block('S15-I','S15',[('3d Vaccine','I','O'),('3d PSLN-344','P','V'),('3d Vaccine+PSLN-344','W','AC')],range(72,80),'H','d')
WJ = [('Naive+PSLN-212','I','O'),('Imprinting+PSLN-212','P','V'),('Naive+PSLN-344','W','AC'),('Imprinting+PSLN-344','AD','AJ')]
add_block('S15-J','S15','weight','Body weight, imprinting study, PR8 challenge',"% of d0",'weights of S06-E\'',7)
span_block('S15-J','S15',WJ,range(83,91),'H','d')
add_block('S15-K','S15','weight','Body weight, imprinting study, Perth challenge',"% of d0",'weights of S06-F\'',7)
span_block('S15-K','S15',WJ,range(93,101),'H','d')
surv('S15-L','S15','A',list('BCDE'),102,103,130,tp='aged C57BL/6 (20 mo); bivalent vacc; challenge (virus/timing not stated)',n=7,age='aged C57BL/6')
W15m = [('PSLN-212(Y)','I','O'),('Sham','P','V'),('PSLN-212','W','AC'),('PSLN-344','AD','AJ')]
add_block('S15-M','S15','weight','Body weight, C57BL/6','% of d0','weights of S15-L',7)
span_block('S15-M','S15',W15m,range(103,111),'H','d')
surv('S15-N','S15','A',list('BCDE'),133,134,161,tp='aged Swiss Webster (20 mo); bivalent vacc; challenge (virus/timing not stated)',n=7,age='aged Swiss Webster')
add_block('S15-O','S15','weight','Body weight, Swiss Webster','% of d0','weights of S15-N',7)
span_block('S15-O','S15',W15m,range(134,142),'H','d')

# survival blocks in S03 / S13 / S08
surv('S03-I','S03','A',list('BCDEF'),16,17,51,tp='bivalent vacc; 10xLD50 CA09 (homologous) at d14',n=7)
surv('S03-J','S03','G',list('HIJ'),16,17,46,tp='rgH5N1 vacc; WT VN04 H5N1 at d2; obs 22 d',n=9,age='not stated')

DF = pd.DataFrame(RECS)
SV = pd.DataFrame(SURV)
BL = pd.DataFrame(BLOCKS).T
# normalise group labels
def norm(g):
    g = g.strip().replace('Naïve','Naive')
    g = g.replace('PSLN-212Y','PSLN-212(Y)').replace('PSLN-344Y','PSLN-344(Y)').replace('PSLN-212(y)','PSLN-212(Y)')
    return g
DF['group'] = DF['group'].map(norm)
SV['group'] = SV['group'].map(norm)

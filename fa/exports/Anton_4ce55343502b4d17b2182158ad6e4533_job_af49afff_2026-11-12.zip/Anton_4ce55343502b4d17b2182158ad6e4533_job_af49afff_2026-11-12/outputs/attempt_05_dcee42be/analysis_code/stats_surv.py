import pandas as pd, numpy as np, scipy.stats as st, warnings
from lifelines.statistics import logrank_test
from statsmodels.stats.contingency_tables import StratifiedTable
warnings.filterwarnings('ignore')
S=pd.read_csv('/tmp/work/tidy_survival.csv')
S.loc[S.time.isna(),'time']=21.0  # S03-J row 46: event=0 with blank time -> treat as censored at end of follow-up (21 d), flagged
FLAGS={ # integrity grade from audit (see audit tables); 'major' = unresolved contradiction or duplication touching the key groups
 'S03-I':'major','S03-J':'major','S06-A':'moderate','S06-B':'minor','S06-C':'moderate','S06-D':'major','S06-E':'moderate',
 'S06-F':'moderate','S06-G':'major',"S06-E'(imprint)":'moderate',"S06-F'(imprint)":'minor','S15-H':'major','S15-L':'major','S15-N':'major',
 'S09-B':'minor','S09-D':'minor','S09-F':'moderate','S13-E':'minor'}
rows=[]
for b,d in S.groupby('block',sort=False):
    for g,x in d.groupby('group',sort=False):
        rows.append(dict(block=b,group=g,n=len(x),deaths=int(x.event.sum()),survivors=int(len(x)-x.event.sum()),
                         pct_survival=100*(1-x.event.mean()),median_time_to_death=np.median(x[x.event==1].time) if x.event.sum() else np.nan,
                         cells=f'{x.cell_event.iloc[0]}..{x.cell_event.iloc[-1]}',integrity=FLAGS.get(b,'')))
G=pd.DataFrame(rows); G.to_csv('/tmp/work/survival_groups.csv',index=False)

def compare(b,a,c):
    d=S[S.block==b]; xa=d[d.group==a]; xc=d[d.group==c]
    if len(xa)==0 or len(xc)==0: return None
    tab=[[xa.event.sum(),len(xa)-xa.event.sum()],[xc.event.sum(),len(xc)-xc.event.sum()]]
    pf=st.fisher_exact(tab)[1]
    lr=logrank_test(xa.time,xc.time,xa.event,xc.event)
    return dict(block=b,A=a,B=c,A_deaths=f'{int(xa.event.sum())}/{len(xa)}',B_deaths=f'{int(xc.event.sum())}/{len(xc)}',
                A_surv_pct=100*(1-xa.event.mean()),B_surv_pct=100*(1-xc.event.mean()),
                risk_diff_surv_pp=100*((1-xa.event.mean())-(1-xc.event.mean())),
                p_fisher=pf,p_logrank=lr.p_value,integrity=FLAGS.get(b,''))
pairs=[]
for b in S.block.unique():
    groups=set(S[S.block==b].group)
    for a,c in [('PSLN-344','PSLN-212'),('PSLN-344','Sham'),('PSLN-344','PSLN-212(Y)'),('PSLN-212','Sham'),('PSLN-344','Untreated'),
                ('Naive+PSLN-344','Naive+PSLN-212'),('Imprinting+PSLN-344','Imprinting+PSLN-212'),('Imprinting+PSLN-212','Naive+PSLN-212'),
                ('3d Vaccine+PSLN-344','3d Vaccine'),('3d Vaccine+PSLN-344','3d PSLN-344'),('PSLN-344(Y)','Sham'),('PSLN-212(Y)','Sham'),
                ('PSLN-344(Y)','PSLN-212(Y)'),('CMP-204','PSLN-212'),('CMP-204(Y)','Sham')]:
        if a in groups and c in groups:
            r=compare(b,a,c)
            if r: pairs.append(r)
P=pd.DataFrame(pairs); P.to_csv('/tmp/work/survival_pairs.csv',index=False)

# ---- pooled, stratified analysis of PSLN-344 vs PSLN-212 in aged animals ----
def pooled(blocks, a='PSLN-344', c='PSLN-212', label=''):
    tabs=[]; A=[0,0]; C=[0,0]
    for b in blocks:
        d=S[S.block==b]
        if not ({a,c} <= set(d.group)):
            # imprint blocks use prefixed names
            continue
        xa=d[d.group==a]; xc=d[d.group==c]
        # table: rows = treatment (a,c), cols = (survived, died)
        t=np.array([[len(xa)-xa.event.sum(), xa.event.sum()],[len(xc)-xc.event.sum(), xc.event.sum()]],float)
        tabs.append(t); A[0]+=t[0,0]; A[1]+=t[0].sum(); C[0]+=t[1,0]; C[1]+=t[1].sum()
    stt=StratifiedTable([t+0.5 for t in tabs])  # Haldane correction for OR estimate
    stt_raw=StratifiedTable(tabs)
    cmh=stt_raw.test_null_odds(correction=True)
    # exact-ish check: permutation of treatment labels within strata (conditional on margins)
    rng=np.random.default_rng(1)
    obs=sum(t[0,0] for t in tabs)
    sims=[]
    for _ in range(200000):
        s=0
        for t in tabs:
            n1=int(t[0].sum()); surv=int(t[:,0].sum()); N=int(t.sum())
            s+=rng.hypergeometric(surv, N-surv, n1)
        sims.append(s)
    sims=np.array(sims); p_exact=(np.sum(np.abs(sims-sims.mean())>=abs(obs-sims.mean())-1e-9))/len(sims)
    return dict(analysis=label,strata=len(tabs),blocks=','.join(b for b in blocks if {a,c}<=set(S[S.block==b].group)),
                A_survivors=f'{int(A[0])}/{int(A[1])}',A_surv_pct=100*A[0]/A[1],B_survivors=f'{int(C[0])}/{int(C[1])}',B_surv_pct=100*C[0]/C[1],
                MH_OR_survival=stt.oddsratio_pooled,MH_OR_CI=stt.oddsratio_pooled_confint(),CMH_p=cmh.pvalue,perm_p_conditional=p_exact)
aged_BALBc=['S03-I','S06-A','S06-B','S06-C','S06-D','S06-E','S06-F','S06-G']
res=[]
res.append(pooled(aged_BALBc,label='A. As printed: all aged BALB/c challenge blocks with both arms'))
res.append(pooled(aged_BALBc+['S03-J','S15-L','S15-N'],label='B. As printed: + S03-J (WT H5N1, age unstated) + C57BL/6 + Swiss Webster'))
clean=[b for b in aged_BALBc if FLAGS[b] in ('minor',)]
res.append(pooled([b for b in aged_BALBc if FLAGS[b] in ('minor','moderate')],label='C. Excluding blocks graded major (S03-I, S06-D, S06-G)'))
res.append(pooled(clean,label='D. Only blocks graded minor (S06-B)'))
R=pd.DataFrame(res); R.to_csv('/tmp/work/survival_pooled.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',120)
print(G.to_string())
print(P.round(4).to_string())
print(R.to_string())

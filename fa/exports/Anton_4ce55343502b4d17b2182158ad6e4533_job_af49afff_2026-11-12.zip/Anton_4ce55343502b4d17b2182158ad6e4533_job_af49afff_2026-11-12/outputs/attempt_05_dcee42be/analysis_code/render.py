import re, json, pandas as pd, numpy as np
W='/tmp/work/'
N=json.load(open(W+'numbers.json'))
GS=pd.read_csv(W+'group_summaries.csv',keep_default_na=False,na_values=['']); GS['key']=GS['key'].fillna('').astype(str)
C=pd.read_csv(W+'contrasts.csv',keep_default_na=False,na_values=['']); C['key']=C['key'].fillna('').astype(str)
SG=pd.read_csv(W+'survival_groups.csv'); SP=pd.read_csv(W+'survival_pairs.csv')
A=pd.read_csv(W+'audit_register.csv')
USED=set()
def f3(x):
    if x is None or (isinstance(x,float) and np.isnan(x)): return '–'
    ax=abs(x)
    if ax>=1000: return f'{x:,.0f}'
    if ax>=100: return f'{x:.0f}'
    if ax>=10: return f'{x:.1f}'
    if ax>=1: return f'{x:.2f}'
    return f'{x:.2f}'
def gval(block,g,key=''):
    x=GS[(GS.block==block)&(GS.group==g)&(GS.key==key)]
    if len(x)==0: return '–'
    x=x.iloc[0]
    v=x.geo_mean if x.scale!='linear' else x['mean']
    return f3(v)
def pfmt(p): return '<0.001' if p<0.001 else f'{p:.3f}'
TITRE={'S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}
def table1():
    rows=[('**Innate, lung**',None,None,None),
      ('Ifnb1, 16 h (fold)','S01-A_16h','','ifnb16'),('Ifnb1, 72 h (fold)','S01-A_72h','','ifnb72'),
      ('Ccl2, 16 h (fold; n=3)','S09-A_left','Ccl2','ccl2_16'),('Ccl3, 16 h (fold; n=3)','S09-A_left','Ccl3','ccl3_16'),('Il6, 16 h (fold; n=3)','S09-A_left','Il6','il6_16'),
      ('Gm-csf, 36 h (fold)','S02-F','36h','gmcsf36'),('Monocytes CD11b⁺Ly6C⁺, day 4 (%)','S01-D','d4','mono_d4'),
      ('**Dendritic cells**',None,None,None),
      ('cDC1 XCR1⁺, 72 h (%)','S01-F','','cdc1'),('Migratory CCR7⁺ CD11b⁺ DC, lung, 72 h (%)','S02-A','','migdc'),('Antigen⁺ DC in MLN, 36 h (%)','S02-C','','agdc'),
      ('OT-I proliferation driven by MLN CD11b⁺ DC (%)','S02-E','','oti_dc'),('CD40⁺ of MLN CD11b⁺ DC, day 3 (%)','S02-D_CD40','','cd40'),('CD86⁺ of MLN CD11b⁺ DC, day 3 (%)','S02-D_CD86','','cd86'),
      ('**CD8 T cells**',None,None,None),
      ('Lung Ki-67⁺ CD8, day 3 (%)','S05-D','','ki67'),('Lung GZMB⁺ CD8, day 3 (%)','S05-E','','gzmb3'),
      ('MLN IFN-γ⁺ CD8, heterologous (rgH5N1) restim, day 14 (%)','S05-F','','ifng14'),('Same, day 60 (%)','S05-G','','ifng60'),
      ('Lung TRM CD69⁺CD103⁺ CD8, day 25 (%)','S05-I','','trm'),('MLN IFN-γ⁺ CD8, CA09 restim (%; day n.s.)','S14-A_H1N1','','ifngH1'),
      ('**Tfh / germinal centre**',None,None,None),
      ('ICOS-hi Tfh, day 7 (%)','S04-A_ICOShi','','tfh_hi'),('Tfr, day 7 (%)','S04-B_Tfr','','tfr7'),('Tfr, day 30 (%)','S04-C','','tfr30'),('GC B cells, day 7 (%)','S03-K','','gcb'),
      ('**Antibody (single dose, day 14)**',None,None,None),
      ('IgG anti-CA09 (GMT)','S03-A','','igg_ca'),('HAI anti-CA09 (GMT)','S03-C','','hai_ca'),('Neutralising anti-CA09 (GMT)','S03-D','','nt_ca'),
      ('IgG anti-Aichi (GMT)','S03-E','','igg_ai'),('HAI anti-Aichi (GMT)','S03-G','','hai_ai'),('Neutralising anti-Aichi (GMT)','S03-H','','nt_ai'),
      ('**Aged-lung milieu**',None,None,None),
      ('CD206⁺ macrophages (%; time n.s.)','S11-E','','cd206'),('Lung Treg, day 7 (%; n=3)','S04-D','','treg')]
    out=['| Readout | Block | Sham / vaccine | PSLN-212 aged | **PSLN-344 aged** | PSLN-212 young | PSLN-344 vs PSLN-212: effect (95% CI) | p (Welch; exact MWU) | Restoration fraction |',
         '|---|---|---|---|---|---|---|---|---|']
    for lab,b,k,id_ in rows:
        if b is None: out.append(f'| {lab} | | | | | | | | |'); continue
        c1=N[id_+'_c1']; USED.add(id_+'_c1')
        sh=gval(b,'Sham',k) if gval(b,'Sham',k)!='–' else gval(b,'PBS',k)
        unit='×' if (b in TITRE or 'fold' in lab or b=='S09-A_left') else ' pp'
        eff=f"{c1['eff']}{unit} ({c1['lo']} to {c1['hi']})" if unit=='×' else f"{'+' if not c1['eff'].startswith('-') else ''}{c1['eff']} pp ({c1['lo']} to {c1['hi']})"
        out.append(f"| {lab} | {b.replace('_',' ')} | {sh} | {gval(b,'PSLN-212',k)} | **{gval(b,'PSLN-344',k)}** | {gval(b,'PSLN-212(Y)',k)} | {eff} | {c1['p']}; {c1['pm']} | {c1['rf']} |")
    return '\n'.join(out)
def table2():
    blocks=[('S03-I','Bivalent → CA09 10×LD50 (homologous), d14'),('S06-A','Aichi H3N2 → PR8 H1N1, d14'),('S06-B','Aichi H3N2 → PR8 H1N1, d3'),
            ('S06-C','Bivalent → rgH5N1, d14'),('S06-D','Bivalent → rgH5N1, d3'),('S06-E','Aichi H3N2 → PR8 H1N1, d60'),('S06-F','Bivalent → rgH5N1, d60'),
            ('S06-G','CA09 H1N1 → Perth H3N2, d60'),('S03-J','rgH5N1 vacc → WT VN04 H5N1, d2 (age n.s.)'),('S15-L','C57BL/6, bivalent (challenge n.s.)'),('S15-N','Swiss Webster, bivalent (challenge n.s.)')]
    out=['| Block | Vaccine → challenge, timing | Sham | PSLN-212 | **PSLN-344** | PSLN-212 young | Untreated (no challenge) | 344 vs 212: Fisher p; log-rank p | Integrity |',
         '|---|---|---|---|---|---|---|---|---|']
    for b,lab in blocks:
        d=SG[SG.block==b]
        def s(g):
            x=d[d.group==g]
            return f"{int(x.survivors.iloc[0])}/{int(x.n.iloc[0])}" if len(x) else '–'
        p=SP[(SP.block==b)&(SP.A=='PSLN-344')&(SP.B=='PSLN-212')].iloc[0]
        USED.add('sv_'+b)
        out.append(f"| {b} | {lab} | {s('Sham')} | {s('PSLN-212')} | **{s('PSLN-344')}** | {s('PSLN-212(Y)')} | {s('Untreated')} | {pfmt(p.p_fisher)}; {pfmt(p.p_logrank)} | {d.integrity.iloc[0]} |")
    return '\n'.join(out)
def table_audit(short=True):
    if short:
        out=['| ID | Severity | Finding (blocks) | Headline evidence | Consequence |','|---|---|---|---|---|']
        for _,r in A.iterrows():
            out.append(f"| {r.id} | {r.severity} | {r.finding} ({r.blocks}) | {r.headline} | {r.impact} |")
    else:
        out=[]
        for _,r in A.iterrows():
            out.append(f"**{r.id} ({r.severity}): {r.finding}** Blocks: {r.blocks}.\n\n*Evidence.* {r.evidence}\n\n*Consequence.* {r.impact} *Resolution:* {r.resolution}\n")
    return '\n'.join(out)
def sub(m):
    key=m.group(1); field=m.group(2)
    USED.add(key)
    v=N[key]
    return str(v[field]) if isinstance(v,dict) else str(v)
def render(template_path,out_path):
    t=open(template_path).read()
    t=t.replace('{{LEDGER_N}}',str(len(pd.read_csv(W+'ledger_numbers.csv')))).replace('{{TABLE1}}',table1()).replace('{{TABLE2}}',table2()).replace('{{TABLE_AUDIT}}',table_audit(True)).replace('{{AUDIT_FULL}}',table_audit(False))
    t=re.sub(r'\{\{([A-Za-z0-9_\-\'\(\)]+)\.([A-Za-z0-9_]+)\}\}',sub,t)
    left=re.findall(r'\{\{[^}]+\}\}',t)
    if left: raise SystemExit(f'unrendered placeholders: {left[:5]}')
    open(out_path,'w').write(t)
    json.dump(sorted(USED),open(W+'used_ids.json','w'))
    return t
if __name__=='__main__':
    import sys
    render(sys.argv[1],sys.argv[2]); print('rendered',len(USED),'ids used')

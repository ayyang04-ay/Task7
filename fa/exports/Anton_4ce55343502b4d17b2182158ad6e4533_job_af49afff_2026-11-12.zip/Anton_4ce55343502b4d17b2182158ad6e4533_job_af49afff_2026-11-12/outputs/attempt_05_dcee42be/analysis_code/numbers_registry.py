import pandas as pd, numpy as np, json
W='/tmp/work/'
C=pd.read_csv(W+'contrasts.csv',keep_default_na=False,na_values=['']); C['key']=C['key'].fillna('').astype(str)
E=pd.read_csv(W+'extra_contrasts.csv',keep_default_na=False,na_values=['']); E['key']=E['key'].fillna('').astype(str)
GS=pd.read_csv(W+'group_summaries.csv',keep_default_na=False,na_values=['']); GS['key']=GS['key'].fillna('').astype(str)
SG=pd.read_csv(W+'survival_groups.csv'); SP=pd.read_csv(W+'survival_pairs.csv'); SPo=pd.read_csv(W+'survival_pooled.csv')
REG={}
def cells(block,group,key=''):
    x=GS[(GS.block==block)&(GS.group==group)&(GS.key==key)]
    return x.cells.iloc[0] if len(x) else ''
def fmt(x,kind='auto'):
    if x is None or (isinstance(x,float) and np.isnan(x)): return 'n/a'
    if kind=='p':
        return '<0.001' if x<0.001 else f'{x:.3f}'
    if kind=='pct': return f'{x:.1f}'
    ax=abs(x)
    if ax>=1000: return f'{x:,.0f}'
    if ax>=100: return f'{x:.0f}'
    if ax>=10: return f'{x:.1f}'
    if ax>=1: return f'{x:.2f}'
    return f'{x:.3f}'
def reg(id_, text, value, blocks, cellref, reduction, n='', grade=''):
    REG[id_]=dict(id=id_,quantity=text,value=value,blocks=blocks,cells=cellref,n=n,reduction=reduction,integrity=grade)
    return value

RED={'log2':'per-animal values log2-transformed; group = geometric mean; contrast = ratio of geometric means with Welch 95% CI on log scale; p = Welch t (log scale) and exact Mann-Whitney',
     'linear':'group = arithmetic mean of per-animal values; contrast = difference of means with Welch 95% CI; p = Welch t and exact Mann-Whitney',
     'log10_given':'values supplied as log10 fold; group = 10^(mean of log10); contrast = ratio with Welch 95% CI; p = Welch t and exact Mann-Whitney',
     'titre':'per-animal titres log2-transformed (HAI values below LOD 1:10 set to 5); group = GMT; contrast = GMT ratio with Welch 95% CI; p = Welch t and exact Mann-Whitney'}
TITRE={'S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}

def contrast(id_, block, key, contrast_prefix, label, grade='no issue found'):
    r=C[(C.block==block)&(C.key==key)&(C.contrast.str.startswith(contrast_prefix))]
    if len(r)==0: raise KeyError((block,key,contrast_prefix))
    r=r.iloc[0]
    sc='titre' if block in TITRE else r['scale']
    eff_word = 'x' if r['scale']!='linear' else ' pp' if '%' in label else ''
    val=dict(A=fmt(r.A_summary),B=fmt(r.B_summary),eff=fmt(r.effect),lo=fmt(r.ci_lo),hi=fmt(r.ci_hi),p=fmt(r.p_welch,'p'),pm=fmt(r.p_mwu_exact,'p'),
             g=fmt(r.hedges_g),rf=fmt(r.restoration_fraction) if not np.isnan(r.restoration_fraction) else 'n/a',nA=int(r.nA),nB=int(r.nB),unit=eff_word)
    cl=f"{r.A}: {cells(block,r.A,key)}; {r.B}: {cells(block,r.B,key)}"
    rf_note='' if np.isnan(r.restoration_fraction) else f"; restoration fraction = (mean344 - mean212)/(mean212(Y) - mean212) on the analysis scale using {cells(block,'PSLN-212(Y)',key)} for 212(Y)"
    reg(id_, f'{label}: {r.A} vs {r.B}', val, block+(f' [{key}]' if key else ''), cl, RED[sc]+rf_note, n=f'{int(r.nA)} vs {int(r.nB)}', grade=grade)
    return val

def extra(id_, analysis_substr, label, grade='no issue found', B=None):
    r=E[E.analysis==analysis_substr]
    if len(r)==0: r=E[E.analysis.str.contains(analysis_substr,regex=False)]
    if B is not None: r=r[r.B==B]
    if len(r)==0: raise KeyError(analysis_substr)
    if len(r)>1 and len(set(zip(r.A,r.B)))>1: raise ValueError(f'ambiguous extra lookup {analysis_substr}: {list(zip(r.A,r.B))}')
    r=r.iloc[0]
    val=dict(A=fmt(r.A_summary),B=fmt(r.B_summary),eff=fmt(r.effect),lo=fmt(r.ci_lo),hi=fmt(r.ci_hi),p=fmt(r.p_welch,'p'),pm=fmt(r.p_mwu,'p'),nA=int(r.nA),nB=int(r.nB))
    cl=f"{r.A}: {r.A_cells}; {r.B}: {r.B_cells}" if isinstance(r.A_cells,str) and r.A_cells else r.block
    red=('ratio of geometric means, Welch 95% CI on log scale' if 'ratio' in str(r.effect_type) else 'difference of arithmetic means, Welch 95% CI')+'; p = Welch t / exact Mann-Whitney'
    reg(id_, label, val, r.block, cl, red+(f'; note: {r.note}' if isinstance(r.note,str) and r.note else ''), n=f'{int(r.nA)} vs {int(r.nB)}', grade=grade)
    return val

def surv_pair(id_, block, A, B, label, grade):
    r=SP[(SP.block==block)&(SP.A==A)&(SP.B==B)].iloc[0]
    ga=SG[(SG.block==block)&(SG.group==A)].iloc[0]; gb=SG[(SG.block==block)&(SG.group==B)].iloc[0]
    val=dict(A=f"{int(ga.survivors)}/{int(ga.n)}",B=f"{int(gb.survivors)}/{int(gb.n)}",rd=fmt(r.risk_diff_surv_pp),pf=fmt(r.p_fisher,'p'),pl=fmt(r.p_logrank,'p'))
    reg(id_, f'{label}: survivors {A} vs {B}', val, block, f'{A}: {ga.cells}; {B}: {gb.cells}',
        'survivors = rows with event code 0 at end of follow-up; Fisher exact (2-sided) on survivors/deaths; log-rank on time-to-event', n=f'{int(ga.n)} vs {int(gb.n)}', grade=grade)
    return val

def group(id_, block, g, key, label, grade='no issue found', geo=False):
    x=GS[(GS.block==block)&(GS.group==g)&(GS.key==key)].iloc[0]
    v=x.geo_mean if geo else x['mean']
    val=dict(v=fmt(v),sd=fmt(x.sd),n=int(x.n))
    reg(id_, f'{label} ({g})', val, block+(f' [{key}]' if key else ''), x.cells, ('geometric mean' if geo else 'arithmetic mean (SD)')+' of per-animal values', n=str(int(x.n)), grade=grade)
    return val

N={}
# ---------- core immunogenicity / innate / DC / T / B (C1 = 344 vs 212 aged; C3 = 344 vs 212(Y); C2 = vs sham) ----------
spec=[('ifnb16','S01-A_16h','','Ifnb1 lung 16 h (fold)'),('ifnb72','S01-A_72h','','Ifnb1 lung 72 h (fold)'),
      ('ccl2_16','S09-A_left','Ccl2','Ccl2 lung 16 h (fold)'),('ccl3_16','S09-A_left','Ccl3','Ccl3 lung 16 h (fold)'),('il6_16','S09-A_left','Il6','Il6 lung 16 h (fold)'),
      ('ccl5_16','S09-A_left','Ccl5','Ccl5 lung 16 h (fold)'),('tnf_16','S09-A_left','Tnf','Tnf lung 16 h (fold)'),('il10_16','S09-A_left','Il10','Il10 lung 16 h (fold)'),
      ('gmcsf16','S02-F','16h','Gm-csf lung 16 h (fold)'),('gmcsf36','S02-F','36h','Gm-csf lung 36 h (fold)'),('gmcsf72','S02-F','72h','Gm-csf lung 72 h (fold)'),
      ('mono_d4','S01-D','d4','Lung monocytes day 4 (%)'),('mono_d8','S01-D','d8','Lung monocytes day 8 (%)'),('cd11bdc_d4','S01-E','d4','Lung CD11b+ DC day 4 (%)'),
      ('cdc1','S01-F','','Lung cDC1 72 h (%)'),('migdc','S02-A','','Lung migratory CCR7+ CD11b+ DC 72 h (%)'),('mlndc','S02-B','','MLN CD11b+CD103- DC 72 h (%)'),
      ('agdc','S02-C','','MLN DC carrying AF647-OVA 36 h (%)'),('cd40','S02-D_CD40','','CD40+ of MLN CD11b+ DC day 3 (%)'),('cd86','S02-D_CD86','','CD86+ of MLN CD11b+ DC day 3 (%)'),
      ('oti_dc','S02-E','','OT-I proliferation driven by sorted MLN CD11b+ DC (%)'),
      ('ki67','S05-D','','Lung Ki-67+ CD8 day 3 (%)'),('gzmb3','S05-E','','Lung GZMB+ CD8 day 3 (%)'),('ifng14','S05-F','','MLN IFN-g+ CD8, rgH5N1 restim, day 14 (%)'),
      ('ifng60','S05-G','','MLN IFN-g+ CD8, rgH5N1 restim, day 60 (%)'),('gzmb60','S05-H','','MLN GZMB+ CD8 day 60 (%)'),('trm','S05-I','','Lung TRM CD69+CD103+ CD8 day 25 (%)'),
      ('ifngH1','S14-A_H1N1','','MLN IFN-g+ CD8, CA09 restim (%)'),('ifngH3','S14-A_H3N2','','MLN IFN-g+ CD8, Aichi restim (%)'),
      ('tfh_hi','S04-A_ICOShi','','MLN ICOS-hi Tfh day 7 (%)'),('tfh_lo','S04-A_ICOSlo','','MLN ICOS-lo Tfh day 7 (%)'),('tfr7','S04-B_Tfr','','MLN Tfr day 7 (%)'),('tfr30','S04-C','','MLN Tfr day 30 (%)'),
      ('gcb','S03-K','','MLN GC B cells day 7 (%)'),('aicda','S03-L_Aicda','','Aicda in MLN B cells day 5 (fold)'),('e47','S03-L_E47','','E47 in MLN B cells day 5 (fold)'),
      ('igg_ca','S03-A','','Serum IgG anti-CA09 day 14 (GMT)'),('hai_ca','S03-C','','HAI anti-CA09 day 14 (GMT)'),('nt_ca','S03-D','','Neutralising titre anti-CA09 day 14 (GMT)'),
      ('igg_ai','S03-E','','Serum IgG anti-Aichi day 14 (GMT)'),('hai_ai','S03-G','','HAI anti-Aichi day 14 (GMT)'),('nt_ai','S03-H','','Neutralising titre anti-Aichi day 14 (GMT)'),
      ('igg2a_ca','S13-A','','Serum IgG2a anti-CA09 day 14 (GMT)'),('igg1_ca','S13-B','','Serum IgG1 anti-CA09 day 14 (GMT)'),
      ('igg_ca28','S13-I','','Serum IgG anti-CA09 day 28 after boost (GMT)'),('igg_ai28','S13-J','','Serum IgG anti-Aichi day 28 after boost (GMT)'),
      ('mlnigg','S13-H','','IgG+ of MLN B220+ cells (%)'),('cd206','S11-E','','Lung CD206+ macrophages (%) [timepoint not stated]'),('treg','S04-D','','Lung Treg day 7 (%)')]
for id_,b,k,lab in spec:
    N[id_+'_c1']=contrast(id_+'_c1',b,k,'C1',lab)
    try: N[id_+'_c3']=contrast(id_+'_c3',b,k,'C3',lab)
    except KeyError: pass
    try: N[id_+'_c2']=contrast(id_+'_c2',b,k,'C2',lab)
    except KeyError: pass
    try: N[id_+'_c4']=contrast(id_+'_c4',b,k,'C4',lab)
    except KeyError: pass
    try: N[id_+'_c5']=contrast(id_+'_c5',b,k,'C5',lab)
    except KeyError: pass
# dose response S08-A
for d in ['dose5','dose10','dose20','dose40']:
    N['s08a_'+d]=contrast('s08a_'+d,'S08-A',d,'C1',f'Ifnb1 16 h dose-response at {d[4:]} ug (fold)',grade='age not stated')
for g in ['PSLN-212','PSLN-344','CMP-204','PSLN-344/R848']:
    for d in ['dose10','dose20','dose40']:
        N[f's08a_{g}_{d}']=group(f's08a_{g}_{d}','S08-A',g,d,f'Ifnb1 16 h at {d[4:]} ug',geo=True,grade='age not stated')
# extra contrasts
ex=[('r_ca','IgG2a/IgG1 ratio CA09, recomputed','IgG2a/IgG1 (CA09) recomputed per animal from S13-A/S13-B titres: PSLN-344 vs PSLN-212'),
    ('r_ai','IgG2a/IgG1 ratio Aichi, recomputed','IgG2a/IgG1 (Aichi) recomputed per animal from S13-C/S13-D titres: PSLN-344 vs PSLN-212'),
    ('ccr2_mono','CCR2 antagonist: lung monocytes','INCB3344 vs vehicle, lung monocytes (PSLN-344)'),('ccr2_mac','CCR2 antagonist: lung Ly6C+ macrophages','INCB3344 vs vehicle, lung Ly6C+ macrophages (PSLN-344)'),
    ('ccr2_gzmb','CCR2 antagonist: lung GZMB+ CD8 (young)','INCB3344 vs vehicle, lung GZMB+ CD8, YOUNG (PSLN-344(Y))'),('cbx','Gap-junction blocker CBX','Carbenoxolone vs saline, recruited lung monocytes day 3 (aged, PSLN-344)'),
    ('ifnar_nocdc','IFNAR-/- BM: donor moDC (no cDC','Ifnar-/- vs WT donor BM (cDC precursors removed): donor moDC day 3'),('ifnar_cdc','IFNAR-/- BM: donor moDC (with cDC','Ifnar-/- vs WT donor BM (with cDC precursors): donor moDC'),
    ('gmcsf_rescue','IFNAR-/- BM + GM-CSF vs IFNAR-/- BM','Ifnar-/- BM + i.t. GM-CSF vs Ifnar-/- BM: donor moDC'),('ifnar_mono','IFNAR-/- BM: monocyte infiltration','Ifnar-/- vs WT BM: donor monocyte infiltration (young, n=3)'),
    ('gm_212','GM-CSF added to PSLN-212','PSLN-212 + GM-CSF vs PSLN-212: moDC-like cells day 5'),('ptx_ag','PTX: MLN DCs carrying antigen','Pertussis toxin arm vs PSLN-344: antigen+ MLN DC'),
    ('ptx_oti','PTX: DC-driven OT-I','Pertussis toxin arm vs PSLN-344: DC-driven OT-I proliferation'),('ptx_mln','PTX: OT-I proliferation in MLN','PTX vs PBS: OT-I proliferation in MLN (PSLN-344 + OVA)'),
    ('ptx_lung','PTX: OT-I proliferation in lung','PTX vs PBS: OT-I proliferation in lung (PSLN-344 + OVA)'),('spad','SP-A/D knockout','Sftpa1/Sftpd KO vs WT: DiD+ alveolar macrophages'),
    ('srb','PSLN-SRB vs free SRB','PSLN-SRB vs free SRB: SRB+ AECII'),('s08c','PSLN-344-SRB vs PSLN-SRB','PSLN-344-SRB vs PSLN-SRB: SRB+ AECII (S08-C; flagged)'),
    ('ee','Encapsulation efficiency','Encapsulation efficiency PSLN-344 vs PSLN-212 (%)'),
    ('cns_ifnb_pbs','CNS Ifnb1: PSLN-344 vs PBS','CNS Ifnb1 36 h, PSLN-344 vs PBS'),('cns_tnf_pbs','CNS Tnf: PSLN-344 vs PBS','CNS Tnf 36 h, PSLN-344 vs PBS'),('cns_tnf_sham','CNS Tnf: PSLN-344 vs Sham','CNS Tnf 36 h, PSLN-344 vs Sham'),
    ('cns_isg_pbs','CNS Isg15: PSLN-344 vs PBS','CNS Isg15 36 h, PSLN-344 vs PBS'),('cns_ct_ifnb','CNS Ifnb1: cholera toxin vs PBS','CNS Ifnb1 36 h, cholera toxin vs PBS'),
    ('cns_ct_tnf','CNS Tnf: cholera toxin vs PBS','CNS Tnf 36 h, cholera toxin vs PBS'),('cns_ct_isg','CNS Isg15: cholera toxin vs PBS','CNS Isg15 36 h, cholera toxin vs PBS'),
    ('ifnb72_vsY','Ifnb1 72h: 344 aged vs 212(Y)','Ifnb1 72 h: PSLN-344 aged vs PSLN-212 young'),('ifnb72_212vsY','Ifnb1 72h: 212 aged vs 212(Y)','Ifnb1 72 h: PSLN-212 aged vs PSLN-212 young'),
    ('tnf72_vsY','Tnf 72 h (block labelled 16 h): PSLN-344 vs PSLN-212(Y)','Tnf 72 h: PSLN-344 aged vs PSLN-212 young'),('tnf72_vs212','Tnf 72 h (block labelled 16 h): PSLN-344 vs PSLN-212','Tnf 72 h: PSLN-344 vs PSLN-212 (aged)'),
    ('tnf72_212vsY','Tnf 72 h (block labelled 16 h): PSLN-212 vs PSLN-212(Y)','Tnf 72 h: PSLN-212 aged vs young'),
    ('il10_72_vsY','Il10 72 h (block labelled 16 h): PSLN-344 vs PSLN-212(Y)','Il10 72 h: PSLN-344 aged vs PSLN-212 young'),('il10_72_212vsY','Il10 72 h (block labelled 16 h): PSLN-212 vs PSLN-212(Y)','Il10 72 h: PSLN-212 aged vs young'),
    ('il6_72_vs212','Il6 72 h (block labelled 16 h): PSLN-344 vs PSLN-212','Il6 72 h: PSLN-344 vs PSLN-212 (aged)'),('ccl2_72_vs212','Ccl2 72 h (block labelled 16 h): PSLN-344 vs PSLN-212','Ccl2 72 h: PSLN-344 vs PSLN-212 (aged)'),
    ('ccl2_72_vsY','Ccl2 72 h (block labelled 16 h): PSLN-344 vs PSLN-212(Y)','Ccl2 72 h: PSLN-344 aged vs PSLN-212 young'),
    ('nadir_344','nadir (d2-d10): PSLN-344 vs vaccine','Post-immunisation weight nadir: PSLN-344 vs vaccine alone (% of d0)'),
    ('nadir_r848','nadir (d2-d10): PSLN-212/R848 vs vaccine','Post-immunisation weight nadir: PSLN-212/R848 vs vaccine alone (% of d0)'),
    ('nadir_212','nadir (d2-d10): PSLN-212 vs vaccine','Post-immunisation weight nadir: PSLN-212 vs vaccine alone (% of d0)')]
BFILT={'r_ca':'PSLN-212','r_ai':'PSLN-212'}
for id_,sub,lab in ex:
    g='S08-D companion-copy flag (CMP-204 column)' if id_.startswith('nadir') else ('flagged block' if id_=='s08c' else 'no issue found')
    N[id_]=extra(id_,sub,lab,grade=g,B=BFILT.get(id_))
# ---------- survival ----------
grades={'S03-I':'major','S03-J':'major','S06-A':'moderate','S06-B':'minor','S06-C':'moderate','S06-D':'major','S06-E':'moderate','S06-F':'moderate','S06-G':'major',
        "S06-E'(imprint)":'moderate',"S06-F'(imprint)":'minor','S15-H':'major','S15-L':'major','S15-N':'major','S09-B':'minor','S09-D':'minor','S09-F':'moderate','S13-E':'minor'}
for b in ['S03-I','S06-A','S06-B','S06-C','S06-D','S06-E','S06-F','S06-G','S15-L','S15-N','S03-J']:
    N['sv_'+b]=surv_pair('sv_'+b,b,'PSLN-344','PSLN-212','Challenge survival',grades[b])
N['sv_S06-G_untr']=surv_pair('sv_S06-G_untr','S06-G','PSLN-344','Untreated','Challenge survival vs unchallenged controls',grades['S06-G'])
N['sv_S06-E_untr']=surv_pair('sv_S06-E_untr','S06-E','PSLN-344','Untreated','Challenge survival vs unchallenged controls',grades['S06-E'])
N['sv_S15H_v']=surv_pair('sv_S15H_v','S15-H','3d Vaccine+PSLN-344','3d Vaccine','Day-3 challenge',grades['S15-H'])
N['sv_S15H_a']=surv_pair('sv_S15H_a','S15-H','3d Vaccine+PSLN-344','3d PSLN-344','Day-3 challenge',grades['S15-H'])
N['sv_impE_n']=surv_pair('sv_impE_n',"S06-E'(imprint)",'Naive+PSLN-344','Naive+PSLN-212','Imprinting study, PR8 challenge (naive)',grades["S06-E'(imprint)"])
N['sv_impE_i']=surv_pair('sv_impE_i',"S06-E'(imprint)",'Imprinting+PSLN-344','Imprinting+PSLN-212','Imprinting study, PR8 challenge (imprinted)',grades["S06-E'(imprint)"])
N['sv_impF_n']=surv_pair('sv_impF_n',"S06-F'(imprint)",'Naive+PSLN-344','Naive+PSLN-212','Imprinting study, Perth challenge (naive)',grades["S06-F'(imprint)"])
N['sv_impF_i']=surv_pair('sv_impF_i',"S06-F'(imprint)",'Imprinting+PSLN-344','Imprinting+PSLN-212','Imprinting study, Perth challenge (imprinted)',grades["S06-F'(imprint)"])
for b in ['S09-B','S09-D','S09-F']:
    N['svY_'+b]=surv_pair('svY_'+b,b,'PSLN-344(Y)','PSLN-212(Y)','Young-animal challenge',grades[b])
N['svY_S13E']=surv_pair('svY_S13E','S13-E','CMP-204(Y)','Sham','Young-animal homologous challenge',grades['S13-E'])
N['sv_cmp_S03I']=surv_pair('sv_cmp_S03I','S03-I','CMP-204','PSLN-212','Homologous challenge',grades['S03-I'])
for i,r in SPo.iterrows():
    key='pool_'+'ABCD'[i]
    N[key]=reg(key,'Pooled survival PSLN-344 vs PSLN-212 (aged): '+r.analysis,
        dict(A=r.A_survivors,Ap=fmt(r.A_surv_pct),B=r.B_survivors,Bp=fmt(r.B_surv_pct),OR=fmt(r.MH_OR_survival),ORci=r.MH_OR_CI,p=fmt(r.CMH_p,'p'),pp=fmt(r.perm_p_conditional,'p')),
        r.blocks,'per-block PSLN-344 and PSLN-212 survival columns (see survival_groups sheet)',
        'stratified by block; Mantel-Haenszel odds ratio of survival (0.5 added to cells for OR estimate); CMH test with continuity correction; conditional permutation p (200,000 draws within strata)',
        grade='mixed')
json.dump(N,open(W+'numbers.json','w'),indent=1,default=str)
L=pd.DataFrame(REG.values()); L['value']=L['value'].astype(str); L.to_csv(W+'ledger_numbers.csv',index=False)
print(len(REG),'ledger entries')

# ---------- additional registry entries: pooled risk differences, audit counts, RF summary, power ----------
from statsmodels.stats.proportion import confint_proportions_2indep
for key,(a,n1,b,n2,lab,blocks) in {'rd_A':(46,56,6,56,'as printed, 8 aged BALB/c blocks','S03-I,S06-A..G'),
                                   'rd_C':(28,35,4,35,'excluding blocks graded major','S06-A,S06-B,S06-C,S06-E,S06-F'),
                                   'rd_D':(5,7,0,7,'S06-B only (only block graded minor)','S06-B')}.items():
    lo,hi=confint_proportions_2indep(a,n1,b,n2,method='newcomb',compare='diff')
    N[key]=reg(key,f'Pooled survival risk difference PSLN-344 minus PSLN-212 ({lab})',dict(rd=f'{100*(a/n1-b/n2):.1f}',lo=f'{100*lo:.1f}',hi=f'{100*hi:.1f}',a=f'{a}/{n1}',b=f'{b}/{n2}'),
               blocks,'PSLN-344 and PSLN-212 survival columns of each block','pooled survivors/n; risk difference with Newcombe hybrid-score 95% CI (unstratified; stratified OR reported separately)',grade='mixed')
F1=pd.read_csv(W+'fig1_data.csv'); rf=F1.rf.dropna()
N['rf_summary']=reg('rf_summary','Restoration fraction across readouts with a young benchmark',dict(n=str(len(rf)),median=f'{rf.median():.2f}',q1=f'{rf.quantile(.25):.2f}',q3=f'{rf.quantile(.75):.2f}',ge50=str(int((rf>=0.5).sum())),mn=f'{rf.min():.2f}',mx=f'{rf.max():.2f}'),
    ', '.join(F1.block),'see per-readout entries','RF = (mean344 - mean212)/(mean212(Y) - mean212) on analysis scale (log2 for titres/folds, log10 for S09-A, raw for %); median and IQR across readouts',grade='no issue found')
N['aud']=reg('aud','Audit counts',dict(pairs4='18',pairs3='27',null_pairs='131,784',null4='0',null3='0-2',s11='35/100',s11cols='34/40',s11null='0/100 and 1/100',untr='4/21',untrG='3/7',hai_pos='17/25',nt_pos='8/25'),
    'weight blocks (S08-D, S09-C/E/G, S13-F/G, S15-A..O); S11-A/B/D; S06-E/F/G Untreated',
    'all per-animal cells of the listed blocks',
    'weights: all pairs of animal trajectories from different block/group combinations; "informative" = value differs from the same animal\'s previous-day value; null = same scan with days shifted by +/-2 and +/-4; S11 and all immunology block pairs: same group/day/animal-column position compared (hai_pos = S03-C vs S03-G, nt_pos = S03-D vs S03-H) (scripts audit_dups2.py, audit_survw.py)',grade='')
N['power']=reg('power','Sample size for confirmatory study',dict(n80_20_90='16',n80_20_80='12',n75_25_90='23',n70_30_90='37',n80_50_80='50',vt='15'),
    'design assumption','n/a','simulated Fisher exact power (20,000 draws, 2-sided alpha 0.05); lung titre: two-sample t, 1 log10 difference, SD 0.8 log10, 90% power',grade='')
REG['r_ca']['cells']='PSLN-344: IgG2a S13!B3:B7 / IgG1 S13!F3:F7; PSLN-212: IgG2a S13!A3:A7 / IgG1 S13!E3:E7 (ratio per animal, same row)'
REG['r_ai']['cells']='PSLN-344: IgG2a S13!J3:J7 / IgG1 S13!N3:N7; PSLN-212: IgG2a S13!I3:I7 / IgG1 S13!M3:M7 (ratio per animal, same row)'
json.dump(N,open(W+'numbers.json','w'),indent=1,default=str)
L=pd.DataFrame(REG.values()); L['value']=L['value'].astype(str); L.to_csv(W+'ledger_numbers.csv',index=False)
print(len(REG),'ledger entries (final)')

# R848 combination cytokines at 16 h (S09-A left) and CMP-204 Ifnb1 (S01-A)
for an in ['Tnf','Il10']:
    N[f'r848_{an}']=group(f'r848_{an}','S09-A_left','PSLN-212/R848',an,f'{an} lung 16 h (fold; 10^mean log10)',geo=True)
N['cmp_ifnb16']=group('cmp_ifnb16','S01-A_16h','CMP-204','','Ifnb1 lung 16 h (fold)',geo=True)
json.dump(N,open(W+'numbers.json','w'),indent=1,default=str)
L=pd.DataFrame(REG.values()); L['value']=L['value'].astype(str); L.to_csv(W+'ledger_numbers.csv',index=False)
print(len(REG),'ledger entries (final+)')

# Tukey (annotation's stated method) p-adj for PSLN-344 vs PSLN-212
T=pd.read_csv(W+'tukey.csv',keep_default_na=False,na_values=['']); T['key']=T['key'].fillna('').astype(str)
def tk(id_,block,key,label):
    r=T[(T.block==block)&(T.key==key)&(((T.group1=='PSLN-212')&(T.group2=='PSLN-344'))|((T.group1=='PSLN-344')&(T.group2=='PSLN-212')))].iloc[0]
    N[id_]=reg(id_,f'Tukey-adjusted p, PSLN-344 vs PSLN-212: {label}',dict(p=f"{r['p-adj']:.2f}",anova_p=f"{r.anova_p:.2g}"),block+(f' [{key}]' if key else ''),'all arms of the block (see Group_summaries)',
               'one-way ANOVA across all arms of the block (analysis scale as in Appendix A), Tukey HSD (statsmodels pairwise_tukeyhsd)',grade='')
tk('tk_cd40','S02-D_CD40','','CD40+ MLN CD11b+ DC'); tk('tk_tfr30','S04-C','','Tfr day 30'); tk('tk_ifnb72','S01-A_72h','','Ifnb1 72 h')
json.dump(N,open(W+'numbers.json','w'),indent=1,default=str)
L=pd.DataFrame(REG.values()); L['value']=L['value'].astype(str); L.to_csv(W+'ledger_numbers.csv',index=False)
print(len(REG),'ledger entries (with Tukey)')

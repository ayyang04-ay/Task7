import openpyxl, numpy as np, json
from openpyxl.utils import range_boundaries, get_column_letter
wb=openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx',data_only=True)
def rng(ref):
    sh,r=ref.split('!'); c1,r1,c2,r2=range_boundaries(r); ws=wb[sh]
    return np.array([ws.cell(row=i,column=j).value for i in range(r1,r2+1) for j in range(c1,c2+1)],dtype=float)
gm=lambda x: float(np.exp(np.mean(np.log(x))))
N=json.load(open('/tmp/work/numbers.json'))
checks=[]
def chk(name, mine, indep, tol=0.01):
    ok = abs(float(str(mine).replace(',',''))-indep)/max(abs(indep),1e-9) < tol
    checks.append((name, mine, round(indep,4), 'OK' if ok else 'MISMATCH'))
chk('S03-A GMT 344', N['igg_ca_c1']['A'], gm(rng('S03!D3:D7')))
chk('S03-A GMT 212', N['igg_ca_c1']['B'], gm(rng('S03!C3:C7')))
chk('S03-A ratio', N['igg_ca_c1']['eff'], gm(rng('S03!D3:D7'))/gm(rng('S03!C3:C7')))
h=rng('S03!N3:N7'); h2=rng('S03!M3:M7'); h=np.where(h<10,5,h); h2=np.where(h2<10,5,h2)
chk('S03-C HAI GMT 344', N['hai_ca_c1']['A'], gm(h)); chk('S03-C HAI GMT 212', N['hai_ca_c1']['B'], gm(h2))
chk('S05-F mean 344', N['ifng14_c1']['A'], rng('S05!C33:C37').mean()); chk('S05-F mean 212', N['ifng14_c1']['B'], rng('S05!B33:B37').mean())
chk('S01-A 16h GM 344', N['ifnb16_c1']['A'], gm(rng('S01!B8:F8'))); chk('S01-A 16h GM 212', N['ifnb16_c1']['B'], gm(rng('S01!B5:F5')))
chk('S01-A 16h GM 212Y', N['ifnb16_c3']['B'], gm(rng('S01!B9:F9')))
chk('S09-A Ccl2 16h 344 (10^mean)', N['ccl2_16_c1']['A'], 10**rng('S09!Q5:S5').mean()); chk('S09-A Ccl2 16h 212', N['ccl2_16_c1']['B'], 10**rng('S09!H5:J5').mean())
chk('S09 Tnf 72h 344', N['tnf72_vsY']['A'], 10**rng('S09!AN8:AP8').mean()); chk('S09 Tnf 72h 212Y', N['tnf72_vsY']['B'], 10**rng('S09!AQ8:AS8').mean())
chk('S09 Il10 72h 212Y', N['il10_72_vsY']['B'], 10**rng('S09!AQ9:AS9').mean())
chk('S02-E mean 344', N['oti_dc_c1']['A'], rng('S02!L10:L14').mean()); chk('S02-E mean 212', N['oti_dc_c1']['B'], rng('S02!K10:K14').mean())
chk('S02-F Gm-csf 36h ratio', N['gmcsf36_c1']['eff'], gm(rng('S02!B18:F18'))/gm(rng('S02!G18:K18')))
chk('S08-B EE 344', N['ee']['A'], rng('S08!M11:O11').mean()); chk('S08-B EE 212', N['ee']['B'], rng('S08!D11:F11').mean())
chk('S04-D Treg 344', N['treg_c1']['A'], rng('S04!C29:C31').mean())
chk('S10 CNS Tnf 344/PBS', N['cns_tnf_pbs']['eff'], gm(rng('S10!H3:H7'))/gm(rng('S10!F3:F7')))
# S08-D nadir d2-d10 per animal, PSLN-344 cols Q..U rows 22..26
nad=[min(rng(f'S08!{c}22:{c}26')) for c in 'QRSTU']; chk('S08-D nadir 344', N['nadir_344']['A'], float(np.mean(nad)))
nadv=[min(rng(f'S08!{c}22:{c}26')) for c in ['AA','AB','AC','AD','AE']]; chk('S08-D nadir vaccine', N['nadir_344']['B'], float(np.mean(nadv)))
# survival: S06-B PSLN-344 events J17:J23 ; PSLN-212 I10:I16
ev344=rng('S06!J17:J23'); ev212=rng('S06!I10:I16')
checks.append(('S06-B 344 survivors', N['sv_S06-B']['A'], f'{int((ev344==0).sum())}/7', 'OK' if N['sv_S06-B']['A']==f'{int((ev344==0).sum())}/7' else 'MISMATCH'))
checks.append(('S06-B 212 survivors', N['sv_S06-B']['B'], f'{int((ev212==0).sum())}/7', 'OK' if N['sv_S06-B']['B']==f'{int((ev212==0).sum())}/7' else 'MISMATCH'))
# pooled 46/56: PSLN-344 and PSLN-212 columns per block
pool344={'S03-I':'S03!E38:E44','S06-A':'S06!D17:D23','S06-B':'S06!J17:J23','S06-C':'S06!P17:P23','S06-D':'S06!D48:D54','S06-E':'S06!J48:J54','S06-F':'S06!P48:P54','S06-G':'S06!D85:D91'}
pool212={'S03-I':'S03!D31:D37','S06-A':'S06!C10:C16','S06-B':'S06!I10:I16','S06-C':'S06!O10:O16','S06-D':'S06!C41:C47','S06-E':'S06!I41:I47','S06-F':'S06!O41:O47','S06-G':'S06!C78:C84'}
s344=sum(int((rng(v)==0).sum()) for v in pool344.values()); s212=sum(int((rng(v)==0).sum()) for v in pool212.values())
checks.append(('pooled 344 survivors', N['pool_A']['A'], f'{s344}/56', 'OK' if N['pool_A']['A']==f'{s344}/56' else 'MISMATCH'))
checks.append(('pooled 212 survivors', N['pool_A']['B'], f'{s212}/56', 'OK' if N['pool_A']['B']==f'{s212}/56' else 'MISMATCH'))
# S11-A vs S11-B identical same-position cells
a=rng('S11!B3:U7'); b=rng('S11!B10:U14'); checks.append(('S11 identical cells', N['aud']['s11'], f'{int(np.isclose(a,b).sum())}/{a.size}', 'OK' if N['aud']['s11']==f'{int(np.isclose(a,b).sum())}/{a.size}' else 'MISMATCH'))
# untreated deaths
u=int(rng('S06!L62:L68').sum()+rng('S06!R62:R68').sum()+rng('S06!F99:F105').sum()); checks.append(('untreated deaths', N['aud']['untr'], f'{u}/21','OK' if N['aud']['untr']==f'{u}/21' else 'MISMATCH'))
for c in checks: print(c)
print('ALL OK' if all(c[3]=='OK' for c in checks) else 'SOME MISMATCH')

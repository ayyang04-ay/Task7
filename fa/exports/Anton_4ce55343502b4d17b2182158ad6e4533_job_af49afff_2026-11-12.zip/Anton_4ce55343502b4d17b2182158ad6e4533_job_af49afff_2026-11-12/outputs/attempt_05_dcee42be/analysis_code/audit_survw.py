import sys; sys.path.insert(0,'/tmp/work/lib')
import parse as P, pandas as pd, numpy as np
df=P.DF; sv=P.SV
def weight_fates(wb):
    d=df[df.block==wb].copy(); d['day']=d.key.str.replace('d','').astype(float)
    out=[]
    for (g,r),x in d.groupby(['group','rep']):
        x=x.sort_values('day'); days=list(x.day); vals=list(x.value)
        last=max(days)
        if last<14:
            fate='dead(blank)'; dd=last
        else:
            # LOCF: >=3 identical trailing values
            k=1
            while k<len(vals) and abs(vals[-1-k]-vals[-1])<1e-9: k+=1
            if (k>=3) or (k>=2 and vals[-1]<=90): fate='dead(LOCF)'; dd=days[-k]
            else: fate='alive'; dd=None
        out.append(dict(group=g,rep=r,fate=fate,last_informative_day=dd,d14=vals[-1] if last==14 else None,nadir=min(vals)))
    return pd.DataFrame(out)
pairs=[('S06-A','S15-A'),('S06-B','S15-B'),('S06-C','S15-C'),('S06-D','S15-D'),('S06-E','S15-E'),('S06-F','S15-F'),('S06-G','S15-G'),
       ('S15-H','S15-I'),("S06-E'(imprint)",'S15-J'),("S06-F'(imprint)",'S15-K'),('S15-L','S15-M'),('S15-N','S15-O'),
       ('S09-B','S09-C'),('S09-D','S09-E'),('S09-F','S09-G'),('S03-I','S13-F'),('S03-J','S13-G')]
rows=[]
for sb,wb in pairs:
    f=weight_fates(wb)
    s=sv[sv.block==sb]
    groups=sorted(set(f.group)|set(s.group))
    for g in groups:
        ss=s[s.group==g]; ff=f[f.group==g]
        sdeaths=int(ss.event.sum()) if len(ss) else None
        wdead=int((ff.fate!='alive').sum()) if len(ff) else None
        sdays=sorted(ss[ss.event==1].time.astype(int).tolist()) if len(ss) else None
        wdays=sorted([int(x) for x in ff[ff.fate!='alive'].last_informative_day.tolist()]) if len(ff) else None
        rows.append(dict(survival_block=sb,weight_block=wb,group=g,n_surv=len(ss) if len(ss) else None,deaths_surv=sdeaths,
                         death_days_surv=sdays,n_weight=len(ff) if len(ff) else None,deaths_by_weight=wdead,
                         last_weight_day_of_dead=wdays,
                         consistent=(sdeaths==wdead) if (sdeaths is not None and wdead is not None) else 'group missing in one block'))
R=pd.DataFrame(rows)
R.to_csv('/tmp/work/surv_vs_weight.csv',index=False)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',60)
print(R.to_string())

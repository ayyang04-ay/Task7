import sys; sys.path.insert(0,'/tmp/work/lib')
import pandas as pd, json, numpy as np
import parse as P
W='/tmp/work/'
used=set(json.load(open(W+'used_ids.json')))
L=pd.read_csv(W+'ledger_numbers.csv'); L.insert(1,'cited_in_memo',L.id.isin(used))
# ---- block register ----
BL=P.BL.copy()
obs=P.DF.groupby('block').apply(lambda d: ', '.join(f"{g}:{n}" for g,n in d.groupby('group').rep.nunique().items())).rename('observed_n_per_group')
sv=P.SV.groupby('block').apply(lambda d: ', '.join(f"{g}:{len(x)}" for g,x in d.groupby('group'))).rename('observed_n_per_group')
obs=pd.concat([obs,sv])
BL=BL.join(obs)
grade={}; use={}
excluded={'S05-A':'A10','S05-B':'A10','S07-C':'A9','S08-C':'A6','S11-A':'A5','S11-B':'A5'}
for b in BL.index:
    grade[b]='no issue found'; use[b]='supporting'
for b,a in excluded.items(): grade[b]=f'excluded ({a})'; use[b]='excluded'
for b in ['S03-B','S03-F']: grade[b]='labels rotated (A7); replaced by S13-derived ratio'; use[b]='replaced'
grade['S09-A_right']='mislabelled 16 h; is 72 h (A8)'; use['S09-A_right']='Section 4 (72 h persistence)'
grade['S04-B_TfhTfr']='derived from S04-B Tfr (A11)'; use['S04-B_TfhTfr']='not counted'
grade['S01-G']='complement of S01-F (A11)'; use['S01-G']='not counted separately'
for b in ['S01-A_16h','S01-A_72h','S01-D','S01-F','S02-A','S02-B','S02-C','S02-D_CD40','S02-D_CD86','S02-E','S02-F','S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S03-K',
          'S04-A_ICOShi','S04-A_ICOSlo','S04-B_Tfr','S04-C','S04-D','S05-D','S05-E','S05-F','S05-G','S05-H','S05-I','S09-A_left','S11-E','S13-A','S13-B','S13-C','S13-D','S13-H','S13-I','S13-J','S14-A_H1N1','S14-A_H3N2']:
    use[b]='Table 1 / Fig. 1 (immunogenicity)'
for b in ['S02-G','S02-H','S02-I','S07-A','S07-B_mono','S07-B_LyMac','S11-C','S12-A','S05-C','S01-B','S01-C','S08-A','S08-B','S03-L_Aicda','S03-L_E47','S01-E']:
    use[b]='Section 5 (mechanism)'
for b in ['S10-A_Ifnb1','S10-A_Tnf','S10-A_Isg15']: use[b]='Section 2.3 (CNS safety)'
use['S08-D']='Section 2.3 (tolerability)'; grade['S08-D']='CMP-204 column offset-copied into S15-F (A1)'
sgr={'S03-I':'major (A3)','S03-J':'major (A3, A13)','S06-A':'moderate (A1, A2)','S06-B':'minor','S06-C':'moderate (A1, A3, A13)','S06-D':'major (A3, A13)','S06-E':'moderate (A3, A4)',
     'S06-F':'moderate (A1)','S06-G':'major (A3, A4)',"S06-E'(imprint)":'moderate (A1)',"S06-F'(imprint)":'minor','S15-H':'major (A1: protected group weights copied)','S15-L':'major (A1, A2, A14)','S15-N':'major (A2, A14)',
     'S09-B':'minor (A13)','S09-D':'minor','S09-F':'moderate (A3, A13)','S13-E':'minor (A13)'}
for b,g in sgr.items(): grade[b]=g; use[b]='Table 2 / Fig. 2 (protection)' if not b.startswith(('S09','S13')) else 'Section 2.2 (young animals)'
wgr={'S15-A':'A1/A2 (copies with S15-M, S15-J)','S15-B':'consistent with S06-B','S15-C':'A1 (copied into S15-I; shares with S09-E)','S15-D':'A3 (contradicts S06-D)','S15-E':'A3 (count mismatch)',
     'S15-F':'A1 (offset copy of S08-D)','S15-G':'A3 (contradicts S06-G)','S15-I':'A1 (copy of S15-C)','S15-J':'A1 (offset copies)','S15-K':'consistent with S06-F\'','S15-M':'A1/A2 (copies)','S15-O':'A2 (template)',
     'S09-C':'A1 (d12 row duplicated between groups)','S09-E':'A1 (copied into S15-M, S09-G)','S09-G':'A1','S13-F':'A3 (contradicts S03-I)','S13-G':'A3 (contradicts S03-J)'}
for b,g in wgr.items(): grade[b]=g; use[b]='audit only (animal fate reconstruction)'
BL['integrity_grade']=pd.Series(grade); BL['used_for']=pd.Series(use)
BL=BL.reset_index(drop=True)
# ---- write ----
sheets={
 'README':pd.DataFrame({'item':['Purpose','Source files','Citation format','Ledger','Reductions','Integrity grades','Code'],
   'text':['Evidence ledger for the PSLN-344 portfolio recommendation. Every number in the memo has an ID here with its worksheet cells, n and reduction.',
           'adjuvant_program_dataset.xlsx (15 sheets; parsed into 107 blocks) and adjuvant_program_annotation.pdf',
           'Sheet!Cell, e.g. S06!J17:J23. Block IDs follow the workbook; sub-blocks are suffixed (e.g. S01-A_16h, S09-A_left/right). The second S06-E/S06-F blocks (rows 71-98) are named S06-E\'(imprint) and S06-F\'(imprint).',
           "Sheet 'Ledger': one row per quantity; 'cited_in_memo' marks those used in the memo text or tables. Values are dictionaries: A = PSLN-344 (or first-named group), B = comparator, eff = effect, lo/hi = 95% CI, p = Welch, pm = exact Mann-Whitney, g = Hedges' g, rf = restoration fraction.",
           'Titres: log2 (HAI 0 -> 5, below 1:10 LOD), GMT and GMT ratios; qPCR folds and ratios: log scale; S09-A supplied as log10; percentages: arithmetic means and differences; Welch 95% CIs. Survival: Fisher exact, log-rank, stratified Mantel-Haenszel / CMH, conditional permutation; Newcombe CIs for risk differences.',
           'See Audit_register and Block_register. Survival studies graded minor / moderate / major as defined in memo Appendix A.',
           'analysis_code/ folder next to this file; parse.py maps every block to exact cell ranges.']}),
 'Ledger':L,
 'Block_register':BL,
 'Audit_register':pd.read_csv(W+'audit_register.csv'),
 'Contrasts':pd.read_csv(W+'contrasts.csv'),
 'Extra_contrasts':pd.read_csv(W+'extra_contrasts.csv'),
 'Tukey':pd.read_csv(W+'tukey.csv'),
 'Group_summaries':pd.read_csv(W+'group_summaries.csv'),
 'Survival_groups':pd.read_csv(W+'survival_groups.csv'),
 'Survival_pairs':pd.read_csv(W+'survival_pairs.csv'),
 'Survival_pooled':pd.read_csv(W+'survival_pooled.csv'),
 'Survival_vs_weight':pd.read_csv(W+'surv_vs_weight.csv'),
 'Dup_weights':pd.read_csv(W+'dup_weight_strong.csv'),
 'Dup_nonweight_coincid':pd.read_csv(W+'dup_cont_pairs.csv'),
 'S08D_nadir':pd.read_csv(W+'s08d_nadir.csv'),
 'Tidy_observations':pd.read_csv(W+'tidy_observations.csv'),
 'Tidy_survival':pd.read_csv(W+'tidy_survival.csv'),
}
sheets['Dup_nonweight_coincid'].insert(0,'note','Shared 1-decimal values between unrelated vectors are expected by chance; only position-wise identity (S11-A vs S11-B) and S01-B vs S08-C were treated as findings.')
out='/tmp/outputs/PSLN-344_evidence_ledger.xlsx'
with pd.ExcelWriter(out,engine='openpyxl') as xw:
    for name,df in sheets.items():
        df.to_excel(xw,sheet_name=name[:31],index=False)
# formatting: widths, freeze panes, wrap
import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
wb=openpyxl.load_workbook(out)
for ws in wb.worksheets:
    ws.freeze_panes='A2'
    for c in ws[1]: c.font=Font(bold=True); c.fill=PatternFill('solid',fgColor='DDEBF7')
    for col in ws.columns:
        letter=col[0].column_letter
        maxlen=max((len(str(c.value)) if c.value is not None else 0) for c in col[:200])
        ws.column_dimensions[letter].width=min(max(10,maxlen*0.9),70)
    if ws.title in ('README','Ledger','Audit_register','Block_register'):
        for row in ws.iter_rows(min_row=2):
            for c in row: c.alignment=Alignment(wrap_text=True,vertical='top')
wb.save(out)
print('ledger written', {k:len(v) for k,v in sheets.items()})

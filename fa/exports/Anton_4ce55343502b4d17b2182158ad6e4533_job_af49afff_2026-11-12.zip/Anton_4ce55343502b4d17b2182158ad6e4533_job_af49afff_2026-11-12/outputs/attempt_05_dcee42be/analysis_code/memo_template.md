# PSLN-344 — Portfolio Review: Recommendation, Evidence and Forward View

**Asset.** PSLN-344 is a Mn²⁺-coordinated, pulmonary-surfactant-biomimetic liposome (DPPC/DPPG/DPPE-PEG2000/cholesterol) encapsulating the STING agonist CDN-1807. It is an intranasal adjuvant for inactivated influenza A vaccine in older adults. Its internal comparator, PSLN-212, is the identical liposome without Mn²⁺.

**Evidence base.** Two files, used as the sole ground truth:
- `adjuvant_program_dataset.xlsx`: 15 sheets, parsed into 107 analysable blocks, 5,593 per-animal measurements and 514 animal-level survival records.
- `adjuvant_program_annotation.pdf`: 19 pp.

Where general scientific or regulatory knowledge is used, it is marked *external context*. No claim about PSLN-344 rests on it.

**How to check any number.**
- Each number names its block (e.g. S06-B). Key numbers also give worksheet cells (e.g. `S06!J17:J23`).
- `PSLN-344_evidence_ledger.xlsx` has one row per quantity ({{LEDGER_N}} in total): cells, n, the reduction applied and an integrity grade. It also holds the per-animal tidy data with cell addresses, every contrast, the survival analyses and the audit tables.
- Reductions and statistics are defined in Appendix A.
- "PSLN-212(Y)" / "young" = 7–8-week-old mice given the non-Mn formulation, the benchmark for what the adjuvant achieves without immunosenescence. All other groups are aged (≥20 months) unless stated.

---

## 1. Recommendation

**Do not advance PSLN-344 into IND-enabling development at this review.**

I do not recommend terminating it today either:
- Put it on hold and fund only a 4–6-week independent source-data audit (Gate 0).
- If Gate 0 fails, terminate.
- If Gate 0 passes, fund one pre-registered, blinded confirmatory study in aged mice (Gate 1, ~9 months) before any other spend.

**Reason 1 — If the data are genuine, the biology is strong.**

In aged mice, adding Mn²⁺ to the same liposome (single intranasal dose, bivalent inactivated vaccine, day 14) gives:

| Readout (block) | PSLN-344 | PSLN-212 | Effect (95% CI) |
|---|---|---|---|
| Serum IgG vs CA09, GMT (S03-A) | {{igg_ca_c1.A}} | {{igg_ca_c1.B}} | {{igg_ca_c1.eff}}× ({{igg_ca_c1.lo}}–{{igg_ca_c1.hi}}) |
| HAI vs CA09, GMT (S03-C) | {{hai_ca_c1.A}} | {{hai_ca_c1.B}} | {{hai_ca_c1.eff}}× ({{hai_ca_c1.lo}}–{{hai_ca_c1.hi}}) |
| Cross-reactive IFN-γ⁺ CD8 T cells, % (S05-F) | {{ifng14_c1.A}} | {{ifng14_c1.B}} | +{{ifng14_c1.eff}} pp ({{ifng14_c1.lo}}–{{ifng14_c1.hi}}) |

- Across {{rf_summary.n}} readouts that have a young benchmark, PSLN-344 closes a median {{rf_summary.median}} (IQR {{rf_summary.q1}}–{{rf_summary.q3}}) of the age-related deficit (Fig. 1).
- As printed, {{pool_A.A}} aged BALB/c mice survive challenge with PSLN-344 versus {{pool_A.B}} with PSLN-212, across eight studies. The risk difference is {{rd_A.rd}} percentage points (95% CI {{rd_A.lo}}–{{rd_A.hi}}).

**Reason 2 — The protection evidence, which is what an adjuvant decision rests on, cannot be certified.**

The challenge dataset contains four kinds of problem (Section 3):
- **Re-used weight data.** Body-weight trajectories recur across independent experiments. {{aud.pairs4}} animal pairs share ≥4 identical changing values, against {{aud.null4}} of {{aud.null_pairs}} pairs when the days are deliberately mis-aligned. There are also integer-offset copies of 5–8-decimal values.
- **Contradictory records.** Survival records contradict the weight records of the same animals.
- **A non-independent replication.** The "three-strain replication" re-uses one template.
- **Deaths without challenge.** Unchallenged, unvaccinated aged controls died ({{aud.untr}}; S06-E, S06-G).

These may be compilation errors, and no single one proves the effect is false. But an IND package cannot be built on them without the source records.

**Reason 3 — Even if the data are clean, three translational gaps block a clinical plan.**
- **Delivery.** The proposed mechanism is alveolar: uptake depends on surfactant proteins and alveolar epithelium (S01-B, S01-C). Mouse intranasal instillation delivers much of the dose to the lower airways, whereas a human nasal spray deposits in the nose (*external context*).
- **Inflammation.** In aged lungs given PSLN-344, Tnf and Il10 transcripts at 72 h are still {{tnf72_vsY.eff}}× and {{il10_72_vsY.eff}}× the young level (S09-A, 72 h panel). This is an ageing feature that Mn²⁺ does not correct (Fig. 4).
- **Manganese.** There are no data on Mn disposition, including olfactory or CNS exposure.

There is also no licensed-vaccine benchmark, no lung viral-load data, and every animal was female.

**What would change this recommendation.** Advance only if all three of the following hold:
1. Gate 0 traces every flagged item to a clerical cause and recovers the primary records.
2. Gate 1 reproduces a survival benefit over PSLN-212 of ≥40 percentage points in aged mice of both sexes and two strains, with ≥1 log₁₀ less lung virus than unadjuvanted vaccine.
3. Protection survives nasal-restricted delivery, or an inhaled product with acceptable lung safety is in view.

**What we drop if we stop (as printed).**
- The only formulation in our data that repairs aged-lung antigen presentation (monocyte → moDC differentiation, CD11b⁺ DC migration, CD8 priming).
- Heterosubtypic protection in aged animals that starts within 3 days and lasts to day 60.
- A candidate pharmacodynamic biomarker set (airway CCL2 / IFN-β / GM-CSF).

Whatever the decision, one mechanistic hypothesis should be kept as platform knowledge: the aged-lung bottleneck that Mn²⁺ relieves may be GM-CSF- and type-I-IFN-licensed monocyte → moDC differentiation (S02-G, S02-H; Sections 5–6).

**Answers to the committee's questions, by section.**

| Question | Short answer | Section |
|---|---|---|
| Do we advance? | No, not to IND-enabling. Hold for a 4–6-week source-data audit; terminate if it fails; otherwise one confirmatory aged-mouse study before re-presenting. | 1, 3 |
| What is driving protection? | Durable cross-subtype protection is most consistent with cross-reactive CD8 T-cell immunity (effector and lung-resident memory), primed through a Mn²⁺-restored monocyte → moDC / CD11b⁺ DC axis. An early day-2–3 phase needs antigen plus adjuvant, but its nature is unresolved. Antibody explains only the strain-matched result. Causality is untested. | 5 |
| Is there a biomarker of efficacy? | None established. Carry a two-tier hypothesis: an early airway PD panel (CCL2, IFN-β/ISG, GM-CSF with 72 h resolution) and the day-14 cross-reactive IFN-γ⁺ CD8 response as candidate efficacy correlate. | 6 |
| Could it go into patients, and in what role? | Not yet. If the gates are passed: a mucosal adjuvant with inactivated or split antigen for adults ≥65, for breadth and speed (pandemic/pre-pandemic use or add-on to licensed IM vaccine). The biomarkers can be measured in people: PD for dose selection, CD8 for early go/no-go. | 6, 7 |
| What must the next studies establish? | Data integrity; confirmed aged heterosubtypic protection with viral load in both sexes against PSLN-212 and a standard-of-care benchmark; the causal arm of immunity; deliverability and Mn/lung safety; biomarker linkage. | 8 |
| What was considered and ruled out? | 21 options and interpretations, with the evidence for each | 9 |

---

## 2. The strongest case for PSLN-344, as printed

### 2.1 Immunogenicity in aged animals

Table 1 compares PSLN-344 with PSLN-212 in aged BALB/c. The liposome and CDN-1807 are the same; only Mn²⁺ differs. The young benchmark is shown alongside.
- n = 5 per arm unless noted. Group values are geometric means for folds and titres and arithmetic means for percentages.
- Effects are ratios of geometric means (×) or differences in percentage points (pp).
- Restoration fraction = (PSLN-344 − PSLN-212) / (young − PSLN-212): 0 means no rescue of the aged deficit, 1 means the young level.
- Cells for every entry are in the ledger.

{{TABLE1}}

![Fig. 1](figures/fig1_immunogenicity_effects.png)

*Figure 1. Effect of Mn²⁺ in aged animals (A: Hedges' g, PSLN-344 vs PSLN-212; group values on the right) and the fraction of the aged deficit closed (B). Blocks in brackets.*

*Check under the annotation's stated method.* Using one-way ANOVA with Tukey across all arms of each block, the PSLN-344 vs PSLN-212 contrast stays significant for every Table 1 readout with three exceptions: CD40 (Tukey-adjusted p {{tk_cd40.p}}), day-30 Tfr ({{tk_tfr30.p}}) and 72 h Ifnb1 ({{tk_ifnb72.p}}). The memo does not rely on any of those three as a positive effect. All Tukey pairs are in the ledger (*Tukey* sheet).

*Note on Ifnb1 at 72 h.* In young animals IFN-β has resolved by 72 h, so the young value is the lower one. The negative restoration fraction means PSLN-344 moves *away* from the young profile at that timepoint (Section 4).

What the table shows:

**(a) Mn²⁺ corrects the aged innate defect rather than simply adding inflammation.**
- At 16 h, Ifnb1 rises from {{ifnb16_c1.B}}× to {{ifnb16_c1.A}}× (S01-A). That equals the young value ({{ifnb16_c3.B}}×; ratio {{ifnb16_c3.eff}}, 95% CI {{ifnb16_c3.lo}}–{{ifnb16_c3.hi}}).
- Downstream, Ccl2 rises {{ccl2_16_c1.eff}}× and Gm-csf {{gmcsf36_c1.eff}}× at 36 h.
- It is not a payload effect. PSLN-344 carries no more CDN-1807: encapsulation efficiency is {{ee.A}}% vs {{ee.B}}% (S08-B).
- It is dose-sparing. PSLN-344 at 10 µg ({{s08a_PSLN-344_dose10.v}}×) exceeds PSLN-212 at 40 µg ({{s08a_PSLN-212_dose40.v}}×) (S08-A; age not stated).

**(b) Antigen-presentation function recovers even where surface markers do not.**
- DC-driven OT-I proliferation rises from {{oti_dc_c1.B}}% to {{oti_dc_c1.A}}% (young {{oti_dc_c3.B}}%; S02-E).
- Yet CD40 and CD86 on MLN CD11b⁺ DC close only {{cd40_c1.rf}} and {{cd86_c1.rf}} of the deficit (S02-D).

**(c) Antibody quality improves.**
- Recomputed per animal from the primary subclass titres (S13-A–D), IgG2a/IgG1 rises {{r_ca.eff}}× against CA09 (95% CI {{r_ca.lo}}–{{r_ca.hi}}) and {{r_ai.eff}}× against Aichi ({{r_ai.lo}}–{{r_ai.hi}}). That is the young (Th1-type) ratio.
- The printed quotient blocks S03-B/S03-F say the opposite because their labels are rotated (finding A7).

**(d) Cellular memory is durable and cross-reactive.**
- IFN-γ⁺ CD8 T cells recalled by a heterologous virus (rgH5N1) are {{ifng60_c1.A}}% vs {{ifng60_c1.B}}% at day 60 (S05-G).
- Lung resident-memory CD8 (TRM) cells are {{trm_c1.A}}% vs {{trm_c1.B}}% at day 25 (S05-I).

**(e) In young animals Mn²⁺ adds little.** Ifnb1 rises only {{ifnb16_c5.eff}}× (S01-A), and survival is identical (Section 2.2). The value proposition is specific to older adults.

### 2.2 Protection, as printed (Table 2, Fig. 2)

Table 2. Aged-animal challenge studies, survivors/n at end of follow-up (14 days; S03-J 21 days). The integrity grade comes from the audit in Section 3.

{{TABLE2}}

![Fig. 2](figures/fig2_survival_by_block.png)

*Figure 2. Survival by study as printed, with the integrity grade of each study.*

**Pooled across the eight aged BALB/c studies, stratified by study:**

| Analysis | PSLN-344 survivors | PSLN-212 survivors | Mantel-Haenszel OR for survival | p |
|---|---|---|---|---|
| All eight studies | {{pool_A.A}} ({{pool_A.Ap}}%) | {{pool_A.B}} ({{pool_A.Bp}}%) | {{pool_A.OR}} | CMH {{pool_A.p}} |
| Excluding studies graded major | {{pool_C.A}} | {{pool_C.B}} | — | risk difference {{rd_C.rd}} pp (95% CI {{rd_C.lo}}–{{rd_C.hi}}) |
| Least-affected study only (S06-B) | {{sv_S06-B.A}} | {{sv_S06-B.B}} | — | Fisher {{sv_S06-B.pf}} |

The protection pattern, as printed, has four properties:
- **Heterosubtypic.** The vaccine and challenge viruses share neither HA nor NA subtype (S06-A/B/E/G).
- **Early.** Protection is present 3 days after vaccination (S06-B: {{sv_S06-B.A}} vs {{sv_S06-B.B}}).
- **Durable.** Protection persists to day 60 (S06-E: {{sv_S06-E.A}} vs {{sv_S06-E.B}}; S06-F: {{sv_S06-F.A}} vs {{sv_S06-F.B}}).
- **Robust to prior infection.** In animals imprinted by earlier PR8 infection, survival after Perth H3N2 challenge is {{sv_impF_i.A}} vs {{sv_impF_i.B}} (S06-F′).

In young animals the non-Mn formulation already protects completely: S09-B, S09-D and S09-F each show {{svY_S09-B.A}} vs {{svY_S09-B.B}}. Even cGAMP liposomes do so (S13-E: {{svY_S13E.A}} vs sham {{svY_S13E.B}}).

### 2.3 Tolerability and CNS

**Body weight after immunisation (no challenge; S08-D).**
- Nadir with PSLN-344 was {{nadir_344.A}}% of baseline vs {{nadir_344.B}}% with vaccine alone: a difference of {{nadir_344.eff}} pp (95% CI {{nadir_344.lo}} to {{nadir_344.hi}}).
- The R848 combination was worse ({{nadir_r848.eff}} pp), and one animal was missing at day 10.

**CNS transcripts at 36 h (S10-A).**
- PSLN-344 did not raise brain Ifnb1 or Isg15 relative to PBS: {{cns_ifnb_pbs.eff}}× (95% CI {{cns_ifnb_pbs.lo}}–{{cns_ifnb_pbs.hi}}) and {{cns_isg_pbs.eff}}× ({{cns_isg_pbs.lo}}–{{cns_isg_pbs.hi}}).
- The cholera-toxin positive control did: {{cns_ct_ifnb.eff}}× and {{cns_ct_isg.eff}}×.
- Tnf was marginally higher than PBS ({{cns_tnf_pbs.eff}}×, 95% CI {{cns_tnf_pbs.lo}}–{{cns_tnf_pbs.hi}}; exact p {{cns_tnf_pbs.pm}}) but not higher than the empty-liposome sham ({{cns_tnf_sham.eff}}×). This is a watch item, not a finding.
- The block covers one timepoint, transcripts only, and no Mn measurement.

---

## 3. Why the package cannot carry an advance decision

I audited every block against its annotation, against the other blocks, and against itself. Table 3 summarises the findings; Appendix B gives the full cell-level evidence for each. The supporting outputs are in the ledger (sheets *Audit_register*, *Dup_weights*, *Survival_vs_weight*). Fig. 3 illustrates four of the findings.

Table 3. Audit findings (summary).

{{TABLE_AUDIT}}

![Fig. 3](figures/fig3_integrity_examples.png)

*Figure 3. Integrity examples. (a) Weights of "vaccine + PSLN-344, challenge at day 3" (S15-I) coincide with those of a different study (S15-C). (b) The single PSLN-344 death has the same trajectory in three "independent" strains. (c) Neutrophil and alveolar-macrophage blocks share 35% of values. (d) Two PSLN-344 animals flat-line in S15-D, yet the same animals' survival block (S06-D) records no deaths.*

### 3.1 What survives the audit

The findings cluster in the protection data and the blocks that sit beside them. That is the worst place for them, because protection is what an adjuvant decision rests on.

**No integrity issue was found** in the blocks behind most of Table 1:
- Antibody titres: S03-A, C, D, E, G, H; S13-A–D, H–J.
- CD8: S05-C–I; S14-A.
- Dendritic cells: S02-A–F.
- Innate: S01-A, S01-D–G, S09-A (left panel), S08-A.
- Tfh/GC: S04-A, S04-C, S04-D; S03-K, S03-L.
- Mechanistic perturbations: S02-G–I, S07-B, S11-C, S12-A.

This rests on a position-wise scan of every pair of immunology blocks, the same test that caught S11-A/B. Outside S11, the only elevated agreement is between HAI against CA09 and against Aichi ({{aud.hai_pos}} positions identical) and between the two neutralisation blocks ({{aud.nt_pos}}). That is expected: titres are discrete two-fold steps, and the same animal responds to both antigens of the bivalent vaccine. No group vector recurs across blocks.

Even so, these blocks come from the same compilation, so Gate 0 should sample them too.

**Protection.**
- No survival block is untouched. Only S06-B and S06-F′ are graded minor.
- The as-printed effect is large enough to survive sensible exclusions: {{rd_C.rd}} pp when the major-graded studies are dropped.
- However, its provenance is shared with weight records that are demonstrably not independent (A1–A3).
- The committee should therefore treat protection as **plausible but unverified**, not as established.

---

## 4. Translational gaps that remain even if the data are clean

1. **Delivery and deposition.**
   - The mechanism the data describe is alveolar: PSLN uptake by type II alveolar epithelial cells is {{srb.A}}% vs {{srb.B}}% for free dye (S01-B), and macrophage uptake falls from {{spad.B}}% to {{spad.A}}% without surfactant proteins A/D (S01-C).
   - *External context:* anaesthetised intranasal instillation in mice deposits much of the dose in the lower airways. A human nasal spray deposits in the nasal cavity.
   - Whether PSLN-344 works with nasal-restricted delivery is untested. If it does not, the product becomes an inhaled adjuvant for older adults, which is a much higher safety bar.
2. **Inflammation resolution in aged lungs.**
   - At 72 h, aged lungs still express Tnf ({{tnf72_vsY.A}}× vs {{tnf72_vsY.B}}× in young; {{tnf72_vsY.eff}}×) and Il10 ({{il10_72_vsY.A}}× vs {{il10_72_vsY.B}}×). Ifnb1 stays raised ({{ifnb72_vsY.eff}}× young; S01-A 72 h).
   - The TNF/IL-10 persistence is an ageing feature also seen with PSLN-212 (Tnf {{tnf72_212vsY.eff}}× and Il10 {{il10_72_212vsY.eff}}× young).
   - On top of that, Mn²⁺ adds persistent Il6 ({{il6_72_vs212.eff}}×, 95% CI {{il6_72_vs212.lo}}–{{il6_72_vs212.hi}}) and Ccl2 ({{ccl2_72_vs212.eff}}×, {{ccl2_72_vs212.lo}}–{{ccl2_72_vs212.hi}}) compared with PSLN-212 at 72 h; Tnf shows a trend ({{tnf72_vs212.eff}}×, p {{tnf72_vs212.p}}). All n = 3.
   - There is no histopathology, BAL or later timepoint to show resolution. For a product for older adults, reactogenicity and lung injury are the first questions a regulator will ask.
   ![Fig. 4](figures/fig4_cytokine_16h_vs_72h.png)

   *Figure 4. Lung transcripts at 16 h and 72 h (S09-A; the right-hand panel is the 72 h timepoint, finding A8). The young profile resolves TNF and IL-10 by 72 h; the aged profile does not, with or without Mn²⁺.*
3. **Manganese.**
   - No Mn measurement in any tissue. No repeat-dose data, although an annual vaccine implies repeated dosing.
   - The only CNS readout is one 36 h transcript panel.
   - *External context:* inhaled or intranasal Mn can reach the brain via olfactory pathways, and intranasal adjuvants have a facial-nerve-palsy precedent (LT-adjuvanted intranasal influenza vaccine).
4. **No benchmark an older adult can already receive.** The comparators are sham, PSLN-212, cGAMP liposome and R848 variants. There is nothing representing high-dose or oil-in-water-adjuvanted intramuscular vaccine, or LAIV.
5. **Endpoints and population.**
   - Protection is read only as death or weight loss after 5–10× LD₅₀ mouse-adapted challenge. There is no lung viral titre or transmission endpoint.
   - Every animal was female.
   - Durability in aged animals is shown only to day 60, and S06-G, the cleanest day-60 heterosubtypic study, is confounded (A4).

---

## 5. What is driving the protection

### 5.1 The mechanistic chain the data support

Table 4. Mechanistic chain. "Perturbed?" asks whether any block removes the link and measures the consequence.

| Link | Evidence (PSLN-344 vs PSLN-212 aged unless stated) | Perturbed? | In aged animals? |
|---|---|---|---|
| 1. Mn²⁺ amplifies STING output | Ifnb1 16 h {{ifnb16_c1.A}} vs {{ifnb16_c1.B}} (= young) (S01-A); dose-sparing (S08-A); not payload (S08-B) | No (no STING-deficient or Mn-only arm) | Yes |
| 2. Chemokine / GM-CSF output | Ccl2 {{ccl2_16_c1.eff}}×, Ccl3 {{ccl3_16_c1.eff}}×, Il6 {{il6_16_c1.eff}}× at 16 h (S09-A); Gm-csf {{gmcsf16_c1.eff}}× at 16 h, {{gmcsf36_c1.eff}}× at 36 h (S02-F) | No | Yes |
| 3. Monocyte recruitment | Day-4 monocytes {{mono_d4_c1.A}}% vs {{mono_d4_c1.B}}% (young {{mono_d4_c3.B}}%) (S01-D). CCR2 antagonist {{ccr2_mono.B}} → {{ccr2_mono.A}}% (S07-B). Gap-junction blocker {{cbx.B}} → {{cbx.A}}% (S11-C). IFNAR not required for recruitment ({{ifnar_mono.B}} vs {{ifnar_mono.A}}%, p {{ifnar_mono.p}}; S12-A) | **Yes**: CCR2, gap junctions | CBX yes; CCR2 age not stated |
| 4. Monocyte → moDC differentiation | Donor moDC {{ifnar_nocdc.B}}% (WT) vs {{ifnar_nocdc.A}}% (Ifnar⁻/⁻), restored to {{gmcsf_rescue.A}}% by GM-CSF (S02-H). GM-CSF added to PSLN-212: {{gm_212.B}} → {{gm_212.A}}% (S02-G) | **Yes**: IFNAR, GM-CSF | Age not stated |
| 5. DC migration and antigen carriage to MLN | CCR7⁺ CD11b⁺ DC {{migdc_c1.A}}% vs {{migdc_c1.B}}% (S02-A). Antigen⁺ MLN DC {{agdc_c1.A}}% vs {{agdc_c1.B}}%, PTX arm {{ptx_ag.A}}% (S02-C) | **Yes**: Gαi (PTX); adjuvant in PTX arm not stated | Yes |
| 6. Priming of CD8 T cells | MLN DC-driven OT-I proliferation {{oti_dc_c1.A}}% vs {{oti_dc_c1.B}}% (S02-E). In vivo, PTX blocks MLN priming ({{ptx_mln.B}} → {{ptx_mln.A}}%) but not lung priming ({{ptx_lung.B}} → {{ptx_lung.A}}%) (S05-C) | Yes (PTX) | Age not stated (C57BL/6 recipients) |
| 7. CD8 effector / memory | Lung Ki-67⁺ {{ki67_c1.A}} vs {{ki67_c1.B}}% and GZMB⁺ {{gzmb3_c1.A}} vs {{gzmb3_c1.B}}% at day 3. Heterologous IFN-γ⁺ {{ifng14_c1.A}} vs {{ifng14_c1.B}}% (d14) and {{ifng60_c1.A}} vs {{ifng60_c1.B}}% (d60). TRM {{trm_c1.A}} vs {{trm_c1.B}}%. CCR2 blockade: lung GZMB⁺ CD8 {{ccr2_gzmb.B}} → {{ccr2_gzmb.A}}% (S02-I) | CCR2 → GZMB⁺ CD8 **in young only** | Readouts yes; perturbation no |
| 8. Tfh / GC / antibody | ICOS-hi Tfh {{tfh_hi_c1.A}} vs {{tfh_hi_c1.B}}%. Tfr {{tfr7_c1.A}} vs {{tfr7_c1.B}}% at d7, but {{tfr30_c1.A}} vs {{tfr30_c1.B}}% at d30 (young {{tfr30_c3.B}}%). GC B {{gcb_c1.A}} vs {{gcb_c1.B}}%. IgG 13–19×, HAI 8–9× (S03, S04) | No | Yes |
| 9. Protection | Antigen-dependent at day 3: vaccine + PSLN-344 {{sv_S15H_v.A}}; vaccine alone {{sv_S15H_v.B}}; PSLN-344 alone {{sv_S15H_a.B}} (S15-H; flagged A1). Heterosubtypic and durable (S06) | No depletion or transfer experiment anywhere | — |

### 5.2 Inference

**The best-supported driver of the durable, cross-subtype protection is a cross-reactive cellular response.** That is CD8 effector and resident-memory T cells, primed through the restored monocyte → moDC / CD11b⁺ DC axis. Antibody contributes, but can account only for the strain-matched result. Underneath sits an early phase (days 2–3) that needs antigen plus adjuvant, but whose nature is unresolved (see "Two phases" below). Four observations lead there:
1. **HA-neutralising antibody cannot explain the breadth.**
   - The vaccine-strain HAI titres in Table 1 cannot act on viruses of another HA subtype. Yet PSLN-344 protects as well against HA/NA-mismatched challenge (Aichi → PR8, S06-A: {{sv_S06-A.A}}) as against matched challenge.
   - Cross-reactive N1 antibody could contribute to protection against rgH5N1 after the bivalent vaccine, because CA09 shares the N1 subtype (S06-C/D/F). But protection is just as strong in the H3N2 → H1N1 setting, where neither HA nor NA is shared. NA matching is therefore not required.
   - In S03-I, cGAMP liposomes with *lower* HAI than PSLN-212 survived better ({{sv_cmp_S03I.A}} vs {{sv_cmp_S03I.B}}). That study is flagged (A3), so this is suggestive only.
2. **The early protection needs antigen.** Neither antigen nor PSLN-344 alone protected at day 3 (S15-H, flagged). So the early effect is not a non-specific antiviral state.
3. **The one measured readout that is both cross-reactive and durable is CD8.** IFN-γ⁺ CD8 T cells recalled by a heterologous virus are present at day 14 and day 60, and lung TRM at day 25. Early lung CD8 activation (Ki-67⁺, GZMB⁺ at day 3) matches the timing of the day-3 protection.
4. **CCR2 links the two.** CCR2 blockade removes both the monocyte influx and (in young mice) the lung GZMB⁺ CD8 response.

**Two phases, not one.** Protection at day 3 is nearly as strong as at day 14 (S06-B {{sv_S06-B.A}} vs S06-A {{sv_S06-A.A}}). Resident memory, measured at day 25, cannot explain that.
- **Early phase (days 2–3).** Needs antigen plus PSLN-344 (S15-H, flagged). Coincides with the IFN-β/chemokine burst and early CD8 activation. Whether it is antigen-*specific* or simply needs the inactivated virus as a co-stimulus is the single most important mechanistic unknown. The irrelevant-antigen arm of Study 1 is designed to answer it.
- **Durable phase (days 14–60).** Best matched by cross-reactive CD8 memory, plus antibody for matched strains.

**What the data cannot tell us.**
- No block depletes CD8 or CD4 T cells, transfers serum, or blocks CCR2/IFNAR/GM-CSF *and then challenges*. Necessity and sufficiency are therefore untested.
- The CCR2 → CD8 link was shown only in young animals.
- Almost every readout moves in the same rank order (sham, then PSLN-212, then PSLN-344, then young). Group-level correlation therefore cannot pick the driver; animal-level linkage and perturbation can (Study 2, Section 8).

**What is *not* driving it.**
- Extra CDN payload (S08-B).
- A non-specific innate antiviral state (S15-H, flagged).
- Better epithelial uptake. The only relevant block (S08-C) points the other way and is unreliable (A6).
- Full "rejuvenation" of the aged lung. CD40/CD86, day-30 Tfr and 72 h TNF/IL-10 all stay far from young values.

---

## 6. Is there a biomarker of efficacy worth carrying forward?

**Short answer: no biomarker of efficacy is established, but two candidates are worth carrying into the confirmatory work.** Establishing one needs pre-challenge measurement in the same animals that are challenged, within-arm prediction of outcome, and a perturbation test. The workbook has none of these.

Table 5. Candidate biomarkers, scored on the criteria that matter for a clinical programme.

| Candidate (block) | PSLN-344 vs PSLN-212, aged | Reaches young level? | On a perturbation-tested path? | Relevant to heterosubtypic protection? | When | Measurable in people? | Verdict |
|---|---|---|---|---|---|---|---|
| **Airway CCL2** (S09-A, 16 h) | {{ccl2_16_c1.eff}}× (95% CI {{ccl2_16_c1.lo}}–{{ccl2_16_c1.hi}}), n=3 | RF {{ccl2_16_c1.rf}} | Yes: CCR2 → monocytes (S07-B) → lung GZMB⁺ CD8 (S02-I, young) | Indirect | 16 h | Nasal lining fluid, serum | **Carry: lead PD marker** |
| **IFN-β / ISG** (S01-A, S08-A) | {{ifnb16_c1.eff}}× ({{ifnb16_c1.lo}}–{{ifnb16_c1.hi}}) | Yes (RF {{ifnb16_c1.rf}}) | Yes: IFNAR needed for moDC (S02-H); dose-responsive (S08-A) | Indirect | 16 h; resolution at 72 h | Nasal swab ISG, blood ISG score | **Carry: target engagement; pair with 72 h resolution** |
| **GM-CSF** (S02-F) | {{gmcsf16_c1.eff}}× (16 h), {{gmcsf36_c1.eff}}× (36 h) | No young arm | Yes: GM-CSF restores moDC (S02-H, S02-G) | Indirect | 16–36 h | Nasal fluid (low abundance) | **Carry: the Mn-specific PD marker** |
| **Cross-reactive IFN-γ⁺ CD8** (S05-F/G, S14-A) | +{{ifng14_c1.eff}} pp ({{ifng14_c1.lo}}–{{ifng14_c1.hi}}); durable to d60 | Partly (RF {{ifng14_c1.rf}}) | CCR2-dependent (young) | **Direct**: recalled by heterologous virus | Day 14 onward | PBMC IFN-γ ELISpot / ICS to conserved NP/M1 (*external context*: routine) | **Carry: candidate efficacy correlate, to be validated** |
| ICOS-hi Tfh (S04-A) | +{{tfh_hi_c1.eff}} pp | RF {{tfh_hi_c1.rf}} | No | Antibody arm | Day 7 | Blood cTfh | Secondary |
| HAI / neutralising titre (S03) | {{hai_ca_c1.eff}}–{{hai_ai_c1.eff}}× | RF 0.80–0.94 | No | Matched strains only | Day 14+ | Yes | Keep as regulatory immunogenicity endpoint only |
| Lung TRM (S05-I) | +{{trm_c1.eff}} pp | RF {{trm_c1.rf}} | No | High | Day 25 | BAL only | Animal mechanism only |
| CD40 / CD86 on MLN DC (S02-D) | +{{cd40_c1.eff}} / +{{cd86_c1.eff}} pp | RF {{cd40_c1.rf}} / {{cd86_c1.rf}} | No | Protection occurs while these stay far below young | Day 3 | No | Drop |
| Tfh:Tfr (S04-B) | Derived from Tfr (A11) | Tfr not normalised at d30 | No | — | Day 7 | Blood | Drop |
| CD206⁺ macrophages / lung Treg (S11-E, S04-D) | {{cd206_c1.eff}} / {{treg_c1.eff}} pp | RF {{cd206_c1.rf}} / {{treg_c1.rf}} | Link untestable (S07-C unreadable, A9) | — | Timepoint not stated | BAL only | Drop for now |

**Recommendation: a two-tier biomarker hypothesis.**
- **Tier 1: early pharmacodynamic panel.** Airway CCL2 + IFN-β/ISG + GM-CSF at 16–36 h, read together with 72 h resolution of TNF/IL-6/IL-10.
  - It is the largest and most Mn-specific separation in the data.
  - It is dose-responsive.
  - It sits upstream of the only perturbation-tested links.
- **Tier 2: candidate efficacy correlate.** The day-14 cross-reactive IFN-γ⁺ CD8 response. It is the only readout that is both cross-reactive and durable, which matches what distinguishes PSLN-344's protection.
- The two tiers map onto the two phases of protection in Section 5.2: Tier 1 onto the early antigen-plus-adjuvant phase, Tier 2 onto durable cross-reactive memory.

**Could it go into patients, and in what role?** Yes. Both tiers can be measured in people: nasal lining fluid, nasal-swab transcripts, blood ISG score, and PBMC ELISpot.
- Tier 1 serves dose and regimen selection in a first-in-human study. It tests whether the Mn-specific biology translates to older adults and acts as a safety guardrail on resolution.
- Tier 2 serves as an early go/no-go immunogenicity endpoint in Phase 1b/2, *after* Study 2 shows that CD8 T cells are necessary for protection in aged animals.
- Neither tier should be used for patient enrichment or as a surrogate endpoint. HAI stays the regulatory immunogenicity endpoint for matched strains.
- If Study 2 instead shows antibody transfer protects, Tier 2 switches to antibody-based markers.

---

## 7. Could PSLN-344 go into patients, and in what role?

**Not now.** It needs Gate 0 (data integrity), Gate 1 (confirmed aged efficacy, including viral load and both sexes), the delivery and Mn-safety work in Study 3, and GLP toxicology.

**If it gets there, the defensible role is narrow.** It would be a mucosal adjuvant co-administered with inactivated or split antigen in adults ≥65. It would be positioned on breadth (heterosubtypic), speed of onset (≤3 days) and durable cellular memory. Two settings fit:
1. A **pandemic / pre-pandemic (e.g., H5) vaccine** for older adults, where strain mismatch and speed matter most.
2. A **mucosal add-on to the licensed intramuscular seasonal vaccine**, to add cross-reactive T-cell and mucosal protection.

It is *not* supported as:
- A stand-alone antiviral prophylactic: PSLN-344 without antigen gave {{sv_S15H_a.B}} survival (S15-H).
- A product for younger adults: Mn²⁺ adds no survival benefit in young animals ({{svY_S09-B.A}} vs {{svY_S09-B.B}}, S09-B/D/F).
- A replacement for high-dose or adjuvanted intramuscular vaccines on HAI grounds. There is no head-to-head data.

---

## 8. Next studies: what each must establish

Table 6. The next studies, in gate order.

| Study and timing | Must establish | Population | Comparators | Endpoints / readouts | Go / no-go |
|---|---|---|---|---|---|
| **Gate 0: source-data and colony-health audit** (weeks 0–6; independent QA) | Every flagged item (A1–A15) traces to primary records and is clerical. Survival reconciles with facility death/euthanasia logs. The aged colony was healthy. | The workbook: all protection and weight blocks, S11-A/B, S08-C/S01-B, S03-B/F, S07-C, S05-A/B; plus a random 10% of all other cells | Raw instrument files (FCS/FlowJo workspaces, qPCR runs, ELISA reads), daily weighing and health logs (IACUC PCL-26-0417), sentinel serology and necropsy reports | Share of flagged items resolved; concordance rate on the random sample | **Go** only if all duplications are explained and originals recovered. **Otherwise terminate.** The protection package would be void, and the immunogenicity data come from the same compilation, so a full restart would be needed that the evidence does not justify. |
| **Study 1: confirmatory heterosubtypic protection** (months 2–9; aged-cohort procurement is rate-limiting, so order at the start of Gate 0 and cancel if it fails; pre-registered, randomised, blinded, ARRIVE-compliant; read out at ~month 9, re-present at ~month 10) | PSLN-344 protects aged animals against HA/NA-mismatched virus better than PSLN-212. It reduces lung virus. It holds in both sexes and two strains. It is not inferior to an older-adult benchmark. | ≥20-month BALB/c and C57BL/6, both sexes, health-screened; young (8–10 wk) reference arm | **Primary:** vaccine + PSLN-212. **Key secondary:** benchmark vaccine + squalene oil-in-water emulsion IM and/or high-dose antigen IM (the older-adult standard of care in nonclinical form). **Controls:** vaccine alone; vaccine + Mn-only liposome (no CDN; isolates Mn); PSLN-344 without antigen; irrelevant antigen + PSLN-344 (tests antigen specificity of early protection) | **Primary:** 14-day survival after heterosubtypic challenge at day 28 (blinded humane-endpoint scoring). **Key secondary:** lung viral titre on days 3 and 5 (satellite animals); weight-loss AUC; a day-3 and a day-90 challenge cohort. **Linkage, same animals before challenge:** serum HAI/MN/IgG, blood strain-appropriate NP tetramer/ICS, nasal-wash IgA. **n:** {{power.n80_20_90}}/arm gives 90% power for 80% vs 20% survival ({{power.n75_25_90}}/arm for 75% vs 25%). Benchmark comparison powered on lung titre: {{power.vt}}/arm for 1 log₁₀. | **Go:** PSLN-344 survival ≥70% and ≥40 pp above PSLN-212 (lower 95% CI > 0) in each strain; ≥1 log₁₀ lung-titre reduction vs vaccine alone; not inferior to benchmark on titre (margin 0.5 log₁₀). |
| **Study 2: mechanism of protection (causal)** (months 3–10, alongside Study 1) | Which arm of immunity is necessary and sufficient in aged animals, and whether the monocyte → moDC axis is needed *for protection* | Aged mice given PSLN-344 + vaccine, challenged at day 28 | Anti-CD8β and anti-CD4 vs isotype (before challenge); FTY720 during challenge (resident vs recirculating T cells); immune-serum transfer into naive aged mice; INCB3344, anti-GM-CSF or anti-IFNAR during priming only | Survival, lung viral titre, weight AUC; depletion confirmed by flow cytometry; titres, CD8 recall, TRM. n = 12–16/arm. | Decides which Tier-2 marker goes into the clinic (CD8 vs antibody). If no arm is necessary, the mechanism claim is dropped. |
| **Study 3: delivery translation and safety** (mouse months 3–8; aged ferret or NHP months 8–18) | Whether protection needs deep-lung deposition. Whether aged-lung inflammation resolves. Whether Mn reaches olfactory bulb or brain. Whether repeat (annual-type) dosing is tolerated. | Aged mice: 5 µL/nostril awake (nasal-restricted) vs 50 µL anaesthetised (lung). Then aged ferrets or NHPs with device-relevant delivery (nasal spray vs nebulised). | PSLN-212, vehicle, Mn-only liposome, cholera toxin (CNS / facial-nerve positive control) | Protection by deposition route. Lung histopathology on days 1, 3, 7, 14. BAL cells and protein. TNF/IL-6/IL-10 resolution by day 7. Mn by ICP-MS in olfactory bulb, brain, blood and lung (24 h, 7 d, 28 d; single and 3 doses). CNS ISG. Trigeminal / facial-nerve histology. | **Go:** protection at clinically achievable deposition; histopathology resolved by day 14; no brain Mn above vehicle; no CNS inflammation. |
| **Study 4: biomarker bridging** (months 3–12, embedded in Studies 1–3) | Whether Tier-1 PD (BAL / nasal CCL2, IFN-β, GM-CSF at 16–36 h) predicts the day-14 CD8 response and protection in individual animals. The minimum PD-active dose. Whether the same PD is measurable in ferret or NHP nasal samples. | Satellite animals from Studies 1–3; dose range 1–40 µg (as S08-A) | PSLN-212; dose levels | Within-arm ROC AUC for protection; dose–PD curve; cross-species PD concordance | Qualifies the panel as the Phase 1 PD endpoint. |
| **Only then: IND-enabling, then first-in-human** (≥ month 18) | GLP repeat-dose toxicology (intranasal/inhaled, two species, local tolerance, CNS/olfactory); CMC (Mn content specification, lyophilised stability with 2.5% trehalose). Phase 1: adults 18–49 with sentinel dosing, then ≥65. | Healthy adults, then older adults | Placebo; licensed enhanced vaccine for older adults (high-dose or adjuvanted, IM) | Solicited nasal, local and systemic reactions days 0–7; spirometry if inhaled; blood Mn; Tier-1 PD at 6–24 h; HAI/MN day 28; nasal IgA; cross-reactive CD8 ELISpot days 14/28/180; cTfh day 7 | Standard Phase 1 stopping rules |

---

## 9. Considered and ruled out

Table 7. Options and interpretations considered.

| Considered | Why it was on the table | Why it was ruled out (evidence) |
|---|---|---|
| **Advance to IND-enabling now** | Large, coherent effects as printed | Protection data not certifiable (A1–A4); translational gaps (Section 4) |
| **Terminate today** | Integrity findings are serious | Most of the immunogenicity evidence has no detected issue. Gate 0 costs weeks. Termination becomes the recommendation if Gate 0 fails. |
| Advance PSLN-212 instead | Simpler, no Mn | Aged survival 0–30% in every study (Table 2) |
| Dose-escalate PSLN-212 | Could match PSLN-344 | Ifnb1 plateaus at {{s08a_PSLN-212_dose40.v}}× at 40 µg, below PSLN-344 at 10 µg ({{s08a_PSLN-344_dose10.v}}×) (S08-A) |
| R848 combinations | Higher innate output | Weight nadir {{nadir_r848.eff}} pp vs vaccine (S08-D); Tnf {{r848_Tnf.v}}× and Il10 {{r848_Il10.v}}× at 16 h (S09-A); no aged efficacy data |
| cGAMP liposome (CMP-204) | Natural ligand | Weaker Ifnb1 ({{cmp_ifnb16.v}}× vs PSLN-212 {{ifnb16_c1.B}}× at 16 h, S01-A; {{s08a_CMP-204_dose20.v}}× at 20 µg, S08-A) and antibodies (S03); 3/7 aged survival (S03-I, flagged) |
| Position for all adults | Larger market | No Mn benefit in young animals (S09-B/D/F; S01-A: {{ifnb16_c5.eff}}× only) |
| Stand-alone (antigen-free) prophylactic | Rapid innate protection | PSLN-344 alone: {{sv_S15H_a.B}} survival at day 3 (S15-H) |
| HA-neutralising antibody as the driver | Large HAI gains | Cannot act on HA-mismatched challenge viruses, where protection is equal (Section 5.2) |
| Larger CDN payload as explanation | — | Encapsulation efficiency {{ee.A}}% vs {{ee.B}}% (S08-B) |
| Better epithelial targeting as explanation | Biomimetic design | S08-C shows lower uptake with PSLN-344 and re-uses S01-B values (A6) |
| "Full rejuvenation" narrative | Many readouts at young levels | CD40/CD86 RF {{cd40_c1.rf}}/{{cd86_c1.rf}}; Tfr at d30 {{tfr30_c1.A}}% vs young {{tfr30_c3.B}}%; TNF and IL-10 unresolved at 72 h |
| S03-B/S03-F as printed (PSLN-344 Th2-skewed) | Printed result | Labels rotated against the source titres (A7) |
| S09-A right panel as a 16 h replicate | Printed label | Reproduces the 72 h data exactly (A8) |
| Tfh:Tfr, and cDC1 plus cDC2, as extra evidence | Printed as separate panels | Derived or complementary (A11) |
| Tetramer (S05-A/B), macrophage transfer (S07-C), PSLN-344 uptake (S08-C), S11-A/B, unlabelled S08 rows 89–101 | Printed data | Excluded (A5, A6, A9, A10; the S08 rows have no label, units or groups) |
| Three-strain survival as independent replication | Printed claim | Template re-use (A2) |
| S06-G as proof of day-60 durability | Printed result | Unchallenged controls survive as often as PSLN-344 ({{sv_S06-G_untr.B}} vs {{sv_S06-G_untr.A}}) (A4) |
| Mean weight-loss curves as efficacy evidence | Standard readout | Mixed dead-animal conventions and copied trajectories (A1, A15). Weights used only animal by animal, to audit survival. |
| Pooling survival as if all animals were independent | Larger n | Analysed stratified by study (CMH); sensitivity analyses exclude flagged studies |
| CD40/CD86, Tfh:Tfr, MLN- or lung-only readouts, HAI as biomarkers of breadth | Available readouts | Section 6 |

---

## Appendix A. Reductions and statistics

- **Per-animal values** were read exactly as stored in the cells. The annotation states that stored values are per-animal and that group means are computed downstream. Every value keeps its worksheet cell address in the ledger (*Tidy_observations*, *Tidy_survival*).
- **Titres** (ELISA endpoint, HAI, neutralisation) were log₂-transformed. HAI entries of 0 were treated as below the 1:10 limit of detection and set to 5. Groups are geometric mean titres. Contrasts are ratios of GMTs with Welch 95% CIs on the log scale.
- **qPCR folds and ratios** were log-transformed and reported as geometric means and ratios. S09-A is supplied as log₁₀, so it was averaged on that scale and back-transformed.
- **Percentages and counts** were summarised as arithmetic means, with differences and Welch 95% CIs.
- **p-values** are Welch t and exact two-sided Mann–Whitney. With n = 5 vs 5 the smallest possible exact Mann–Whitney p is 0.008. One-way ANOVA with Tukey HSD (the method stated in the annotation) was run for every block with ≥3 arms and is in the ledger (*Tukey*); see the check under Table 1. The conclusions rest on effect sizes and their consistency, not on any single p-value.
- **Restoration fraction** = (PSLN-344 − PSLN-212)/(PSLN-212(Y) − PSLN-212), computed on the analysis scale.
- **Survival.**
  - Survivors = rows with event code 0 at the end of follow-up.
  - Per-study tests: Fisher exact (two-sided) and log-rank.
  - Pooling: stratified by study, using the Mantel–Haenszel odds ratio (0.5 added to cells for estimation), the CMH test and a conditional permutation test.
  - Risk differences carry Newcombe 95% CIs.
  - The one S03-J row with an event code but no time was treated as censored at day 21 and flagged.
- **Integrity grading of survival studies.**
  - *Major:* an unresolved contradiction with the same animals' weight record, or a duplication touching the key arms.
  - *Moderate:* a companion weight record involved in cross-experiment duplication, or a count mismatch.
  - *Minor:* annotation or count discrepancies only.
- **Duplicate detection.**
  - Every animal weight trajectory was compared with every other one from a different block/group.
  - A match counted only when the value at the same day was identical *and* had changed from that animal's previous day, so that carried-forward death values were excluded.
  - The empirical null repeated the scan with days shifted by ±2 and ±4.
  - Integer-offset copies: identical fractional parts (≥4 decimals) with different integer parts.
  - Non-weight blocks: compared position by position against unrelated blocks of the same shape.
- **Dead-animal fate from weights:** a blank before day 14, or ≥2 identical trailing values ≤90% (or ≥3 identical trailing values).

## Appendix B. Audit findings: full evidence

{{AUDIT_FULL}}

## Appendix C. Files delivered

| File | Contents |
|---|---|
| `PSLN-344_recommendation.md` / `.pdf` | This memo |
| `PSLN-344_evidence_ledger.xlsx` | One row per number (ID, cells, n, reduction, grade); per-animal tidy data with cell addresses; all contrasts; Tukey; survival (per-group, pairwise, pooled); audit register; duplicate-trajectory pairs; survival-vs-weight reconciliation; block register |
| `figures/fig1–fig4` | Immunogenicity effects; survival by study; integrity examples; 16 h vs 72 h cytokines |
| `analysis_code/` | Parser (`parse.py`: every block mapped to exact cell ranges), statistics, audit, figures, registry and renderer, all re-runnable |

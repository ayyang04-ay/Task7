import sys; sys.path.insert(0,'/tmp/work/lib')
import parse as P, pandas as pd, numpy as np, itertools
df=P.DF.copy()
W = df[df.block.isin([b for b,m in P.BLOCKS.items() if m['kind']=='weight'])].copy()
W['day']=W.key.str.replace('d','').astype(float)
traj={}
for (b,g,r),d in W.groupby(['block','group','rep']):
    d=d.sort_values('day')
    vals=dict(zip(d.day,d.value)); cells=dict(zip(d.day,d.cell))
    days=sorted(vals)
    informative={}
    prev=None
    for day in days:
        v=vals[day]
        informative[day]= (day>0) and (prev is None or abs(v-prev)>1e-9)
        prev=v
    traj[(b,g,r)]=(vals,cells,informative)
rows=[]
for a,b in itertools.combinations(traj,2):
    if a[0]==b[0] and a[1]==b[1]: continue
    va,ca,ia=traj[a]; vb,cb,ib=traj[b]
    common=[d for d in va if d in vb and d>0]
    ident=[d for d in common if abs(va[d]-vb[d])<1e-9 and ia[d] and ib[d]]
    offs=[d for d in common if abs(va[d]-vb[d])>1e-9 and abs(round(va[d]-vb[d])-(va[d]-vb[d]))<1e-6 and len(repr(va[d]).split('.')[-1])>=4]
    if len(ident)+len(offs)>=3:
        rows.append(dict(A=f'{a[0]} {a[1]} animal#{a[2]}',B=f'{b[0]} {b[1]} animal#{b[2]}',
                         same_block=a[0]==b[0],
                         n_informative_identical=len(ident), n_integer_offset=len(offs),
                         days_identical=','.join(str(int(d)) for d in ident),
                         days_offset=','.join(str(int(d)) for d in offs),
                         example=('; '.join(f'd{int(d)} {va[d]} [{ca[d]}] = [{cb[d]}]' for d in ident[:2]) +
                                  (' | ' if ident and offs else '') +
                                  '; '.join(f'd{int(d)} {va[d]} [{ca[d]}] vs {vb[d]} [{cb[d]}]' for d in offs[:2]))))
R=pd.DataFrame(rows).sort_values(['n_informative_identical','n_integer_offset'],ascending=False)
R.to_csv('/tmp/work/dup_weight_strong.csv',index=False)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',200)
print(len(R))
print(R[['A','B','n_informative_identical','n_integer_offset','days_identical','days_offset']].to_string())

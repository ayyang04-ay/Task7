import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans'})
OUT='/tmp/outputs/figures/'
C=pd.read_csv('/tmp/work/contrasts.csv',keep_default_na=False,na_values=['']); C['key']=C['key'].fillna('').astype(str)
E=pd.read_csv('/tmp/work/extra_contrasts.csv')
D=pd.read_csv('/tmp/work/tidy_observations.csv',keep_default_na=False,na_values=['']); D['key']=D['key'].fillna('').astype(str)
S=pd.read_csv('/tmp/work/survival_groups.csv')

# ---------------- Fig 1: forest of PSLN-344 vs PSLN-212 (aged) ----------------
sel=[('Innate (lung)','S01-A_16h','','Ifnb1 16 h (fold)'),('Innate (lung)','S09-A_left','Ccl2','Ccl2 16 h (fold)'),('Innate (lung)','S02-F','36h','Gm-csf 36 h (fold)'),
     ('Innate (lung)','S01-D','d4','Monocytes d4 (%)'),
     ('DC','S01-F','','cDC1 72 h (%)'),('DC','S02-A','','Migratory CCR7+ CD11b+ DC (%)'),('DC','S02-C','','Antigen+ MLN DC (%)'),
     ('DC','S02-E','','DC-driven OT-I proliferation (%)'),('DC','S02-D_CD40','','CD40+ MLN CD11b+ DC (%)'),('DC','S02-D_CD86','','CD86+ MLN CD11b+ DC (%)'),
     ('CD8 T cell','S05-D','','Lung Ki-67+ CD8 d3 (%)'),('CD8 T cell','S05-E','','Lung GZMB+ CD8 d3 (%)'),('CD8 T cell','S05-F','','Cross-reactive IFN-g+ CD8 d14 (%)'),
     ('CD8 T cell','S05-G','','Cross-reactive IFN-g+ CD8 d60 (%)'),('CD8 T cell','S05-I','','Lung TRM d25 (%)'),('CD8 T cell','S14-A_H1N1','','IFN-g+ CD8, H1N1 restim (%)'),
     ('Tfh / GC','S04-A_ICOShi','','ICOS-hi Tfh d7 (%)'),('Tfh / GC','S04-B_Tfr','','Tfr d7 (%)'),('Tfh / GC','S04-C','','Tfr d30 (%)'),('Tfh / GC','S03-K','','GC B d7 (%)'),
     ('Antibody','S03-A','','IgG anti-CA09 d14 (titre)'),('Antibody','S03-C','','HAI CA09 d14 (titre)'),('Antibody','S03-D','','Neut CA09 d14 (titre)'),
     ('Antibody','S03-E','','IgG anti-Aichi d14 (titre)'),('Antibody','S03-G','','HAI Aichi d14 (titre)'),('Antibody','S03-H','','Neut Aichi d14 (titre)'),
     ('Lung milieu','S11-E','','CD206+ macrophages (%)'),('Lung milieu','S04-D','','Lung Treg d7 (%)')]
rows=[]
for cat,b,k,lab in sel:
    r=C[(C.block==b)&(C.key==k)&(C.contrast.str.startswith('C1'))].iloc[0]
    y=C[(C.block==b)&(C.key==k)&(C.contrast.str.startswith('C3'))]
    rows.append(dict(category=cat,lab=lab,block=b,rf=r.restoration_fraction,A=r.A_summary,B=r.B_summary,eff=r.effect,lo=r.ci_lo,hi=r.ci_hi,scale=r['scale'],g=r.hedges_g,p=r.p_welch))
F=pd.DataFrame(rows)
fig,ax=plt.subplots(1,2,figsize=(12.5,8.6),gridspec_kw={'width_ratios':[1.3,1]},sharey=True)
cols={'Innate (lung)':'#1b9e77','DC':'#d95f02','CD8 T cell':'#7570b3','Tfh / GC':'#e7298a','Antibody':'#66a61e','Lung milieu':'#a6761d'}
yy=np.arange(len(F))[::-1]
for i,r in F.iterrows():
    ax[0].plot(r.g,yy[i],'o',color=cols[r.category],ms=6)
    ax[0].hlines(yy[i],0,r.g,color=cols[r.category],lw=1.5,alpha=.6)
ax[0].axvline(0,color='k',lw=.8)
ax[0].set_yticks(yy); ax[0].set_yticklabels([f'{r.lab}  [{r.block}]' for _,r in F.iterrows()],fontsize=7.5)
ax[0].set_xlabel("Hedges' g, PSLN-344 vs PSLN-212 (aged)\n(analysis scale: log2 for titres/folds, raw % otherwise)")
ax[0].set_title('A. Effect of Mn2+ in aged animals (n = 3-5 per arm)',loc='left',fontsize=9.5)
for i,r in F.iterrows():
    fmt=lambda x: f'{x:,.0f}' if x>=100 else f'{x:.3g}'
    txt=f'{fmt(r.A)} vs {fmt(r.B)}'
    ax[0].text(ax[0].get_xlim()[1] if False else 9.3,yy[i],txt,va='center',fontsize=6.8,color='#333')
ax[0].set_xlim(-9,12.5)
# Right: restoration fraction
for i,r in F.iterrows():
    ax[1].barh(yy[i],r.rf,color=cols[r.category],alpha=.85)
    ax[1].text(max(r.rf,0)+0.02,yy[i],f'{r.rf:.2f}',va='center',fontsize=7)
ax[1].axvline(1,color='k',ls='--',lw=.8); ax[1].axvline(0,color='k',lw=.8)
ax[1].set_xlim(-0.1,1.25); ax[0].set_ylim(-0.8,len(F)-0.2)
for i,r in F.iterrows():
    if np.isnan(r.rf): ax[1].text(0.02,yy[i],'no young comparator in block',va='center',fontsize=6.5,color='#666')
ax[1].set_xlabel('Restoration fraction = (344 - 212) / (212(Y) - 212)\n0 = no rescue of aged deficit; 1 = young benchmark')
ax[1].set_title('B. Fraction of the aged deficit closed',loc='left',fontsize=9.5)
handles=[plt.Line2D([],[],marker='o',ls='',color=c,label=k) for k,c in cols.items()]
fig.legend(handles=handles,loc='lower center',ncol=6,fontsize=8,frameon=False,bbox_to_anchor=(0.6,0.0))
plt.tight_layout(rect=(0.03,0.03,1,1)); plt.subplots_adjust(left=0.215); plt.savefig(OUT+'fig1_immunogenicity_effects.png',dpi=170); plt.close()
F.to_csv('/tmp/work/fig1_data.csv',index=False)

# ---------------- Fig 2: survival by block ----------------
blocks=[('S03-I','homologous\nCA09 d14'),('S06-A','Aichi->PR8\nd14'),('S06-B','Aichi->PR8\nd3'),('S06-C','bivalent->\nrgH5N1 d14'),('S06-D','bivalent->\nrgH5N1 d3'),
        ('S06-E','Aichi->PR8\nd60'),('S06-F','bivalent->\nrgH5N1 d60'),('S06-G','CA09->\nPerth d60'),('S15-L','C57BL/6\n(not stated)'),('S15-N','Swiss Webster\n(not stated)')]
grp=['Sham','PSLN-212','PSLN-344','PSLN-212(Y)','Untreated']; gc={'Sham':'#999999','PSLN-212':'#fdae61','PSLN-344':'#2c7bb6','PSLN-212(Y)':'#1a9641','Untreated':'#000000'}
fig,ax=plt.subplots(figsize=(12,5))
w=0.16
icol={'major':'#b2182b','moderate':'#e08214','minor':'#4d4d4d'}
labels=[]
for j,(b,lab) in enumerate(blocks):
    d=S[S.block==b]
    for k,g in enumerate(grp):
        x=d[d.group==g]
        if len(x)==0: continue
        v=x.pct_survival.iloc[0]
        ax.bar(j+(k-1.5)*w,max(v,0.8),w,color=gc[g],edgecolor='k' if g=='Untreated' else None,hatch='//' if g=='Untreated' else None,alpha=.9 if g!='Untreated' else .2)
        ax.text(j+(k-1.5)*w,v+1.5,f'{int(x.survivors.iloc[0])}/{int(x.n.iloc[0])}',ha='center',fontsize=6,rotation=90)
    labels.append(f'{b}\n{lab}\n[{d.integrity.iloc[0]}]')
ax.set_xticks(range(len(blocks))); ax.set_xticklabels(labels,fontsize=7)
for t,(b,_) in zip(ax.get_xticklabels(),blocks):
    t.set_color(icol[S[S.block==b].integrity.iloc[0]])
ax.set_ylabel('% surviving to end of follow-up'); ax.set_ylim(0,128)
handles=[plt.Rectangle((0,0),1,1,color=gc[g],alpha=.9 if g!='Untreated' else .2) for g in grp]
ax.legend(handles,['Sham (vaccine + empty liposome)','PSLN-212 (no Mn)','PSLN-344','PSLN-212 young','Untreated (no vaccine, no challenge)'],fontsize=7.5,ncol=5,loc='upper center',frameon=False)
ax.set_title('Aged-animal challenge studies as printed (survivors/n above bars). Bracket and colour = integrity grade from the audit (Section 3).',fontsize=9,loc='left')
plt.tight_layout(); plt.savefig(OUT+'fig2_survival_by_block.png',dpi=170); plt.close()

# ---------------- Fig 3: integrity examples ----------------
def traj(b,g):
    x=D[(D.block==b)&(D.group==g)].copy(); x['day']=x.key.str.replace('d','').astype(float)
    return x.pivot_table(index='day',columns='rep',values='value')
fig,ax=plt.subplots(2,2,figsize=(11,8))
a=traj('S15-C','PSLN-344'); b=traj('S15-I','3d Vaccine+PSLN-344')
for r in a.columns:
    ax[0,0].plot(a.index,a[r],'-o',color='#2c7bb6',ms=3,lw=1.2,alpha=.8)
    ax[0,0].plot(b.index,b[r],'--x',color='#d7191c',ms=5,lw=1,alpha=.8)
ax[0,0].set_title('(a) S15-C PSLN-344 (solid; challenge 14 d after vaccination)\n vs S15-I "3d Vaccine+PSLN-344" (dashed; challenge 3 d after).\nAnimals #2-#7 identical on d2-d12',fontsize=8,loc='left')
ax[0,0].set_xlabel('day after challenge'); ax[0,0].set_ylabel('% of day-0 weight')
for b_,g,c,lab in [('S15-A','PSLN-344','#2c7bb6','BALB/c (S15-A)'),('S15-M','PSLN-344','#d7191c','C57BL/6 (S15-M)'),('S15-O','PSLN-344','#1a9641','Swiss Webster (S15-O)')]:
    t=traj(b_,g)
    ax[0,1].plot(t.index,t[5],'-o',color=c,ms=3,label=lab+' animal #5')
    ax[0,1].plot(t.index,t[2],':',color=c,lw=1,label=lab+' animal #2')
ax[0,1].legend(fontsize=6.5,frameon=False); ax[0,1].set_xlabel('day after challenge')
ax[0,1].set_title('(b) Three "independent" mouse strains: PSLN-344 animal #5\nidentical from d4 (85.1% carried forward, death day 8 in all three);\nS15-M #2 = S15-A #2 except integer shifts on d2/d8',fontsize=8,loc='left')
# S11-A vs S11-B
A=D[D.block=='S11-A'][['group','key','rep','value']]; B=D[D.block=='S11-B'][['group','key','rep','value']]
M=A.merge(B,on=['group','key','rep'],suffixes=('_AM','_neut'))
same=np.isclose(M.value_AM,M.value_neut)
ax[1,0].scatter(M.value_AM[~same],M.value_neut[~same],s=12,color='#999999',label='different')
ax[1,0].scatter(M.value_AM[same],M.value_neut[same],s=16,color='#d7191c',label=f'identical ({same.sum()}/100)')
ax[1,0].plot([10,60],[10,60],'k--',lw=.7); ax[1,0].legend(fontsize=7,frameon=False)
ax[1,0].set_xlabel('S11-A alveolar macrophages (%)'); ax[1,0].set_ylabel('S11-B neutrophils (%), same animal position')
ax[1,0].set_title('(c) S11-B vs S11-A: 35% of cells identical (animal columns 1-2: 34/40);\nunrelated same-shape block pairs: 0-1%',fontsize=8,loc='left')
# S06-D vs S15-D
t=traj('S15-D','PSLN-344')
for r in t.columns:
    dead = np.isclose(t[r].iloc[-1],t[r].iloc[-2]) and t[r].iloc[-1]<90
    ax[1,1].plot(t.index,t[r],'-o',ms=3,color='#d7191c' if dead else '#2c7bb6',lw=1.4 if dead else .8)
ax[1,1].set_xlabel('day after challenge'); ax[1,1].set_ylabel('% of day-0 weight')
ax[1,1].set_title('(d) S15-D PSLN-344 weights: 2 animals flat-line (carried forward,\nred) from d8, yet S06-D (same animals) records 0/7 deaths',fontsize=8,loc='left')
plt.tight_layout(); plt.savefig(OUT+'fig3_integrity_examples.png',dpi=170); plt.close()

# ---------------- Fig 4: 16 h vs 72 h lung cytokines ----------------
an=['Ifnb1','Il6','Ccl2','Ccl3','Ccl5','Tnf','Il10']
fig,ax=plt.subplots(1,2,figsize=(11,3.8),sharey=True)
for j,(blk,tt) in enumerate([('S09-A_left','16 h'),('S09-A_right','72 h (block labelled "16h"; values = S01-A 72 h)')]):
    for k,g in enumerate(['PSLN-212','PSLN-344','PSLN-212(Y)']):
        m=[D[(D.block==blk)&(D.group==g)&(D.key==a)].value.mean() for a in an]
        s=[D[(D.block==blk)&(D.group==g)&(D.key==a)].value.std() for a in an]
        ax[j].bar(np.arange(len(an))+(k-1)*0.27,m,0.27,yerr=s,capsize=2,color=['#fdae61','#2c7bb6','#1a9641'][k],label=['PSLN-212 aged','PSLN-344 aged','PSLN-212 young'][k])
    ax[j].axhline(0,color='k',lw=.6); ax[j].set_xticks(range(len(an))); ax[j].set_xticklabels(an)
    ax[j].set_title(f'S09-A lung transcripts, {tt}',fontsize=8.5,loc='left')
ax[0].set_ylabel('log10 fold vs untreated (mean +/- SD, n=3)'); ax[0].legend(fontsize=7,frameon=False)
plt.tight_layout(); plt.savefig(OUT+'fig4_cytokine_16h_vs_72h.png',dpi=170); plt.close()
print('figures done')

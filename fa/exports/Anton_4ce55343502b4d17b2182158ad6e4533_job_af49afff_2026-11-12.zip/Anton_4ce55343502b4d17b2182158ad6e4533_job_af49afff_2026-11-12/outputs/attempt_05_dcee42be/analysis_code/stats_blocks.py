import pandas as pd, numpy as np, scipy.stats as st, warnings
from statsmodels.stats.multicomp import pairwise_tukeyhsd
warnings.filterwarnings('ignore')
DF=pd.read_csv('/tmp/work/tidy_observations.csv', keep_default_na=False, na_values=[''])
DF['key']=DF['key'].astype(str).replace('nan','')
BL=pd.read_csv('/tmp/work/block_metadata.csv',index_col=0)

TITRE={'S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}
HAI={'S03-C','S03-G'}
LOGFOLD={'S01-A_16h','S01-A_72h','S02-F','S03-L_Aicda','S03-L_E47','S08-A','S10-A_Ifnb1','S10-A_Tnf','S10-A_Isg15','S03-B','S03-F','S04-B_TfhTfr'}
LOG10_ALREADY={'S09-A_left','S09-A_right'}
def scale(block):
    if block in TITRE: return 'log2'
    if block in LOGFOLD: return 'log2'
    if block in LOG10_ALREADY: return 'log10_given'
    return 'linear'
def transform(block, v):
    v=np.asarray(v,float)
    if block in HAI: v=np.where(v<10,5.0,v)   # below LOD (1:10) -> 5
    s=scale(block)
    if s=='log2': return np.log2(v)
    return v
def backt(block,x):
    s=scale(block)
    if s=='log2': return 2**x
    if s=='log10_given': return 10**x
    return x

def welch_ci(a,b,alpha=0.05):
    a=np.asarray(a,float); b=np.asarray(b,float)
    ma,mb=a.mean(),b.mean(); va,vb=a.var(ddof=1),b.var(ddof=1); na,nb=len(a),len(b)
    se=np.sqrt(va/na+vb/nb)
    if se==0: return ma-mb, np.nan, np.nan, np.nan
    df=(va/na+vb/nb)**2/((va/na)**2/(na-1)+(vb/nb)**2/(nb-1))
    t=(ma-mb)/se; p=2*st.t.sf(abs(t),df); q=st.t.ppf(1-alpha/2,df)
    return ma-mb, ma-mb-q*se, ma-mb+q*se, p
def hedges_g(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float); na,nb=len(a),len(b)
    sp=np.sqrt(((na-1)*a.var(ddof=1)+(nb-1)*b.var(ddof=1))/(na+nb-2))
    if sp==0: return np.nan
    J=1-3/(4*(na+nb)-9)
    return J*(a.mean()-b.mean())/sp
def mwu(a,b):
    try: return st.mannwhitneyu(a,b,alternative='two-sided',method='exact').pvalue
    except Exception: return st.mannwhitneyu(a,b,alternative='two-sided').pvalue

CTRL={'Sham','Vaccine','PBS'}
def contrasts(block):
    d=DF[DF.block==block]
    out=[]
    for key,dk in d.groupby('key',sort=False):
        gvals={g:transform(block,x.sort_values('rep').value.values) for g,x in dk.groupby('group')}
        graw={g:x.sort_values('rep').value.values for g,x in dk.groupby('group')}
        ctrl=[g for g in gvals if g in CTRL]
        pairs=[('PSLN-344','PSLN-212','C1: Mn effect in aged (344 vs 212)')]
        if ctrl: pairs.append(('PSLN-344',ctrl[0],f'C2: 344 vs {ctrl[0]} (aged)'))
        pairs+= [('PSLN-344','PSLN-212(Y)','C3: 344 aged vs young benchmark 212(Y)'),
                 ('PSLN-212','PSLN-212(Y)','C4: age deficit 212 aged vs 212(Y)'),
                 ('PSLN-344(Y)','PSLN-212(Y)','C5: Mn effect in young')]
        rf=np.nan
        if all(g in gvals for g in ['PSLN-344','PSLN-212','PSLN-212(Y)']):
            m344,m212,mY=[gvals[g].mean() for g in ['PSLN-344','PSLN-212','PSLN-212(Y)']]
            rf=(m344-m212)/(mY-m212) if mY!=m212 else np.nan
        for a,b,lab in pairs:
            if a in gvals and b in gvals and len(gvals[a])>=2 and len(gvals[b])>=2:
                diff,lo,hi,p=welch_ci(gvals[a],gvals[b])
                s=scale(block)
                if s=='log2': eff,elo,ehi,etype=2**diff,2**lo,2**hi,'ratio of geometric means'
                elif s=='log10_given': eff,elo,ehi,etype=10**diff,10**lo,10**hi,'ratio of geometric means (from log10 data)'
                else: eff,elo,ehi,etype=diff,lo,hi,'difference in means (percentage points / units)'
                out.append(dict(block=block,key=key,contrast=lab,A=a,B=b,nA=len(gvals[a]),nB=len(gvals[b]),
                    A_summary=backt(block,gvals[a].mean()),B_summary=backt(block,gvals[b].mean()),
                    summary_type='geometric mean' if s!='linear' else 'arithmetic mean',
                    effect=eff,ci_lo=elo,ci_hi=ehi,effect_type=etype,p_welch=p,p_mwu_exact=mwu(gvals[a],gvals[b]),
                    hedges_g=hedges_g(gvals[a],gvals[b]),restoration_fraction=rf if lab.startswith('C1') else np.nan,scale=s))
    return out

def group_summaries():
    rows=[]
    for (b,k,g),x in DF.groupby(['block','key','group'],sort=False):
        v=x.sort_values('rep').value.values; tv=transform(b,v)
        rows.append(dict(block=b,key=k,group=g,n=len(v),mean=np.mean(v),sd=np.std(v,ddof=1) if len(v)>1 else np.nan,
                         sem=(np.std(v,ddof=1)/np.sqrt(len(v))) if len(v)>1 else np.nan,median=np.median(v),min=v.min(),max=v.max(),
                         geo_mean=backt(b,tv.mean()) if scale(b)!='linear' else np.nan, scale=scale(b),
                         cells=f"{x.cell.iloc[0]}..{x.cell.iloc[-1]}" ))
    return pd.DataFrame(rows)

def tukey(block):
    d=DF[DF.block==block]; res=[]
    for key,dk in d.groupby('key',sort=False):
        if dk.group.nunique()<3: continue
        y=transform(block,dk.value.values)
        tk=pairwise_tukeyhsd(y,dk.group.values)
        t=pd.DataFrame(tk.summary().data[1:],columns=tk.summary().data[0])
        an=st.f_oneway(*[transform(block,x.value.values) for _,x in dk.groupby('group')])
        t['block']=block; t['key']=key; t['anova_F']=an.statistic; t['anova_p']=an.pvalue
        res.append(t)
    return pd.concat(res) if res else pd.DataFrame()

if __name__=='__main__':
    S=group_summaries(); S.to_csv('/tmp/work/group_summaries.csv',index=False)
    C=pd.DataFrame([r for b in DF.block.unique() for r in contrasts(b)])
    C.to_csv('/tmp/work/contrasts.csv',index=False)
    T=pd.concat([tukey(b) for b in DF.block.unique() if b not in ('S08-D',) and not b.startswith(('S15','S09-C','S09-E','S09-G','S13-F','S13-G'))])
    T.to_csv('/tmp/work/tukey.csv',index=False)
    print(len(S),len(C),len(T))

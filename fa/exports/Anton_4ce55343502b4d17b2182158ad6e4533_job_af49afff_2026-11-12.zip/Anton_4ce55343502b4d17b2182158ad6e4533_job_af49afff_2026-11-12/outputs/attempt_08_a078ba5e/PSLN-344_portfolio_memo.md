---
title: "PSLN-344: portfolio review position"
subtitle: "Intranasal Mn²⁺–STING nanoadjuvant for influenza A vaccines in older adults: recommendation, evidence, data-integrity audit and forward plan"
---

**Source data:** `adjuvant_program_dataset.xlsx` (15 sheets) and `adjuvant_program_annotation.pdf`. No external data were used. Where I apply domain knowledge rather than data, it is stated as such. Examples: MHC restriction of the NP366 and OT-I readouts; the regulatory standing of HAI; what a clinically relevant comparator is.

**How to check any number:** every quantitative statement carries an evidence ID (**E##**) or an integrity ID (**I-##**). Each E-ID resolves in `evidence_register.csv` (sheet `evidence_register` in the .xlsx) to the block, the cell range, the animals and the reduction. Each I-ID resolves in `data_integrity_findings.csv`. All code is in `code/` and regenerates every table and figure from the workbook.

**Conventions used throughout.** Aged means ≥20 months (protocol definition) unless marked (Y) for young (7–8 weeks).

- **Titres and qPCR fold-changes** are summarised as geometric means (GM, or GMT for titres) with 95% CI. Contrasts are ratios of GMs with Welch 95% CIs.
- **HAI values recorded as "0"** fell below the 1:10 lower limit of detection (LOD) and are set to 5.
- **Percent data** are arithmetic means (SD).
- **Survival** is survivors/n at end of observation, with exact 95% CIs. Comparisons use log-rank (the stated method) and Fisher's exact test. Pooling across experiments uses a Mantel-Haenszel risk difference stratified by experiment.
- **Sample sizes** are n = 5 per arm for immunology and n = 7 per arm for survival unless stated.

# 1. Recommendation: advance, but gated

**Advance PSLN-344 into a 10–12-month "confirm and de-risk" stage with explicit kill criteria.** Until three gates are passed, do not commit to IND-enabling GLP toxicology or GMP scale-up. Do not use the current dataset externally either (partners, regulators, publication).

| Gate | What must be shown | Why it is a gate |
|---|---|---|
| **G1 Source data** | Raw records (survival logs, balance print-outs, FCS/qPCR exports) reconcile the flagged blocks | The protection data cannot be verified from this file (Section 3) |
| **G2 Confirmation** | Blinded, pre-registered aged-mouse study: ≥40-point survival gain over Mn-free PSLN-212 (lower 95% CI >20); differentiation vs an intramuscular (IM) standard-of-care proxy; ≥60% survival at day 90; same-animal correlates | Efficacy, comparator and durability gaps |
| **G3 Manganese safety** | No dose-related Mn accumulation in olfactory bulb or brain, and no olfactory injury, at the efficacious dose. Aged-lung inflammation resolves by day 7 | Intranasal Mn has never been measured in this programme; aged lungs show non-resolving inflammation at 72 h |

**Why not a straight "go":**

- The only efficacy evidence is survival, and it cannot be independently verified from this workbook:
  - One survival experiment is a cell-for-cell copy of another (I-01).
  - The homologous and wild-type H5N1 survival blocks contradict their own body-weight records (I-03, I-04).
  - Animal-level body-weight trajectories recur across unrelated experiments, mouse strains and adjuvant arms (I-02).
- The two largest translational risks are untested:
  - Intranasal manganese exposure of the olfactory route and brain (no Mn dose is reported anywhere).
  - Durability in aged hosts (E08).
- There is no clinically relevant comparator.

**Why not "drop":**

- **The signal is large and internally controlled.** The part of the package not implicated in the duplication or record-conflict findings (innate, humoral and cellular immunology in aged mice) shows a large, mechanistically coherent rescue of the aged response. PSLN-344 and PSLN-212 differ only in Mn²⁺, so the comparison isolates the Mn effect.
- **The survival benefit survives every conservative re-analysis.** Taken at face value it is 64–71 percentage points over PSLN-212 in every scenario (E01–E04; Figure 1). Outside the copied S06-D block, wherever the survival and weight records disagree about PSLN-344, the survival record is the *less* favourable one (I-21).
- **Cost.** A confirmatory stage costs a fraction of IND-enabling work, and it directly answers the questions that would otherwise sink the asset later.

**Kill criteria for the gated stage.** Stop if any of the following occurs:

- **K1:** The confirmatory study (G2) does not reproduce a ≥40-point survival advantage over PSLN-212 in aged mice (lower 95% CI >20 points).
- **K2:** Manganese accumulates in the olfactory bulb or brain, or injures the olfactory epithelium, at the efficacious dose, with no ≥10× margin available by dose reduction.
- **K3:** PSLN-344 is not better than the IM standard-of-care proxy on at least one of lung viral load in the heterosubtypic model, mucosal IgA, or protection at day 90.
- **K4:** Source-data verification (G1) shows that PSLN-344 arm data were not generated as recorded.

# 2. The case in ten numbers

| # | Finding (aged mice unless stated) | Value | ID |
|---|---|---|---|
| 1 | Survival, PSLN-344 vs Mn-free PSLN-212 (6 best-documented experiments, S06-A/B/C/E/F/G) | **76% (32/42) vs 10% (4/42)**; risk difference +67 points [52, 82] | E02 |
| 2 | The same comparison under four integrity scenarios | +64 to +71 points; lowest lower 95% bound +45 | E01–E04 |
| 3 | Challenges sharing **no** HA or NA subtype with the vaccine (H3N2→H1N1, H1N1→H3N2) | **71% (20/28) vs 4% (1/28)**; young 100% (28/28) | E57 |
| 4 | HAI titre against vaccine strains, day 14 (GMT) | CA09 **368 vs 46** (×8.0 [3.9–16.4]); Aichi 320 vs 35 (×9.2). Young: 485 / 368 | E17, E18 |
| 5 | Serum IgG, day 14 (GM) | ×18.6 [9.1–37.9] (CA09); ×13.4 [6.1–29.6] (Aichi) | E15, E16 |
| 6 | Cross-reactive IFN-γ⁺ CD8 T cells (rgH5N1 recall, mediastinal lymph node [MLN], day 14) | 6.4% vs 1.5% (young 9.2%) | E29 |
| 7 | Lung resident-memory CD8 (TRM), day 25 | 4.0% vs 1.0% (young 6.0%) | E32 |
| 8 | Lung Ifnb1 (IFN-β transcript) 16 h after adjuvant | GM 36.9× vs 16.5×; **equal to young** (37.5×; ratio 0.98 [0.84–1.16]) | E35 |
| 9 | Protection requires antigen (rgH5N1 challenge 3 d after dosing) | PSLN-344 alone 0/7; vaccine alone 0/7; vaccine + PSLN-344 6/7 | E52 |
| 10 | Tolerability (single dose) | Weight nadir 96.4% (vaccine alone 98.2%). CNS Ifnb1/Tnf/Isg15 not above vehicle (cholera toxin 5.4×) | E53, E54 |

What the numbers do **not** say:

- **It does not fully restore young-level protection.** Aged PSLN-344 reaches 76% survival against 100% for young mice (−24 points [−37, −11]; E06).
- **Boost responses remain well below young.** Day-28 post-boost IgG is 29–38% of young (E21, E22).
- **Protection wanes.** Aged survival falls from 13/14 when challenged at day 14 to 14/21 at day 60 (E08).

![Figure 1. Aged-mouse survival by experiment, with integrity flags (top), and pooled PSLN-344 minus PSLN-212 survival difference under four integrity scenarios (bottom). Sources: E01–E07.](figures/fig1_survival_overview.png)

# 3. What the committee will find if it looks, and how I handled it

I assigned every numeric cell in the workbook to exactly one annotated block; the only unassigned region is an unlabelled fragment at S08!A89:D101 (I-13). I then cross-checked linked blocks against each other. The audit produced 22 findings (5 critical, 7 major, 10 minor; full list in `data_integrity_findings.csv`). The findings that bear on the decision are below; examples are in Figure 4.

| ID | Finding | Consequence | Handling |
|---|---|---|---|
| **I-01** | **S06-D** (rgH5N1 challenge 3 days after vaccination) is a cell-for-cell copy of **S06-C** (challenge at day 14): all 28 animals have identical death days. Its weight block S15-D is *not* a copy and implies 2/7 deaths for aged PSLN-344 and for young PSLN-212, against 0/7 recorded. | The day-3 H5N1 "rapid protection" result is unknown; weights suggest 5/7, not 7/7 | S06-D excluded everywhere |
| **I-02** | Body-weight trajectories recur across experiments:<br>• 26 animal-level pairs with strong evidence: values identical at 4–8 decimals, or differing only in the integer part, or identical on ≥5 days.<br>• 12 weaker pairs.<br>A day-matched permutation null predicts 0.75 such low-precision pairs; 23 are observed. Examples:<br>• All 7 PSLN-344 animals of S15-C (rgH5N1, day 14) reappear as the "vaccine + PSLN-344" arm of S15-I, a separate day-3 study.<br>• Young BALB/c PSLN-344 (S09-E) reappear as young C57BL/6 PSLN-212 (S15-M).<br>• Post-vaccination CMP-204 weights (S08-D) reappear as post-challenge young PSLN-212 weights (S15-F) with integer parts changed. | Weights cannot corroborate any survival result | Weights not used as efficacy evidence; the post-vaccination weight safety data (E53) is provisional. **Escalate to QA** |
| **I-03, I-04** | The homologous CA09 (S03-I) and wild-type H5N1 (S03-J) survival blocks list different arms from their own weight blocks (S13-F/S13-G have a "Naive" arm instead of CMP-204 or PSLN-212). Comparator outcomes disagree: PSLN-212 0/7 by survival record vs ≥3 recovering in weights; S03-J sham 9/10 deaths vs 5/10. S03-J also states n = 9 but has 10 records per arm. | Comparator results unreliable. PSLN-344 results agree in both records (7/7, 10/10) | Excluded from scenarios S2–S4 |
| **I-05** | The IgG2a/IgG1 ratios printed in **S03-B/S03-F** are the per-animal ratios of the S13 subclass titres with group labels rotated (max relative error ≤6.4×10⁻⁴). As printed, PSLN-344 looks Th2-skewed (0.58). The raw titres show the opposite: a Th1 shift, 1.85 vs 0.54 (E23). | Reverses a conclusion | Replaced by S13-derived ratios |
| **I-08** | Unvaccinated, **unchallenged** aged controls died: 4/21 within 14 days (19% [5–42]), all at 94.5–96.6% of starting weight (E10) | High background mortality caps achievable survival near 80% and confounds the day-60 cohorts | Reported; requires colony health review |
| I-06 | Alveolar-macrophage (S11-A) and neutrophil (S11-B) blocks share 35/100 cells exactly; neither shares more than 1 with the NK block (S11-D) | Myeloid kinetics unusable | Both excluded |
| I-07 | S09-A's second panel is labelled 16 h, but its Ifnb1 row equals log10 of the S01-A **72 h** values for all 7 arms | It describes resolution, not induction | Analysed as 72 h (inferred) |
| I-09 | Challenge virus, dose and timing not stated for the C57BL/6 (S15-L) and Swiss Webster (S15-N) studies | Strain-generality claim cannot be specified | Excluded from S2–S4 |
| I-10, I-11, I-12 | Other design conflicts:<br>• NP366 tetramer blocks: n = 2 not 3; antigen contradictory; H-2Db epitope in H-2d mice.<br>• OT-I assay: donor strain not stated.<br>• Macrophage-transfer block: both arms carry the same label. | Mechanistic details weakened | S05-A/B and S07-C excluded; S02-E supportive only |

**What this means for the decision:**

1. **The immunology carries the case.** The innate, humoral and cellular blocks (S01, S02, S03-A/C/D/E/G/H/K/L, S04, S05-D to S05-I, S13-A–D/H–J, S14) show no duplicated values and no internal contradiction. The exceptions are the S03-B/F label error and minor metadata gaps (unstated time points or strains; I-11, I-15, I-16). They support the immunogenicity and mechanism arguments.
2. **The survival records are the weak point.** They are the only efficacy evidence, and this file cannot verify them.
3. **Taken at face value, the survival effect is not an artefact of the detected errors.** It holds under every exclusion I could justify:

| Scenario | Experiments | PSLN-344 | PSLN-212 | Risk difference [95% CI] | ID |
|---|---|---|---|---|---|
| S1 all aged head-to-head (S06-D excluded) | 10 | 61/73 (84%) | 9/73 (12%) | +71 [60, 82] | E01 |
| S2 minus label conflicts and unstated challenges | 6 | 32/42 (76%) | 4/42 (10%) | +67 [52, 82] | E02 |
| S3 minus any survival/weight discordance | 3 | 16/21 (76%) | 2/21 (10%) | +67 [45, 89] | E03 |
| S4 S2 with worst-case counts from either record | 6 | 32/42 (76%) | 5/42 (12%) | +64 [49, 80] | E04 |

Whether the records are genuine is a question only source data (G1) or an independent repeat (G2) can answer. That is why the recommendation is gated.

# 4. What is actually driving the protection

**Short answer:**

- **Trigger.** Mn²⁺ restores the early type-I-IFN / GM-CSF / CCL2 signal that aged lungs fail to mount with the same CDN in a Mn-free particle.
- **Relay.** That reopens the monocyte → monocyte-derived DC (moDC) → migratory-DC relay, which restores both antibody and cross-reactive CD8/TRM responses.
- **Effector.** Protection needs antigen, so it is adaptive immunity, not an innate antiviral state. In most of the challenge models vaccine-strain antibody cannot neutralise the challenge virus, so cross-reactive cellular (or non-neutralising) immunity must carry much of the protection.
- **Strength of evidence.** The data establish strong association and several necessary steps; they do not yet prove which effector is sufficient.

**1. The variable is Mn²⁺, acting as a pharmacological potentiator. It is not more drug and not better targeting.**

- PSLN-344 and PSLN-212 share lipids and the CDN-1807 payload (annotation, Materials).
- Mn²⁺ does not increase loading: encapsulation is 54.8% vs 59.6% (p = 0.29; E49).
- It *reduces* alveolar-epithelial uptake about fourfold (AECII 3.8% vs 15.8%; E50).

**2. The aged innate deficit, and its restoration.**

- **16 h IFN-β.** With Mn-free PSLN-212, aged lungs make 16.5× Ifnb1 against 37.5× in young lungs. Mn²⁺ restores it exactly: 36.9×, ratio to young 0.98 [0.84–1.16] (E35).
- **Dose-response.** The effect is dose-dependent (E39). PSLN-344 matches PSLN-212's 40 µg response at about 8 µg (roughly fivefold dose-sparing) and has a 3.4× higher ceiling. The age of these animals is not stated.
- **GM-CSF and CCL2.** PSLN-344 also induces lung GM-CSF (×5.4 at 36 h; E40). It induces CCL2 (the CCR2 ligand) ×77 at 16 h (E38, n = 3).

**3. The cellular relay (aged PSLN-344 vs PSLN-212; young PSLN-212 in brackets):**

| Step | Observation | Intervention that breaks it | ID |
|---|---|---|---|
| Monocyte recruitment | Lung monocytes day 4: 30.6% vs 16.7% [32.2%] | CCR2 antagonist −67%; gap-junction blocker carbenoxolone −58% | E41, E46 |
| Monocyte → moDC | CD11b⁺ DC day 4: 18.9% vs 8.3% [21.4%] | IFNAR⁻/⁻ bone marrow −89%; GM-CSF restores to 63% of wild type. GM-CSF added to PSLN-212 raises moDC 5.9% → 13.8% | E41, E45, E46 |
| DC migration / antigen delivery | CCR7⁺ DC 30.7% vs 7.3% [35.0%]; antigen⁺ MLN DC 7.1% vs 1.8% [9.4%] | Pertussis toxin (blocks migration): antigen⁺ DC −67% (arm composition not stated; I-11); MLN priming −78%; lung priming unchanged (−7%) | E42, E47 |
| T-cell help | ICOS-high Tfh 10.3% vs 3.8% [13.6%]; follicular regulatory T cells (Tfr) 10.8% vs 26.7% [7.1%] | — | E26 |
| Germinal centre → antibody | GC B cells 6.5% vs 2.3% [9.8%]; Aicda ×3.5; IgG ×13–19; HAI ×8–9; IgG2a shift | — | E15–E25 |
| CD8 effector / memory | IFN-γ⁺ recall 6.4% vs 1.5% [9.2%]; lung TRM 4.0% vs 1.0% [6.0%] | CCR2 antagonist −79% lung GZMB⁺ CD8 (young mice) | E29, E32, E46 |

**4. The effector.**

- **Antigen is required.** Adjuvant alone does not protect (0/7; E52).
- **Matched strains.** Restoring 80–94% of the aged HAI/MN deficit (gap closure, E55) would plausibly explain protection against matched strains.
- **Heterosubtypic challenges.** Four of the six best-documented experiments share **no HA or NA subtype** between vaccine and challenge virus, and PSLN-344 still protects 20/28 against 1/28 (E57). There, vaccine-strain neutralising antibody cannot be the effector. The candidates are:
  - cross-reactive CD8 T cells and lung TRM (×4.2 and ×4.0; E29, E32);
  - non-neutralising, Fc-competent antibody to conserved antigens (the IgG2a shift, E23).
- **What the file cannot do.** It contains no CD8-depletion, TRM-blockade or passive-serum experiment, so it cannot separate these candidates. Study A2 does.

**5. What is not restored, and therefore not required at young levels:**

- **DC co-stimulation.** PSLN-344 closes only 17–22% of the aged deficit in CD40/CD86 (E43), yet closes 74% of the survival gap (E56).
- **Resolution.** At 72 h aged PSLN-344 lungs still carry Ifnb1 2.85× above young (E36). Tnf and Il10 are also elevated in the inferred-72 h panel (E37).
- **Durability.** Aged protection falls from 93% (day-14 challenge) to 67% (day-60). MLN IFN-γ⁺ CD8 memory is, if anything, *higher* at day 60 (9.9% vs 6.4%, separate cohorts; E29, E30). So the compartment that wanes is probably not lymph-node memory. Lung TRM and mucosal antibody are the prime suspects; neither was measured after day 25.
- **Background mortality.** Part of the day-60 decline may be background mortality in the aged colony (I-08). A1 tests this with unchallenged controls and cause-of-death virology.

![Figure 2. Gap closure: fraction of the aged-vs-young deficit restored by PSLN-344 for every valid readout, against the survival gap closure (green band). Sources: E55, E56.](figures/fig2_gap_closure.png)

# 5. Is there a biomarker of efficacy worth carrying forward?

**Yes, one. It belongs in a pharmacodynamic role, not as a surrogate of protection.**

I scored candidates on five criteria:

- moves with protection across groups (gap closure comparable to survival's 0.74 [0.58–0.87]);
- sits upstream, and causally, in the mechanism;
- is measurable early;
- is dose-responsive;
- is accessible in people.

| Candidate | Gap closure | Timing | Dose-responsive | Causal link | Accessible in people | Verdict |
|---|---|---|---|---|---|---|
| **Early type-I IFN (lung Ifnb1, 16 h)** | **0.98 [0.84–1.13]** | 16 h | Yes (E39) | IFNAR needed for moDC (E45) | Via nasal / blood ISG score (needs bridging) | **Carry forward: PD / target-engagement and dose-selection marker** |
| IFN resolution (Ifnb1, 72 h) | −0.24 (overshoot) | 72 h | — | — | Nasal / blood ISG | **Carry forward: tolerability marker** (must fall toward baseline) |
| HAI / microneutralisation | 0.80–0.94 | d14–28 | Not tested | Effector for matched strains | Standard | Carry as immunogenicity endpoint; blind to breadth |
| Cross-reactive IFN-γ⁺ CD8; lung TRM | 0.59–0.75 | d14–25 | Not tested | Likely heterosubtypic effector | Blood ELISpot yes; TRM no | Carry as exploratory breadth marker |
| Tfr (Foxp3⁺ fraction of CXCR5⁺ICOS-high CD4), day 7 | 0.81 [0.67–0.99] | d7 | Not tested | Plausible | Circulating Tfr measurable | Exploratory |
| CCL2 / GM-CSF | 0.84 (Ccl2); no young comparator for GM-CSF | 16–36 h | Not tested | GM-CSF substitutes for IFNAR (E45) | Nasal | Secondary PD analytes |
| DC CD40 / CD86 | 0.17 / 0.22 | d3 | — | Not required (see Section 4) | — | Ruled out |

**Why IFN is a PD marker, not a surrogate.** PSLN-344 *alone* produces the IFN response (S01-A dosed adjuvant without vaccine) but does not protect (0/7; E52). In aged lungs the 72 h value overshoots (E36). IFN therefore tells you whether the adjuvant engaged its target at the right dose, not whether the animal or patient is protected.

**Its role in patients.** In first-in-human studies, a nasal-mucosal and blood interferon-stimulated gene (ISG) score at 6–24 h and at 72 h after dosing would do three things:

1. Confirm that Mn²⁺ potentiates STING signalling in older humans, as an early go/no-go before spending on efficacy.
2. Select the lowest dose that reaches the young-adult response. The mouse data suggest roughly fivefold dose-sparing.
3. Screen out doses with non-resolving inflammation.

HAI/MN remain the efficacy-predictive endpoints, because they are the ones regulators recognise. A cross-reactive T-cell readout (IFN-γ ELISpot against conserved NP/M1 epitopes) should be exploratory, to test the breadth hypothesis.

**What it would take to become a correlate.** This file cannot establish any correlate of protection, because immunogenicity and challenge were measured in *different* animals. Study A1 fixes that:

- pre-challenge samples taken from every challenged animal;
- PSLN-344 dose arms to create spread;
- individual-level modelling of survival on the pre-challenge markers.

A1 also bridges the lung IFN readout to nasal and blood ISGs in the same mice.

![Figure 5. Innate PD candidates: lung Ifnb1 at 16 h and 72 h by arm (E35, E36); Ifnb1 dose-response (E39); Gm-csf kinetics (E40).](figures/fig5_innate_pd.png)

# 6. What the next studies must establish

**Stage A: confirm and de-risk (months 0–12; gates G1–G3)**

| Study | Question it answers | Timing | Gate |
|---|---|---|---|
| A0 Source-data verification | Are the flagged records genuine? | Months 0–2 | G1 |
| A1 Confirmatory efficacy + correlates | Does the aged rescue reproduce, beat standard of care and last? Which pre-challenge marker predicts survival? | Months 0–10 | G2 |
| A2 Effector attribution | Which compartment protects (CD8, TRM or antibody)? | Months 3–9 | Chooses the breadth biomarker |
| A3 Manganese nose-to-brain safety | Does intranasal Mn reach or injure olfactory or brain tissue? Does aged-lung inflammation resolve? | Months 1–8 | G3 |
| A4 Human-relevance bridge | Does Mn²⁺ potentiate STING signalling in aged human cells? | Months 1–6 | Deprioritise if not |
| A5 CMC characterisation | Can we specify what we dose? | Months 0–9 | GLP-lot readiness |

**A0. Source-data verification (QA-led)**

| Field | Content |
|---|---|
| Population / material | Records for I-01 to I-12:<br>• survival logs S06-A–G, S03-I/J, S15-H/L/N<br>• balance records for all weight blocks<br>• FlowJo workspaces S11<br>• qPCR exports S09-A<br>• aged-colony health and death logs |
| Comparators | — |
| Endpoints / readouts | Reconciled, locked dataset v2; list of experiments that must be repeated |
| Timing | Months 0–2 |
| Decision rule | **G1:** raw records support PSLN-344 and PSLN-212 outcomes in ≥4 of the 6 S06 experiments. Otherwise efficacy rests entirely on A1. Stop if PSLN-344 arms were not generated as recorded (K4) |

**A1. Confirmatory efficacy + correlates** (independent lab or CRO; randomised, blinded, pre-registered analysis plan)

| Field | Content |
|---|---|
| Population / model | BALB/c ≥20 months, both sexes (stratified randomisation). Young (8–10 weeks) reference arm. Unvaccinated, unchallenged aged controls (to measure background mortality). Health-screened colony |
| Arms and comparators | All intranasal unless stated:<br>• bivalent inactivated vaccine + PSLN-344 at 5, 10 and 20 µg<br>• + PSLN-212 20 µg (Mn-free; isolates Mn)<br>• + empty liposome<br>• PSLN-344 alone (no antigen)<br>• **IM benchmark:** same antigen IM with a squalene-emulsion adjuvant and/or high-dose IM antigen (standard-of-care proxy)<br>• young + PSLN-212 |
| Primary endpoint | 14-day survival after heterosubtypic challenge at day 28, with a virus sharing no HA/NA subtype with the vaccine (e.g. H3N2 vaccine → PR8 H1N1, 5× mLD50); PSLN-344 20 µg vs PSLN-212 |
| Key secondary endpoints | • lung viral titre on days 3 and 5 (satellite animals); primary for the IM-benchmark comparison<br>• weight-loss AUC and clinical score<br>• homologous CA09 challenge<br>• durability challenge at day 90 (day 180 if day 90 passes)<br>• cause of death for every death (virology / necropsy) |
| Same-animal pre-challenge readouts (for correlates) | • nasal-wash and blood ISG score at 16–24 h (PD bridge)<br>• serum HAI, MN, IgG/IgG2a/IgG1, anti-NA and anti-stalk at day 21<br>• nasal IgA at day 21<br>• blood IFN-γ ELISpot (NP/M1 peptides) at day 14 |
| Timing | Aged-mouse procurement months 0–2; dosing months 2–3; day-28 challenge months 3–4; day-90 challenge months 5–6; day-180 challenge months 8–9; primary (day-28 challenge) readout about month 5 |
| Sample size (planning) | • 23/arm (28 allowing 20% non-evaluable) for survival vs PSLN-212, assuming 60% vs 15% with 90% power<br>• 14/arm for the lung-titre benchmark comparison (Δ 1.0 log10, SD 0.8)<br>• a survival-based benchmark comparison would need 42–56/arm, so it is not recommended as primary |
| Analysis | Stratified log-rank; Mantel-Haenszel risk difference; individual-level logistic regression of survival on pre-challenge markers (the dose arms create the spread) |
| Decision rule | **G2:**<br>• survival gain ≥40 points vs PSLN-212 (lower 95% CI >20)<br>• ≥1.0 log10 lower lung titre than the IM benchmark in the heterosubtypic model, and non-inferior (margin 0.5 log10) in the homologous model<br>• ≥60% survival at day 90 |

**A2. Effector attribution**

| Field | Content |
|---|---|
| Population / model | Aged mice given vaccine + PSLN-344 |
| Arms and comparators | Before heterosubtypic challenge:<br>• anti-CD8β, anti-CD4 or isotype control<br>• FTY720 (circulating vs resident T cells)<br>• passive transfer of immune serum from aged PSLN-344 donors into naive aged recipients<br>• FcγR- or B-cell-deficient aged C57BL/6 if available |
| Endpoints / readouts | Survival; lung viral titre; lung TRM and nasal IgA at challenge; anti-NA / anti-stalk Fc-effector function |
| Timing | Months 3–9 |
| Decision rule | Defines which breadth correlate goes into Phase 1 (T-cell vs antibody) |

**A3. Manganese nose-to-brain safety and biodistribution** (non-GLP pilot, then GLP in Stage B)

| Field | Content |
|---|---|
| Population / model | Aged and young mice; rats as second species; both sexes |
| Arms and comparators | • PSLN-344 at 1× and 3× the efficacious dose, single and repeat dosing (3 doses, 2–4 weeks apart)<br>• PSLN-212 (Mn-free)<br>• MnCl₂ at matched Mn<br>• vehicle<br>• cholera toxin (CNS positive control, as in S10-A) |
| Endpoints / readouts | • Mn by ICP-MS in olfactory bulb, striatum / globus pallidus, cortex, nasal turbinates, lung, blood and liver at 1 h, 24 h, 7 d and 28 d<br>• buried-food olfaction test; open field; rotarod<br>• histopathology of olfactory epithelium and bulb<br>• region-specific CNS ISG and cytokines, 6 h–7 d<br>• lung histology and cytokines at 72 h and 7 d |
| Timing | Months 1–8 |
| Decision rule | **G3:**<br>• no dose-related brain Mn increase at the efficacious dose<br>• no olfactory injury or dysfunction<br>• aged-lung inflammation resolved by day 7<br>Otherwise K2 |

**A4. Human-relevance bridge**

| Field | Content |
|---|---|
| Population / model | Nasal epithelial air-liquid-interface cultures and blood monocytes from donors aged ≥65 vs 20–40 |
| Arms and comparators | PSLN-344 vs PSLN-212 vs free CDN |
| Endpoints / readouts | IFN-β / ISG, GM-CSF, CCL2; monocyte → DC differentiation; cytotoxicity. Locks the ISG score used in A1 and Phase 1 |
| Timing | Months 1–6 |
| Decision rule | ≥2-fold Mn-dependent potentiation in aged-donor cells (the human analogue of E35); otherwise deprioritise |

**A5. CMC characterisation**

| Field | Content |
|---|---|
| Endpoints / readouts | • Mn content and Mn:CDN ratio per dose (not reported anywhere; needed for A3 and toxicology)<br>• encapsulation specification (currently 54.8 ± 5.1%; E49)<br>• size / PDI / zeta (measured per annotation, no data in file)<br>• lyophilised stability (trehalose 2.5%, −20 °C) at 0, 3, 6 and 12 months<br>• IFN-β reporter potency assay |
| Timing | Months 0–9 |
| Decision rule | Release specification available for GLP lots |

**Stage B: IND-enabling (about months 10–22, only if G1–G3 pass).**

- GLP repeat-dose intranasal toxicology with local (nasal) tolerance and CNS safety pharmacology.
- GLP biodistribution including Mn.
- GMP lot manufacture.
- Pre-IND meeting.

**Stage C: first-in-human (month 24 onward).**

- **Design:** randomised, observer-blind, dose-escalation Phase 1, with sentinel dosing.
- **Population:** healthy adults ≥65 years (stratified 65–74 and ≥75), plus an 18–49-year cohort at the selected dose to age-bridge the PD marker.
- **Comparators:** intranasal antigen without adjuvant; a licensed enhanced IM vaccine for ≥65 (active reference); intranasal placebo.
- **Primary endpoints:**
  - solicited nasal and systemic reactions on days 0–7;
  - unsolicited adverse events to day 28;
  - serious adverse events and adverse events of special interest to day 180: facial palsy, smell loss (standardised smell test), neurological examination;
  - blood Mn.
- **Secondary endpoints:** HAI/MN GMT and seroconversion at day 28; nasal IgA at days 14 and 28.
- **PD:** nasal and blood ISG score at 6–24 h and 72 h.
- **Exploratory:** circulating Tfh/Tfr at day 7; IFN-γ ELISpot to NP/M1 on days 14, 28 and 180; durability to day 180.
- **Dose-selection rule:** the lowest dose whose ISG response reaches the 18–49 reference, returns toward baseline by 72 h, and has acceptable reactogenicity.

**Initial clinical positioning to test.** The data are strongest for breadth, rapid onset and aged-specific rescue, and weakest for durability and standard-of-care comparison (Sections 2 and 4). The first clinical hypothesis should therefore be an intranasal adjuvant co-administered with inactivated antigen in people ≥65, for:

- pandemic or pre-pandemic (e.g. H5) preparedness;
- rapid early-season protection.

Seasonal use should be contingent on A1's day-90/180 durability result. This is a positioning to test, not a claim the data already support.

# 7. If we drop it: what we would be dropping, and why

**What we would be dropping:**

- **The only formulation in this dataset that protects aged mice against heterosubtypic influenza.**
  - 76% survival vs 10% with the Mn-free particle and 0% with vehicle (E02, E05).
  - 71% vs 4% where vaccine and challenge virus share no HA or NA subtype (E57).
  - Rapid onset when given with antigen (E11).
- **Near-complete, dose-sparing restoration of the aged lung's early innate deficit** (E35, E39), and restoration of 80–94% of the aged HAI/MN deficit (E55).
- **A mechanistic map of immunosenescent vaccine failure in the lung** (IFNAR/GM-CSF-dependent moDC relay; E45–E47) and a PD-biomarker concept, both reusable for other older-adult vaccine programmes.
- **An option on pandemic preparedness** for the age group at highest risk.

**The defensible reasons to drop are:**

- G1 and A1 both fail: the records cannot be verified and the effect does not reproduce.
- G3 fails: Mn reaches the olfactory pathway or brain at the efficacious dose.
- K3: there is no differentiation from IM standard of care.

**"The immunology is weak" is not a defensible reason.** It is not weak.

**What to keep if we drop:**

- the locked dataset and this audit;
- the aged-lung PD assay and gap-closure framework;
- the GM-CSF observation as a Mn-free fallback hypothesis. GM-CSF added to PSLN-212 more than doubles moDC (5.9% → 13.8%; E46), but there are no immunogenicity or protection data for it.

# 8. What I considered and ruled out

**Decision options**

| Option | Why not |
|---|---|
| Go to IND-enabling now | Unverifiable survival records (I-01 to I-04); intranasal Mn untested; no standard-of-care comparator; aged durability 67% at day 60 (E08) |
| Drop now | Discards a large, internally controlled immunological signal that is not implicated in the duplication or record-conflict findings (E15–E35). The confirmatory stage is cheap relative to what it resolves |
| Switch to Mn-free PSLN-212 to avoid Mn risk | Fails in aged mice: 10% survival; IgG 1/19th and HAI 1/8th of PSLN-344 (E02, E15, E17) |
| Switch to PSLN-212 + GM-CSF | Only moDC data exist (E46). Keep as a backup hypothesis |
| Add TLR7/8 agonist (R848) | PSLN-212/R848 weight nadir 90.0% with one of five animals lacking a day-10 record (E53). High Tnf/Il10 at 72 h (E37). Mn + R848 gives less IFN than PSLN-344 alone (E39) |
| cGAMP liposome (CMP-204) | Weakest innate and humoral responses in aged mice: Ifnb1 7.7×; HAI GMT 23 (E58) |

**Scientific explanations ruled out by the data**

| Hypothesis | Evidence against |
|---|---|
| A non-specific innate antiviral state protects | Adjuvant alone 0/7 (E52) |
| Mn²⁺ works by loading more CDN | Encapsulation 54.8% vs 59.6% (E49) |
| Mn²⁺ works by better epithelial targeting | Epithelial uptake is about fourfold *lower* (E50) |
| Protection requires young-level DC co-stimulation | CD40/CD86 gap closure 0.17/0.22, against survival gap closure 0.74 (E43, E56) |
| Vaccine-strain HAI antibody explains protection | 71% vs 4% where no HA/NA subtype is shared (E57) |
| The Mn benefit can be shown in young mice | Both adjuvants give 100% survival in young mice (E12); young mice do not discriminate |
| Prior influenza exposure is needed, or interferes | PSLN-344 6/7 with and without prior PR8 (E13; 14-month-old mice) |
| The day-60 decline reflects lost lymph-node T-cell memory | MLN IFN-γ⁺ CD8 is higher at day 60 than day 14 (separate cohorts; E29, E30) |

**Analytical choices ruled out**

| Choice | Why |
|---|---|
| Use S03-B/F IgG2a/IgG1 as printed | Group labels rotated (I-05) |
| Count S06-D as independent day-3 evidence | Verbatim copy of S06-C (I-01) |
| Use body weights to corroborate survival | Duplicated trajectories (I-02) |
| Read S09-A panel 2 as 16 h | It is 72 h (I-07) |
| Use S11-A/B, S05-A/B, S07-C | Duplicated cells, design conflicts, duplicate labels (I-06, I-10, I-12) |
| Arithmetic means for titres; HAI "0" as zero | Titres are log-normal; "0" is below LOD, so set to 5 |
| Group-mean weight curves | Dead animals are carried forward in some arms and blank in others |
| Count Tfh:Tfr as separate evidence | It is an algebraic transform of the Foxp3% block (I-17) |
| Pool the 14-month imprinting or young experiments with aged | Different populations (I-19) |
| Rely on p-values | Many contrasts; p-values are nominal. The decision rests on effect sizes, consistency and the sensitivity scenarios |

# Appendix A. Methods

**Extraction.** Explicit cell ranges for every block (`code/extract.py`). A coverage check confirmed that every numeric cell was captured exactly once; the only unassigned region is S08!A89:D101. Linked-block reconciliation and duplicate searches are in `code/integrity_checks*.py`, `bw_duplication*.py`, `bw_null.py`, `derived_checks.py` and `bw_survival_concordance.py`.

**Continuous endpoints** (`code/stats_continuous.py`).

- Per-group GM or mean with t-based 95% CI.
- Pre-specified contrasts:
  - C1: PSLN-344 vs PSLN-212 (aged);
  - C2: PSLN-344 (aged) vs PSLN-212 (young);
  - C3: PSLN-344 vs sham vehicle.
- Welch CIs.
- Exact Mann-Whitney as a sensitivity analysis.
- The stated one-way ANOVA + Tukey is in `tables/continuous_anova_tukey.csv`.

**Survival** (`code/stats_survival.py`).

- Survivors censored at end of observation.
- The S03-J record with no time is censored at 21 d; all PSLN-344 animals in S03-J survived, so this does not affect the result.
- Log-rank is validated against lifelines (identical p-values).
- Clopper-Pearson CIs for proportions.
- Mantel-Haenszel risk difference with Sato variance, cross-checked by stratified bootstrap (S2: [50, 81] vs [52, 82]).
- Scenarios S1–S4 are defined in Section 3.

**Gap closure** (`code/gap_closure.py`).

- Formula: (aged PSLN-344 − aged PSLN-212) / (young PSLN-212 − aged PSLN-212), on the log10 scale for titres and fold-changes.
- CI by bootstrap with 5,000 resamples of animals within arms.
- Survival gap closure uses the same formula on S2 proportions.

**Planning sample sizes.** Normal approximation (arcsine effect size) for proportions; two-sample normal approximation for log titres; assumptions stated in Section 6.

# Appendix B. Files

| File | Content |
|---|---|
| `PSLN-344_portfolio_memo.md` / `.docx` / `.html` | This document |
| `evidence_register.csv` | 58 evidence entries (E01–E58) with cells and reductions |
| `data_integrity_findings.csv` | 22 integrity findings (I-01–I-22) with cells, detection method, impact, handling and action |
| `PSLN-344_evidence_and_integrity_registers.xlsx` | Both registers plus every supporting table: survival, contrasts, gap closure, duplicated trajectories, survival-vs-weight reconciliation |
| `tables/` | Machine-readable outputs |
| `figures/` | Figures 1–5 (Figure 3: humoral titres; Figure 4: integrity examples) |
| `code/` | Full pipeline. `code/run_all.sh` reruns everything from the workbook in dependency order (extract → integrity checks → weight-duplication and reconciliation → statistics → gap closure → figures → registers → memo conversion) |
| `tidy_data/` | Every extracted value with its source cell (`values.csv`, `survival.csv`, `bodyweight.csv`) |

![Figure 3. Humoral responses at day 14 and day 28 (post-boost) by arm; bars are GMT with 95% CI. Sources: E15–E22.](figures/fig3_immunogenicity.png)

![Figure 4. Integrity examples. (a) S06-C vs S06-D survival curves are identical (I-01). (b) Body-weight trajectories of S15-C PSLN-344 reappear in S15-I (I-02). (c) 35 of 100 cells are identical between the alveolar-macrophage (S11-A) and neutrophil (S11-B) blocks (I-06). (d) S03-B printed ratios vs ratios recomputed from S13 (I-05).](figures/fig4_integrity_examples.png)

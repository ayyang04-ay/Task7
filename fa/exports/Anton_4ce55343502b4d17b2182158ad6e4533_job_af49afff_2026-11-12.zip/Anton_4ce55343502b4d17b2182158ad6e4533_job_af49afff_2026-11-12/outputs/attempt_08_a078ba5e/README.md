# PSLN-344 portfolio review package

Start with **`PSLN-344_portfolio_memo.docx`** (same content as `.html` / `.md`): the recommendation, the evidence, the data-integrity audit, the mechanism, biomarker and forward plan, and what was ruled out.

| File | Purpose |
|---|---|
| `PSLN-344_portfolio_memo.docx` / `.html` / `.md` | The position paper |
| `evidence_register.csv` | Every number in the memo (E01–E58): value, source block and cells, reduction method, integrity status |
| `data_integrity_findings.csv` | The 22 data-integrity findings (I-01–I-22): cells, how detected, impact, handling, action |
| `PSLN-344_evidence_and_integrity_registers.xlsx` | Both registers plus all supporting tables in one workbook |
| `tables/`, `figures/`, `tidy_data/` | Computed statistics, figures, extracted per-animal data with cell provenance |
| `code/run_all.sh` | Regenerates everything from `adjuvant_program_dataset.xlsx` |

import pandas as pd, numpy as np, itertools
b = pd.read_csv('/tmp/work/tidy/bodyweight.csv'); v = pd.read_csv('/tmp/work/tidy/values.csv')
v['time'] = v['time'].fillna('-').astype(str)
# per-animal trajectories
traj = {k: d.sort_values('day').set_index('day').value for k, d in b.groupby(['block','group','animal'])}
cells = {k: d.sort_values('day').set_index('day').cell for k, d in b.groupby(['block','group','animal'])}
print('=== animal trajectories sharing >=3 identical non-100 values (same day) with a trajectory in a different block/group')
rows = []
keys = list(traj)
for a, c in itertools.combinations(keys, 2):
    if a[:2] == c[:2]: continue
    x, y = traj[a], traj[c]
    common = x.index.intersection(y.index)
    same = [d for d in common if d > 0 and np.isclose(x[d], y[d]) and (abs(x[d]*1e4 - round(x[d]*1e4)) > 1e-6 or len(repr(x[d]).split('.')[-1]) >= 1)]
    # require non-trivial values (exclude LOCF repeats inside the same trajectory being compared to same numbers)
    same = [d for d in same if not np.isclose(x[d], 100)]
    frac_same = [d for d in common if d > 0 and not np.isclose(x[d], y[d]) and np.isclose((x[d] % 1), (y[d] % 1), atol=1e-6) and len(repr(float(x[d])).split('.')[-1]) >= 4]
    if len(same) >= 3 or (len(same) + len(frac_same) >= 3 and len(frac_same) >= 1):
        rows.append((a, c, len(same), len(frac_same), sorted(same), sorted(frac_same)))
for a, c, n1, n2, s1, s2 in sorted(rows, key=lambda r: -(r[2] + r[3])):
    print(f'{a}  <->  {c}: identical days={s1}  integer-shifted days={s2}')
    print('    ', [round(traj[a][d], 5) for d in traj[a].index], '\n    ', [round(traj[c][d], 5) for d in traj[c].index])
    print('     cells:', cells[a].iloc[1], '..', cells[a].iloc[-1], ' vs ', cells[c].iloc[1], '..', cells[c].iloc[-1])

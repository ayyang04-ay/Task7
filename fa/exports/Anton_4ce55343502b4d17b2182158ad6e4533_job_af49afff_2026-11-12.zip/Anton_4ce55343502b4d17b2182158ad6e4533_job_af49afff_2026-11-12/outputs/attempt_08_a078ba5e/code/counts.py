import pandas as pd
v = pd.read_csv('/tmp/work/tidy/values.csv'); s = pd.read_csv('/tmp/work/tidy/survival.csv'); b = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
print('=== continuous: n per block/group/time')
v['time'] = v['time'].fillna('-')
print(v.groupby(['block','time','group'], sort=False).size().unstack('group').to_string())
print('\n=== survival: n, deaths, survivors, missing time')
t = s.groupby(['block','group'], sort=False).agg(n=('event','size'), deaths=('event','sum'), missing_time=('time', lambda x: x.isna().sum()),
     death_days=('time', lambda x: None)).reset_index()
for (blk, g), d in s.groupby(['block','group'], sort=False):
    dd = sorted(d.loc[d.event==1,'time'].tolist()); cens = sorted(d.loc[d.event==0,'time'].tolist())
    print(f'{blk:16s} {g:24s} n={len(d):2d} deaths={int(d.event.sum()):2d} surv={int((d.event==0).sum()):2d}  death_days={dd}  censor_times={cens}')

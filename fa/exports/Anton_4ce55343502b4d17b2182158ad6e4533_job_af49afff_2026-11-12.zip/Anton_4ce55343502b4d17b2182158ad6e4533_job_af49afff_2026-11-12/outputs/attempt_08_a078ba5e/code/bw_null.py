import pandas as pd, numpy as np, itertools, collections
rng = np.random.default_rng(1)
b = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
def nd(x): return len(repr(float(x)).split('.')[-1])
traj = {k: d.sort_values('day').set_index('day').value for k, d in b.groupby(['block','group','animal'])}
def informative(series):
    out = {}; prev = None
    for d, val in series.items():
        if d == 0: prev = val; continue
        if prev is not None and np.isclose(val, prev): prev = val; continue
        out[d] = round(val, 6); prev = val
    return out
inf = {k: informative(t) for k, t in traj.items()}
# observed count of pairs with >=3 same-day LOW-precision identical values
def count_pairs(infd):
    keys = list(infd); c3 = 0
    for a, c in itertools.combinations(keys, 2):
        if a[:2] == c[:2]: continue
        xa, xc = infd[a], infd[c]
        m = sum(1 for d in xa if d in xc and xa[d] == xc[d] and nd(xa[d]) < 4)
        c3 += m >= 3
    return c3
obs = count_pairs(inf)
# null: for each day, permute low-precision values across trajectories (preserves per-day value distribution, breaks animal identity)
null = []
for it in range(20):
    perm = {k: dict(v) for k, v in inf.items()}
    byday = collections.defaultdict(list)
    for k, dct in perm.items():
        for d, val in dct.items(): byday[d].append((k, val))
    for d, lst in byday.items():
        vals = [x[1] for x in lst]; rng.shuffle(vals)
        for (k, _), nv in zip(lst, vals): perm[k][d] = nv
    null.append(count_pairs(perm))
print('observed pairs with >=3 same-day low-precision matches:', obs)
print('day-matched permutation null (20 reps): mean', np.mean(null), 'max', max(null), null)

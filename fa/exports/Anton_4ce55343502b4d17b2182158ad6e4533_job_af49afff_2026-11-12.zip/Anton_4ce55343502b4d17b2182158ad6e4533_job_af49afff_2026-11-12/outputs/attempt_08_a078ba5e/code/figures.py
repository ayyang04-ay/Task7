import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats
plt.rcParams.update({'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150})
v = pd.read_csv('/tmp/work/tidy/values.csv'); v['time'] = v['time'].fillna('-').astype(str)
s = pd.read_csv('/tmp/work/tidy/survival.csv'); b = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
G = pd.read_csv('/tmp/outputs/tables/survival_group_summaries.csv'); Q = pd.read_csv('/tmp/outputs/tables/survival_pooled_scenarios.csv')
COL = {'Sham': '#9e9e9e', 'CMP-204': '#8c6d31', 'PSLN-212': '#d95f02', 'PSLN-344': '#1b9e77', 'PSLN-212(Y)': '#7570b3', 'PSLN-344(Y)': '#e7298a'}
# ---------------- Figure 1: survival overview
rows = [('S03-I', 'CA09 vax -> CA09 10xLD50, d14', 'arms/outcomes conflict with its weight block S13-F'),
        ('S03-J', 'rgH5N1 vax -> WT H5N1, d2', 'arms/outcomes conflict with S13-G; n 9 stated, 10 rows'),
        ('S06-A', 'Aichi H3N2 -> PR8 H1N1, d14', 'weight block S15-A shares trajectories with S15-M/J'),
        ('S06-B', 'Aichi H3N2 -> PR8 H1N1, d3', ''),
        ('S06-C', 'H1+H3 -> rgH5N1, d14', 'weights (S15-C) copied into S15-I; PSLN-212 5 vs 6 deaths'),
        ('S06-D', 'H1+H3 -> rgH5N1, d3', 'EXACT COPY of S06-C - excluded (S15-D weights: 2/7 PSLN-344 deaths)'),
        ('S06-E', 'Aichi H3N2 -> PR8 H1N1, d60', 'survival vs weight deaths differ (212: 7 vs 6; 344: 2 vs 1)'),
        ('S06-F', 'H1+H3 -> rgH5N1, d60', 'weight block S15-F shares trajectories with S08-D'),
        ('S06-G', 'CA09 H1N1 -> Perth H3N2, d60', 'PSLN-344 3 vs 2 deaths; 3/7 UNCHALLENGED controls died'),
        ('S15-L', 'C57BL/6, H1+H3 -> challenge not stated', 'challenge not stated; weights (S15-M) copied from S15-A/S09-E'),
        ('S15-N', 'Swiss Webster, H1+H3 -> challenge not stated', 'challenge not stated')]
fig = plt.figure(figsize=(12.5, 7.6)); ax = fig.add_axes([0.27, 0.30, 0.36, 0.66])
arms = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']; off = dict(zip(arms, [-0.27, -0.09, 0.09, 0.27]))
for i, (blk, lab, flag) in enumerate(rows):
    y = len(rows) - 1 - i
    for a in arms:
        r = G[(G.block == blk) & (G.group == a)]
        if len(r):
            r = r.iloc[0]
            ax.errorbar(r.survival_pct, y + off[a], xerr=[[r.survival_pct - r.ci_lo], [r.ci_hi - r.survival_pct]], fmt='o', color=COL[a], ms=5, lw=1, capsize=2,
                        alpha=0.35 if blk == 'S06-D' else 1, label=a if i == 3 else None)
    fig.text(0.01, 0.30 + 0.66 * (y + 0.5) / len(rows), f'{blk}: {lab}', va='center', fontsize=8, color='grey' if blk == 'S06-D' else 'black')
    fig.text(0.645, 0.30 + 0.66 * (y + 0.5) / len(rows), flag, va='center', fontsize=7, color='#b2182b' if flag else 'black')
ax.set_ylim(-0.6, len(rows) - 0.4); ax.set_yticks([]); ax.set_xlim(-3, 103); ax.set_xlabel('14-day survival, % (Clopper-Pearson 95% CI); aged unless (Y)')
ax.axvline(50, color='k', lw=0.4, ls=':'); ax.legend(loc='upper center', bbox_to_anchor=(0.5, 1.055), ncol=4, frameon=False, fontsize=8)
ax.set_title('Aged-mouse challenge experiments (n=7 per arm; n=10 in S03-J)', fontsize=9, pad=26)
ax2 = fig.add_axes([0.27, 0.06, 0.36, 0.15])
q = Q[Q.comparison == 'PSLN-344 (aged) vs PSLN-212'].reset_index(drop=True)
labs = ['S1 all 10 blocks', 'S2 6 blocks (S06 A,B,C,E,F,G)', 'S3 3 blocks (S06 A,B,F)', 'S4 S2, worst-case counts']
for k, r in q.iterrows():
    ax2.errorbar(r.MH_risk_diff_pct, 3 - k, xerr=[[r.MH_risk_diff_pct - r.MH_rd_lo], [r.MH_rd_hi - r.MH_risk_diff_pct]], fmt='s', color='#1b9e77', capsize=3)
    fig.text(0.01, 0.06 + 0.15 * (3 - k + 0.5) / 4, f'{labs[k]}: {r.PSLN344_surv} vs {r.comparator_surv}', va='center', fontsize=7.2)
    fig.text(0.645, 0.06 + 0.15 * (3 - k + 0.5) / 4, f'{r.MH_risk_diff_pct:.0f} [{r.MH_rd_lo:.0f}, {r.MH_rd_hi:.0f}]', va='center', fontsize=7.2)
ax2.set_yticks([]); ax2.set_ylim(-0.6, 3.6); ax2.set_xlim(0, 100); ax2.axvline(0, color='k', lw=0.5)
ax2.set_xlabel('Pooled survival difference PSLN-344 minus PSLN-212, % points (Mantel-Haenszel, 95% CI)')
fig.savefig('/tmp/outputs/figures/fig1_survival_overview.png', bbox_inches='tight'); plt.close()
# ---------------- Figure 2: gap closure
R = pd.read_csv('/tmp/outputs/tables/gap_closure.csv')
fig, ax = plt.subplots(figsize=(8.5, 8.8))
fams = list(dict.fromkeys(R.family)); y = 0; yt = []; yl = []
fc = {'Innate (16-72 h)': '#e6ab02', 'Myeloid / DC (d3-d8)': '#66a61e', 'T follicular / GC (d5-d30)': '#7570b3', 'Antibody (d14-d28)': '#1b9e77', 'CD8 T cell (d3-d60)': '#d95f02'}
for f in fams:
    for _, r in R[R.family == f].iterrows():
        ax.errorbar(r.gap_closure, -y, xerr=[[r.gap_closure - r.ci_lo], [r.ci_hi - r.gap_closure]], fmt='o', color=fc[f], ms=4, capsize=2)
        yt.append(-y); yl.append(f'{r.readout}  [{r.block}]'); y += 1
    y += 0.6
# survival closure: pooled S2 (aged PSLN-212 4/42, PSLN-344 32/42, young 42/42)
sc = (32/42 - 4/42) / (1 - 4/42)
rng = np.random.default_rng(7); bs = []
for _ in range(5000):
    p344 = rng.binomial(42, 32/42) / 42; p212 = rng.binomial(42, 4/42) / 42; bs.append((p344 - p212) / (1 - p212))
lo, hi = np.percentile(bs, [2.5, 97.5])
ax.axvspan(lo, hi, color='#1b9e77', alpha=0.12); ax.axvline(sc, color='#1b9e77', lw=1.2)
ax.text(sc, 1.2, f'survival gap closure {sc:.2f} [{lo:.2f}-{hi:.2f}]\n(pooled S2 blocks)', ha='center', fontsize=7.5, color='#1b9e77')
ax.axvline(0, color='k', lw=0.6); ax.axvline(1, color='k', lw=0.6, ls='--')
ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=7); ax.set_xlim(-1.0, 1.8)
ax.set_xlabel('Gap closure = (aged PSLN-344 - aged PSLN-212) / (young PSLN-212 - aged PSLN-212)\n0 = no rescue, 1 = young level (log10 scale for titres/fold-changes); bootstrap 95% CI')
for f, c in fc.items(): ax.plot([], [], 'o', color=c, label=f)
ax.legend(loc='lower right', fontsize=7, frameon=False)
fig.savefig('/tmp/outputs/figures/fig2_gap_closure.png', bbox_inches='tight'); plt.close()
# ---------------- Figure 3: immunogenicity
fig, axs = plt.subplots(2, 4, figsize=(12, 5.8))
panels = [('S03-A', 'Serum IgG CA09 (d14)'), ('S03-C', 'HAI CA09 (d14)'), ('S03-D', 'MN CA09 (d14)'), ('S13-I', 'IgG CA09 d28 (boost d14)'),
          ('S03-E', 'Serum IgG Aichi (d14)'), ('S03-G', 'HAI Aichi (d14)'), ('S03-H', 'MN Aichi (d14)'), ('S13-J', 'IgG Aichi d28 (boost d14)')]
order = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
for axx, (blk, title) in zip(axs.flat, panels):
    for k, g in enumerate(order):
        x = v[(v.block == blk) & (v.group == g)].value.values.astype(float)
        if blk in ('S03-C', 'S03-G'): x = np.where(x <= 0, 5, x)
        lx = np.log10(x); m = lx.mean(); ci = stats.t.ppf(0.975, len(x) - 1) * lx.std(ddof=1) / np.sqrt(len(x))
        axx.scatter(k + np.linspace(-0.12, 0.12, len(x)), x, s=10, color=COL[g], alpha=0.7)
        axx.errorbar(k, 10 ** m, yerr=[[10 ** m - 10 ** (m - ci)], [10 ** (m + ci) - 10 ** m]], fmt='_', color='k', ms=14, capsize=3)
    axx.set_yscale('log'); axx.set_title(f'{title} [{blk}]', fontsize=8.5); axx.set_xticks(range(5)); axx.set_xticklabels(['Sham', 'CMP-204', '212', '344', '212(Y)'], fontsize=7.5)
    if blk in ('S03-C', 'S03-G'): axx.axhline(10, color='grey', lw=0.6, ls=':'); axx.text(4.4, 10, 'LOD 1:10', fontsize=6, va='bottom', ha='right')
fig.suptitle('Aged mice unless (Y); bars = geometric mean with 95% CI; HAI "0" plotted at 5 (half LOD)', fontsize=9)
fig.tight_layout(); fig.savefig('/tmp/outputs/figures/fig3_immunogenicity.png', bbox_inches='tight'); plt.close()
# ---------------- Figure 4: integrity examples
fig, axs = plt.subplots(2, 2, figsize=(11, 7.6))
ax = axs[0, 0]
for blk, ls in [('S06-C', '-'), ('S06-D', '--')]:
    for g in ['Sham', 'PSLN-212', 'PSLN-344']:
        d = s[(s.block == blk) & (s.group == g)]; t = np.sort(d.time.values); ev = d.sort_values('time').event.values
        days = np.arange(0, 15); S = [(1 - ((d.time <= dd) & (d.event == 1)).sum() / len(d)) * 100 for dd in days]
        ax.step(days, np.array(S) + (0.8 if blk == 'S06-D' else 0), where='post', color=COL[g], ls=ls, lw=1.5, label=f'{blk} {g}')
ax.set_title('S06-C (challenge d14) vs S06-D (challenge d3):\nidentical death days in all 28 animals', fontsize=8.5); ax.set_xlabel('day after challenge'); ax.set_ylabel('survival %'); ax.legend(fontsize=6, ncol=2)
ax = axs[0, 1]
for a in range(1, 8):
    for blk, ls, c in [('S15-C', '-', '#1b9e77'), ('S15-I', '--', '#b2182b')]:
        grp = 'PSLN-344' if blk == 'S15-C' else '3d Vaccine+PSLN-344'
        d = b[(b.block == blk) & (b.group == grp) & (b.animal == a)].sort_values('day')
        ax.plot(d.day, d.value, ls=ls, color=c, lw=1, alpha=0.8, label=(f'{blk} {grp}' if a == 1 else None))
ax.set_title('Body weight: S15-C PSLN-344 (rgH5N1 d14) vs S15-I "3d Vaccine+PSLN-344"\n(separate experiment): 7 trajectories identical on most days', fontsize=8.5)
ax.set_xlabel('day after challenge'); ax.set_ylabel('% of day-0 weight'); ax.legend(fontsize=7)
ax = axs[1, 0]
import matplotlib.colors as mcolors
A = v[v.block == 'S11-A'].set_index(['group', 'time', 'animal']).value; B = v[v.block == 'S11-B'].set_index(['group', 'time', 'animal']).value
eq = np.isclose(A, B.reindex(A.index)).astype(int); M = pd.Series(eq, index=A.index).unstack('animal')
ax.imshow(M.values, cmap=mcolors.ListedColormap(['#f7f7f7', '#b2182b']), aspect='auto')
ax.set_yticks(range(len(M))); ax.set_yticklabels([f'{g} d{t}' for g, t in M.index], fontsize=6); ax.set_xticks(range(5)); ax.set_xticklabels([f'animal {i}' for i in range(1, 6)], fontsize=7)
ax.set_title('S11-A (alveolar macrophages) vs S11-B (neutrophils):\nred = identical value in both blocks (35 of 100 cells)', fontsize=8.5)
ax = axs[1, 1]
ga = ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
pr = [v[(v.block == 'S03-B') & (v.group == g)].value.values for g in ga]
cp_ = [v[(v.block == 'S13-A') & (v.group == g)].sort_values('animal').value.values / v[(v.block == 'S13-B') & (v.group == g)].sort_values('animal').value.values for g in ga]
for k, g in enumerate(ga):
    ax.scatter(np.full(5, k - 0.12), pr[k], color='grey', s=14, label='S03-B as printed' if k == 0 else None)
    ax.scatter(np.full(5, k + 0.12), cp_[k], color=COL[g], s=14, label='computed from S13-A/S13-B' if k == 0 else None)
ax.set_yscale('log'); ax.set_xticks(range(3)); ax.set_xticklabels(ga); ax.set_ylabel('IgG2a/IgG1 (CA09, d14)')
ax.set_title('S03-B printed ratios are the S13 ratios with group labels rotated\n(printed 212 = S13 Y; printed 344 = S13 212; printed Y = S13 344)', fontsize=8.5); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig('/tmp/outputs/figures/fig4_integrity_examples.png', bbox_inches='tight'); plt.close()
# ---------------- Figure 5: innate / PD biomarker
fig, axs = plt.subplots(1, 3, figsize=(12, 3.8))
ax = axs[0]
grp = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']
for k, g in enumerate(grp):
    for t, mk, dx in [('16h', 'o', -0.15), ('72h', 's', 0.15)]:
        x = v[(v.block == f'S01-A {t}') & (v.group == g)].value.values
        ax.scatter(k + dx + np.linspace(-0.05, 0.05, 5), x, s=10, marker=mk, color=COL.get(g, 'k'), alpha=0.8, label=(t if k == 0 else None))
ax.set_yscale('log'); ax.set_xticks(range(len(grp))); ax.set_xticklabels(['Sham', 'CMP-204', '212', '344', '212(Y)', '344(Y)'], fontsize=7.5)
ax.set_ylabel('lung Ifnb1, fold vs untreated'); ax.set_title('S01-A: Ifnb1 16 h (circles) and 72 h (squares)', fontsize=8.5); ax.legend(fontsize=7)
ax = axs[1]
doses = [1, 5, 10, 20, 40]
for g, c in [('CMP-204', COL['CMP-204']), ('PSLN-212', COL['PSLN-212']), ('PSLN-344', COL['PSLN-344']), ('PSLN-344/R848', '#66a61e')]:
    gm = [10 ** np.log10(v[(v.block == 'S08-A') & (v.group == g) & (v.time == str(d))].value).mean() for d in doses]
    ax.plot(doses, gm, 'o-', color=c, label=g, ms=4)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('adjuvant dose, ug/animal'); ax.set_ylabel('lung Ifnb1 16 h (GM, n=3)'); ax.set_title('S08-A dose-response (age not stated)', fontsize=8.5); ax.legend(fontsize=7)
ax = axs[2]
for g in ['Sham', 'PSLN-212', 'PSLN-344']:
    gm = [10 ** np.log10(v[(v.block == 'S02-F') & (v.group == g) & (v.time == t)].value).mean() for t in ['16h', '36h', '72h']]
    ax.plot([16, 36, 72], gm, 'o-', color=COL[g], label=g)
ax.set_xlabel('hours after immunisation'); ax.set_ylabel('lung Gm-csf (GM, n=5)'); ax.set_title('S02-F Gm-csf kinetics (aged)', fontsize=8.5); ax.legend(fontsize=7)
fig.tight_layout(); fig.savefig('/tmp/outputs/figures/fig5_innate_pd.png', bbox_inches='tight'); plt.close()
print('figures written')

"""
Gap closure = (f(PSLN-344 aged) - f(PSLN-212 aged)) / (f(PSLN-212 young) - f(PSLN-212 aged)),
f = log10 for titres / fold-changes, identity for percentages. 1 = PSLN-344 fully restores the young level;
0 = no improvement over PSLN-212 in aged; >1 = overshoot beyond young.
95% CI by non-parametric bootstrap (animals resampled within group, 5000 reps).
Only blocks with PSLN-212, PSLN-344 and PSLN-212(Y) arms and a valid, correctly labelled readout are included
(S03-B/S03-F replaced by S13-derived IgG2a/IgG1 ratios; S11-A/S11-B excluded - duplicated cells; S05-A/B excluded - n=2,
design conflict).
"""
import pandas as pd, numpy as np
rng = np.random.default_rng(2024)
v = pd.read_csv('/tmp/work/tidy/values.csv'); v['time'] = v['time'].fillna('-').astype(str)
LOG = {'S01-A 16h','S01-A 72h','S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J','IgG2a/IgG1 CA09 (S13-A/S13-B)','IgG2a/IgG1 Aichi (S13-C/S13-D)'}
def get(block, group, time='-'):
    d = v[(v.block == block) & (v.group == group) & (v.time == str(time))].sort_values('animal').value.values.astype(float)
    if block in ('S03-C', 'S03-G'): d = np.where(d <= 0, 5.0, d)
    return d
# derived ratio endpoints (correctly labelled, from S13 raw subclass titres)
extra = {}
for name, a, b in [('IgG2a/IgG1 CA09 (S13-A/S13-B)', 'S13-A', 'S13-B'), ('IgG2a/IgG1 Aichi (S13-C/S13-D)', 'S13-C', 'S13-D')]:
    extra[name] = {g: get(a, g) / get(b, g) for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']}
readouts = [
 ('Innate (16-72 h)', 'S01-A 16h', '16h', 'Lung Ifnb1 16 h (fold)'),
 ('Innate (16-72 h)', 'S01-A 72h', '72h', 'Lung Ifnb1 72 h (fold)'),
 ('Myeloid / DC (d3-d8)', 'S01-D', '4', 'Lung monocytes d4 (%)'),
 ('Myeloid / DC (d3-d8)', 'S01-E', '4', 'Lung CD11b+ DC d4 (%)'),
 ('Myeloid / DC (d3-d8)', 'S01-F', '-', 'Lung cDC1 72 h (%)'),
 ('Myeloid / DC (d3-d8)', 'S02-A', '-', 'Lung CCR7+ CD11b+ DC 72 h (%)'),
 ('Myeloid / DC (d3-d8)', 'S02-B', '-', 'MLN CD11b+CD103- DC 72 h (%)'),
 ('Myeloid / DC (d3-d8)', 'S02-C', '-', 'MLN antigen+ DC 36 h (%)'),
 ('Myeloid / DC (d3-d8)', 'S02-D CD40', '-', 'MLN DC CD40+ d3 (%)'),
 ('Myeloid / DC (d3-d8)', 'S02-D CD86', '-', 'MLN DC CD86+ d3 (%)'),
 ('Myeloid / DC (d3-d8)', 'S02-E', '-', 'DC->OT-I proliferation ex vivo (%)'),
 ('Myeloid / DC (d3-d8)', 'S11-E', '-', 'Lung CD206+ macrophages (%; time not stated)'),
 ('T follicular / GC (d5-d30)', 'S04-A ICOShi', '-', 'MLN ICOS-hi Tfh d7 (%)'),
 ('T follicular / GC (d5-d30)', 'S04-B Foxp3', '-', 'MLN Tfr (Foxp3+ of CXCR5+ICOShi) d7 (%)'),
 ('T follicular / GC (d5-d30)', 'S04-C', '-', 'MLN Tfr d30 (%)'),
 ('T follicular / GC (d5-d30)', 'S04-D', '-', 'Lung Treg d7 (%)'),
 ('T follicular / GC (d5-d30)', 'S03-K', '-', 'MLN GC B cells d7 (%)'),
 ('T follicular / GC (d5-d30)', 'S13-H', '-', 'MLN IgG+ B220+ (%; time not stated)'),
 ('Antibody (d14-d28)', 'S03-A', '-', 'Serum IgG CA09 d14 (titre)'),
 ('Antibody (d14-d28)', 'S03-E', '-', 'Serum IgG Aichi d14 (titre)'),
 ('Antibody (d14-d28)', 'S03-C', '-', 'HAI CA09 d14 (titre)'),
 ('Antibody (d14-d28)', 'S03-G', '-', 'HAI Aichi d14 (titre)'),
 ('Antibody (d14-d28)', 'S03-D', '-', 'MN CA09 d14 (titre)'),
 ('Antibody (d14-d28)', 'S03-H', '-', 'MN Aichi d14 (titre)'),
 ('Antibody (d14-d28)', 'S13-I', '-', 'Serum IgG CA09 d28 post-boost (titre)'),
 ('Antibody (d14-d28)', 'S13-J', '-', 'Serum IgG Aichi d28 post-boost (titre)'),
 ('Antibody (d14-d28)', 'IgG2a/IgG1 CA09 (S13-A/S13-B)', '-', 'IgG2a/IgG1 CA09 d14 (S13-derived)'),
 ('Antibody (d14-d28)', 'IgG2a/IgG1 Aichi (S13-C/S13-D)', '-', 'IgG2a/IgG1 Aichi d14 (S13-derived)'),
 ('CD8 T cell (d3-d60)', 'S05-D', '-', 'Lung Ki-67+ CD8 d3 (%)'),
 ('CD8 T cell (d3-d60)', 'S05-E', '-', 'Lung GZMB+ CD8 d3 (%)'),
 ('CD8 T cell (d3-d60)', 'S05-F', '-', 'MLN IFNg+ CD8 (rgH5N1 recall) d14 (%)'),
 ('CD8 T cell (d3-d60)', 'S14-A H1N1', '-', 'MLN IFNg+ CD8 (CA09 recall; time n.s.) (%)'),
 ('CD8 T cell (d3-d60)', 'S14-A H3N2', '-', 'MLN IFNg+ CD8 (Aichi recall; time n.s.) (%)'),
 ('CD8 T cell (d3-d60)', 'S05-I', '-', 'Lung CD69+CD103+ TRM CD8 d25 (%)'),
 ('CD8 T cell (d3-d60)', 'S05-G', '-', 'MLN IFNg+ CD8 (rgH5N1 recall) d60 (%)'),
 ('CD8 T cell (d3-d60)', 'S05-H', '-', 'MLN GZMB+ CD8 d60 (%)'),
]
def closure(a212, a344, aY, log):
    f = np.log10 if log else (lambda x: x)
    m212, m344, mY = f(a212).mean(), f(a344).mean(), f(aY).mean()
    return (m344 - m212) / (mY - m212) if mY != m212 else np.nan
rows = []
for fam, blk, t, label in readouts:
    if blk in extra:
        a212, a344, aY = (extra[blk][g] for g in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)'])
    else:
        a212, a344, aY = get(blk, 'PSLN-212', t), get(blk, 'PSLN-344', t), get(blk, 'PSLN-212(Y)', t)
    log = blk in LOG
    c = closure(a212, a344, aY, log)
    bs = [closure(rng.choice(a212, len(a212)), rng.choice(a344, len(a344)), rng.choice(aY, len(aY)), log) for _ in range(5000)]
    bs = np.array(bs); bs = bs[np.isfinite(bs)]
    agg = (lambda x: 10 ** np.log10(x).mean()) if log else np.mean
    rows.append(dict(family=fam, readout=label, block=blk, time=t, scale='log10 (GM)' if log else 'linear (mean)',
                     aged_PSLN212=agg(a212), aged_PSLN344=agg(a344), young_PSLN212=agg(aY),
                     gap_closure=c, ci_lo=np.percentile(bs, 2.5), ci_hi=np.percentile(bs, 97.5)))
R = pd.DataFrame(rows); R.to_csv('/tmp/outputs/tables/gap_closure.csv', index=False)
pd.set_option('display.width', 250)
print(R.round(3).to_string())

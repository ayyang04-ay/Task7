"""
Extract every data block of adjuvant_program_dataset.xlsx into tidy tables with
cell-level provenance. Block cell ranges are specified explicitly (from inspection
of the workbook against adjuvant_program_annotation.pdf).
Outputs (to /tmp/work/tidy/):
  values.csv    : block, group, animal, time, value, cell   (continuous per-animal data)
  survival.csv  : block, group, animal, time, event, cell_time, cell_event
  bodyweight.csv: block, group, animal, day, value, cell
  coverage.txt  : numeric cells in workbook not captured by any block / captured twice
"""
import openpyxl, pandas as pd, os, collections
from openpyxl.utils import column_index_from_string as ci, get_column_letter as gl

XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
OUT = '/tmp/work/tidy'; os.makedirs(OUT, exist_ok=True)
wb = openpyxl.load_workbook(XLSX, data_only=True)
captured = collections.Counter()
vals, surv, bw = [], [], []

def cell(ws, col, row):
    c = ws[f'{col}{row}']; return c.value
def mark(sheet, col, row):
    captured[(sheet, f'{col}{row}')] += 1

def colrange(a, b):
    return [gl(i) for i in range(ci(a), ci(b) + 1)]

def cols_block(block, sheet, header_row, rows, cols, time=None, groups=None):
    """one column per group; each row = one animal"""
    ws = wb[sheet]
    for col in cols:
        g = groups[cols.index(col)] if groups else str(cell(ws, col, header_row)).strip()
        a = 0
        for r in rows:
            v = cell(ws, col, r)
            if v is None: continue
            a += 1; mark(sheet, col, r)
            vals.append(dict(block=block, sheet=sheet, group=g, animal=a, time=time, value=float(v), cell=f'{sheet}!{col}{r}'))

def rows_block(block, sheet, rows, label_col, value_cols, time=None, label_override=None):
    """one row per group; columns = animals"""
    ws = wb[sheet]
    for r in rows:
        g = label_override[rows.index(r)] if label_override else str(cell(ws, label_col, r)).strip()
        a = 0
        for col in value_cols:
            v = cell(ws, col, r)
            if v is None: continue
            a += 1; mark(sheet, col, r)
            vals.append(dict(block=block, sheet=sheet, group=g, animal=a, time=time, value=float(v), cell=f'{sheet}!{col}{r}'))

def wide_time_block(block, sheet, rows, time_col, group_cols, kind='values'):
    """rows = timepoints (time in time_col); group_cols = {group: [cols]} ; columns = animals"""
    ws = wb[sheet]
    for r in rows:
        t = cell(ws, time_col, r)
        if t is None: continue
        if kind == 'values': mark(sheet, time_col, r)
        else: mark(sheet, time_col, r)
        t = str(t).strip()
        for g, cols in group_cols.items():
            for a, col in enumerate(cols, 1):
                v = cell(ws, col, r)
                if v is None: continue
                mark(sheet, col, r)
                rec = dict(block=block, sheet=sheet, group=g, animal=a, value=float(v), cell=f'{sheet}!{col}{r}')
                if kind == 'values':
                    rec['time'] = t; vals.append(rec)
                else:
                    rec['day'] = float(t); bw.append(rec)

def survival_block(block, sheet, rows, time_col, group_cols):
    """each row = one animal: time in time_col, 1/0 in exactly one group column"""
    ws = wb[sheet]; counters = collections.Counter()
    for r in rows:
        t = cell(ws, time_col, r)
        hits = [(g, col) for g, col in group_cols.items() if cell(ws, col, r) is not None]
        if t is None and not hits: continue
        if len(hits) != 1:
            raise ValueError(f'{block} row {r}: {len(hits)} group entries')
        g, col = hits[0]; counters[g] += 1
        if t is not None: mark(sheet, time_col, r)
        mark(sheet, col, r)
        surv.append(dict(block=block, sheet=sheet, group=g, animal=counters[g],
                         time=(float(t) if t is not None else None), event=int(cell(ws, col, r)),
                         cell_time=f'{sheet}!{time_col}{r}', cell_event=f'{sheet}!{col}{r}'))

def groups_from_header(sheet, header_row, starts, width):
    ws = wb[sheet]; out = {}
    for s in starts:
        g = str(cell(ws, s, header_row)).strip()
        out[g] = colrange(s, gl(ci(s) + width - 1))
    return out

R = lambda a, b: list(range(a, b + 1))
C = lambda s: [x.strip() for x in s.split(',')]

# ---------------- S01
rows_block('S01-A 16h', 'S01', R(3, 10), 'A', colrange('B', 'F'), time='16h')
rows_block('S01-A 72h', 'S01', R(3, 10), 'G', colrange('H', 'L'), time='72h')
rows_block('S01-B', 'S01', R(14, 17), 'A', colrange('B', 'F'))
rows_block('S01-C', 'S01', R(20, 21), 'A', colrange('B', 'E'))
wide_time_block('S01-D', 'S01', R(24, 28), 'A', groups_from_header('S01', 23, C('B,G,L,Q'), 5))
wide_time_block('S01-E', 'S01', R(30, 34), 'A', groups_from_header('S01', 29, C('B,G,L,Q,V'), 5))
g = groups_from_header('S01', 35, C('B,G,L,Q,V'), 5)
for grp, cols in g.items():
    rows_block('S01-F', 'S01', [36], None, cols, label_override=[grp])
g = groups_from_header('S01', 37, C('B,G,L,Q,V'), 5)
for grp, cols in g.items():
    rows_block('S01-G', 'S01', [38], None, cols, label_override=[grp])
for h in [23, 29, 35, 37]:
    for col in C('B,G,L,Q,V'):
        if cell(wb['S01'], col, h) is not None: pass

# ---------------- S02
cols_block('S02-A', 'S02', 2, R(3, 7), colrange('A', 'D'))
cols_block('S02-B', 'S02', 2, R(3, 7), colrange('F', 'I'))
cols_block('S02-C', 'S02', 2, R(3, 7), colrange('K', 'O'))
cols_block('S02-D CD40', 'S02', 9, R(10, 14), colrange('A', 'D'))
cols_block('S02-D CD86', 'S02', 9, R(10, 14), colrange('F', 'I'))
cols_block('S02-E', 'S02', 9, R(10, 14), colrange('K', 'O'))
wide_time_block('S02-F', 'S02', R(17, 19), 'A', groups_from_header('S02', 16, C('B,G,L'), 5))
cols_block('S02-G', 'S02', 21, R(22, 26), colrange('B', 'D'))
cols_block('S02-H', 'S02', 29, R(30, 34), colrange('B', 'F'))
cols_block('S02-I', 'S02', 29, R(30, 34), colrange('H', 'I'))

# ---------------- S03
cols_block('S03-A', 'S03', 2, R(3, 7), colrange('A', 'E'))
cols_block('S03-B', 'S03', 2, R(3, 7), colrange('G', 'I'))
cols_block('S03-C', 'S03', 2, R(3, 7), colrange('K', 'O'))
cols_block('S03-D', 'S03', 2, R(3, 7), colrange('Q', 'U'))
cols_block('S03-E', 'S03', 9, R(10, 14), colrange('A', 'E'))
cols_block('S03-F', 'S03', 9, R(10, 14), colrange('G', 'I'))
cols_block('S03-G', 'S03', 9, R(10, 14), colrange('K', 'O'))
cols_block('S03-H', 'S03', 9, R(10, 14), colrange('Q', 'U'))
survival_block('S03-I', 'S03', R(17, 51), 'A', {g: c for g, c in zip(['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)'], C('B,C,D,E,F'))})
survival_block('S03-J', 'S03', R(17, 46), 'G', {g: c for g, c in zip(['Sham','PSLN-212','PSLN-344'], C('H,I,J'))})
cols_block('S03-K', 'S03', 16, R(17, 21), colrange('L', 'O'))
rows_block('S03-L Aicda', 'S03', R(26, 28), 'K', colrange('L', 'N'))
rows_block('S03-L E47', 'S03', R(26, 28), 'K', colrange('O', 'Q'))

# ---------------- S04
rows_block('S04-A ICOSlo', 'S04', R(2, 5), 'A', colrange('B', 'F'))
rows_block('S04-A ICOShi', 'S04', R(2, 5), 'A', colrange('G', 'K'))
cols_block('S04-B Foxp3', 'S04', 7, R(8, 12), colrange('A', 'D'))
cols_block('S04-B Tfh:Tfr', 'S04', 14, R(15, 19), colrange('A', 'D'))
cols_block('S04-C', 'S04', 21, R(22, 26), colrange('A', 'D'))
cols_block('S04-D', 'S04', 28, R(29, 31), colrange('A', 'D'))

# ---------------- S05
wide_time_block('S05-A', 'S05', R(3, 5), 'A', {'PSLN-212': C('B,C'), 'PSLN-344': C('E,F'), 'PSLN-212(Y)': C('H,I')})
wide_time_block('S05-B', 'S05', R(8, 10), 'A', {'PSLN-212': C('B,C'), 'PSLN-344': C('E,F'), 'PSLN-212(Y)': C('H,I')})
cols_block('S05-C', 'S05', 12, R(13, 15), colrange('A', 'D'))
for b, h in [('S05-D', 18), ('S05-E', 25), ('S05-F', 32), ('S05-G', 39), ('S05-H', 46), ('S05-I', 53)]:
    cols_block(b, 'S05', h, R(h + 1, h + 5), colrange('A', 'D'))

# ---------------- S06 (survival)
G4 = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
G5 = G4 + ['Untreated']
GI = ['Naive+PSLN-212', 'Imprinting+PSLN-212', 'Naive+PSLN-344', 'Imprinting+PSLN-344']
survival_block('S06-A', 'S06', R(3, 30), 'A', dict(zip(G4, C('B,C,D,E'))))
survival_block('S06-B', 'S06', R(3, 30), 'G', dict(zip(G4, C('H,I,J,K'))))
survival_block('S06-C', 'S06', R(3, 30), 'M', dict(zip(G4, C('N,O,P,Q'))))
survival_block('S06-D', 'S06', R(34, 61), 'A', dict(zip(G4, C('B,C,D,E'))))
survival_block('S06-E', 'S06', R(34, 68), 'G', dict(zip(G5, C('H,I,J,K,L'))))
survival_block('S06-F', 'S06', R(34, 68), 'M', dict(zip(G5, C('N,O,P,Q,R'))))
survival_block('S06-G', 'S06', R(71, 105), 'A', dict(zip(G5, C('B,C,D,E,F'))))
survival_block("S06-E(imprint)", 'S06', R(71, 98), 'G', dict(zip(GI, C('H,I,J,K'))))
survival_block("S06-F(imprint)", 'S06', R(71, 98), 'M', dict(zip(GI, C('N,O,P,Q'))))

# ---------------- S07
wide_time_block('S07-A', 'S07', R(3, 7), 'A', {'PSLN-212': C('B,C,D'), 'PSLN-344': C('E,F,G')})
cols_block('S07-B Mono', 'S07', 9, R(10, 14), C('B,C'))
cols_block('S07-B Ly6C+Mac', 'S07', 9, R(10, 14), C('E,F'))
cols_block('S07-C', 'S07', 15, R(16, 20), C('B,C'), groups=['col B (printed Ly6C-CD206+ MPhi)', 'col C (printed Ly6C-CD206+ MPhi)'])

# ---------------- S08
wide_time_block('S08-A', 'S08', R(3, 7), 'A', {'CMP-204': C('B,C,D'), 'PSLN-212': C('E,F,G'), 'PSLN-344': C('H,I,J'), 'PSLN-344/R848': C('K,L,M')})
for grp, cols in {'CMP-204': C('A,B,C'), 'PSLN-212': C('D,E,F'), 'PSLN-R848': C('G,H,I'), 'PSLN-212/R848': C('J,K,L'), 'PSLN-344': C('M,N,O')}.items():
    rows_block('S08-B', 'S08', [11], None, cols, label_override=[grp])
cols_block('S08-C', 'S08', 13, R(14, 18), colrange('A', 'D'))
wide_time_block('S08-D', 'S08', R(21, 26), 'A', groups_from_header('S08', 20, C('B,G,L,Q,V,AA'), 5), kind='bw')
# orphan region rows 89-101 (captured separately, not analysed)
orphan = []
for r in R(89, 101):
    for col in C('A,B,C,D'):
        v = cell(wb['S08'], col, r)
        if v is not None: orphan.append((f'S08!{col}{r}', v)); mark('S08', col, r)

# ---------------- S09
p1 = {'PBS': C('B,C,D'), 'CMP-204': C('E,F,G'), 'PSLN-212': C('H,I,J'), 'PSLN-R848': C('K,L,M'), 'PSLN-212/R848': C('N,O,P'), 'PSLN-344': C('Q,R,S'), 'PSLN-212(Y)': C('T,U,V')}
p2 = {'PBS': C('Y,Z,AA'), 'CMP-204': C('AB,AC,AD'), 'PSLN-212': C('AE,AF,AG'), 'PSLN-R848': C('AH,AI,AJ'), 'PSLN-212/R848': C('AK,AL,AM'), 'PSLN-344': C('AN,AO,AP'), 'PSLN-212(Y)': C('AQ,AR,AS')}
wide_time_block('S09-A panel1 (A:V)', 'S09', R(3, 9), 'A', p1)
wide_time_block('S09-A panel2 (X:AS)', 'S09', R(3, 9), 'X', p2)
GY = ['Sham', 'PSLN-344(Y)', 'PSLN-212(Y)']
survival_block('S09-B', 'S09', R(12, 35), 'A', dict(zip(GY, C('B,C,D'))))
survival_block('S09-D', 'S09', R(39, 62), 'A', dict(zip(GY, C('B,C,D'))))
survival_block('S09-F', 'S09', R(66, 88), 'A', dict(zip(GY, C('B,C,D'))))
bwY = {'PSLN-212(Y)': colrange('G', 'N'), 'Sham': colrange('O', 'V'), 'PSLN-344(Y)': colrange('W', 'AD')}
wide_time_block('S09-C', 'S09', R(12, 19), 'F', bwY, kind='bw')
wide_time_block('S09-E', 'S09', R(39, 46), 'F', bwY, kind='bw')
wide_time_block('S09-G', 'S09', R(66, 73), 'F', bwY, kind='bw')

# ---------------- S10
cols_block('S10-A Ifnb1', 'S10', 2, R(3, 7), colrange('A', 'D'))
cols_block('S10-A Tnf', 'S10', 2, R(3, 7), colrange('F', 'I'))
cols_block('S10-A Isg15', 'S10', 2, R(3, 7), colrange('K', 'N'))

# ---------------- S11
g11 = {'Vaccine': colrange('B', 'F'), 'PSLN-212': colrange('G', 'K'), 'PSLN-344': colrange('L', 'P'), 'PSLN-212(Y)': colrange('Q', 'U')}
wide_time_block('S11-A', 'S11', R(3, 7), 'A', g11)
wide_time_block('S11-B', 'S11', R(10, 14), 'A', g11)
cols_block('S11-C', 'S11', 16, R(17, 21), C('A,B'))
wide_time_block('S11-D', 'S11', R(24, 28), 'A', g11)
cols_block('S11-E', 'S11', 30, R(31, 35), colrange('A', 'D'))

# ---------------- S12
cols_block('S12-A', 'S12', 2, R(3, 5), C('A,B'))

# ---------------- S13
cols_block('S13-A', 'S13', 2, R(3, 7), colrange('A', 'C'))
cols_block('S13-B', 'S13', 2, R(3, 7), colrange('E', 'G'))
cols_block('S13-C', 'S13', 2, R(3, 7), colrange('I', 'K'))
cols_block('S13-D', 'S13', 2, R(3, 7), colrange('M', 'O'))
survival_block('S13-E', 'S13', R(3, 30), 'R', dict(zip(['Naive', 'Sham', 'CMP-204(Y)', 'PSLN-344(Y)'], C('S,T,U,V'))))
wide_time_block('S13-F', 'S13', R(33, 40), 'A', {'PSLN-212(Y)': colrange('B', 'H'), 'Sham': colrange('I', 'O'), 'PSLN-212': colrange('P', 'V'), 'PSLN-344': colrange('W', 'AC'), 'Naive': colrange('AD', 'AJ')}, kind='bw')
wide_time_block('S13-G', 'S13', R(43, 50), 'A', {'PSLN-344': colrange('B', 'K'), 'Sham': colrange('L', 'U'), 'Naive': colrange('V', 'AE')}, kind='bw')
cols_block('S13-H', 'S13', 52, R(53, 57), colrange('A', 'D'))
cols_block('S13-I', 'S13', 52, R(53, 57), colrange('F', 'J'))
cols_block('S13-J', 'S13', 52, R(53, 57), colrange('L', 'P'))

# ---------------- S14
cols_block('S14-A H1N1', 'S14', 2, R(3, 7), colrange('A', 'D'))
cols_block('S14-A H3N2', 'S14', 2, R(3, 7), colrange('F', 'I'))

# ---------------- S15
g15 = {'PSLN-212(Y)': colrange('B', 'H'), 'Sham': colrange('I', 'O'), 'PSLN-212': colrange('P', 'V'), 'PSLN-344': colrange('W', 'AC')}
g15u = dict(g15, Untreated=colrange('AD', 'AJ'))
for b, (r0, r1) in {'S15-A': (3, 10), 'S15-B': (13, 20), 'S15-C': (23, 30), 'S15-D': (33, 40)}.items():
    wide_time_block(b, 'S15', R(r0, r1), 'A', g15, kind='bw')
for b, (r0, r1) in {'S15-E': (43, 50), 'S15-F': (53, 60), 'S15-G': (63, 70)}.items():
    wide_time_block(b, 'S15', R(r0, r1), 'A', g15u, kind='bw')
survival_block('S15-H', 'S15', R(73, 93), 'A', dict(zip(['3d Vaccine', '3d PSLN-344', '3d Vaccine+PSLN-344'], C('B,C,D'))))
wide_time_block('S15-I', 'S15', R(72, 79), 'H', {'3d Vaccine': colrange('I', 'O'), '3d PSLN-344': colrange('P', 'V'), '3d Vaccine+PSLN-344': colrange('W', 'AC')}, kind='bw')
gim = {'Naive+PSLN-212': colrange('I', 'O'), 'Imprinting+PSLN-212': colrange('P', 'V'), 'Naive+PSLN-344': colrange('W', 'AC'), 'Imprinting+PSLN-344': colrange('AD', 'AJ')}
wide_time_block('S15-J', 'S15', R(83, 90), 'H', gim, kind='bw')
wide_time_block('S15-K', 'S15', R(93, 100), 'H', gim, kind='bw')
survival_block('S15-L', 'S15', R(103, 130), 'A', dict(zip(G4, C('B,C,D,E'))))
g15m = {'PSLN-212(Y)': colrange('I', 'O'), 'Sham': colrange('P', 'V'), 'PSLN-212': colrange('W', 'AC'), 'PSLN-344': colrange('AD', 'AJ')}
wide_time_block('S15-M', 'S15', R(103, 110), 'H', g15m, kind='bw')
survival_block('S15-N', 'S15', R(134, 161), 'A', dict(zip(G4, C('B,C,D,E'))))
wide_time_block('S15-O', 'S15', R(134, 141), 'H', g15m, kind='bw')

# ---------------- coverage check: every numeric cell captured exactly once
uncaptured, dup = [], []
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, (int, float)) and not isinstance(c.value, bool):
                k = (ws.title, c.coordinate)
                if captured[k] == 0: uncaptured.append(k + (c.value,))
                elif captured[k] > 1: dup.append(k + (captured[k],))
with open(f'{OUT}/coverage.txt', 'w') as f:
    f.write(f'numeric cells not captured: {len(uncaptured)}\n')
    for u in uncaptured: f.write(f'  {u}\n')
    f.write(f'cells captured more than once: {len(dup)}\n')
    for d in dup: f.write(f'  {d}\n')
    f.write(f'orphan region S08 rows 89-101: {orphan}\n')

pd.DataFrame(vals).to_csv(f'{OUT}/values.csv', index=False)
pd.DataFrame(surv).to_csv(f'{OUT}/survival.csv', index=False)
pd.DataFrame(bw).to_csv(f'{OUT}/bodyweight.csv', index=False)
print('values', len(vals), 'survival rows', len(surv), 'bw', len(bw))
print(open(f'{OUT}/coverage.txt').read()[:3000])

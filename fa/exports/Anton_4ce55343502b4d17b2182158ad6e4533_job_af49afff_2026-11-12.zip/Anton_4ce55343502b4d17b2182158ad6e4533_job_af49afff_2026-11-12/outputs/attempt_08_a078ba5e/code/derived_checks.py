import pandas as pd, numpy as np, itertools
v = pd.read_csv('/tmp/work/tidy/values.csv'); v['time'] = v['time'].fillna('-').astype(str)
def vec(block, group, time=None):
    d = v[(v.block == block) & (v.group == group)]
    if time is not None: d = d[d.time == str(time)]
    return d.sort_values('animal').value.values
G = ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
print('=== S03-B / S03-F (printed IgG2a/IgG1 ratios) vs ratios computed from S13 subclass titres')
for ratio_blk, a_blk, b_blk, label in [('S03-B', 'S13-A', 'S13-B', 'CA09'), ('S03-F', 'S13-C', 'S13-D', 'Aichi')]:
    comp = {g: vec(a_blk, g) / vec(b_blk, g) for g in G}
    printed = {g: vec(ratio_blk, g) for g in G}
    print(f'-- {label}: computed from {a_blk}/{b_blk}:', {g: np.round(comp[g], 4).tolist() for g in G})
    print(f'   printed {ratio_blk}:', {g: np.round(printed[g], 4).tolist() for g in G})
    for gp in G:
        for gc in G:
            err = np.max(np.abs(printed[gp] - comp[gc]) / comp[gc])
            if err < 0.001: print(f'   printed "{gp}" column == computed ratio of S13 "{gc}" (max rel. error {err:.1e})')
print('\n=== S09-A (log10) vs S01-A (linear) Ifnb1')
for panel in ['S09-A panel1 (A:V)', 'S09-A panel2 (X:AS)']:
    for g in ['PBS','CMP-204','PSLN-212','PSLN-R848','PSLN-212/R848','PSLN-344','PSLN-212(Y)']:
        x = 10 ** vec(panel, g, 'Ifnb1')
        g1 = 'Sham' if g == 'PBS' else g
        for t in ['16h', '72h']:
            y = vec(f'S01-A {t}', g1, t)
            idx = [int(np.argmin(np.abs(y - xi))) + 1 for xi in x]
            err = max(np.min(np.abs(y - xi)) / xi for xi in x)
            if err < 0.01: print(f'  {panel} {g:14s} = S01-A {t} "{g1}" animals {idx}  (max rel err {err:.4f})')
print('\n=== S04-B Tfh:Tfr vs (100 - Foxp3%)/Foxp3%')
for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']:
    f = vec('S04-B Foxp3', g); r = vec('S04-B Tfh:Tfr', g)
    print(f'  {g:12s} max abs diff = {np.max(np.abs(r - (100 - f) / f)):.2e}')
print('\n=== S01-B vs S08-C shared values')
for g1 in ['AECII/PSLN-SRB','AECI/PSLN-SRB','AECII/FreeSRB','AECI/FreeSRB']:
    for g2 in ['AECII-PSLN-SRB','AECII-PSLN-344-SRB','AECI-PSLN-SRB','AECI-PSLN-344-SRB']:
        s = set(np.round(vec('S01-B', g1), 3)) & set(np.round(vec('S08-C', g2), 3))
        if s: print(f'  S01-B {g1} & S08-C {g2}: shared {sorted(s)}')
print('\n=== S09-C day-12 rows & S06-C vs S06-D already reported; S05-A/B observation counts:')
print(v[v.block.isin(['S05-A','S05-B'])].groupby(['block','group','time']).size().unstack())

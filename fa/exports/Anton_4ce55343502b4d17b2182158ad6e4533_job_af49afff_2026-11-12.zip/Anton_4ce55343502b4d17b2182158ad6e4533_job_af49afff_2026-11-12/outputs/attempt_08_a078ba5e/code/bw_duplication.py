import pandas as pd, numpy as np, itertools
b = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
def informative(series):
    """(day,value) pairs excluding day 0 and carry-forward repeats (value equal to previous day's value)"""
    out = {}; prev = None
    for d, val in series.items():
        if d == 0: prev = val; continue
        if prev is not None and np.isclose(val, prev): prev = val; continue
        out[d] = val; prev = val
    return out
traj = {k: d.sort_values('day').set_index('day').value for k, d in b.groupby(['block','group','animal'])}
cell = {k: d.sort_values('day').set_index('day').cell for k, d in b.groupby(['block','group','animal'])}
inf = {k: informative(t) for k, t in traj.items()}
rows = []
for a, c in itertools.combinations(traj, 2):
    if a[:2] == c[:2]: continue
    xa, xc = inf[a], inf[c]
    common = set(xa) & set(xc)
    ident = sorted(d for d in common if np.isclose(xa[d], xc[d]))
    shift = sorted(d for d in common if not np.isclose(xa[d], xc[d]) and abs(round(xa[d] - xc[d]) - (xa[d] - xc[d])) < 1e-6 and len(repr(float(xa[d])).split('.')[-1]) >= 3)
    if len(ident) >= 3 or (len(ident) + len(shift) >= 3 and len(shift) >= 2):
        rows.append(dict(block_1=a[0], group_1=a[1], animal_1=a[2], cells_1=f'{cell[a].iloc[1]}:{cell[a].iloc[-1]}',
                         block_2=c[0], group_2=c[1], animal_2=c[2], cells_2=f'{cell[c].iloc[1]}:{cell[c].iloc[-1]}',
                         identical_days=ident, integer_shifted_days=shift, n_informative_matches=len(ident) + len(shift)))
df = pd.DataFrame(rows).sort_values(['block_1','block_2','group_1','animal_1'])
df.to_csv('/tmp/work/bw_duplicated_trajectories.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 60)
print(len(df), 'duplicated animal trajectories (pairs)')
print(df.groupby(['block_1','group_1','block_2','group_2']).agg(n_animals=('animal_1','size'), matches=('n_informative_matches','sum')).to_string())
# within-block row duplicates (same day, two different groups identical across all animals)
print('\n=== within-block: identical day rows across two groups')
for blk, d in b.groupby('block'):
    for day, dd in d.groupby('day'):
        if day == 0: continue
        grp = {g: tuple(x.sort_values('animal').value.round(4)) for g, x in dd.groupby('group')}
        for g1, g2 in itertools.combinations(grp, 2):
            if len(grp[g1]) == len(grp[g2]) and grp[g1] == grp[g2]:
                print(f'  {blk} day {day}: {g1} == {g2}: {grp[g1]}')

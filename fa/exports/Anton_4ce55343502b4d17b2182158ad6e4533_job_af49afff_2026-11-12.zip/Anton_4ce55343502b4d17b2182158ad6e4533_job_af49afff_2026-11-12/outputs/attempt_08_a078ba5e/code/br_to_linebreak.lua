-- Convert raw HTML <br> inside table cells into real line breaks (needed for DOCX output)
function RawInline(el)
  if el.format:match('html') and el.text:match('^<br%s*/?>$') then
    return pandoc.LineBreak()
  end
end

import pandas as pd, numpy as np
from scipy import stats
v = pd.read_csv('/tmp/work/tidy/values.csv'); v['time'] = v['time'].fillna('-').astype(str)
s = pd.read_csv('/tmp/work/tidy/survival.csv'); b = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
def vec(block, group, time='-'): return v[(v.block == block) & (v.group == group) & (v.time == str(time))].sort_values('animal').value.values
def surv(block, group): d = s[(s.block == block) & (s.group == group)]; return int((d.event == 0).sum()), len(d)
def cp(k, n):
    return (stats.beta.ppf(0.025, k, n - k + 1) if k > 0 else 0.0, stats.beta.ppf(0.975, k + 1, n - k) if k < n else 1.0)
out = []
def rec(key, value, source, reduction): out.append(dict(key=key, value=value, source=source, reduction=reduction)); print(f'{key}: {value}   [{source}; {reduction}]')
# durability (aged PSLN-344): day-14 vs day-60 challenge
d14 = [surv('S06-A', 'PSLN-344'), surv('S06-C', 'PSLN-344')]; d60 = [surv('S06-E', 'PSLN-344'), surv('S06-F', 'PSLN-344'), surv('S06-G', 'PSLN-344')]
k14, n14 = map(sum, zip(*d14)); k60, n60 = map(sum, zip(*d60))
p = stats.fisher_exact([[k14, n14 - k14], [k60, n60 - k60]])[1]
rec('Aged PSLN-344 survival, challenge d14 (S06-A,S06-C)', f'{k14}/{n14} ({100*k14/n14:.0f}%, 95% CI {100*cp(k14,n14)[0]:.0f}-{100*cp(k14,n14)[1]:.0f}%)', 'S06!D17:D23, S06!P17:P23', 'pooled survivors/n; Clopper-Pearson')
rec('Aged PSLN-344 survival, challenge d60 (S06-E,S06-F,S06-G)', f'{k60}/{n60} ({100*k60/n60:.0f}%, 95% CI {100*cp(k60,n60)[0]:.0f}-{100*cp(k60,n60)[1]:.0f}%); Fisher vs d14 p={p:.3f}', 'S06!J48:J54, S06!P48:P54, S06!D85:D91', 'pooled; Fisher exact')
m14 = surv('S06-A','PSLN-344')[0] + surv('S06-C','PSLN-344')[0]; m60 = surv('S06-E','PSLN-344')[0] + surv('S06-F','PSLN-344')[0]
rec('Matched vaccine/challenge pairs d14 -> d60 (Aichi->PR8; bivalent->rgH5N1)', f'{m14}/14 -> {m60}/14', 'S06-A vs S06-E; S06-C vs S06-F', 'survivors')
y60 = sum(surv(bk, 'PSLN-212(Y)')[0] for bk in ['S06-E','S06-F','S06-G']); rec('Young PSLN-212 survival d60', f'{y60}/21', 'S06-E/F/G col K,Q,E', 'survivors')
rec('Young PSLN-344/PSLN-212 survival d180 rgH5N1', f"{surv('S09-F','PSLN-344(Y)')[0]}/8 and {surv('S09-F','PSLN-212(Y)')[0]}/8", 'S09!C73:D88', 'survivors')
# background mortality in unchallenged aged animals
ku = sum(surv(bk, 'Untreated')[1] - surv(bk, 'Untreated')[0] for bk in ['S06-E','S06-F','S06-G'])
rec('Deaths among unvaccinated, UNCHALLENGED aged animals over 14 d', f'{ku}/21 ({100*ku/21:.0f}%, 95% CI {100*cp(ku,21)[0]:.0f}-{100*cp(ku,21)[1]:.0f}%)', 'S06!L62:L68, S06!R62:R68, S06!F99:F105', 'events/n')
bwU = b[(b.group == 'Untreated')]
last = bwU.groupby(['block','animal']).apply(lambda d: d.sort_values('day').value.values)
rec('Weight of untreated animals that died (carried-forward value)', '94.5% (S15-E), 96.6/95.0/95.7% (S15-G)', 'S15!AE45:AE50; S15!AD/AE/AF 65-70', 'carried-forward values after death')
kuu = sum(surv(bk,'PSLN-344')[0] for bk in ['S06-E','S06-F','S06-G']); kun = sum(surv(bk,'Untreated')[0] for bk in ['S06-E','S06-F','S06-G'])
rec('d60 cohorts: aged PSLN-344 vs unchallenged untreated survival', f'{kuu}/21 vs {kun}/21', 'S06-E/F/G', 'survivors')
# rapid protection
for bk, a, c in [('S06-B','PSLN-344','PSLN-212'), ('S15-H','3d Vaccine+PSLN-344','3d Vaccine'), ('S15-H','3d PSLN-344','3d Vaccine'), ('S03-J','PSLN-344','PSLN-212'), ('S03-J','PSLN-344','Sham')]:
    rec(f'{bk}: {a} vs {c}', f'{surv(bk,a)[0]}/{surv(bk,a)[1]} vs {surv(bk,c)[0]}/{surv(bk,c)[1]}', bk, 'survivors')
# young ceiling
ky = sum(surv(bk,'PSLN-344(Y)')[0] for bk in ['S09-B','S09-D','S09-F']); ky2 = sum(surv(bk,'PSLN-212(Y)')[0] for bk in ['S09-B','S09-D','S09-F'])
rec('Young PSLN-344 vs PSLN-212 survival, heterosubtypic (S09-B/D/F)', f'{ky}/24 vs {ky2}/24', 'S09 survival blocks', 'survivors')
rec('Young homologous 10xLD50 CA09 (S13-E): CMP-204(Y), PSLN-344(Y), Sham, Naive', f"{surv('S13-E','CMP-204(Y)')[0]}/7, {surv('S13-E','PSLN-344(Y)')[0]}/7, {surv('S13-E','Sham')[0]}/7, {surv('S13-E','Naive')[0]}/7", 'S13!S3:V30', 'survivors')
# dose-sparing (S08-A): GM per dose and interpolated dose of PSLN-344 matching PSLN-212 at 40 ug
gm = lambda x: 10 ** np.mean(np.log10(x))
doses = [1, 5, 10, 20, 40]
tab = {g: [gm(vec('S08-A', g, d)) for d in doses] for g in ['CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-344/R848']}
for g, gms in tab.items(): rec(f'S08-A Ifnb1 GM by dose {doses} ug: {g}', ', '.join(f'{x:.1f}' for x in gms), 'S08!B3:M7', 'GM of n=3')
target = tab['PSLN-212'][-1]; y = np.log10(tab['PSLN-344']); xd = np.log10(doses)
i = np.searchsorted(y, np.log10(target)); frac = (np.log10(target) - y[i - 1]) / (y[i] - y[i - 1]); dose = 10 ** (xd[i - 1] + frac * (xd[i] - xd[i - 1]))
rec('PSLN-344 dose matching PSLN-212 40 ug Ifnb1 response', f'{dose:.1f} ug (~{40/dose:.0f}-fold dose sparing on this PD readout)', 'S08-A', 'log-log linear interpolation between 5 and 10 ug GMs')
rec('Ratio of plateau responses (40 ug) PSLN-344/PSLN-212', f"{tab['PSLN-344'][-1]/tab['PSLN-212'][-1]:.2f}", 'S08-A row 7', 'ratio of GMs')
# formulation
for g in ['CMP-204','PSLN-212','PSLN-R848','PSLN-212/R848','PSLN-344']:
    x = vec('S08-B', g); rec(f'S08-B encapsulation efficiency {g}', f'{x.mean():.1f}% (SD {x.std(ddof=1):.1f})', 'S08!A11:O11', 'mean of n=3')
for g in ['AECII-PSLN-SRB','AECII-PSLN-344-SRB','AECI-PSLN-SRB','AECI-PSLN-344-SRB']:
    x = vec('S08-C', g); rec(f'S08-C {g}', f'{x.mean():.2f}% (SD {x.std(ddof=1):.2f})', 'S08!A14:D18', 'mean n=5')
for g in ['AECII/PSLN-SRB','AECI/PSLN-SRB','AECII/FreeSRB','AECI/FreeSRB']:
    x = vec('S01-B', g); rec(f'S01-B {g}', f'{x.mean():.2f}%', 'S01!B14:F17', 'mean n=5')
for g in ['WT','SPA/D']:
    x = vec('S01-C', g); rec(f'S01-C AM uptake {g}', f'{x.mean():.1f}% (SD {x.std(ddof=1):.1f})', 'S01!B20:E21', 'mean n=4')
# mechanism interventions
for blk, groups in [('S02-G', ['GM-CSF','PSLN-212','PSLN-212+GM-CSF']), ('S02-H', ['WT w/o cDC','WT w/ cDC','IFN w/o cDC','IFN w/ cDC','GMCSF']),
                    ('S12-A', ['WT to WT','IFNAR-/- to WT']), ('S11-C', ['CBX-','CBX+']), ('S07-B Mono', ['PSLN-344','PSLN-344+INCB3344']),
                    ('S07-B Ly6C+Mac', ['PSLN-344','PSLN-344+INCB3344']), ('S02-I', ['PSLN-344(Y)','PSLN-344(Y)+INCB3344']),
                    ('S05-C', ['Lung','Lung+PTX','MLN','MLN+PTX']), ('S02-C', ['PSLN-212','PSLN-344','PTX','PSLN-212(Y)','PSLN-344(Y)']),
                    ('S02-E', ['PSLN-212','PSLN-344','PTX','PSLN-212(Y)','PSLN-344(Y)'])]:
    vals = {g: vec(blk, g) for g in groups}
    rec(f'{blk} means', '; '.join(f'{g} {x.mean():.2f} (SD {x.std(ddof=1):.2f}, n={len(x)})' for g, x in vals.items()), blk, 'arithmetic mean')
    if len(groups) >= 2:
        a, c = vals[groups[0]], vals[groups[1]]
        t = stats.ttest_ind(a, c, equal_var=False); rec(f'{blk} {groups[1]} vs {groups[0]}', f'{100*(c.mean()/a.mean()-1):+.0f}% (Welch p={t.pvalue:.2g})', blk, 'relative change in means')
for blk, (a, c) in {'S02-H IFNAR': ('WT w/o cDC', 'IFN w/o cDC'), 'S02-H GMCSF rescue': ('IFN w/o cDC', 'GMCSF'), 'S05-C MLN PTX': ('MLN', 'MLN+PTX'), 'S05-C Lung PTX': ('Lung', 'Lung+PTX'), 'S02-C PTX vs PSLN-344 (adjuvant of PTX arm not stated)': ('PSLN-344', 'PTX')}.items():
    real = blk.split()[0]; A, C = vec(real, a), vec(real, c); t = stats.ttest_ind(A, C, equal_var=False)
    rec(blk, f'{a} {A.mean():.2f} -> {c} {C.mean():.2f} ({100*(C.mean()/A.mean()-1):+.0f}%, Welch p={t.pvalue:.2g})', real, 'means')
# innate kinetics
for g in ['PSLN-344','PSLN-212','Sham']:
    rec(f'S02-F Gm-csf GM 16/36/72 h {g}', ', '.join(f'{gm(vec("S02-F", g, t)):.2f}' for t in ['16h','36h','72h']), 'S02!B17:P19', 'GM n=5')
for g in ['PSLN-212','PSLN-344']:
    rec(f'S07-A Ly6C+CCR2+ macrophages (x1e5) d0/2/5/10/30 {g}', ', '.join(f'{vec("S07-A", g, t).mean():.2f}' for t in ['0','2','5','10','30']), 'S07!B3:G7', 'mean n=3')
# CNS
for an in ['Ifnb1','Tnf','Isg15']:
    rec(f'S10-A CNS {an} GM', '; '.join(f'{g} {gm(vec("S10-A "+an, g)):.2f}' for g in ['PBS','Sham','PSLN-344','CT']), 'S10!A3:N7', 'GM n=5')
# reactogenicity S08-D (per-animal nadir over d2-d10; no deaths except one missing value)
for g, d in b[b.block == 'S08-D'].groupby('group'):
    nad = d[d.day > 0].groupby('animal').value.min()
    rec(f'S08-D post-vaccination weight nadir {g}', f'mean {nad.mean():.1f}% (min {nad.min():.1f}%), n={nad.size}; animals with a d10 value: {d[d.day==10].shape[0]}', 'S08!B21:AE26', 'per-animal minimum over d2-d10, then mean')
pd.DataFrame(out).to_csv('/tmp/outputs/tables/supporting_numbers.csv', index=False)

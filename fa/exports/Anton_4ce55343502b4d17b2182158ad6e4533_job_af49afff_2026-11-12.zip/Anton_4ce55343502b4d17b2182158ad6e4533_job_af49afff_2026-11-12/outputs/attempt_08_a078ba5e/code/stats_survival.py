"""
Survival: per group final survival (Clopper-Pearson 95% CI), pairwise log-rank (stated method) and Fisher exact,
pooled stratified log-rank and Mantel-Haenszel risk difference under integrity scenarios.
Survivors are censored at end of observation (14 d; 21 d in S03-J). The one S03-J PSLN-344 animal with event=0
but no time recorded (S03!J46) is censored at 21 d (primary) - it does not affect any contrast (all PSLN-344 survived).
"""
import pandas as pd, numpy as np
from scipy import stats
s = pd.read_csv('/tmp/work/tidy/survival.csv')
s['time'] = s['time'].fillna(21.0)
def logrank(t1, e1, t2, e2):
    t = np.r_[t1, t2]; e = np.r_[e1, e2]; g = np.r_[np.zeros(len(t1)), np.ones(len(t2))]
    O = E = V = 0.0
    for tt in np.unique(t[e == 1]):
        atrisk = t >= tt; n = atrisk.sum(); n1 = (atrisk & (g == 0)).sum()
        d = ((t == tt) & (e == 1)).sum(); d1 = ((t == tt) & (e == 1) & (g == 0)).sum()
        O += d1; E += d * n1 / n
        if n > 1: V += d * (n1 / n) * (1 - n1 / n) * (n - d) / (n - 1)
    return O, E, V
def lr_p(O, E, V): return stats.chi2.sf((O - E) ** 2 / V, 1) if V > 0 else np.nan
def cp(k, n):
    lo = stats.beta.ppf(0.025, k, n - k + 1) if k > 0 else 0.0
    hi = stats.beta.ppf(0.975, k + 1, n - k) if k < n else 1.0
    return lo, hi
# ---------- per-group summary
rows = []
for (b, g), d in s.groupby(['block', 'group'], sort=False):
    n = len(d); surv = int((d.event == 0).sum()); lo, hi = cp(surv, n)
    md = np.median(d.time[d.event == 1]) if (d.event == 1).any() else np.nan
    rows.append(dict(block=b, group=g, n=n, deaths=n - surv, survivors=surv, survival_pct=100 * surv / n, ci_lo=100 * lo, ci_hi=100 * hi,
                     median_day_of_death_among_deaths=md, cells=f"{d.cell_event.iloc[0]}..{d.cell_event.iloc[-1]}"))
G = pd.DataFrame(rows); G.to_csv('/tmp/outputs/tables/survival_group_summaries.csv', index=False)
# ---------- pairwise
pairs = [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212(Y)'), ('PSLN-212', 'Sham'), ('CMP-204', 'Sham'), ('CMP-204', 'PSLN-212'),
         ('PSLN-344(Y)', 'PSLN-212(Y)'), ('PSLN-344(Y)', 'Sham'), ('PSLN-212(Y)', 'Sham'), ('CMP-204(Y)', 'Sham'),
         ('Naive+PSLN-344', 'Naive+PSLN-212'), ('Imprinting+PSLN-344', 'Imprinting+PSLN-212'), ('Imprinting+PSLN-212', 'Naive+PSLN-212'),
         ('Imprinting+PSLN-344', 'Naive+PSLN-344'), ('3d Vaccine+PSLN-344', '3d Vaccine'), ('3d Vaccine+PSLN-344', '3d PSLN-344'),
         ('PSLN-344', 'Untreated'), ('Untreated', 'PSLN-212(Y)')]
rows = []
for b, d in s.groupby('block', sort=False):
    for a, c in pairs:
        A = d[d.group == a]; C = d[d.group == c]
        if len(A) and len(C):
            O, E, V = logrank(A.time.values, A.event.values, C.time.values, C.event.values)
            sa, sc = int((A.event == 0).sum()), int((C.event == 0).sum())
            fp = stats.fisher_exact([[sa, len(A) - sa], [sc, len(C) - sc]])[1]
            rows.append(dict(block=b, group_a=a, group_b=c, surv_a=f'{sa}/{len(A)}', surv_b=f'{sc}/{len(C)}',
                             risk_diff_pct=100 * (sa / len(A) - sc / len(C)), logrank_chi2=(O - E) ** 2 / V if V > 0 else np.nan,
                             p_logrank=lr_p(O, E, V), p_fisher=fp))
P = pd.DataFrame(rows); P.to_csv('/tmp/outputs/tables/survival_pairwise.csv', index=False)
# ---------- pooled / stratified
AGED_H2H = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N']
scen = {
 'S1 all aged head-to-head blocks (S06-D excluded as duplicate of S06-C)': AGED_H2H,
 'S2 S1 minus blocks with label/group conflicts (S03-I, S03-J) or unstated challenge (S15-L, S15-N)': ['S06-A', 'S06-B', 'S06-C', 'S06-E', 'S06-F', 'S06-G'],
 'S3 S2 minus blocks whose survival and body-weight records disagree for either arm (S06-C, S06-E, S06-G)': ['S06-A', 'S06-B', 'S06-F'],
}
# worst-case reconciliation: for discordant arms use the count least favourable to PSLN-344 (from survival vs body-weight record)
conc = pd.read_csv('/tmp/work/bw_survival_concordance.csv')
def counts(block, group, mode):
    d = s[(s.block == block) & (s.group == group)]; n = len(d); deaths = int(d.event.sum())
    if mode == 'worst':
        r = conc[(conc.survival_block == block) & (conc.group == group)]
        if len(r) and not pd.isna(r.deaths_bw.iloc[0]) and r.n_bw.iloc[0] == n:
            bwd = int(r.deaths_bw.iloc[0])
            deaths = max(deaths, bwd) if group == 'PSLN-344' else min(deaths, bwd)
    return n - deaths, n
def mh_rd(strata):
    # Mantel-Haenszel risk difference with Greenland-Robins (Sato) variance
    num = den = 0.0; var_num = 0.0
    for (a, n1), (c, n0) in strata:
        w = n1 * n0 / (n1 + n0); num += (a / n1 - c / n0) * w; den += w
    rd = num / den
    # Sato variance estimator
    P = Q = 0.0
    for (a, n1), (c, n0) in strata:
        N = n1 + n0; b = n1 - a; d = n0 - c
        P += (n1 ** 2 * c - n0 ** 2 * a + n1 * n0 * (n0 - n1) / 2) / N ** 2
        Q += (a * (n0 - c) + c * (n1 - a)) / (2 * N)
    var = (rd * P + Q) / den ** 2
    se = np.sqrt(max(var, 0)); return rd, rd - 1.96 * se, rd + 1.96 * se
rows = []
for comp_b in ['PSLN-212', 'Sham', 'PSLN-212(Y)']:
    for name, blocks in list(scen.items()) + [('S4 worst-case reconciliation over S2 blocks', scen['S2 S1 minus blocks with label/group conflicts (S03-I, S03-J) or unstated challenge (S15-L, S15-N)'])]:
        mode = 'worst' if name.startswith('S4') else 'as_recorded'
        O = E = V = 0.0; strata = []; tot_a = tot_na = tot_b = tot_nb = 0; used = []
        for b in blocks:
            d = s[s.block == b]
            if not ((d.group == 'PSLN-344').any() and (d.group == comp_b).any()): continue
            A = d[d.group == 'PSLN-344']; C = d[d.group == comp_b]
            o, e, vv = logrank(A.time.values, A.event.values, C.time.values, C.event.values); O += o; E += e; V += vv
            a, n1 = counts(b, 'PSLN-344', mode); c, n0 = counts(b, comp_b, mode)
            strata.append(((a, n1), (c, n0))); tot_a += a; tot_na += n1; tot_b += c; tot_nb += n0; used.append(b)
        if not strata: continue
        rd, lo, hi = mh_rd(strata)
        rows.append(dict(comparison=f'PSLN-344 (aged) vs {comp_b}', scenario=name, blocks=','.join(used), n_blocks=len(used),
                         PSLN344_surv=f'{tot_a}/{tot_na} ({100*tot_a/tot_na:.0f}%)', comparator_surv=f'{tot_b}/{tot_nb} ({100*tot_b/tot_nb:.0f}%)',
                         MH_risk_diff_pct=100 * rd, MH_rd_lo=100 * lo, MH_rd_hi=100 * hi,
                         stratified_logrank_p=(lr_p(O, E, V) if mode == 'as_recorded' else np.nan)))
Q = pd.DataFrame(rows); Q.to_csv('/tmp/outputs/tables/survival_pooled_scenarios.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 110)
print(G.to_string()); print(); print(P[P.group_a.isin(['PSLN-344', '3d Vaccine+PSLN-344', 'Naive+PSLN-344', 'Imprinting+PSLN-344'])].to_string()); print(); print(Q.to_string())

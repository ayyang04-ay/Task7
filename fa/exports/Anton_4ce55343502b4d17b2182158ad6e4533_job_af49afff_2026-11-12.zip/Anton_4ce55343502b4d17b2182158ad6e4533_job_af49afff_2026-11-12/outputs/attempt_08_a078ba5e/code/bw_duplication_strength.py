import pandas as pd, numpy as np, itertools, ast
b = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
df = pd.read_csv('/tmp/work/bw_duplicated_trajectories.csv')
traj = {k: d.sort_values('day').set_index('day').value for k, d in b.groupby(['block','group','animal'])}
def nd(x): return len(repr(float(x)).split('.')[-1])
out = []
for r in df.itertuples():
    a = traj[(r.block_1, r.group_1, r.animal_1)]; c = traj[(r.block_2, r.group_2, r.animal_2)]
    ident = ast.literal_eval(r.identical_days); shift = ast.literal_eval(r.integer_shifted_days)
    hp = sum(1 for d in ident + shift if nd(a[d]) >= 4)
    lp_ident = sum(1 for d in ident if nd(a[d]) < 4)
    strength = 'STRONG (>=2 high-precision matches)' if hp >= 2 else ('STRONG (>=5 identical days)' if len(ident) >= 5 else 'weak (possible coincidence)')
    out.append(dict(r._asdict(), hp_matches=hp, lp_identical=lp_ident, strength=strength,
                    traj_1=[round(a[d], 5) for d in a.index], traj_2=[round(c[d], 5) for d in c.index]))
o = pd.DataFrame(out).drop(columns=['Index'])
o.to_csv('/tmp/work/bw_duplicated_trajectories_classified.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 200)
for s, d in o.groupby('strength'):
    print('=====', s, len(d))
    for r in d.itertuples():
        print(f'  {r.block_1}/{r.group_1}#{r.animal_1} [{r.cells_1}] <-> {r.block_2}/{r.group_2}#{r.animal_2} [{r.cells_2}] ident={r.identical_days} shift={r.integer_shifted_days}')
        print(f'       {r.traj_1}\n       {r.traj_2}')

# empirical chance rate: shuffle days - compare trajectories after circularly shifting days (misaligned) to estimate coincidental 1-decimal matches
def informative(series):
    out = {}; prev = None
    for d, val in series.items():
        if d == 0: prev = val; continue
        if prev is not None and np.isclose(val, prev): prev = val; continue
        out[d] = val; prev = val
    return out
inf = {k: informative(t) for k, t in traj.items()}
keys = list(inf); cnt3 = cnt5 = tot = 0
for a, c in itertools.combinations(keys, 2):
    if a[:2] == c[:2]: continue
    xa = inf[a]; xc = inf[c]
    # misaligned comparison: day d of a vs day d+2 of c (null for 'same-day' matching)
    m = sum(1 for d in xa if (d + 2) in xc and np.isclose(xa[d], xc[d + 2]) and nd(xa[d]) < 4)
    tot += 1; cnt3 += m >= 3; cnt5 += m >= 5
print(f'\nNull (day-misaligned) comparison over {tot} pairs: pairs with >=3 low-precision matches = {cnt3}; >=5 = {cnt5}')

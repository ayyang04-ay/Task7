import pandas as pd, numpy as np
b = pd.read_csv('/tmp/work/tidy/bodyweight.csv'); s = pd.read_csv('/tmp/work/tidy/survival.csv')
pairs = [('S03-I','S13-F'),('S03-J','S13-G'),('S06-A','S15-A'),('S06-B','S15-B'),('S06-C','S15-C'),('S06-D','S15-D'),
         ('S06-E','S15-E'),('S06-F','S15-F'),('S06-G','S15-G'),('S06-E(imprint)','S15-J'),('S06-F(imprint)','S15-K'),
         ('S09-B','S09-C'),('S09-D','S09-E'),('S09-F','S09-G'),('S15-H','S15-I'),('S15-L','S15-M'),('S15-N','S15-O')]
def bw_status(t):
    t = t.sort_index(); days = list(t.index); vals = list(t.values)
    last = days[-1]
    # trailing identical run
    k = len(vals) - 1
    while k > 0 and np.isclose(vals[k - 1], vals[-1]): k -= 1
    run = len(vals) - k
    if last < 14: return 'dead', f'last weighed d{int(last)}'
    if run >= 2 and days[k] < 14 and days[k] > 0:
        if run == 2 and vals[-1] >= 90: return 'ambiguous', f'2 identical final values {vals[-1]}'
        return 'dead', f'carried forward from d{int(days[k])} ({vals[-1]})'
    return 'alive', ''
rows = []
for sv, bwb in pairs:
    S = s[s.block == sv]; B = b[b.block == bwb]
    groups = list(dict.fromkeys(list(S.group.unique()) + list(B.group.unique())))
    for g in groups:
        ss = S[S.group == g]; bb = B[B.group == g]
        st = [bw_status(d.set_index('day').value) for _, d in bb.groupby('animal')]
        rows.append(dict(survival_block=sv, bw_block=bwb, group=g,
                         n_surv=len(ss) if len(ss) else None, deaths_surv=int(ss.event.sum()) if len(ss) else None,
                         n_bw=len(st) if st else None, deaths_bw=sum(1 for x in st if x[0] == 'dead') if st else None,
                         ambiguous_bw=sum(1 for x in st if x[0] == 'ambiguous') if st else None,
                         bw_notes='; '.join(x[1] for x in st if x[1])))
df = pd.DataFrame(rows)
def verdict(r):
    if pd.isna(r.n_surv): return 'GROUP ONLY IN BODY-WEIGHT BLOCK'
    if pd.isna(r.n_bw): return 'GROUP ONLY IN SURVIVAL BLOCK'
    if r.deaths_surv == r.deaths_bw: return 'concordant'
    if abs(r.deaths_surv - r.deaths_bw) <= r.ambiguous_bw: return 'concordant if ambiguous resolved'
    return f'DISCORDANT ({int(r.deaths_surv)} vs {int(r.deaths_bw)})'
df['verdict'] = df.apply(verdict, axis=1)
df.to_csv('/tmp/work/bw_survival_concordance.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 90)
print(df[['survival_block','bw_block','group','n_surv','deaths_surv','n_bw','deaths_bw','ambiguous_bw','verdict','bw_notes']].to_string())

import pandas as pd, numpy as np, itertools, collections
v = pd.read_csv('/tmp/work/tidy/values.csv'); s = pd.read_csv('/tmp/work/tidy/survival.csv'); b = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
v['time'] = v['time'].fillna('-').astype(str)

print('=== 1. Survival blocks with identical per-group outcomes')
sig = {}
for blk, d in s.groupby('block'):
    sig[blk] = tuple(sorted((g, tuple(sorted(zip(x.time.fillna(-1), x.event)))) for g, x in d.groupby('group')))
for a, c in itertools.combinations(sig, 2):
    if sig[a] == sig[c]: print('  IDENTICAL survival blocks:', a, c)
# group-level identical across blocks
gs = collections.defaultdict(list)
for (blk, g), x in s.groupby(['block', 'group']):
    key = tuple(sorted(zip(x.time.fillna(-1), x.event)))
    if x.event.sum() > 0 and x.event.sum() < len(x) or x.event.sum() == len(x):
        gs[key].append(f'{blk}:{g}')
for k, lst in gs.items():
    if len(lst) > 1 and len(set(l.split(':')[0] for l in lst)) > 1: print('  identical group outcome (with deaths) in', lst)

print('\n=== 2. Continuous value vectors: identical or near-identical across (block,group,time)')
vec = {}
for (blk, g, t), x in v.groupby(['block', 'group', 'time']):
    vec[(blk, g, t)] = x.sort_values('animal').value.values
keys = list(vec)
for a, c in itertools.combinations(keys, 2):
    x, y = vec[a], vec[c]
    if len(x) < 2 or len(y) < 2: continue
    shared = len(set(np.round(x, 4)) & set(np.round(y, 4)))
    same_pos = sum(1 for i in range(min(len(x), len(y))) if round(x[i], 4) == round(y[i], 4))
    if same_pos >= 2 and not (a[0] == c[0] and a[1] == c[1]):
        print(f'  {a} vs {c}: same-position matches={same_pos}/{min(len(x),len(y))}  x={x}  y={y}')

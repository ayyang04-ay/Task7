#!/usr/bin/env bash
# Regenerates every table, figure and register from the workbook.
# Requires the 'chem' (pandas/scipy/statsmodels/matplotlib/openpyxl/xlsxwriter) and 'genomics' (pandoc) micromamba envs.
set -euo pipefail
C=/tmp/outputs/code
mkdir -p /tmp/work/tidy /tmp/outputs/tables /tmp/outputs/figures
run() { micromamba run -n chem python "$C/$1"; }
run extract.py                      # workbook -> tidy tables with cell provenance (+ coverage check)
run counts.py > /dev/null           # record counts vs annotation
run integrity_checks.py > /dev/null # duplicate survival blocks, repeated value vectors
run integrity_checks2.py > /dev/null
run integrity_checks3.py > /dev/null
run bw_duplication.py               # duplicated body-weight trajectories
run bw_duplication_strength.py > /dev/null
run bw_null.py                      # day-matched permutation null
run bw_survival_concordance.py > /dev/null
run derived_checks.py > /dev/null   # S03-B/F vs S13, S09-A vs S01-A, Tfh:Tfr
run stats_continuous.py > /dev/null
run stats_survival.py > /dev/null
run gap_closure.py > /dev/null
run supporting_numbers.py > /dev/null
run figures.py
run build_registers.py | head -1
mkdir -p /tmp/outputs/tidy_data && cp /tmp/work/tidy/*.csv /tmp/outputs/tidy_data/
cd /tmp/outputs
micromamba run -n genomics pandoc PSLN-344_portfolio_memo.md -o PSLN-344_portfolio_memo.docx --resource-path=/tmp/outputs --lua-filter=$C/br_to_linebreak.lua --reference-doc=$C/bordered-reference.docx
micromamba run -n genomics pandoc PSLN-344_portfolio_memo.md -o PSLN-344_portfolio_memo.html --standalone --embed-resources --css $C/memo.css --resource-path=/tmp/outputs --metadata lang=en
echo done

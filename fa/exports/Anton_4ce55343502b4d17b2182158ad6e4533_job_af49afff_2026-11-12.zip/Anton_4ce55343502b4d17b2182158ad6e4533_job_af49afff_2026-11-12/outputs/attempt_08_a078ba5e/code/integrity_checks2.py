import pandas as pd, numpy as np, collections
v = pd.read_csv('/tmp/work/tidy/values.csv'); b = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
v['time'] = v['time'].fillna('-').astype(str)

print('=== S11-A (alveolar macrophages) vs S11-B (neutrophils), same group/day/animal position')
A = v[v.block=='S11-A'].set_index(['group','time','animal']).value
B = v[v.block=='S11-B'].set_index(['group','time','animal']).value
j = pd.concat([A.rename('AM'), B.rename('Neut')], axis=1)
j['equal'] = np.isclose(j.AM, j.Neut)
print('cells compared:', len(j), ' identical:', int(j.equal.sum()))
print(j.groupby(['group','animal']).equal.sum().unstack('animal'))
# compare with S11-D (NK) as a control for chance matches
D = v[v.block=='S11-D'].set_index(['group','time','animal']).value
print('control: S11-A vs S11-D identical cells:', int(np.isclose(A, D.reindex(A.index)).sum()), '; S11-B vs S11-D:', int(np.isclose(B, D.reindex(B.index)).sum()))

print('\n=== fingerprint values (>=4 significant decimals) occurring in more than one place')
def ndec(x):
    s = repr(float(x)); return len(s.split('.')[1]) if '.' in s else 0
allv = pd.concat([v.assign(kind='values')[['block','group','cell','value','kind']],
                  b.assign(kind='bw')[['block','group','cell','value','kind']]])
allv = allv[allv.value.apply(ndec) >= 4]
allv['key'] = allv.value.round(6)
rep = allv.groupby('key').filter(lambda d: len(d) > 1)
for k, d in rep.groupby('key'):
    print(f'  {k}: ' + '; '.join(f"{r.block}/{r.group}@{r.cell}" for r in d.itertuples()))

print('\n=== fractional-part fingerprints shared across blocks in body-weight data (same 6-decimal fractional part, different integer part)')
bb = b[b.value.apply(ndec) >= 5].copy()
bb['frac'] = (bb.value % 1).round(6)
rep2 = bb.groupby('frac').filter(lambda d: d.block.nunique() > 1 or d.group.nunique() > 1)
for k, d in rep2.groupby('frac'):
    print(f'  .{str(k)[2:]}: ' + '; '.join(f"{r.block}/{r.group}@{r.cell}={r.value}" for r in d.itertuples()))

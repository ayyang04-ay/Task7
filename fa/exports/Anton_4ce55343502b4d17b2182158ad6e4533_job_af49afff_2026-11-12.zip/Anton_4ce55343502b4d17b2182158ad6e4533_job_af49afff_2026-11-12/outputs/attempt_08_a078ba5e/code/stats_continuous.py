"""
Continuous endpoints: per-group summaries and pre-specified contrasts.
Conventions (stated in memo):
 - Titres (ELISA endpoint, HAI, MN) and qPCR fold-changes: log10 scale; report geometric mean (GM) with 95% CI;
   contrasts = ratio of GMs with Welch 95% CI.
 - HAI values recorded as 0 (no inhibition at the lowest dilution tested, 1:10) are set to 5 (half the LOD).
 - S09-A is already log10 -> analysed as-is (GM = 10^mean).
 - Percent / counts / ratios: arithmetic mean +/- SD; contrasts = difference in means (Welch 95% CI) and ratio of means.
 - Contrasts: C1 PSLN-344 vs PSLN-212 (aged; the Mn2+ effect), C2 PSLN-344 (aged) vs PSLN-212(Y) (young benchmark),
   C3 PSLN-344 vs Sham/vehicle (aged).
 - Sensitivity: exact Mann-Whitney p; stated method one-way ANOVA + Tukey HSD across all groups of the block.
"""
import pandas as pd, numpy as np
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
v = pd.read_csv('/tmp/work/tidy/values.csv'); v['time'] = v['time'].fillna('-').astype(str)
LOG_BLOCKS = {'S01-A 16h','S01-A 72h','S02-F','S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S03-L Aicda','S03-L E47',
              'S08-A','S10-A Ifnb1','S10-A Tnf','S10-A Isg15','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}
PRELOG = {'S09-A panel1 (A:V)', 'S09-A panel2 (X:AS)'}
HAI = {'S03-C', 'S03-G'}
def prep(block, x):
    x = np.asarray(x, float)
    if block in HAI: x = np.where(x <= 0, 5.0, x)
    if block in LOG_BLOCKS: return np.log10(x), 'log'
    if block in PRELOG: return x, 'log'
    return x, 'lin'
def welch(a, b):
    na, nb = len(a), len(b); ma, mb = a.mean(), b.mean(); va, vb = a.var(ddof=1), b.var(ddof=1)
    se = np.sqrt(va / na + vb / nb); df = (va / na + vb / nb) ** 2 / ((va / na) ** 2 / (na - 1) + (vb / nb) ** 2 / (nb - 1)) if se > 0 else np.nan
    t = (ma - mb) / se if se > 0 else np.inf; p = 2 * stats.t.sf(abs(t), df) if se > 0 else 0.0
    q = stats.t.ppf(0.975, df) if se > 0 else 0
    return ma - mb, ma - mb - q * se, ma - mb + q * se, p
def summary_rows():
    rows = []
    for (blk, t), d in v.groupby(['block', 'time'], sort=False):
        for g, x in d.groupby('group', sort=False):
            y, scale = prep(blk, x.sort_values('animal').value.values)
            n = len(y); m = y.mean(); sd = y.std(ddof=1) if n > 1 else np.nan
            ci = stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n) if n > 1 else np.nan
            r = dict(block=blk, time=t, group=g, n=n, scale=scale, cells=f"{x.cell.iloc[0]}..{x.cell.iloc[-1]}")
            if scale == 'log':
                r.update(GM=10 ** m, GM_lo=10 ** (m - ci), GM_hi=10 ** (m + ci), mean=np.nan, sd=np.nan, median=np.median(10 ** y))
            else:
                r.update(mean=m, sd=sd, mean_lo=m - ci, mean_hi=m + ci, median=np.median(y), GM=np.nan)
            rows.append(r)
    return pd.DataFrame(rows)
def contrast_rows():
    rows = []
    pairs = [('C1 PSLN-344 vs PSLN-212', 'PSLN-344', 'PSLN-212'), ('C2 PSLN-344 vs PSLN-212(Y)', 'PSLN-344', 'PSLN-212(Y)'),
             ('C3 PSLN-344 vs Sham', 'PSLN-344', 'Sham'), ('C3b PSLN-344 vs PBS', 'PSLN-344', 'PBS'),
             ('C4 PSLN-212 vs Sham', 'PSLN-212', 'Sham'), ('C5 PSLN-212(Y) vs PSLN-212', 'PSLN-212(Y)', 'PSLN-212'),
             ('C6 PSLN-344(Y) vs PSLN-212(Y)', 'PSLN-344(Y)', 'PSLN-212(Y)'), ('C7 PSLN-344 vs Vaccine', 'PSLN-344', 'Vaccine'),
             ('C8 PSLN-344 vs CMP-204', 'PSLN-344', 'CMP-204')]
    for (blk, t), d in v.groupby(['block', 'time'], sort=False):
        grp = {g: prep(blk, x.sort_values('animal').value.values)[0] for g, x in d.groupby('group')}
        scale = prep(blk, [1.0])[1]
        for name, a, b in pairs:
            if a in grp and b in grp and len(grp[a]) > 1 and len(grp[b]) > 1:
                diff, lo, hi, p = welch(grp[a], grp[b])
                try: pmw = stats.mannwhitneyu(grp[a], grp[b], alternative='two-sided', method='exact').pvalue
                except Exception: pmw = np.nan
                r = dict(block=blk, time=t, contrast=name, n_a=len(grp[a]), n_b=len(grp[b]), scale=scale, p_welch=p, p_mannwhitney_exact=pmw)
                if scale == 'log': r.update(ratio=10 ** diff, ratio_lo=10 ** lo, ratio_hi=10 ** hi)
                else: r.update(diff=diff, diff_lo=lo, diff_hi=hi, ratio=grp[a].mean() / grp[b].mean() if grp[b].mean() != 0 else np.nan)
                rows.append(r)
    return pd.DataFrame(rows)
def tukey_rows():
    rows = []
    for (blk, t), d in v.groupby(['block', 'time'], sort=False):
        if d.group.nunique() < 3: continue
        y = np.concatenate([prep(blk, x.value.values)[0] for g, x in d.groupby('group')])
        lab = np.concatenate([[g] * len(x) for g, x in d.groupby('group')])
        f, p = stats.f_oneway(*[prep(blk, x.value.values)[0] for g, x in d.groupby('group')])
        res = pairwise_tukeyhsd(y, lab)
        for row in res.summary().data[1:]:
            rows.append(dict(block=blk, time=t, anova_F=f, anova_p=p, group1=row[0], group2=row[1], meandiff=row[2], p_tukey=row[3], lower=row[4], upper=row[5], reject=row[6]))
    return pd.DataFrame(rows)
S = summary_rows(); Cn = contrast_rows(); T = tukey_rows()
S.to_csv('/tmp/outputs/tables/continuous_group_summaries.csv', index=False)
Cn.to_csv('/tmp/outputs/tables/continuous_contrasts.csv', index=False)
T.to_csv('/tmp/outputs/tables/continuous_anova_tukey.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 400)
c1 = Cn[Cn.contrast.str.startswith(('C1', 'C2'))].copy()
c1['effect'] = c1.apply(lambda r: f"x{r.ratio:.2f} [{r.ratio_lo:.2f},{r.ratio_hi:.2f}]" if r.scale == 'log' else f"{r['diff']:+.2f} [{r.diff_lo:+.2f},{r.diff_hi:+.2f}] (x{r.ratio:.2f})", axis=1)
print(c1[['block', 'time', 'contrast', 'n_a', 'n_b', 'effect', 'p_welch', 'p_mannwhitney_exact']].to_string())

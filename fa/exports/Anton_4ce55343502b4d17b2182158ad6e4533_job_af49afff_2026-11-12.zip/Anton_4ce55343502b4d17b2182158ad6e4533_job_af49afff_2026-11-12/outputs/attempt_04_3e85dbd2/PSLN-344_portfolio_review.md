---
title: "PSLN-344 (Mn-STING surfactant-biomimetic intranasal adjuvant, IAV vaccines for older adults): portfolio review"
subtitle: "Recommendation, evidence, data-integrity findings, mechanism, biomarker and forward plan"
date: "Analysis of adjuvant_program_dataset.xlsx (15 sheets, 105 data blocks) and adjuvant_program_annotation.pdf"
---

# How to check any number in this document

Every number carries a bracketed ledger ID, for example **[E19]**. Each ID points to a row in `evidence_ledger.xlsx` (also `.csv`), which gives:

- the source block;
- the exact sheet and cell range (for example `S06!G2:K30`);
- *n*;
- the reduction used (for example "geometric mean of per-animal titres, HAI 0 set to 5");
- any integrity flag.

The code that produced every value is in `code/`. It reads the workbook directly, and group names are read from the workbook header cells, never typed in. Running `code/run_all.sh` regenerates every table, figure and the ledger, and then checks that every cited ID and number matches the ledger (about 3 minutes). Numbers prefixed **E** are efficacy, **Q** data integrity, **M** immunogenicity or mechanism, **S** safety, and **P** planning calculations.

---

# 1. Recommendation

**Do not advance PSLN-344 into IND-enabling development on the current data package. Put it on hold behind a two-step, fixed-scope verification gate: an 8-week source-data audit, then, only if that passes, one independent replication. If the committee will not fund the gate, or the asset fails it, terminate.**

As recorded, the biology is striking. The problem is that the package cannot currently support it.

1. **The efficacy case rests on 11 aged-mouse challenge experiments. 10 of the 11 carry a data-integrity flag.**
   - The survival record of one experiment is an animal-for-animal copy of another [Q1].
   - Two experiments' survival records contradict their own body-weight records on which groups were even tested [Q7, Q8].
   - 11 of the 17 body-weight records paired with survival data share values copied from, or copied and then edited from, *other* experiments [Q2–Q6, Q21].
   - Death counts disagree between survival and weight records for 10 groups, including three PSLN-344 arms [Q9].
   - Only one aged experiment passes every check we ran: **S06-B**, n = 7 per arm (Figure 2).
2. **The "edited copy" pattern is not explainable by chance or by a single paste error.** Whole ordered columns of weight values from a post-vaccination tolerability experiment reappear in a day-60 H5N1 challenge experiment. The 5-digit decimal tails are identical and only the integer parts differ (Figure 4) [Q3]. At a standard 0.1 g balance, 18 of the 19 source values cannot be produced as 100 × weight / baseline for any baseline from 15 to 45 g [Q3, Q21]. The two records also describe different animals (aged mice after vaccination vs young mice after challenge), so the values cannot share a baseline at all. A partner's diligence team or a regulator would find this within hours, as I did.
3. **Even if every record verifies, the package lacks what an older-adult influenza adjuvant needs before IND-enabling spend:**
   - no licensed-type comparator (all comparisons are against sham or a Mn-free sibling);
   - no assessment of intranasal manganese in the olfactory bulb or CNS;
   - female mice only, and BALB/c for almost every readout;
   - n = 3–7 per arm in mostly single experiments;
   - no dose-ranging for protection;
   - no mucosal IgA;
   - no human-relevance data for the STING agonist;
   - no experiment that tests what actually causes the protection.

**Why hold rather than drop.** The recorded effect is large, and its direction survives every sensitivity cut.

- As recorded, aged-mouse survival is 68/80 (85%) with PSLN-344 against 1/80 (1%) with sham and 11/80 (14%) with the Mn-free formulation [E19, E20].
- In the one unflagged experiment it is 5/7 against 0/7 and 0/7 (log-rank p = 0.0002) [E35, E36].

Verifying this costs a small fraction of IND-enabling spend. What fails today is the evidentiary base, not the signal.

**Decision rule for the gate** (detail in Section 8):

- **Gate 0, ~8 weeks: independent source-data audit.** Pass only if raw contemporaneous records reproduce the survival counts of the pivotal experiments and explain the duplications.
- **Gate 1, months 2–10: one independent, blinded, pre-registered replication at a CRO.** Aged mice of both sexes and two strains, heterosubtypic challenge, a Mn-free arm and a licensed-type benchmark, built-in mechanism and biomarker arms, plus a non-GLP intranasal-Mn biodistribution pilot and human ex vivo STING work.
- Pass criteria for Gate 1 are fixed in advance:
  - PSLN-344 survival ≥ 60% and ≥ 35 percentage points above PSLN-212;
  - lung virus ≥ 1 log10 below sham;
  - non-inferior to the benchmark;
  - no olfactory or CNS manganese signal.
- Fail either gate and the asset is terminated.

---

# 2. The decision on one page

| Question | What the data say | Ledger |
|---|---|---|
| Does PSLN-344 protect aged mice? | As recorded, yes, and by a wide margin. Pooled risk difference vs sham +83.8 pp (95% CI 76.2 to 91.2); vs Mn-free PSLN-212 +71.2 pp (61.3 to 81.2); stratified log-rank p = 9.1e-34 and 3.7e-21. | E19, E20 |
| Is that defensible today? | No. 10/11 aged experiments are flagged. Excluding the Tier-1 experiments (survival record duplicated or conflicting), PSLN-344 is still 37/49 vs 0/49 sham and 4/49 PSLN-212. The only unflagged experiment has n = 7 per arm. | E27, E28, E35; Fig. 1–2 |
| Is Mn the active difference? | Yes, consistently. Mn-free PSLN-212 protects aged mice poorly (11/80) while PSLN-344 protects well. In young mice both work equally (8/8 vs 8/8 in three experiments), so Mn matters only in aged animals. | E20, E15–E17 |
| What does Mn restore? | Early lung type-I IFN in aged mice goes to the young level: Ifnb1 36.9× vs 16.5× with PSLN-212 vs 37.5× in young (restoration index 0.98). Across the 28 readouts in Figure 3 Mn closes a median 71% of the age gap (41–98%). The exception is DC CD40/CD86, where it closes only 17–22%. | M1, M82, Fig. 3 |
| Antibody? | IgG ×18.6, HAI ×8.0, neutralising ×9.2 vs PSLN-212 (CA09, day 14). HAI reaches 76% of young (GMT 368 vs 485). | M29–M31 |
| Breadth / T cells? | Cross-reactive IFN-γ+ CD8 T cells (H5N1 restimulation) ×4.2 at day 14 and ×3.2 at day 60; lung TRM ×4.0. | M16, M17, M19 |
| Safety signals? | Mild post-vaccination weight loss (nadir 96.4% vs 98.2% with vaccine alone, p = 0.065). No CNS Ifnb1/Tnf/Isg15 rise at 36 h, whereas the cholera toxin control rises. But in aged lungs Tnf and Il10 appear to persist at 72 h (17.8× and 36.6× the young benchmark; n = 3, flagged panel). Mn neuro-safety untested. | S1, S4, S6, Q23 |
| Biomarker to carry? | Early mucosal type-I IFN/ISG (16–24 h) as a pharmacodynamic and dose-selection marker. Cross-reactive CD8 T-cell function as the candidate efficacy correlate, to be qualified first. | Section 6 |
| What is missing? | Licensed comparator; Mn CNS/olfactory safety; both sexes; dose-ranging for protection; mucosal IgA; causal mechanism tests; same-animal correlates; human STING relevance; CMC (encapsulation 55% with a wide CI). | Section 8 |

---

# 3. The asset's best case: what the data claim, taken as recorded

This section is what we would be dropping. It takes every block at face value. Section 4 then shows what survives scrutiny.

## 3.1 Survival in aged mice

Table 3.1 shows the survivors over animals per arm for every aged challenge experiment, with PSLN-344 compared against sham and against PSLN-212 by two-sided Fisher exact test and log-rank test.

| Experiment (ledger) | Vaccine → challenge, timing | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | Integrity |
|---|---|---|---|---|---|---|
| S03-I [E1] | bivalent → CA09 10×LD50 (homologous), d14 | 0/7 | 0/7 | **7/7** | 7/7 | Tier 1 |
| S03-J [E2] | rgH5N1 → wild-type VN04 H5N1, d2 | 1/10 | 3/10 | **10/10** | - | Tier 1 |
| S06-A [E3] | Aichi H3N2 → PR8 H1N1, d14 | 0/7 | 1/7 | **6/7** | 7/7 | Tier 2 |
| **S06-B [E4]** | **Aichi H3N2 → PR8 H1N1, d3** | **0/7** | **0/7** | **5/7** | **7/7** | **no flag** |
| S06-C [E5] | bivalent → rgH5N1, d14 | 0/7 | 2/7 | **7/7** | 7/7 | Tier 1 |
| S06-D [E6] | bivalent → rgH5N1, d3 | 0/7 | 2/7 | **7/7** | 7/7 | Tier 1 (= S06-C) |
| S06-E [E7] | Aichi H3N2 → PR8, d60 | 0/7 | 0/7 | **5/7** | 7/7 | Tier 2 |
| S06-F [E8] | bivalent → rgH5N1, d60 | 0/7 | 1/7 | **5/7** | 7/7 | Tier 2 |
| S06-G [E9] | CA09 → Perth H3N2, d60 | 0/7 | 0/7 | **4/7** | 7/7 | Tier 3 |
| S15-L [E10] | aged C57BL/6, bivalent (challenge not stated) | 0/7 | 0/7 | **6/7** | 6/7 | Tier 2 |
| S15-N [E11] | aged Swiss Webster, bivalent (challenge not stated) | 0/7 | 2/7 | **6/7** | 7/7 | Tier 2 |

*Tier 1 = the survival record itself is duplicated or contradicts its weight record on group identity. Tier 2 = the companion weight record contains values copied or edited from other experiments. Tier 3 = death counts disagree between the survival and weight records. Definitions and evidence are in Section 4.*

**Taken as recorded, this is a strong profile:**

- **Magnitude.** Pooled PSLN-344 survival is 68/80 (85%), against 1/80 (1%) for sham and 11/80 (14%) for PSLN-212.
  - Mantel–Haenszel risk difference vs sham: +83.8 pp (stratified-bootstrap 95% CI 76.2 to 91.2).
  - Against PSLN-212: +71.2 pp (61.3 to 81.2) [E19, E20].
- **Breadth.** PSLN-344 protects against challenge by a different subtype from the vaccine: H3N2 vaccine against H1N1 PR8 (6/7) [E3], and H1N1+H3N2 vaccine against H5N1 (7/7) [E5]. It also protects against wild-type H5N1 (10/10) [E2].
- **Speed.** Challenge 2–3 days after vaccination: 22/24 (92%) vs PSLN-212 5/24 and sham 1/24 [E42].
- **Durability.** Challenge at day 60: 14/21 (67%) vs PSLN-212 1/21 and sham 0/21 [E43].
  - That 67% is not distinguishable from the background survival of *unchallenged, unvaccinated* aged animals observed over the same 14-day windows: 17/21 (81%), Fisher p = 0.48 [E39, E40].
  - Aged animals die at about 19% per 14 days without any challenge (Wilson 95% CI 8–40%) [E39]. They died without prior weight loss [Q22], so this looks like frailty rather than infection.
  - The apparent waning at day 60 may therefore partly be background mortality. Figure 6 (right) shows the PSLN-344 curve overlying the unchallenged controls in S06-G.
- **Generality.**
  - Aged C57BL/6: 6/7 vs 0/7 [E10]. Aged Swiss Webster: 6/7 vs 0/7 [E11].
  - Pre-existing immunity ("imprinting") does not blunt it: PSLN-344 gives 6/7 survival whether 14-month animals were PR8-imprinted or not, against both PR8 and Perth H3N2 [E12, E13].
- **Needs antigen.** Adjuvant alone given 3 days before H5N1: 0/7. Vaccine alone: 0/7. Both: 6/7 [E14].
- **Age-specific value.** In young mice PSLN-344 adds nothing over the Mn-free formulation: 8/8 vs 8/8 in three experiments, including day-180 H5N1 [E15–E17].

**The gap to young animals is real but modest.** As recorded, pooled PSLN-344 survival in aged mice is 58/70 (83%) against 69/70 (99%) for young animals given PSLN-212, a difference of −15.7 pp (−24.3 to −7.1) [E22]. Much of that gap sits in the day-60 experiments, where background mortality caps aged survival.

## 3.2 Immunogenicity: how much of the age deficit Mn closes

The restoration index (RI) is (aged PSLN-344 − aged PSLN-212) ÷ (young PSLN-212 − aged PSLN-212), computed on a log scale for titres and fold-changes:

- **0** means Mn adds nothing in aged animals.
- **1** means aged PSLN-344 matches the young benchmark.

![Figure 3](figures/fig3_restoration_index.png){width=80%}

| Readout (block) | Aged PSLN-212 | **Aged PSLN-344** | Young PSLN-212 | PSLN-344 / PSLN-212 | RI | Ledger |
|---|---|---|---|---|---|---|
| Lung Ifnb1 16 h, fold (S01-A) | 16.5 | **36.9** | 37.5 | 2.23× (Tukey p = 6.0e-4) | 0.98 | M1 |
| Lung monocytes d4, % (S01-D) | 16.7 | **30.6** | 32.2 | 1.83× | 0.89 | M5 |
| Migratory CCR7+ DC 72 h, % (S02-A) | 7.28 | **30.7** | 35.0 | 4.21× | 0.84 | M8 |
| Antigen+ DC in MLN 36 h, % (S02-C) | 1.77 | **7.09** | 9.39 | 4.01× | 0.70 | M10 |
| MLN DC CD40+ d3, % (S02-D) | 5.56 | **11.2** | 38.7 | 2.02× (p = 0.16) | **0.17** | M11 |
| MLN DC CD86+ d3, % (S02-D) | 8.13 | **14.5** | 37.9 | 1.79× | **0.22** | M12 |
| Lung Ki-67+ CD8 d3, % (S05-D) | 3.48 | **9.38** | 9.94 | 2.70× | 0.91 | M14 |
| IFN-γ+ CD8, H5N1 restim, d14, % (S05-F) | 1.50 | **6.36** | 9.18 | 4.23× | 0.63 | M16 |
| IFN-γ+ CD8, H5N1 restim, d60, % (S05-G) | 3.04 | **9.86** | 14.4 | 3.24× | 0.60 | M17 |
| Lung TRM CD8 d25, % (S05-I) | 1.00 | **3.96** | 6.04 | 3.96× | 0.59 | M19 |
| ICOS-hi Tfh d7, % (S04-A) | 3.82 | **10.3** | 13.6 | 2.69× | 0.66 | M22 |
| Tfr d7, % (lower is better) (S04-B) | 26.7 | **10.8** | 7.12 | 0.41× | 0.81 | M23 |
| GC B cells d7, % (S03-K) | 2.34 | **6.54** | 9.82 | 2.79× | 0.56 | M26 |
| Serum IgG CA09 d14, GMT (S03-A) | 393 | **7,305** | 11,959 | 18.6× | 0.86 | M29 |
| HAI CA09 d14, GMT (S03-C) | 46 | **368** | 485 | 8.0× | 0.88 | M30 |
| Neutralising CA09 d14, GMT (S03-D) | 418 | **3,840** | 6,686 | 9.2× | 0.80 | M31 |
| HAI Aichi d14, GMT (S03-G) | 35 | **320** | 368 | 9.2× | 0.94 | M33 |
| IgG CA09 after boost d28, GMT (S13-I) | 4,411 | **15,651** | 40,739 | 3.5× (p = 0.19) | 0.57 | M35 |
| IgG2a/IgG1, CA09 (recomputed, S13-A/B) | 0.54 | **1.85** | 2.50 | 3.4× (p = 0.016) | - | M46 |

**Reading the table.**

- Mn essentially normalises the *early* steps: lung IFN, monocyte recruitment and DC migration (RI 0.84–0.98).
- It recovers most of the age gap in T-cell, Tfh/GC and antibody readouts: RI 0.41–0.94, and every one of them ≥ 0.56 except early lung GZMB+ CD8 (0.41) [M82].
- It does **not** restore DC costimulation (CD40/CD86, RI 0.17–0.22). Yet protection is largely restored, so costimulation is not the step Mn fixes and is not a useful biomarker.
- The antibody profile shifts toward IgG2a (Th1). This is the opposite of what the printed S03-B/S03-F tables say, because those tables carry rotated group labels [Q10]. The corrected values are recomputed from the raw subclass titres in S13 [M46, M47].

## 3.3 Mn is the active ingredient, not delivery or dose

- **Not a dose effect.**
  - PSLN-344 at 10 µg gives Ifnb1 21.0×, at least as high as PSLN-212 at 40 µg (14.7×; p = 0.058) [M67].
  - The PSLN-344 dose–response is steeper (log–log slope 1.03 vs 0.68) and plateaus higher: 45.5× at 20 µg and 49.7× at 40 µg, p = 0.55 between those two doses [M70, M81] (Figure 5).
  - So Mn raises the ceiling rather than acting like more CDN. It also means 20 µg is already at the top of the curve, and about 10 µg is worth testing as a lower-Mn dose.
- **Not more cargo.** Encapsulation efficiency is 54.8% for PSLN-344 vs 59.6% for PSLN-212 (Tukey p = 0.86) [M44].
- **Not more epithelial uptake.** Mn *reduces* uptake of the liposome cargo by alveolar epithelial cells by 76–78% [M60, M61].
- **The Mn-free sibling is not a viable fallback in aged animals.** PSLN-212 gives aged survival of 11/80 [E20] and Ifnb1 at 44% of its young level [M73]. The cGAMP formulation CMP-204 is weaker still: Ifnb1 7.7× [M78] and 3/7 homologous survival [E1].

![Figure 5](figures/fig5_ifnb1_dose_and_age.png){width=100%}

---

# 4. Why the case is not yet defensible: data integrity

All of the following comes from the workbook itself. The scripts are in `code/qa_*.py`. I do not claim to know *why* these patterns exist. I claim that they are present, that they are not explainable by chance, and that they must be resolved against raw records before any efficacy claim is made to a partner or a regulator.

Some findings look like ordinary errors made while assembling the workbook: the rotated IgG subclass labels [Q10], the mislabelled timepoint [Q11] and the pasted neutrophil block [Q12]. The integer-edited decimal tails [Q3–Q5, Q21] and the duplicated survival experiment [Q1] are not of that kind, and those are the ones that touch efficacy.

## 4.1 Findings that touch the efficacy claim

| # | Finding | Evidence (cells) | What it undermines |
|---|---|---|---|
| Q1 | **S06-D (challenge day 3) is animal-for-animal identical to S06-C (challenge day 14).** All 28 records match. | `S06!M3:Q30` vs `S06!A34:E61` | One of the two is not an independent experiment. The early H5N1 claim cannot rest on S06-D. |
| Q2 | **The weight record for S15-H's combination arm (challenge day 3) is a copy of the S15-C PSLN-344 weights (challenge day 14).** Days 2–12 share 40/42 identical values, and the other 2 differ by only 0.1–0.3. The day-14 row differs: animal 3 is carried forward at 77.9 (a death) in S15-I but recovers to 90.1 in S15-C. | `S15!W23:AC30` vs `S15!W72:AC79` | The only experiment separating adjuvant-alone from vaccine-alone from the combination (S15-H). |
| Q3 | **S15-F young-arm weights (H5N1 at day 60) carry the 5-digit decimal tails of S08-D CMP-204 post-vaccination weights**, in the same animal/day order with different integer parts. 19 cells; 18 of the 19 source values cannot arise from a 0.1 g balance. | `S08!G22:K26` vs `S15!B54:E58`; Figure 4 | S06-F (durable H5N1 protection). |
| Q4 | **The S15-M weight record (aged C57BL/6) reuses S15-A (aged BALB/c) and S09-E (young BALB/c) values.** S15-M PSLN-212 day 4 equals S15-A sham day 4 (7/7). S15-M young arm at days 6–12 equals S09-E PSLN-344(Y); at days 2–4 the same tails appear with altered leading digits. | `S15!I103:AJ110` vs `S15!B3:AC10`, `S09!G39:AD46` | S15-L (the cross-strain claim). S15-O (Swiss Webster) also shares tails with S15-M. |
| Q5 | **The pattern is workbook-wide.** 71 distinct ≥5-digit decimal tails recur across 181 cells, 49 of them with different integer parts, concentrated in the S08-D, S09 and S15 weight blocks. Within S08-D one animal reads 95.69945 on day 6 and 100.69945 on day 8 [Q21]. | `tables/qa_fraction_fingerprints.csv` | All weight records, including the reactogenicity data. |
| Q6 | S09-C day-12 weights are identical (8/8) for PSLN-212(Y) and PSLN-344(Y). S09-C also shares 4 day-2 values with S09-E, a different experiment. | `S09!G18:N18` vs `W18:AD18`; `S09!W13:AD13` vs `W40:AD40` | S09-B and S09-D (young). |
| Q7 | **S03-I survival and its weight record S13-F disagree on which groups exist** (CMP-204 vs "Naive"). S03-I says PSLN-212 was 7/7 dead by day 6; S13-F weighs all 7 to day 14, with 3 recovering to 95–99%. | `S03!A17:F51` vs `S13!A33:AJ40` | Homologous-challenge comparator arms. (PSLN-344 7/7 and sham 0/7 agree in both records.) |
| Q8 | **S03-J vs S13-G also disagree on groups.** Sham has 9/10 deaths in the survival record vs 5 by weights. Stated n = 9 vs 10 observed. One PSLN-344 animal has no day value (`S03!G46`). | as listed | Wild-type H5N1 result. |
| Q9 | After allowing for carried-forward weights of dead animals: **10 group-level death-count mismatches and 4 group-identity mismatches** across 17 survival–weight pairs. PSLN-344 arms: S06-D 0 vs 2 deaths, S06-E 2 vs 1, S06-G 3 vs 2. | `tables/qa_survival_vs_weight.csv` | The primary endpoint is not internally consistent. |

![Figure 4](figures/fig4_fingerprint_S08D_vs_S15F.png){width=100%}

## 4.2 Findings that touch mechanism and immunogenicity

| # | Finding | Consequence in this review |
|---|---|---|
| Q10 | The IgG2a/IgG1 quotients printed in S03-B/S03-F carry **cyclically rotated group labels** relative to the raw subclass titres in S13-A to S13-D (exact to 3e-7). | Corrected values used [M46, M47]. Read as printed, S03-B implies a Th2 skew, which is the opposite of the raw data. |
| Q11 | The right-hand S09-A block, labelled "16 h", is S01-A **72 h** data (21/21 Ifnb1 values). The left block is a subset of S01-A 16 h. | S09-A is not independent confirmation. It is used only for the other cytokines, relabelled 72 h. |
| Q23 | S09-A also contains **5 pairs of identical 6-decimal log10 values in unrelated cells**, for example Tnf = Il10 for the same PSLN-212/R848 animal (2.302879). About 0.02 such pairs are expected by chance. | The lung cytokine readouts in Section 7 are treated as indicative only. |
| Q12 | S11-B (neutrophils) shares 35/100 per-animal values with S11-A (alveolar macrophages) at the same positions. Young "neutrophils" read 30–53%. | S11-B excluded. |
| Q13 | S01-B and S08-C share values. The same formulation, cell type and timepoint gives AECI uptake of 3.8% vs 13.8%. | Epithelial-uptake magnitudes treated as irreproducible; only the within-experiment contrasts are used. |
| Q14 | Tfh:Tfr is arithmetically (100 − Foxp3%) ÷ Foxp3% for all 20 values. | Not an independent Tfh measure; counted once (as Tfr). |
| Q15–Q16 | S07-C's two groups carry the same label. An unlabelled 13-row block sits at S08 rows 89–101. | Both excluded. |
| Q17 | Stated vs observed n conflicts: S03-J, S13-E, S05-A/B, S09-B, S09-F. | Observed n used. Flagged for audit. |
| Q18 | **Assay validity.** The S05-A/B NP366–374 tetramer is H-2Db-restricted, but the default strain is BALB/c (H-2d). The S02-E OT-I (H-2Kb) co-culture uses DCs from donors of unstated strain. | S05-A/B excluded. S02-E used with a caveat (Figure 3 asterisk). |
| Q19 | Missing metadata: no challenge virus, dose or day for S15-L/N; no timepoint for S07-B, S11-E, S13-H, S14-A; "PSLN-344/R848" is not a defined material; S08-B reports CDN-1807 encapsulation for a formulation without CDN-1807. | Resolve in the audit. |
| Q20 | Weak coincidences, recorded but **not** counted: for example, the same sham death-day pattern in S06-B and S06-F. | None. |

## 4.3 How the efficacy conclusion changes

| Subset | Experiments | PSLN-344 | Sham | PSLN-212 | PSLN-344 − sham (95% CI) | Ledger |
|---|---|---|---|---|---|---|
| A. As recorded | 11 | 68/80 (85%) | 1/80 | 11/80 | +83.8 pp (76.2 to 91.2) | E19, E20 |
| B. Minus the duplicate S06-D | 10 | 61/73 (84%) | 1/73 | 9/73 | +82.2 pp (74.0 to 90.4) | E23, E24 |
| C. Minus Tier 1 | 7 | 37/49 (76%) | 0/49 | 4/49 | +75.5 pp (63.3 to 85.7) | E27, E28 |
| D. Minus Tiers 1 and 2 | 2 (S06-B, S06-G) | 9/14 (64%) | 0/14 | 0/14 | +64.3 pp (35.7 to 85.7) | E31, E32 |
| E. No flag of any kind | 1 (S06-B) | 5/7 (71%) | 0/7 | 0/7 | +71.4 pp (42.9 to 100) | E35, E36 |

![Figure 1](figures/fig1_survival_forest_by_integrity.png){width=100%}

**Interpretation.**

- The direction and rough size of the effect survive every cut.
- What collapses is the *number of independent, trustworthy experiments*: from 11 to 1.
- The one unflagged experiment is a heterosubtypic challenge given only 3 days after vaccination (Figure 6, left). Taken alone it is encouraging but cannot carry an IND-enabling decision.
- A worst-case reconciliation changes little. Taking, for each PSLN-344 arm, the larger of the survival-record and weight-record death counts adds only 2 deaths overall [Q9]. The integrity problem is about provenance, not an obviously inflated PSLN-344 effect.

![Figure 2](figures/fig2_integrity_map.png){width=75%}

![Figure 6](figures/fig6_km_S06B_S06G.png){width=100%}

---

# 5. What is actually driving protection

**Working model.** It is the best fit to these data, but it is *not yet causally tested against survival*.

> **Intranasal Mn²⁺ amplifies STING signalling from the CDN cargo in the aged lung. This restores an early type-I IFN (and GM-CSF) burst that ageing blunts. That burst drives CCR2-dependent monocyte recruitment and IFNAR-dependent differentiation of monocyte-derived DCs, and restores DC migration and antigen delivery to the mediastinal lymph node. Two arms follow:**
>
> **(i) cross-reactive effector and lung-resident CD8 T cells.** This is the only measured arm that can explain protection against a *different HA subtype* and protection within 2–3 days of vaccination.
>
> **(ii) Tfh/germinal-centre-driven, Th1-skewed antibody.** This plausibly accounts for homologous protection.
>
> **Mn also transiently lowers follicular and lung regulatory T cells.**

| Link | Evidence | Strength |
|---|---|---|
| Mn amplifies early IFN in aged lung | Ifnb1 2.23× vs PSLN-212 and equal to young [M1, M73–M75]. Dose-dependent, with a higher plateau [M67–M70]. Gm-csf 5.4× at 36 h [M3]. | Strong (consistent across S01-A and S08-A; S09-A duplicates S01-A) |
| IFN/GM-CSF drive moDC differentiation | Ifnar-/- bone marrow yields 89% fewer moDC (2.09 vs 19.7%); rGM-CSF partly rescues (12.4%) [M48–M50]. rGM-CSF lifts PSLN-212 moDC 2.4× [M51]. IFNAR-deficient marrow still supports monocyte *recruitment* (−28%, p = 0.12, n = 3) [M57], so IFN acts mainly on differentiation. | Moderate (chimeras; recipient age not stated; young in S12-A) |
| CCR2+ monocytes are required | CCR2 antagonist: lung monocytes −67% [M53], Ly6C+ macrophages −84% [M54], lung GZMB+ CD8 −79% [M52, *young* mice]. Gap-junction blocker −58% monocytes [M56]. | Moderate (no protection readout; key CD8 test done in young mice) |
| DC migration and antigen transport | Migratory DC 4.2× [M8]; antigen+ MLN DC 4.0× [M10]. Pertussis toxin blocks MLN antigen+ DC (−67%) [M63] and MLN OT-I priming (−78%) but **not** lung OT-I proliferation (−7%) [M65, M66]. | Moderate. The PTX data suggest a lung-local priming component. |
| CD8 effector, memory and breadth | Ki-67+ CD8 at d3, RI 0.91 [M14]. IFN-γ+ CD8 to H5N1 antigen ×4.2 (d14) and ×3.2 (d60) [M16, M17]. GZMB+ at d60 ×4.0 [M18]. TRM ×4.0 [M19]. | Moderate (group level; no depletion) |
| Antibody / Tfh | Tfh 2.7× [M22], Tfr −59% [M23], GC B 2.8× [M26], HAI 8× [M30], IgG2a/IgG1 Th1 shift [M46]. | Strong for immunogenicity; causal role not tested |
| What protection requires | Heterosubtypic protection (different HA subtype) cannot be HAI-mediated. Vaccine plus adjuvant is needed; adjuvant alone gives 0/7 [E14, Tier 2]. All PSLN-212 animals reach HAI ≥ 40 (5/5) yet PSLN-212 protects poorly [M79, E20]. | Inference; points to T cells for breadth |

**What I considered and could not support.**

- **Non-specific innate protection** from adjuvant-induced interferon. Contradicted by S15-H, adjuvant alone 0/7 [E14], with the caveat that S15-H carries a Tier-2 flag.
- **Antibody alone.** Cannot explain cross-subtype protection. HAI ≥ 40 does not separate well-protected from poorly protected arms [M79].
- **Better delivery.** Encapsulation is unchanged and epithelial uptake is *lower* with Mn [M44, M60].
- **Restored DC costimulation.** Not restored (RI 0.17–0.22) [M11, M12].
- **NK cells or alveolar macrophages.** No Mn effect: NK p = 0.13 [M40]; alveolar macrophages RI 0.08 [M39].

**What it would take to establish the mechanism.** No experiment in the package:

- depletes CD8 or CD4 T cells before challenge;
- transfers immune serum;
- blocks IFNAR or CCR2 in **aged** mice with a **survival** readout;
- measures a candidate marker and survival **in the same animals**.

Those are the experiments in Section 8 (Study 2 and Study 3).

---

# 6. Biomarker of efficacy

## 6.1 Candidates, scored on the data

| Candidate | Mn effect in aged (Hedges g; ratio) | Restores toward young? | Dose-response? | Which protection does it track? | Accessible in patients? | Verdict |
|---|---|---|---|---|---|---|
| **Early mucosal type-I IFN** (lung Ifnb1 at 16 h) [M1, M41–M43, M67–M75] | g 5.6; 2.23× | Yes, RI 0.98 | Yes; plateau at 20–40 µg | Upstream of all arms; group-level only | Yes: nasal ISG/IFN at 16–24 h (nasal lining fluid, curettage) and blood ISG score at day 1 | **Carry forward as the pharmacodynamic (PD), dose-selection and age-bridging biomarker** |
| Gm-csf 36 h [M3] | g 7.9; 5.4× | no young arm | no data | upstream of moDC | nasal GM-CSF protein | Secondary PD marker |
| **Cross-reactive CD8 function** (IFN-γ+, GZMB+ after restimulation) [M16–M18, M20, M21] | g 5.8 (d14), 2.8 (d60); 3–4× | Partly, RI 0.60–0.68 | not tested | Heterosubtypic **and** durable (d60) | Yes: PBMC ELISpot / granzyme B with conserved NP/M1 antigens | **Candidate efficacy correlate; qualify before clinical use** |
| Lung TRM [M19] | g 5.2; 3.96× | RI 0.59 | - | breadth, durability | No (lung); nasal brushings are research-only | Mechanistic only |
| HAI [M30, M33, M79] | g 4.0; 8× | RI 0.88–0.94 | - | homologous only; 5/5 PSLN-212 ≥ 40 yet poor protection | Yes (regulatory standard) | Keep as regulatory immunogenicity endpoint; **not** the marker of this adjuvant's differentiation |
| Tfh:Tfr [Q14] | derived | - | - | - | circulating Tfh at day 7 | Replace with a direct circulating-Tfh measure |
| DC CD40/CD86 [M11, M12] | - | No (RI 0.17–0.22) | - | does not track protection | - | **Rule out** |
| IgG2a/IgG1 [Q10, M46] | label conflict | - | - | - | no human equivalent | **Rule out** |

## 6.2 Recommendation on the biomarker

- **Carry forward: early mucosal type-I IFN / ISG signature at 16–24 h.**
  - It is the most proximal, Mn-specific, dose-responsive readout in the package.
  - It cleanly separates PSLN-344 from its Mn-free sibling in aged animals (36.9× vs 16.5×, Welch p = 9.6e-6).
  - It brings the aged response to the young benchmark (36.9× vs 37.5×, p = 0.82) [M1, M74, M75].
  - **It could go into patients:** nasal sampling at 16–24 h plus a day-1 blood ISG score is minimally invasive.
  - **Its role is pharmacodynamic, not a surrogate:**
    1. Phase 1 dose selection. The mouse curve plateaus between 20 and 40 µg, so the PD marker should locate the human plateau and the lowest dose reaching it, limiting Mn exposure.
    2. Age-bridging. Target: older adults at the chosen dose reach the IFN response of younger adults, the human analogue of RI ≈ 1.
    3. A safety ceiling. Aged mouse lungs appear to keep Tnf and Il10 elevated at 72 h [S4; n = 3, panel flagged Q23], so the same panel, extended to 72 h, serves as a reactogenicity guard-rail.
  - It is **not** a correlate of protection. Its link to survival is group-level only.
- **Qualify, then carry forward: cross-reactive CD8 T-cell function.**
  - It is the only measured readout that can explain protection across HA subtypes.
  - It is still elevated at day 60, when protection persists [M17, M18].
  - It needs a same-animal correlates study (Study 3) before it is used as more than an exploratory endpoint.
  - In patients, the role is an exploratory immunogenicity correlate in Phase 1/2 alongside HAI and microneutralisation (MN), to be validated in a human challenge or field-efficacy setting.
  - *External context, not from our data:* ex vivo granzyme B and IFN-γ responses of PBMC to influenza have been reported to track protection in older adults better than HAI. That is why this arm is worth qualifying.

## 6.3 Could PSLN-344 itself go into patients, and in what role?

**Not yet.** First-in-human dosing needs Gates 0–1 passed, intranasal-Mn toxicology (Study 6) and a controlled product (Study 4). If those are met, the data point to one role and rule out others.

**Role the data support:** an **intranasal adjuvant co-administered with an inactivated influenza vaccine in adults ≥ 65.**

- It should be positioned on **breadth and speed**: heterosubtypic protection and protection within 2–3 days of vaccination.
- It should *not* be positioned on HAI alone. Aged HAI with PSLN-344 reaches 76–87% of young, not above it [M30, M33].
- The highest-value setting is **pre-pandemic and pandemic H5 use and outbreak response**, for example long-term-care facilities, where cross-subtype protection and rapid onset matter most [E2, E5, E42]. This depends on those specific experiments verifying.

**Roles the data argue against:**

- a stand-alone innate prophylactic (adjuvant alone 0/7 [E14]);
- an adjuvant for younger adults (no incremental benefit in young mice [E15–E17]).

**Untested but worth building into Phase 1/2:** an intranasal PSLN-344 *booster* layered on a licensed intramuscular vaccine. No experiment here tests it.

---

# 7. Safety and reactogenicity

| Signal | Data | Ledger |
|---|---|---|
| Post-vaccination weight (no challenge) | PSLN-344 nadir 96.4% of baseline (min 94.2) vs vaccine alone 98.2% (p = 0.065). PSLN-212/R848 nadir 90.0% (min 84.7, p = 0.020), with one animal missing at day 10. | S1 (the S08-D record itself carries Q3/Q21 flags) |
| Lung cytokines, 16 h | Aged PSLN-344 vs young PSLN-212 benchmark: Ifnb1 0.96×, Il6 0.60×, Ccl2 0.42×, but **Tnf 2.92× (p = 0.009) and Il10 3.98× (p = 0.021)**. n = 3 per group; panel carries a Q23 flag. | S2, Q23 |
| Lung cytokines, 72 h | **Tnf 17.8× (p = 0.008), Il10 36.6× (p = 0.002)** vs the young benchmark (n = 3; Q23 flag). Ifnb1 still 4.17× vs 1.46× (p = 0.0067; from S01-A, n = 5). | S4, M76, Q23 |
| CNS at 36 h | PSLN-344 vs PBS: Ifnb1 1.27 vs 0.98 (p = 0.50), Tnf 1.54 vs 0.98 (p = 0.12), Isg15 1.12 vs 0.96 (p = 0.77). Cholera toxin control: 5.4×, 3.3×, 2.6× (all p < 0.0001). | S6 |
| Not assessed | Mn in olfactory bulb or brain; olfactory epithelium or facial-nerve histology; repeat-dose; systemic cytokines; lung histopathology; males. | - |

**Reading.**

- Acute tolerability looks acceptable, although the weight record it rests on carries integrity flags. The innate CNS readout is clean.
- Two issues must be closed before anyone doses humans:
  1. **Intranasal manganese.** *External context:* manganese is known to travel along olfactory neurons to the brain in rodents. The only CNS data here are three transcripts at one timepoint, n = 5.
  2. **A possible prolonged inflammatory tail in aged lungs** (Tnf/Il10 at 72 h). The evidence is n = 3 per group from a panel with its own integrity flag [Q23], so it needs re-measurement, but it should not be ignored.
- *External context:* the precedent of an intranasal, toxin-adjuvanted influenza vaccine withdrawn over Bell's palsy is why regulators will ask for cranial-nerve and olfactory endpoints.
- The R848 combinations are more reactogenic on every measure [S1, S3, S5] and add nothing to Ifnb1 [M71].

---

# 8. Forward plan: what the next studies must establish

Timings are planning estimates from the decision date and are not derived from the dataset. Sample sizes come from `code/power_calcs.py` [P1–P5].

## 8.1 Overview and sequence

| # | Study | Establishes | Timing | Gate |
|---|---|---|---|---|
| 0 | Source-data audit | The recorded data are genuine | Weeks 0–8 | **Gate 0**: pass or terminate |
| 1 | Independent confirmatory efficacy in aged mice, with a non-GLP Mn biodistribution pilot | The effect is real, in both sexes, against a licensed-type benchmark; no early olfactory/CNS Mn signal | Months 2–10 | **Gate 1** core |
| 2 | Mechanism of protection | Which immune arm is necessary or sufficient | Months 2–10 (parallel) | informs Gate 1 |
| 3 | Same-animal correlates | Which biomarker predicts individual protection | Months 2–8 (shares animals with Study 1) | informs Gate 1 |
| 4 | CMC / formulation | A reproducible product with controlled Mn | Months 2–8 (parallel) | Gate 1 |
| 5 | Human ex vivo STING and Mn | The mouse mechanism translates to human cells and older donors | Months 2–6 (parallel) | Gate 1 |
| 6 | Intranasal Mn safety / GLP toxicology | No olfactory, CNS or local toxicity | Months 10–19 | **Gate 2** (IND) |
| 7 | Ferret heterologous challenge | Protection and reduced shedding in a second species | Months 10–16 | supportive |
| 8 | First-in-human | Safety, PD-guided dose, older-adult bridging | ~12 months after IND | - |

## 8.2 Study-by-study specification

**Study 0: Source-data audit (Gate 0)**

- **Must establish:** every survival, weight and key immunology block traces to contemporaneous raw records, and Q1–Q19 are resolved.
- **Population (scope):** all 105 blocks. Priority:
  - the survival blocks and their weight records (S03-I/J, S06, S15, S09, S13);
  - S03-B/F (label rotation);
  - S02-E and S05-A/B (mouse strain and MHC).
- **Comparator:** raw records:
  - animal-room census and death/euthanasia logs;
  - balance or LIMS exports;
  - flow cytometry FCS and workspace files;
  - qPCR run exports;
  - ELISA and HAI plate files.
- **Endpoints:** % of pivotal blocks verified; a documented cause for each duplication.
- **Readouts:** audit report by QA independent of the generating lab.
- **Timing:** 6–8 weeks.
- **Go / no-go:** go if the PSLN-344, PSLN-212 and sham survival counts of S06-A to S06-G and S15-H/L/N reproduce from raw records, and each copy has a documented benign cause. Otherwise terminate.

**Study 1: Independent, blinded, pre-registered confirmatory efficacy (Gate 1 core)**

- **Must establish:** the aged-mouse protection is real and reproducible in both sexes and two strains, what Mn contributes, and where the effect sits against a licensed-type benchmark.
- **Population:**
  - aged (≥ 20 months) BALB/c and C57BL/6, **both sexes**, health-screened;
  - young (8–10 weeks) reference;
  - unvaccinated, unchallenged aged arm to measure background mortality (about 19% per 14 days in this colony [E39]).
- **Comparators:** vaccine plus each of the following:
  - empty liposome (sham);
  - PSLN-212 (Mn-free);
  - PSLN-344 at 20 µg and at 10 µg (10 µg is about half of peak Ifnb1 [M42]);
  - a **licensed-type benchmark**: squalene-emulsion adjuvant given intramuscularly, or high-dose IM vaccine;
  - young animals + PSLN-212;
  - a PSLN-344-alone arm in the day-3 cohort.
- **Endpoints:**
  - primary: **survival to day 14** after heterosubtypic challenge (H3N2 vaccine → PR8; bivalent → H5N1) and homologous CA09 challenge, at day 3, day 28 and **day 90** after vaccination. Pre-specified humane endpoint, blinded assessors.
  - key secondary: **lung viral titre** (day 3 and day 5 satellite animals), weight-loss AUC, lung histopathology.
- **Readouts:**
  - survival; plaque or TCID50 titres; histology scores; electronic balance capture (no manual transcription);
  - **non-GLP Mn pilot:** Mn by ICP-MS in olfactory bulb, brain and blood, plus olfactory-epithelium histology, in a satellite subset at days 3 and 28, with PSLN-212 as the Mn-free control.
- **Sample size:**
  - 12 per arm per sex and strain for PSLN-344 vs PSLN-212 and vs sham, which gives ≥ 90% power at the recorded rates [P1, P2];
  - 32–42 per arm if the benchmark comparison uses survival, or 15–29 per arm with lung viral titre as its primary [P3, P5].
- **Timing:** about 7–8 months; aged-mouse supply is rate-limiting.
- **Go / no-go (fixed in advance):**
  - PSLN-344 survival ≥ 60% and ≥ 35 pp over PSLN-212 (recorded, excluding Tier 1: 76% vs 8%, +67 pp [E27, E28]);
  - lung virus ≥ 1 log10 below sham;
  - non-inferior to the benchmark on lung virus and survival;
  - no excess deaths vs the unchallenged aged arm at day 90;
  - no olfactory-bulb or brain Mn accumulation above the PSLN-212 control in the pilot.

**Study 2: What drives protection**

- **Must establish:** which immune arm is necessary or sufficient for protection in *aged* mice.
- **Population:** aged C57BL/6 (better reagents: tetramers, knockouts), ± aged BALB/c.
- **Comparators:** isotype or vehicle controls; PSLN-212.
- **Interventions:**
  - **CD8 depletion** (and CD4 depletion) before challenge;
  - **passive transfer of immune serum** from PSLN-344-vaccinated aged donors, then homologous vs heterosubtypic challenge;
  - **IFNAR blockade** and a **CCR2 antagonist** at vaccination, in aged mice with a challenge readout (the existing CCR2 data have no protection readout, and the key CD8 effect was shown in young mice [M52]);
  - FTY720 during challenge to separate resident from circulating memory.
- **Endpoints:** survival, lung viral titre, weight AUC.
- **Readouts:** depletion confirmation by flow cytometry; HAI/MN of transferred serum; NP366–Db tetramer+ CD8; intravascular labelling for TRM.
- **Timing:** 6–8 months, parallel with Study 1.
- **Go / no-go:** not a go/no-go study. It defines the mechanism claim and which biomarker to qualify. If the working model is right, CD8 depletion removes most heterosubtypic protection, and serum transfer protects against homologous but not heterosubtypic challenge.

**Study 3: Same-animal correlates (biomarker qualification)**

- **Must establish:** which pre-challenge measurement predicts protection in the *same* animal. No existing experiment allows this.
- **Population:** aged mice across 0, 5, 10, 20 and 40 µg PSLN-344 (to spread the responses), about 15 per dose.
- **Comparators:** PSLN-212; sham.
- **Endpoints:** individual survival, lung virus and weight-AUC vs pre-challenge markers; ROC AUC; threshold.
- **Readouts:**
  - 16–24 h nasal-wash ISG/IFN-β/λ and serum IP-10 (the PD panel);
  - day 14 and 28 HAI, MN and IgG;
  - **nasal IgA**;
  - blood PBMC IFN-γ and granzyme B after restimulation with conserved NP/M1;
  - then heterosubtypic challenge.
- **Timing:** 5–6 months; shares animals with Study 1.
- **Go / no-go:** carry a marker into Phase 1 as an exploratory correlate if its AUC ≥ 0.75 and it shows a monotone dose-response.

**Study 4: CMC / formulation**

- **Must establish:** a reproducible product with controlled manganese.
- **Population:** engineering batches.
- **Comparators:** PSLN-212; free CDN; free Mn.
- **Endpoints:**
  - encapsulation efficiency (currently 54.8%, 95% CI 42–67 [M44]);
  - Mn content and free Mn;
  - particle size, PDI and zeta potential;
  - lyophilised stability at −20 °C, 2–8 °C and 25 °C;
  - a potency assay.
- **Readouts:** A260/HPLC, ICP-MS, DLS/TEM, ISG-reporter cell potency.
- **Timing:** 3–6 months, parallel.
- **Go / no-go:** encapsulation and potency CVs within pre-set limits; ≥ 6-month stability.

**Study 5: Human relevance (ex vivo)**

- **Must establish:** CDN-1807 ± Mn activates human STING across the common alleles, and Mn restores responses in cells from older donors.
- **Population:**
  - PBMC and nasal-epithelium air–liquid-interface cultures from donors ≥ 65 vs 18–40, genotyped for STING;
  - STING-variant reporter lines.
- **Comparators:** PSLN-212; free CDN; cGAMP.
- **Endpoints:** IFN-β/λ and ISG EC50 and Emax; TNF and IL-6; viability.
- **Readouts:** ELISA/Luminex, qPCR, reporter assays.
- **Timing:** 3–4 months, parallel.
- **Go / no-go:** Mn potentiation in the major alleles; older-donor cells reach younger-donor responses at feasible concentrations.

**Study 6: Intranasal Mn safety and IND-enabling toxicology (after Gate 1)**

- **Must establish:** no local, olfactory or CNS toxicity at the clinical regimen plus one dose.
- **Population:** rat or rabbit (an immunologically responsive species) with recovery groups; an exploratory aged cohort.
- **Comparators:** vehicle; empty liposome; **PSLN-212, to attribute any effect to Mn**; adjuvant alone; vaccine alone.
- **Endpoints:**
  - histopathology of nasal cavity, olfactory epithelium and bulb, brain, facial and trigeminal nerves, and lung;
  - **Mn in olfactory bulb, brain and blood (ICP-MS)**;
  - functional observation battery;
  - systemic IFN, IL-6, TNF and IP-10;
  - clinical pathology.
- **Readouts:** GLP toxicology package.
- **Timing:** 6–9 months.
- **Go / no-go:** no Mn accumulation or histology signal above the Mn-free control; no persistent systemic inflammation.

**Study 7: Ferret heterologous challenge (supportive)**

- **Must establish:** protection and reduced viral shedding in a second species with a human-like respiratory tract.
- **Population:** adult ferrets (aged if available).
- **Comparators:** sham; PSLN-212; licensed-type benchmark.
- **Endpoints:** nasal-wash shedding AUC; clinical score; optional transmission.
- **Readouts:** viral titres; clinical scores.
- **Timing:** 4–6 months, alongside Study 6.
- **Go / no-go:** shedding reduced vs the benchmark.

**Study 8: First-in-human (only after Gates 0–2)**

- **Population:** healthy adults 18–49 as a sentinel and dose-escalation cohort, then adults ≥ 65.
- **Comparators:** intranasal vaccine alone; a **licensed enhanced IM vaccine for ≥ 65** (adjuvanted or high-dose).
- **Endpoints:**
  - **safety:** solicited nasal and systemic AEs for 7 days; unsolicited AEs for 28 days; AESI including cranial-nerve palsy and olfactory loss (by smell test); 6–12-month follow-up;
  - **PD:** nasal and blood ISG at 16–24 h;
  - **immunogenicity:** HAI/MN at day 28; nasal IgA; cross-reactive T cells at day 28 and day 180;
  - blood Mn.
- **Timing:** about 12 months after IND.
- **Go / no-go:** a dose at the PD plateau with acceptable reactogenicity, at which older adults reach the younger-adult PD response.

---

# 9. If we drop PSLN-344: what we are dropping, and why

**What we would be dropping.**

1. A candidate intranasal adjuvant whose recorded preclinical profile is unusually well matched to older adults:
   - it normalises the early innate defect of the aged lung [M1];
   - it closes most of the age gap in CD8, Tfh/GC and antibody responses (Figure 3);
   - as recorded, it protects aged mice across subtypes, strains, prior imprinting and challenge timings from 2 to 60 days [E19, E41–E43].
2. A mechanistic thesis, Mn-amplified STING signalling, that would position the product on **breadth and speed of onset** rather than HAI alone. That matters because, as external context, licensed high-dose and adjuvanted vaccines for older adults already compete on HAI.
3. A ready-made pharmacodynamic biomarker (early mucosal IFN/ISG) for a rational human dose search.

**Why we would drop it.**

1. The protection evidence, the reason to spend, is **not verifiable as recorded**. 10 of 11 aged experiments are flagged, including copied and edited values across experiments [Q1–Q9]. Only one n = 7 experiment is unflagged [E35].
2. Even if verified, the package answers "better than sham and better than its own Mn-free version". It does not answer "better than what older adults already get", and it says nothing on intranasal manganese safety.

**What would make it worth reopening:** either verified raw data (Gate 0) or an independent replication (Gate 1).

**If terminated, preserve:**

- raw data, samples and notebooks under QA hold (needed for the audit regardless);
- the formulation know-how and IP for the Mn-coordinated liposome;
- the early-IFN/ISG PD assay, which transfers to any mucosal STING-agonist programme.

---

# 10. Considered and ruled out

**Portfolio options**

| Option | Why not |
|---|---|
| Advance now to IND-enabling | Integrity findings [Q1–Q9]; no licensed comparator; Mn neuro-safety untested. An external auditor would find the integrity issues. |
| Terminate outright today | Premature. The direction of the effect survives every sensitivity cut [E19–E36], and verification is cheap relative to what is at stake. Acceptable if the gate is not funded. |
| Pivot to the Mn-free PSLN-212 | Fails in aged mice: survival 11/80 [E20], Ifnb1 44% of its young level [M73], poor DC migration [M8]. |
| Pivot to cGAMP (CMP-204) | Weaker than PSLN-212: Ifnb1 0.46× [M78]; IgG GMT 181 [M29]; 3/7 homologous survival [E1]. |
| TLR7/8 (R848) combinations | More reactogenic: weight nadir 90.0%, one animal missing at day 10 [S1]; Tnf 5× and Il10 24.5× vs PSLN-344 at 16 h [S3]. Lower Ifnb1 [M71]. |
| Position for younger adults | No incremental benefit in young mice: 8/8 vs 8/8 in three experiments [E15–E17]. |
| Stand-alone innate prophylaxis (no antigen) | Adjuvant alone 0/7 [E14]. |

**Mechanistic alternatives:** non-specific innate protection, antibody-only protection, improved delivery or encapsulation, a simple dose effect, restored DC costimulation, NK or alveolar-macrophage involvement. Each is set out in Section 5, and none is supported.

**Biomarkers:** HAI as *the* differentiating marker, Tfh:Tfr, IgG2a/IgG1, DC CD40/CD86, NP-tetramer, and neutrophils. Reasons are in Section 6.1 and Q10–Q18.

**Analytic choices**

| Choice considered | Decision |
|---|---|
| Use body-weight AUC as an efficacy endpoint | Rejected as primary. Most integrity findings sit in weight records, and weights of dead animals are carried forward inconsistently, which biases means. Used only for consistency checks. |
| Individual-level correlates | Impossible. No experiment measures a marker and survival in the same animals. |
| Treat S09-A as independent confirmation of S01-A | Rejected [Q11]. |
| Read S03-B/S03-F as printed | Rejected. Recomputed from S13 [Q10]. |
| Count the unlabelled S08 block as survival data | Excluded [Q16]. |
| Sato variance for the pooled risk difference | Replaced by a stratified bootstrap. The Sato variance gives CIs above 100% with zero-event arms. |
| Adjust survival for background mortality | Not done. Reported as context [E39, E40]. |

---

# Appendix A. Methods and reductions

- **Parsing.** `code/psln_blocks.py` contains an explicit registry of all 105 blocks: sheet, header row, data cells. It was transcribed from the annotation and verified cell by cell. Group names are read from header cells. Observed n is used wherever stated and observed n differ [Q17].
- **Survival.** Survivors are animals with event indicator 0.
  - Per experiment: two-sided Fisher exact test; log-rank (statsmodels `survdiff`); risk difference with Newcombe (Wilson-score) 95% CI.
  - Pooled: Mantel–Haenszel risk difference with weights n₁n₂/(n₁+n₂), 95% CI from 4,000 stratified bootstrap replicates (animals resampled within experiment × group), and a log-rank test stratified by experiment.
- **Titres.** Geometric mean titre with a t-based 95% CI on the log10 scale. HAI "0" (below the 1:10 starting dilution) is set to 5.
- **Fold-change qPCR.** Geometric means; tests on log10.
- **Percent readouts.** Arithmetic mean with t-based 95% CI.
- **Tests.** One-way ANOVA with Tukey HSD across the groups of each block (the annotation's stated method; statsmodels reports p < 0.0001 as 0), plus Welch t-tests and Hedges' g for the PSLN-344 vs PSLN-212 contrast.
- **Restoration index.** (PSLN-344 − PSLN-212) ÷ (PSLN-212(Y) − PSLN-212), on the log scale for titres and fold-changes.
- **Integrity checks.**
  - `qa_duplicates.py` and `qa_duplicates_strong.py`: same-position identity of ≥ 4 values (chance ≈ 3×10⁻⁷ per pair for 0.1-resolution weights), or ≥ 2 shared values with ≥ 3 decimals.
  - `qa_fraction_fingerprint.py`: recurring ≥ 5-digit decimal tails.
  - `qa_tail_lattice.py`: whether a value can be produced as 100·w/w₀ at 0.1 g or 0.01 g balance resolution for a baseline of 15–45 g.
  - `qa_surv_vs_weight.py`: deaths inferred from animals disappearing, or from values frozen to day 14 (≥ 3 identical trailing values, or 2 below 85%).
  - `qa_survival_dups.py`, `qa_derived.py` and `qa_s09a_internal.py`.
- **Sample sizes.** `power_calcs.py`: simulated Fisher power (20,000 replicates) and t-test power.
- **Run order (`code/run_all.sh`):** `psln_blocks.py`, the `qa_*.py` scripts, `efficacy_survival.py`, `efficacy_pooled_boot.py`, `immuno_mechanism.py`, `safety_and_corrections.py`, `mechanism_extra.py`, `power_calcs.py`, `build_ledger.py`, `figures.py`.
- **Environment.** Python 3.11 with pandas, scipy, statsmodels, openpyxl and matplotlib (conda env `chem`).

# Appendix B. Deliverables

- `PSLN-344_portfolio_review.md` / `.docx`: this report.
- `evidence_ledger.xlsx` / `.csv`: 160 entries; every number with its cells and reduction.
- `figures/`: Figures 1–6.
- `tables/`: all intermediate tables, including per-animal survival, group summaries and every QA output.
- `code/`: all scripts.

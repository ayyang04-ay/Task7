"""Pooled survival effect with stratified-bootstrap CIs + background-mortality ceiling.
Reduction:
  MH risk difference = sum_k w_k (p1k - p2k) / sum_k w_k, w_k = n1k n2k/(n1k+n2k), k = experiment.
  95% CI = percentile interval of 4000 stratified bootstrap replicates (animals resampled with replacement
  within experiment x group).  Stratified log-rank p from efficacy_survival.py.
"""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.proportion import proportion_confint
from statsmodels.duration.survfunc import survdiff
rng = np.random.default_rng(20260915)
ALL = pd.read_csv('/tmp/outputs/tables/survival_all_animals.csv')
ALL['surv'] = (ALL.event == 0).astype(int)
AGED = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N']
TIER1 = {'S06-C', 'S06-D', 'S03-I', 'S03-J'}
TIER2 = {'S06-A', 'S06-E', 'S06-F', 'S15-L', 'S15-N'}
subsets = {
    'A. As recorded (all 11 aged experiments)': AGED,
    'B. As recorded minus S06-D (exact duplicate of S06-C)': [e for e in AGED if e != 'S06-D'],
    'C. Excluding Tier-1 (survival record itself in conflict)': [e for e in AGED if e not in TIER1],
    'D. Excluding Tier-1 + Tier-2 (companion weight record copied/edited)': [e for e in AGED if e not in TIER1 | TIER2],
    'E. No integrity flag of any kind (S06-B only)': ['S06-B'],
}

def mh(tabs):
    w = np.array([a[1] * b[1] / (a[1] + b[1]) for a, b in tabs])
    d = np.array([a[0] / a[1] - b[0] / b[1] for a, b in tabs])
    return float((w * d).sum() / w.sum())

rows = []
for lab, ex in subsets.items():
    for g1, g2 in [('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212'), ('PSLN-212', 'Sham'), ('PSLN-344', 'PSLN-212(Y)')]:
        data = []
        for e in ex:
            d = ALL[ALL.experiment == e]
            a = d[d.group == g1].surv.values; b = d[d.group == g2].surv.values
            if len(a) and len(b):
                data.append((e, a, b))
        if not data:
            continue
        est = mh([((a.sum(), len(a)), (b.sum(), len(b))) for _, a, b in data])
        boots = []
        for _ in range(4000):
            tabs = []
            for _, a, b in data:
                ra = rng.choice(a, len(a)); rb = rng.choice(b, len(b))
                tabs.append(((ra.sum(), len(a)), (rb.sum(), len(b))))
            boots.append(mh(tabs))
        lo, hi = np.percentile(boots, [2.5, 97.5])
        D = ALL[ALL.experiment.isin([x[0] for x in data]) & ALL.group.isin([g1, g2])].dropna(subset=['day'])
        try:
            chi2, _ = survdiff(D.day.values, D.event.values, (D.group == g1).astype(int).values, strata=D.experiment.values)
            p = stats.chi2.sf(chi2, 1)
        except Exception:
            p = np.nan
        k1 = sum(a.sum() for _, a, _ in data); n1 = sum(len(a) for _, a, _ in data)
        k2 = sum(b.sum() for _, _, b in data); n2 = sum(len(b) for _, _, b in data)
        rows.append(dict(subset=lab, comparison=f'{g1} vs {g2}', k_exps=len(data), group1=f'{k1}/{n1} ({100*k1/n1:.0f}%)',
                         group2=f'{k2}/{n2} ({100*k2/n2:.0f}%)', MH_RD_pp=round(100 * est, 1),
                         boot95_lo=round(100 * lo, 1), boot95_hi=round(100 * hi, 1), strat_logrank_p=p,
                         experiments=', '.join(x[0] for x in data)))
R = pd.DataFrame(rows)
R['strat_logrank_p'] = R.strat_logrank_p.map(lambda x: f'{x:.1e}' if x >= 1e-300 else '<1e-300')
pd.set_option('display.width', 260, 'display.max_colwidth', 70, 'display.max_rows', 200)
print(R.drop(columns=['experiments']).to_string())
R.to_csv('/tmp/outputs/tables/survival_pooled_sensitivity.csv', index=False)

print('\n=== Background mortality: unvaccinated, unchallenged 20-month animals (Untreated) vs day-60 PSLN-344 arms')
U = ALL[ALL.group == 'Untreated']
for e, d in U.groupby('experiment'):
    print(f'  {e}: Untreated survivors {d.surv.sum()}/{len(d)}; death days {sorted(d[d.event==1].day.tolist())}')
ku, nu = U.surv.sum(), len(U)
lo, hi = proportion_confint(nu - ku, nu, method='wilson')
print(f'  pooled Untreated deaths {nu-ku}/{nu} = {100*(nu-ku)/nu:.1f}% (Wilson 95% CI {100*lo:.1f}-{100*hi:.1f}%) over a 14-day window')
P60 = ALL[(ALL.experiment.isin(['S06-E', 'S06-F', 'S06-G'])) & (ALL.group == 'PSLN-344')]
k6, n6 = P60.surv.sum(), len(P60)
odds, p = stats.fisher_exact([[k6, n6 - k6], [ku, nu - ku]])
print(f'  day-60 PSLN-344 survivors {k6}/{n6} ({100*k6/n6:.0f}%) vs Untreated {ku}/{nu} ({100*ku/nu:.0f}%): Fisher p = {p:.2f}')
S60 = ALL[(ALL.experiment.isin(['S06-E', 'S06-F', 'S06-G'])) & (ALL.group == 'Sham')]
print(f'  day-60 Sham survivors {S60.surv.sum()}/{len(S60)}')
Y60 = ALL[(ALL.experiment.isin(['S06-E', 'S06-F', 'S06-G'])) & (ALL.group == 'PSLN-212(Y)')]
print(f'  day-60 young PSLN-212 survivors {Y60.surv.sum()}/{len(Y60)}')
# day-14-type challenges (S06-A, S06-C, S15-L, S15-N, S03-I) vs d60 (S06-E/F/G) for PSLN-344
for lab, ex in [('d14 heterosubtypic/homologous (S03-I,S06-A,S06-C,S15-L,S15-N)', ['S03-I', 'S06-A', 'S06-C', 'S15-L', 'S15-N']),
                ('early d2-3 (S03-J,S06-B,S06-D)', ['S03-J', 'S06-B', 'S06-D']), ('d60 (S06-E,S06-F,S06-G)', ['S06-E', 'S06-F', 'S06-G'])]:
    d = ALL[ALL.experiment.isin(ex) & (ALL.group == 'PSLN-344')]
    print(f'  PSLN-344 {lab}: {d.surv.sum()}/{len(d)} ({100*d.surv.mean():.0f}%)')

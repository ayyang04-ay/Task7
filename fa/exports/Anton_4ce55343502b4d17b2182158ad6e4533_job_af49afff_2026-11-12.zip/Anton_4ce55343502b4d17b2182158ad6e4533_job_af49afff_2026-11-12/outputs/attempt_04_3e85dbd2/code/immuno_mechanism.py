"""Group summaries, stated tests, and restoration index for every value/timecourse block.

Reduction rules (applied uniformly; quoted in the report and in the evidence ledger):
  * Percent / fold readouts: arithmetic mean and SD of per-animal values; 95% CI = mean +/- t(0.975, n-1)*SD/sqrt(n).
  * Titres (ELISA endpoint, HAI, neutralisation): geometric mean titre GMT = 10^mean(log10 titre), 95% CI on log scale.
    HAI values recorded as 0 (below the 1:10 starting dilution) are set to 5 (half the lowest dilution) before logging.
  * qRT-PCR fold values: geometric mean (log10 scale), since fold-changes are ratio data.
  * Tests: one-way ANOVA across the groups in the block followed by Tukey HSD (the annotation's stated method),
    on log10 scale for titres/fold, linear for percent.  Pairwise Welch t-tests reported alongside.
  * Hedges' g for PSLN-344 vs PSLN-212 (the Mn effect in aged animals).
  * Restoration index (RI) = (PSLN-344 - PSLN-212) / (PSLN-212(Y) - PSLN-212) on the analysis scale:
      RI = 0 -> Mn adds nothing in aged animals; RI = 1 -> aged PSLN-344 equals young PSLN-212.
"""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import psln_blocks as P

LOG_UNITS = {'titre', 'fold'}

# blocks to summarise: (block, timepoint selector for timecourse or None)
SELECT = [
    ('S01-A 16h', None), ('S01-A 72h', None), ('S01-B', None), ('S01-C', None),
    ('S01-D', 4), ('S01-D', 2), ('S01-D', 8), ('S01-E', 4), ('S01-E', 8), ('S01-F', None), ('S01-G', None),
    ('S02-A', None), ('S02-B', None), ('S02-C', None), ('S02-D CD40', None), ('S02-D CD86', None), ('S02-E', None),
    ('S02-F', '16h'), ('S02-F', '36h'), ('S02-F', '72h'), ('S02-G', None), ('S02-H', None), ('S02-I', None),
    ('S03-A', None), ('S03-B', None), ('S03-C', None), ('S03-D', None), ('S03-E', None), ('S03-F', None), ('S03-G', None), ('S03-H', None),
    ('S03-K', None), ('S03-L Aicda', None), ('S03-L E47', None),
    ('S04-A ICOSlo', None), ('S04-A ICOShi', None), ('S04-B Foxp3', None), ('S04-B Tfh:Tfr', None), ('S04-C', None), ('S04-D', None),
    ('S05-A', 7), ('S05-B', 7), ('S05-C', None), ('S05-D', None), ('S05-E', None), ('S05-F', None), ('S05-G', None), ('S05-H', None), ('S05-I', None),
    ('S07-A', 5), ('S07-A', 10), ('S07-B mono', None), ('S07-B Ly6C+Mph', None),
    ('S08-A', 20), ('S08-A', 5), ('S08-A', 40), ('S08-B', None), ('S08-C', None),
    ('S10-A Ifnb1', None), ('S10-A Tnf', None), ('S10-A Isg15', None),
    ('S11-A', 4), ('S11-C', None), ('S11-D', 4), ('S11-E', None), ('S12-A', None),
    ('S13-A', None), ('S13-B', None), ('S13-C', None), ('S13-D', None), ('S13-H', None), ('S13-I', None), ('S13-J', None),
    ('S14-A H1N1', None), ('S14-A H3N2', None),
]


def scale_of(bid):
    b = P.REG[bid]
    if b.get('scale') == 'titre' or b.get('unit') == 'titre':
        return 'log'
    if b.get('unit') == 'fold':
        return 'log'
    return 'lin'


def get(bid, t):
    df = P.extract(bid)
    b = P.REG[bid]
    if b['kind'] == 'timecourse' and t is not None:
        df = df[df.time.astype(str) == str(t)]
    if b.get('lod'):
        df = df.assign(value=np.where(df.value < b['lod'], b['lod'] / 2, df.value))
    return df


def summarise(bid, t):
    df = get(bid, t)
    sc = scale_of(bid)
    rows = []
    for g, d in df.groupby('group', sort=False):
        v = d.value.values.astype(float)
        n = len(v)
        if sc == 'log':
            lv = np.log10(v)
            m, s = lv.mean(), lv.std(ddof=1) if n > 1 else np.nan
            h = stats.t.ppf(0.975, n - 1) * s / np.sqrt(n) if n > 1 else np.nan
            centre, lo, hi = 10 ** m, 10 ** (m - h), 10 ** (m + h)
            label = 'geometric mean'
        else:
            m, s = v.mean(), v.std(ddof=1) if n > 1 else np.nan
            h = stats.t.ppf(0.975, n - 1) * s / np.sqrt(n) if n > 1 else np.nan
            centre, lo, hi = m, m - h, m + h
            label = 'mean'
        rows.append(dict(block=bid, time=t, group=g, n=n, centre=centre, ci_lo=lo, ci_hi=hi,
                         sd_lin=(v.std(ddof=1) if n > 1 else np.nan), stat=label, scale=sc,
                         values=', '.join(f'{x:g}' for x in v), cells=f'{d.cell.iloc[0]}:{d.cell.iloc[-1]}',
                         sheet=P.REG[bid]['sheet'], measurand=P.REG[bid].get('measurand'), unit=P.REG[bid].get('unit'),
                         block_time=P.REG[bid].get('time', '')))
    return pd.DataFrame(rows), df


def tests(bid, t, df):
    sc = scale_of(bid)
    y = np.log10(df.value.values) if sc == 'log' else df.value.values
    g = df.group.values
    out = {}
    groups = list(dict.fromkeys(g))
    if len(groups) >= 3:
        F, p = stats.f_oneway(*[y[g == k] for k in groups])
        out['anova_p'] = p
        try:
            tk = pairwise_tukeyhsd(y, g)
            res = pd.DataFrame(tk._results_table.data[1:], columns=tk._results_table.data[0])
            out['tukey'] = res
        except Exception:
            out['tukey'] = None
    for a, b in [('PSLN-344', 'PSLN-212'), ('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212(Y)'), ('PSLN-212', 'Sham'),
                 ('PSLN-344', 'Vaccine'), ('PSLN-344', 'CMP-204'), ('PSLN-344(Y)', 'PSLN-212(Y)')]:
        if a in groups and b in groups:
            ya, yb = y[g == a], y[g == b]
            tt = stats.ttest_ind(ya, yb, equal_var=False)
            sp = np.sqrt(((len(ya) - 1) * ya.var(ddof=1) + (len(yb) - 1) * yb.var(ddof=1)) / (len(ya) + len(yb) - 2))
            d = (ya.mean() - yb.mean()) / sp if sp > 0 else np.nan
            J = 1 - 3 / (4 * (len(ya) + len(yb)) - 9)
            out[f'welch_p {a} vs {b}'] = tt.pvalue
            out[f'hedges_g {a} vs {b}'] = d * J
            if out.get('tukey') is not None:
                tk = out['tukey']
                r = tk[((tk.group1 == a) & (tk.group2 == b)) | ((tk.group1 == b) & (tk.group2 == a))]
                if len(r):
                    out[f'tukey_p {a} vs {b}'] = float(r['p-adj'].iloc[0])
    return out


if __name__ == '__main__':
    allsum = []
    comp = []
    for bid, t in SELECT:
        s, df = summarise(bid, t)
        allsum.append(s)
        te = tests(bid, t, df)
        sc = scale_of(bid)
        cen = dict(zip(s.group, s.centre))
        row = dict(block=bid, time=t, measurand=P.REG[bid].get('measurand'), scale=sc, anova_p=te.get('anova_p'))
        for k, v in te.items():
            if k not in ('tukey', 'anova_p'):
                row[k] = v
        # fold / % of young
        def ratio(a, b):
            return cen[a] / cen[b] if a in cen and b in cen and cen[b] not in (0,) else np.nan
        row['PSLN-344/PSLN-212'] = ratio('PSLN-344', 'PSLN-212')
        row['PSLN-344/Sham'] = ratio('PSLN-344', 'Sham')
        row['PSLN-344 as % of young PSLN-212'] = 100 * ratio('PSLN-344', 'PSLN-212(Y)')
        if all(k in cen for k in ('PSLN-344', 'PSLN-212', 'PSLN-212(Y)')):
            f = (np.log10 if sc == 'log' else (lambda x: x))
            den = f(cen['PSLN-212(Y)']) - f(cen['PSLN-212'])
            row['restoration_index'] = (f(cen['PSLN-344']) - f(cen['PSLN-212'])) / den if den != 0 else np.nan
        comp.append(row)
    S = pd.concat(allsum)
    C = pd.DataFrame(comp)
    S.to_csv('/tmp/outputs/tables/immuno_mechanism_group_summaries.csv', index=False)
    C.to_csv('/tmp/outputs/tables/immuno_mechanism_tests.csv', index=False)
    pd.set_option('display.width', 280, 'display.max_colwidth', 40, 'display.max_rows', 600)
    print(S[['block', 'time', 'group', 'n', 'stat', 'centre', 'ci_lo', 'ci_hi']].round(3).to_string())

"""Cross-check report <-> evidence ledger.
1) every bracketed ledger ID in the report exists;
2) for every line that cites IDs, each decimal number on the line should be found in the ledger text of the cited IDs
   (after normalisation).  Misses are printed for manual review (many are legitimate derived values, e.g. rounding)."""
import re, pandas as pd
L = pd.read_csv('/tmp/outputs/evidence_ledger.csv')
ids = set(L.id)
txt = {r.id: f"{r.claim} {r.value} {r.cells} {r.reduction} {r.integrity_flag}" for _, r in L.iterrows()}
rep = open('/tmp/outputs/PSLN-344_portfolio_review.md').read()
refs = re.findall(r'\[([EQMSP]\d+(?:[–-][EQMSP]?\d+)?(?:,\s*[EQMSP]\d+(?:[–-][EQMSP]?\d+)?)*)', rep)
def expand(tok):
    out = []
    for part in re.split(r',\s*', tok):
        m = re.match(r'([EQMSP])(\d+)[–-]([EQMSP])?(\d+)', part)
        if m:
            for k in range(int(m.group(2)), int(m.group(4)) + 1):
                out.append(f'{m.group(1)}{k}')
        else:
            out.append(part.strip())
    return out
cited = set()
for r in refs:
    for i in expand(r):
        cited.add(i)
missing = sorted(c for c in cited if c not in ids)
print('distinct IDs cited:', len(cited), ' missing from ledger:', missing)
# line-level number check
def norm_numbers(s):
    s = s.replace(',', '')
    return re.findall(r'(?<![A-Za-z\d])\d+\.\d+|(?<![A-Za-z\d.])\d{2,}(?![\d.])', s)
def variants(x):
    v = {x}
    try:
        f = float(x)
        v |= {f'{f:g}', f'{f:.1f}', f'{f:.2f}', f'{f:.3g}', f'{f:.2g}', f'{f:.3e}', f'{f:.2e}', f'{f:.1e}'}
        if f >= 1000: v |= {f'{f:.3g}'.replace('e+0', 'e+0'), f'{f:.2e}'.replace('e+0', 'e+0')}
        v |= {s.replace('e+0', 'e+') for s in list(v)}
    except: pass
    return v
issues = []
for ln, line in enumerate(rep.splitlines(), 1):
    r = re.findall(r'\[([EQMSP]\d+(?:[–-][EQMSP]?\d+)?(?:,\s*[EQMSP]\d+(?:[–-][EQMSP]?\d+)?)*)\]', line)
    cells = re.findall(r'\|\s*([EQMSP]\d+(?:[–-][EQMSP]?\d+)?(?:,\s*[EQMSP]\d+(?:[–-][EQMSP]?\d+)?)*)\s*\|?\s*$', line)
    toks = r + cells
    if not toks: continue
    cid = [i for t in toks for i in expand(t)]
    blob = ' '.join(txt.get(i, '') for i in cid).replace(',', '')
    nums = norm_numbers(re.sub(r'\[[^\]]*\]', '', line))
    miss = [n for n in nums if not any(v in blob for v in variants(n))]
    if miss:
        issues.append((ln, cid, miss, line.strip()[:160]))
print('lines with numbers not found verbatim in cited ledger rows:', len(issues))
for i in issues: print(i)

print('\n--- table rows keyed by an ID in the first column ---')
for ln, line in enumerate(rep.splitlines(), 1):
    m = re.match(r'\|\s*([QEMSP]\d+)(?:[–-]([QEMSP]?\d+))?\s*\|', line)
    if not m: continue
    cid = expand(m.group(0).strip('| ').strip())
    blob = ' '.join(txt.get(i, '') for i in cid).replace(',', '')
    nums = norm_numbers(re.sub(r'`[^`]*`', '', line))
    miss = [n for n in nums if not any(v in blob for v in variants(n))]
    print(ln, cid, 'not verbatim:', miss)

"""Evidence ledger: every number cited in the report, with its source cells and reduction.

IDs:  E = efficacy (survival), Q = data-integrity findings, M = immunogenicity/mechanism,
      S = safety/reactogenicity, P = planning calculations.
Each row: id, claim, value, source_block, cells (sheet!range), n, reduction, integrity_flag.
"""
import numpy as np, pandas as pd
import psln_blocks as P
from statsmodels.stats.proportion import proportion_confint

T = '/tmp/outputs/tables/'
L = []


def add(id_, claim, value, block, cells, n, reduction, flag=''):
    L.append(dict(id=id_, claim=claim, value=value, source_block=block, cells=cells, n=n, reduction=reduction, integrity_flag=flag))


def fmt_p(p):
    if pd.isna(p):
        return 'n/a'
    if isinstance(p, str):
        return p
    if p == 0 or p < 1e-12:
        return '<1e-12'
    if p < 0.001:
        return f'{p:.1e}'
    return f'{p:.3f}' if p < 0.1 else f'{p:.2f}'


# ============ E: efficacy =====================================================================
S = pd.read_csv(T + 'survival_by_group.csv')
C = pd.read_csv(T + 'survival_comparisons.csv')
PO = pd.read_csv(T + 'survival_pooled_sensitivity.csv')
ALL = pd.read_csv(T + 'survival_all_animals.csv')

def surv_cells(exp, group):
    b = P.REG[exp]; d = ALL[(ALL.experiment == exp) & (ALL.group == group)]
    return f"{b['sheet']}!{d.cell.iloc[0]}:{d.cell.iloc[-1]} (indicator); {b['sheet']}!{d.day_cell.iloc[0]}:{d.day_cell.iloc[-1]} (days)"

eid = 1
order = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N',
         'S06-E(imprint)', 'S06-F(imprint)', 'S15-H', 'S09-B', 'S09-D', 'S09-F', 'S13-E']
E_ID = {}
for exp in order:
    d = S[S.experiment == exp]
    parts = []
    for _, r in d.iterrows():
        parts.append(f"{r.group} {r.survivors}/{r.n}")
    comp = C[C.experiment == exp]
    ptxt = '; '.join(f"{r.test}: Fisher p={fmt_p(r.fisher_p)}, log-rank p={fmt_p(r.logrank_p)}" for _, r in comp.iterrows())
    meta = P.REG[exp]
    add(f'E{eid}', f"{exp} survival, {meta.get('strain')}; vaccine {meta.get('vaccine')}; challenge {meta.get('challenge')}",
        ' | '.join(parts) + (f' || {ptxt}' if ptxt else ''), exp,
        '; '.join(surv_cells(exp, g) for g in d.group), int(d.n.sum()),
        'Survivors = animals with event indicator 0 at end of follow-up; two-sided Fisher exact on survivors/deaths; log-rank (statsmodels survdiff) on days-to-event.',
        d.integrity.iloc[0] if 'integrity' in d and isinstance(d.integrity.iloc[0], str) else '')
    E_ID[exp] = f'E{eid}'; eid += 1

for _, r in PO.iterrows():
    add(f'E{eid}', f"Pooled aged survival, {r.subset}: {r.comparison}",
        f"{r.group1} vs {r.group2}; MH risk difference {r.MH_RD_pp:.1f} pp (stratified bootstrap 95% CI {r.boot95_lo:.1f} to {r.boot95_hi:.1f}); stratified log-rank p={r.strat_logrank_p}",
        'see experiments', r.experiments, r.k_exps,
        'Mantel-Haenszel risk difference over experiments (weights n1n2/(n1+n2)); CI = percentile of 4000 stratified bootstrap replicates; log-rank stratified by experiment.',
        'Subset defined by integrity tier (report section 3)')
    E_ID[f'POOL|{r.subset[:1]}|{r.comparison}'] = f'E{eid}'; eid += 1

# background mortality
U = ALL[ALL.group == 'Untreated']; ku = int((U.event == 0).sum()); nu = len(U)
lo, hi = proportion_confint(nu - ku, nu, method='wilson')
add(f'E{eid}', 'Background 14-day mortality in unvaccinated, unchallenged 20-month animals (Untreated arms of S06-E, S06-F, S06-G)',
    f"{nu-ku}/{nu} died ({100*(nu-ku)/nu:.0f}%; Wilson 95% CI {100*lo:.0f}-{100*hi:.0f}%): S06-E 1/7 (day 4), S06-F 0/7, S06-G 3/7 (days 3, 7, 10)",
    'S06-E, S06-F, S06-G', 'S06!L34:L68 with G34:G68; S06!R34:R68 with M34:M68; S06!F71:F105 with A71:A105', nu,
    'Deaths = event indicator 1; Wilson score interval.', 'S06-E/S06-G carry T3 flags')
E_ID['BG'] = f'E{eid}'; eid += 1
P60 = ALL[ALL.experiment.isin(['S06-E', 'S06-F', 'S06-G']) & (ALL.group == 'PSLN-344')]
from scipy import stats
k6 = int((P60.event == 0).sum()); n6 = len(P60)
pf = stats.fisher_exact([[k6, n6 - k6], [ku, nu - ku]])[1]
add(f'E{eid}', 'Day-60 challenge: PSLN-344 survival vs unchallenged aged background',
    f"PSLN-344 {k6}/{n6} ({100*k6/n6:.0f}%) vs Untreated (no challenge) {ku}/{nu} ({100*ku/nu:.0f}%); Fisher p={pf:.2f}; Sham 0/21; young PSLN-212 21/21",
    'S06-E, S06-F, S06-G', 'S06!J34:J68, P34:P68, D71:D105 (PSLN-344); untreated as above', n6 + nu, 'Two-sided Fisher exact.', 'T2/T3 flags on these experiments')
E_ID['D60'] = f'E{eid}'; eid += 1
for lab, ex in [('day-14 challenge (S03-I, S06-A, S06-C, S15-L, S15-N)', ['S03-I', 'S06-A', 'S06-C', 'S15-L', 'S15-N']),
                ('day-2/3 challenge (S03-J, S06-B, S06-D)', ['S03-J', 'S06-B', 'S06-D']),
                ('day-60 challenge (S06-E, S06-F, S06-G)', ['S06-E', 'S06-F', 'S06-G'])]:
    row = []
    for g in ['PSLN-344', 'PSLN-212', 'Sham', 'PSLN-212(Y)']:
        d = ALL[ALL.experiment.isin(ex) & (ALL.group == g)]
        if len(d):
            row.append(f"{g} {int((d.event==0).sum())}/{len(d)} ({100*(d.event==0).mean():.0f}%)")
    add(f'E{eid}', f'Aged survival by challenge timing, as recorded: {lab}', '; '.join(row), ', '.join(ex), 'per-experiment indicator/day columns (see E1-E11)', None,
        'Survivors summed across experiments (simple pooling, as recorded).', 'includes flagged experiments')
    E_ID[f'TIMING|{lab[:6]}'] = f'E{eid}'; eid += 1

# ============ Q: integrity =====================================================================
q = []
def addq(claim, value, block, cells, reduction, impact):
    q.append((claim, value, block, cells, reduction, impact))

addq('S06-D (challenge day 3) is identical to S06-C (challenge day 14) animal-for-animal',
     'Sham death days 4,4,5,6,6,6,7 in both; PSLN-212 5,8,10,10,12,14+,14+ in both; PSLN-344 and PSLN-212(Y) 7/7 alive in both (28/28 records identical)',
     'S06-C vs S06-D', 'S06!M3:Q30 vs S06!A34:E61', 'qa_survival_dups.py: identical (day, event) multisets per group',
     'One of the two experiments is not an independent record; the early (day-3) H5N1 protection claim cannot rest on S06-D.')
addq('S15-I (weights for the S15-H adjuvant-alone / vaccine-alone / combination experiment, challenge day 3) combination arm is a copy of S15-C PSLN-344 weights (challenge day 14)',
     'Days 2-12: 40 of 42 per-animal values identical (the other two differ by 0.3 and 0.1: 100.6 vs 100.3 at day 2, 94.6 vs 94.5 at day 10). The day-14 row differs in all 7 animals; animal 3 is carried forward at 77.9 (i.e. a death, matching the single S15-H death) in S15-I but recovers to 90.1 in S15-C. S15-C day 14 in turn shares 5/7 values with S15-M PSLN-344 day 14',
     'S15-C vs S15-I', 'S15!W23:AC30 vs S15!W72:AC79', 'qa_duplicates.py / qa_duplicates_strong.py (same-position identity)',
     'The only experiment testing adjuvant-alone vs vaccine-alone (S15-H) has a non-original weight record.')
addq('S15-F young (PSLN-212(Y)) weights carry the decimal tails of S08-D CMP-204 post-vaccination weights, in the same animal/day order, with different integer parts',
     'e.g. S08!I22:I26 = 97.98907, 95.16393, 95.69945, 100.69945, 99.71038 vs S15!D54:D58 = 98.98907, 92.16393, 87.69945, 85.69945, 89.71038; same pattern for columns G,J,K vs B,E,C (19 cells)',
     'S08-D vs S15-F', 'S08!G22:K26 vs S15!B54:E58', 'qa_fraction_fingerprint.py; qa_tail_lattice.py / qa_tail_lattice_summary.py: at 0.1 g balance resolution 18/19 S08-D values cannot be produced as 100*w/w0 for any baseline 15-45 g and 18/19 pairs cannot share a baseline; the two records are different animals (aged CMP-204 after vaccination vs young PSLN-212 after challenge), so a shared baseline is impossible in any case',
     'Values consistent with copying then editing the integer part; the S15-F weight record (day-60 H5N1 challenge) is not an original measurement.')
addq('S15-M (aged C57BL/6) weights reuse values from S15-A (aged BALB/c) and S09-E (young BALB/c)',
     'S15-M PSLN-212 day 4 = S15-A Sham day 4 (7/7 identical incl. 89.42307692, 90.10989011); S15-M PSLN-212(Y) days 6-12 = S09-E PSLN-344(Y) animals 2-8 (6-7 of 7 values/day identical, incl. 94.512195, 96.358543, 99.085366, 98.039216), and at days 2-4 the same decimal tails reappear with altered leading digits (92.987805 vs 98.987805; 94.957983 vs 96.957983; 98.718768 vs 98.918768); S15-M PSLN-344 shares 3 same-position values/day with S15-A PSLN-344 at days 4-14 (e.g. 92.42424, 92.81709, 89.09091, 82.9972, 93.63636, 90.79832)',
     'S15-M vs S15-A, S09-E', 'S15!I103:AJ110 vs S15!B3:AC10 and S09!G39:AD46', 'qa_duplicates_strong.py',
     'The cross-strain (C57BL/6) experiment S15-L has a weight record assembled from other experiments.')
tails = pd.read_csv(T + 'qa_fraction_fingerprints.csv')
n_tails = len(tails); n_diffint = int((tails.n_int > 1).sum())
allcells = sum(tails.n)
addq('Workbook-wide fractional-tail fingerprint',
     f'{n_tails} distinct >=5-digit decimal tails occur in more than one cell ({allcells} cells), {n_diffint} of them with different integer parts; concentrated in S08-D, S09-C/E and S15 weight blocks',
     'S08, S09, S15', 'qa_fraction_fingerprints.csv lists every cell', 'qa_fraction_fingerprint.py',
     'Pattern is systematic, not a single paste error.')
addq('S09-C day-12 weights identical for PSLN-212(Y) and PSLN-344(Y); S09-C shares day-2 values with S09-E', '8/8 values identical at day 12 (97.7, 95.2, 93.3, 93.5, 99.1, 96.9, 100.3, 99.8); S09-C PSLN-344(Y) day 2 shares 4 same-position values with S09-E PSLN-344(Y) day 2 (97.9, 98.2, 99.5, 100.2), a different experiment', 'S09-C, S09-E',
     'S09!G18:N18 vs S09!W18:AD18; S09!W13:AD13 vs S09!W40:AD40', 'qa_duplicates_strong.py', 'Row copied between groups; values shared across experiments.')
addq('S03-I survival vs its weight record S13-F disagree on group identity and outcome',
     'S03-I has CMP-204 and no Naive arm; S13-F has Naive and no CMP-204. S03-I PSLN-212: 7/7 dead by day 6; S13-F PSLN-212: all 7 weighed through day 14, 3 recovering (95.0-99.0% at day 14; the other 4 frozen at 78.5-80.1% from day 10)',
     'S03-I vs S13-F', 'S03!A17:F51 vs S13!A33:AJ40', 'qa_surv_vs_weight.py', 'Homologous-challenge comparator arms (PSLN-212, CMP-204) unreliable; PSLN-344 7/7 and Sham 0/7 agree in both.')
addq('S03-J survival vs weight record S13-G disagree; n and a missing value',
     'S03-J groups Sham/PSLN-212/PSLN-344 vs S13-G PSLN-344/Sham/Naive; S03-J Sham 9/10 deaths vs 5 by weights; stated n=9 vs 10 observed; PSLN-344 animal in row 46 has event 0 but no day value; follow-up 22 days but weights only to day 14',
     'S03-J vs S13-G', 'S03!G17:J46 (G46 empty) vs S13!A43:AE50', 'qa_surv_vs_weight.py; qa_derived.py',
     'Wild-type H5N1 day-2 result cannot be reconciled with its own weight record.')
SVW = pd.read_csv(T + 'qa_survival_vs_weight.csv')
mm = SVW[SVW.verdict == 'MISMATCH']
addq('Survival vs weight death-count mismatches (after allowing for last-observation-carried-forward)',
     f"{len(mm)} group-level mismatches and 4 group-identity mismatches across 17 survival/weight pairs; PSLN-344 arms: S06-D 0 vs 2, S06-E 2 vs 1, S06-G 3 vs 2 (survival vs weight-inferred deaths)",
     'S06/S15, S09, S03/S13 pairs', 'qa_survival_vs_weight.csv', 'qa_surv_vs_weight.py (death inferred when an animal disappears or its value is frozen to day 14)',
     'Death counts in the primary endpoint are not internally consistent.')
addq('IgG2a/IgG1 quotients in S03-B/S03-F carry rotated group labels relative to the raw subclass titres in S13-A to S13-D',
     'S03-B column printed "PSLN-344" = S13 PSLN-212 quotients (max |diff| 3e-7); printed "PSLN-212(Y)" = S13 PSLN-344; printed "PSLN-212" = S13 PSLN-212(Y); same rotation in S03-F',
     'S03-B, S03-F vs S13-A..D', 'S03!G3:I7, S03!G10:I14 vs S13!A3:O7', 'qa_derived.py',
     'Read as printed, S03-B says Mn skews to IgG1 (Th2); the raw titres say the opposite (Th1 shift).')
addq('S09-A "16 h" right-hand block contains 72 h data; both S09-A blocks are subsets of S01-A',
     'Ifnb1: left block reproduces S01-A 16 h (21/21 values), right block reproduces S01-A 72 h (21/21) and 1/21 of 16 h',
     'S09-A vs S01-A', 'S09!A1:V9 and X1:AS9 vs S01!A3:L10', 'qa_derived.py', 'Mislabelled timepoint; S09-A Ifnb1 is not independent confirmation of S01-A.')
addq('S11-B (neutrophils) duplicates S11-A (alveolar macrophages)', '35/100 per-animal values identical at the same group/day/position (animals 1-2 of every group/day); young "neutrophils" 30-53% throughout',
     'S11-A vs S11-B', 'S11!B3:U7 vs S11!B10:U14', 'qa_derived.py', 'S11-B excluded.')
addq('S01-B vs S08-C overlap/irreproducibility', 'AECII PSLN-SRB shares 3/5 values (17.7, 17.5, 12.2); AECI PSLN-SRB 3.8% (S01-B) vs 13.8% (S08-C) for the same formulation, cell type, age and timepoint (gating differs)',
     'S01-B vs S08-C', 'S01!B14:F15 vs S08!A14:C18', 'qa_derived.py', 'Epithelial uptake numbers not reproducible between experiments.')
addq('Tfh:Tfr ratio is arithmetically (100 - Foxp3%)/Foxp3%', '20/20 values reproduced to <5e-6', 'S04-B', 'S04!A8:D12 and S04!A15:D19', 'qa_derived.py', 'Not an independent readout of Tfh; counted once.')
addq('S07-C both groups carry the same label', 'Header B15 and C15 both "Ly6C-CD206+ MΦ"; annotation says one should be Ly6C+CD206-', 'S07-C', 'S07!B15:C20', 'inspection', 'Uninterpretable; excluded.')
addq('Unlabelled block S08 rows 89-101', '13 rows: column A = 14, columns C/D = 0 (6 + 7 values); no label, group, measurand', 'S08 rows 89-101', 'S08!A89:D101', 'inspection', 'Looks like orphan survival data (all alive at 14 d); excluded.')
addq('Stated n vs observed n conflicts', 'S03-J stated 9, observed 10/group; S13-E stated 5, observed 7; S05-A/B stated 3, observed 2 per timepoint; annotation says S09-B Sham has 7 (workbook 8) and S09-F all 8 (workbook Sham 7)',
     'S03-J, S13-E, S05-A/B, S09-B, S09-F', 'S03!G15, S13!R1, S05!A1/A6, S09!A12:B19, S09!A66:B72', 'psln_blocks.py counts', 'Bookkeeping; affects denominators.')
addq('Assay-validity questions', 'S05-A/B use an H-2Db-restricted NP366-374 tetramer but the default strain (BALB/c) is H-2d, and the block text says both ovalbumin and bivalent vaccine; S02-E co-cultures OT-I (H-2Kb-restricted) T cells with DCs from donors whose strain is not stated (default BALB/c)',
     'S05-A, S05-B, S02-E', 'S05!A1:I10; S02!K9:O14', 'annotation cross-check', 'Cannot be interpreted until donor/recipient strains are confirmed.')
addq('Missing or conflicting metadata', 'No challenge virus/dose/day for S15-L and S15-N; no timepoint for S07-B, S11-E, S13-H, S14-A; S10-A annotated as "mean with SD" but holds 5 per-animal values; "PSLN-344/R848" (S08-A) is not a defined material; S08-B reports CDN-1807 encapsulation for PSLN-R848, which contains no CDN-1807',
     'S15-L/N, S07-B, S11-E, S13-H, S14-A, S10-A, S08-A, S08-B', 'annotation pp. 10-19', 'annotation cross-check', 'Limits interpretation; must be resolved in audit.')
for i, (claim, value, block, cells, red, impact) in enumerate(q, 1):
    add(f'Q{i}', claim, value, block, cells, None, red, impact)

# ============ M: immunogenicity / mechanism ======================================================
G = pd.read_csv(T + 'immuno_mechanism_group_summaries.csv')
Tt = pd.read_csv(T + 'immuno_mechanism_tests.csv')
mid = 1
M_ID = {}
KEY = [
    ('S01-A 16h', None, 'Lung Ifnb1 16 h (fold)'), ('S01-A 72h', None, 'Lung Ifnb1 72 h (fold)'), ('S02-F', '36h', 'Lung Gm-csf 36 h (fold)'), ('S02-F', '16h', 'Lung Gm-csf 16 h (fold)'),
    ('S01-D', '4', 'Lung monocytes day 4 (%)'), ('S01-E', '4', 'Lung CD11b+ DC day 4 (%)'), ('S01-F', None, 'Lung cDC1 72 h (%)'),
    ('S02-A', None, 'Lung migratory CCR7+ DC 72 h (%)'), ('S02-B', None, 'MLN CD11b+CD103- DC 72 h (%)'), ('S02-C', None, 'MLN antigen+ DC 36 h (%)'),
    ('S02-D CD40', None, 'MLN DC CD40+ day 3 (%)'), ('S02-D CD86', None, 'MLN DC CD86+ day 3 (%)'), ('S02-E', None, 'OT-I proliferation with MLN DC (%)'),
    ('S05-D', None, 'Lung Ki-67+ CD8 day 3 (%)'), ('S05-E', None, 'Lung GZMB+ CD8 day 3 (%)'), ('S05-F', None, 'MLN IFN-g+ CD8, rgH5N1 restim, day 14 (%)'),
    ('S05-G', None, 'MLN IFN-g+ CD8, rgH5N1 restim, day 60 (%)'), ('S05-H', None, 'MLN GZMB+ CD8 day 60 (%)'), ('S05-I', None, 'Lung TRM CD69+CD103+ CD8 day 25 (%)'),
    ('S14-A H1N1', None, 'MLN IFN-g+ CD8, CA09 restim (%)'), ('S14-A H3N2', None, 'MLN IFN-g+ CD8, Aichi restim (%)'),
    ('S04-A ICOShi', None, 'MLN ICOS-hi Tfh day 7 (%)'), ('S04-B Foxp3', None, 'MLN Tfr (Foxp3+ of CXCR5+ICOShi) day 7 (%)'), ('S04-C', None, 'MLN Tfr day 30 (%)'), ('S04-D', None, 'Lung Treg day 7 (%)'),
    ('S03-K', None, 'MLN GC B cells day 7 (%)'), ('S03-L Aicda', None, 'MLN B-cell Aicda day 5 (fold)'), ('S13-H', None, 'MLN IgG+ B220+ (%)'),
    ('S03-A', None, 'Serum IgG anti-CA09 day 14 (GMT)'), ('S03-C', None, 'HAI anti-CA09 day 14 (GMT)'), ('S03-D', None, 'Neutralising anti-CA09 day 14 (GMT)'),
    ('S03-E', None, 'Serum IgG anti-Aichi day 14 (GMT)'), ('S03-G', None, 'HAI anti-Aichi day 14 (GMT)'), ('S03-H', None, 'Neutralising anti-Aichi day 14 (GMT)'),
    ('S13-I', None, 'Serum IgG anti-CA09 day 28 post-boost (GMT)'), ('S13-J', None, 'Serum IgG anti-Aichi day 28 post-boost (GMT)'),
    ('S11-E', None, 'Lung CD206+ macrophages (%) [timepoint not stated]'), ('S07-A', '5', 'Lung Ly6C+CCR2+ macrophages day 5 (x1e5)'), ('S11-A', '4', 'Lung alveolar macrophages day 4 (%)'), ('S11-D', '4', 'Lung NK cells day 4 (%)'),
    ('S08-A', '20', 'Lung Ifnb1 16 h at 20 ug (fold) [age not stated]'), ('S08-A', '10', 'Lung Ifnb1 16 h at 10 ug (fold)'), ('S08-A', '40', 'Lung Ifnb1 16 h at 40 ug (fold)'),
    ('S08-B', None, 'Encapsulation efficiency (%)'), ('S01-G', None, 'Lung cDC2 72 h (%)'),
]
for blk, t, lab in KEY:
    g = G[(G.block == blk) & ((G.time.astype(str) == str(t)) if t is not None else G.time.isna())]
    if not len(g):
        # S08-A 10 ug not in SELECT -> compute directly
        d = P.extract(blk); d = d[d.time.astype(str) == str(t)]
        parts = []
        for gg, dd in d.groupby('group', sort=False):
            parts.append(f"{gg} {10**np.log10(dd.value).mean():.1f}")
        add(f'M{mid}', lab, '; '.join(parts), blk, f"{P.REG[blk]['sheet']}!{d.cell.iloc[0]}:{d.cell.iloc[-1]}", len(d), 'geometric mean of per-animal fold values')
        M_ID[(blk, str(t))] = f'M{mid}'; mid += 1
        continue
    parts = []
    for _, r in g.iterrows():
        if r.scale == 'log':
            parts.append(f"{r.group} {r.centre:.3g} ({r.ci_lo:.3g}-{r.ci_hi:.3g})")
        else:
            parts.append(f"{r.group} {r.centre:.3g} ({r.ci_lo:.3g}-{r.ci_hi:.3g})")
    tt = Tt[(Tt.block == blk) & ((Tt.time.astype(str) == str(t)) if t is not None else Tt.time.isna())]
    extra = ''
    if len(tt):
        r = tt.iloc[0]
        bits = []
        if 'tukey_p PSLN-344 vs PSLN-212' in r and not pd.isna(r['tukey_p PSLN-344 vs PSLN-212']):
            tp = r['tukey_p PSLN-344 vs PSLN-212']
            bits.append(f"Tukey PSLN-344 vs PSLN-212 p={'<0.0001' if tp == 0 else fmt_p(tp)}")
        if 'tukey_p PSLN-344 vs PSLN-212(Y)' in r and not pd.isna(r['tukey_p PSLN-344 vs PSLN-212(Y)']):
            tp = r['tukey_p PSLN-344 vs PSLN-212(Y)']
            bits.append(f"vs young PSLN-212 p={'<0.0001' if tp == 0 else fmt_p(tp)}")
        if not pd.isna(r.get('hedges_g PSLN-344 vs PSLN-212', np.nan)):
            bits.append(f"Hedges g(344 vs 212)={r['hedges_g PSLN-344 vs PSLN-212']:.1f}")
        if not pd.isna(r.get('PSLN-344/PSLN-212', np.nan)):
            bits.append(f"PSLN-344/PSLN-212={r['PSLN-344/PSLN-212']:.2f}x")
        if not pd.isna(r.get('PSLN-344 as % of young PSLN-212', np.nan)):
            bits.append(f"PSLN-344 = {r['PSLN-344 as % of young PSLN-212']:.0f}% of young PSLN-212")
        if not pd.isna(r.get('restoration_index', np.nan)):
            bits.append(f"restoration index={r['restoration_index']:.2f}")
        if not pd.isna(r.get('anova_p', np.nan)):
            bits.append(f"ANOVA p={fmt_p(r['anova_p'])}")
        extra = ' || ' + '; '.join(bits)
    first = g.iloc[0]
    red = ('geometric mean (95% CI) of per-animal values on log10 scale' if first.scale == 'log' else 'arithmetic mean (95% t-CI) of per-animal values') + \
          ('; HAI 0 (<1:10) set to 5' if blk in ('S03-C', 'S03-G') else '') + '; one-way ANOVA + Tukey HSD (stated method), log10 scale for titres/fold; RI=(344-212)/(212Y-212)'
    cells = '; '.join(f"{first.sheet}!{c}" for c in g.cells)
    add(f'M{mid}', lab, '; '.join(parts) + extra, blk, cells, int(g.n.sum()), red)
    M_ID[(blk, str(t))] = f'M{mid}'; mid += 1

# corrected IgG2a/IgG1
RR = pd.read_csv(T + 'igg2a_igg1_corrected.csv')
for ag in RR.antigen.unique():
    d = RR[RR.antigen == ag]
    add(f'M{mid}', f'IgG2a/IgG1 quotient recomputed from raw subclass titres, {ag} day 14',
        '; '.join(f"{r.group} {r.geo_mean_ratio:.2f}" for _, r in d.iterrows()) + ' (geometric mean); Tukey PSLN-344 vs PSLN-212 p=' + ('0.016' if 'CA09' in ag else '0.0008') + '; PSLN-344 vs young p=' + ('0.70' if 'CA09' in ag else '0.82'),
        d.source.iloc[0], 'S13!A3:G7' if 'CA09' in ag else 'S13!I3:O7', 15, 'per-animal IgG2a/IgG1, geometric mean; Tukey on log10', 'Uses S13 labels; S03-B/F labels rotated (Q10)')
    M_ID[('IgG2a', ag)] = f'M{mid}'; mid += 1

MC = pd.read_csv(T + 'mechanism_contrasts.csv')
for _, r in MC.iterrows():
    blk = r.contrast.split()[0]
    add(f'M{mid}', r.contrast, f"{r.a} {r.mean_a:.3g} vs {r.b} {r.mean_b:.3g} (ratio {r.ratio:.2f}; {r['pct_change']:+.0f}%); Welch p={r.welch_p}", blk,
        f"{P.REG[blk]['sheet'] if blk in P.REG else blk} (see block)", int(r.n_a + r.n_b),
        'arithmetic means (geometric for S08-A/S01-A fold data); Welch t-test (log10 scale for fold data)')
    M_ID[('C', r.contrast[:40])] = f'M{mid}'; mid += 1

# ============ S: safety ===========================================================================
Gs = pd.read_csv(T + 'safety_S08D_weight_nadir.csv')
sid = 1
add(f'S{sid}', 'Post-vaccination weight nadir days 2-10 (no challenge), S08-D',
    '; '.join(f"{r.group} {r.mean_nadir:.1f}% (min {r.min_nadir:.1f}; Welch vs Vaccine p={fmt_p(r.welch_p_vs_vaccine)})" for _, r in Gs.iterrows()) + '; PSLN-212/R848 has 4/5 animals at day 10 (W26 empty)',
    'S08-D', 'S08!B21:AE26', 30, 'per-animal minimum of % day-0 weight over days 2-10; group mean', 'S08-D CMP-204 tails reused in S15-F (Q3)'); sid += 1
TT = pd.read_csv(T + 'safety_S09A_contrasts.csv')
for tp in TT.timepoint.unique():
    d = TT[TT.timepoint == tp]
    add(f'S{sid}', f'Lung cytokine transcripts, aged PSLN-344 vs young PSLN-212 benchmark, {tp}',
        '; '.join(f"{r.analyte} x{r.fold_344_over_young212:.2f} (p={fmt_p(r.p_vs_young)})" for _, r in d.iterrows()),
        'S09-A', 'S09!Q3:V9 (16 h); S09!AN3:AS9 (72 h)', 6, 'ratio of geometric means (10^mean log10) aged PSLN-344 / young PSLN-212(y); Welch t on log10; n=3 per group', 'right block relabelled 72 h (Q11)'); sid += 1
    add(f'S{sid}', f'Lung cytokine transcripts, PSLN-212/R848 vs PSLN-344 (aged), {tp}',
        '; '.join(f"{r.analyte} x{r.fold_R848combo_over_344:.2f} (p={fmt_p(r.p_R848_vs_344)})" for _, r in d.iterrows()),
        'S09-A', 'S09!N3:S9 (16 h); S09!AK3:AP9 (72 h)', 6, 'ratio of geometric means; Welch t on log10; n=3', ''); sid += 1
CNS = pd.read_csv(T + 'safety_S10A_cns.csv')
add(f'S{sid}', 'CNS transcripts 36 h after intranasal vaccination (aged), S10-A',
    '; '.join(f"{r.analyte} {r.contrast}: {r.geo_fold_a:.2f} vs {r.geo_fold_b:.2f} (Tukey p={'<0.0001' if r.tukey_p == 0 else fmt_p(r.tukey_p)})" for _, r in CNS.iterrows()),
    'S10-A', 'S10!A3:N7', 60, 'geometric mean fold; one-way ANOVA + Tukey on log10 per analyte', 'annotation says mean with SD but 5 per-animal values present (Q19)'); sid += 1
add(f'S{sid}', 'Ifnb1 persistence (72 h as % of 16 h), S01-A',
    'aged PSLN-344 11.3%; young PSLN-212 3.9%; young PSLN-344 6.0%; aged PSLN-212 20.7%; 72 h level aged PSLN-344 4.17x vs young PSLN-212 1.46x (Welch p=0.0067)',
    'S01-A', 'S01!B3:L10', 80, 'ratio of geometric means 72 h/16 h', ''); sid += 1

# ============ P: planning ===========================================================================
pl = [
    ('Sample size, confirmatory aged-mouse study: PSLN-344 vs Sham (76% vs 2%)', '8/arm for 80% power; 9/arm for 90% (two-sided Fisher, alpha 0.05)'),
    ('Sample size: PSLN-344 vs PSLN-212 (76% vs 8%)', '9/arm (80%); 12/arm (90%); 12/arm with 3 co-primary comparisons (alpha 0.0167)'),
    ('Sample size: PSLN-344 vs licensed-type adjuvant (76% vs 40%, planning assumption)', '32/arm (80%); 42/arm (90% or 80% with alpha 0.0167)'),
    ('Sample size: PSLN-344 vs licensed-type adjuvant (76% vs 50%, planning assumption)', '61/arm (80%); 77/arm (90%)'),
    ('Sample size: lung viral titre endpoint (SD 0.8 log10, planning assumption)', '15/arm to detect 1.0 log10, 29/arm for 0.7 log10, 55/arm for 0.5 log10 (90% power, t-test)'),
]
for i, (c, v) in enumerate(pl, 1):
    add(f'P{i}', c, v, 'derived', 'power_calcs.py', None, 'Fisher power by 20k-replicate simulation; t-test power (statsmodels) for continuous', 'rates from E-ledger (Tier-1-excluded pooled) unless labelled planning assumption')


# ---- extra Q / M entries ----
nq = len([x for x in L if x['id'].startswith('Q')]) + 1
add(f'Q{nq}', 'Weak coincidences noted but NOT counted as integrity flags',
    'Identical survival records that can plausibly arise by chance with 7 animals and integer days: S06-B Sham = S06-F Sham (4,4,4,5,5,6,6); S06-B PSLN-344 = S06-E PSLN-344 (8,10, five survivors); "one death on day 8, six survivors" recurs in five PSLN-344 arms (S06-A, S06-E/F imprint, S15-L, S15-N)',
    'S06, S15', 'qa_survival_identical_records.csv', None, 'qa_survival_dups.py', 'Reported for completeness; not used to tier experiments.')
nq += 1
add(f'Q{nq}', 'Within-animal tail edit inside S08-D', 'S08!I24 = 95.69945 and S08!I25 = 100.69945 (same animal, days 6 and 8): identical 5-digit tail, integer part +5; neither value is reachable as 100*w/w0 at 0.1 g or 0.01 g balance resolution',
    'S08-D', 'S08!I24:I25', None, 'qa_tail_lattice.py', 'S08-D (reactogenicity) itself is not a clean source record.')
nq += 1
add(f'Q{nq}', 'Unchallenged aged controls died without weight loss', 'S15-G Untreated animals carried forward from day 4, 8 and 10 at 96.6, 95.0 and 95.7% of day-0 weight (S15!AD65:AF70); consistent with sudden deaths of frail 20-month animals rather than infection',
    'S15-G', 'S15!AD63:AJ70', 7, 'inspection of last-observation-carried-forward values', 'Context for background mortality (E39).')
nq2 = len([x for x in L if x['id'].startswith('Q')]) + 1
add(f'Q{nq2}', 'S09-A cytokine panel contains identical 6-decimal log10 values in unrelated cells',
    '5 pairs of identical values across different analytes/groups (expected by chance ~0.02): O8 Tnf = O9 Il10 (PSLN-212/R848, 2.302879); AP3 Ifnb1 = AP9 Il10 (PSLN-344, 0.361235); B8 Tnf PBS = I6 Ccl3 PSLN-212 (0.105360); K4 Il6 PSLN-R848 = T9 Il10 PSLN-212(y) (0.237814); AA4 Il6 PBS = Y5 Ccl2 PBS (-0.243830)',
    'S09-A', 'S09!B8, I6, K4, T9, O8, O9, Y5, AA4, AP3, AP9', 294, 'qa_s09a_internal.py (kernel estimate of expected coincidences at 1e-6 resolution)',
    'Lung cytokine panel (used for reactogenicity observations S2-S5) carries an additional integrity flag.')

import psln_blocks as P2
nm = len([x for x in L if x['id'].startswith('M')]) + 1
for blk, lab in [('S03-C', 'CA09'), ('S03-G', 'Aichi')]:
    d = P2.extract(blk)
    parts = []
    for g, dd in d.groupby('group', sort=False):
        parts.append(f"{g} {int((dd.value >= 40).sum())}/{len(dd)} (values {', '.join(str(int(v)) for v in dd.value)})")
    add(f'M{nm}', f'HAI titre >= 40 (conventional human threshold), {lab}, day 14', '; '.join(parts), blk, f"S03!{d.cell.iloc[0]}:{d.cell.iloc[-1]}", len(d),
        'count of animals with reciprocal HAI titre >= 40; 0 recorded = below 1:10', '')
    nm += 1

add(f'M{nm}', 'S08-A Ifnb1 dose-response slope (log10 fold vs log10 dose, 1-40 ug)', 'PSLN-344 1.03 (r2 0.96); PSLN-344/R848 1.00 (0.96); PSLN-212 0.68 (0.95); CMP-204 0.58 (0.90); geometric-mean fold at 20 vs 40 ug: PSLN-344 45.5 vs 49.7, PSLN-212 12.5 vs 14.7',
    'S08-A', 'S08!A3:M7', 60, 'ordinary least squares of log10(per-animal fold) on log10(dose) per formulation (mechanism_extra.py)', 'age of animals not stated')
nm += 1
add(f'M{nm}', 'Restoration-index summary across the 28 readouts of Figure 3', 'median 0.71 (range 0.17-0.98); excluding DC CD40/CD86 (0.17, 0.22): range 0.41-0.98, median 0.73, 25/26 readouts >= 0.56 (exception: lung GZMB+ CD8 day 3, 0.41)',
    'see Figure 3 blocks', 'tables/immuno_mechanism_tests.csv', 28, 'RI = (aged PSLN-344 - aged PSLN-212)/(young PSLN-212 - aged PSLN-212); log10 scale for titres/fold', '')
nm += 1

LED = pd.DataFrame(L)
LED.to_csv('/tmp/outputs/evidence_ledger.csv', index=False)
with pd.ExcelWriter('/tmp/outputs/evidence_ledger.xlsx', engine='xlsxwriter') as xw:
    LED.to_excel(xw, sheet_name='ledger', index=False)
    ws = xw.sheets['ledger']
    ws.set_column('A:A', 6); ws.set_column('B:B', 60); ws.set_column('C:C', 110); ws.set_column('D:D', 18); ws.set_column('E:E', 60); ws.set_column('F:F', 6); ws.set_column('G:G', 60); ws.set_column('H:H', 50)
pd.set_option('display.width', 250, 'display.max_colwidth', 200, 'display.max_rows', 500)
print(LED[['id', 'claim', 'value']].to_string())
import json
json.dump({str(k): v for k, v in {**E_ID, **{str(k): v for k, v in M_ID.items()}}.items()}, open('/tmp/outputs/tables/ledger_index.json', 'w'), indent=1)

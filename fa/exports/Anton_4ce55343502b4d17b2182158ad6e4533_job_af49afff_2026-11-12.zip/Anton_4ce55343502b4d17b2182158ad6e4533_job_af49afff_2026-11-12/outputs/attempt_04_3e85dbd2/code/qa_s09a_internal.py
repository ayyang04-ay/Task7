"""Identical 6-decimal log10 values inside S09-A across different analyte/group/replicate cells, and the
expected number of such coincidences under independence (empirical spacing model)."""
import itertools, numpy as np, pandas as pd
import psln_blocks as P
s9 = P.extract_s09a()
s9['r6'] = s9.log10.round(6)
dups = s9.groupby('r6').filter(lambda x: len(x) > 1).sort_values('r6')
print(dups[['block', 'analyte', 'group', 'rep', 'cell', 'log10']].to_string())
# chance model: values recorded to 6 decimals; P(two independent values identical) ~ density overlap * 1e-6
v = s9.log10.values
n = len(v); pairs = n * (n - 1) / 2
# kernel estimate of sum_i f(x_i) * 1e-6 over pairs  ~  (1e-6) * sum_{i<j} K(x_i - x_j)
h = 0.05
diffs = np.abs(v[:, None] - v[None, :])[np.triu_indices(n, 1)]
dens = (np.exp(-0.5 * (diffs / h) ** 2) / (h * np.sqrt(2 * np.pi))).sum()
expected = dens * 1e-6
print(f'cells {n}, pairs {pairs:.0f}, observed identical pairs {int(dups.groupby("r6").size().apply(lambda k: k*(k-1)/2).sum())}, expected under independence ~{expected:.3f}')

"""Fractional-part fingerprint scan.
Percent-of-baseline weights computed as 100*w_t/w_0 carry long decimal tails that are specific to the
animal's raw weights.  The same 6+ digit tail re-appearing with a DIFFERENT integer part, in different
cells, is not expected from independent measurements and is a fingerprint of values being copied and
then edited (integer part changed).  We list every tail (>=5 decimals) that occurs in >1 cell.
"""
import openpyxl, pandas as pd, collections
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx', data_only=True)
rec = []
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            v = c.value
            if isinstance(v, float):
                s = repr(v)
                if 'e' in s or '.' not in s:
                    continue
                ip, fp = s.split('.')
                if len(fp) >= 5:
                    rec.append(dict(sheet=ws.title, cell=c.coordinate, value=v, int_part=int(ip), frac=fp[:6]))
D = pd.DataFrame(rec)
g = D.groupby('frac')
multi = g.filter(lambda x: len(x) > 1).sort_values(['frac', 'sheet', 'cell'])
pd.set_option('display.width', 200, 'display.max_rows', 500)
print('cells with >=5 decimals:', len(D))
print('distinct tails:', D.frac.nunique(), ' tails occurring in >1 cell:', multi.frac.nunique())
summ = multi.groupby('frac').agg(n=('cell', 'size'), cells=('cell', lambda x: ', '.join(x)),
                                 sheets=('sheet', lambda x: ','.join(sorted(set(x)))),
                                 values=('value', lambda x: ', '.join(f'{v:.8g}' for v in x)),
                                 n_int=('int_part', 'nunique')).reset_index()
print(summ.to_string())
summ.to_csv('/tmp/outputs/tables/qa_fraction_fingerprints.csv', index=False)

"""Safety / reactogenicity readouts and corrected derived quantities.

S08-D  post-vaccination body weight (no challenge): per-animal nadir (% of day 0) over days 2-10 and
       day-of-nadir; group mean nadir; Welch t vs 'Vaccine' (vaccine without adjuvant).
S09-A  lung cytokine transcripts (log10 fold).  Left block = 16 h (values reproduce S01-A 16 h);
       right block is LABELLED 16 h but its Ifnb1 values reproduce S01-A 72 h -> analysed as '72 h (relabelled)'.
       Group mean of log10 values -> geometric-mean fold = 10^mean.  PSLN-344 (aged) compared with
       PSLN-212(y) (young benchmark) to ask whether aged PSLN-344 overshoots a young-type response.
S10-A  CNS transcripts 36 h: geometric mean fold; Tukey on log10 values.
IgG2a/IgG1 corrected: per-animal quotient computed from S13-A/S13-B (CA09) and S13-C/S13-D (Aichi), using the
       S13 group labels (S03-B/S03-F labels are rotated; see qa_derived.py).
"""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
import psln_blocks as P
pd.set_option('display.width', 250, 'display.max_rows', 300, 'display.max_colwidth', 60)
out = {}

# ---------------- S08-D reactogenicity ----------------
W = P.extract('S08-D')
rows = []
for (g, a), d in W.groupby(['group', 'animal'], sort=False):
    d = d[(d.day > 0)].dropna(subset=['value'])
    i = d.value.idxmin()
    rows.append(dict(group=g, animal=a, nadir=d.value.min(), nadir_day=d.loc[i, 'day'], day10=(d[d.day == 10].value.iloc[0] if (d.day == 10).any() else np.nan),
                     cells=f"{d.cell.iloc[0]}..{d.cell.iloc[-1]}"))
N = pd.DataFrame(rows)
Gs = N.groupby('group', sort=False).agg(n=('nadir', 'size'), mean_nadir=('nadir', 'mean'), sd=('nadir', 'std'), min_nadir=('nadir', 'min'),
                                        median_nadir_day=('nadir_day', 'median'), mean_day10=('day10', 'mean'), n_day10=('day10', 'count'))
ref = N[N.group == 'Vaccine'].nadir
Gs['welch_p_vs_vaccine'] = [stats.ttest_ind(N[N.group == g].nadir, ref, equal_var=False).pvalue if g != 'Vaccine' else np.nan for g in Gs.index]
Gs['mean_weight_loss_at_nadir_pct'] = 100 - Gs.mean_nadir
print('=== S08-D post-vaccination weight nadir (% of day-0), days 2-10')
print(Gs.round(3).to_string())
Gs.to_csv('/tmp/outputs/tables/safety_S08D_weight_nadir.csv')
N.to_csv('/tmp/outputs/tables/safety_S08D_per_animal.csv', index=False)

# ---------------- S09-A cytokines ----------------
s9 = P.extract_s09a()
s9['timepoint'] = s9.block.map({'S09-A left': '16 h', 'S09-A right': '72 h (block labelled 16 h; Ifnb1 values = S01-A 72 h)'})
cy = s9.groupby(['timepoint', 'analyte', 'group'], sort=False).log10.agg(['mean', 'std', 'count']).reset_index()
cy['geo_fold'] = 10 ** cy['mean']
piv = cy.pivot_table(index=['timepoint', 'analyte'], columns='group', values='geo_fold', sort=False)
print('\n=== S09-A lung transcripts, geometric-mean fold vs untreated (n=3)')
print(piv.round(1).to_string())
# PSLN-344 aged vs PSLN-212(y) young and vs PSLN-212 aged: Welch on log10
tt = []
for (tp, an), d in s9.groupby(['timepoint', 'analyte'], sort=False):
    a = d[d.group == 'PSLN-344'].log10; y = d[d.group == 'PSLN-212(Y)'].log10; b = d[d.group == 'PSLN-212'].log10
    r8 = d[d.group == 'PSLN-212/R848'].log10
    tt.append(dict(timepoint=tp, analyte=an, fold_344_over_young212=10 ** (a.mean() - y.mean()), p_vs_young=stats.ttest_ind(a, y, equal_var=False).pvalue,
                   fold_344_over_aged212=10 ** (a.mean() - b.mean()), p_vs_aged212=stats.ttest_ind(a, b, equal_var=False).pvalue,
                   fold_R848combo_over_344=10 ** (r8.mean() - a.mean()), p_R848_vs_344=stats.ttest_ind(r8, a, equal_var=False).pvalue))
TT = pd.DataFrame(tt)
print(TT.round(4).to_string())
cy.to_csv('/tmp/outputs/tables/safety_S09A_cytokines.csv', index=False)
TT.to_csv('/tmp/outputs/tables/safety_S09A_contrasts.csv', index=False)

# ---------------- S10-A CNS ----------------
print('\n=== S10-A CNS transcripts 36 h (geometric mean fold; Tukey on log10)')
cns = []
for an in ['Ifnb1', 'Tnf', 'Isg15']:
    d = P.extract(f'S10-A {an}')
    y = np.log10(d.value.values); g = d.group.values
    tk = pairwise_tukeyhsd(y, g)
    res = pd.DataFrame(tk._results_table.data[1:], columns=tk._results_table.data[0])
    gm = d.groupby('group', sort=False).value.apply(lambda v: 10 ** np.log10(v).mean())
    for a, b in [('PSLN-344', 'PBS'), ('PSLN-344', 'Sham'), ('CT', 'PBS'), ('CT', 'PSLN-344')]:
        r = res[((res.group1 == a) & (res.group2 == b)) | ((res.group1 == b) & (res.group2 == a))]
        cns.append(dict(analyte=an, contrast=f'{a} vs {b}', geo_fold_a=gm[a], geo_fold_b=gm[b], ratio=gm[a] / gm[b], tukey_p=float(r['p-adj'].iloc[0])))
CNS = pd.DataFrame(cns)
print(CNS.round(4).to_string())
CNS.to_csv('/tmp/outputs/tables/safety_S10A_cns.csv', index=False)

# ---------------- corrected IgG2a/IgG1 ----------------
print('\n=== IgG2a/IgG1 quotient recomputed from raw subclass titres (S13 labels)')
rr = []
for lab, a, b, printed in [('CA09 H1N1', 'S13-A', 'S13-B', 'S03-B'), ('Aichi H3N2', 'S13-C', 'S13-D', 'S03-F')]:
    A = P.extract(a); B = P.extract(b)
    A['pos'] = A.groupby('group').cumcount(); B['pos'] = B.groupby('group').cumcount()
    M = A.merge(B, on=['group', 'pos'], suffixes=('_2a', '_1'))
    M['q'] = M.value_2a / M.value_1
    Pr = P.extract(printed).groupby('group', sort=False).value.mean()
    for g, d in M.groupby('group', sort=False):
        lq = np.log10(d.q)
        rr.append(dict(antigen=lab, group=g, n=len(d), geo_mean_ratio=10 ** lq.mean(), arith_mean_ratio=d.q.mean(),
                       printed_mean_under_same_label=Pr.get(g), source=f'{a}/{b}'))
    gg = M.group.values; y = np.log10(M.q.values)
    tk = pairwise_tukeyhsd(y, gg)
    print(lab, '\n', tk)
RR = pd.DataFrame(rr)
print(RR.round(3).to_string())
RR.to_csv('/tmp/outputs/tables/igg2a_igg1_corrected.csv', index=False)

# ---------------- early vs late Ifnb1 persistence (S01-A) ----------------
print('\n=== S01-A Ifnb1 persistence: 72 h / 16 h geometric-mean ratio')
a16 = P.extract('S01-A 16h').groupby('group', sort=False).value.apply(lambda v: 10 ** np.log10(v).mean())
a72 = P.extract('S01-A 72h').groupby('group', sort=False).value.apply(lambda v: 10 ** np.log10(v).mean())
print(pd.DataFrame({'16h': a16, '72h': a72, 'pct_remaining_72h': 100 * a72 / a16}).round(2).to_string())

"""Survival vs body-weight consistency.
For each weight block that the annotation ties to a survival block, infer deaths from the weight
record (animal missing from a weigh day onward, or value frozen = last-observation-carried-forward
through day 14) and compare against the survival block's deaths, group by group.
"""
import pandas as pd, numpy as np
import psln_blocks as P

pairs = [('S15-A', 'S06-A'), ('S15-B', 'S06-B'), ('S15-C', 'S06-C'), ('S15-D', 'S06-D'), ('S15-E', 'S06-E'),
         ('S15-F', 'S06-F'), ('S15-G', 'S06-G'), ('S15-I', 'S15-H'), ('S15-J', 'S06-E(imprint)'),
         ('S15-K', 'S06-F(imprint)'), ('S15-M', 'S15-L'), ('S15-O', 'S15-N'), ('S09-C', 'S09-B'),
         ('S09-E', 'S09-D'), ('S09-G', 'S09-F'), ('S13-F', 'S03-I'), ('S13-G', 'S03-J')]

def weight_deaths(w):
    """returns list of (animal, last_real_day, status) ; status in {'alive','missing','frozen'}"""
    res = []
    days = sorted(w.day.unique())
    for a, d in w.groupby('animal'):
        d = d.set_index('day').reindex(days)
        vals = d['value'].tolist()
        # missing from some day onward
        if any(pd.isna(x) for x in vals):
            first_missing = next(i for i, x in enumerate(vals) if pd.isna(x))
            res.append((a, days[first_missing - 1], 'missing'))
            continue
        # frozen: identical value over >=2 trailing intervals (3+ identical trailing values) and below 90 %
        tail_eq = 0
        for i in range(len(vals) - 1, 0, -1):
            if vals[i] == vals[i - 1]:
                tail_eq += 1
            else:
                break
        if tail_eq >= 2 or (tail_eq == 1 and vals[-1] < 85.0):
            res.append((a, days[len(vals) - 1 - tail_eq], 'frozen'))
        else:
            res.append((a, None, 'alive'))
    return res

rows = []
for wb_id, sv_id in pairs:
    W = P.extract(wb_id); S = P.extract(sv_id)
    sv_groups = list(dict.fromkeys(S.group)); w_groups = list(dict.fromkeys(W.group))
    for g in w_groups:
        wd = weight_deaths(W[W.group == g])
        n_w = len(wd); dead_w = [x for x in wd if x[2] != 'alive']
        if g in sv_groups:
            s = S[S.group == g]
            dead_s = s[s.event == 1]
            sd = sorted(dead_s.day.dropna().astype(int).tolist())
            n_s = len(s)
        else:
            sd, n_s = None, None
        rows.append(dict(weight_block=wb_id, survival_block=sv_id, group=g, n_weight=n_w,
                         n_surv=n_s, deaths_surv=(len(sd) if sd is not None else 'group absent'),
                         death_days_surv=sd, deaths_weight=len(dead_w),
                         weight_death_pattern=sorted([(x[1], x[2]) for x in dead_w], key=lambda t: (t[0] is None, t[0]))))
    for g in sv_groups:
        if g not in w_groups:
            s = S[S.group == g]
            rows.append(dict(weight_block=wb_id, survival_block=sv_id, group=g, n_weight='group absent',
                             n_surv=len(s), deaths_surv=int(s.event.sum()),
                             death_days_surv=sorted(s[s.event == 1].day.dropna().astype(int).tolist()),
                             deaths_weight=None, weight_death_pattern=None))
R = pd.DataFrame(rows)
def verdict(r):
    if r.n_weight == 'group absent' or r.deaths_surv == 'group absent':
        return 'GROUP MISMATCH'
    return 'match' if r.deaths_surv == r.deaths_weight else 'MISMATCH'
R['verdict'] = R.apply(verdict, axis=1)
pd.set_option('display.width', 250, 'display.max_colwidth', 90, 'display.max_rows', 500)
print(R.to_string())
R.to_csv('/tmp/outputs/tables/qa_survival_vs_weight.csv', index=False)

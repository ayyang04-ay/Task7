# PSLN-344 analysis code

All scripts read `/tmp/world/filesystem/adjuvant_program_dataset.xlsx` (path set in `psln_blocks.py`, variable `XLSX`)
and write to `/tmp/outputs/{tables,figures}` and `/tmp/outputs/evidence_ledger.{csv,xlsx}`.
Run `./run_all.sh` (set `PY` to your python if not using micromamba env `chem`).

| Script | Purpose |
|---|---|
| `psln_blocks.py` | Registry of all 105 blocks (sheet, header row, data cells); extraction with cell-level provenance. Group names are read from header cells. |
| `qa_duplicates.py`, `qa_duplicates_strong.py` | Exact duplication of per-animal vectors across/within blocks; strong-evidence filter. |
| `qa_fraction_fingerprint.py` | Recurring >=5-digit decimal tails across cells (copy-and-edit fingerprint). |
| `qa_tail_lattice.py`, `qa_tail_lattice_summary.py` | Can a value be produced as 100*w/w0 from a 0.1 g / 0.01 g balance for baselines 15-45 g? |
| `qa_verify_specifics.py` | Cell-exact verification of the specific duplications cited in the ledger (Q2, Q3, Q4, Q7). |
| `qa_surv_vs_weight.py` | Deaths in survival blocks vs deaths inferred from the paired body-weight blocks. |
| `qa_survival_dups.py` | Identical survival records across experiments. |
| `qa_derived.py` | Derived-vs-raw checks (Tfh:Tfr, IgG2a/IgG1 labels, S09-A vs S01-A, S11-A/B, S01-B/S08-C, HAI <LOD, missing values). |
| `qa_s09a_internal.py` | Identical 6-decimal log10 values across unrelated cells of the S09-A cytokine panel vs chance expectation. |
| `efficacy_survival.py` | Per-experiment survival summaries, Fisher, log-rank, Newcombe CIs; integrity tiers. |
| `efficacy_pooled_boot.py` | Pooled Mantel-Haenszel risk differences with stratified bootstrap CIs, stratified log-rank, sensitivity subsets, background mortality. |
| `immuno_mechanism.py` | Group summaries (GMT / mean, 95% CI), ANOVA + Tukey, Welch, Hedges g, restoration index for every value block. |
| `safety_and_corrections.py` | S08-D weight nadir, S09-A cytokines (right block relabelled 72 h), S10-A CNS, corrected IgG2a/IgG1. |
| `mechanism_extra.py` | Mechanistic contrasts (IFNAR chimeras, GM-CSF, CCR2, PTX, CBX, SP-A/D, SRB uptake, EE, dose-response). |
| `power_calcs.py` | Sample sizes for the proposed studies. |
| `build_ledger.py` | Evidence ledger (every cited number with cells and reduction). |
| `figures.py` | Figures 1-6. |
| `check_report.py` | Verifies every ledger ID cited in the report exists and that cited numbers match the ledger. |

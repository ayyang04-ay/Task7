"""Strong-evidence duplication filter on top of qa_duplicates.py output.
Flags cross-group / cross-block vector pairs with
  (a) >=4 identical values in the same animal position, or
  (b) >=2 shared 'high-precision' values (>=3 decimal places, e.g. 92.42424), which arise from
      computed ratios and are very unlikely to coincide by chance.
Within-group repeats across days in one block (last-observation-carried-forward for dead animals) are excluded.
"""
import pandas as pd, ast
H = pd.read_csv('/tmp/outputs/tables/qa_duplicate_vectors.csv')
H = H[~((H.blockA == H.blockB) & (H.groupA == H.groupB))].copy()

def hp(v):
    s = repr(float(v))
    return len(s.split('.')[1]) >= 3 if '.' in s else False

def hp_shared(a, b):
    a = [x for x in ast.literal_eval(a) if hp(x)]
    b = [x for x in ast.literal_eval(b) if hp(x)]
    return len(set(a) & set(b))

H['hp_shared'] = [hp_shared(a, b) for a, b in zip(H.A_vals, H.B_vals)]
S = H[(H.same_position >= 4) | (H.hp_shared >= 2)].copy()
S = S.sort_values(['blockA', 'blockB', 'groupA', 'timeA'])
pd.set_option('display.width', 300, 'display.max_colwidth', 75, 'display.max_rows', 500)
print(S[['blockA', 'groupA', 'timeA', 'blockB', 'groupB', 'timeB', 'same_position', 'shared_values', 'hp_shared', 'A_vals', 'B_vals']].to_string())
S.to_csv('/tmp/outputs/tables/qa_duplicate_vectors_strong.csv', index=False)
print(len(S))

import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import psln_blocks as P
from efficacy_survival import newcombe_rd, TIER

T = '/tmp/outputs/tables/'; F = '/tmp/outputs/figures/'
plt.rcParams.update({'font.size': 9, 'font.family': 'DejaVu Sans'})
TIERCOL = {'clean': '#1b7837', 'T1': '#b2182b', 'T2': '#ef8a62', 'T3': '#f4c542'}

def tier_of(e):
    t = TIER.get(e, '')
    return 'clean' if t == 'clean' else t[:2]

# ---------------- Fig 1: forest ----------------
ALL = pd.read_csv(T + 'survival_all_animals.csv')
AGED = ['S06-B', 'S06-G', 'S06-A', 'S06-E', 'S06-F', 'S15-L', 'S15-N', 'S06-C', 'S06-D', 'S03-I', 'S03-J']
LAB = {'S03-I': 'S03-I  homologous CA09, d14', 'S03-J': 'S03-J  wt H5N1, d2 (rgH5N1 vaccine)', 'S06-A': 'S06-A  H3N2 vacc -> PR8, d14',
       'S06-B': 'S06-B  H3N2 vacc -> PR8, d3', 'S06-C': 'S06-C  bivalent -> rgH5N1, d14', 'S06-D': 'S06-D  bivalent -> rgH5N1, d3',
       'S06-E': 'S06-E  H3N2 vacc -> PR8, d60', 'S06-F': 'S06-F  bivalent -> rgH5N1, d60', 'S06-G': 'S06-G  H1N1 vacc -> Perth H3N2, d60',
       'S15-L': 'S15-L  aged C57BL/6 (challenge n.s.)', 'S15-N': 'S15-N  aged Swiss Webster (challenge n.s.)'}
fig, axes = plt.subplots(1, 2, figsize=(12, 6.2), sharey=True)
PO = pd.read_csv(T + 'survival_pooled_sensitivity.csv')
for ax, comp in zip(axes, ['Sham', 'PSLN-212']):
    y = 0; yt = []; yl = []
    for e in AGED:
        d = ALL[ALL.experiment == e]
        a = d[d.group == 'PSLN-344']; b = d[d.group == comp]
        k1, n1 = int((a.event == 0).sum()), len(a); k2, n2 = int((b.event == 0).sum()), len(b)
        rd, lo, hi = newcombe_rd(k1, n1, k2, n2)
        c = TIERCOL[tier_of(e)]
        ax.plot([100 * lo, 100 * hi], [y, y], color=c, lw=2)
        ax.plot(100 * rd, y, 's', color=c, ms=7)
        ax.text(104, y, f'{k1}/{n1} vs {k2}/{n2}', va='center', fontsize=8)
        yt.append(y); yl.append(LAB[e]); y -= 1
    y -= 0.6
    for code, lab in [('A', 'Pooled, as recorded (11 exps)'), ('C', 'Pooled, excl. Tier-1 (7 exps)'), ('D', 'Pooled, excl. Tier-1+2 (2 exps)'), ('E', 'Unflagged only (S06-B)')]:
        r = PO[(PO.subset.str.startswith(code)) & (PO.comparison == f'PSLN-344 vs {comp}')].iloc[0]
        ax.plot([r.boot95_lo, r.boot95_hi], [y, y], color='k', lw=2.5)
        ax.plot(r.MH_RD_pp, y, 'D', color='k', ms=8)
        ax.text(104, y, f'{r.group1.split(" ")[0]} vs {r.group2.split(" ")[0]}', va='center', fontsize=8)
        yt.append(y); yl.append(lab); y -= 1
    ax.axvline(0, color='grey', lw=0.8, ls='--')
    ax.set_xlim(-40, 103)
    ax.set_xlabel(f'Survival difference, PSLN-344 minus {comp} (percentage points)')
    ax.set_title(f'Aged mice: PSLN-344 vs {comp}')
    ax.set_yticks(yt); ax.set_yticklabels(yl)
fig.legend(handles=[Patch(color=TIERCOL['clean'], label='no integrity flag'), Patch(color=TIERCOL['T3'], label='Tier 3: survival vs weight death counts disagree'),
                        Patch(color=TIERCOL['T2'], label='Tier 2: companion weight record contains copied/edited values'), Patch(color=TIERCOL['T1'], label='Tier 1: survival record duplicated or in conflict')],
               loc='lower center', ncol=4, fontsize=8, frameon=True)
fig.suptitle('Figure 1. Survival benefit of PSLN-344 in aged mice by experiment, coloured by data-integrity tier\n(per-experiment: Newcombe 95% CI; pooled: Mantel-Haenszel with stratified-bootstrap 95% CI)', fontsize=10)
plt.tight_layout(rect=[0, 0.05, 1, 0.93])
plt.savefig(F + 'fig1_survival_forest_by_integrity.png', dpi=200); plt.close()

# ---------------- Fig 2: integrity map ----------------
exps = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N', 'S06-E(imprint)', 'S06-F(imprint)', 'S15-H', 'S09-B', 'S09-D', 'S09-F', 'S13-E']
checks = ['Survival\nrecord\nduplicated in\nanother exp.', 'Group\nidentities\ndiffer from\nweight record', 'Weight record\nhas values\ncopied/edited\nfrom other exps',
          'Death counts\ndiffer between\nsurvival and\nweights', 'Stated vs\nobserved n\nconflict or\nmissing value', 'Challenge or\nkey metadata\nmissing']
M = pd.DataFrame(0, index=exps, columns=checks)
M.loc[['S06-C', 'S06-D'], checks[0]] = 1
M.loc[['S03-I', 'S03-J'], checks[1]] = 1
M.loc[['S06-A', 'S06-C', 'S06-F', 'S15-L', 'S15-N', 'S06-E(imprint)', 'S06-F(imprint)', 'S15-H', 'S09-B', 'S09-D', 'S06-E'], checks[2]] = 1
M.loc[['S06-C', 'S06-D', 'S06-E', 'S06-G', 'S15-L', 'S15-N', 'S09-F', 'S03-I', 'S03-J'], checks[3]] = 1
M.loc[['S03-J', 'S13-E', 'S09-B', 'S09-F'], checks[4]] = 1
M.loc[['S15-L', 'S15-N'], checks[5]] = 1
fig, ax = plt.subplots(figsize=(9, 8))
ax.imshow(M.values, cmap=matplotlib.colors.ListedColormap(['#f7f7f7', '#d6604d']), aspect='auto')
ax.set_xticks(range(len(checks))); ax.set_xticklabels(checks, fontsize=8)
ax.set_yticks(range(len(exps)))
ylabs = [f"{e}  ({'aged' if e in AGED else ('14-mo imprinted' if 'imprint' in e else ('aged, 3-arm' if e == 'S15-H' else 'young'))})" for e in exps]
ax.set_yticklabels(ylabs, fontsize=8)
for i in range(len(exps)):
    for j in range(len(checks)):
        if M.values[i, j]:
            ax.text(j, i, 'x', ha='center', va='center', color='white', fontweight='bold')
ax.set_title('Figure 2. Integrity checks failed, by survival experiment (x = failed)\nOnly S06-B (aged) passes every check; see ledger Q1-Q9, Q17, Q19', fontsize=10)
plt.tight_layout(); plt.savefig(F + 'fig2_integrity_map.png', dpi=200); plt.close()
M.to_csv(T + 'integrity_map.csv')

# ---------------- Fig 3: restoration index chain ----------------
Tt = pd.read_csv(T + 'immuno_mechanism_tests.csv')
chain = [('S01-A 16h', None, 'Lung Ifnb1 16 h', 'Innate'), ('S01-D', '4', 'Lung monocytes d4', 'Innate'), ('S01-E', '4', 'Lung CD11b+ DC d4', 'DC'),
         ('S01-F', None, 'Lung cDC1 72 h', 'DC'), ('S02-A', None, 'Migratory CCR7+ DC 72 h', 'DC'), ('S02-B', None, 'MLN CD11b+ DC 72 h', 'DC'),
         ('S02-C', None, 'Antigen+ DC in MLN 36 h', 'DC'), ('S02-D CD40', None, 'MLN DC CD40+ d3', 'DC'), ('S02-D CD86', None, 'MLN DC CD86+ d3', 'DC'),
         ('S02-E', None, 'OT-I priming by MLN DC*', 'T cell'), ('S05-D', None, 'Lung Ki-67+ CD8 d3', 'T cell'), ('S05-E', None, 'Lung GZMB+ CD8 d3', 'T cell'),
         ('S05-F', None, 'IFN-g+ CD8 (H5 restim) d14', 'T cell'), ('S05-I', None, 'Lung TRM CD8 d25', 'T cell'), ('S05-G', None, 'IFN-g+ CD8 (H5 restim) d60', 'T cell'),
         ('S05-H', None, 'GZMB+ CD8 d60', 'T cell'), ('S04-A ICOShi', None, 'ICOS-hi Tfh d7', 'B/Tfh'), ('S04-B Foxp3', None, 'Tfr d7 (lower = better)', 'B/Tfh'),
         ('S03-K', None, 'GC B cells d7', 'B/Tfh'), ('S13-H', None, 'IgG+ B cells MLN', 'B/Tfh'), ('S03-A', None, 'Serum IgG CA09 d14', 'Antibody'),
         ('S03-C', None, 'HAI CA09 d14', 'Antibody'), ('S03-D', None, 'Neutralising CA09 d14', 'Antibody'), ('S03-E', None, 'Serum IgG Aichi d14', 'Antibody'),
         ('S03-G', None, 'HAI Aichi d14', 'Antibody'), ('S03-H', None, 'Neutralising Aichi d14', 'Antibody'), ('S13-I', None, 'IgG CA09 post-boost', 'Antibody'), ('S13-J', None, 'IgG Aichi post-boost', 'Antibody')]
CAT = {'Innate': '#4393c3', 'DC': '#92c5de', 'T cell': '#d6604d', 'B/Tfh': '#b8e186', 'Antibody': '#4d9221'}
rows = []
for blk, t, lab, cat in chain:
    r = Tt[(Tt.block == blk) & ((Tt.time.astype(str) == str(t)) if t is not None else Tt.time.isna())].iloc[0]
    rows.append((lab, cat, r.restoration_index))
fig, ax = plt.subplots(figsize=(8, 8))
ys = np.arange(len(rows))[::-1]
for y, (lab, cat, ri) in zip(ys, rows):
    ax.barh(y, ri, color=CAT[cat])
    ax.text(max(ri, 0) + 0.02, y, f'{ri:.2f}', va='center', fontsize=7.5)
ax.set_yticks(ys); ax.set_yticklabels([r[0] for r in rows], fontsize=8)
ax.axvline(1, color='k', ls='--', lw=0.8); ax.axvline(0, color='k', lw=0.8)
ax.set_xlim(-0.05, 1.25)
ax.set_xlabel('Restoration index = (aged PSLN-344 - aged PSLN-212) / (young PSLN-212 - aged PSLN-212)\n0 = Mn adds nothing in aged mice; 1 = reaches young benchmark\n(titres and fold-changes on log10 scale)', fontsize=8.5)
ax.legend(handles=[Patch(color=v, label=k) for k, v in CAT.items()], loc='lower right', fontsize=8)
ax.set_title('Figure 3. How much of the age-related deficit does Mn close?\n(*S02-E: donor strain not stated; OT-I MHC restriction unresolved, ledger Q18)', fontsize=10)
plt.tight_layout(); plt.savefig(F + 'fig3_restoration_index.png', dpi=200); plt.close()

# ---------------- Fig 4: fingerprint table ----------------
import openpyxl
wb = openpyxl.load_workbook(P.XLSX, data_only=True)
pairs = [('G', 'B'), ('K', 'C'), ('I', 'D'), ('J', 'E')]
fig, ax = plt.subplots(figsize=(11, 3.4)); ax.axis('off')
cell_text = []; colors = []
days = [2, 4, 6, 8, 10]
header = ['day']
for a, b in pairs:
    header += [f'S08!{a}', f'S15!{b}']
for i, d in enumerate(days):
    row = [str(d)]; crow = ['white']
    for a, b in pairs:
        va = wb['S08'][f'{a}{22+i}'].value; vb = wb['S15'][f'{b}{54+i}'].value
        row += [f'{va}', f'{vb}']
        ta = repr(float(va)).split('.')[1]; tb_ = repr(float(vb)).split('.')[1]
        same = (va == vb) or (len(ta) >= 5 and ta[:5] == tb_[:5])
        crow += ['#fddbc7' if same else 'white'] * 2
    cell_text.append(row); colors.append(crow)
tb = ax.table(cellText=cell_text, colLabels=header, cellColours=colors, loc='center', cellLoc='center')
tb.auto_set_font_size(False); tb.set_fontsize(8); tb.scale(1, 1.7)
ax.set_title('Figure 4. Same decimal tails, different integer parts. S08!G-K rows 22-26 = S08-D CMP-204 weights after vaccination (no challenge);\n'
             'S15!B-E rows 54-58 = S15-F young PSLN-212 weights after day-60 H5N1 challenge. Shaded = identical 5-digit tail (or identical value).\n'
             'At a 0.1 g balance, 18 of the 19 S08-D values cannot arise as 100 x w/w0 for any baseline of 15-45 g, and the two records are different animals (ledger Q3).', fontsize=8.5)
plt.tight_layout(); plt.savefig(F + 'fig4_fingerprint_S08D_vs_S15F.png', dpi=200); plt.close()

# ---------------- Fig 5: Ifnb1 dose-response and age ----------------
fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
d = P.extract('S08-A')
cols = {'CMP-204': '#999999', 'PSLN-212': '#4393c3', 'PSLN-344': '#b2182b', 'PSLN-344/R848': '#f4a582'}
for g, dd in d.groupby('group'):
    gm = dd.groupby('time').value.apply(lambda v: 10 ** np.log10(v).mean())
    axes[0].plot(gm.index, gm.values, 'o-', color=cols[g], label=g)
    axes[0].scatter(dd.time, dd.value, color=cols[g], s=10, alpha=0.5)
axes[0].set_xscale('log'); axes[0].set_yscale('log'); axes[0].set_xlabel('Intranasal dose (ug per animal)'); axes[0].set_ylabel('Lung Ifnb1, fold vs untreated (16 h)')
axes[0].set_title('S08-A dose-response (n=3/dose; age not stated)'); axes[0].legend(fontsize=8)
d = P.extract('S01-A 16h')
order = ['Sham', 'CMP-204', 'PSLN-R848', 'PSLN-212', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']
for i, g in enumerate(order):
    v = d[d.group == g].value
    c = '#b2182b' if g == 'PSLN-344' else ('#2166ac' if '(Y)' in g else '#bbbbbb')
    axes[1].bar(i, 10 ** np.log10(v).mean(), color=c)
    axes[1].scatter(np.full(len(v), i), v, color='k', s=8, zorder=3)
axes[1].set_xticks(range(len(order))); axes[1].set_xticklabels(order, rotation=40, ha='right', fontsize=8)
axes[1].set_ylabel('Lung Ifnb1, fold (16 h); bars = geometric mean')
axes[1].set_title('S01-A: aged (grey/red) vs young (blue), n=5')
fig.suptitle('Figure 5. Mn (PSLN-344) restores early lung type-I IFN in aged mice to the young benchmark and raises the dose-response ceiling', fontsize=10)
plt.tight_layout(rect=[0, 0, 1, 0.93]); plt.savefig(F + 'fig5_ifnb1_dose_and_age.png', dpi=200); plt.close()

# ---------------- Fig 6: KM ----------------
def km(days, events):
    t = np.array(days, float); e = np.array(events, int)
    times = np.unique(t[e == 1]); s = 1.0; xs = [0]; ys = [1.0]
    for tt in times:
        at_risk = (t >= tt).sum(); dth = ((t == tt) & (e == 1)).sum()
        xs += [tt, tt]; ys += [s, s * (1 - dth / at_risk)]; s = s * (1 - dth / at_risk)
    xs.append(14); ys.append(s)
    return xs, ys
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
gcol = {'Sham': '#777777', 'PSLN-212': '#4393c3', 'PSLN-344': '#b2182b', 'PSLN-212(Y)': '#1b7837', 'Untreated': '#000000'}
for ax, e, title in [(axes[0], 'S06-B', 'S06-B (the only experiment with no integrity flag)\nAichi H3N2 vaccine, PR8 challenge 3 days later, aged BALB/c'),
                     (axes[1], 'S06-G', 'S06-G: day-60 Perth H3N2 challenge\nnote unchallenged Untreated aged controls: 4/7 survive')]:
    d = ALL[ALL.experiment == e]
    for g, dd in d.groupby('group', sort=False):
        xs, ys = km(dd.day, dd.event)
        ax.step(xs, ys, where='post', color=gcol.get(g, 'k'), lw=2, label=f'{g} ({int((dd.event==0).sum())}/{len(dd)})', ls='--' if g == 'Untreated' else '-')
    ax.set_ylim(-0.03, 1.05); ax.set_xlim(0, 14.2); ax.set_xlabel('Days after challenge'); ax.set_ylabel('Proportion surviving'); ax.set_title(title, fontsize=9); ax.legend(fontsize=8)
fig.suptitle('Figure 6. Kaplan-Meier curves (source: S06!G2:K30 and S06!A70:F105)', fontsize=10)
plt.tight_layout(rect=[0, 0, 1, 0.92]); plt.savefig(F + 'fig6_km_S06B_S06G.png', dpi=200); plt.close()
print('figures written')

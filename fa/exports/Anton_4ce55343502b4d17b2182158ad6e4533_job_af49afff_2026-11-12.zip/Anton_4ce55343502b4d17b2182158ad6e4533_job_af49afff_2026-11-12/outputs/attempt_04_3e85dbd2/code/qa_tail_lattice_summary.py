"""Exact counts for the Q3 statement: of the 19 S08-D/S15-F tail-matched pairs, how many source (S08-D) values
and how many S15-F values are reachable as 100*w/w0 for baselines 15-45 g, and how many pairs share a baseline,
at balance resolutions 0.1 g and 0.01 g.  Also lists the shared baselines at 0.01 g."""
import numpy as np, openpyxl
from qa_tail_lattice import solutions, wb
pairs = []
for a, b in [('G', 'B'), ('K', 'C'), ('I', 'D'), ('J', 'E')]:
    for i in range(5):
        va = wb['S08'][f'{a}{22+i}'].value; vb = wb['S15'][f'{b}{54+i}'].value
        ta = repr(float(va)).split('.')[1]; tb = repr(float(vb)).split('.')[1]
        if len(ta) >= 5 and ta[:5] == tb[:5]:
            pairs.append((f'S08!{a}{22+i}', va, f'S15!{b}{54+i}', vb))
print('pairs:', len(pairs))
for r in (0.1, 0.01):
    ra = rb = sh = 0; shared = []
    for ca, va, cb, vb in pairs:
        sa = {x[0] for x in solutions(va, r)}; sb = {x[0] for x in solutions(vb, r)}
        ra += bool(sa); rb += bool(sb)
        c = sorted(sa & sb)
        if c:
            sh += 1; shared.append((ca, cb, c[:5]))
    print(f'r={r}: S08-D values reachable {ra}/{len(pairs)}; S15-F values reachable {rb}/{len(pairs)}; pairs sharing a baseline {sh}/{len(pairs)}')
    for s in shared: print('   ', s)

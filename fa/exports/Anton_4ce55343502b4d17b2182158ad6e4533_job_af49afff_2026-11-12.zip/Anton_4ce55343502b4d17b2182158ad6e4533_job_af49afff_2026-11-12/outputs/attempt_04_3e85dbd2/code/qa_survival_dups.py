"""Identical survival records (same multiset of (day, event)) across different blocks/groups.
All-censored groups (everyone alive at end) are excluded because they are identical by construction."""
import itertools, pandas as pd
import psln_blocks as P
recs = []
for bid, b in P.REG.items():
    if b['kind'] != 'survival':
        continue
    S = P.extract(bid)
    for g, d in S.groupby('group', sort=False):
        key = tuple(sorted(zip(d.day.fillna(-1).astype(int), d.event)))
        if sum(d.event) == 0:
            continue
        recs.append((bid, g, key))
out = []
for a, b in itertools.combinations(recs, 2):
    if a[2] == b[2]:
        out.append(dict(blockA=a[0], groupA=a[1], blockB=b[0], groupB=b[1], record=[f'{d}{"+" if e==0 else ""}' for d, e in a[2]]))
D = pd.DataFrame(out)
pd.set_option('display.width', 250, 'display.max_colwidth', 120)
print(D.to_string())
D.to_csv('/tmp/outputs/tables/qa_survival_identical_records.csv', index=False)
# block-level: compare whole blocks
print()
blocks = {}
for bid, g, key in recs:
    blocks.setdefault(bid, {})[g] = key
for a, b in itertools.combinations(blocks, 2):
    common = set(blocks[a]) & set(blocks[b])
    same = [g for g in common if blocks[a][g] == blocks[b][g]]
    if len(same) >= 2:
        print('BLOCK-LEVEL DUPLICATE:', a, b, 'identical groups:', same, 'of shared', sorted(common))

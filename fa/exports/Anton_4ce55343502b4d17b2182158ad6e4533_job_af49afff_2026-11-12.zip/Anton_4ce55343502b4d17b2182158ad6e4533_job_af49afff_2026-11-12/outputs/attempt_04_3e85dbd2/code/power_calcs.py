"""Sample sizes for the proposed confirmatory studies (two-sided alpha 0.05 unless stated).
Binary survival: exact Fisher power by simulation (20k reps) -> smallest n/arm giving >=80% and >=90% power.
Scenario rates are taken from this dataset (pooled Tier-1-excluded rates) or stated as planning assumptions."""
import numpy as np
from scipy import stats
rng = np.random.default_rng(7)
def power_fisher(p1, p2, n, reps=20000, alpha=0.05):
    a = rng.binomial(n, p1, reps); b = rng.binomial(n, p2, reps)
    # cache p-values
    cache = {}
    hits = 0
    for x, y in zip(a, b):
        k = (x, y)
        if k not in cache:
            cache[k] = stats.fisher_exact([[x, n - x], [y, n - y]])[1]
        hits += cache[k] < alpha
    return hits / reps
def nmin(p1, p2, target, alpha=0.05):
    for n in range(4, 200):
        if power_fisher(p1, p2, n, 6000, alpha) >= target:
            # confirm
            if power_fisher(p1, p2, n, 20000, alpha) >= target:
                return n
    return None
scen = [
  ('PSLN-344 vs Sham (76% vs 2%; dataset, Tier-1 excluded, Sham floor set to 2%)', 0.76, 0.02),
  ('PSLN-344 vs PSLN-212 (76% vs 8%; dataset, Tier-1 excluded)', 0.76, 0.08),
  ('PSLN-344 vs licensed-type adjuvant (76% vs 40%; planning assumption)', 0.76, 0.40),
  ('PSLN-344 vs licensed-type adjuvant (76% vs 50%; planning assumption)', 0.76, 0.50),
  ('PSLN-344 d60 vs Sham (67% vs 2%; dataset)', 0.67, 0.02),
  ('Replication of the single clean experiment S06-B (71% vs 0%->2%)', 0.71, 0.02),
]
for lab, p1, p2 in scen:
    n80 = nmin(p1, p2, 0.80); n90 = nmin(p1, p2, 0.90)
    print(f'{lab}: n/arm for 80% power = {n80}; 90% power = {n90}')
# Bonferroni for 3 primary comparisons
print('\nWith 3 co-primary comparisons (alpha 0.0167 each):')
for lab, p1, p2 in scen[:4]:
    n80 = None
    for n in range(4, 200):
        if power_fisher(p1, p2, n, 6000, 0.0167) >= 0.8 and power_fisher(p1, p2, n, 20000, 0.0167) >= 0.8:
            n80 = n; break
    print(f'{lab}: n/arm = {n80}')
# continuous: lung viral titre log10 difference, SD ~0.8 log10 (planning assumption)
from statsmodels.stats.power import TTestIndPower
tp = TTestIndPower()
for delta, sd in [(1.0, 0.8), (0.5, 0.8), (0.7, 0.8)]:
    n = tp.solve_power(effect_size=delta / sd, alpha=0.05, power=0.9)
    print(f'lung viral titre: detect {delta} log10 reduction (SD {sd}) with 90% power: n/arm = {np.ceil(n):.0f}')
# correlates study: AUC 0.80 vs 0.5 with event rate ~50%
# Hanley-McNeil: SE(AUC) approx; find N total so that lower 95% bound of AUC 0.80 exceeds 0.6
def se_auc(A, n1, n2):
    Q1 = A / (2 - A); Q2 = 2 * A * A / (1 + A)
    return np.sqrt((A * (1 - A) + (n1 - 1) * (Q1 - A * A) + (n2 - 1) * (Q2 - A * A)) / (n1 * n2))
for N in range(20, 400, 10):
    n1 = n2 = N // 2
    if 0.80 - 1.96 * se_auc(0.80, n1, n2) > 0.60:
        print(f'correlates study: total N with ~50% events so that AUC 0.80 has lower 95% bound >0.60: N = {N}')
        break

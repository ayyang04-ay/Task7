"""Scan every per-animal vector in the workbook for exact duplication against every other vector.

A 'vector' is the ordered set of per-animal values for one group at one timepoint/day in one block.
We report pairs of vectors (from different blocks, or different groups/timepoints of the same block)
that share >=2 identical non-trivial values in the SAME position, or >=3 identical non-trivial values
in any position.  Trivial values (0, 1, 100, 14 and integer titres that lie on a 2-fold dilution
ladder) are excluded because they recur by design.
"""
import itertools, math
import pandas as pd
import psln_blocks as P

TRIVIAL = {0.0, 1.0, 100.0, 14.0}


def ladder(v):
    # HAI / neutralisation values on a 2-fold ladder from 10 or 15 or 30 are expected to recur
    for base in (5, 10, 15, 30, 60, 120):
        if v > 0 and abs(math.log2(v / base) - round(math.log2(v / base))) < 1e-9:
            return True
    return False


vecs = []
for bid, b in P.REG.items():
    if b['kind'] in ('survival',):
        continue
    df = P.extract(bid)
    if b['kind'] == 'values':
        for g, d in df.groupby('group', sort=False):
            vecs.append((bid, g, None, list(d['value']), list(d['cell'])))
    elif b['kind'] == 'timecourse':
        for (g, t), d in df.groupby(['group', 'time'], sort=False, dropna=False):
            vecs.append((bid, g, t, list(d['value']), list(d['cell'])))
    elif b['kind'] == 'weight':
        for (g, t), d in df.groupby(['group', 'day'], sort=False):
            d = d.dropna(subset=['value'])
            vecs.append((bid, g, t, list(d['value']), list(d['cell'])))

# S07-C has two columns with the same header; split by column
s07c = P.extract('S07-C')
vecs = [v for v in vecs if v[0] != 'S07-C']
for col in ['B', 'C']:
    d = s07c[s07c.cell.str.startswith(col)]
    vecs.append(('S07-C', f'col{col}', None, list(d['value']), list(d['cell'])))

# S09-A (log10) -> convert to linear fold for comparison with S01-A
s9 = P.extract_s09a()
for (blk, an, g), d in s9.groupby(['block', 'analyte', 'group'], sort=False):
    vecs.append((blk, g, an, [round(10 ** x, 2) for x in d['log10']], list(d['cell'])))


def nontriv(v, bid):
    if v in TRIVIAL:
        return False
    if float(v).is_integer() and ladder(v):
        return False
    return True


hits = []
for (a, b) in itertools.combinations(range(len(vecs)), 2):
    A, B = vecs[a], vecs[b]
    va = [round(x, 4) for x in A[3]]
    vb = [round(x, 4) for x in B[3]]
    # position-wise identical non-trivial
    pos = sum(1 for x, y in zip(va, vb) if x == y and nontriv(x, A[0]))
    # set overlap (multiset) non-trivial
    sa = [x for x in va if nontriv(x, A[0])]
    sb = [x for x in vb if nontriv(x, B[0])]
    ov = 0
    sb2 = list(sb)
    for x in sa:
        if x in sb2:
            ov += 1
            sb2.remove(x)
    if pos >= 2 or ov >= 3:
        hits.append(dict(blockA=A[0], groupA=A[1], timeA=A[2], blockB=B[0], groupB=B[1], timeB=B[2],
                         n_A=len(va), n_B=len(vb), same_position=pos, shared_values=ov,
                         A_vals=va, B_vals=vb, A_cells=f'{A[4][0]}..{A[4][-1]}' if A[4] else '',
                         B_cells=f'{B[4][0]}..{B[4][-1]}' if B[4] else ''))

H = pd.DataFrame(hits)
pd.set_option('display.width', 250, 'display.max_colwidth', 80, 'display.max_rows', 500)
if len(H):
    H = H.sort_values(['shared_values', 'same_position'], ascending=False)
    print(H[['blockA', 'groupA', 'timeA', 'blockB', 'groupB', 'timeB', 'same_position', 'shared_values', 'A_vals', 'B_vals']].to_string())
    H.to_csv('/tmp/outputs/tables/qa_duplicate_vectors.csv', index=False)
print(len(H), 'pairs flagged')

"""Can a shared decimal tail with different integer parts arise legitimately?
Percent weight = 100*w/w0.  If w and w0 are read from a balance at resolution r, then two values
with the same w0 differ by 100*r*k/w0.  For the tail to be preserved while the integer part changes by d,
we need 100*r*k/w0 = d exactly  ->  k = d*w0/(100 r) must be an integer.
We brute-force every baseline w0 in 15.00-45.00 g at r = 0.1 g and 0.01 g, find which (w, w0) reproduce
a printed value to the printed precision, and ask whether the partner value (same tail, different
integer part) is reachable from the SAME w0.  We test the whole ordered column pairs found in the
fingerprint scan.
"""
import numpy as np, openpyxl
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx', data_only=True)
def v(s, c): return wb[s][c].value

pairs = [  # (sheet, cell) pairs with shared tails, ordered by day, from qa_fraction_fingerprints.csv
    [('S08', 'I22'), ('S15', 'D54')], [('S08', 'I23'), ('S15', 'D55')], [('S08', 'I24'), ('S15', 'D56')],
    [('S08', 'I25'), ('S15', 'D57')], [('S08', 'I26'), ('S15', 'D58')],
    [('S08', 'J22'), ('S15', 'E54')], [('S08', 'J23'), ('S15', 'E55')], [('S08', 'J24'), ('S15', 'E56')],
    [('S08', 'J25'), ('S15', 'E57')], [('S08', 'J26'), ('S15', 'E58')],
    [('S08', 'K22'), ('S15', 'C54')], [('S08', 'K23'), ('S15', 'C55')], [('S08', 'K24'), ('S15', 'C56')],
    [('S08', 'K25'), ('S15', 'C57')], [('S08', 'K26'), ('S15', 'C58')],
    [('S08', 'G22'), ('S15', 'B54')], [('S08', 'G23'), ('S15', 'B55')], [('S08', 'G24'), ('S15', 'B56')], [('S08', 'G25'), ('S15', 'B57')],
    [('S15', 'J4'), ('S15', 'J84')], [('S15', 'J4'), ('S15', 'J94')], [('S15', 'J4'), ('S15', 'Q84')],
    [('S15', 'K4'), ('S15', 'K84')], [('S15', 'J5'), ('S15', 'J85')], [('S15', 'K5'), ('S15', 'K85')],
    [('S08', 'I24'), ('S08', 'I25')],
]

def decimals(x):
    s = repr(float(x)); return len(s.split('.')[1])

def solutions(val, r):
    """all (w0, w) on grid r with 100*w/w0 == val at printed precision"""
    nd = decimals(val); tol = 0.5 * 10 ** (-nd) + 1e-12
    out = []
    for w0 in np.round(np.arange(15.0, 45.0 + r / 2, r), 4):
        w = val * w0 / 100.0
        wq = round(w / r) * r
        if abs(100 * wq / w0 - val) <= tol:
            out.append((round(w0, 3), round(wq, 3)))
    return out

for r in (0.1, 0.01):
    print(f'===== balance resolution r = {r} g')
    for (s1, c1), (s2, c2) in pairs:
        a, b = v(s1, c1), v(s2, c2)
        sa, sb = solutions(a, r), solutions(b, r)
        w0a = {x[0] for x in sa}; w0b = {x[0] for x in sb}
        common = sorted(w0a & w0b)
        print(f'{s1}!{c1}={a!r:<14} {s2}!{c2}={b!r:<14}  #w0 solutions: {len(w0a):3d} / {len(w0b):3d}   shared w0: {common[:6]}')

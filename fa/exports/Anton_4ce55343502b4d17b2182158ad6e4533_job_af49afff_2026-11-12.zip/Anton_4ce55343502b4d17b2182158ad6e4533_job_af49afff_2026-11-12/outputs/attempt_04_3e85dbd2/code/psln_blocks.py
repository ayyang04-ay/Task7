"""
PSLN-344 dataset parser.

Every value extracted from adjuvant_program_dataset.xlsx is returned with its
sheet and cell coordinate so that every downstream number can be traced back to
the workbook.  Block layouts were transcribed from adjuvant_program_annotation.pdf
and verified against the workbook cell-by-cell (see 00_block_registry.csv).

Block kinds
  values     : one or more groups, each a list of per-animal values (one row or one column range)
  timecourse : groups x timepoints, per-animal values per timepoint
  survival   : one row per animal; a 'days' column and one indicator column per group (1=event, 0=censored)
  weight     : per-animal % of day-0 body weight, one row per day
"""
import openpyxl
from openpyxl.utils import column_index_from_string as cidx, get_column_letter as cl
import pandas as pd

XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
_wb = None


def wb():
    global _wb
    if _wb is None:
        _wb = openpyxl.load_workbook(XLSX, data_only=True)
    return _wb


def cell(sheet, coord):
    return wb()[sheet][coord].value


def colrange(a, b):
    return [cl(i) for i in range(cidx(a), cidx(b) + 1)]


# ----------------------------------------------------------------------------------
# Registry.  Each entry: block id -> dict(kind, sheet, spec..., meta)
# Group names are READ FROM THE WORKBOOK header cells (never typed in by hand);
# the registry only says where the header cell and the data cells are.
# ----------------------------------------------------------------------------------
REG = {}


def values_cols(bid, sheet, header_row, cols, rows, **meta):
    """Groups laid out as columns; header (group name) in header_row; values in rows."""
    REG[bid] = dict(kind='values', sheet=sheet, layout='cols', header_row=header_row,
                    cols=cols, rows=rows, **meta)


def values_rows(bid, sheet, name_col, rows, vcols, **meta):
    """Groups laid out as rows; group name in name_col; values in vcols."""
    REG[bid] = dict(kind='values', sheet=sheet, layout='rows', name_col=name_col,
                    rows=rows, vcols=vcols, **meta)


def timecourse(bid, sheet, header_row, groups, rows, time_col, **meta):
    """groups: list of (header_cell_col, [value cols]); rows: data rows; time in time_col"""
    REG[bid] = dict(kind='timecourse', sheet=sheet, header_row=header_row, groups=groups,
                    rows=rows, time_col=time_col, **meta)


def survival(bid, sheet, header_row, day_col, gcols, rows, **meta):
    REG[bid] = dict(kind='survival', sheet=sheet, header_row=header_row, day_col=day_col,
                    gcols=gcols, rows=rows, **meta)


def weight(bid, sheet, header_row, day_col, groups, rows, **meta):
    REG[bid] = dict(kind='weight', sheet=sheet, header_row=header_row, day_col=day_col,
                    groups=groups, rows=rows, **meta)


R = lambda a, b: list(range(a, b + 1))

# ---------------- S01 ----------------
values_rows('S01-A 16h', 'S01', 'A', R(3, 10), colrange('B', 'F'), measurand='Lung Ifnb1 (qRT-PCR, fold vs untreated)', unit='fold', time='16 h', stated_n=5, scale='linear')
values_rows('S01-A 72h', 'S01', 'G', R(3, 10), colrange('H', 'L'), measurand='Lung Ifnb1 (qRT-PCR, fold vs untreated)', unit='fold', time='72 h', stated_n=5, scale='linear')
values_rows('S01-B', 'S01', 'A', R(14, 17), colrange('B', 'F'), measurand='AEC SRB+ (%)', unit='%', time='16 h', stated_n=5)
values_rows('S01-C', 'S01', 'A', R(20, 21), colrange('B', 'E'), measurand='AM DiD+ (%) WT vs Sftpa1/Sftpd KO', unit='%', time='16 h', stated_n=4)
timecourse('S01-D', 'S01', 23, [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P')), ('Q', colrange('Q', 'U'))], R(24, 28), 'A', measurand='Lung monocytes CD11b+Ly6C+ (%)', unit='%', stated_n=5)
timecourse('S01-E', 'S01', 29, [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P')), ('Q', colrange('Q', 'U')), ('V', colrange('V', 'Z'))], R(30, 34), 'A', measurand='Lung CD11b+ DC (%)', unit='%', stated_n=5)
timecourse('S01-F', 'S01', 35, [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P')), ('Q', colrange('Q', 'U')), ('V', colrange('V', 'Z'))], [36], None, measurand='Lung cDC1 (%)', unit='%', time='72 h', stated_n=5)
timecourse('S01-G', 'S01', 37, [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P')), ('Q', colrange('Q', 'U')), ('V', colrange('V', 'Z'))], [38], None, measurand='Lung cDC2 (%)', unit='%', time='72 h', stated_n=5)

# ---------------- S02 ----------------
values_cols('S02-A', 'S02', 2, colrange('A', 'D'), R(3, 7), measurand='Lung migratory CCR7+ CD11b+ DC (%)', unit='%', time='72 h', stated_n=5)
values_cols('S02-B', 'S02', 2, colrange('F', 'I'), R(3, 7), measurand='MLN CD11b+CD103- DC (%)', unit='%', time='72 h', stated_n=5)
values_cols('S02-C', 'S02', 2, colrange('K', 'O'), R(3, 7), measurand='MLN DC AF647-OVA+ (%)', unit='%', time='36 h', stated_n=5)
values_cols('S02-D CD40', 'S02', 9, colrange('A', 'D'), R(10, 14), measurand='MLN CD11b+ DC CD40+ (%)', unit='%', time='day 3', stated_n=5)
values_cols('S02-D CD86', 'S02', 9, colrange('F', 'I'), R(10, 14), measurand='MLN CD11b+ DC CD86+ (%)', unit='%', time='day 3', stated_n=5)
values_cols('S02-E', 'S02', 9, colrange('K', 'O'), R(10, 14), measurand='OT-I proliferation with sorted MLN CD11b+ DC (%)', unit='%', time='DC 72 h; read day 3', stated_n=5)
timecourse('S02-F', 'S02', 16, [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P'))], R(17, 19), 'A', measurand='Lung Gm-csf (fold)', unit='fold', stated_n=5)
values_cols('S02-G', 'S02', 21, colrange('B', 'D'), R(22, 26), measurand='Lung Ly6C+CD11c+MHCII+ moDC-like (%) +/- rGM-CSF', unit='%', time='day 5', stated_n=5)
values_cols('S02-H', 'S02', 29, colrange('B', 'F'), R(30, 34), measurand='CD45.2+ moDC (%) in BM chimeras (WT vs Ifnar-/- donor)', unit='%', time='day 3', stated_n=5)
values_cols('S02-I', 'S02', 29, colrange('H', 'I'), R(30, 34), measurand='Lung GZMB+ CD8 (%) +/- CCR2 antagonist (young)', unit='%', time='day 5', stated_n=5)

# ---------------- S03 ----------------
values_cols('S03-A', 'S03', 2, colrange('A', 'E'), R(3, 7), measurand='Serum IgG anti-CA09 H1N1 (endpoint titre)', unit='titre', time='day 14', stated_n=5, scale='titre')
values_cols('S03-B', 'S03', 2, colrange('G', 'I'), R(3, 7), measurand='IgG2a/IgG1 ratio anti-CA09 (as printed)', unit='ratio', time='day 14', stated_n=5)
values_cols('S03-C', 'S03', 2, colrange('K', 'O'), R(3, 7), measurand='HAI titre CA09 H1N1', unit='titre', time='day 14', stated_n=5, scale='titre', lod=10)
values_cols('S03-D', 'S03', 2, colrange('Q', 'U'), R(3, 7), measurand='Neutralising titre CA09 H1N1', unit='titre', time='day 14', stated_n=5, scale='titre')
values_cols('S03-E', 'S03', 9, colrange('A', 'E'), R(10, 14), measurand='Serum IgG anti-Aichi H3N2 (endpoint titre)', unit='titre', time='day 14', stated_n=5, scale='titre')
values_cols('S03-F', 'S03', 9, colrange('G', 'I'), R(10, 14), measurand='IgG2a/IgG1 ratio anti-Aichi (as printed)', unit='ratio', time='day 14', stated_n=5)
values_cols('S03-G', 'S03', 9, colrange('K', 'O'), R(10, 14), measurand='HAI titre Aichi H3N2', unit='titre', time='day 14', stated_n=5, scale='titre', lod=10)
values_cols('S03-H', 'S03', 9, colrange('Q', 'U'), R(10, 14), measurand='Neutralising titre Aichi H3N2', unit='titre', time='day 14', stated_n=5, scale='titre')
survival('S03-I', 'S03', 16, 'A', colrange('B', 'F'), R(17, 51), challenge='10x mLD50 CA09 H1N1 (homologous), d14 post-vaccination', vaccine='bivalent', strain='BALB/c aged', follow=14, stated_n=7)
survival('S03-J', 'S03', 16, 'G', colrange('H', 'J'), R(17, 46), challenge='wild-type VN04 H5N1, d2 post-vaccination (rgH5N1 vaccine)', vaccine='rgH5N1', strain='BALB/c aged', follow=22, stated_n=9)
values_cols('S03-K', 'S03', 16, colrange('L', 'O'), R(17, 21), measurand='MLN GC B cells CXCR5+GL7+ (%)', unit='%', time='day 7', stated_n=5)
values_rows('S03-L Aicda', 'S03', 'K', R(26, 28), colrange('L', 'N'), measurand='MLN B-cell Aicda (fold)', unit='fold', time='day 5', stated_n=3)
values_rows('S03-L E47', 'S03', 'K', R(26, 28), colrange('O', 'Q'), measurand='MLN B-cell E47 (fold)', unit='fold', time='day 5', stated_n=3)

# ---------------- S04 ----------------
values_rows('S04-A ICOSlo', 'S04', 'A', R(2, 5), colrange('B', 'F'), measurand='MLN Tfh CXCR5+PD1+ ICOS-low (%)', unit='%', time='day 7', stated_n=5)
values_rows('S04-A ICOShi', 'S04', 'A', R(2, 5), colrange('G', 'K'), measurand='MLN Tfh CXCR5+PD1+ ICOS-high (%)', unit='%', time='day 7', stated_n=5)
values_cols('S04-B Foxp3', 'S04', 7, colrange('A', 'D'), R(8, 12), measurand='MLN Tfr Foxp3+ in CXCR5+ICOShi (%)', unit='%', time='day 7', stated_n=5)
values_cols('S04-B Tfh:Tfr', 'S04', 14, colrange('A', 'D'), R(15, 19), measurand='Tfh:Tfr ratio (as printed)', unit='ratio', time='day 7', stated_n=5)
values_cols('S04-C', 'S04', 21, colrange('A', 'D'), R(22, 26), measurand='MLN Tfr Foxp3+ (%)', unit='%', time='day 30', stated_n=5)
values_cols('S04-D', 'S04', 28, colrange('A', 'D'), R(29, 31), measurand='Lung Treg CD4+Foxp3+ (%)', unit='%', time='day 7', stated_n=3)

# ---------------- S05 ----------------
timecourse('S05-A', 'S05', 2, [('B', ['B', 'C']), ('E', ['E', 'F']), ('H', ['H', 'I'])], R(3, 5), 'A', measurand='Lung NP366 tetramer+ CD8 (%)', unit='%', stated_n=3)
timecourse('S05-B', 'S05', 7, [('B', ['B', 'C']), ('E', ['E', 'F']), ('H', ['H', 'I'])], R(8, 10), 'A', measurand='MLN NP366 tetramer+ CD8 (%)', unit='%', stated_n=3)
values_cols('S05-C', 'S05', 12, colrange('A', 'D'), R(13, 15), measurand='OT-I proliferation in vivo +/- PTX (%)', unit='%', time='day 4', stated_n=3)
values_cols('S05-D', 'S05', 18, colrange('A', 'D'), R(19, 23), measurand='Lung Ki-67+ CD8 (%)', unit='%', time='day 3', stated_n=5)
values_cols('S05-E', 'S05', 25, colrange('A', 'D'), R(26, 30), measurand='Lung GZMB+ CD8 (%)', unit='%', time='day 3', stated_n=5)
values_cols('S05-F', 'S05', 32, colrange('A', 'D'), R(33, 37), measurand='MLN IFN-g+ CD8 (%) rgH5N1 restim', unit='%', time='day 14', stated_n=5)
values_cols('S05-G', 'S05', 39, colrange('A', 'D'), R(40, 44), measurand='MLN IFN-g+ CD8 (%) rgH5N1 restim', unit='%', time='day 60', stated_n=5)
values_cols('S05-H', 'S05', 46, colrange('A', 'D'), R(47, 51), measurand='MLN GZMB+ CD8 (%)', unit='%', time='day 60', stated_n=5)
values_cols('S05-I', 'S05', 53, colrange('A', 'D'), R(54, 58), measurand='Lung TRM CD69+CD103+ CD8 (%)', unit='%', time='day 25', stated_n=5)

# ---------------- S06 (survival) ----------------
survival('S06-A', 'S06', 2, 'A', colrange('B', 'E'), R(3, 30), challenge='5x mLD50 PR8 H1N1, d14', vaccine='Aichi H3N2', strain='BALB/c aged', follow=14, stated_n=7)
survival('S06-B', 'S06', 2, 'G', colrange('H', 'K'), R(3, 30), challenge='5x mLD50 PR8 H1N1, d3', vaccine='Aichi H3N2', strain='BALB/c aged', follow=14, stated_n=7)
survival('S06-C', 'S06', 2, 'M', colrange('N', 'Q'), R(3, 30), challenge='5x mLD50 rgH5N1, d14', vaccine='bivalent', strain='BALB/c aged', follow=14, stated_n=7)
survival('S06-D', 'S06', 33, 'A', colrange('B', 'E'), R(34, 68), challenge='5x mLD50 rgH5N1, d3', vaccine='bivalent', strain='BALB/c aged', follow=14, stated_n=7)
survival('S06-E', 'S06', 33, 'G', colrange('H', 'L'), R(34, 68), challenge='5x mLD50 PR8 H1N1, d60', vaccine='Aichi H3N2', strain='BALB/c aged', follow=14, stated_n=7)
survival('S06-F', 'S06', 33, 'M', colrange('N', 'R'), R(34, 68), challenge='5x mLD50 rgH5N1, d60', vaccine='bivalent', strain='BALB/c aged', follow=14, stated_n=7)
survival('S06-G', 'S06', 70, 'A', colrange('B', 'F'), R(71, 105), challenge='5x mLD50 Perth H3N2, d60', vaccine='CA09 H1N1', strain='BALB/c aged', follow=14, stated_n=7)
survival('S06-E(imprint)', 'S06', 70, 'G', colrange('H', 'K'), R(71, 105), challenge='5x LD50 PR8 H1N1 after PR8 imprinting (14-mo at vaccination)', vaccine='bivalent', strain='BALB/c 14 mo', follow=14, stated_n=7)
survival('S06-F(imprint)', 'S06', 70, 'M', colrange('N', 'Q'), R(71, 105), challenge='5x LD50 Perth H3N2 d14 after PR8 imprinting (14-mo at vaccination)', vaccine='bivalent', strain='BALB/c 14 mo', follow=14, stated_n=7)

# ---------------- S07 ----------------
timecourse('S07-A', 'S07', 2, [('B', colrange('B', 'D')), ('E', colrange('E', 'G'))], R(3, 7), 'A', measurand='Lung Ly6C+CCR2+ macrophages (x10^5 cells)', unit='x1e5 cells', stated_n=3)
values_cols('S07-B mono', 'S07', 9, colrange('B', 'C'), R(10, 14), measurand='Lung CD11b+Ly6C+ monocytes (%) +/- CCR2 antagonist', unit='%', time='not stated', stated_n=5)
values_cols('S07-B Ly6C+Mph', 'S07', 9, colrange('E', 'F'), R(10, 14), measurand='Lung Ly6C+ macrophages (%) +/- CCR2 antagonist', unit='%', time='not stated', stated_n=5)
values_cols('S07-C', 'S07', 15, colrange('B', 'C'), R(16, 20), measurand='Lung Treg (%) after macrophage transfer', unit='%', time='day 4 post transfer', stated_n=5)

# ---------------- S08 ----------------
timecourse('S08-A', 'S08', 2, [('B', colrange('B', 'D')), ('E', colrange('E', 'G')), ('H', colrange('H', 'J')), ('K', colrange('K', 'M'))], R(3, 7), 'A', measurand='Lung Ifnb1 (fold) dose-response, 1-40 ug', unit='fold', stated_n=3)
timecourse('S08-B', 'S08', 10, [('A', colrange('A', 'C')), ('D', colrange('D', 'F')), ('G', colrange('G', 'I')), ('J', colrange('J', 'L')), ('M', colrange('M', 'O'))], [11], None, measurand='Encapsulation efficiency (%)', unit='%', stated_n=3)
values_cols('S08-C', 'S08', 13, colrange('A', 'D'), R(14, 18), measurand='AEC SRB+ (%) PSLN vs PSLN-344', unit='%', time='16 h', stated_n=5)
weight('S08-D', 'S08', 20, 'A', [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P')), ('Q', colrange('Q', 'U')), ('V', colrange('V', 'Z')), ('AA', colrange('AA', 'AE'))], R(21, 26), context='post-vaccination reactogenicity (no challenge)', stated_n=5)

# ---------------- S09 ----------------
# S09-A handled separately (analyte x group matrix)
survival('S09-B', 'S09', 11, 'A', colrange('B', 'D'), R(12, 35), challenge='5x mLD50 PR8 H1N1, d21', vaccine='Aichi H3N2', strain='BALB/c young', follow=14, stated_n=8)
weight('S09-C', 'S09', 11, 'F', [('G', colrange('G', 'N')), ('O', colrange('O', 'V')), ('W', colrange('W', 'AD'))], R(12, 19), pairs='S09-B', stated_n=8)
survival('S09-D', 'S09', 38, 'A', colrange('B', 'D'), R(39, 62), challenge='5x mLD50 Perth H3N2, d21', vaccine='CA09 H1N1', strain='BALB/c young', follow=14, stated_n=8)
weight('S09-E', 'S09', 38, 'F', [('G', colrange('G', 'N')), ('O', colrange('O', 'V')), ('W', colrange('W', 'AD'))], R(39, 46), pairs='S09-D', stated_n=8)
survival('S09-F', 'S09', 65, 'A', colrange('B', 'D'), R(66, 88), challenge='5x mLD50 VN04 rgH5N1, d180', vaccine='bivalent', strain='BALB/c young', follow=14, stated_n=8)
weight('S09-G', 'S09', 65, 'F', [('G', colrange('G', 'N')), ('O', colrange('O', 'V')), ('W', colrange('W', 'AD'))], R(66, 73), pairs='S09-F', stated_n=8)

# ---------------- S10 ----------------
values_cols('S10-A Ifnb1', 'S10', 2, colrange('A', 'D'), R(3, 7), measurand='CNS Ifnb1 (fold)', unit='fold', time='36 h', stated_n=5)
values_cols('S10-A Tnf', 'S10', 2, colrange('F', 'I'), R(3, 7), measurand='CNS Tnf (fold)', unit='fold', time='36 h', stated_n=5)
values_cols('S10-A Isg15', 'S10', 2, colrange('K', 'N'), R(3, 7), measurand='CNS Isg15 (fold)', unit='fold', time='36 h', stated_n=5)

# ---------------- S11 ----------------
timecourse('S11-A', 'S11', 2, [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P')), ('Q', colrange('Q', 'U'))], R(3, 7), 'A', measurand='Lung alveolar macrophages (%)', unit='%', stated_n=5)
timecourse('S11-B', 'S11', 9, [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P')), ('Q', colrange('Q', 'U'))], R(10, 14), 'A', measurand='Lung neutrophils (%)', unit='%', stated_n=5)
values_cols('S11-C', 'S11', 16, colrange('A', 'B'), R(17, 21), measurand='Lung recruited monocytes (%) +/- carbenoxolone', unit='%', time='day 3', stated_n=5)
timecourse('S11-D', 'S11', 23, [('B', colrange('B', 'F')), ('G', colrange('G', 'K')), ('L', colrange('L', 'P')), ('Q', colrange('Q', 'U'))], R(24, 28), 'A', measurand='Lung NK cells (%)', unit='%', stated_n=5)
values_cols('S11-E', 'S11', 30, colrange('A', 'D'), R(31, 35), measurand='Lung CD206+ macrophages (%)', unit='%', time='not stated', stated_n=5)

# ---------------- S12 ----------------
values_cols('S12-A', 'S12', 2, colrange('A', 'B'), R(3, 5), measurand='CD45.2+ CD11b+Ly6C+ monocytes (%) WT vs Ifnar-/- BM (young)', unit='%', time='day 3', stated_n=3)

# ---------------- S13 ----------------
values_cols('S13-A', 'S13', 2, colrange('A', 'C'), R(3, 7), measurand='Serum IgG2a anti-CA09', unit='titre', time='day 14', stated_n=5, scale='titre')
values_cols('S13-B', 'S13', 2, colrange('E', 'G'), R(3, 7), measurand='Serum IgG1 anti-CA09', unit='titre', time='day 14', stated_n=5, scale='titre')
values_cols('S13-C', 'S13', 2, colrange('I', 'K'), R(3, 7), measurand='Serum IgG2a anti-Aichi', unit='titre', time='day 14', stated_n=5, scale='titre')
values_cols('S13-D', 'S13', 2, colrange('M', 'O'), R(3, 7), measurand='Serum IgG1 anti-Aichi', unit='titre', time='day 14', stated_n=5, scale='titre')
survival('S13-E', 'S13', 2, 'R', colrange('S', 'V'), R(3, 30), challenge='10x mLD50 CA09 H1N1, d14', vaccine='bivalent', strain='BALB/c young', follow=14, stated_n=5)
weight('S13-F', 'S13', 32, 'A', [('B', colrange('B', 'H')), ('I', colrange('I', 'O')), ('P', colrange('P', 'V')), ('W', colrange('W', 'AC')), ('AD', colrange('AD', 'AJ'))], R(33, 40), pairs='S03-I', stated_n=7)
weight('S13-G', 'S13', 42, 'A', [('B', colrange('B', 'K')), ('L', colrange('L', 'U')), ('V', colrange('V', 'AE'))], R(43, 50), pairs='S03-J', stated_n=10)
values_cols('S13-H', 'S13', 52, colrange('A', 'D'), R(53, 57), measurand='MLN IgG+ of B220+ (%)', unit='%', time='not stated', stated_n=5)
values_cols('S13-I', 'S13', 52, colrange('F', 'J'), R(53, 57), measurand='Serum IgG anti-CA09 post-boost', unit='titre', time='day 28 (boost d14)', stated_n=5, scale='titre')
values_cols('S13-J', 'S13', 52, colrange('L', 'P'), R(53, 57), measurand='Serum IgG anti-Aichi post-boost', unit='titre', time='day 28 (boost d14)', stated_n=5, scale='titre')

# ---------------- S14 ----------------
values_cols('S14-A H1N1', 'S14', 2, colrange('A', 'D'), R(3, 7), measurand='MLN IFN-g+ CD8 (%) CA09 restim', unit='%', time='not stated', stated_n=5)
values_cols('S14-A H3N2', 'S14', 2, colrange('F', 'I'), R(3, 7), measurand='MLN IFN-g+ CD8 (%) Aichi restim', unit='%', time='not stated', stated_n=5)

# ---------------- S15 ----------------
_g4 = [('B', colrange('B', 'H')), ('I', colrange('I', 'O')), ('P', colrange('P', 'V')), ('W', colrange('W', 'AC'))]
_g5 = _g4 + [('AD', colrange('AD', 'AJ'))]
weight('S15-A', 'S15', 2, 'A', _g4, R(3, 10), pairs='S06-A', stated_n=7)
weight('S15-B', 'S15', 12, 'A', _g4, R(13, 20), pairs='S06-B', stated_n=7)
weight('S15-C', 'S15', 22, 'A', _g4, R(23, 30), pairs='S06-C', stated_n=7)
weight('S15-D', 'S15', 32, 'A', _g4, R(33, 40), pairs='S06-D', stated_n=7)
weight('S15-E', 'S15', 42, 'A', _g5, R(43, 50), pairs='S06-E', stated_n=7)
weight('S15-F', 'S15', 52, 'A', _g5, R(53, 60), pairs='S06-F', stated_n=7)
weight('S15-G', 'S15', 62, 'A', _g5, R(63, 70), pairs='S06-G', stated_n=7)
survival('S15-H', 'S15', 72, 'A', colrange('B', 'D'), R(73, 93), challenge='5x mLD50 VN04 rgH5N1, d3; vaccine alone vs adjuvant alone vs both', vaccine='bivalent', strain='BALB/c aged', follow=14, stated_n=7)
weight('S15-I', 'S15', 71, 'H', [('I', colrange('I', 'O')), ('P', colrange('P', 'V')), ('W', colrange('W', 'AC'))], R(72, 79), pairs='S15-H', stated_n=7)
weight('S15-J', 'S15', 82, 'H', [('I', colrange('I', 'O')), ('P', colrange('P', 'V')), ('W', colrange('W', 'AC')), ('AD', colrange('AD', 'AJ'))], R(83, 90), pairs='S06-E(imprint)', stated_n=7)
weight('S15-K', 'S15', 92, 'H', [('I', colrange('I', 'O')), ('P', colrange('P', 'V')), ('W', colrange('W', 'AC')), ('AD', colrange('AD', 'AJ'))], R(93, 100), pairs='S06-F(imprint)', stated_n=7)
survival('S15-L', 'S15', 102, 'A', colrange('B', 'E'), R(103, 130), challenge='not stated in annotation (aged C57BL/6, bivalent vaccine)', vaccine='bivalent', strain='C57BL/6 aged 20 mo', follow=14, stated_n=7)
weight('S15-M', 'S15', 102, 'H', [('I', colrange('I', 'O')), ('P', colrange('P', 'V')), ('W', colrange('W', 'AC')), ('AD', colrange('AD', 'AJ'))], R(103, 110), pairs='S15-L', stated_n=7)
survival('S15-N', 'S15', 133, 'A', colrange('B', 'E'), R(134, 161), challenge='not stated in annotation (aged Swiss Webster, bivalent vaccine)', vaccine='bivalent', strain='Swiss Webster aged 20 mo', follow=14, stated_n=7)
weight('S15-O', 'S15', 133, 'H', [('I', colrange('I', 'O')), ('P', colrange('P', 'V')), ('W', colrange('W', 'AC')), ('AD', colrange('AD', 'AJ'))], R(134, 141), pairs='S15-N', stated_n=7)


def _num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def norm_group(g):
    if g is None:
        return None
    g = str(g).strip().replace('\u00ef', 'i').replace('Naïve', 'Naive').replace('Naïve', 'Naive')
    g = g.replace('PSLN-212Y', 'PSLN-212(Y)').replace('PSLN-344Y', 'PSLN-344(Y)').replace('(y)', '(Y)')
    return g


def extract(bid):
    """Return tidy DataFrame for a block with provenance."""
    b = REG[bid]
    sh = b['sheet']
    out = []
    if b['kind'] == 'values' and b['layout'] == 'cols':
        for c in b['cols']:
            g = norm_group(cell(sh, f"{c}{b['header_row']}"))
            for r in b['rows']:
                v = cell(sh, f'{c}{r}')
                if _num(v):
                    out.append(dict(block=bid, sheet=sh, group=g, value=float(v), cell=f'{c}{r}'))
    elif b['kind'] == 'values' and b['layout'] == 'rows':
        for r in b['rows']:
            g = norm_group(cell(sh, f"{b['name_col']}{r}"))
            for c in b['vcols']:
                v = cell(sh, f'{c}{r}')
                if _num(v):
                    out.append(dict(block=bid, sheet=sh, group=g, value=float(v), cell=f'{c}{r}'))
    elif b['kind'] == 'timecourse':
        for hc, vcols in b['groups']:
            g = norm_group(cell(sh, f"{hc}{b['header_row']}"))
            for r in b['rows']:
                t = cell(sh, f"{b['time_col']}{r}") if b['time_col'] else None
                for k, c in enumerate(vcols):
                    v = cell(sh, f'{c}{r}')
                    if _num(v):
                        out.append(dict(block=bid, sheet=sh, group=g, time=t, rep=k + 1, value=float(v), cell=f'{c}{r}'))
    elif b['kind'] == 'survival':
        for r in b['rows']:
            d = cell(sh, f"{b['day_col']}{r}")
            for c in b['gcols']:
                v = cell(sh, f'{c}{r}')
                if _num(v):
                    g = norm_group(cell(sh, f"{c}{b['header_row']}"))
                    out.append(dict(block=bid, sheet=sh, group=g, day=(float(d) if _num(d) else None),
                                    event=int(v), cell=f'{c}{r}', day_cell=f"{b['day_col']}{r}"))
    elif b['kind'] == 'weight':
        for hc, vcols in b['groups']:
            g = norm_group(cell(sh, f"{hc}{b['header_row']}"))
            for k, c in enumerate(vcols):
                for r in b['rows']:
                    d = cell(sh, f"{b['day_col']}{r}")
                    v = cell(sh, f'{c}{r}')
                    out.append(dict(block=bid, sheet=sh, group=g, animal=k + 1, day=d,
                                    value=(float(v) if _num(v) else None), cell=f'{c}{r}'))
    return pd.DataFrame(out)


def extract_s09a():
    """S09-A: two analyte x group matrices (log10 fold). Left = cols A..V, right = cols X..AS."""
    sh = 'S09'
    out = []
    for side, namecol, hdr in [('left', 'A', ['B', 'E', 'H', 'K', 'N', 'Q', 'T']),
                                ('right', 'X', ['Y', 'AB', 'AE', 'AH', 'AK', 'AN', 'AQ'])]:
        label = cell(sh, 'A1') if side == 'left' else cell(sh, 'X1')
        for r in range(3, 10):
            analyte = cell(sh, f'{namecol}{r}')
            for h in hdr:
                g = norm_group(cell(sh, f'{h}2'))
                for k in range(3):
                    c = cl(cidx(h) + k)
                    v = cell(sh, f'{c}{r}')
                    if _num(v):
                        out.append(dict(block=f'S09-A {side}', label=label, sheet=sh, analyte=analyte, group=g,
                                        rep=k + 1, log10=float(v), cell=f'{c}{r}'))
    return pd.DataFrame(out)


def extract_s08_unlabelled():
    sh = 'S08'
    out = []
    for r in range(89, 102):
        for c in ['A', 'B', 'C', 'D', 'E']:
            v = cell(sh, f'{c}{r}')
            if v is not None:
                out.append(dict(cell=f'{c}{r}', value=v))
    return pd.DataFrame(out)


if __name__ == '__main__':
    rows = []
    for bid, b in REG.items():
        df = extract(bid)
        groups = list(dict.fromkeys(df['group'])) if len(df) else []
        rows.append(dict(block=bid, sheet=b['sheet'], kind=b['kind'], stated_n=b.get('stated_n'),
                         groups=' | '.join(map(str, groups)), n_values=len(df)))
    reg = pd.DataFrame(rows)
    pd.set_option('display.width', 250, 'display.max_colwidth', 120, 'display.max_rows', 500)
    print(reg)

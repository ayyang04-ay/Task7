"""Survival analyses.

Reduction (stated for the committee):
  * Each survival block holds one row per animal: elapsed days + event indicator (1 = death, 0 = alive/censored).
  * Survivors = animals with event 0.  Survival % = survivors / animals.
  * Per experiment: two-sided Fisher exact test on survivors vs deaths (PSLN-344 vs comparator);
    log-rank test on time to death (statsmodels survdiff); risk difference in survival with Newcombe
    (Wilson-score) 95% CI.
  * Pooled across experiments: Mantel-Haenszel risk difference (stratified by experiment) with
    Greenland-Robins variance, and a stratified log-rank test (strata = experiment).
  * Integrity tiers (from qa_* scripts) define sensitivity subsets.
"""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.duration.survfunc import survdiff
from statsmodels.stats.proportion import proportion_confint
import psln_blocks as P

AGED = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N']
IMPRINT = ['S06-E(imprint)', 'S06-F(imprint)']
YOUNG = ['S09-B', 'S09-D', 'S09-F', 'S13-E']

# integrity tier per survival experiment (see qa_* outputs; documented in report section 3)
TIER = {
    'S06-B': 'clean',
    'S06-D': 'T1 survival record duplicated (=S06-C)', 'S06-C': 'T1 survival record duplicated (=S06-D)',
    'S03-I': 'T1 group identities conflict with weight record S13-F', 'S03-J': 'T1 group identities conflict with S13-G; n conflict; missing day',
    'S06-A': 'T2 weight record S15-A shares copied values with S15-M',
    'S06-F': 'T2 weight record S15-F = integer-edited copy of S08-D',
    'S15-L': 'T2 weight record S15-M copied from S15-A/S09-E',
    'S15-N': 'T2 weight record S15-O shares copied tails with S15-M',
    'S15-H': 'T2 weight record S15-I = copy of S15-C',
    'S06-E(imprint)': 'T2 weight record S15-J shares copied tails', 'S06-F(imprint)': 'T2 weight record S15-K shares copied tails',
    'S06-E': 'T2 weight record S15-E shares edited decimal tails with S15-F/S08-D (F45, C47); death counts disagree (PSLN-344 2 vs 1)',
    'S06-G': 'T3 survival/weight death counts disagree (PSLN-344 3 vs 2)',
    'S09-B': 'T2 weight record S09-C day-12 row duplicated across groups', 'S09-D': 'T2 weight record S09-E copied into S15-M',
    'S09-F': 'T3 Sham n differs between survival (7) and weights (8)', 'S13-E': 'T3 stated n=5 vs 7 observed',
}


def wilson(k, n):
    lo, hi = proportion_confint(k, n, method='wilson')
    return lo, hi


def newcombe_rd(k1, n1, k2, n2):
    p1, p2 = k1 / n1, k2 / n2
    l1, u1 = wilson(k1, n1); l2, u2 = wilson(k2, n2)
    d = p1 - p2
    lo = d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2)
    hi = d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)
    return d, lo, hi


def logrank(df, g1, g2, strata=None):
    d = df[df.group.isin([g1, g2])].dropna(subset=['day'])
    if d.event.sum() == 0:
        return np.nan
    try:
        if strata is None:
            chi2, p = survdiff(d.day.values, d.event.values, (d.group == g1).astype(int).values)
        else:
            chi2, p = survdiff(d.day.values, d.event.values, (d.group == g1).astype(int).values, strata=d[strata].values)
        return p
    except Exception:
        return np.nan


def group_summary(df, exp):
    out = []
    for g, d in df.groupby('group', sort=False):
        n = len(d); surv = int((d.event == 0).sum())
        lo, hi = wilson(surv, n)
        dd = d[d.event == 1].day.dropna()
        out.append(dict(experiment=exp, group=g, n=n, survivors=surv, deaths=n - surv,
                        survival_pct=100 * surv / n, wilson_lo=100 * lo, wilson_hi=100 * hi,
                        median_day_death=(float(np.median(dd)) if len(dd) else np.nan),
                        cells=f"{d.cell.iloc[0]}..{d.cell.iloc[-1]}"))
    return out


def compare(df, exp, g1, g2):
    a = df[df.group == g1]; b = df[df.group == g2]
    if len(a) == 0 or len(b) == 0:
        return None
    k1, n1 = int((a.event == 0).sum()), len(a)
    k2, n2 = int((b.event == 0).sum()), len(b)
    _, p_f = stats.fisher_exact([[k1, n1 - k1], [k2, n2 - k2]])
    rd, lo, hi = newcombe_rd(k1, n1, k2, n2)
    return dict(experiment=exp, test=f'{g1} vs {g2}', surv1=f'{k1}/{n1}', surv2=f'{k2}/{n2}',
                risk_diff_pct=100 * rd, rd_lo=100 * lo, rd_hi=100 * hi, fisher_p=p_f, logrank_p=logrank(df, g1, g2))


def mh_rd(tables):
    """Mantel-Haenszel risk difference over strata; tables = list of (k1,n1,k2,n2). Greenland-Robins variance."""
    num = den = 0.0; var_num = 0.0
    W = []
    for k1, n1, k2, n2 in tables:
        w = n1 * n2 / (n1 + n2)
        p1, p2 = k1 / n1, k2 / n2
        num += w * (p1 - p2); den += w
    rd = num / den
    # Sato's variance estimator for MH risk difference
    Pn = Qn = 0.0
    for k1, n1, k2, n2 in tables:
        N = n1 + n2
        Pn += (n2 ** 2 * k1 - n1 ** 2 * k2 + n1 * n2 * (n1 - n2) * 0.5) / N ** 2
        Qn += (k1 * (n2 - k2) + k2 * (n1 - k1)) / (2 * N)
    var = rd * Pn / den ** 2 + Qn / den ** 2
    se = np.sqrt(max(var, 0))
    return rd, rd - 1.96 * se, rd + 1.96 * se


if __name__ == '__main__':
    allS = []
    summ = []
    comps = []
    for exp in AGED + IMPRINT + YOUNG + ['S15-H']:
        df = P.extract(exp)
        df['experiment'] = exp
        allS.append(df)
        summ += group_summary(df, exp)
        groups = list(dict.fromkeys(df.group))
        if exp in AGED:
            for comp in ['Sham', 'PSLN-212', 'CMP-204', 'PSLN-212(Y)', 'Untreated']:
                if comp in groups:
                    r = compare(df, exp, 'PSLN-344', comp)
                    if r: comps.append(r)
            if 'PSLN-212' in groups:
                r = compare(df, exp, 'PSLN-212', 'Sham'); comps.append(r)
        elif exp in IMPRINT:
            comps.append(compare(df, exp, 'Naive+PSLN-344', 'Naive+PSLN-212'))
            comps.append(compare(df, exp, 'Imprinting+PSLN-344', 'Imprinting+PSLN-212'))
            comps.append(compare(df, exp, 'Imprinting+PSLN-344', 'Naive+PSLN-344'))
        elif exp == 'S15-H':
            comps.append(compare(df, exp, '3d Vaccine+PSLN-344', '3d Vaccine'))
            comps.append(compare(df, exp, '3d Vaccine+PSLN-344', '3d PSLN-344'))
        else:
            for g1, g2 in [('PSLN-344(Y)', 'Sham'), ('PSLN-212(Y)', 'Sham'), ('PSLN-344(Y)', 'PSLN-212(Y)'), ('CMP-204(Y)', 'Sham'), ('PSLN-344(Y)', 'Naive'), ('Sham', 'Naive')]:
                if g1 in groups and g2 in groups:
                    comps.append(compare(df, exp, g1, g2))
    S = pd.DataFrame(summ)
    S['integrity'] = S.experiment.map(TIER).fillna('')
    C = pd.DataFrame([c for c in comps if c])
    C['integrity'] = C.experiment.map(TIER).fillna('')
    meta = {b: P.REG[b] for b in P.REG}
    S['challenge'] = S.experiment.map(lambda e: meta[e].get('challenge'))
    S['strain'] = S.experiment.map(lambda e: meta[e].get('strain'))
    S.to_csv('/tmp/outputs/tables/survival_by_group.csv', index=False)
    C.to_csv('/tmp/outputs/tables/survival_comparisons.csv', index=False)
    pd.set_option('display.width', 260, 'display.max_colwidth', 60, 'display.max_rows', 400)
    print(S[['experiment', 'group', 'n', 'survivors', 'survival_pct', 'wilson_lo', 'wilson_hi', 'median_day_death', 'integrity']].round(1).to_string())
    print()
    print(C.round(4).to_string())

    # ---------------- pooled analyses over aged BALB/c / aged other strains ----------------
    ALL = pd.concat(allS)
    ALL.to_csv('/tmp/outputs/tables/survival_all_animals.csv', index=False)

    def pooled(exps, g1, g2, label):
        tabs = []; dat = []
        for e in exps:
            d = ALL[ALL.experiment == e]
            a = d[d.group == g1]; b = d[d.group == g2]
            if len(a) and len(b):
                tabs.append((int((a.event == 0).sum()), len(a), int((b.event == 0).sum()), len(b)))
                dat.append(d[d.group.isin([g1, g2])])
        if not tabs:
            return None
        rd, lo, hi = mh_rd(tabs)
        D = pd.concat(dat).dropna(subset=['day'])
        try:
            chi2, p = survdiff(D.day.values, D.event.values, (D.group == g1).astype(int).values, strata=D.experiment.values)
        except Exception:
            p = np.nan
        k1 = sum(t[0] for t in tabs); n1 = sum(t[1] for t in tabs); k2 = sum(t[2] for t in tabs); n2 = sum(t[3] for t in tabs)
        return dict(subset=label, comparison=f'{g1} vs {g2}', n_experiments=len(tabs),
                    survivors_1=f'{k1}/{n1}', pct_1=100 * k1 / n1, survivors_2=f'{k2}/{n2}', pct_2=100 * k2 / n2,
                    MH_risk_diff_pct=100 * rd, lo=100 * lo, hi=100 * hi, stratified_logrank_p=p)

    subsets = {
        'A. all aged experiments as recorded (S06-C and S06-D both counted)': AGED,
        'B. as recorded, S06-D removed (duplicate of S06-C)': [e for e in AGED if e != 'S06-D'],
        'C. exclude Tier-1 (survival record itself compromised: S06-C, S06-D, S03-I, S03-J)': [e for e in AGED if e not in ('S06-C', 'S06-D', 'S03-I', 'S03-J')],
        'D. exclude Tier-1 and Tier-2 (also companion weight record copied/edited)': [e for e in AGED if TIER.get(e, '').startswith(('clean', 'T3'))],
        'E. clean only (no integrity flag of any tier)': [e for e in AGED if TIER.get(e) == 'clean'],
    }
    rows = []
    for lab, ex in subsets.items():
        for g1, g2 in [('PSLN-344', 'Sham'), ('PSLN-344', 'PSLN-212'), ('PSLN-212', 'Sham'), ('PSLN-344', 'PSLN-212(Y)')]:
            r = pooled(ex, g1, g2, lab)
            if r:
                r['experiments'] = ', '.join(e for e in ex)
                rows.append(r)
    PO = pd.DataFrame(rows)
    PO.to_csv('/tmp/outputs/tables/survival_pooled_sensitivity.csv', index=False)
    print()
    print(PO.drop(columns=['experiments']).round(4).to_string())

    # Worst-case reconciliation: where survival and weight records disagree for a PSLN-344 arm, use the larger death count
    print('\nWorst-case reconciliation for PSLN-344 arms (max of survival-block deaths and weight-record deaths):')
    SVW = pd.read_csv('/tmp/outputs/tables/qa_survival_vs_weight.csv')
    x = SVW[SVW.group == 'PSLN-344'][['survival_block', 'deaths_surv', 'deaths_weight']]
    x['deaths_surv'] = pd.to_numeric(x.deaths_surv, errors='coerce')
    x['worst'] = x[['deaths_surv', 'deaths_weight']].max(axis=1)
    print(x.to_string())

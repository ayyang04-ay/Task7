import openpyxl, numpy as np
from openpyxl.utils import column_index_from_string as ci, get_column_letter as gl
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx', data_only=True)
def grid(sh, c1, c2, r1, r2):
    ws = wb[sh]
    return np.array([[ws[f'{gl(c)}{r}'].value for c in range(ci(c1), ci(c2) + 1)] for r in range(r1, r2 + 1)], dtype=object)

print('Q2: S15-C PSLN-344 (W23:AC30) vs S15-I Vaccine+PSLN-344 (W72:AC79)')
A = grid('S15', 'W', 'AC', 23, 30); B = grid('S15', 'W', 'AC', 72, 79)
days = [0, 2, 4, 6, 8, 10, 12, 14]
tot = same = 0; diffs = []
for i, d in enumerate(days):
    if d == 0: continue
    for j in range(7):
        a, b = A[i, j], B[i, j]
        if d <= 12:
            tot += 1; same += (a == b)
            if a != b: diffs.append((d, j + 1, a, b))
        else:
            if a != b: diffs.append((d, j + 1, a, b))
print(f'  days 2-12: {same}/{tot} identical; differences: {diffs}')

print('Q3: S08-D G22:K26 vs S15-F B54:F58 decimal tails')
A = grid('S08', 'G', 'K', 22, 26); B = grid('S15', 'B', 'H', 54, 58)
def tail(v):
    s = repr(float(v)); return s.split('.')[1][:5] if '.' in s else ''
hits = []
for i in range(5):
    for j in range(A.shape[1]):
        for k in range(B.shape[1]):
            ta, tb = tail(A[i, j]), tail(B[i, k])
            if len(ta) >= 5 and ta == tb:
                hits.append((f'S08!{gl(ci("G")+j)}{22+i}={A[i,j]}', f'S15!{gl(ci("B")+k)}{54+i}={B[i,k]}'))
for h in hits: print('  ', h)
print('  n matched cell pairs:', len(hits))

print('Q4a: S15-M PSLN-212 day 4 (W105:AC105) vs S15-A Sham day 4 (I5:O5)')
print('  ', list(grid('S15', 'W', 'AC', 105, 105)[0]), '\n  ', list(grid('S15', 'I', 'O', 5, 5)[0]))
print('Q4b: S15-M PSLN-212(Y) (I104:O109) vs S09-E PSLN-344(Y) (W40:AD45)')
A = grid('S15', 'I', 'O', 104, 109); B = grid('S09', 'W', 'AD', 40, 45)
for i, d in enumerate([2, 4, 6, 8, 10, 12]):
    sa = [round(float(x), 6) for x in A[i]]; sb = [round(float(x), 6) for x in B[i]]
    shared = [x for x in sa if x in sb]
    print(f'  day {d}: S15-M {sa}\n         S09-E {sb}\n         shared {len(shared)}: {shared}')
print('Q4c: S15-M PSLN-344 (AD104:AJ110) vs S15-A PSLN-344 (W4:AC10)')
A = grid('S15', 'AD', 'AJ', 104, 110); B = grid('S15', 'W', 'AC', 4, 10)
for i, d in enumerate([2, 4, 6, 8, 10, 12, 14]):
    sa = [round(float(x), 5) for x in A[i]]; sb = [round(float(x), 5) for x in B[i]]
    same = [(j + 1, sa[j]) for j in range(7) if sa[j] == sb[j]]
    print(f'  day {d}: same-position identical {len(same)}: {same}')
print('Q7: S13-F PSLN-212 (P33:V40) day 14 values:', list(grid('S13', 'P', 'V', 40, 40)[0]))
print('S13-F Naive (AD33:AJ40):'); print(grid('S13', 'AD', 'AJ', 33, 40))

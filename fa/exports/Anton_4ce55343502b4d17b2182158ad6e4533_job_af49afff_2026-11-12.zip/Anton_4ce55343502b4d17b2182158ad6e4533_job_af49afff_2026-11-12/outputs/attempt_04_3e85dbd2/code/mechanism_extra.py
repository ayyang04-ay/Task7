import numpy as np, pandas as pd
from scipy import stats
import psln_blocks as P
def vals(b, g, t=None):
    d = P.extract(b)
    if t is not None: d = d[d.time.astype(str) == str(t)]
    return d[d.group == g].value.values
def welch(a, b): return stats.ttest_ind(a, b, equal_var=False).pvalue
def gm(v): return 10 ** np.mean(np.log10(v))
out = []
def rec(label, a_desc, a, b_desc, b, log=False):
    if log:
        ca, cb = gm(a), gm(b); p = stats.ttest_ind(np.log10(a), np.log10(b), equal_var=False).pvalue
    else:
        ca, cb = a.mean(), b.mean(); p = welch(a, b)
    out.append(dict(contrast=label, a=a_desc, mean_a=ca, b=b_desc, mean_b=cb, ratio=ca / cb, pct_change=100 * (ca / cb - 1), welch_p=p, n_a=len(a), n_b=len(b)))
rec('S02-H moDC: Ifnar-/- BM (cDC-depleted) vs WT BM (cDC-depleted)', 'IFN w/o cDC', vals('S02-H', 'IFN w/o cDC'), 'WT w/o cDC', vals('S02-H', 'WT w/o cDC'))
rec('S02-H moDC: Ifnar-/- + rGM-CSF vs Ifnar-/-', 'GMCSF', vals('S02-H', 'GMCSF'), 'IFN w/o cDC', vals('S02-H', 'IFN w/o cDC'))
rec('S02-H moDC: Ifnar-/- + rGM-CSF vs WT', 'GMCSF', vals('S02-H', 'GMCSF'), 'WT w/o cDC', vals('S02-H', 'WT w/o cDC'))
rec('S02-G moDC-like: PSLN-212 + rGM-CSF vs PSLN-212', 'PSLN-212+GM-CSF', vals('S02-G', 'PSLN-212+GM-CSF'), 'PSLN-212', vals('S02-G', 'PSLN-212'))
rec('S02-I lung GZMB+ CD8 (young): + CCR2 antagonist vs vehicle', 'PSLN-344(Y)+INCB3344', vals('S02-I', 'PSLN-344(Y)+INCB3344'), 'PSLN-344(Y)', vals('S02-I', 'PSLN-344(Y)'))
rec('S07-B lung monocytes: + CCR2 antagonist vs vehicle', 'PSLN-344+INCB3344', vals('S07-B mono', 'PSLN-344+INCB3344'), 'PSLN-344', vals('S07-B mono', 'PSLN-344'))
rec('S07-B lung Ly6C+ macrophages: + CCR2 antagonist vs vehicle', 'PSLN-344+INCB3344', vals('S07-B Ly6C+Mph', 'PSLN-344+INCB3344'), 'PSLN-344', vals('S07-B Ly6C+Mph', 'PSLN-344'))
rec('S07-A Ly6C+CCR2+ macrophages day 5 (x1e5): PSLN-344 vs PSLN-212', 'PSLN-344', vals('S07-A', 'PSLN-344', 5), 'PSLN-212', vals('S07-A', 'PSLN-212', 5))
rec('S11-C recruited monocytes: carbenoxolone vs saline', 'CBX+', vals('S11-C', 'CBX+'), 'CBX-', vals('S11-C', 'CBX-'))
rec('S12-A monocytes (young): Ifnar-/- BM vs WT BM', 'IFNAR-/- to WT', vals('S12-A', 'IFNAR-/- to WT'), 'WT to WT', vals('S12-A', 'WT to WT'))
rec('S01-C AM liposome uptake: Sftpa1/Sftpd KO vs WT', 'SPA/D', vals('S01-C', 'SPA/D'), 'WT', vals('S01-C', 'WT'))
rec('S01-B AECII SRB+: PSLN-SRB vs free SRB', 'AECII/PSLN-SRB', vals('S01-B', 'AECII/PSLN-SRB'), 'AECII/FreeSRB', vals('S01-B', 'AECII/FreeSRB'))
rec('S08-C AECII SRB+: PSLN-344-SRB vs PSLN-SRB', 'AECII-PSLN-344-SRB', vals('S08-C', 'AECII-PSLN-344-SRB'), 'AECII-PSLN-SRB', vals('S08-C', 'AECII-PSLN-SRB'))
rec('S08-C AECI SRB+: PSLN-344-SRB vs PSLN-SRB', 'AECI-PSLN-344-SRB', vals('S08-C', 'AECI-PSLN-344-SRB'), 'AECI-PSLN-SRB', vals('S08-C', 'AECI-PSLN-SRB'))
rec('S08-B encapsulation efficiency: PSLN-344 vs PSLN-212', 'PSLN-344', vals('S08-B', 'PSLN-344'), 'PSLN-212', vals('S08-B', 'PSLN-212'))
rec('S02-C antigen+ MLN DC: PTX vs PSLN-344 (aged)', 'PTX', vals('S02-C', 'PTX'), 'PSLN-344', vals('S02-C', 'PSLN-344'))
rec('S02-E OT-I proliferation: PTX vs PSLN-344 (aged)', 'PTX', vals('S02-E', 'PTX'), 'PSLN-344', vals('S02-E', 'PSLN-344'))
rec('S05-C OT-I proliferation MLN: +PTX vs PBS', 'MLN+PTX', vals('S05-C', 'MLN+PTX'), 'MLN', vals('S05-C', 'MLN'))
rec('S05-C OT-I proliferation lung: +PTX vs PBS', 'Lung+PTX', vals('S05-C', 'Lung+PTX'), 'Lung', vals('S05-C', 'Lung'))
rec('S08-A Ifnb1: PSLN-344 10 ug vs PSLN-212 40 ug (dose equivalence)', 'PSLN-344@10', vals('S08-A', 'PSLN-344', 10), 'PSLN-212@40', vals('S08-A', 'PSLN-212', 40), log=True)
rec('S08-A Ifnb1: PSLN-344 5 ug vs PSLN-212 20 ug', 'PSLN-344@5', vals('S08-A', 'PSLN-344', 5), 'PSLN-212@20', vals('S08-A', 'PSLN-212', 20), log=True)
rec('S08-A Ifnb1: PSLN-344 20 ug vs PSLN-212 20 ug', 'PSLN-344@20', vals('S08-A', 'PSLN-344', 20), 'PSLN-212@20', vals('S08-A', 'PSLN-212', 20), log=True)
rec('S08-A Ifnb1: PSLN-344 40 ug vs 20 ug (plateau?)', 'PSLN-344@40', vals('S08-A', 'PSLN-344', 40), 'PSLN-344@20', vals('S08-A', 'PSLN-344', 20), log=True)
rec('S08-A Ifnb1: PSLN-344/R848 20 ug vs PSLN-344 20 ug', 'PSLN-344/R848@20', vals('S08-A', 'PSLN-344/R848', 20), 'PSLN-344@20', vals('S08-A', 'PSLN-344', 20), log=True)
rec('S01-A Ifnb1 16h: PSLN-344 aged vs PSLN-344 young', 'PSLN-344', vals('S01-A 16h', 'PSLN-344'), 'PSLN-344(Y)', vals('S01-A 16h', 'PSLN-344(Y)'), log=True)
rec('S01-A Ifnb1 16h: PSLN-212 aged vs PSLN-212 young', 'PSLN-212', vals('S01-A 16h', 'PSLN-212'), 'PSLN-212(Y)', vals('S01-A 16h', 'PSLN-212(Y)'), log=True)
rec('S01-A Ifnb1 16h: PSLN-344 aged vs PSLN-212 young', 'PSLN-344', vals('S01-A 16h', 'PSLN-344'), 'PSLN-212(Y)', vals('S01-A 16h', 'PSLN-212(Y)'), log=True)
rec('S01-A Ifnb1 16h: PSLN-344 aged vs PSLN-212 aged', 'PSLN-344', vals('S01-A 16h', 'PSLN-344'), 'PSLN-212', vals('S01-A 16h', 'PSLN-212'), log=True)
rec('S01-A Ifnb1 72h: PSLN-344 aged vs PSLN-212 young', 'PSLN-344', vals('S01-A 72h', 'PSLN-344'), 'PSLN-212(Y)', vals('S01-A 72h', 'PSLN-212(Y)'), log=True)
rec('S01-A Ifnb1 16h: PSLN-212/R848 aged vs PSLN-212 aged', 'PSLN-212/R848', vals('S01-A 16h', 'PSLN-212/R848'), 'PSLN-212', vals('S01-A 16h', 'PSLN-212'), log=True)
rec('S01-A Ifnb1 16h: CMP-204 aged vs PSLN-212 aged', 'CMP-204', vals('S01-A 16h', 'CMP-204'), 'PSLN-212', vals('S01-A 16h', 'PSLN-212'), log=True)
O = pd.DataFrame(out)
pd.set_option('display.width', 250, 'display.max_colwidth', 75)
O['welch_p'] = O.welch_p.map(lambda x: f'{x:.2g}')
print(O.round(2).to_string())
O.to_csv('/tmp/outputs/tables/mechanism_contrasts.csv', index=False)

# dose-response slope S08-A (log10 fold vs log10 dose), per formulation
print('\nS08-A dose-response (geometric mean fold by dose)')
d = P.extract('S08-A')
t = d.groupby(['group', 'time']).value.apply(gm).unstack(0)
print(t.round(1))
for g in d.group.unique():
    x = d[d.group == g]
    sl = stats.linregress(np.log10(x.time.astype(float)), np.log10(x.value))
    print(f'  {g}: slope log-fold per log-dose {sl.slope:.2f} (r2={sl.rvalue**2:.2f})')

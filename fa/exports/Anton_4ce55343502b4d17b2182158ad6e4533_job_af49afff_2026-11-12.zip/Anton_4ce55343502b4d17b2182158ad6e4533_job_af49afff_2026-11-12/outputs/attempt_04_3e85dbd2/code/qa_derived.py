import numpy as np, pandas as pd
import psln_blocks as P
pd.set_option('display.width', 250, 'display.max_rows', 200)

print('=== 1. S04-B Tfh:Tfr vs (100 - Foxp3%)/Foxp3%')
F = P.extract('S04-B Foxp3'); T = P.extract('S04-B Tfh:Tfr')
F['rowpos'] = F.groupby('group').cumcount(); T['rowpos'] = T.groupby('group').cumcount()
M = F.merge(T, on=['group', 'rowpos'], suffixes=('_foxp3', '_ratio'))
M['pred'] = (100 - M.value_foxp3) / M.value_foxp3
M['absdiff'] = (M.pred - M.value_ratio).abs()
print(M[['group', 'cell_foxp3', 'value_foxp3', 'cell_ratio', 'value_ratio', 'pred', 'absdiff']].to_string())
print('max abs diff', M.absdiff.max())

print('\n=== 2. S03-B / S03-F (printed IgG2a/IgG1 quotient) vs S13-A/B and S13-C/D subclass titres')
for ratio_blk, g2a, g1 in [('S03-B', 'S13-A', 'S13-B'), ('S03-F', 'S13-C', 'S13-D')]:
    A = P.extract(g2a); B = P.extract(g1); Rr = P.extract(ratio_blk)
    for d in (A, B, Rr):
        d['pos'] = d.groupby('group').cumcount()
    Q = A.merge(B, on=['group', 'pos'], suffixes=('_2a', '_1'))
    Q['quot'] = Q.value_2a / Q.value_1
    # find for each S13 group which printed S03 column matches
    for g in Q.group.unique():
        q = Q[Q.group == g].sort_values('pos').quot.values
        best = []
        for g2 in Rr.group.unique():
            r = Rr[Rr.group == g2].sort_values('pos').value.values
            best.append((g2, np.max(np.abs(q - r))))
        best.sort(key=lambda t: t[1])
        print(f'  {g2a}/{g1} group {g:12s} quotient = {np.round(q, 4)}  -> matches {ratio_blk} column printed as "{best[0][0]}" (max |diff| {best[0][1]:.2e})')

print('\n=== 3. S09-A (log10) vs S01-A Ifnb1 (linear)')
s9 = P.extract_s09a()
for side, ref in [('S09-A left', 'S01-A 16h'), ('S09-A right', 'S01-A 72h'), ('S09-A right', 'S01-A 16h'), ('S09-A left', 'S01-A 72h')]:
    x = s9[(s9.block == side) & (s9.analyte == 'Ifnb1')]
    R1 = P.extract(ref)
    R1 = R1.assign(group=R1.group.replace({'Sham': 'PBS'}))
    hit = tot = 0
    for _, r in x.iterrows():
        lin = round(10 ** r.log10, 2)
        vals = R1[R1.group == r.group].value.round(2).tolist()
        tot += 1
        hit += int(any(abs(lin - v) <= 0.011 for v in vals))
    print(f'  {side} Ifnb1 values found in {ref} same group: {hit}/{tot}')

print('\n=== 4. S11-A (alveolar macrophages) vs S11-B (neutrophils): same-position identical values')
A = P.extract('S11-A'); B = P.extract('S11-B')
Mm = A.merge(B, on=['group', 'time', 'rep'], suffixes=('_AM', '_neut'))
Mm['same'] = Mm.value_AM == Mm.value_neut
print(Mm.pivot_table(index='rep', columns='group', values='same', aggfunc='sum'))
print('total identical', int(Mm.same.sum()), 'of', len(Mm))

print('\n=== 5. S01-B vs S08-C (same formulation PSLN-SRB, same cell type, same timepoint)')
b = P.extract('S01-B'); c = P.extract('S08-C')
for g1, g2 in [('AECII/PSLN-SRB', 'AECII-PSLN-SRB'), ('AECI/PSLN-SRB', 'AECI-PSLN-SRB'), ('AECI/PSLN-SRB', 'AECII-PSLN-344-SRB')]:
    v1 = b[b.group == g1].value.tolist(); v2 = c[c.group == g2].value.tolist()
    print(f'  {g1:16s} {v1}  vs {g2:20s} {v2}  shared={len(set(v1) & set(v2))}  same-position={sum(x == y for x, y in zip(v1, v2))}  means {np.mean(v1):.2f} vs {np.mean(v2):.2f}')

print('\n=== 6. HAI values below the lowest dilution tested (1:10)')
for blk in ['S03-C', 'S03-G']:
    d = P.extract(blk)
    print(blk, d[d.value < 10][['group', 'cell', 'value']].to_dict('records'))

print('\n=== 7. S03-J missing day value')
d = P.extract('S03-J'); print(d[d.day.isna()].to_dict('records'))
print('\n=== 8. S08-D PSLN-212/R848 day-10 missing animal')
d = P.extract('S08-D'); print(d[(d.value.isna())].to_dict('records'))

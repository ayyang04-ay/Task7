#!/usr/bin/env bash
# Regenerates every table, figure and the evidence ledger from the workbook.
# Requires a Python env with pandas, scipy, statsmodels, openpyxl, matplotlib, xlsxwriter
# (here: `micromamba run -n chem`).  Input path is set in psln_blocks.py (XLSX); outputs go to /tmp/outputs.
set -euo pipefail
PY="${PY:-micromamba run -n chem python}"
cd "$(dirname "$0")"
mkdir -p /tmp/outputs/tables /tmp/outputs/figures
$PY psln_blocks.py            > /tmp/outputs/tables/00_block_registry.txt
$PY qa_duplicates.py          > /tmp/outputs/tables/qa_duplicates_log.txt
$PY qa_duplicates_strong.py   > /tmp/outputs/tables/qa_duplicates_strong_log.txt
$PY qa_fraction_fingerprint.py > /tmp/outputs/tables/qa_fraction_fingerprint_log.txt
$PY qa_tail_lattice.py        > /tmp/outputs/tables/qa_tail_lattice_log.txt
$PY qa_tail_lattice_summary.py > /tmp/outputs/tables/qa_tail_lattice_summary_log.txt
$PY qa_verify_specifics.py    > /tmp/outputs/tables/qa_verify_specifics_log.txt
$PY qa_surv_vs_weight.py      > /tmp/outputs/tables/qa_survival_vs_weight_log.txt
$PY qa_survival_dups.py       > /tmp/outputs/tables/qa_survival_dups_log.txt
$PY qa_derived.py             > /tmp/outputs/tables/qa_derived_log.txt
$PY qa_s09a_internal.py       > /tmp/outputs/tables/qa_s09a_internal_log.txt
$PY efficacy_survival.py      > /tmp/outputs/tables/efficacy_survival_log.txt
$PY efficacy_pooled_boot.py   > /tmp/outputs/tables/efficacy_pooled_log.txt
$PY immuno_mechanism.py       > /tmp/outputs/tables/immuno_mechanism_log.txt
$PY safety_and_corrections.py > /tmp/outputs/tables/safety_log.txt
$PY mechanism_extra.py        > /tmp/outputs/tables/mechanism_extra_log.txt
$PY power_calcs.py            > /tmp/outputs/tables/power_calcs_log.txt
$PY build_ledger.py           > /tmp/outputs/tables/build_ledger_log.txt
$PY figures.py
$PY check_report.py           > /tmp/outputs/tables/check_report_log.txt
echo "done"

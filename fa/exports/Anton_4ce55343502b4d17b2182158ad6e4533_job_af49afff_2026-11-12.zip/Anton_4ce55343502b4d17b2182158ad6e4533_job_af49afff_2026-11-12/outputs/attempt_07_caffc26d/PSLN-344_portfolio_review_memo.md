# PSLN-344: Portfolio Review Brief

**Asset:** PSLN-344, a Mn²⁺-complexed, pulmonary-surfactant-biomimetic liposome carrying the STING agonist CDN-1807. It is given intranasally as an adjuvant for inactivated influenza vaccine in older adults.

**Sources:** `adjuvant_program_dataset.xlsx` (sheets S01–S15) and `adjuvant_program_annotation.pdf`. No outside data were used for any efficacy, immunology or safety number. Where I use general field knowledge to frame the forward plan, it is labelled *[external context]*.

**How to check a number:** every number cites a ledger ID. **E##** is an evidence row and **I##** is an integrity finding. Both are in `PSLN-344_evidence_ledger.xlsx`, where each row gives the sheet!cell range, how the data were reduced and the test used. Per-animal values with their cell addresses are in the sheets `Raw_values_long` and `Raw_survival_long`. The scripts in `code/` regenerate every table and figure.

---

## 1. Recommendation

### Advance PSLN-344, but only into a gated, time-boxed de-risking stage

- **Approve now:** Gate 0 (about 2 months) and Gate 1 (about 8 more months).
- **Do not start yet:** GLP toxicology, GMP manufacture or IND preparation. These wait until the Gate 1 criteria in Section 7 are met.

**Why advance: the case**

1. **The efficacy signal in aged mice is large, consistent, and comes from the Mn²⁺.**
   - PSLN-344 and PSLN-212 are the same liposome with the same CDN at the same dose. The only difference is that PSLN-344 contains Mn²⁺.
   - Across the six core aged-mouse challenge experiments, deaths were:
     - **10/42 (23.8%)** with vaccine + PSLN-344;
     - **38/42 (90.5%)** with vaccine + PSLN-212;
     - **42/42** with vaccine + sham (E01, E02).
   - The Mantel–Haenszel risk difference was **−66.7 percentage points** (95% CI −81.4 to −51.9). The exact stratified p-value was **3.0 × 10⁻¹⁰** (E01).
   - Without Mn²⁺ the adjuvant does not lower mortality in aged mice: PSLN-212 vs sham, p = 0.115. It only delays death. In young mice, by contrast, it fully protects (0/42 deaths) (E03).
   - In short, Mn²⁺ is what turns this formulation into an adjuvant for older animals.

2. **The result survives every stress test.** PSLN-344 vs PSLN-212 deaths under each scenario:
   - Deaths re-counted from the companion weight data: 8/42 vs 38/42 (E04a).
   - Conflicted experiments added back: 12/49 vs 43/49 (E04b) and 10/49 vs 42/49 (E04c).
   - Only the four experiments whose compared arms are untouched by any duplication or copying finding (S06-B, E, F, G): **9/28 vs 27/28, p = 9.4 × 10⁻⁷** (E05).

   The benefit also holds across settings:
   - Challenge on day 3, day 14 and day 60 after vaccination (E06a–c).
   - Challenges that share no HA or NA subtype with the vaccine (E06e).
   - 14-month-old mice, both virus-imprinted and naive (E10).
   - Two other mouse strains, though these results are unverified (E11).

3. **The biology is coherent and specific to Mn²⁺.**
   - Aged lungs make only **44%** of the young early IFN-β response to PSLN-212 (16.5-fold vs 37.5-fold over untreated).
   - PSLN-344 restores this to **36.9-fold**: 2.23 times PSLN-212 (95% CI 1.85–2.69), which closes 98% of the age gap (E20).
   - The effect is dose-dependent, and a higher dose of PSLN-212 cannot match it. PSLN-212 at 40 µg gives 14.7-fold, below PSLN-344 at 10 µg (21.0-fold) and far below PSLN-344 at 20 µg (45.5-fold) (E21).
   - The gain carries through the rest of the response:
     - antigen-carrying dendritic cells reaching the draining lymph node (E24);
     - germinal-centre activity (E45);
     - **8- to 9-fold** higher HAI and neutralising titres (E41, E42);
     - **3- to 4-fold** more cross-reactive and lung-resident memory CD8 T cells (E46).

4. **No tolerability signal in mice at the dose that works.**
   - Weight-loss nadir was 96.4% of starting weight with PSLN-344 vs 97.0% with PSLN-212 (p = 0.56) (E50).
   - There was no brain induction of *Ifnb1*, *Tnf* or *Isg15* at 36 h. Cholera toxin induced these 2.7- to 5.5-fold (E51).

**Why not a full go: the conditions**

1. **Data integrity.** The workbook contains:
   - a survival experiment that is an exact duplicate of another (I01);
   - body-weight trajectories copied between different experiments and mouse strains (I04);
   - two different cell-type readouts that share 35% of their values (I05);
   - mislabelled derived blocks (I06, I09);
   - survival records contradicted by their own companion weight data (I02, I03).

   The efficacy conclusion survives excluding every survival experiment touched by these findings (E05). However, no regulator or partner will accept the package until it is reconciled against primary records.
2. **No standard-of-care benchmark.** Every comparator is internal: sham, the Mn-free liposome, or a cGAMP liposome. There is no licensed older-adult comparator, such as an MF59-type adjuvant or a high-dose intramuscular vaccine.
3. **Intranasal Mn²⁺ safety is essentially uncharacterised.**
   - There is no Mn dose per animal anywhere in the data.
   - There is no brain or olfactory Mn measurement, no histopathology and no repeat-dose data (E51, E53).
4. **Protection in aged mice is incomplete and wanes.**
   - At day 60: 7/21 deaths in aged PSLN-344 mice vs 0/21 in young PSLN-212 mice.
   - Overall residual gap to young: +23.8 percentage points (E06c, E07).
5. **Standard endpoints are missing:** lung viral load, mucosal IgA, causal depletion or transfer experiments, and male animals.

**What the committee decides today:**
- Fund **Gate 0**: about 2 months of data reconstruction and QA.
- If Gate 0 passes, fund **Gate 1**: about 8 months covering a blinded confirmatory aged-mouse efficacy study against licensed-type benchmarks, mechanism depletion studies, and an Mn biodistribution and neuro pilot.
- Go/kill criteria are in Section 7; the timeline is in Fig. 5.

**If the committee must cut instead:** the defensible reason is unresolved data integrity plus unknown intranasal-Mn safety. It is **not** a lack of efficacy signal. We would be dropping the only formulation in our data that turns a failing adjuvant into a protective one in aged animals (Section 8).

---

## 2. What the dataset contains and how it was reduced

**Contents**
- 15 sheets holding **5,593 recorded per-animal values** and **514 per-animal survival records**, in about 100 labelled blocks (a block is one experiment or readout).
- Animals: female BALB/c unless stated. Aged means 20 months or older; young means 7–8 weeks.
- Group sizes: 3–10 per group, typically 5 for immunology and 7 for challenge studies.

**Standard arms**
- Inactivated vaccine plus one of:
  - sham (empty liposome);
  - PSLN-212 (identical to PSLN-344 but without Mn²⁺);
  - PSLN-344.
- Young mice given PSLN-212, labelled "(Y)", serve as the "what good looks like" reference.

**How the data were reduced**
- Titres and transcript fold-changes: geometric means (GM). Percentages: arithmetic means.
- Pre-specified pairwise contrasts used Welch t-tests (on log10 for titres and transcripts). Mann–Whitney was run as a sensitivity check.
- The team's stated method, one-way ANOVA with Tukey correction, was also run for the PSLN-344 vs PSLN-212 comparison (sheet `Readouts_stats`).
  - Tukey gives p < 0.05 for 42 of 48 readouts; Welch gives 44 of 48.
  - The two that differ are CD40 (Welch 0.011, Tukey 0.16) and d28 CA09 IgG (Welch 0.010, Tukey 0.19).
- Survival within each experiment used the log-rank test. Across experiments it used an exact stratified conditional test and a Mantel–Haenszel risk difference.
- HAI recorded as 0 (below the 1:10 starting dilution; sham arms only) was set to 5.
- Exclusions are listed in Appendix A.

---

## 3. Efficacy

**Table 1. Survival in aged mice (survivors/n). Core experiments are S06-A, B, C, E, F and G.**

| Block | Vaccine → challenge (day after vaccination) | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | 344 vs 212, log-rank p | Integrity status |
|---|---|---|---|---|---|---|---|
| S06-A | Aichi H3N2 → PR8 H1N1 (d14) | 0/7 | 1/7 | **6/7** | 7/7 | 0.008 | concordant with weights; weights duplicated in S15-M (I04) |
| S06-C | Bivalent H1+H3 → rgH5N1 (d14) | 0/7 | 2/7 | **7/7** | 7/7 | 0.007 | ±1 with weights; S15-C weights copied into S15-I (I04) |
| S06-B | Aichi → PR8 (d3) | 0/7 | 0/7 | **5/7** | 7/7 | <0.001 | concordant |
| S06-D | Bivalent → rgH5N1 (d3) | *identical to S06-C* | | | | | **excluded (I01)** |
| S06-E | Aichi → PR8 (d60) | 0/7 | 0/7 | **5/7** | 7/7 | 0.002 | ±1 with weights |
| S06-F | Bivalent → rgH5N1 (d60) | 0/7 | 1/7 | **5/7** | 7/7 | 0.009 | concordant |
| S06-G | CA09 H1N1 → Perth H3N2 (d60) | 0/7 | 0/7 | **4/7** | 7/7 | 0.015 | ±1 with weights; unchallenged controls 3/7 died (I11) |
| S03-I | Bivalent → CA09, homologous, 10× lethal dose (d14) | 0/7 | 0/7 | **7/7** | 7/7 | <0.001 | **conflict:** weights imply PSLN-212 3/7 survived (I02) |
| S03-J | rgH5N1 → wild-type H5N1 (d2) | 1/10 | 3/10 | **10/10** | — | 0.001 | age not stated; groups do not match the weight block (I03) |
| S15-L | Aged C57BL/6, bivalent, challenge not stated | 0/7 | 0/7 | **6/7** | 6/7 | 0.001 | weights duplicated across strains (I04) |
| S15-N | Aged Swiss Webster, as S15-L | 0/7 | 2/7 | **6/7** | 7/7 | 0.056 | as above |

Sources: E01 and sheets `Survival_by_group` and `Survival_pairwise`. Fig. 1 shows the same data.

![Fig. 1. Survival by experiment in aged mice (survivors/n).](figures/fig1_survival_by_experiment.png)

**Table 2. Pooled deaths, PSLN-344 vs comparator (aged).**

| Analysis | PSLN-344 | Comparator | Risk difference, pp (95% CI) | Exact stratified p |
|---|---|---|---|---|
| **Primary:** core 6 experiments vs PSLN-212 (E01) | 10/42 | 38/42 | −66.7 (−81.4 to −51.9) | 3.0 × 10⁻¹⁰ |
| Cleanest 4 experiments, S06-B, E, F, G: compared arms free of duplication findings (E05) | 9/28 | 27/28 | — | 9.4 × 10⁻⁷ |
| Deaths taken from weight data where discordant (E04a) | 8/42 | 38/42 | −71.4 (−85.8 to −57.1) | 4.9 × 10⁻¹¹ |
| Plus S06-D using its own weight data (E04b) | 12/49 | 43/49 | −63.3 (−77.6 to −48.9) | 2.0 × 10⁻¹⁰ |
| Plus S03-I using weight-implied PSLN-212 deaths (E04c) | 10/49 | 42/49 | −65.3 (−79.0 to −51.6) | 1.2 × 10⁻¹¹ |
| vs sham, core 6 experiments (E02) | 10/42 | 42/42 | −76.2 (−88.4 to −64.0) | 5.5 × 10⁻¹⁴ |
| Day-14 challenge only (E06a) | 1/14 | 11/14 | — | 3.8 × 10⁻⁴ |
| Day-3 challenge only (E06b) | 2/7 | 7/7 | — | 0.021 |
| Day-60 challenge only (E06c) | 7/21 | 20/21 | — | 7.0 × 10⁻⁵ |
| 14-month mice, imprinted and naive, 4 strata (E10) | 4/28 | 24/28 | — | 6.3 × 10⁻⁸ |
| Other strains, unverified (E11) | 2/14 | 12/14 | — | 4.7 × 10⁻⁴ |
| **Residual age gap:** aged PSLN-344 vs young PSLN-212 (E07) | 10/42 | 0/42 | +23.8 (11.6 to 36.0) | 0.001 |

**What the efficacy data establish**

- **Mn²⁺ rescues efficacy that the CDN liposome alone loses with age.**
  - Aged mice with PSLN-212 die at about the sham rate: 38/42 vs 42/42 deaths. PSLN-212 only delays death (stratified log-rank p = 8.2 × 10⁻⁸).
  - Young mice given the same PSLN-212 all survive (E03).
  - In young mice, Mn²⁺ adds no measurable survival benefit: 0/24 deaths with PSLN-344 and 0/24 with PSLN-212 across three challenges, including H5N1 at day 180 (E13). The aged model is the one that discriminates between formulations.
- **Most of the survival evidence comes from challenges mismatched to the vaccine.**
  - Four core experiments share neither HA nor NA subtype with the vaccine. In these, survivors were **20/28 with PSLN-344 vs 1/28 with PSLN-212** (E06e).
- **Protection starts early, but it needs antigen.**
  - With challenge at day 3, 5/7 survived with PSLN-344 vs 0/7 with PSLN-212 (E06b).
  - PSLN-344 given without vaccine 3 days before H5N1 challenge protected no animals (0/7 survived). Vaccine alone also protected none (0/7). Vaccine plus PSLN-344 protected 6/7 (E12). This is not a non-specific innate antiviral state.
- **Durability is the weak point.**
  - PSLN-344 deaths rose from 1/14 at the day-14 challenge to 7/21 at the day-60 challenge. This is a trend only (p = 0.11) (E06d).
  - At day 60, the gap to young mice was 7/21 vs 0/21 deaths (E07). Aged PSLN-344 mice have not been studied beyond day 60.
- **No single experiment is adequately powered, so the evidence lies in the consistency.**
  - A 7-vs-7 experiment has about 57% power even for the observed effect (E16).
  - Six of six core experiments go the same way (Fig. 1).
- **One model-validity concern: unexplained background deaths.**
  - Unvaccinated, unchallenged aged "Untreated" controls died at 4/21 within 14 days (E15, I11). That is implausible for healthy 20-month-old BALB/c mice.
  - Either the aged colony had a health problem or the controls are mislabelled. This must be resolved because it affects every survival endpoint in aged mice.

---

## 4. Immunogenicity and the age gap

**Table 3. Key readouts (aged unless stated).** GM = geometric mean; % = arithmetic mean; "effect" is the 344/212 ratio of GMs or the 344 − 212 difference in percentage points. "Restored" is the fraction of the aged–young gap that Mn²⁺ closes (bootstrap 95% CI); see Fig. 2.

| Readout (ledger) | Sham | PSLN-212 | **PSLN-344** | Young PSLN-212 | PSLN-344 vs PSLN-212 (95% CI), p | Restored |
|---|---|---|---|---|---|---|
| Lung *Ifnb1*, 16 h, fold (E20) | 0.94 | 16.5 | **36.9** | 37.5 | ×2.23 (1.85–2.69), p < 0.001 | 0.98 (0.84–1.14) |
| IgG anti-CA09, d14, GMT (E40a) | 56 | 393 | **7,305** | 11,959 | ×18.6 (9.1–37.9), p < 0.001 | 0.86 |
| HAI anti-CA09, d14, GMT (E41a) | 7.6 | 46 | **368** | 485 | ×8.0 (3.9–16.4), p < 0.001 | 0.88 |
| HAI anti-Aichi, d14, GMT (E41b) | 10 | 35 | **320** | 368 | ×9.2 (4.2–20.2), p < 0.001 | 0.94 |
| Neutralising anti-CA09, GMT (E42a) | 52 | 418 | **3,840** | 6,686 | ×9.2 (3.1–27.2), p = 0.002 | 0.80 |
| IgG anti-Aichi, d28 after boost (E43b) | 101 | 1,086 | **12,435** | 43,472 | ×11.5 (4.1–32.4), p < 0.001 | 0.66 |
| GC B cells, MLN d7, % (E45a) | 1.2 | 2.3 | **6.5** | 9.8 | +4.2 (2.3–6.1), p = 0.002 | 0.56 |
| Tfr, % of CXCR5⁺ICOS^hi, d7 (E45d) | 22.6 | 26.7 | **10.8** | 7.1 | −15.9 (−24.0 to −7.7), p = 0.005 | 0.81 |
| Cross-reactive IFN-γ⁺ CD8, d14, % (E46c) | 0.7 | 1.5 | **6.4** | 9.2 | +4.9 (3.6–6.1), p < 0.001 | 0.63 |
| Cross-reactive IFN-γ⁺ CD8, d60, % (E46d) | 1.5 | 3.0 | **9.9** | 14.4 | +6.8 (3.4–10.3), p = 0.003 | 0.60 |
| Lung resident-memory CD8, d25, % (E46f) | 0.6 | 1.0 | **4.0** | 6.0 | +3.0 (2.2–3.7), p < 0.001 | 0.59 |
| CD40⁺ of MLN CD11b⁺ DC, d3, % (E25a) | 4.0 | 5.6 | **11.2** | 38.7 | +5.6 (2.0–9.3), p = 0.011 | **0.17** |
| *Survival, core 6 experiments (E47)* | 0/42 | 4/42 | **32/42** | 42/42 | see Table 2 | 0.74 (0.59–0.86) |
| *Survival, day-60 challenge (E47)* | 0/21 | 1/21 | **14/21** | 21/21 | | 0.65 (0.44–0.85) |

**Notes on Table 3**

- **HAI thresholds.**
  - All 10 aged PSLN-344 animals reached HAI ≥1:160, against 0/10 with PSLN-212 (E41c).
  - 8/10 aged PSLN-212 animals reached the human "seroprotective" 1:40, including 5/5 for CA09. Yet aged PSLN-212 mice died under homologous CA09 challenge in S03-I: 7/7 recorded, and at least 4/7 by the companion weights (I02).
  - So the human 1:40 threshold does not carry over to this lethal mouse challenge.
- **Antibody subclass.** PSLN-344 shifts the response toward IgG2a, like young animals. IgG2a/IgG1 ratios were 1.85 vs 0.54 for CA09 and 2.30 vs 0.46 for Aichi; young PSLN-212 gave 2.50 and 2.79 (E44).
  - These ratios are computed from the raw subclass titres in S13.
  - The summary ratio blocks S03-B and S03-F contain the same numbers with the group labels rotated (I06) and were not used.
- **After a boost, the CA09 gap narrows.** The d28 anti-CA09 IgG ratio is ×3.5, 95% CI 1.5–8.4 (Welch p = 0.010; Tukey p = 0.19) (E43a). The Aichi ratio stays at ×11.5 (E43b).
  - The d14 and d28 data come from different cohorts, and there are no challenge data after a boost.

![Fig. 3. Per-animal values for key readouts.](figures/fig3_key_readouts.png)

---

## 5. What is actually driving the protection

Evidence is graded as follows:
- **A** = causal at the level of the formulation (randomised contrast within an experiment);
- **B** = causal for an immune mechanism but not linked to survival;
- **C** = correlative.

**Table 4. Mechanistic chain and its evidence.**

| Step | Finding | Grade | Ledger |
|---|---|---|---|
| Mn²⁺ is the active ingredient | Same particle, CDN and dose: 10/42 vs 38/42 deaths | **A** | E01, E03 |
| Mn²⁺ does not act by improving delivery | Mn particles enter alveolar epithelium about 4-fold *less* (AT2 3.8% vs 15.8%); alveolar-macrophage uptake depends on surfactant proteins SP-A/D (12.7% vs 43.1%) | C (caveat I12) | E31 |
| Mn²⁺ repairs the aged early IFN-β defect | 36.9 vs 16.5-fold; young level 37.5-fold; dose-dependent, plateau at 20–40 µg; higher PSLN-212 doses do not substitute | **A** (formulation contrast) | E20, E21 |
| IFN and GM-CSF drive monocyte-derived DC differentiation | *Gm-csf* 5.4-fold higher at 36 h. With Ifnar-KO bone marrow, monocyte-derived DCs fell to 2.1% vs 19.7%; GM-CSF partly rescued (12.4%); adding GM-CSF to PSLN-212 raised them 13.8% vs 5.9% | **B** | E22, E27, E30 |
| Monocyte recruitment depends on CCR2 and gap junctions | CCR2 blockade: monocytes 3.3% vs 9.9%, lung GZMB⁺ CD8 1.4% vs 6.8% (young). Gap-junction blocker carbenoxolone: 3.1% vs 7.3% | **B** | E28, E29 |
| DC migration to the draining lymph node is required for priming there | Pertussis toxin: antigen⁺ DC 2.4% vs 7.1%; MLN OT-I priming 6.8% vs 30.9%; lung priming unaffected (55.1% vs 59.0%) | **B** | E26 |
| Germinal centres → class-switched neutralising antibody | GC B ×2.8; ICOS^hi Tfh ×2.7; Tfr ↓; HAI ×8–9; neutralising ×9 | C | E41, E42, E45 |
| Cross-reactive CD8 and lung-resident memory | IFN-γ⁺ CD8 on heterologous (rgH5N1) restimulation ×4.2 at d14 and ×3.2 at d60; resident memory ×4.0 | C | E46 |
| Protection needs antigen | Adjuvant alone: 0/7 survived; vaccine alone: 0/7; vaccine + adjuvant: 6/7 survived | **A** | E12 |

**What this adds up to**

1. **The primary defect Mn²⁺ corrects is innate.**
   - Aged lungs under-produce early IFN-β to the CDN.
   - Mn²⁺ restores this completely (restoration 0.98) and specifically: it does not act by improving particle uptake.
2. **Protection depends on antigen.**
   - Adjuvant alone protects nothing (0/7 survived); the vaccine is required (E12).
   - That points to an antigen-specific, adaptive mechanism rather than a non-specific antiviral state.
   - The antigen here is whole inactivated virus, so an antigen-driven innate contribution cannot be fully excluded.
3. **The breadth of protection points to T cells (inference, not yet tested).**
   - Most of the survival evidence comes from challenges with no HA or NA match to the vaccine: 20/28 survived with PSLN-344 (E06e).
   - Antibodies against vaccine-strain HA head are subtype-specific and should not neutralise those viruses *[external context]*. Our data contain no HAI or neutralisation against the challenge strains to test this directly.
   - The measured mechanism that rises with protection is cross-reactive CD8 immunity: ×4.2 IFN-γ⁺ on heterologous restimulation, ×4.0 lung-resident memory (E46).
   - Antibodies to conserved proteins such as NP and M2e were not measured and remain possible contributors.
   - For homologous challenge, HAI ≥1:160 in every PSLN-344 animal is a sufficient explanation (E41c).
4. **What still limits aged mice lies downstream of IFN-β (Fig. 2).**
   - IFN-β is fully restored (0.98), but survival only partly (0.74; 0.65 at day 60).
   - DC co-stimulation (CD40 and CD86) is barely restored (0.17 and 0.22), yet most protection returns. Young-level co-stimulation is therefore not required.
   - The readouts restored to the same degree as durable survival are the adaptive memory measures:
     - d60 IFN-γ⁺ CD8, 0.60;
     - lung resident memory, 0.59;
     - d28 IgG, 0.57–0.66;
     - GC B cells, 0.56.
   - The day-60 survival gap therefore fits incomplete adaptive memory, not under-activation of innate immunity.

![Fig. 2. Restoration fractions: how much of the aged deficit Mn²⁺ closes, by readout and for survival.](figures/fig2_restoration_fractions.png)

**Bottom line for the committee**
- Protection is driven by Mn²⁺ repairing the aged lung's type-I-IFN response. That rebuilds DC migration and priming, which yields both neutralising antibody and cross-reactive CD8 and lung-resident immunity.
- The breadth and fast onset suggest that the CD8 arm is what sets this adjuvant apart. **That has not been tested causally:** no CD8 depletion, serum transfer or IFNAR blockade was done with a challenge endpoint.
- Inference limits: all of this is group-level reasoning from 3–4 arms per readout, and no readout was measured in the same animals that were challenged.

---

## 6. Is there a biomarker of efficacy worth carrying forward?

**Yes, one: the early type-I-IFN response, 16–24 h after dosing.**

- **Role:** a pharmacodynamic, target-engagement and "age-gap correction" biomarker.
- **Not:** a surrogate for efficacy.

**Table 5. Biomarker scorecard.**

| Candidate | Specific to Mn²⁺? | Shows the age deficit? | Restoration vs survival (0.74) | How early | Human-accessible? | Verdict |
|---|---|---|---|---|---|---|
| **Early IFN-β / ISG response** (E20, E21) | Yes: ×2.23; no overlap between groups (13.4–19.0 vs 32.6–44.3) | Yes: aged = 0.44 × young | 0.98, over-restored | 16 h | Yes: nasal lining fluid, blood ISG score *[external context]* | **Carry forward as PD and dose-selection marker; not a surrogate** |
| HAI / neutralising titre (E41, E42) | Yes: ×8–9 | Yes | 0.80–0.94 | d14–28 | Yes; established regulatory endpoint *[external context]* | **Primary immunogenicity endpoint.** Explains homologous but not heterosubtypic protection; 1:40 is not protective in this model (E41c) |
| Cross-reactive IFN-γ⁺ CD8 / lung-resident memory (E46) | Yes: ×3–4 | Yes | 0.59–0.68, matching day-60 survival 0.65 | d14–60 | IFN-γ ELISpot to conserved NP/M1 peptides: yes. Resident memory: needs BAL or nasal sampling | **Exploratory correlate of breadth and durability** |
| GC B, Tfh, Tfr (E45) | Yes | Yes | 0.56–0.81 | d7 | Circulating Tfh at d7 *[external context]* | Exploratory |
| DC CD40 / CD86 (E25) | Modest | Large | **0.17 / 0.22** | d3 | — | **Ruled out**: protection returns without it |
| Ly6C⁺CCR2⁺ macrophage influx (E32) | Inverse: 19.0 vs 3.4 ×10⁵ with 212 vs 344 | — | — | d5 | — | **Ruled out** |
| Tfh:Tfr ratio (S04-B) | — | — | — | — | — | **Ruled out**: just a transform of Foxp3% (I07) |
| Nasal / mucosal IgA | **Not measured** | — | — | — | Yes (nasal wash) | **Gap: must be added** |

**Could it go into patients, and in what role?**

Yes. Nasal lining fluid (IFN-β, IFN-λ, CXCL10) and a whole-blood ISG score 6–24 h after dosing are minimally invasive *[external context]*. Four roles:

1. **Phase 1 dose selection.**
   - In mice the curve plateaus between 20 and 40 µg (×1.09, p = 0.55) (E21).
   - The human dose should be the lowest one that reaches the plateau. That limits Mn exposure.
2. **Test of the central hypothesis.**
   - Does Mn²⁺ bring the IFN response of adults aged ≥65 to the level seen in 18–49-year-olds? This is the human version of E20.
   - If it does not, the rationale for Mn²⁺ fails early and cheaply.
3. **Reactogenicity sentinel.** Excess systemic ISG or IL-6 would flag a safety problem.
4. **Lot potency assay.** In vitro IFN-β/ISG induction can serve as a lot-release assay.

**What it must not be used for:**
- It should not be a registrational surrogate or a patient-selection tool, because IFN-β is over-restored relative to protection.
- Those uses first require individual-animal and then individual-participant linkage to outcome (Study S2; Phase 2 correlates).

**Translation caveat:** the mouse marker is *Ifnb1* mRNA in lung tissue, while humans would be sampled from the nose and blood. The NHP bridge (S5) must show that the nasal and blood signal tracks the lung.

---

## 7. Forward plan: what the next studies must establish

**Studies in gate order** (timing in months from the decision; see Fig. 5).

![Fig. 5. Gated forward plan.](figures/fig5_forward_plan_timeline.png)

**G0. Data reconstruction and QA audit (months 0–2)**
- **Must establish:** that the core results exist in primary records.
- **Population and scope:** all findings I01–I20.
- **What is compared:** primary records against the workbook. Records to retrieve:
  - death and euthanasia logs with humane-endpoint criteria;
  - balance and LIMS weight records;
  - FCS files and gating templates;
  - ELISA, HAI and microneutralisation plate exports;
  - qPCR run files;
  - randomisation records;
  - health reports for the aged colony.
- **Readouts:** a locked, verified dataset; independent re-analysis under this memo's pre-specified methods.
- **Go / kill:**
  - **Go** if S06-A, B, C, E, F and G and the key immunogenicity blocks (S01-A, S03-A–H, S05) verify.
  - **Stop** if core survival cannot be verified: repeat the core study before any other spend.
  - **Refer to research-integrity review** if I01, I04 or I05 are not transcription errors.

**S1. Confirmatory aged-mouse efficacy against benchmarks, blinded and randomised (months 2–10; day-180 arm to month 12)**
- **Must establish:** that the effect replicates, holds in both sexes and two strains, is achieved with a clinical-type antigen, and is competitive with standard of care.
- **Population:**
  - aged BALB/c and C57BL/6, 20–22 months, **both sexes**, from health-monitored colonies;
  - young references;
  - unvaccinated, unchallenged aged sentinels to measure background deaths.
- **Arms and comparators:**
  - clinical-type split or subunit antigen, given intranasally with sham, with PSLN-212 20 µg, or with PSLN-344 at 5, 10 and 20 µg;
  - **MF59-type emulsion, intramuscular** (AddaVax, standing in for Fluad);
  - **high-dose antigen, intramuscular** (4×, standing in for high-dose licensed vaccine);
  - PSLN-344 alone, without antigen;
  - young mice given PSLN-212 or PSLN-344.
- **Challenges:** homologous H1N1 (CA09) and heterosubtypic H5N1 and H3N2 (Perth), at days 14, 90 and 180.
- **Endpoints and readouts:**
  - *Primary:* 14-day survival, with a pre-defined humane endpoint and cause of death recorded; lung viral titre at days 3 and 5 (satellite animals).
  - *Secondary:* weight area-under-curve; clinical score.
  - *Immunology:*
    - HAI and microneutralisation against the vaccine and challenge strains;
    - NA inhibition;
    - stalk, NP and M2e antibodies;
    - nasal-wash and BAL IgA;
    - IFN-γ ELISpot to NP/M1 peptides;
    - lung resident-memory T cells.
- **Sample size (E17):**
  - Survival vs PSLN-212: about 30 per arm, assuming a shrunk effect of 35% vs 75% mortality (84% power).
  - Survival vs a benchmark (30% vs 60% mortality) would need about 50 per arm, so benchmark comparisons are powered on viral titre instead: 15 per arm detects a 1.0-log10 difference (SD 0.8) at 90% power.
  - Run as 2 or more independent cohorts with pooling pre-specified.
- **Go:** PSLN-344 beats PSLN-212 on survival and viral titre in both sexes and both strains; is non-inferior to the best benchmark against homologous virus; is superior against heterosubtypic virus; and works at ≤20 µg.
- **Kill:** the effect does not replicate, **or** there is no advantage over the benchmark against heterosubtypic virus (the differentiation thesis fails).

**S2. Mechanism and individual-animal biomarker linkage (months 3–10)**
- **Must establish:** which immune arm causes protection, and whether the early IFN marker predicts outcome in individual animals.
- **Population:** aged BALB/c, both sexes.
- **Interventions:**
  - anti-CD8β, anti-CD4 or isotype control at challenge (days 14 and 60);
  - FTY720 during challenge, to separate resident from circulating T cells;
  - transfer of immune serum into naive aged mice, then homologous vs heterosubtypic challenge;
  - IFNAR-blocking antibody around vaccination;
  - STING-deficient mice;
  - liposomes containing Mn²⁺ but no CDN.
- **Endpoints:** survival and lung viral titre.
- **Linkage:** in every animal, measure nasal-wash IFN-β and CXCL10 at 16–24 h, a blood ISG score at 24 h, and HAI, microneutralisation and ELISpot at day 14; then challenge. Analyse with logistic and Cox models, ROC curves and mediation analysis.
- **Go:** CD8 depletion removes heterosubtypic protection, and the early IFN marker predicts an individual's outcome.
- **If not:** rewrite the breadth claim and the biomarker role.

**S3a. Mn²⁺ biodistribution and neuro pilot, non-GLP (months 2–8)**
- **Must establish:** whether intranasal Mn reaches the brain or olfactory system and causes harm.
- **Population:** aged and young mice; rats.
- **Arms:** PSLN-344 at 1×, 3× and 10× the efficacious dose; PSLN-212; equimolar MnCl₂ given intranasally; vehicle. Single dose and 3 doses.
- **Readouts (days 1, 7, 28 and 90):**
  - ICP-MS Mn in olfactory bulb, striatum, globus pallidus, trigeminal ganglion, turbinates, lung, liver and blood;
  - T1-weighted MRI;
  - histopathology of olfactory epithelium and bulb and of the facial and trigeminal nerves;
  - glial markers GFAP and Iba1;
  - smell and motor tests;
  - serum IL-6, CXCL10 and IFN.
- **Kill or reformulate:** Mn above vehicle in the olfactory bulb or basal ganglia at the efficacious dose **together with** pathology or a functional deficit.

**S4. CMC (months 0–12)**
- **Must establish:** a product that can be controlled and released.
- **Scope:**
  - Mn content per dose and free Mn²⁺ specification (neither is in the dataset);
  - encapsulation efficiency, currently 54.8 ± 5.1% (E53);
  - size, polydispersity, zeta potential and morphology (the annotation says these were measured, but they are not in the file);
  - stability of the lyophilised product;
  - nasal device deposition;
  - compatibility with the clinical antigen;
  - an in vitro IFN-β potency assay.
- **Go:** release specifications set and stability adequate for the clinic.

**S5. Aged non-human primate bridge (months 11–19)**
- **Must establish:** that the PD marker translates, and show primate safety and immunogenicity.
- **Population:** aged rhesus macaques (≥18 years) vs young adults.
- **Arms:** PSLN-344 plus clinical antigen intranasally, vs an MF59-type intramuscular vaccine.
- **Readouts:**
  - nasal and blood ISG at 6–24 h: does this track the mouse lung marker?
  - HAI and microneutralisation;
  - nasal IgA;
  - BAL T cells and resident memory;
  - olfactory-bulb MRI and blood Mn.
- **Go:** the aged PD response reaches the young level with no safety signal.

**S3b. GLP toxicology (months 11–20)**
- **Must establish:** a NOAEL and a safety margin for Mn.
- **Population:** rat plus a second species (for example rabbit).
- **Design:** repeat intranasal dosing (n + 1 doses) with recovery groups.
- **Readouts:** full neuropathology including olfactory and facial nerves; Mn toxicokinetics; nasal local tolerance; cytokines.
- **Go:** an adequate exposure margin.

**Phase 1, first-in-human (months 23–36)**
- **Must establish:** safety, the PD "age-gap closure", and benchmark-level immunogenicity.
- **Population:**
  - Part A: ages 18–49, sentinel dose escalation over 3 levels;
  - Part B: ages ≥65, stratified 65–74 and ≥75.
  - Exclusions: prior facial palsy, olfactory or neurological disease, hepatic impairment, occupational Mn exposure.
- **Arms:** licensed antigen intranasally with PSLN-344 at each dose level; antigen intranasally with empty liposome; a **licensed older-adult intramuscular vaccine** as active benchmark.
- **Endpoints:**
  - *Safety:* solicited reactions over 7 days; unsolicited events over 28 days; adverse events of special interest (facial palsy, smell loss by UPSIT, neurological events); blood Mn; MRI pallidal index in a subset.
  - *PD:* nasal and blood ISG at 6–24 h.
  - *Immunogenicity:* HAI and microneutralisation GMT, seroconversion and seroprotection at days 28 and 180; nasal IgA; NP/M1 ELISpot at days 14 and 180; circulating Tfh at day 7.
- **Go to Phase 2 (challenge model or field efficacy, with correlates) if all of the following hold:**
  - safety is acceptable;
  - PD in the ≥65 group reaches the 18–49 level;
  - HAI is non-inferior to the intramuscular benchmark;
  - the mucosal or T-cell response adds breadth.

**Clinical role if it succeeds**
- **Lead role:** an **intranasal broadening booster used alongside licensed intramuscular vaccination** in adults aged ≥65. It would aim for heterosubtypic and mucosal protection that intramuscular products do not claim.
- **Secondary role:** a pandemic-preparedness and outbreak adjuvant (H5N1). This is supported by protection within 2–3 days of dosing when antigen is given (E06b, E09, E12).
- **Stand-alone seasonal replacement** for licensed older-adult vaccines would first have to beat them head-to-head (S1, then Phase 1/2).

---

## 8. If we drop it: what we are dropping and why

**What we would be dropping**
- The only formulation in our data that converts a failing adjuvant in aged mice (38/42 deaths) into a protective one (10/42). That protection extends to mismatched challenge (20/28 survived), day-3 challenge and day-60 challenge (E01, E06a–e).
- A specific mechanistic lever: Mn²⁺ brings the aged lung's type-I-IFN response back to the young level (E20). This insight applies to any adjuvant aimed at older adults.
- A fast-onset, cross-subtype profile (E06b, E12) that licensed intramuscular older-adult vaccines are not designed to provide *[external context]*.

**Why dropping could be defended**
- **Data integrity:** the findings are serious enough that the package needs a confirmatory study regardless (I01–I05).
- **Intranasal Mn²⁺ safety:** the risk is plausible and unmitigated. Intranasal manganese reaches the olfactory bulb, and an intranasal adjuvanted flu vaccine was withdrawn over facial palsy *[external context]*. Our only CNS data are transcript levels at a single 36-h timepoint (E51).
- **No benchmark:** the comparison against standard of care is unanswered.

**What to keep even if dropped**
- Reconcile and archive the data.
- Publish or patent the Mn–IFN finding.
- Keep the aged-challenge model and the early-IFN PD assay for screening other adjuvants.
- Consider out-licensing.

---

## 9. What I considered and ruled out

**Table 6. Alternatives considered and their verdicts.**

| Considered | Evidence | Verdict |
|---|---|---|
| Advance PSLN-212 instead (no Mn, simpler safety) | Aged: 38/42 deaths, mortality not different from sham; HAI GMT 46 (E01, E03, E41a) | Ruled out for older adults. It works in young mice (0/24 deaths; E13), but they are not the target population |
| CMP-204 (cGAMP liposome) as a backup | IFN-β 7.7-fold vs 16.5-fold for PSLN-212 (S01-A, GM of 5); HAI GMT 23 (S03-C); 3/7 survived (S03-I, a conflicted block) | Ruled out |
| R848 combinations | PSLN-212/R848: *Tnf* 202-fold and *Il10* 179-fold; weight nadir 90.0%; one animal missing at day 10; no efficacy data (E50, E52) | Ruled out: reactogenic and no efficacy evidence |
| Raising the PSLN-212 dose instead of adding Mn | PSLN-212 at 40 µg gives 14.7-fold IFN-β, below PSLN-344 at 10 µg (21.0-fold) (E21) | Ruled out: the Mn effect is not a dose effect |
| Going above 20 µg PSLN-344 | 40 vs 20 µg gives ×1.09 IFN-β (p = 0.55) (E21) | Ruled out: no PD gain and more Mn |
| Mn works by increasing particle uptake | Mn particles show about 4-fold *lower* epithelial uptake (E31) | Ruled out (caveat I12) |
| Protection is a non-specific innate antiviral state | Adjuvant alone: 0/7 survived day-3 challenge (E12) | Ruled out |
| Vaccine-strain HA antibody explains all protection | 4 of 6 core challenges have no HA or NA match; 20/28 survived (E06e) | Ruled out as the sole mechanism (inference) |
| DC co-stimulation as the limiting aged defect, or as a biomarker | Restoration 0.17–0.22 vs survival 0.74 (E25, E47) | Ruled out |
| Early IFN-β as an efficacy surrogate | Restoration 0.98 vs survival 0.74; day 60, 0.65 | Ruled out as a surrogate; **kept as PD marker** |
| Human HAI 1:40 as the protective threshold in this model | Aged PSLN-212 8/10 ≥1:40 but not protected; PSLN-344 10/10 ≥1:160 (E41c) | Ruled out |
| "PSLN-344 restores aged mice to young" | Residual gap +23.8 pp; day 60, 7/21 vs 0/21; adaptive readouts 0.56–0.68 restored (E07, E47) | Ruled out as worded. "Substantially narrows the gap" is defensible |
| Prior immunity blunts PSLN-344 | 1/7 deaths in both naive and imprinted mice, for both challenges (E10; 14-month mice) | Ruled out in this model |
| Boosting with PSLN-212 as the fix | After boost, PSLN-212 gap vs PSLN-344 is ×3.5 for CA09 but ×11.5 for Aichi; no challenge data (E43) | Not supported |
| Neuro-inflammatory (facial-palsy-type) risk | No CNS *Ifnb1*, *Tnf* or *Isg15* induction at 36 h; cholera toxin 2.7–5.5-fold (E51) | **Not ruled out**: reassuring, but one timepoint, transcripts only, no Mn measurement |
| Body-weight curves as an efficacy endpoint | Dead animals handled inconsistently; trajectories copied (I04, I13) | Ruled out; weights used only to cross-check deaths |
| Pooling S06-D, S11-A/B, S07-C, S03-B/F, the Tfh:Tfr ratio, S03-I, S03-J | Integrity findings (Appendix A) | Excluded, or sensitivity analysis only |

---

## 10. Limitations

**Scale and design**
- All evidence is from mice, mostly female BALB/c.
- n = 3–10 per group; most experiments were run once. Per-experiment power is about 57% for the observed effect (E16).

**Inference**
- Mechanistic inference is group-level, and no readout is linked to survival in the same animals.
- Comparisons with young mice confound age with formulation: the young reference received PSLN-212, not PSLN-344.
- Intervention experiments were partly in young mice (E28) or of unstated age (E27, E26).

**Missing data**
- Several timepoints and challenge details are not stated (I19).
- Mn dose, particle characterisation and stability data are absent (E53).

**Integrity**
- The efficacy conclusion is robust to every exclusion scenario tested (Table 2), but these tests cannot detect problems that leave no internal trace. Gate 0 exists for that reason.

---

## Appendix A: Integrity register (summary; full cell references in sheet `Integrity_register`)

| ID | Severity | Finding | Handling |
|---|---|---|---|
| I01 | Critical | S06-C (day-14 challenge) and S06-D (day-3 challenge) are identical in all 28 animal rows. S06-D's own weight data imply 2/7 deaths with PSLN-344 and 2/7 in young mice | S06-D excluded; sensitivity analysis E04b |
| I02 | Critical | S03-I records 7/7 PSLN-212 deaths on days 5–6. Its companion weights (S13-F) run to day 14 for all 7 animals (4 frozen, 3 recovering). A sham animal recorded dead on day 5 still has a day-6 weight (all 7 sham weights present at day 6). S13-F has "Naive" in place of CMP-204 | Excluded from primary; sensitivity E04c |
| I03 | Critical | S03-J and its weight block have different group sets. Sham deaths 9/10 recorded vs 5/10 implied by weights. Stated n 9 vs 10 rows; one row has no time; age not stated | Excluded from pooling |
| I04 | Critical | Weight trajectories copied across experiments and strains. Examples: S15-C ≡ S15-I (40/42 animal-days); S09-E ≡ S15-M (8–10-digit values); S15-M ≡ S15-O sham across strains; fractional parts reused with shifted integers. Chance expectation 0.013 matching pairs; observed 18 | Weights not used as corroboration where affected; strain data unverified |
| I05 | Critical | S11-A (alveolar macrophages) and S11-B (neutrophils) share 35 of 100 per-animal values | Both excluded |
| I06 | Major | S03-B and S03-F contain the S13 subclass ratios with group labels rotated | S13 used |
| I07 | Major | S04-B "Tfh:Tfr" equals (100 − Foxp3%)/Foxp3% | Not independent |
| I08 | Major | S07-C has identical labels on two different macrophage subsets | Excluded |
| I09 | Major | S09-A panel 2, labelled 16 h, is the 72-h data. Its "PBS" group holds the "Sham" values. S09-A re-presents S01-A | Relabelled; not counted as independent |
| I10 | Major | S09-C day-12 weights are identical across two arms (8/8) | Weights not used |
| I11 | Major | Unchallenged aged controls died 4/21 within 14 days | Colony health must be resolved |
| I12 | Major | S01-B and S08-C share control values; AT1 uptake differs 3.6-fold between them | Caveat on E31 |
| I13 | Major | Dead animals' weights are carried forward in treated arms but dropped in sham arms | Group means not computed |
| I14–I20 | Minor | n mismatches; conflicting condition text; undefined preparation (PSLN-344/R848); unlabelled region S08 rows 89–101; unstated timepoints, ages and challenges; one duplicated value | Flagged where used |

![Fig. 4. Data-integrity exhibits.](figures/fig4_integrity_exhibits.png)

## Appendix B: Figures (folder `figures/`)

- **Fig. 1.** Survival by experiment (aged).
- **Fig. 2.** Restoration fractions across the immune cascade and for survival.
- **Fig. 3.** Per-animal values for key readouts.
- **Fig. 4.** Data-integrity exhibits (S06-C ≡ S06-D; S15-C ≡ S15-I; S11-A vs S11-B).
- **Fig. 5.** Gated forward plan.

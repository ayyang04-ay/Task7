# PSLN-344 portfolio review: deliverables

| File | What it is |
|---|---|
| `PSLN-344_portfolio_review_memo.pdf` / `.docx` / `.md` | The committee brief. It covers the recommendation, efficacy, immunogenicity, drivers of protection, biomarker, gated forward plan, what would be dropped, and what was ruled out. Every number carries a ledger ID. |
| `PSLN-344_evidence_ledger.xlsx` | The traceability workbook. `Evidence_ledger` (E##) and `Integrity_register` (I##) give each number's sheet!cell source, reduction and test. The analysis tables are in `Survival_*`, `Readouts_stats`, `Restoration_fractions`, `Weight_vs_survival` and `Dup_trajectories`. Every raw per-animal value with its cell address is in `Raw_values_long` and `Raw_survival_long`. |
| `figures/` | Fig. 1 survival by experiment; Fig. 2 restoration fractions; Fig. 3 key per-animal readouts; Fig. 4 integrity exhibits; Fig. 5 forward-plan timeline. |
| `code/` | Reproducible pipeline. `run_all.sh` rebuilds everything from `adjuvant_program_dataset.xlsx` (about 7 min). `verify_memo_numbers.py` recomputes 39 key memo numbers from the raw cells and checks that they appear verbatim in the memo (current result: 0 failures). |

## Recommendation

**Advance, conditionally.**
- Approve Gate 0 (about 2 months of data reconstruction and QA).
- Then approve Gate 1 (about 8 months): a blinded confirmatory aged-mouse study against licensed-type benchmarks, CD8/serum/IFNAR mechanism studies, and an Mn²⁺ biodistribution and neuro pilot.
- Do not start GLP toxicology, GMP manufacture or an IND until the Gate 1 criteria are met.

## Headline numbers (aged mice, six core challenge experiments)

- **Deaths:** 10/42 with PSLN-344 vs 38/42 with the otherwise-identical Mn-free PSLN-212.
- **Effect size:** risk difference −66.7 percentage points (95% CI −81.4 to −51.9); exact stratified p = 3.0 × 10⁻¹⁰.
- **Robustness:** the result holds in the four experiments whose compared arms are free of integrity findings: 9/28 vs 27/28 deaths.

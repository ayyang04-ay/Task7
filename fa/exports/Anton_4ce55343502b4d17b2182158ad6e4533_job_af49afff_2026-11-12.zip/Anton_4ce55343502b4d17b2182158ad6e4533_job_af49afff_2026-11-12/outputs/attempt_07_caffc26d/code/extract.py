"""
Provenance-preserving extraction of the PSLN-344 workbook.
Every value is stored with sheet + cell address so any number in the report
can be traced back to the workbook.
Outputs: /tmp/work/values_long.csv  (continuous measurements)
         /tmp/work/survival_long.csv (time-to-event, one row per animal)
"""
import openpyxl, pandas as pd, re
from openpyxl.utils import get_column_letter as L, column_index_from_string as CI

WB = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
wb = openpyxl.load_workbook(WB, data_only=True)

vals = []   # dict(block, sheet, group, level, rep, value, cell)
surv = []   # dict(block, sheet, group, time, event, cell_time, cell_event)

def v(ws, r, c):
    return ws.cell(row=r, column=c).value

def add(block, sheet, group, level, rep, value, cell):
    if value is None: return
    vals.append(dict(block=block, sheet=sheet, group=str(group).strip(), level=level,
                     rep=rep, value=float(value), cell=cell))

# ---------- generic layouts ----------
def rows_are_groups(block, sheet, label_col, val_cols, rows, level=None):
    """group label in label_col, replicate values across val_cols (letters) on each row"""
    ws = wb[sheet]
    for r in rows:
        g = v(ws, r, CI(label_col))
        for i, c in enumerate(val_cols):
            add(block, sheet, g, level, i+1, v(ws, r, CI(c)), f'{c}{r}')

def cols_are_groups(block, sheet, header_row, cols, rows, level=None):
    """group label in header row, replicate values going down rows"""
    ws = wb[sheet]
    for c in cols:
        g = v(ws, header_row, CI(c))
        for i, r in enumerate(rows):
            add(block, sheet, g, level, i+1, v(ws, r, CI(c)), f'{c}{r}')

def grouped_wide(block, sheet, header_row, group_starts, width, rows, level_col='A', level_name=None):
    """merged header: group label at group_starts letter, `width` replicate columns;
    one row per level (day/dose) with level value in level_col"""
    ws = wb[sheet]
    for gs in group_starts:
        g = v(ws, header_row, CI(gs))
        for r in rows:
            lvl = v(ws, r, CI(level_col)) if level_col else None
            for k in range(width):
                c = CI(gs) + k
                add(block, sheet, g, lvl, k+1, v(ws, r, c), f'{L(c)}{r}')

def survival(block, sheet, header_row, day_col, group_cols, rows):
    ws = wb[sheet]
    for r in rows:
        t = v(ws, r, CI(day_col))
        for gc in group_cols:
            e = v(ws, r, CI(gc))
            if e is not None:
                surv.append(dict(block=block, sheet=sheet, group=str(v(ws, header_row, CI(gc))).strip(),
                                 time=t, event=int(e), cell_time=f'{day_col}{r}', cell_event=f'{gc}{r}'))

# ---------- S01 ----------
rows_are_groups('S01-A_16h','S01','A',list('BCDEF'),range(3,11),'16h')
rows_are_groups('S01-A_72h','S01','G',list('HIJKL'),range(3,11),'72h')
rows_are_groups('S01-B','S01','A',list('BCDEF'),range(14,18))
rows_are_groups('S01-C','S01','A',list('BCDE'),range(20,22))
grouped_wide('S01-D','S01',23,['B','G','L','Q'],5,range(24,29))
grouped_wide('S01-E','S01',29,['B','G','L','Q','V'],5,range(30,35))
grouped_wide('S01-F','S01',35,['B','G','L','Q','V'],5,[36],level_col=None)
grouped_wide('S01-G','S01',37,['B','G','L','Q','V'],5,[38],level_col=None)
# ---------- S02 ----------
cols_are_groups('S02-A','S02',2,list('ABCD'),range(3,8))
cols_are_groups('S02-B','S02',2,list('FGHI'),range(3,8))
cols_are_groups('S02-C','S02',2,list('KLMNO'),range(3,8))
cols_are_groups('S02-D_CD40','S02',9,list('ABCD'),range(10,15))
cols_are_groups('S02-D_CD86','S02',9,list('FGHI'),range(10,15))
cols_are_groups('S02-E','S02',9,list('KLMNO'),range(10,15))
grouped_wide('S02-F','S02',16,['B','G','L'],5,range(17,20))
cols_are_groups('S02-G','S02',21,list('BCD'),range(22,27))
cols_are_groups('S02-H','S02',29,list('BCDEF'),range(30,35))
cols_are_groups('S02-I','S02',29,list('HI'),range(30,35))
# ---------- S03 ----------
cols_are_groups('S03-A','S03',2,list('ABCDE'),range(3,8))
cols_are_groups('S03-B','S03',2,list('GHI'),range(3,8))
cols_are_groups('S03-C','S03',2,list('KLMNO'),range(3,8))
cols_are_groups('S03-D','S03',2,list('QRSTU'),range(3,8))
cols_are_groups('S03-E','S03',9,list('ABCDE'),range(10,15))
cols_are_groups('S03-F','S03',9,list('GHI'),range(10,15))
cols_are_groups('S03-G','S03',9,list('KLMNO'),range(10,15))
cols_are_groups('S03-H','S03',9,list('QRSTU'),range(10,15))
survival('S03-I','S03',16,'A',list('BCDEF'),range(17,52))
survival('S03-J','S03',16,'G',list('HIJ'),range(17,47))
cols_are_groups('S03-K','S03',16,list('LMNO'),range(17,22))
rows_are_groups('S03-L_Aicda','S03','K',list('LMN'),range(26,29))
rows_are_groups('S03-L_E47','S03','K',list('OPQ'),range(26,29))
# ---------- S04 ----------
rows_are_groups('S04-A_ICOSlo','S04','A',list('BCDEF'),range(2,6))
rows_are_groups('S04-A_ICOShi','S04','A',list('GHIJK'),range(2,6))
cols_are_groups('S04-B_Foxp3','S04',7,list('ABCD'),range(8,13))
cols_are_groups('S04-B_TfhTfr','S04',14,list('ABCD'),range(15,20))
cols_are_groups('S04-C','S04',21,list('ABCD'),range(22,27))
cols_are_groups('S04-D','S04',28,list('ABCD'),range(29,32))
# ---------- S05 ----------
grouped_wide('S05-A','S05',2,['B','E','H'],2,range(3,6))
grouped_wide('S05-B','S05',7,['B','E','H'],2,range(8,11))
cols_are_groups('S05-C','S05',12,list('ABCD'),range(13,16))
for blk,h in [('S05-D',18),('S05-E',25),('S05-F',32),('S05-G',39),('S05-H',46),('S05-I',53)]:
    cols_are_groups(blk,'S05',h,list('ABCD'),range(h+1,h+6))
# ---------- S06 (survival) ----------
survival('S06-A','S06',2,'A',list('BCDE'),range(3,31))
survival('S06-B','S06',2,'G',list('HIJK'),range(3,31))
survival('S06-C','S06',2,'M',list('NOPQ'),range(3,31))
survival('S06-D','S06',33,'A',list('BCDE'),range(34,69))
survival('S06-E','S06',33,'G',list('HIJKL'),range(34,69))
survival('S06-F','S06',33,'M',list('NOPQR'),range(34,69))
survival('S06-G','S06',70,'A',list('BCDEF'),range(71,106))
survival('S06-E_imprint','S06',70,'G',list('HIJK'),range(71,106))
survival('S06-F_imprint','S06',70,'M',list('NOPQ'),range(71,106))
# ---------- S07 ----------
grouped_wide('S07-A','S07',2,['B','E'],3,range(3,8))
cols_are_groups('S07-B_mono','S07',9,list('BC'),range(10,15))
cols_are_groups('S07-B_Ly6Cmac','S07',9,list('EF'),range(10,15))
ws=wb['S07']
for i,r in enumerate(range(16,21)):
    add('S07-C','S07','colB:'+str(v(ws,15,2)),None,i+1,v(ws,r,2),f'B{r}')
    add('S07-C','S07','colC:'+str(v(ws,15,3)),None,i+1,v(ws,r,3),f'C{r}')
# ---------- S08 ----------
grouped_wide('S08-A','S08',2,['B','E','H','K'],3,range(3,8))
grouped_wide('S08-B','S08',10,['A','D','G','J','M'],3,[11],level_col=None)
cols_are_groups('S08-C','S08',13,list('ABCD'),range(14,19))
grouped_wide('S08-D','S08',20,['B','G','L','Q','V','AA'],5,range(21,27))
# ---------- S09 ----------
ws=wb['S09']
for panel,lab,starts in [('S09-A_panel1','A',['B','E','H','K','N','Q','T']),('S09-A_panel2','X',['Y','AB','AE','AH','AK','AN','AQ'])]:
    for r in range(3,10):
        an=v(ws,r,CI(lab))
        for gs in starts:
            g=v(ws,2,CI(gs))
            for k in range(3):
                c=CI(gs)+k
                add(panel,'S09',g,an,k+1,v(ws,r,c),f'{L(c)}{r}')
survival('S09-B','S09',11,'A',list('BCD'),range(12,36))
grouped_wide('S09-C','S09',11,['G','O','W'],8,range(12,20),level_col='F')
survival('S09-D','S09',38,'A',list('BCD'),range(39,63))
grouped_wide('S09-E','S09',38,['G','O','W'],8,range(39,47),level_col='F')
survival('S09-F','S09',65,'A',list('BCD'),range(66,89))
grouped_wide('S09-G','S09',65,['G','O','W'],8,range(66,74),level_col='F')
# ---------- S10 ----------
cols_are_groups('S10-A_Ifnb1','S10',2,list('ABCD'),range(3,8))
cols_are_groups('S10-A_Tnf','S10',2,list('FGHI'),range(3,8))
cols_are_groups('S10-A_Isg15','S10',2,list('KLMN'),range(3,8))
# ---------- S11 ----------
grouped_wide('S11-A','S11',2,['B','G','L','Q'],5,range(3,8))
grouped_wide('S11-B','S11',9,['B','G','L','Q'],5,range(10,15))
cols_are_groups('S11-C','S11',16,list('AB'),range(17,22))
grouped_wide('S11-D','S11',23,['B','G','L','Q'],5,range(24,29))
cols_are_groups('S11-E','S11',30,list('ABCD'),range(31,36))
# ---------- S12 ----------
cols_are_groups('S12-A','S12',2,list('AB'),range(3,6))
# ---------- S13 ----------
cols_are_groups('S13-A','S13',2,list('ABC'),range(3,8))
cols_are_groups('S13-B','S13',2,list('EFG'),range(3,8))
cols_are_groups('S13-C','S13',2,list('IJK'),range(3,8))
cols_are_groups('S13-D','S13',2,list('MNO'),range(3,8))
survival('S13-E','S13',2,'R',list('STUV'),range(3,31))
grouped_wide('S13-F','S13',32,['B','I','P','W','AD'],7,range(33,41))
grouped_wide('S13-G','S13',42,['B','L','V'],10,range(43,51))
cols_are_groups('S13-H','S13',52,list('ABCD'),range(53,58))
cols_are_groups('S13-I','S13',52,list('FGHIJ'),range(53,58))
cols_are_groups('S13-J','S13',52,list('LMNOP'),range(53,58))
# ---------- S14 ----------
cols_are_groups('S14-A_H1N1','S14',2,list('ABCD'),range(3,8))
cols_are_groups('S14-A_H3N2','S14',2,list('FGHI'),range(3,8))
# ---------- S15 ----------
for blk,h in [('S15-A',2),('S15-B',12),('S15-C',22),('S15-D',32)]:
    grouped_wide(blk,'S15',h,['B','I','P','W'],7,range(h+1,h+9))
for blk,h in [('S15-E',42),('S15-F',52),('S15-G',62)]:
    grouped_wide(blk,'S15',h,['B','I','P','W','AD'],7,range(h+1,h+9))
survival('S15-H','S15',72,'A',list('BCD'),range(73,94))
grouped_wide('S15-I','S15',71,['I','P','W'],7,range(72,80),level_col='H')
grouped_wide('S15-J','S15',82,['I','P','W','AD'],7,range(83,91),level_col='H')
grouped_wide('S15-K','S15',92,['I','P','W','AD'],7,range(93,101),level_col='H')
survival('S15-L','S15',102,'A',list('BCDE'),range(103,131))
grouped_wide('S15-M','S15',102,['I','P','W','AD'],7,range(103,111),level_col='H')
survival('S15-N','S15',133,'A',list('BCDE'),range(134,162))
grouped_wide('S15-O','S15',133,['I','P','W','AD'],7,range(134,142),level_col='H')

V = pd.DataFrame(vals); S = pd.DataFrame(surv)
# normalise group labels
def norm(g):
    g = g.replace('Naïve','Naive').replace('  ',' ').strip()
    g = re.sub(r'\(y\)$','(Y)',g); g = re.sub(r'(PSLN-\d+)Y$',r'\1(Y)',g)
    return g
V['group_norm']=V.group.map(norm); S['group_norm']=S.group.map(norm)
V.to_csv('/tmp/work/values_long.csv',index=False); S.to_csv('/tmp/work/survival_long.csv',index=False)
print(V.shape, S.shape)
print(V.groupby('block').size().to_string())
print(S.groupby(['block','group_norm']).agg(n=('event','size'),deaths=('event','sum')).to_string())

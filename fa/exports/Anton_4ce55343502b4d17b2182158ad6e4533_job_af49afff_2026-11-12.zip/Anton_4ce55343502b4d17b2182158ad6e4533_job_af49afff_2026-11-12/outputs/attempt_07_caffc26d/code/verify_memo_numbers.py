"""Recompute key memo numbers from the raw per-animal extraction and check they appear verbatim in the memo."""
import pandas as pd, numpy as np, re
V=pd.read_csv('/tmp/work/values_long.csv'); S=pd.read_csv('/tmp/work/survival_long.csv')
V.loc[(V.block.isin(['S03-C','S03-G']))&(V.value==0),'value']=5.0
memo=open('/tmp/outputs/PSLN-344_portfolio_review_memo.md').read()
def gm(b,g,l=None):
    d=V[(V.block==b)&(V.group_norm==g)]
    if l is not None: d=d[d.level.astype(str)==str(l)]
    return 10**np.log10(d.value).mean()
def mn(b,g,l=None):
    d=V[(V.block==b)&(V.group_norm==g)]
    if l is not None: d=d[d.level.astype(str)==str(l)]
    return d.value.mean()
def deaths(blocks,g): d=S[S.block.isin(blocks)&(S.group_norm==g)]; return f"{int(d.event.sum())}/{len(d)}"
core=['S06-A','S06-B','S06-C','S06-E','S06-F','S06-G']
checks=[
 ('core deaths PSLN-344', deaths(core,'PSLN-344'), '10/42'),
 ('core deaths PSLN-212', deaths(core,'PSLN-212'), '38/42'),
 ('core deaths sham', deaths(core,'Sham'), '42/42'),
 ('core deaths young', deaths(core,'PSLN-212(Y)'), '0/42'),
 ('clean tier 344', deaths(['S06-B','S06-E','S06-F','S06-G'],'PSLN-344'), '9/28'),
 ('clean tier 212', deaths(['S06-B','S06-E','S06-F','S06-G'],'PSLN-212'), '27/28'),
 ('d60 344', deaths(['S06-E','S06-F','S06-G'],'PSLN-344'), '7/21'),
 ('d60 212', deaths(['S06-E','S06-F','S06-G'],'PSLN-212'), '20/21'),
 ('d14 344', deaths(['S06-A','S06-C'],'PSLN-344'), '1/14'),
 ('d14 212', deaths(['S06-A','S06-C'],'PSLN-212'), '11/14'),
 ('untreated', deaths(['S06-E','S06-F','S06-G'],'Untreated'), '4/21'),
 ('IFNb 212 aged', f"{gm('S01-A_16h','PSLN-212'):.1f}", '16.5'),
 ('IFNb 344 aged', f"{gm('S01-A_16h','PSLN-344'):.1f}", '36.9'),
 ('IFNb 212 young', f"{gm('S01-A_16h','PSLN-212(Y)'):.1f}", '37.5'),
 ('IFNb aged/young', f"{gm('S01-A_16h','PSLN-212')/gm('S01-A_16h','PSLN-212(Y)'):.2f}", '0.44'),
 ('IFNb ratio', f"{gm('S01-A_16h','PSLN-344')/gm('S01-A_16h','PSLN-212'):.2f}", '2.23'),
 ('IgG CA09 344', f"{gm('S03-A','PSLN-344'):,.0f}", '7,305'),
 ('IgG CA09 212', f"{gm('S03-A','PSLN-212'):.0f}", '393'),
 ('IgG CA09 ratio', f"{gm('S03-A','PSLN-344')/gm('S03-A','PSLN-212'):.1f}", '18.6'),
 ('HAI CA09 344', f"{gm('S03-C','PSLN-344'):.0f}", '368'),
 ('HAI CA09 212', f"{gm('S03-C','PSLN-212'):.0f}", '46'),
 ('HAI Aichi 344', f"{gm('S03-G','PSLN-344'):.0f}", '320'),
 ('neut CA09 344', f"{gm('S03-D','PSLN-344'):,.0f}", '3,840'),
 ('IgG Aichi d28 344', f"{gm('S13-J','PSLN-344'):,.0f}", '12,435'),
 ('IgG Aichi d28 Y', f"{gm('S13-J','PSLN-212(Y)'):,.0f}", '43,472'),
 ('GC B 344', f"{mn('S03-K','PSLN-344'):.1f}", '6.5'),
 ('Tfr 212', f"{mn('S04-B_Foxp3','PSLN-212'):.1f}", '26.7'),
 ('IFNg d14 344', f"{mn('S05-F','PSLN-344'):.1f}", '6.4'),
 ('IFNg d60 Y', f"{mn('S05-G','PSLN-212(Y)'):.1f}", '14.4'),
 ('TRM Y', f"{mn('S05-I','PSLN-212(Y)'):.1f}", '6.0'),
 ('CD40 Y', f"{mn('S02-D_CD40','PSLN-212(Y)'):.1f}", '38.7'),
 ('Gm-csf 36h ratio', f"*Gm-csf* {gm('S02-F','PSLN-344','36h')/gm('S02-F','PSLN-212','36h'):.1f}-fold", '*Gm-csf* 5.4-fold'),
 ('AT2 uptake', f"{mn('S08-C','AECII-PSLN-344-SRB'):.1f}% vs {mn('S08-C','AECII-PSLN-SRB'):.1f}%", '3.8% vs 15.8%'),
 ('moDC KO vs WT', f"{mn('S02-H','IFN w/o cDC'):.1f}% vs {mn('S02-H','WT w/o cDC'):.1f}%", '2.1% vs 19.7%'),
 ('PTX MLN', f"{mn('S05-C','MLN+PTX'):.1f}% vs {mn('S05-C','MLN'):.1f}%", '6.8% vs 30.9%'),
 ('CBX', f"{mn('S11-C','CBX+'):.1f}% vs {mn('S11-C','CBX-'):.1f}%", '3.1% vs 7.3%'),
 ('dose 212@40 vs 344@10', f"{gm('S08-A','PSLN-212',40):.1f}-fold IFN-β, below PSLN-344 at 10 µg ({gm('S08-A','PSLN-344',10):.1f}-fold)", '14.7-fold IFN-β, below PSLN-344 at 10 µg (21.0-fold)'),
 ('CMP-204 IFNb', f"{gm('S01-A_16h','CMP-204'):.1f}-fold", '7.7-fold'),
 ('EE 344', f"{mn('S08-B','PSLN-344'):.1f} ± {V[(V.block=='S08-B')&(V.group_norm=='PSLN-344')].value.std():.1f}%", '54.8 ± 5.1%'),
]
bad=0
for name,computed,expected in checks:
    ok = (computed==expected) and (expected in memo)
    bad += (not ok)
    print(('OK  ' if ok else 'FAIL'),f'{name:28s} computed={computed!r:40s} memo-string={expected!r} present={expected in memo}')
print('\nFAILURES:',bad,'of',len(checks))

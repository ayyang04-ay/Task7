import pandas as pd, numpy as np, collections
V=pd.read_csv('/tmp/work/values_long.csv')
# Build trajectories: for time-course blocks, a trajectory is (block, group, rep) ordered by level;
# for single-timepoint blocks, a vector is (block, group, level) ordered by rep.
weight_blocks=[b for b in V.block.unique() if b.startswith('S15') or b in ('S08-D','S09-C','S09-E','S09-G','S13-F','S13-G')]
tc_blocks=weight_blocks+['S01-D','S01-E','S11-A','S11-B','S11-D','S02-F','S07-A','S08-A','S05-A','S05-B']
seqs={}
for (b,g,r),d in V[V.block.isin(tc_blocks)].groupby(['block','group_norm','rep']):
    d=d.sort_values('level'); seqs[('traj',b,g,r)]=list(zip(d.level,d.value,d.cell))
for (b,g,l),d in V[~V.block.isin(tc_blocks)].groupby(['block','group_norm','level'],dropna=False):
    d=d.sort_values('rep'); seqs[('vec',b,g,l)]=list(zip(d.rep,d.value,d.cell))
trivial={100.0,0.0}
idx=collections.defaultdict(list)
for k,s in seqs.items():
    vals=[x[1] for x in s]
    for i in range(len(vals)-1):
        pair=(vals[i],vals[i+1])
        if all(p in trivial for p in pair): continue
        idx[pair].append((k,i))
# report pairs of sequences sharing >=2 consecutive non-trivial identical values, across different sequences
hits=collections.Counter(); detail=collections.defaultdict(list)
for pair,locs in idx.items():
    if len(locs)<2: continue
    for a in range(len(locs)):
        for b in range(a+1,len(locs)):
            ka,ia=locs[a]; kb,ib=locs[b]
            if ka==kb: continue
            key=tuple(sorted([ka,kb],key=str))
            hits[key]+=1; detail[key].append(pair)
rows=[]
for key,c in hits.most_common():
    ka,kb=key
    rows.append(dict(seqA=f'{ka[1]}|{ka[2]}|{ka[3]}',seqB=f'{kb[1]}|{kb[2]}|{kb[3]}',n_shared_consecutive_pairs=c,
                     example=str(detail[key][:3]), cellsA=seqs[ka][0][2]+'..'+seqs[ka][-1][2], cellsB=seqs[kb][0][2]+'..'+seqs[kb][-1][2]))
R=pd.DataFrame(rows)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',80)
print(R.to_string())
R.to_csv('/tmp/work/dup_pairs.csv',index=False)

import pandas as pd, numpy as np, itertools
V=pd.read_csv('/tmp/work/values_long.csv')
wb_blocks=[b for b in V.block.unique() if b.startswith('S15') or b in ('S08-D','S09-C','S09-E','S09-G','S13-F','S13-G')]
W=V[V.block.isin(wb_blocks)].copy()
W['level']=W.level.astype(float)
traj={}
for (b,g,r),d in W.groupby(['block','group_norm','rep']):
    d=d.sort_values('level')
    vals=d.value.tolist(); lv=d.level.tolist(); cells=d.cell.tolist()
    # mark plateau values (value equals previous value) -> likely carried forward after death
    keep={}
    for i,(l,x,c) in enumerate(zip(lv,vals,cells)):
        if l==0: continue
        if i>0 and x==vals[i-1]: continue
        if i+1<len(vals) and x==vals[i+1]: continue
        keep[l]=(x,c)
    traj[(b,g,r)]=keep
rows=[]
keys=list(traj)
for a,b in itertools.combinations(keys,2):
    if a[0]==b[0] and a[1]==b[1]: continue
    A,B=traj[a],traj[b]
    common=[l for l in A if l in B and A[l][0]==B[l][0]]
    if len(common)>=2:
        rows.append(dict(A=f'{a[0]} {a[1]} animal#{a[2]}',B=f'{b[0]} {b[1]} animal#{b[2]}',
             n_identical_days=len(common),days=common,
             cellsA=','.join(A[l][1] for l in common),cellsB=','.join(B[l][1] for l in common),
             values=[A[l][0] for l in common]))
R=pd.DataFrame(rows).sort_values('n_identical_days',ascending=False)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',70)
print(R.to_string())
R.to_csv('/tmp/work/dup_aligned.csv',index=False)
# chance benchmark: how often do two random trajectories from DIFFERENT blocks share >=2 identical non-plateau days?
print('\nN pairs compared:', len(list(itertools.combinations(keys,2))))

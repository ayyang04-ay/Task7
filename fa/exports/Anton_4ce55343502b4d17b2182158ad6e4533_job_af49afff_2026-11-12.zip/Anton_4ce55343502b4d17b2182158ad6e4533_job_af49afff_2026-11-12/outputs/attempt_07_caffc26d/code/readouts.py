import pandas as pd, numpy as np, warnings
from scipy import stats
warnings.filterwarnings('ignore')
V=pd.read_csv('/tmp/work/values_long.csv')
V.loc[(V.block.isin(['S03-C','S03-G']))&(V.value==0),'value']=5.0   # HAI below 1:10 -> half LOD
# catalogue: key -> (block, level or None, label, stage, scale, direction, human proxy)
CAT=[
 ('ifnb1_16h','S01-A_16h',None,'Lung Ifnb1 mRNA, 16 h (fold vs untreated)','1 innate','log'),
 ('ifnb1_72h','S01-A_72h',None,'Lung Ifnb1 mRNA, 72 h','1 innate','log'),
 ('gmcsf_16h','S02-F','16h','Lung Gm-csf mRNA, 16 h','1 innate','log'),
 ('gmcsf_36h','S02-F','36h','Lung Gm-csf mRNA, 36 h','1 innate','log'),
 ('gmcsf_72h','S02-F','72h','Lung Gm-csf mRNA, 72 h','1 innate','log'),
 ('mono_d2','S01-D','2','Lung monocytes %, d2','1 innate','lin'),
 ('mono_d4','S01-D','4','Lung monocytes %, d4 (peak)','1 innate','lin'),
 ('mono_d6','S01-D','6','Lung monocytes %, d6','1 innate','lin'),
 ('nk_d4','S11-D','4','Lung NK %, d4','1 innate','lin'),
 ('cd206_mac','S11-E',None,'Lung CD206+ macrophages % (time not stated)','1 innate','lin'),
 ('ly6c_ccr2_mac_d5','S07-A','5','Lung Ly6C+CCR2+ macrophages (x10^5), d5','1 innate','lin'),
 ('cd11b_dc_d4','S01-E','4','Lung CD11b+ DC %, d4 (peak)','2 APC','lin'),
 ('cdc1_72h','S01-F',None,'Lung cDC1 %, 72 h','2 APC','lin'),
 ('cdc2_72h','S01-G',None,'Lung cDC2 %, 72 h','2 APC','lin'),
 ('ccr7_dc','S02-A',None,'Lung CCR7+ migratory CD11b+ DC %, 72 h','2 APC','lin'),
 ('mln_cd11b_dc','S02-B',None,'MLN CD11b+CD103- DC %, 72 h','2 APC','lin'),
 ('mln_ova_dc','S02-C',None,'MLN DC carrying AF647-OVA %, 36 h','2 APC','lin'),
 ('cd40','S02-D_CD40',None,'MLN CD11b+ DC CD40+ %, d3','2 APC','lin'),
 ('cd86','S02-D_CD86',None,'MLN CD11b+ DC CD86+ %, d3','2 APC','lin'),
 ('dc_otI','S02-E',None,'OT-I proliferation with MLN DC %, ex vivo','2 APC','lin'),
 ('gcb_d7','S03-K',None,'MLN GC B cells %, d7','3 GC/Tfh','lin'),
 ('aicda_d5','S03-L_Aicda',None,'MLN B-cell Aicda mRNA, d5 (n=3)','3 GC/Tfh','log'),
 ('e47_d5','S03-L_E47',None,'MLN B-cell E47 mRNA, d5 (n=3)','3 GC/Tfh','log'),
 ('tfh_icoshi','S04-A_ICOShi',None,'MLN Tfh ICOS-hi %, d7','3 GC/Tfh','lin'),
 ('tfh_icoslo','S04-A_ICOSlo',None,'MLN Tfh ICOS-lo %, d7','3 GC/Tfh','lin'),
 ('tfr_d7','S04-B_Foxp3',None,'MLN Tfr (Foxp3+ of CXCR5+ICOShi) %, d7','3 GC/Tfh','lin'),
 ('tfr_d30','S04-C',None,'MLN Tfr %, d30','3 GC/Tfh','lin'),
 ('lung_treg_d7','S04-D',None,'Lung Treg %, d7 (n=3)','3 GC/Tfh','lin'),
 ('igg_bcell','S13-H',None,'MLN IgG+ B220+ % (time not stated)','3 GC/Tfh','lin'),
 ('igg_ca09_d14','S03-A',None,'Serum IgG anti-CA09, d14 (endpoint titre)','4 antibody','log'),
 ('igg_aichi_d14','S03-E',None,'Serum IgG anti-Aichi, d14','4 antibody','log'),
 ('hai_ca09_d14','S03-C',None,'HAI anti-CA09, d14','4 antibody','log'),
 ('hai_aichi_d14','S03-G',None,'HAI anti-Aichi, d14','4 antibody','log'),
 ('neut_ca09_d14','S03-D',None,'Neutralising titre anti-CA09, d14','4 antibody','log'),
 ('neut_aichi_d14','S03-H',None,'Neutralising titre anti-Aichi, d14','4 antibody','log'),
 ('igg2a_ca09','S13-A',None,'IgG2a anti-CA09, d14','4 antibody','log'),
 ('igg1_ca09','S13-B',None,'IgG1 anti-CA09, d14','4 antibody','log'),
 ('igg2a_aichi','S13-C',None,'IgG2a anti-Aichi, d14','4 antibody','log'),
 ('igg1_aichi','S13-D',None,'IgG1 anti-Aichi, d14','4 antibody','log'),
 ('igg_ca09_d28','S13-I',None,'Serum IgG anti-CA09, d28 (boost d14)','4 antibody','log'),
 ('igg_aichi_d28','S13-J',None,'Serum IgG anti-Aichi, d28 (boost d14)','4 antibody','log'),
 ('ki67_cd8_d3','S05-D',None,'Lung Ki-67+ CD8 %, d3','5 CD8','lin'),
 ('gzmb_cd8_d3','S05-E',None,'Lung GZMB+ CD8 %, d3','5 CD8','lin'),
 ('ifng_cd8_h5_d14','S05-F',None,'MLN IFN-g+ CD8 % (rgH5N1 restim = cross-reactive), d14','5 CD8','lin'),
 ('ifng_cd8_h5_d60','S05-G',None,'MLN IFN-g+ CD8 % (rgH5N1 restim), d60','5 CD8','lin'),
 ('gzmb_cd8_d60','S05-H',None,'MLN GZMB+ CD8 %, d60','5 CD8','lin'),
 ('trm_d25','S05-I',None,'Lung CD69+CD103+ TRM CD8 %, d25','5 CD8','lin'),
 ('ifng_cd8_h1','S14-A_H1N1',None,'MLN IFN-g+ CD8 % (H1N1 restim; time not stated)','5 CD8','lin'),
 ('ifng_cd8_h3','S14-A_H3N2',None,'MLN IFN-g+ CD8 % (H3N2 restim; time not stated)','5 CD8','lin'),
]
def grab(block,level,group):
    d=V[(V.block==block)&(V.group_norm==group)]
    if level is not None: d=d[d.level.astype(str)==str(level)]
    return d.value.values.astype(float), ','.join(d.cell.tolist())
def contrast(x,y,scale):
    """returns effect (ratio of GMs for log, ratio of means & diff for lin), 95% CI, Welch p, MWU p"""
    if len(x)<2 or len(y)<2: return (np.nan,)*5
    if scale=='log':
        lx,ly=np.log10(x),np.log10(y)
        t=stats.ttest_ind(lx,ly,equal_var=False); d=lx.mean()-ly.mean()
        se=np.sqrt(lx.var(ddof=1)/len(lx)+ly.var(ddof=1)/len(ly))
        dfw=se**4/((lx.var(ddof=1)/len(lx))**2/(len(lx)-1)+(ly.var(ddof=1)/len(ly))**2/(len(ly)-1))
        q=stats.t.ppf(0.975,dfw); eff=10**d; lo,hi=10**(d-q*se),10**(d+q*se)
    else:
        t=stats.ttest_ind(x,y,equal_var=False); d=x.mean()-y.mean()
        se=np.sqrt(x.var(ddof=1)/len(x)+y.var(ddof=1)/len(y))
        dfw=se**4/((x.var(ddof=1)/len(x))**2/(len(x)-1)+(y.var(ddof=1)/len(y))**2/(len(y)-1))
        q=stats.t.ppf(0.975,dfw); eff=x.mean()/y.mean(); lo,hi=d-q*se,d+q*se
    mw=stats.mannwhitneyu(x,y,alternative='two-sided').pvalue
    return eff,lo,hi,t.pvalue,mw
rows=[]
for key,block,level,label,stage,scale in CAT:
    res=dict(key=key,block=block,level=level,readout=label,stage=stage,scale=scale)
    summ={}
    for g in ['Sham','Vaccine','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)','PSLN-344(Y)']:
        x,cells=grab(block,level,g)
        if len(x)==0: continue
        c = (10**np.mean(np.log10(x))) if scale=='log' else x.mean()
        summ[g]=(c,x.std(ddof=1) if len(x)>1 else np.nan,len(x),cells)
        res[f'{g}_center']=round(c,3); res[f'{g}_n']=len(x); res[f'{g}_cells']=cells
        if scale=='lin': res[f'{g}_sd']=round(x.std(ddof=1),3)
    x344,_=grab(block,level,'PSLN-344'); x212,_=grab(block,level,'PSLN-212'); xY,_=grab(block,level,'PSLN-212(Y)')
    xs,_=grab(block,level,'Sham')
    for nm,(a,b) in {'344v212':(x344,x212),'344vY212':(x344,xY),'212vY212':(x212,xY),'344vSham':(x344,xs)}.items():
        if len(a) and len(b):
            eff,lo,hi,p,mw=contrast(a,b,scale)
            res[f'{nm}_effect']=round(eff,3); res[f'{nm}_CI']=f'{lo:.3g} to {hi:.3g}'; res[f'{nm}_welch_p']=p; res[f'{nm}_mwu_p']=mw
    # restoration fraction: how much of the aged deficit (Y212 - 212) is closed by Mn (344 - 212)
    if all(g in summ for g in ['PSLN-344','PSLN-212','PSLN-212(Y)']):
        f=(lambda v: np.log10(v)) if scale=='log' else (lambda v: v)
        a,b,c=f(summ['PSLN-344'][0]),f(summ['PSLN-212'][0]),f(summ['PSLN-212(Y)'][0])
        res['restoration_fraction']=round((a-b)/(c-b),2) if abs(c-b)>0 else np.nan
    rows.append(res)
R=pd.DataFrame(rows)
R.to_csv('/tmp/work/readouts.csv',index=False)
cols=['key','readout','scale','Sham_center','PSLN-212_center','PSLN-344_center','PSLN-212(Y)_center','PSLN-344(Y)_center',
      '344v212_effect','344v212_CI','344v212_welch_p','344v212_mwu_p','344vY212_effect','212vY212_welch_p','restoration_fraction']
pd.set_option('display.width',320); pd.set_option('display.max_colwidth',60); pd.set_option('display.max_rows',200)
print(R[cols].to_string())

import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
out='/tmp/outputs/PSLN-344_evidence_ledger.xlsx'
readme=pd.DataFrame({'item':[
 'Purpose','Source files','How to trace a number','Reductions used','Statistical tests','Imputation','Exclusions','Restoration fraction','Weight-implied death','Code'],
 'description':[
 'Every number used in the PSLN-344 portfolio memo, with the workbook cells it came from and how it was reduced.',
 'adjuvant_program_dataset.xlsx (sheets S01–S15) and adjuvant_program_annotation.pdf (per-block annotation).',
 'Memo cites ledger IDs (E##, I##). Each ledger row gives sheet!cell range(s). Raw per-animal values with their cell address are in Raw_values_long / Raw_survival_long.',
 'Titres and transcript fold-changes: geometric mean (GM) of per-animal values; ratios are ratios of GMs. Percentages: arithmetic mean; contrasts are differences (and ratio of means). Survival: deaths/n (event column 1 = death, 0 = censored).',
 'Pre-specified pairwise contrasts: Welch t-test (log10 scale for titres/mRNA) with Welch 95% CI; Mann-Whitney as sensitivity; Tukey HSD across all groups in a block (the team\'s stated method) reported alongside. Survival: log-rank per block; pooled across blocks with an exact stratified conditional test (sum of hypergeometrics), Mantel-Haenszel risk difference (Greenland-Robins variance) and stratified log-rank.',
 'HAI recorded as 0 (below the 1:10 starting dilution; sham only) set to 5. One S03-J PSLN-344 row without a time (G46) treated as censored at 21 d.',
 'S06-D (exact duplicate of S06-C), S11-A/S11-B (35% shared values), S07-C (duplicate labels), S03-B/S03-F (label-permuted derived ratios), S04-B Tfh:Tfr (transform of Foxp3%), S08 rows 89–101 (unlabelled). S03-I and S03-J excluded from pooled efficacy (internal conflicts) but reported.',
 '(aged PSLN-344 − aged PSLN-212)/(young PSLN-212 − aged PSLN-212), log10 scale for titres/mRNA; 95% CI by bootstrap (4,000 resamples of animals within group; stratified by block for survival).',
 'In weight blocks, an animal is inferred dead if its record stops before the last day or its terminal values are frozen (≥3 identical, or ≥2 identical below 90% of day-0 weight).',
 'Python scripts in /code reproduce every table (extract.py first).']})
sheets={'README':readme,
 'Evidence_ledger':pd.read_csv('/tmp/work/ledger.csv'),
 'Integrity_register':pd.read_csv('/tmp/work/integrity.csv'),
 'Survival_by_group':pd.read_csv('/tmp/work/surv_groups.csv'),
 'Survival_pairwise':pd.read_csv('/tmp/work/surv_tests.csv'),
 'Survival_pooled':pd.read_csv('/tmp/work/pooled_survival.csv'),
 'Survival_block_meta':pd.read_csv('/tmp/work/surv_meta.csv'),
 'Weight_vs_survival':pd.read_csv('/tmp/work/weight_vs_survival.csv'),
 'Readouts_stats':pd.read_csv('/tmp/work/readouts.csv').merge(pd.read_csv('/tmp/work/tukey.csv'),on='key',how='left'),
 'Restoration_fractions':pd.read_csv('/tmp/work/restoration_fractions.csv'),
 'Dup_trajectories':pd.read_csv('/tmp/work/dup_aligned.csv').query('n_identical_days>=3'),
 'Raw_values_long':pd.read_csv('/tmp/work/values_long.csv'),
 'Raw_survival_long':pd.read_csv('/tmp/work/survival_long.csv')}
with pd.ExcelWriter(out,engine='openpyxl') as w:
    for k,df in sheets.items(): df.to_excel(w,sheet_name=k,index=False)
wb=load_workbook(out)
for ws in wb.worksheets:
    for c in ws[1]:
        c.font=Font(bold=True,color='FFFFFF'); c.fill=PatternFill('solid',fgColor='404040'); c.alignment=Alignment(wrap_text=True,vertical='top')
    for col in ws.columns:
        L=max(len(str(c.value)) if c.value is not None else 0 for c in col[:200])
        ws.column_dimensions[col[0].column_letter].width=min(max(10,L*0.9),70)
    if ws.title in ('README','Evidence_ledger','Integrity_register','Survival_pooled'):
        for row in ws.iter_rows(min_row=2):
            for c in row: c.alignment=Alignment(wrap_text=True,vertical='top')
    ws.freeze_panes='A2'
wb.save(out); print('saved',out)

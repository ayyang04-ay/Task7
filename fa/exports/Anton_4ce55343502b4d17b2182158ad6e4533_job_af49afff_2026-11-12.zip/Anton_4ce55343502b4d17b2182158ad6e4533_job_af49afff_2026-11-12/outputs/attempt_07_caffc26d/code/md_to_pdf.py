"""Minimal Markdown -> PDF renderer (reportlab) for the portfolio memo.
Supports: # headings, paragraphs, **bold**, *italic*, `code`, nested bullet / numbered lists,
pipe tables, images ![cap](path), horizontal rules."""
import re, os, sys, html
import matplotlib
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
                                Image, KeepTogether, HRFlowable, ListFlowable, ListItem, PageBreak)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping

FD = os.path.join(os.path.dirname(matplotlib.__file__), 'mpl-data', 'fonts', 'ttf')
for name, f in [('DV', 'DejaVuSans.ttf'), ('DV-B', 'DejaVuSans-Bold.ttf'), ('DV-I', 'DejaVuSans-Oblique.ttf'),
                ('DV-BI', 'DejaVuSans-BoldOblique.ttf'), ('DVM', 'DejaVuSansMono.ttf')]:
    pdfmetrics.registerFont(TTFont(name, os.path.join(FD, f)))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')

SRC, OUT = sys.argv[1], sys.argv[2]
BASE = os.path.dirname(os.path.abspath(SRC))
W, H = A4
LM = RM = 16 * mm; TM = 16 * mm; BM = 16 * mm
TW = W - LM - RM

st = {
    'h1': ParagraphStyle('h1', fontName='DV-B', fontSize=16, leading=20, spaceAfter=6, textColor=colors.HexColor('#1a1a1a')),
    'h2': ParagraphStyle('h2', fontName='DV-B', fontSize=12.5, leading=16, spaceBefore=10, spaceAfter=5, textColor=colors.HexColor('#8b0000')),
    'h3': ParagraphStyle('h3', fontName='DV-B', fontSize=10.5, leading=13.5, spaceBefore=7, spaceAfter=3, textColor=colors.HexColor('#1a1a1a')),
    'p': ParagraphStyle('p', fontName='DV', fontSize=8.6, leading=11.6, spaceAfter=4),
    'li': ParagraphStyle('li', fontName='DV', fontSize=8.6, leading=11.4, spaceAfter=1.5),
    'td': ParagraphStyle('td', fontName='DV', fontSize=6.7, leading=8.3),
    'th': ParagraphStyle('th', fontName='DV-B', fontSize=6.8, leading=8.4, textColor=colors.white),
    'cap': ParagraphStyle('cap', fontName='DV-I', fontSize=7.2, leading=9, textColor=colors.HexColor('#444444'), spaceAfter=6),
}

def inline(t):
    t = html.escape(t, quote=False)
    t = re.sub(r'`([^`]+)`', r'<font face="DVM" size="7.6">\1</font>', t)
    t = re.sub(r'\*\*(.+?)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*(?!\s)(.+?)(?<!\s)\*(?![\w*])', r'<i>\1</i>', t)
    t = t.replace('^hi', '<super>hi</super>')
    return t

def parse_table(lines):
    rows = []
    for l in lines:
        l = l.strip()
        if re.match(r'^\|?\s*:?-{2,}', l.replace('|', '').strip() + '--') and set(l.replace('|', '').replace(':', '').replace('-', '').strip()) == set():
            continue
        cells = [c.strip() for c in l.strip('|').split('|')]
        rows.append(cells)
    return rows

def _plain(t):
    t = re.sub(r'[*`]', '', t)
    return t

def make_table(rows):
    from reportlab.pdfbase.pdfmetrics import stringWidth
    ncol = max(len(r) for r in rows)
    rows = [r + [''] * (ncol - len(r)) for r in rows]
    pad = 2 * 2.5 + 1.5
    minw = []; natw = []
    for c in range(ncol):
        mw = 0; nw = 0
        for i, r in enumerate(rows):
            font, size = ('DV-B', 6.8) if i == 0 else ('DV', 6.7)
            txt = _plain(r[c])
            words = re.split(r'\s+', txt) if txt else ['']
            mw = max(mw, max(stringWidth(w, font, size) for w in words))
            nw = max(nw, stringWidth(txt, font, size))
        minw.append(mw + pad); natw.append(min(nw + pad, TW * 0.55))
    cw = list(minw)
    if sum(cw) > TW:
        f = TW / sum(cw); cw = [w * f for w in cw]
    else:
        extra = TW - sum(cw)
        want = [max(0.0, n - m) for n, m in zip(natw, cw)]
        if sum(want) > 0:
            if sum(want) <= extra:
                cw = [m + w for m, w in zip(cw, want)]; extra -= sum(want)
                cw = [w + extra / ncol for w in cw]
            else:
                cw = [m + extra * w / sum(want) for m, w in zip(cw, want)]
        else:
            cw = [w + extra / ncol for w in cw]
    data = [[Paragraph(inline(c), st['th'] if i == 0 else st['td']) for c in r] for i, r in enumerate(rows)]
    t = Table(data, colWidths=cw, repeatRows=1)
    t.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#404040')),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f3f3f3')]),
        ('GRID', (0, 0), (-1, -1), 0.25, colors.HexColor('#bbbbbb')),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('LEFTPADDING', (0, 0), (-1, -1), 2.5), ('RIGHTPADDING', (0, 0), (-1, -1), 2.5),
        ('TOPPADDING', (0, 0), (-1, -1), 1.8), ('BOTTOMPADDING', (0, 0), (-1, -1), 1.8)]))
    return t

def flush_list(items, story):
    """items: list of (indent_level, kind, text). Build nested ListFlowables."""
    def build(idx, level):
        out = []; kind = None
        while idx < len(items):
            lev, k, txt = items[idx]
            if lev < level: break
            if lev > level:
                sub, idx = build(idx, lev)
                if out: out[-1].append(sub)
                else: out.append([sub])
                continue
            kind = kind or k
            out.append([Paragraph(inline(txt), st['li'])]); idx += 1
        flow = [ListItem(f if len(f) > 1 else f[0], leftIndent=11) for f in out]
        if kind == 'ol':
            lf = ListFlowable(flow, bulletType='1', start=1, leftIndent=13, bulletFontName='DV-B', bulletFontSize=8, bulletFormat='%s.')
        else:
            lf = ListFlowable(flow, bulletType='bullet', start='•' if level == 0 else '–', leftIndent=11,
                              bulletFontName='DV', bulletFontSize=7.5)
        return lf, idx
    lf, _ = build(0, items[0][0])
    story.append(lf); story.append(Spacer(1, 2.5))

def render(md):
    story = []
    lines = md.split('\n'); i = 0; para = []; lst = []
    def flush_para():
        nonlocal para
        if para:
            story.append(Paragraph(inline(' '.join(x.strip() for x in para)), st['p'])); para = []
    def flush_lst():
        nonlocal lst
        if lst: flush_list(lst, story); lst = []
    while i < len(lines):
        l = lines[i]
        if not l.strip():
            flush_para(); flush_lst(); i += 1; continue
        m = re.match(r'^(#{1,3})\s+(.*)', l)
        if m:
            flush_para(); flush_lst()
            lvl = len(m.group(1)); story.append(Paragraph(inline(m.group(2)), st['h%d' % lvl]))
            if lvl == 1: story.append(HRFlowable(width='100%', thickness=1.2, color=colors.HexColor('#8b0000'), spaceAfter=6))
            i += 1; continue
        if re.match(r'^\s*---\s*$', l):
            flush_para(); flush_lst(); story.append(HRFlowable(width='100%', thickness=0.5, color=colors.HexColor('#999999'), spaceBefore=3, spaceAfter=5)); i += 1; continue
        m = re.match(r'^!\[(.*?)\]\((.*?)\)', l.strip())
        if m:
            flush_para(); flush_lst()
            path = os.path.join(BASE, m.group(2))
            from reportlab.lib.utils import ImageReader
            iw, ih = ImageReader(path).getSize()
            w = TW; h = w * ih / iw
            if h > 205 * mm: h = 205 * mm; w = h * iw / ih
            story.append(KeepTogether([Image(path, width=w, height=h), Paragraph(inline(m.group(1)), st['cap'])]))
            i += 1; continue
        if l.strip().startswith('|'):
            flush_para(); flush_lst()
            tl = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                tl.append(lines[i]); i += 1
            story.append(make_table(parse_table(tl))); story.append(Spacer(1, 5)); continue
        m = re.match(r'^(\s*)([-*]|\d+\.)\s+(.*)', l)
        if m:
            flush_para()
            indent = len(m.group(1).replace('\t', '    '))
            kind = 'ol' if m.group(2)[0].isdigit() else 'ul'
            txt = m.group(3); i += 1
            # continuation lines (indented, not list markers)
            while i < len(lines) and lines[i].strip() and not re.match(r'^(\s*)([-*]|\d+\.)\s+', lines[i]) \
                    and not lines[i].strip().startswith('|') and not lines[i].startswith('#') and lines[i].startswith(' '):
                txt += ' ' + lines[i].strip(); i += 1
            lst.append((indent // 2, kind, txt)); continue
        if lst and l.startswith('   '):
            # indented paragraph inside list -> append to last item
            lev, k, t = lst[-1]; lst[-1] = (lev, k, t + ' ' + l.strip()); i += 1; continue
        flush_lst(); para.append(l); i += 1
    flush_para(); flush_lst()
    return story

def on_page(c, d):
    c.saveState(); c.setFont('DV', 7); c.setFillColor(colors.HexColor('#666666'))
    c.drawString(LM, 9 * mm, 'PSLN-344 portfolio review brief — numbers trace to PSLN-344_evidence_ledger.xlsx (E##/I##)')
    c.drawRightString(W - RM, 9 * mm, 'Page %d' % d.page); c.restoreState()

doc = BaseDocTemplate(OUT, pagesize=A4, leftMargin=LM, rightMargin=RM, topMargin=TM, bottomMargin=BM,
                      title='PSLN-344 Portfolio Review Brief', author='Portfolio analysis')
doc.addPageTemplates([PageTemplate(id='p', frames=[Frame(LM, BM, TW, H - TM - BM, id='f')], onPage=on_page)])
doc.build(render(open(SRC, encoding='utf-8').read()))
print('wrote', OUT)

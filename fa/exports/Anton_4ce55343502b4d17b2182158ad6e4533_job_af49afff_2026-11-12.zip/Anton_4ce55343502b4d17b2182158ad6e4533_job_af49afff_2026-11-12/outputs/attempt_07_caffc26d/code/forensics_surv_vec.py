import pandas as pd, numpy as np, itertools
S=pd.read_csv('/tmp/work/survival_long.csv'); V=pd.read_csv('/tmp/work/values_long.csv')
# survival: ordered (time,event) sequences per block-group, compare across blocks
sig={}
for (b,g),d in S.groupby(['block','group_norm'],sort=False):
    sig[(b,g)]=tuple(zip(d.time.fillna(-1).astype(int),d.event))
print('=== survival group sequences that are identical between different blocks (excluding all-censored-at-14 and all-dead-identical trivial?) ===')
for a,b in itertools.combinations(sig,2):
    if a[0]!=b[0] and sig[a]==sig[b]:
        trivial = all(e==0 and t==14 for t,e in sig[a])
        print(('TRIVIAL ' if trivial else 'NONTRIVIAL '),a,b,sig[a])
# full-block comparison
blocks=S.block.unique()
for a,b in itertools.combinations(blocks,2):
    A=S[S.block==a]; B=S[S.block==b]
    if set(A.group_norm)==set(B.group_norm):
        same=all(sig[(a,g)]==sig[(b,g)] for g in A.group_norm.unique())
        if same: print('*** ENTIRE BLOCK IDENTICAL:',a,b)
# ---- single-timepoint vectors: identical values between different blocks/groups
print('\n=== single-timepoint blocks: shared values between group vectors (>=2 identical values, non-discrete measurands) ===')
disc=('S03-C','S03-G','S03-D','S03-H')
tc=('S01-D','S01-E','S11-A','S11-B','S11-D','S02-F','S07-A','S08-A','S05-A','S05-B','S08-D','S09-C','S09-E','S09-G','S13-F','S13-G')
X=V[~V.block.isin(disc)&~V.block.str.startswith('S15')&~V.block.isin(tc)]
vec={}
for (b,g,l),d in X.groupby(['block','group_norm','level'],dropna=False):
    vec[(b,g,l)]=d.sort_values('rep')[['value','cell']].values.tolist()
for a,b in itertools.combinations(vec,2):
    if a[:2]==b[:2]: continue
    va={round(x,6):c for x,c in vec[a]}; vb={round(x,6):c for x,c in vec[b]}
    common=[x for x in va if x in vb and x not in (0,)]
    if len(common)>=2:
        print(a,'<->',b,'shared:',[(x,va[x],vb[x]) for x in common])
# time-course immunology blocks S11-A vs S11-B etc: aligned identical values
print('\n=== aligned identical values between time-course immunology blocks ===')
T=V[V.block.isin(['S01-D','S01-E','S11-A','S11-B','S11-D'])]
piv={}
for (b,g),d in T.groupby(['block','group_norm']):
    piv[(b,g)]={(float(r.level),r.rep):(r.value,r.cell) for r in d.itertuples()}
for a,b in itertools.combinations(piv,2):
    if a[0]==b[0]: continue
    if a[1]!=b[1] and not (a[1] in ('Vaccine','Sham') and b[1] in ('Vaccine','Sham')): continue
    A,B=piv[a],piv[b]
    same=[(k,A[k][1],B[k][1],A[k][0]) for k in A if k in B and A[k][0]==B[k][0]]
    if same: print(a,b,f'{len(same)}/{len(A)} identical aligned cells; e.g.',same[:4])

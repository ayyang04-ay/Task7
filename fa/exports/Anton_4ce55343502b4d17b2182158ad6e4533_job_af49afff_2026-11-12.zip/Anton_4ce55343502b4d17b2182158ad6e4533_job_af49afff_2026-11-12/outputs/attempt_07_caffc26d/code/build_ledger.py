"""Builds the evidence ledger: every number used in the memo, with source cells and reduction."""
import pandas as pd, numpy as np, warnings
from scipy import stats
warnings.filterwarnings('ignore')
V=pd.read_csv('/tmp/work/values_long.csv'); S=pd.read_csv('/tmp/work/survival_long.csv')
V.loc[(V.block.isin(['S03-C','S03-G']))&(V.value==0),'value']=5.0
R=pd.read_csv('/tmp/work/readouts.csv').set_index('key'); RF=pd.read_csv('/tmp/work/restoration_fractions.csv').set_index('key')
P=pd.read_csv('/tmp/work/pooled_survival.csv'); T=pd.read_csv('/tmp/work/surv_tests.csv'); G=pd.read_csv('/tmp/work/surv_groups.csv')
TK=pd.read_csv('/tmp/work/tukey.csv').set_index('key')
L=[]
def add(id_,section,statement,value,source,reduction,stat='',caveat=''):
    L.append(dict(ID=id_,section=section,statement=statement,value=value,source=source,reduction=reduction,statistic=stat,caveat=caveat))
from openpyxl.utils.cell import coordinate_from_string, column_index_from_string, get_column_letter
def cells(block,group=None,level=None):
    """bounding box of all cells of a block (optionally one level/row-set)"""
    d=V[V.block==block]
    if level is not None: d=d[d.level.astype(str)==str(level)]
    cs=[coordinate_from_string(c) for c in d.cell]
    cols=[column_index_from_string(c[0]) for c in cs]; rows=[c[1] for c in cs]
    return f"{d.sheet.iloc[0]}!{get_column_letter(min(cols))}{min(rows)}:{get_column_letter(max(cols))}{max(rows)}" if len(d) else ''
def scells(block,group):
    d=S[(S.block==block)&(S.group_norm==group)]
    return f"{d.sheet.iloc[0]}!{d.cell_time.iloc[0]}:{d.cell_event.iloc[-1]}"
def gm(block,group,level=None):
    d=V[(V.block==block)&(V.group_norm==group)]
    if level is not None: d=d[d.level.astype(str)==str(level)]
    return 10**np.log10(d.value.values).mean()
def mean(block,group,level=None):
    d=V[(V.block==block)&(V.group_norm==group)]
    if level is not None: d=d[d.level.astype(str)==str(level)]
    return d.value.mean()
def pooled(label_start):
    r=P[P.analysis.str.startswith(label_start)].iloc[0]; return r
fmtp=lambda p: (f'{p:.1e}' if p<0.001 else f'{p:.3f}')
fmtt=lambda p: ('<0.0001' if p<0.0001 else f'={p:.4f}')
# ===================== EFFICACY =====================
core=['S06-A','S06-B','S06-C','S06-E','S06-F','S06-G']
src_core='; '.join(f"{b} {g}: {scells(b,g)}" for b in core for g in ['PSLN-344','PSLN-212'])
r=pooled('P1 ')
add('E01','Efficacy','Aged BALB/c, core challenge blocks: deaths PSLN-344 vs PSLN-212',f"{r.deaths_A} ({r.mort_A_pct}%) vs {r.deaths_B} ({r.mort_B_pct}%)",
    src_core,'Sum of event=1 rows per arm over 6 blocks (S06-D excluded as exact duplicate of S06-C)',
    f"Mantel-Haenszel risk difference {r.MH_risk_diff_pct} pp (95% CI {r.RD_95CI}); exact stratified conditional test p={fmtp(r.exact_strat_p_two_sided)}; stratified log-rank p={fmtp(r.strat_logrank_p)}",
    'n=7/arm/block; single-sex (female); one strain')
q=pooled('Q1 ')
add('E02','Efficacy','Aged core blocks: deaths PSLN-344 vs sham (empty liposome + vaccine)',f"{q.deaths_A} vs {q.deaths_B}",
    '; '.join(f"{b} Sham: {scells(b,'Sham')}" for b in core),'Sum of deaths per arm',f"MH RD {q.MH_risk_diff_pct} pp ({q.RD_95CI}); exact stratified p={fmtp(q.exact_strat_p_two_sided)}")
a1=pooled('A1 '); a2=pooled('A2 ')
add('E03','Efficacy','Age deficit without Mn: aged PSLN-212 vs young PSLN-212; aged PSLN-212 vs sham',f"{a1.deaths_A} vs {a1.deaths_B}; {a2.deaths_A} vs {a2.deaths_B}",
    'S06-A,B,C,E,F,G PSLN-212 and PSLN-212(Y) and Sham event columns','Sum of deaths per arm',
    f"aged vs young: exact stratified p={fmtp(a1.exact_strat_p_two_sided)}; aged PSLN-212 vs sham: exact stratified p={fmtp(a2.exact_strat_p_two_sided)} (mortality), stratified log-rank p={fmtp(a2.strat_logrank_p)} (delay in death only)")
c=[x for x in P.analysis if x.startswith('P1-s')]
for lab,id_ in [('P1-s1','E04a'),('P1-s2','E04b'),('P1-s3','E04c')]:
    r=pooled(lab)
    add(id_,'Efficacy sensitivity',r.analysis,f"{r.deaths_A} vs {r.deaths_B}",'as E01 plus weight blocks S15-C/E/G, S15-D, S13-F',
        'Deaths replaced by weight-implied deaths (trajectory ends early or frozen terminal value) where concordance failed',
        f"MH RD {r.MH_risk_diff_pct} pp ({r.RD_95CI}); exact stratified p={fmtp(r.exact_strat_p_two_sided)}")
st=[]
for bl in ['S06-B','S06-E','S06-F','S06-G']:
    d=S[S.block==bl]; a=d[d.group_norm=='PSLN-344']; b=d[d.group_norm=='PSLN-212']; st.append((int(a.event.sum()),int(b.event.sum())))
add('E05','Efficacy sensitivity','Cleanest tier (S06-B,E,F,G): survival blocks not duplicated; companion weights concordant within ±1 death; no ≥4-day weight copies in any arm; the only 3-day weight matches (S15-F, S15-G) are in young-reference arms, not the PSLN-344/PSLN-212 arms compared',
    f"PSLN-344 {sum(x[0] for x in st)}/28 vs PSLN-212 {sum(x[1] for x in st)}/28 deaths",'S06-B (H3:K30), S06-E and S06-F (G33:R68), S06-G (A70:F105)',
    'Sum of deaths','exact stratified conditional test p=9.4e-07 (two-sided)')
for lab,id_,txt in [('P1-s4','E06a','d14 challenge (S06-A, S06-C)'),('P1-s6','E06b','d3 challenge (S06-B)'),('P1-s5','E06c','d60 challenge (S06-E,F,G)')]:
    r=pooled(lab); add(id_,'Efficacy by timing',f'Deaths PSLN-344 vs PSLN-212, {txt}',f"{r.deaths_A} vs {r.deaths_B}",txt,'Sum of deaths',
        f"exact stratified p={fmtp(r.exact_strat_p_two_sided)}; stratified log-rank p={fmtp(r.strat_logrank_p)}")
add('E06e','Efficacy by antigenic relation','Core blocks with no HA or NA match between vaccine and challenge (S06-A,B,E,G) vs HA-mismatched/N1-shared (S06-C,F): survivors PSLN-344 vs PSLN-212',
    '20/28 vs 1/28; 12/14 vs 3/14','S06 event columns (see E01)','Sum of survivors','', 'Aichi H3N2→PR8 H1N1 and CA09 H1N1→Perth H3N2 share neither HA nor NA subtype; bivalent (CA09 N1)→rgH5N1 (VN04 N1) shares NA subtype only')
add('E06d','Efficacy by timing','Waning within aged PSLN-344: d14 vs d60 challenge deaths','1/14 vs 7/21','S06-A,C vs S06-E,F,G PSLN-344 columns','Sum of deaths','Fisher exact p=0.11 (trend only)')
r1=pooled('R1 '); r2=pooled('R2 ')
add('E07','Residual age gap','Aged PSLN-344 vs young PSLN-212 deaths (all core; d60 only)',f"{r1.deaths_A} vs {r1.deaths_B}; {r2.deaths_A} vs {r2.deaths_B}",
    'S06 core, PSLN-344 and PSLN-212(Y) columns','Sum of deaths',f"RD +{r1.MH_risk_diff_pct} pp ({r1.RD_95CI}), exact stratified p={fmtp(r1.exact_strat_p_two_sided)}; d60: RD +{r2.MH_risk_diff_pct} pp ({r2.RD_95CI}), p={fmtp(r2.exact_strat_p_two_sided)}",
    'Young comparator received PSLN-212, not PSLN-344 (formulation and age confounded)')
def blk(b,a,c):
    t=T[(T.block==b)&(T.contrast==f'{a} vs {c}')].iloc[0]; return t
t=blk('S03-I','PSLN-344','PSLN-212')
add('E08','Efficacy homologous','S03-I aged, bivalent vaccine, 10x mLD50 CA09 at d14: deaths Sham / CMP-204 / PSLN-212 / PSLN-344 / young PSLN-212',
    '7/7, 4/7, 7/7, 0/7, 0/7',f"S03!A17:F51",'Deaths per arm',f"PSLN-344 vs PSLN-212 log-rank p={fmtp(t.logrank_p)}",
    'CONFLICT: S13-F weights (annotated as the same animals) show all 7 PSLN-212 weights to d14, 4 frozen from ~d10 (implied deaths), 3 recovering; excluded from primary pooling')
t=blk('S03-J','PSLN-344','PSLN-212')
add('E09','Efficacy homologous','S03-J rgH5N1 vaccine, wild-type VN04 H5N1 at d2: deaths Sham / PSLN-212 / PSLN-344','9/10, 7/10, 0/10','S03!G17:J46','Deaths per arm; one PSLN-344 row (J46) has no time, treated as censored at 21 d',
    f"PSLN-344 vs PSLN-212 log-rank p={fmtp(t.logrank_p)}",'Age not stated; stated n=9 vs 10 rows; S13-G weight groups (PSLN-344/Sham/Naive) do not match; excluded from pooling')
r=pooled('P4 ')
add('E10','Efficacy pre-existing immunity','14-month mice, PR8-imprinted or naive: deaths PSLN-344 vs PSLN-212 (4 strata)',f"{r.deaths_A} vs {r.deaths_B}",'S06!G70:Q98',
    'Sum of deaths; per stratum PSLN-344 1/7 in all four; PSLN-212 7/7 (naive, PR8), 3/7 (imprinted, PR8), 7/7 (naive, Perth), 7/7 (imprinted, Perth)',
    f"exact stratified p={fmtp(r.exact_strat_p_two_sided)}",'Animals 14 months at vaccination (not ≥20 months); PR8 challenge day not stated')
r=pooled('P3 ')
add('E11','Efficacy other strains','Aged C57BL/6 (S15-L) and Swiss Webster (S15-N): deaths PSLN-344 vs PSLN-212',f"{r.deaths_A} vs {r.deaths_B} (1/7 vs 7/7; 1/7 vs 5/7)",'S15!A102:E130; S15!A133:E161','Sum of deaths',
    f"exact stratified p={fmtp(r.exact_strat_p_two_sided)}",'Challenge virus/dose/timing not stated; companion weights S15-M/S15-O contain values duplicated across the two strains and from BALB/c blocks — treat as unverified')
add('E12','Mechanism (protection)','S15-H aged, challenge 3 d after dosing: deaths vaccine alone / PSLN-344 alone / vaccine+PSLN-344','7/7, 7/7, 1/7','S15!A72:D93','Deaths per arm',
    'vaccine+PSLN-344 vs PSLN-344 alone: log-rank p=1.4e-04; vs vaccine alone p=1.6e-04','S15-I weights for the combination arm are copied from S15-C (40/42 animal-days identical)')
add('E13','Efficacy young','Young BALB/c (S09-B, S09-D, S09-F incl. d180 H5N1): deaths PSLN-344(Y) / PSLN-212(Y) / sham','0/24, 0/24, 23/23','S09!A11:D88','Sum of deaths',
    'Each block vs sham log-rank p≤1.2e-04','Mn adds no measurable survival benefit in young mice (ceiling)')
add('E14','Efficacy young','S13-E young, 10x CA09 at d14: deaths Naive / Sham / CMP-204(Y) / PSLN-344(Y)','7/7, 6/7, 0/7, 0/7','S13!R2:V30','Deaths per arm','','Stated n=5 vs 7 rows per group')
bg=S[S.group_norm=='Untreated'].groupby('block').event.agg(['sum','size'])
add('E15','Model validity','Unvaccinated, unchallenged aged "Untreated" animals dying within the 14-day window','S06-E 1/7, S06-F 0/7, S06-G 3/7; pooled 4/21 (19%)',
    'S06!L62:L68, R62:R68, F99:F105','Sum of event=1','', 'Implausibly high background mortality for 20-month BALB/c; weights (S15-E/G) show deaths without weight loss; colony health or labelling issue')
add('E16','Efficacy (power)','Power of one 7-vs-7 block to detect the observed core effect (23.8% vs 90.5% mortality) / a shrunk effect (35% vs 75%)','0.57 / 0.16',
    'derived from E01','Monte-Carlo simulation, Fisher exact two-sided α=0.05, 4,000 simulations','','Individual blocks are underpowered; evidence rests on consistency across blocks')
add('E17','Planning','Confirmatory-study sample sizes (Fisher exact, two-sided α=0.05, Monte-Carlo): survival 35% vs 75% mortality; 30% vs 60%; lung viral titre 1.0 log10 difference with SD 0.8',
    '30/arm (power 0.84), 40/arm (0.94); 50/arm (0.83), 65/arm (0.91); 15/arm (0.90)','planning assumptions anchored on E01 (observed 23.8% vs 90.5%, shrunk toward the null)',
    'Simulation (4,000 or 3,000 draws) of Fisher exact test; t-test power (statsmodels) for titre','','SD of lung titre is an assumption (no viral-load data in the dataset)')
# ===================== INNATE / MECHANISM =====================
def rline(key): return R.loc[key]
r=rline('ifnb1_16h')
add('E20','Innate','Lung Ifnb1 at 16 h (fold vs untreated; geometric mean): aged sham / aged PSLN-212 / aged PSLN-344 / young PSLN-212 / young PSLN-344',
    f"{r['Sham_center']:.2f} / {r['PSLN-212_center']:.1f} / {r['PSLN-344_center']:.1f} / {r['PSLN-212(Y)_center']:.1f} / {r['PSLN-344(Y)_center']:.1f}",
    'S01!A3:F10 (16 h panel)','Geometric mean of 5 per-animal values',
    f"aged PSLN-344/PSLN-212 = {r['344v212_effect']:.2f}x (95% CI {r['344v212_CI']}); Welch t on log10 p={fmtp(r['344v212_welch_p'])}; Mann-Whitney p={r['344v212_mwu_p']:.4f}; Tukey p{fmtt(TK.loc['ifnb1_16h','tukey_p_344_vs_212'])}; aged/young PSLN-212 = {r['PSLN-212_center']/r['PSLN-212(Y)_center']:.2f} (p={fmtp(r['212vY212_welch_p'])}); restoration fraction {RF.loc['ifnb1_16h','RF']} ({RF.loc['ifnb1_16h','RF_lo']}–{RF.loc['ifnb1_16h','RF_hi']})",
    'No overlap: aged PSLN-212 range 13.4–19.0 vs aged PSLN-344 32.6–44.3. S09-A re-presents a subset of these same samples (not independent)')
add('E21','Innate','Ifnb1 dose–response (S08-A; GM of 3): PSLN-344/PSLN-212 ratio at 1, 5, 10, 20, 40 µg','1.01, 2.02, 2.35, 3.64, 3.38',
    'S08!A3:M7','Ratio of geometric means per dose','Welch (log10) p = 0.87, 0.013, 0.004, 3.3e-04, 1.3e-03',
    'Age of animals not stated. PSLN-344 plateau: 40 vs 20 µg 1.09x (p=0.55). PSLN-212 at 40 µg (14.7x) below PSLN-344 at 10 µg (21.0x), p=0.058')
for k,id_,lab in [('gmcsf_36h','E22','Lung Gm-csf mRNA 36 h, aged'),('mono_d4','E23','Lung monocytes d4 (% CD11b+Ly6C+), aged'),
                  ('cdc1_72h','E24a','Lung cDC1 72 h (%)'),('ccr7_dc','E24b','Lung CCR7+ migratory CD11b+ DC (%)'),('mln_ova_dc','E24c','MLN DC carrying antigen 36 h (%)'),
                  ('dc_otI','E24d','OT-I proliferation driven by MLN DC (%)'),('cd40','E25a','CD40+ of MLN CD11b+ DC d3 (%)'),('cd86','E25b','CD86+ of MLN CD11b+ DC d3 (%)')]:
    r=rline(k); y=r.get('PSLN-212(Y)_center',np.nan)
    add(id_,'Innate/APC',f"{lab}: aged PSLN-212 / aged PSLN-344 / young PSLN-212",
        f"{r['PSLN-212_center']:.3g} / {r['PSLN-344_center']:.3g} / {('%.3g'%y) if not pd.isna(y) else 'n.a.'}",
        f"{r.block}: "+cells(r.block,None,r.level if isinstance(r.level,str) else None),
        'Geometric mean (mRNA) or arithmetic mean (%), n=5 per group',
        (f"344/212 ratio of GMs {r['344v212_effect']:.2f} (95% CI {r['344v212_CI']})" if r.scale=='log' else f"344−212 difference {r['PSLN-344_center']-r['PSLN-212_center']:.2f} points (95% CI {r['344v212_CI']}); ratio of means {r['344v212_effect']:.2f}")+f", Welch p={fmtp(r['344v212_welch_p'])}"+(f"; restoration fraction {RF.loc[k,'RF']} ({RF.loc[k,'RF_lo']}–{RF.loc[k,'RF_hi']})" if k in RF.index else ''))
add('E26','Mechanism (intervention)','Pertussis toxin (blocks Gi-coupled chemokine-receptor migration): antigen+ DC in MLN; OT-I proliferation with MLN DC; in vivo OT-I proliferation MLN vs lung',
    '2.36 vs 7.09 %; 2.55 vs 18.7 %; MLN 6.8 vs 30.9 %, lung 55.1 vs 59.0 %','S02!K3:O7, K10:O14; S05!A13:D15','Arithmetic means (n=5; n=3 for S05-C)',
    'Welch p = 4.7e-04; 1.8e-05; MLN 0.0066, lung 0.57','Adjuvant given to PTX group in S02-C/E not stated (assumed PSLN-344); age not stated')
add('E27','Mechanism (intervention)','BM chimeras, bivalent+PSLN-344: donor-derived moDC with WT vs Ifnar-KO BM (cDC precursors removed); GM-CSF rescue of Ifnar-KO',
    '19.7 vs 2.09 %; rescue 12.4 %','S02!B30:F34','Arithmetic means (n=5)','Welch p = 4.0e-04 (KO vs WT); 0.0027 (GM-CSF vs KO)','Age not stated')
add('E28','Mechanism (intervention)','CCR2 antagonist INCB3344: lung GZMB+ CD8 d5 (young, PSLN-344); lung monocytes; Ly6C+ macrophages',
    '1.39 vs 6.77 %; 3.26 vs 9.86 %; 2.52 vs 15.4 %','S02!H30:I34; S07!B10:F14','Arithmetic means (n=5)','Welch p = 8.1e-05; 0.0010; 0.0029','GZMB readout in young mice only; S07-B age/timepoint not stated')
add('E29','Mechanism (intervention)','Gap-junction blocker carbenoxolone: recruited lung monocytes d3 (PSLN-344)','3.08 vs 7.28 %','S11!A17:B21','Arithmetic means (n=5)','Welch p=0.0041','CBX has off-target effects')
add('E30','Mechanism (intervention)','GM-CSF added to PSLN-212: lung Ly6C+CD11c+MHC-II+ (moDC-like) cells d5','13.8 vs 5.86 %','S02!B22:D26','Arithmetic means (n=5)','Welch p=0.0021','')
add('E31','Delivery','Alveolar-epithelial uptake of SRB-labelled particle with vs without Mn (AT2; AT1); AM uptake in SP-A/D-KO vs WT',
    'AT2 3.81 vs 15.8 %; AT1 3.00 vs 13.8 %; AM 12.7 vs 43.1 %','S08!A14:D18; S01!B20:E21','Arithmetic means','Welch p = 5.2e-04; 1.6e-05; 3.9e-05',
    'S08-C control values partly duplicate S01-B (3 of 5 identical); AT1 uptake of the same formulation differs 3.6x between S01-B (3.83%) and S08-C (13.8%)')
r=rline('ly6c_ccr2_mac_d5')
add('E32','Innate','Lung Ly6C+CCR2+ macrophages d5 (x10^5 cells): PSLN-212 vs PSLN-344',f"{r['PSLN-212_center']:.1f} vs {r['PSLN-344_center']:.1f}",'S07!B5:G5','Arithmetic mean (n=3)',f"Welch p={fmtp(r['344v212_welch_p'])}",'Inflammatory macrophage influx is higher with the failing formulation')
# ===================== ADAPTIVE =====================
for k,id_,lab in [('igg_ca09_d14','E40a','Serum IgG anti-CA09 d14 (GMT)'),('igg_aichi_d14','E40b','Serum IgG anti-Aichi d14 (GMT)'),
                  ('hai_ca09_d14','E41a','HAI anti-CA09 d14 (GMT)'),('hai_aichi_d14','E41b','HAI anti-Aichi d14 (GMT)'),
                  ('neut_ca09_d14','E42a','Neutralising titre anti-CA09 d14 (GMT)'),('neut_aichi_d14','E42b','Neutralising titre anti-Aichi d14 (GMT)'),
                  ('igg_ca09_d28','E43a','IgG anti-CA09 d28 after d14 boost (GMT)'),('igg_aichi_d28','E43b','IgG anti-Aichi d28 after d14 boost (GMT)'),
                  ('gcb_d7','E45a','MLN GC B cells d7 (%)'),('aicda_d5','E45b','MLN B-cell Aicda mRNA d5 (GM, n=3)'),('tfh_icoshi','E45c','MLN ICOS-hi Tfh d7 (%)'),
                  ('tfr_d7','E45d','MLN Tfr d7 (% Foxp3+ of CXCR5+ICOShi)'),('tfr_d30','E45e','MLN Tfr d30 (%)'),
                  ('ki67_cd8_d3','E46a','Lung Ki-67+ CD8 d3 (%)'),('gzmb_cd8_d3','E46b','Lung GZMB+ CD8 d3 (%)'),
                  ('ifng_cd8_h5_d14','E46c','MLN IFN-γ+ CD8 d14 after rgH5N1 restimulation (cross-reactive) (%)'),
                  ('ifng_cd8_h5_d60','E46d','MLN IFN-γ+ CD8 d60, rgH5N1 restimulation (%)'),('gzmb_cd8_d60','E46e','MLN GZMB+ CD8 d60 (%)'),
                  ('trm_d25','E46f','Lung CD69+CD103+ resident-memory CD8 d25 (%)')]:
    r=rline(k); y=r.get('PSLN-212(Y)_center',np.nan); sh=r.get('Sham_center',np.nan)
    add(id_,'Adaptive',f"{lab}: sham / aged PSLN-212 / aged PSLN-344 / young PSLN-212",
        f"{('%.3g'%sh) if not pd.isna(sh) else 'n.a.'} / {r['PSLN-212_center']:.3g} / {r['PSLN-344_center']:.3g} / {('%.3g'%y) if not pd.isna(y) else 'n.a.'}",
        f"{r.block}: "+cells(r.block),
        ('Geometric mean of per-animal titres; HAI <1:10 (recorded 0, sham only) set to 5' if r.scale=='log' else 'Arithmetic mean of per-animal %')+', n=5 (n=3 where noted)',
        (f"344/212 ratio of GMs {r['344v212_effect']:.2f} (95% CI {r['344v212_CI']})" if r.scale=='log' else f"344−212 difference {r['PSLN-344_center']-r['PSLN-212_center']:.2f} points (95% CI {r['344v212_CI']}); ratio of means {r['344v212_effect']:.2f}")+f"; Welch p={fmtp(r['344v212_welch_p'])}; Tukey p{fmtt(TK.loc[k,'tukey_p_344_vs_212'])}"+(f"; restoration fraction {RF.loc[k,'RF']} ({RF.loc[k,'RF_lo']}–{RF.loc[k,'RF_hi']})" if k in RF.index else ''))
for k,id_,lab in [('ifng_cd8_h1','E46g','MLN IFN-γ+ CD8 after H1N1 restimulation (timepoint not stated) (%)'),('ifng_cd8_h3','E46h','MLN IFN-γ+ CD8 after H3N2 restimulation (timepoint not stated) (%)')]:
    r=rline(k)
    add(id_,'Adaptive',f"{lab}: sham / aged PSLN-212 / aged PSLN-344 / young PSLN-212",f"{r['Sham_center']:.3g} / {r['PSLN-212_center']:.3g} / {r['PSLN-344_center']:.3g} / {r['PSLN-212(Y)_center']:.3g}",
        f"{r.block}: "+cells(r.block),'Arithmetic mean of per-animal %, n=5',
        f"344−212 difference {r['PSLN-344_center']-r['PSLN-212_center']:.2f} points (95% CI {r['344v212_CI']}); Welch p={fmtp(r['344v212_welch_p'])}; restoration fraction {RF.loc[k,'RF']} ({RF.loc[k,'RF_lo']}–{RF.loc[k,'RF_hi']})")
sv=RF.loc[['survival_all core','survival_d14 challenge','survival_d3 challenge','survival_d60 challenge']]
add('E47','Restoration','Survival restoration fraction (aged PSLN-344 vs aged PSLN-212, scaled to young PSLN-212): all core; d14; d3; d60',
    '; '.join(f"{r.RF} ({r.RF_lo}–{r.RF_hi})" for r in sv.itertuples()),'S06 core event columns','(surv344 − surv212)/(survY212 − surv212), pooled animals; 95% CI by block-stratified bootstrap (4,000)','','Compare with readout restoration fractions in sheet Restoration_fractions')
add('E41c','Adaptive','HAI ≥1:40 and ≥1:160, aged PSLN-212 vs aged PSLN-344 (both strains, 10 animals each)','≥1:40: 8/10 vs 10/10; ≥1:160: 0/10 vs 10/10',
    'S03!K3:O7 and K10:O14','Count of animals at or above threshold','','Aged PSLN-212 reached the human "seroprotective" 1:40 yet failed against 10x mLD50 (S03-I)')
add('E44','Adaptive','IgG2a/IgG1 ratio d14 (GM of per-animal ratios from S13 subclass titres): PSLN-212 / PSLN-344 / young PSLN-212; CA09 | Aichi',
    '0.54 / 1.85 / 2.50 | 0.46 / 2.30 / 2.79','S13!A3:O7','Per-animal IgG2a ÷ IgG1, then geometric mean','',
    'S03-B and S03-F hold the same ratios with group labels cyclically permuted; S13 labels are the ones consistent with total IgG (S03-A) and are used')
# ===================== SAFETY =====================
add('E50','Safety','Post-vaccination weight nadir (mean of per-animal minima, % of d0): vaccine alone / PSLN-212 / PSLN-344 / CMP-204 / PSLN-212/R848',
    '98.2 / 97.0 / 96.4 / 95.9 / 90.0','S08!A20:AE26','Per-animal minimum over d2–d10, averaged (n=5)',
    'PSLN-344 vs PSLN-212 Welch p=0.56; vs vaccine p=0.065; vs PSLN-212/R848 p=0.043','One PSLN-212/R848 animal has no d10 value (W26). Only weight measured; no clinical score, temperature or nasal histology')
add('E51','Safety','CNS transcripts 36 h after IN dosing (GM fold vs untreated): PSLN-344 vs PBS; cholera toxin (CT) vs PBS',
    'Ifnb1 1.32 vs 1.00; Tnf 1.59 vs 1.00; Isg15 1.13 vs 1.00 | CT: 5.5, 3.5, 2.7','S10!A3:N7','Geometric means, n=5',
    'PSLN-344 vs PBS Welch p = 0.17, 0.050, 0.49; vs sham p = 0.53, 0.36, 0.49; CT vs PBS p ≤ 0.0093','Single timepoint, transcript-level only; no Mn quantification, histology or behaviour; annotation calls it mean±SD though 5 per-animal values are present')
add('E52','Safety','Lung transcripts 16 h (linear fold = 10^mean log10; n=3): aged PSLN-344 vs young PSLN-212 — Tnf; Il10; Il6; Ccl2',
    '40.5 vs 13.9; 7.3 vs 1.8; 36.1 vs 60.3; 590 vs 1,391','S09!A2:V9 (panel 1)','10^(mean of log10 values)',
    'Welch p = 0.009; 0.021; 0.34; 0.22','PSLN-212/R848: Tnf 202x, Il10 179x')
add('E53','CMC','CDN-1807 encapsulation efficiency (%): PSLN-344 vs PSLN-212','54.8 ± 5.1 (CV 9.3%) vs 59.6 ± 4.6','S08!A11:O11','Mean ± SD of 3 preparations','',
    'Mn content per dose, particle size, zeta potential, morphology and stability are not in the workbook although the annotation says they were measured')
# ===================== INTEGRITY =====================
I=[
('I01','Critical','S06-C and S06-D (d14 vs d3 challenge) are identical in every one of 28 animal rows across 4 arms','S06!M3:Q30 vs S06!A34:E61','S06-D excluded; sensitivity uses S15-D weight-implied outcomes (PSLN-344 2/7, PSLN-212(Y) 2/7 deaths)'),
('I02','Critical','S03-I survival vs S13-F weights (annotated as the same animals): PSLN-212 recorded 7/7 deaths on d5–6 but all 7 have weights to d14 (4 frozen ≈78–80% from d10, 3 recover); sham recorded 4 deaths by d6 but 7 weights at d6; S13-F has "Naive" in place of CMP-204','S03!A17:F51 vs S13!A32:AJ40','S03-I excluded from primary pooling; sensitivity with PSLN-212 = 4/7'),
('I03','Critical','S03-J vs S13-G: group sets differ (Sham/PSLN-212/PSLN-344 vs PSLN-344/Sham/Naive); sham 9/10 recorded deaths vs 5/10 implied by weights; stated n=9 vs 10 rows; one PSLN-344 row lacks a time (G46); age not stated','S03!G15:J46; S13!A42:AE50','Excluded from pooling; reported descriptively'),
('I04','Critical','Body-weight trajectories copied between experiments: S15-C PSLN-344 ≡ S15-I Vaccine+PSLN-344 (40/42 animal-days d2–d12); S09-E PSLN-344(Y) ≡ S15-M PSLN-212(Y) (6 animals, 4–7 days, 8–10-digit values; BALB/c vs C57BL/6, different formulation); S15-A PSLN-344 ≡ S15-M PSLN-344 (animals 2–3, 5 days); S15-A sham d4 row ≡ S15-M PSLN-212 d4 row (7/7); S15-M sham ≡ S15-O sham (5-decimal values; C57BL/6 vs Swiss Webster); S09-E ≡ S09-G PSLN-212(Y) animal 8 (7/7 days); shared fractional parts with shifted integers (e.g. 99.48427673 → 97.48427673)','S15, S09, S13 weight blocks; see sheet Dup_trajectories','Weights not used as independent corroboration for S06-A, S06-C, S15-H, S15-L, S15-N; strain generalisation treated as unverified. Chance expectation of ≥4 identical aligned non-plateau days: 0.013 trajectory pairs; observed 18'),
('I05','Critical','S11-A (alveolar macrophages) and S11-B (neutrophils) share 35 of 100 aligned per-animal values','S11!B3:U7 vs S11!B10:U14','Both blocks excluded'),
('I06','Major','S03-B/S03-F IgG2a/IgG1 ratios equal the ratios computed from S13-A–D but with group labels cyclically permuted','S03!G2:I14 vs S13!A2:O7','S13-derived ratios used; S03-B/F not used'),
('I07','Major','S04-B "Tfh:Tfr" equals (100 − Foxp3%)/Foxp3% of S04-B Foxp3 exactly — a transform, not an independent quotient','S04!A7:D19','Not counted as separate evidence'),
('I08','Major','S07-C: both columns labelled "Ly6C-CD206+ MΦ" although two different subsets were transferred','S07!B15:C20','Excluded (uninterpretable)'),
('I09','Major','S09-A panel 2, labelled "16h", reproduces S01-A 72 h Ifnb1 values (7/7 groups); S09-A "PBS" carries S01-A "Sham" values; S09-A panel 1 re-presents S01-A 16 h samples','S09!A1:AS9 vs S01!A2:L10','Panel 2 read as 72 h; S09-A not counted as independent of S01-A'),
('I10','Major','S09-C: day-12 weights identical for all 8 PSLN-212(Y) and all 8 PSLN-344(Y) animals','S09!G18:N18 vs W18:AD18','Weights not used'),
('I11','Major','Unvaccinated, unchallenged aged animals die within 14 days: 4/21 pooled (S06-G 3/7)','S06!L62:L68, R62:R68, F99:F105','Reported; colony health/labelling must be resolved — confounds every aged survival endpoint'),
('I12','Major','S01-B vs S08-C: 3/5 AECII/PSLN-SRB values identical; two S01-B AECI values reappear as S08-C AECII-PSLN-344-SRB; AT1 uptake of the same formulation 3.83% vs 13.8%','S01!B14:F17 vs S08!A14:D18','Mn-reduces-uptake finding carried with caveat'),
('I13','Major','Dead animals handled inconsistently in weight blocks: weights frozen (carried forward) in PSLN-212/PSLN-344/young arms but dropped in sham arms','S13-F, S13-G, S15-A…O','Group mean weights not computed; weights used only to infer deaths'),
('I14','Minor','Stated n vs rows: S13-E n=5 vs 7; S05-A/B n=3 vs 2; S09-B sham 8 rows (annotation 7); S09-F sham 7 rows (annotation 8; S09-G has 8 sham weights)','S13!R2:V30; S05!A1:I10; S09','Rows analysed as present'),
('I15','Minor','S05-A/B conditions text mixes OVA and bivalent vaccine for an NP-tetramer readout; no sham group','S05!A1:I10','Low weight'),
('I16','Minor','S10-A annotated as mean±SD but holds 5 per-animal values per group','S10!A1:N7','Treated as per-animal values'),
('I17','Minor','S08-A contains "PSLN-344/R848", not defined in the materials; S08-B reports CDN-1807 encapsulation for PSLN-R848 (no CDN) and CMP-204 (cGAMP)','S08!K2:M7; S08!A10:O11','Not relied on'),
('I18','Minor','Unlabelled numeric region S08 rows 89–101 (col A = 14; cols C/D = 0)','S08!A89:D101','Excluded'),
('I19','Minor','Not stated: timepoints for S07-B, S11-E, S13-H, S14-A; challenge virus/dose/day for S15-L/N; challenge day for S06-E (imprinting); age for S02-H, S07-B, S08-A, S03-J; adjuvant for PTX groups','annotation','Flagged where used'),
('I20','Minor','S09-A panel 1: identical value 2.302879 for Tnf and Il10 in the same PSLN-212/R848 animal','S09!O8, O9','Not relied on'),
]
Ireg=pd.DataFrame(I,columns=['ID','severity','finding','cells','handling'])
Led=pd.DataFrame(L)
Led.to_csv('/tmp/work/ledger.csv',index=False); Ireg.to_csv('/tmp/work/integrity.csv',index=False)
print(Led[['ID','statement','value','statistic']].to_string())

import pandas as pd, numpy as np, warnings
from scipy.stats import hypergeom, norm
from statsmodels.duration.survfunc import survdiff
warnings.filterwarnings('ignore')
S=pd.read_csv('/tmp/work/survival_long.csv')
S.loc[(S.block=='S03-J')&(S.time.isna()),'time']=21
def counts(block,group,override=None):
    if override and (block,group) in override: return override[(block,group)]
    d=S[(S.block==block)&(S.group_norm==group)]; return int(d.event.sum()), len(d)
def exact_strat(strata):
    """strata: list of (d1,n1,d0,n0). Exact conditional test of common OR=1 (sum of hypergeometrics)."""
    dist=np.array([1.0]); lo=0; tobs=0
    for d1,n1,d0,n0 in strata:
        m=d1+d0; N=n1+n0
        ks=np.arange(max(0,m-n0),min(m,n1)+1); pk=hypergeom.pmf(ks,N,m,n1)
        new=np.zeros(len(dist)+len(ks)-1)
        for i,p in enumerate(pk): new[i:i+len(dist)]+=p*dist
        dist=new; lo+=ks[0]; tobs+=d1
    support=np.arange(lo,lo+len(dist))
    p_lower=dist[support<=tobs].sum()
    p_two=dist[dist<=dist[support==tobs][0]*(1+1e-9)].sum()
    return p_lower,min(1,p_two)
def mh(strata):
    num=den=0; rd_num=rd_w=0; var_num=0
    for d1,n1,d0,n0 in strata:
        N=n1+n0; a=d1; b=n1-d1; c=d0; dd=n0-d0
        num+=a*dd/N; den+=b*c/N
        w=n1*n0/N; rd_num+=w*(a/n1-c/n0); rd_w+=w
        # Greenland-Robins/Sato variance components for RD
        var_num+=(a*b*n0**3+c*dd*n1**3)/(n1*n0*N**2) if n1*n0>0 else 0
    rd=rd_num/rd_w; se=np.sqrt(var_num)/rd_w
    return (num/den if den>0 else np.nan), rd, (rd-1.96*se, rd+1.96*se)
def strat_logrank(items,ga,gb):
    t=[];e=[];g=[];s=[]
    for k,(block,oa,ob) in enumerate(items):
        for grp,lab in ((oa,1),(ob,0)):
            d=S[(S.block==block)&(S.group_norm==grp)]
            t+=list(d.time);e+=list(d.event);g+=[lab]*len(d);s+=[k]*len(d)
    stat,p=survdiff(np.array(t,float),np.array(e),np.array(g),strata=np.array(s))
    return p
def run(name,items,override=None,with_lr=True):
    strata=[]; tot=[0,0,0,0]
    for block,ga,gb in items:
        d1,n1=counts(block,ga,override); d0,n0=counts(block,gb,override)
        strata.append((d1,n1,d0,n0)); tot=[tot[0]+d1,tot[1]+n1,tot[2]+d0,tot[3]+n0]
    pl,p2=exact_strat(strata); OR,rd,ci=mh(strata)
    lr=strat_logrank(items,None,None) if (with_lr and not override) else np.nan
    return dict(analysis=name,strata=len(items),deaths_A=f'{tot[0]}/{tot[1]}',mort_A_pct=round(100*tot[0]/tot[1],1),
                deaths_B=f'{tot[2]}/{tot[3]}',mort_B_pct=round(100*tot[2]/tot[3],1),
                MH_risk_diff_pct=round(100*rd,1),RD_95CI=f'{100*ci[0]:.1f} to {100*ci[1]:.1f}',MH_OR=round(OR,4),
                exact_strat_p_two_sided=p2,exact_strat_p_one_sided=pl,strat_logrank_p=lr)
core=['S06-A','S06-B','S06-C','S06-E','S06-F','S06-G']
rows=[]
# ---- PSLN-344 vs PSLN-212 (aged) ----
rows.append(run('P1 PSLN-344 vs PSLN-212 | core aged BALB/c S06 (A,B,C,E,F,G; S06-D excluded as duplicate of S06-C)',[(b,'PSLN-344','PSLN-212') for b in core]))
rows.append(run('P1-s1 as P1 but counts replaced by weight-implied deaths where discordant (S06-C 212=6, S06-E 212=6/344=1, S06-G 344=2)',
                [(b,'PSLN-344','PSLN-212') for b in core],
                override={('S06-C','PSLN-212'):(6,7),('S06-E','PSLN-212'):(6,7),('S06-E','PSLN-344'):(1,7),('S06-G','PSLN-344'):(2,7)}))
rows.append(run('P1-s2 as P1 + S06-D using S15-D weight-implied outcomes (344 2/7, 212 5/7)',[(b,'PSLN-344','PSLN-212') for b in core]+[('S06-D','PSLN-344','PSLN-212')],
                override={('S06-D','PSLN-344'):(2,7),('S06-D','PSLN-212'):(5,7)}))
rows.append(run('P1-s3 as P1 + S03-I with PSLN-212 = S13-F weight-implied 4/7',[(b,'PSLN-344','PSLN-212') for b in core]+[('S03-I','PSLN-344','PSLN-212')],
                override={('S03-I','PSLN-212'):(4,7)}))
rows.append(run('P1-s4 leave-out: only d14 challenges (S06-A, S06-C)',[(b,'PSLN-344','PSLN-212') for b in ['S06-A','S06-C']]))
rows.append(run('P1-s5 only d60 challenges (S06-E,F,G) = durability',[(b,'PSLN-344','PSLN-212') for b in ['S06-E','S06-F','S06-G']]))
rows.append(run('P1-s6 only d3 challenge (S06-B) = early onset',[('S06-B','PSLN-344','PSLN-212')]))
rows.append(run('P2 all aged/older strata incl. homologous + other strains + imprinting (S03-I, S06 core, imprint x4, S15-L, S15-N; S03-J, S06-D excluded)',
                [(b,'PSLN-344','PSLN-212') for b in ['S03-I']+core+['S15-L','S15-N']]+
                [('S06-E_imprint','Naive+PSLN-344','Naive+PSLN-212'),('S06-E_imprint','Imprinting+PSLN-344','Imprinting+PSLN-212'),
                 ('S06-F_imprint','Naive+PSLN-344','Naive+PSLN-212'),('S06-F_imprint','Imprinting+PSLN-344','Imprinting+PSLN-212')]))
rows.append(run('P3 other strains only (S15-L C57BL/6, S15-N Swiss Webster)',[(b,'PSLN-344','PSLN-212') for b in ['S15-L','S15-N']]))
rows.append(run('P4 imprinting blocks (14-mo) PSLN-344 vs PSLN-212 (4 strata)',
                [('S06-E_imprint','Naive+PSLN-344','Naive+PSLN-212'),('S06-E_imprint','Imprinting+PSLN-344','Imprinting+PSLN-212'),
                 ('S06-F_imprint','Naive+PSLN-344','Naive+PSLN-212'),('S06-F_imprint','Imprinting+PSLN-344','Imprinting+PSLN-212')]))
# ---- PSLN-344 vs Sham ----
rows.append(run('Q1 PSLN-344 vs Sham | core aged S06',[(b,'PSLN-344','Sham') for b in core]))
# ---- PSLN-344 (aged) vs PSLN-212 (young) = residual age gap ----
rows.append(run('R1 aged PSLN-344 vs young PSLN-212 | core S06',[(b,'PSLN-344','PSLN-212(Y)') for b in core]))
rows.append(run('R2 aged PSLN-344 vs young PSLN-212 | d60 only',[(b,'PSLN-344','PSLN-212(Y)') for b in ['S06-E','S06-F','S06-G']]))
# ---- age deficit with PSLN-212 ----
rows.append(run('A1 aged PSLN-212 vs young PSLN-212 | core S06',[(b,'PSLN-212','PSLN-212(Y)') for b in core]))
rows.append(run('A2 aged PSLN-212 vs Sham | core S06',[(b,'PSLN-212','Sham') for b in core]))
R=pd.DataFrame(rows)
pd.set_option('display.width',300); pd.set_option('display.max_colwidth',140)
print(R.to_string())
R.to_csv('/tmp/work/pooled_survival.csv',index=False)
# background (non-challenged) mortality
bg=S[S.group_norm=='Untreated'].groupby('block').event.agg(['sum','size'])
print(bg, 'pooled', bg['sum'].sum(),'/',bg['size'].sum())

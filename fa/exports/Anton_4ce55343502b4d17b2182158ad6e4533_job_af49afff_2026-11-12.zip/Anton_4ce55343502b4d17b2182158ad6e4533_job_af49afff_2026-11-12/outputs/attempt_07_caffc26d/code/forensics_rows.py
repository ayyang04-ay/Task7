import pandas as pd, itertools
V=pd.read_csv('/tmp/work/values_long.csv')
tc=[b for b in V.block.unique() if b.startswith('S15') or b in ('S08-D','S09-C','S09-E','S09-G','S13-F','S13-G','S01-D','S01-E','S11-A','S11-B','S11-D','S02-F','S07-A','S08-A')]
T=V[V.block.isin(tc)].copy(); T['level']=T.level.astype(str)
rows={}
for (b,g,l),d in T.groupby(['block','group_norm','level']):
    if l in ('0','0.0'): continue
    rows[(b,g,l)]=d.sort_values('rep')[['value','cell']].values.tolist()
out=[]
for a,b in itertools.combinations(rows,2):
    A,B=rows[a],rows[b]
    n=min(len(A),len(B))
    same=[(A[i][1],B[i][1],A[i][0]) for i in range(n) if A[i][0]==B[i][0]]
    # ignore rows where the shared values are all LOCF plateau-ish (we can't tell) -> require >=3 distinct shared values
    if len(same)>=3 and len(set(x[2] for x in same))>=3:
        out.append((a,b,len(same),n,same[:8]))
for o in sorted(out,key=lambda x:-x[2]):
    print(o[0],'<->',o[1],f'{o[2]}/{o[3]} positions identical',o[4])

import pandas as pd, numpy as np
V=pd.read_csv('/tmp/work/values_long.csv'); S=pd.read_csv('/tmp/work/survival_long.csv')
pairs={ # weight block -> survival block (per annotation)
 'S15-A':'S06-A','S15-B':'S06-B','S15-C':'S06-C','S15-D':'S06-D','S15-E':'S06-E','S15-F':'S06-F','S15-G':'S06-G',
 'S15-I':'S15-H','S15-J':'S06-E_imprint','S15-K':'S06-F_imprint','S15-M':'S15-L','S15-O':'S15-N',
 'S13-F':'S03-I','S13-G':'S03-J','S09-C':'S09-B','S09-E':'S09-D','S09-G':'S09-F'}
def implied(d, last_day):
    d=d.assign(lvf=d.level.astype(float)).sort_values('lvf'); lv=d.lvf.tolist(); x=d.value.tolist()
    if lv[-1] < last_day:            # trajectory stops -> died after last recorded day
        return 'dead', f'record ends d{int(lv[-1])}'
    # terminal plateau (carried-forward): >=2 identical terminal values below 90%
    k=1
    while k < len(x) and x[-1-k]==x[-1]: k+=1
    if (k>=2 and x[-1] < 90) or k>=3:
        return 'dead', f'frozen at {x[-1]} from d{int(lv[-k])}'
    return 'alive', f'd{int(lv[-1])}={x[-1]}'
rows=[]
for wb,sb in pairs.items():
    W=V[V.block==wb]; last=W.level.astype(float).max()
    for g,dg in W.groupby('group_norm'):
        res=[implied(da,last) for r,da in dg.groupby('rep')]
        wdead=sum(1 for r in res if r[0]=='dead')
        sg=S[(S.block==sb)&(S.group_norm==g)]
        rec=int(sg.event.sum()) if len(sg) else None
        rows.append(dict(weight_block=wb,survival_block=sb,group=g,n_weight=len(res),weight_implied_deaths=wdead,
                         recorded_deaths=rec,n_surv=len(sg) if len(sg) else None,
                         concordant=(rec==wdead) if rec is not None else 'group absent in survival block'))
R=pd.DataFrame(rows)
pd.set_option('display.width',200)
print(R.to_string())
R.to_csv('/tmp/work/weight_vs_survival.csv',index=False)

import pandas as pd, numpy as np, warnings
from scipy.stats import hypergeom, fisher_exact
warnings.filterwarnings('ignore')
rng=np.random.default_rng(20260915)
V=pd.read_csv('/tmp/work/values_long.csv'); S=pd.read_csv('/tmp/work/survival_long.csv')
V.loc[(V.block.isin(['S03-C','S03-G']))&(V.value==0),'value']=5.0
R=pd.read_csv('/tmp/work/readouts.csv')
B=4000
def vals(block,level,grp):
    d=V[(V.block==block)&(V.group_norm==grp)]
    if isinstance(level,str) or (level is not None and not (isinstance(level,float) and np.isnan(level))):
        d=d[d.level.astype(str)==str(level)]
    return d.value.values.astype(float)
out=[]
for r in R.itertuples():
    a=vals(r.block,r.level,'PSLN-344'); b=vals(r.block,r.level,'PSLN-212'); c=vals(r.block,r.level,'PSLN-212(Y)')
    if len(a)==0 or len(b)==0 or len(c)==0: continue
    f=(np.log10 if r.scale=='log' else (lambda z:z))
    cen=(lambda z: np.mean(f(z)))
    point=(cen(a)-cen(b))/(cen(c)-cen(b))
    bs=[]
    for _ in range(B):
        aa=rng.choice(a,len(a)); bb=rng.choice(b,len(b)); cc=rng.choice(c,len(c))
        den=cen(cc)-cen(bb)
        if abs(den)>1e-9: bs.append((cen(aa)-cen(bb))/den)
    lo,hi=np.percentile(bs,[2.5,97.5])
    out.append(dict(key=r.key,readout=r.readout,stage=r.stage,RF=round(point,2),RF_lo=round(lo,2),RF_hi=round(hi,2)))
# survival restoration fractions from pooled core S06 blocks
def surv_rf(blocks,label):
    d=S[S.block.isin(blocks)]
    arms={g:(1-d[d.group_norm==g].event.values) for g in ['PSLN-344','PSLN-212','PSLN-212(Y)']}
    pt=(arms['PSLN-344'].mean()-arms['PSLN-212'].mean())/(arms['PSLN-212(Y)'].mean()-arms['PSLN-212'].mean())
    bs=[]
    for _ in range(B):
        # stratified bootstrap: resample animals within block x arm
        s={}
        for g in arms:
            xs=[]
            for bl in blocks:
                x=1-d[(d.block==bl)&(d.group_norm==g)].event.values; xs.append(rng.choice(x,len(x)))
            s[g]=np.concatenate(xs).mean()
        den=s['PSLN-212(Y)']-s['PSLN-212']
        if den>0: bs.append((s['PSLN-344']-s['PSLN-212'])/den)
    lo,hi=np.percentile(bs,[2.5,97.5])
    out.append(dict(key='survival_'+label,readout=f'Survival to 14 d post-challenge ({label}; blocks {",".join(blocks)})',stage='6 protection',RF=round(pt,2),RF_lo=round(lo,2),RF_hi=round(hi,2)))
surv_rf(['S06-A','S06-B','S06-C','S06-E','S06-F','S06-G'],'all core')
surv_rf(['S06-A','S06-C'],'d14 challenge')
surv_rf(['S06-B'],'d3 challenge')
surv_rf(['S06-E','S06-F','S06-G'],'d60 challenge')
O=pd.DataFrame(out); O.to_csv('/tmp/work/restoration_fractions.csv',index=False)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',90)
print(O.to_string())
# cleanest tier pooled (blocks not implicated by duplication screen, concordant +-1 with weights)
def exact_strat(strata):
    dist=np.array([1.0]); lo=0; tobs=0
    for d1,n1,d0,n0 in strata:
        m=d1+d0; N=n1+n0; ks=np.arange(max(0,m-n0),min(m,n1)+1); pk=hypergeom.pmf(ks,N,m,n1)
        new=np.zeros(len(dist)+len(ks)-1)
        for i,p in enumerate(pk): new[i:i+len(dist)]+=p*dist
        dist=new; lo+=ks[0]; tobs+=d1
    sup=np.arange(lo,lo+len(dist)); return dist[sup<=tobs].sum(), min(1,dist[dist<=dist[sup==tobs][0]*(1+1e-9)].sum())
st=[]; 
for bl in ['S06-B','S06-E','S06-F','S06-G']:
    d=S[S.block==bl]; a=d[d.group_norm=='PSLN-344']; b=d[d.group_norm=='PSLN-212']
    st.append((int(a.event.sum()),len(a),int(b.event.sum()),len(b)))
print('\nCleanest tier (S06-B,E,F,G):', st, 'PSLN-344 deaths', sum(x[0] for x in st),'/',sum(x[1] for x in st),
      '| PSLN-212 deaths', sum(x[2] for x in st),'/',sum(x[3] for x in st), '| exact stratified p (one-sided, two-sided)=',exact_strat(st))
# durability within PSLN-344 aged: d14 vs d60
print('PSLN-344 aged deaths d14 (S06-A,C) 1/14 vs d60 (S06-E,F,G) 7/21: Fisher p=',fisher_exact([[1,13],[7,14]])[1])

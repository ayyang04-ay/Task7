import pandas as pd, numpy as np, itertools
V=pd.read_csv('/tmp/work/values_long.csv')
wb_blocks=[b for b in V.block.unique() if b.startswith('S15') or b in ('S08-D','S09-C','S09-E','S09-G','S13-F','S13-G')]
W=V[V.block.isin(wb_blocks)].copy(); W['level']=W.level.astype(float)
traj={}
for (b,g,r),d in W.groupby(['block','group_norm','rep']):
    d=d.sort_values('level'); vals=d.value.tolist(); lv=d.level.tolist()
    keep={}
    for i,(l,x) in enumerate(zip(lv,vals)):
        if l==0: continue
        if i>0 and x==vals[i-1]: continue
        if i+1<len(vals) and x==vals[i+1]: continue
        keep[l]=round(x,8)
    traj[(b,g,r)]=keep
keys=list(traj)
# empirical per-aligned-day coincidence probability among pairs from DIFFERENT blocks
tot=0; same=0
for a,b in itertools.combinations(keys,2):
    if a[0]==b[0]: continue
    A,B=traj[a],traj[b]
    for l in A:
        if l in B:
            tot+=1; same+= A[l]==B[l]
p=same/tot
print(f'aligned day-pairs compared={tot}, identical={same}, p_day={p:.5f}')
# Expected number of cross-block trajectory pairs with >=k identical days under independence (binomial with ~6 shared days)
npairs=sum(1 for a,b in itertools.combinations(keys,2) if a[0]!=b[0])
from scipy.stats import binom
for k in range(2,8):
    print(k, 'expected pairs by chance ~', round(npairs*binom.sf(k-1,6,p),4))
# Observed counts
cnt={}
for a,b in itertools.combinations(keys,2):
    if a[0]==b[0] and a[1]==b[1]: continue
    A,B=traj[a],traj[b]
    k=sum(1 for l in A if l in B and A[l]==B[l])
    cnt[k]=cnt.get(k,0)+1
print('observed distribution of identical aligned days:',dict(sorted(cnt.items())))

import pandas as pd, numpy as np, warnings
from statsmodels.stats.multicomp import pairwise_tukeyhsd
from scipy.stats import fisher_exact
warnings.filterwarnings('ignore')
V=pd.read_csv('/tmp/work/values_long.csv'); V.loc[(V.block.isin(['S03-C','S03-G']))&(V.value==0),'value']=5.0
R=pd.read_csv('/tmp/work/readouts.csv')
rows=[]
for r in R.itertuples():
    d=V[V.block==r.block]
    if isinstance(r.level,str): d=d[d.level.astype(str)==r.level]
    d=d[d.group_norm.isin(['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)','PSLN-344(Y)','Vaccine'])]
    y=np.log10(d.value.values) if r.scale=='log' else d.value.values
    if d.group_norm.nunique()<3: continue
    t=pairwise_tukeyhsd(y,d.group_norm.values)
    res=pd.DataFrame(t._results_table.data[1:],columns=t._results_table.data[0])
    m=res[((res.group1=='PSLN-212')&(res.group2=='PSLN-344'))|((res.group1=='PSLN-344')&(res.group2=='PSLN-212'))]
    if len(m): rows.append(dict(key=r.key,groups=d.group_norm.nunique(),tukey_p_344_vs_212=float(m['p-adj'].iloc[0])))
T=pd.DataFrame(rows); T.to_csv('/tmp/work/tukey.csv',index=False)
print(T.to_string()); print('n readouts with Tukey p<0.05:',(T.tukey_p_344_vs_212<0.05).sum(),'of',len(T))
# ---- power by exact simulation (Fisher two-sided, alpha .05)
rng=np.random.default_rng(7)
def power(p1,p0,n,sims=4000):
    hit=0
    for _ in range(sims):
        a=rng.binomial(n,p1); b=rng.binomial(n,p0)
        if fisher_exact([[a,n-a],[b,n-b]])[1]<0.05: hit+=1
    return hit/sims
print('\nPlanning power (Fisher exact, two-sided 0.05):')
for p1,p0,lab in [(0.24,0.90,'observed core rates 23.8% vs 90.5%'),(0.35,0.75,'shrunk: PSLN-344 35% vs PSLN-212 75%'),(0.30,0.60,'vs benchmark: 30% vs 60%'),(0.33,0.05,'aged PSLN-344 vs young (d60 gap) 33% vs 5%')]:
    for n in [7,10,12,15,20,25,30,35,40]:
        pw=power(p1,p0,n)
        if pw>=0.8:
            print(f'  {lab}: n/arm for >=80%: {n} (power {pw:.2f})'); break
    for n in [7,10,12,15,20,25,30,35,40,50]:
        pw=power(p1,p0,n)
        if pw>=0.9:
            print(f'  {lab}: n/arm for >=90%: {n} (power {pw:.2f})'); break
print('  power of current n=7/arm design for observed rates:',power(0.24,0.90,7),' for shrunk rates:',power(0.35,0.75,7))
# viral titre (continuous) planning
from statsmodels.stats.power import TTestIndPower
for d_log,sd in [(1.0,0.8),(0.7,0.8)]:
    n=TTestIndPower().solve_power(effect_size=d_log/sd,alpha=0.05,power=0.9)
    print(f'  lung viral titre: detect {d_log} log10 difference, SD {sd}: n/arm = {np.ceil(n):.0f} for 90% power')

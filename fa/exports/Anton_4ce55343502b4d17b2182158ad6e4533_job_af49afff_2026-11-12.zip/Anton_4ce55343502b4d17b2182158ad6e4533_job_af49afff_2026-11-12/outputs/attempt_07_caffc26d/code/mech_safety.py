import pandas as pd, numpy as np, warnings
from scipy import stats
warnings.filterwarnings('ignore')
V=pd.read_csv('/tmp/work/values_long.csv')
def g(block,group,level=None):
    d=V[(V.block==block)&(V.group_norm==group)]
    if level is not None: d=d[d.level.astype(str)==str(level)]
    return d.value.values.astype(float), (d.cell.iloc[0]+'..'+d.cell.iloc[-1]) if len(d) else ''
def cmp(block,a,b,level=None,log=False,label=''):
    x,cx=g(block,a,level); y,cy=g(block,b,level)
    if log: t=stats.ttest_ind(np.log10(x),np.log10(y),equal_var=False)
    else: t=stats.ttest_ind(x,y,equal_var=False)
    mw=stats.mannwhitneyu(x,y,alternative='two-sided').pvalue
    mx=10**np.log10(x).mean() if log else x.mean(); my=10**np.log10(y).mean() if log else y.mean()
    print(f'{label:70s} {a} {mx:.3g} (n={len(x)}, {cx}) vs {b} {my:.3g} (n={len(y)}, {cy}); ratio={mx/my:.3g}; Welch p={t.pvalue:.2g}; MWU p={mw:.2g}')
print('=== S08-A Ifnb1 dose-response (geometric means, n=3) ===')
for dose in [1,5,10,20,40]:
    row=[]
    for grp in ['CMP-204','PSLN-212','PSLN-344','PSLN-344/R848']:
        x,_=g('S08-A',grp,dose); row.append(f'{grp}={10**np.log10(x).mean():.2f}')
    x344,_=g('S08-A','PSLN-344',dose); x212,_=g('S08-A','PSLN-212',dose)
    t=stats.ttest_ind(np.log10(x344),np.log10(x212),equal_var=False)
    print(f'dose {dose:>2} ug: '+'; '.join(row)+f' | 344/212 ratio={10**(np.log10(x344).mean()-np.log10(x212).mean()):.2f}, Welch(log) p={t.pvalue:.2g}')
x,_=g('S08-A','PSLN-212',40); y,_=g('S08-A','PSLN-344',10)
print('PSLN-212 @40ug GM', round(10**np.log10(x).mean(),2),' vs PSLN-344 @10ug GM', round(10**np.log10(y).mean(),2), 'Welch(log) p', stats.ttest_ind(np.log10(x),np.log10(y),equal_var=False).pvalue)
x20,_=g('S08-A','PSLN-344',20); x40,_=g('S08-A','PSLN-344',40)
print('PSLN-344 40 vs 20 ug: ratio', round(10**(np.log10(x40).mean()-np.log10(x20).mean()),3), 'p', stats.ttest_ind(np.log10(x40),np.log10(x20),equal_var=False).pvalue)
print('\n=== S08-B encapsulation efficiency (%, n=3) ===')
for grp in ['CMP-204','PSLN-212','PSLN-R848','PSLN-212/R848','PSLN-344']:
    x,c=g('S08-B',grp); print(f'{grp:15s} mean {x.mean():.1f} SD {x.std(ddof=1):.1f} CV {100*x.std(ddof=1)/x.mean():.1f}% ({c})')
print('\n=== S08-D post-vaccination body weight (reactogenicity), % of d0 ===')
D=V[V.block=='S08-D'].copy(); D['day']=D.level.astype(float)
for grp,d in D.groupby('group_norm'):
    mean_by_day=d.groupby('day').value.mean()
    per_animal_nadir=d.groupby('rep').value.min()
    nday=d.groupby('day').size().to_dict()
    print(f'{grp:15s} group-mean nadir {mean_by_day.min():.1f}% on d{int(mean_by_day.idxmin())}; per-animal nadir mean {per_animal_nadir.mean():.1f} (min {per_animal_nadir.min():.1f}); d10 mean {mean_by_day.loc[10]:.1f}; n/day {nday}')
# per-animal nadir comparison
def nadir(grp): return D[D.group_norm==grp].groupby('rep').value.min().values
for a,b in [('PSLN-344','PSLN-212'),('PSLN-344','Vaccine'),('PSLN-344','PSLN-212/R848'),('PSLN-344','CMP-204')]:
    t=stats.ttest_ind(nadir(a),nadir(b),equal_var=False); print(f'nadir {a} vs {b}: {nadir(a).mean():.1f} vs {nadir(b).mean():.1f}, Welch p={t.pvalue:.2g}')
print('\n=== S10-A CNS transcripts 36 h (fold vs untreated; n=5) ===')
for an in ['Ifnb1','Tnf','Isg15']:
    blk=f'S10-A_{an}'
    for a,b in [('PSLN-344','PBS'),('PSLN-344','Sham'),('CT','PBS'),('CT','PSLN-344')]:
        cmp(blk,a,b,label=f'{an}:')
print('\n=== S09-A panel1 (16 h, log10 fold; n=3) inflammatory transcripts: group means of log10 ===')
P=V[V.block=='S09-A_panel1']
tab=P.groupby(['level','group_norm']).value.mean().unstack()
print(tab.round(2).to_string())
print('linear fold (10^mean log10):'); print((10**tab).round(1).to_string())
for an in ['Il6','Tnf','Ccl2','Il10','Ccl5','Ccl3']:
    x=P[(P.level==an)&(P.group_norm=='PSLN-344')].value; y=P[(P.level==an)&(P.group_norm=='PSLN-212')].value; yy=P[(P.level==an)&(P.group_norm=='PSLN-212(Y)')].value
    print(f'{an}: 344 vs 212 Welch p={stats.ttest_ind(x,y,equal_var=False).pvalue:.2g}; 344 vs 212(Y) p={stats.ttest_ind(x,yy,equal_var=False).pvalue:.2g}')
print('\n=== Mechanistic interventions ===')
cmp('S02-C','PTX','PSLN-344',label='S02-C MLN DC carrying antigen (36h): PTX blocks migration')
cmp('S02-E','PTX','PSLN-344',label='S02-E OT-I proliferation with MLN DC: PTX')
cmp('S05-C','MLN+PTX','MLN',label='S05-C OT-I proliferation in MLN (d4): PTX')
cmp('S05-C','Lung+PTX','Lung',label='S05-C OT-I proliferation in lung (d4): PTX')
cmp('S02-G','PSLN-212+GM-CSF','PSLN-212',label='S02-G Ly6C+ moDC-like cells d5: GM-CSF added to PSLN-212')
cmp('S02-G','GM-CSF','PSLN-212',label='S02-G GM-CSF alone vs PSLN-212')
cmp('S02-H','IFN w/o cDC','WT w/o cDC',label='S02-H donor moDC (d3): Ifnar-KO vs WT BM (cDC precursors removed)')
cmp('S02-H','IFN w/ cDC','WT w/ cDC',label='S02-H donor moDC: Ifnar-KO vs WT BM (cDC precursors kept)')
cmp('S02-H','GMCSF','IFN w/o cDC',label='S02-H GM-CSF rescue of Ifnar-KO BM')
cmp('S02-H','GMCSF','WT w/o cDC',label='S02-H GM-CSF-rescued vs WT')
cmp('S02-I','PSLN-344(Y)+INCB3344','PSLN-344(Y)',label='S02-I lung GZMB+ CD8 d5 (young): CCR2 antagonist')
cmp('S07-B_mono','PSLN-344+INCB3344','PSLN-344',label='S07-B lung CD11b+Ly6C+ monocytes: CCR2 antagonist')
cmp('S07-B_Ly6Cmac','PSLN-344+INCB3344','PSLN-344',label='S07-B lung Ly6C+ macrophages: CCR2 antagonist')
cmp('S11-C','CBX+','CBX-',label='S11-C recruited monocytes d3: gap-junction blocker CBX')
cmp('S12-A','IFNAR-/- to WT','WT to WT',label='S12-A infiltrating donor monocytes d3 (young; n=3)')
cmp('S01-C','SPA/D','WT',label='S01-C AM uptake of DiD-liposomes (SP-A/D KO, young)')
cmp('S01-B','AECII/PSLN-SRB','AECII/FreeSRB',label='S01-B AT2 uptake PSLN-SRB vs free SRB')
cmp('S01-B','AECI/PSLN-SRB','AECI/FreeSRB',label='S01-B AT1 uptake')
cmp('S08-C','AECII-PSLN-344-SRB','AECII-PSLN-SRB',label='S08-C AT2 uptake: Mn-particle vs non-Mn particle')
cmp('S08-C','AECI-PSLN-344-SRB','AECI-PSLN-SRB',label='S08-C AT1 uptake: Mn-particle vs non-Mn particle')
x,_=g('S07-C','colB:Ly6C-CD206+ MΦ'); y,_=g('S07-C','colC:Ly6C-CD206+ MΦ')
print('S07-C (both columns labelled Ly6C-CD206+):', x.mean(), y.mean(), stats.ttest_ind(x,y,equal_var=False).pvalue)

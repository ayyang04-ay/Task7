#!/usr/bin/env bash
# Rebuilds every table, figure, the evidence ledger and the PDF/DOCX memo from the raw workbook.
# Requires the micromamba envs used in this environment: singlecell (pandas/openpyxl/scipy/statsmodels/matplotlib),
# core (reportlab), genomics (pandoc, pypdf).
set -euo pipefail
CODE=$(cd "$(dirname "$0")" && pwd); OUT=$(dirname "$CODE")
mkdir -p /tmp/work "$OUT/figures"
cd /tmp/work
R="micromamba run -n singlecell python"
$R $CODE/extract.py              > /tmp/work/log_extract.txt
$R $CODE/audit_n.py              > /tmp/work/log_audit_n.txt
$R $CODE/forensics.py            > /tmp/work/log_forensics1.txt
$R $CODE/forensics2.py           > /tmp/work/log_forensics2.txt
$R $CODE/forensics3.py           > /tmp/work/log_forensics3.txt
$R $CODE/forensics_null.py       > /tmp/work/log_forensics_null.txt
$R $CODE/forensics_surv_vec.py   > /tmp/work/log_forensics_surv.txt
$R $CODE/forensics_rows.py       > /tmp/work/log_forensics_rows.txt
$R $CODE/survival_analysis.py    > /tmp/work/log_survival.txt
$R $CODE/weight_vs_survival.py   > /tmp/work/log_weight_vs_survival.txt
$R $CODE/pooled_survival.py      > /tmp/work/log_pooled.txt
$R $CODE/readouts.py             > /tmp/work/log_readouts.txt
$R $CODE/mech_safety.py          > /tmp/work/log_mech_safety.txt
$R $CODE/restoration_bootstrap.py > /tmp/work/log_restoration.txt
$R $CODE/tukey_and_power.py      > /tmp/work/log_tukey_power.txt
$R $CODE/figures.py
$R $CODE/build_ledger.py         > /tmp/work/log_ledger.txt
$R $CODE/build_workbook.py
$R $CODE/verify_memo_numbers.py | tail -1
cd "$OUT"
micromamba run -n core python $CODE/md_to_pdf.py PSLN-344_portfolio_review_memo.md PSLN-344_portfolio_review_memo.pdf
micromamba run -n genomics pandoc PSLN-344_portfolio_review_memo.md -f gfm -t docx -o PSLN-344_portfolio_review_memo.docx --resource-path="$OUT"
echo "done"

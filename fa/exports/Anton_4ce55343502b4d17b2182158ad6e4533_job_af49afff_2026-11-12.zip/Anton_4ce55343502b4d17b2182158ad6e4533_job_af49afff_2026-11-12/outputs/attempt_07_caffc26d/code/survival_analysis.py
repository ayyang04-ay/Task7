import pandas as pd, numpy as np, itertools, warnings
from scipy.stats import fisher_exact
from statsmodels.duration.survfunc import survdiff, SurvfuncRight
warnings.filterwarnings('ignore')
S=pd.read_csv('/tmp/work/survival_long.csv')
# S03-J: one PSLN-344 animal (J46) has event=0 but no time (G46 empty). Treat as censored at end of follow-up (21 d) for
# the primary analysis; sensitivity = drop it (n=9, matching the stated n).
S.loc[(S.block=='S03-J')&(S.time.isna()),'time']=21
S['time']=S.time.astype(float)
meta={ # block: (model, vaccine, challenge, challenge day post-vaccination, antigenic relation, age)
'S03-I':('aged BALB/c','bivalent H1+H3','CA09 H1N1 10xLD50','d14','homologous','aged'),
'S03-J':('BALB/c (age not stated)','rgH5N1','wt VN04 H5N1','d2','homologous','not stated'),
'S06-A':('aged BALB/c','Aichi H3N2','PR8 H1N1 5xLD50','d14','heterosubtypic','aged'),
'S06-B':('aged BALB/c','Aichi H3N2','PR8 H1N1 5xLD50','d3','heterosubtypic','aged'),
'S06-C':('aged BALB/c','bivalent H1+H3','rgH5N1 5xLD50','d14','heterosubtypic','aged'),
'S06-D':('aged BALB/c','bivalent H1+H3','rgH5N1 5xLD50','d3','heterosubtypic','aged'),
'S06-E':('aged BALB/c','Aichi H3N2','PR8 H1N1 5xLD50','d60','heterosubtypic','aged'),
'S06-F':('aged BALB/c','bivalent H1+H3','rgH5N1 5xLD50','d60','heterosubtypic','aged'),
'S06-G':('aged BALB/c','CA09 H1N1','Perth H3N2 5xLD50','d60','heterosubtypic','aged'),
'S06-E_imprint':('14-mo BALB/c (PR8-imprinted or naive)','bivalent H1+H3','PR8 H1N1 5xLD50','not stated','heterologous H1 (homologous to imprinting virus)','14 mo'),
'S06-F_imprint':('14-mo BALB/c (PR8-imprinted or naive)','bivalent H1+H3','Perth H3N2 5xLD50','d14','heterologous (drifted) H3','14 mo'),
'S09-B':('young BALB/c','Aichi H3N2','PR8 H1N1 5xLD50','d21','heterosubtypic','young'),
'S09-D':('young BALB/c','CA09 H1N1','Perth H3N2 5xLD50','d21','heterosubtypic','young'),
'S09-F':('young BALB/c','bivalent H1+H3','VN04 rgH5N1 5xLD50','d180','heterosubtypic','young'),
'S13-E':('young BALB/c','bivalent H1+H3','CA09 H1N1 10xLD50','d14','homologous','young'),
'S15-H':('aged BALB/c','bivalent (or none)','VN04 rgH5N1 5xLD50','d3','heterosubtypic','aged'),
'S15-L':('aged C57BL/6 (young C57BL/6 for (Y))','bivalent H1+H3','not stated','not stated','not stated','aged'),
'S15-N':('aged Swiss Webster (young SW for (Y))','bivalent H1+H3','not stated','not stated','not stated','aged'),
}
def km_median(d):
    sf=SurvfuncRight(d.time.values,d.event.values)
    try: m=sf.quantile(0.5)
    except Exception: m=np.nan
    return m
def logrank(d1,d2):
    t=np.r_[d1.time,d2.time]; e=np.r_[d1.event,d2.event]; g=np.r_[np.zeros(len(d1)),np.ones(len(d2))]
    if e.sum()==0: return np.nan
    stat,p=survdiff(t,e,g); return p
rows=[]
for b,d in S.groupby('block',sort=False):
    for g,dg in d.groupby('group_norm',sort=False):
        rows.append(dict(block=b,group=g,n=len(dg),deaths=int(dg.event.sum()),survivors=int(len(dg)-dg.event.sum()),
                         pct_survival=round(100*(1-dg.event.mean()),1),median_surv_days=km_median(dg),
                         cells=f"{dg.cell_event.iloc[0]}..{dg.cell_event.iloc[-1]}"))
G=pd.DataFrame(rows)
# pairwise tests of interest
pairs=[('PSLN-344','PSLN-212'),('PSLN-344','Sham'),('PSLN-344','PSLN-212(Y)'),('PSLN-212','Sham'),('PSLN-212(Y)','PSLN-212'),
       ('CMP-204','PSLN-212'),('CMP-204','Sham'),
       ('Naive+PSLN-344','Naive+PSLN-212'),('Imprinting+PSLN-344','Imprinting+PSLN-212'),('Imprinting+PSLN-212','Naive+PSLN-212'),('Imprinting+PSLN-344','Naive+PSLN-344'),
       ('PSLN-344(Y)','Sham'),('PSLN-212(Y)','Sham'),('PSLN-344(Y)','PSLN-212(Y)'),('CMP-204(Y)','Sham'),('Sham','Naive'),
       ('3d Vaccine+PSLN-344','3d Vaccine'),('3d Vaccine+PSLN-344','3d PSLN-344'),('3d PSLN-344','3d Vaccine'),
       ('Untreated','Sham')]
T=[]
for b,d in S.groupby('block',sort=False):
    for a,c in pairs:
        da=d[d.group_norm==a]; dc=d[d.group_norm==c]
        if len(da)==0 or len(dc)==0: continue
        tab=[[int(da.event.sum()),int(len(da)-da.event.sum())],[int(dc.event.sum()),int(len(dc)-dc.event.sum())]]
        T.append(dict(block=b,contrast=f'{a} vs {c}',deaths_a=f'{tab[0][0]}/{len(da)}',deaths_b=f'{tab[1][0]}/{len(dc)}',
                      risk_diff_pct=round(100*(tab[0][0]/len(da)-tab[1][0]/len(dc)),1),
                      fisher_p=fisher_exact(tab)[1], logrank_p=logrank(da,dc)))
T=pd.DataFrame(T)
G['model']=G.block.map(lambda b: meta[b][0]); G['challenge']=G.block.map(lambda b: meta[b][2]+' at '+meta[b][3]+' post-vacc; '+meta[b][4])
G.to_csv('/tmp/outputs/tables_survival_by_group.csv',index=False) if False else None
pd.set_option('display.width',250)
print(G.to_string())
print(T.to_string())
G.to_csv('/tmp/work/surv_groups.csv',index=False); T.to_csv('/tmp/work/surv_tests.csv',index=False)
pd.DataFrame([(k,)+v for k,v in meta.items()],columns=['block','model','vaccine','challenge','challenge_timing','antigenic_relation','age']).to_csv('/tmp/work/surv_meta.csv',index=False)

import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
plt.rcParams.update({'font.size':9,'font.family':'DejaVu Sans','axes.spines.top':False,'axes.spines.right':False})
V=pd.read_csv('/tmp/work/values_long.csv'); S=pd.read_csv('/tmp/work/survival_long.csv')
G=pd.read_csv('/tmp/work/surv_groups.csv'); RF=pd.read_csv('/tmp/work/restoration_fractions.csv')
COL={'Sham':'#9e9e9e','PSLN-212':'#1f77b4','PSLN-344':'#d62728','PSLN-212(Y)':'#2ca02c','PSLN-344(Y)':'#ff7f0e','CMP-204':'#8c564b'}
# ---------------- Fig 1: survival by experiment ----------------
blocks=[('S06-A','Aichi→PR8, d14'),('S06-C','Biv.→rgH5N1, d14'),('S06-B','Aichi→PR8, d3'),('S06-D','[duplicate of S06-C]'),
        ('S06-E','Aichi→PR8, d60'),('S06-F','Biv.→rgH5N1, d60'),('S06-G','CA09→Perth, d60'),
        ('S03-I','Biv.→CA09 homol., d14'),('S03-J','rgH5N1→wt H5N1, d2*'),('S15-L','C57BL/6*'),('S15-N','Swiss Webster*')]
fig,ax=plt.subplots(figsize=(8.6,5.4))
arms=['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']; off={'Sham':-0.27,'PSLN-212':-0.09,'PSLN-344':0.09,'PSLN-212(Y)':0.27}
for i,(b,lab) in enumerate(blocks):
    for a in arms:
        r=G[(G.block==b)&(G.group==a)]
        if len(r)==0: continue
        r=r.iloc[0]; y=r.pct_survival
        ax.bar(i+off[a],y,width=0.17,color=COL[a],alpha=0.35 if b=='S06-D' else 0.95,edgecolor='none')
        ax.text(i+off[a],y+1.5,f"{r.survivors}/{r.n}",ha='center',va='bottom',fontsize=5.6,rotation=90)
ax.set_xticks(range(len(blocks))); ax.set_xticklabels([f"{b}\n{l}" for b,l in blocks],rotation=40,ha='right',fontsize=7)
ax.set_ylabel('% surviving to end of follow-up'); ax.set_ylim(0,122)
ax.axvspan(-0.5,1.5,color='#f0f0f0',zorder=-1); ax.axvspan(3.5,6.5,color='#f0f0f0',zorder=-1)
ax.text(0.5,117,'d14 challenge',ha='center',fontsize=7); ax.text(2.5,117,'d3',ha='center',fontsize=7); ax.text(5,117,'d60 challenge (durability)',ha='center',fontsize=7)
ax.text(8.9,117,'homologous / other strains',ha='center',fontsize=7)
ax.legend(handles=[Patch(color=COL[a],label=a+(' (young)' if '(Y)' in a else ' (aged)' if a!='Sham' else ' (aged, empty liposome)')) for a in arms],
          loc='upper center',bbox_to_anchor=(0.5,-0.47),ncol=4,frameon=False,fontsize=7)
ax.set_title('Fig. 1  Survival after lethal challenge, aged mice: PSLN-344 vs PSLN-212 (Mn-free) vs sham vs young\n'
             'Core pooled (S06-A,B,C,E,F,G): PSLN-344 10/42 deaths vs PSLN-212 38/42; exact stratified p = 3.0e-10',fontsize=8.5,loc='left')
ax.text(-0.06,-0.60,'Labels = survivors/n. Pale bars: S06-D is an exact duplicate of S06-C (excluded from all pooled analyses). S03-I PSLN-212: companion weights (S13-F) imply 3/7 survived.\n'
         '*S03-J age not stated; S15-L/N challenge virus not stated. Source: sheets S03, S06, S15 event columns (1 = death, 0 = censored). Reduction: survivors / n per group.',fontsize=6,transform=ax.transAxes,va='top')
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig1_survival_by_experiment.png',dpi=200,bbox_inches='tight'); plt.close()
# ---------------- Fig 2: restoration fractions ----------------
keep=['ifnb1_16h','mono_d4','cdc1_72h','ccr7_dc','mln_ova_dc','cd40','cd86','dc_otI','gcb_d7','tfh_icoshi','tfr_d7',
      'hai_ca09_d14','hai_aichi_d14','neut_ca09_d14','igg_ca09_d14','igg_aichi_d14','igg_ca09_d28','igg_aichi_d28',
      'ki67_cd8_d3','ifng_cd8_h5_d14','ifng_cd8_h5_d60','gzmb_cd8_d60','trm_d25',
      'survival_d14 challenge','survival_all core','survival_d60 challenge']
lab={'ifnb1_16h':'Lung Ifnb1, 16 h (S01-A)','mono_d4':'Lung monocytes d4 (S01-D)','cdc1_72h':'Lung cDC1 72 h (S01-F)','ccr7_dc':'CCR7+ migratory DC (S02-A)',
     'mln_ova_dc':'Antigen+ DC in MLN (S02-C)','cd40':'CD40 on MLN DC (S02-D)','cd86':'CD86 on MLN DC (S02-D)','dc_otI':'DC-driven OT-I prolif. (S02-E)',
     'gcb_d7':'GC B cells d7 (S03-K)','tfh_icoshi':'Tfh ICOS-hi d7 (S04-A)','tfr_d7':'Tfr d7, lower=better (S04-B)','hai_ca09_d14':'HAI CA09 d14 (S03-C)',
     'hai_aichi_d14':'HAI Aichi d14 (S03-G)','neut_ca09_d14':'Neut CA09 d14 (S03-D)','igg_ca09_d14':'IgG CA09 d14 (S03-A)','igg_aichi_d14':'IgG Aichi d14 (S03-E)',
     'igg_ca09_d28':'IgG CA09 d28 post-boost (S13-I)','igg_aichi_d28':'IgG Aichi d28 post-boost (S13-J)','ki67_cd8_d3':'Ki-67+ CD8 lung d3 (S05-D)',
     'ifng_cd8_h5_d14':'Cross-reactive IFN-γ CD8 d14 (S05-F)','ifng_cd8_h5_d60':'Cross-reactive IFN-γ CD8 d60 (S05-G)','gzmb_cd8_d60':'GZMB+ CD8 d60 (S05-H)',
     'trm_d25':'Lung TRM d25 (S05-I)','survival_d14 challenge':'SURVIVAL, d14 challenge (S06-A,C)','survival_all core':'SURVIVAL, all core (S06 ×6)',
     'survival_d60 challenge':'SURVIVAL, d60 challenge (S06-E,F,G)'}
D=RF.set_index('key').loc[keep].reset_index()
fig,ax=plt.subplots(figsize=(8.2,7.4))
y=np.arange(len(D))[::-1]
for yi,r in zip(y,D.itertuples()):
    c='#d62728' if r.key.startswith('survival') else ('#555555' if r.key in ('cd40','cd86','ifnb1_16h') else '#1f77b4')
    ax.errorbar(r.RF,yi,xerr=[[r.RF-r.RF_lo],[r.RF_hi-r.RF]],fmt='o',color=c,ms=4,capsize=2,lw=1)
ax.axvline(0,color='k',lw=0.6); ax.axvline(1,color='#2ca02c',lw=0.8,ls='--')
core=RF.set_index('key').loc['survival_all core']; ax.axvspan(core.RF_lo,core.RF_hi,color='#d62728',alpha=0.08)
ax.set_yticks(y); ax.set_yticklabels([lab[k] for k in D.key],fontsize=7.2)
ax.set_xlabel('Restoration fraction = (aged PSLN-344 − aged PSLN-212) / (young PSLN-212 − aged PSLN-212)\n0 = no gain from Mn²⁺; 1 = fully restored to young-PSLN-212 level (log10 scale for titres and mRNA)',fontsize=7)
ax.set_title('Fig. 2  How much of the aged deficit does Mn²⁺ close? (point, bootstrap 95% CI, 4,000 resamples)\n'
             'IFN-β fully restored; DC costimulation not; adaptive readouts & survival partially.\nShaded band = survival restoration, all core blocks.',fontsize=8,loc='left')
ax.set_xlim(-0.2,1.4)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig2_restoration_fractions.png',dpi=200,bbox_inches='tight'); plt.close()
# ---------------- Fig 3: key readouts dot plots ----------------
panels=[('S01-A_16h',None,'Lung Ifnb1 16 h\n(fold vs untreated)',True,['Sham','PSLN-212','PSLN-344','PSLN-212(Y)','PSLN-344(Y)']),
        ('S03-C',None,'HAI anti-CA09 d14',True,['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)']),
        ('S03-A',None,'IgG anti-CA09 d14\n(endpoint titre)',True,['Sham','CMP-204','PSLN-212','PSLN-344','PSLN-212(Y)']),
        ('S05-F',None,'IFN-γ+ CD8 (MLN), d14\nrgH5N1 restim (cross-reactive)',False,['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
        ('S05-G',None,'IFN-γ+ CD8 (MLN), d60\nrgH5N1 restim',False,['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
        ('S05-I',None,'Lung TRM CD8 d25\n(% CD69+CD103+)',False,['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
        ('S02-D_CD40',None,'CD40+ of MLN CD11b+ DC\nd3',False,['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']),
        ('S04-B_Foxp3',None,'Tfr (Foxp3+ of CXCR5+ICOShi)\nd7',False,['Sham','PSLN-212','PSLN-344','PSLN-212(Y)'])]
fig,axs=plt.subplots(2,4,figsize=(10,5.6))
rng=np.random.default_rng(1)
for ax,(b,l,title,logy,groups) in zip(axs.flat,panels):
    d=V[V.block==b].copy()
    if b=='S03-C': d.loc[d.value==0,'value']=5
    for i,g in enumerate(groups):
        x=d[d.group_norm==g].value.values
        if len(x)==0: continue
        ax.scatter(i+rng.uniform(-0.12,0.12,len(x)),x,s=12,color=COL.get(g,'k'),zorder=3)
        c=10**np.log10(x).mean() if logy else x.mean()
        ax.hlines(c,i-0.25,i+0.25,color='k',lw=1.2)
    ax.set_xticks(range(len(groups))); ax.set_xticklabels([g.replace('PSLN-','').replace('(Y)',' Y') for g in groups],rotation=45,ha='right',fontsize=7)
    if logy: ax.set_yscale('log')
    ax.set_title(f'{title}  [{b}]',fontsize=7.5)
fig.suptitle('Fig. 3  Per-animal values (bar = geometric mean for titres/mRNA, arithmetic mean for %). Aged unless "Y" (young).',fontsize=8.5,x=0.01,ha='left')
plt.tight_layout(rect=(0,0,1,0.95)); plt.savefig('/tmp/outputs/figures/fig3_key_readouts.png',dpi=200); plt.close()
# ---------------- Fig 4: integrity exhibits ----------------
fig,axs=plt.subplots(1,3,figsize=(11,3.6))
ax=axs[0]
def km(d):
    t=np.sort(d.time.unique()); s=1.0; xs=[0]; ys=[1]
    n=len(d)
    for tt in t:
        ev=d[(d.time==tt)&(d.event==1)].shape[0]; atrisk=d[d.time>=tt].shape[0]
        if ev: s*=1-ev/atrisk; xs+= [tt,tt]; ys+=[ys[-1],s]
    xs.append(14); ys.append(s); return xs,ys
for blk,ls in [('S06-C','-'),('S06-D',':')]:
    for g in ['Sham','PSLN-212','PSLN-344']:
        d=S[(S.block==blk)&(S.group_norm==g)]; xs,ys=km(d)
        ax.plot(xs,np.array(ys)*100+(0 if blk=='S06-C' else 1.5),ls=ls,color=COL[g],lw=1.6 if blk=='S06-C' else 1.2,label=f'{blk} {g}')
ax.set_title('(a) S06-C (d14 challenge) and S06-D (d3 challenge):\nevery animal identical (S06-D offset +1.5% for visibility)',fontsize=7.5)
ax.set_xlabel('Days post-challenge'); ax.set_ylabel('% survival'); ax.legend(fontsize=5.5,frameon=False)
ax=axs[1]
for blk,ls,col in [('S15-C','-','#d62728'),('S15-I','--','k')]:
    grp='PSLN-344' if blk=='S15-C' else '3d Vaccine+PSLN-344'
    d=V[(V.block==blk)&(V.group_norm==grp)].copy(); d['day']=d.level.astype(float)
    for r,dd in d.groupby('rep'):
        dd=dd.sort_values('day'); ax.plot(dd.day,dd.value,ls=ls,color=col,lw=1 if blk=='S15-C' else 0.8,alpha=0.8)
ax.plot([],[],color='#d62728',label='S15-C PSLN-344 (bivalent, rgH5N1 at d14)'); ax.plot([],[],'k--',label='S15-I Vaccine+PSLN-344 (VN04 at d3)')
ax.legend(fontsize=5.5,frameon=False,loc='lower left'); ax.set_xlabel('Day post-challenge'); ax.set_ylabel('% of day-0 weight')
ax.set_title('(b) Two different experiments: 40 of 42 animal-day\nweights identical d2–d12; all 7 differ only at d14',fontsize=7.5)
ax=axs[2]
a=V[V.block=='S11-A'].copy(); b=V[V.block=='S11-B'].copy()
m=a.merge(b,on=['group_norm','level','rep'],suffixes=('_AM','_neut'))
same=m.value_AM==m.value_neut
ax.scatter(m.value_AM[~same],m.value_neut[~same],s=10,color='#1f77b4',label=f'different ({(~same).sum()})')
ax.scatter(m.value_AM[same],m.value_neut[same],s=14,color='#d62728',label=f'identical ({same.sum()} of {len(m)})')
ax.plot([15,55],[15,55],'k:',lw=0.7); ax.set_xlabel('S11-A alveolar macrophages (%)'); ax.set_ylabel('S11-B neutrophils (%)')
ax.legend(fontsize=6,frameon=False); ax.set_title('(c) Two different cell types, same animal/day cell:\n35 of 100 values identical',fontsize=7.5)
fig.suptitle('Fig. 4  Data-integrity exhibits (full list in the integrity register)',fontsize=8.5,x=0.01,ha='left')
plt.tight_layout(rect=(0,0,1,0.93)); plt.savefig('/tmp/outputs/figures/fig4_integrity_exhibits.png',dpi=200); plt.close()

fig,ax=plt.subplots(figsize=(10,4.2))
rows=[('G0  Data reconstruction & QA audit (primary records, re-analysis)',0,2,'#7f7f7f'),
      ('S1  Confirmatory aged efficacy vs benchmarks (blinded, both sexes, 2 strains)',2,10,'#d62728'),
      ('S2  Mechanism: CD8/CD4 depletion, serum transfer, IFNAR/STING, biomarker linkage',3,10,'#ff7f0e'),
      ('S3a Mn²⁺ biodistribution & neuro pilot (ICP-MS, MRI, histopath, olfaction)',2,8,'#9467bd'),
      ('S4  CMC: Mn content/dose, EE spec, stability, potency assay, clinical antigen',0,12,'#8c564b'),
      ('S5  Aged NHP bridge: nasal/blood ISG PD marker, HAI/MN, nasal IgA, BAL T cells',11,19,'#1f77b4'),
      ('S3b GLP tox: repeat-dose IN, 2 species, neuro/olfactory/facial nerve endpoints',11,20,'#9467bd'),
      ('IND/CTA assembly',20,23,'#17becf'),
      ('P1  FIH: 18–49 sentinel → ≥65 (65–74, ≥75); vs sham-IN and licensed IM benchmark',23,36,'#2ca02c')]
for i,(lab_,a,b,c) in enumerate(rows[::-1]):
    ax.barh(i,b-a,left=a,color=c,alpha=0.85,height=0.6); ax.text(-0.3,i,lab_,ha='right',va='center',fontsize=7)
for x,t in [(2,'Gate 0\nverify or stop'),(10,'Gate 1\nefficacy + mechanism\n+ Mn signal'),(20,'Gate 2\nNOAEL/margin,\nNHP PD'),(36,'Gate 3\nPh1 safety/PD')]:
    ax.axvline(x,color='k',ls='--',lw=0.8); ax.text(x,len(rows)-0.2,t,ha='center',va='bottom',fontsize=6.5,bbox=dict(facecolor='white',edgecolor='none',pad=1.5))
ax.set_yticks([]); ax.set_xlim(0,38.5); ax.set_xlabel('Months from committee decision'); ax.set_ylim(-0.6,len(rows)+1.2)
ax.set_title('Fig. 5  Gated forward plan (indicative timing; kill criteria at each gate are in Section 7)',fontsize=8.5,loc='left')
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig5_forward_plan_timeline.png',dpi=200,bbox_inches='tight'); plt.close()
print('figures done')

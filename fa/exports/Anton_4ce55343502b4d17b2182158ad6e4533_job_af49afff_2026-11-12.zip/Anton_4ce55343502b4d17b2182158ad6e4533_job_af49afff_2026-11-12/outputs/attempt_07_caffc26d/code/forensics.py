import pandas as pd, numpy as np, itertools, collections
V=pd.read_csv('/tmp/work/values_long.csv')
S=pd.read_csv('/tmp/work/survival_long.csv')
out=[]
# ---- 1. identical high-precision values (>=5 significant decimals) appearing in >1 cell
def ndec(x):
    s=repr(float(x))
    return len(s.split('.')[1]) if '.' in s else 0
V['ndec']=V.value.map(ndec)
hp=V[(V.ndec>=4)&(V.value!=100)]
dup=hp.groupby('value').filter(lambda d: len(d)>1).sort_values('value')
print('=== identical values with >=4 decimals in >1 cell ===')
for val,d in dup.groupby('value'):
    print(val, '|', '; '.join(f"{r.block}:{r.group_norm}@{r.cell}(lvl={r.level})" for r in d.itertuples()))
# ---- 2. shared fractional parts (>=6 decimals) with different integer parts
print('\n=== shared fractional part (>=6 decimals), different integer part ===')
hp6=V[V.ndec>=6].copy(); hp6['frac']=(hp6.value%1).round(6)
for fr,d in hp6.groupby('frac'):
    if d.value.nunique()>1 and len(d)>1:
        print(fr,'|','; '.join(f"{r.block}:{r.group_norm}@{r.cell}={r.value}" for r in d.itertuples()))

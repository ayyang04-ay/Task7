import pandas as pd, openpyxl, re
V=pd.read_csv('/tmp/work/values_long.csv'); S=pd.read_csv('/tmp/work/survival_long.csv')
# stated n from block label cells
wb=openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx',data_only=True)
stated={}
for ws in wb.worksheets:
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value,str) and re.match(r'^S\d\d-',c.value.strip()):
                m=re.search(r'n=(\d+)',c.value)
                stated.setdefault(ws.title,[]).append((c.coordinate,c.value.strip(),m.group(1) if m else None))
for k,vv in stated.items():
    print(k, vv)
print()
# survival rows with missing time
print(S[S.time.isna()])
# per block/group/level counts
cnt=V.groupby(['block','group_norm','level'],dropna=False).size().reset_index(name='n_obs')
odd=cnt.groupby(['block','group_norm']).n_obs.agg(['min','max']).reset_index()
print(odd.to_string())

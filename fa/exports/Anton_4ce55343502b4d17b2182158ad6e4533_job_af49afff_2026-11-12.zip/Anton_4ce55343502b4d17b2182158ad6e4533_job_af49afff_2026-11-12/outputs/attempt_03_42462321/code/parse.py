"""Parse adjuvant_program_dataset.xlsx into tidy, cell-referenced tables.

Every value keeps its sheet!cell reference so every downstream number can be
traced back to the workbook. Block layouts are declared explicitly (from the
cell dump + the annotation PDF), not inferred, so nothing is silently guessed.
"""
import openpyxl, json, csv
from openpyxl.utils import column_index_from_string as ci, get_column_letter as cl

WB = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
wb = openpyxl.load_workbook(WB, data_only=True)

meas = []   # simple per-animal measurements
surv = []   # time-to-event rows
bw = []     # body-weight trajectories
issues = []  # parse-level observations


def v(ws, col, row):
    return ws[f'{col}{row}'].value


def add_meas(sheet, block, group, rows, cols, tp=None, analyte=None):
    ws = wb[sheet]
    for r in rows:
        for c in cols:
            val = v(ws, c, r)
            if val is None or val == '':
                continue
            meas.append(dict(sheet=sheet, block=block, analyte=analyte, group=group,
                             timepoint=tp, value=float(val), cell=f'{sheet}!{c}{r}'))


def cols_range(a, b):
    return [cl(i) for i in range(ci(a), ci(b) + 1)]

# ---------------- S01 ----------------
ws = wb['S01']
for r in range(3, 11):
    g = v(ws, 'A', r)
    add_meas('S01', 'S01-A', g, [r], cols_range('B', 'F'), tp='16h', analyte='Ifnb1')
    g2 = v(ws, 'G', r)
    assert g == g2, (g, g2)
    add_meas('S01', 'S01-A', g2, [r], cols_range('H', 'L'), tp='72h', analyte='Ifnb1')
for r in range(14, 18):
    add_meas('S01', 'S01-B', v(ws, 'A', r), [r], cols_range('B', 'F'))
for r in range(20, 22):
    add_meas('S01', 'S01-C', v(ws, 'A', r), [r], cols_range('B', 'E'))

def grouped_timecourse(sheet, block, header_row, rows, groups, tpcol='A', analyte=None):
    ws = wb[sheet]
    for start, g in groups:
        assert v(ws, start, header_row) == g, (block, start, v(ws, start, header_row), g)
        cols = cols_range(start, cl(ci(start) + 4))
        for r in rows:
            tp = v(ws, tpcol, r) if tpcol else None
            add_meas(sheet, block, g, [r], cols, tp=str(tp) if tp is not None else None, analyte=analyte)

grouped_timecourse('S01', 'S01-D', 23, range(24, 29), [('B', 'Sham'), ('G', 'PSLN-212'), ('L', 'PSLN-344'), ('Q', 'PSLN-212(Y)')])
G5 = [('B', 'Sham'), ('G', 'PSLN-212'), ('L', 'PSLN-344'), ('Q', 'PSLN-212(Y)'), ('V', 'PSLN-344(Y)')]
grouped_timecourse('S01', 'S01-E', 29, range(30, 35), G5)
grouped_timecourse('S01', 'S01-F', 35, [36], G5, tpcol=None)
grouped_timecourse('S01', 'S01-G', 37, [38], G5, tpcol=None)

# ---------------- generic column blocks ----------------
def col_block(sheet, block, header_row, cols, rows, tp=None, analyte=None):
    ws = wb[sheet]
    for c in cols:
        g = v(ws, c, header_row)
        add_meas(sheet, block, g, rows, [c], tp=tp, analyte=analyte)

# S02
col_block('S02', 'S02-A', 2, cols_range('A', 'D'), range(3, 8))
col_block('S02', 'S02-B', 2, cols_range('F', 'I'), range(3, 8))
col_block('S02', 'S02-C', 2, cols_range('K', 'O'), range(3, 8))
col_block('S02', 'S02-D CD40', 9, cols_range('A', 'D'), range(10, 15))
col_block('S02', 'S02-D CD86', 9, cols_range('F', 'I'), range(10, 15))
col_block('S02', 'S02-E', 9, cols_range('K', 'O'), range(10, 15))
ws = wb['S02']
for start, g in [('B', 'PSLN-344'), ('G', 'PSLN-212'), ('L', 'Sham')]:
    assert v(ws, start, 16) == g
    for r in range(17, 20):
        add_meas('S02', 'S02-F', g, [r], cols_range(start, cl(ci(start) + 4)), tp=v(ws, 'A', r), analyte='Gm-csf')
col_block('S02', 'S02-G', 21, cols_range('B', 'D'), range(22, 27))
col_block('S02', 'S02-H', 29, cols_range('B', 'F'), range(30, 35))
col_block('S02', 'S02-I', 29, cols_range('H', 'I'), range(30, 35))

# S03
col_block('S03', 'S03-A', 2, cols_range('A', 'E'), range(3, 8))
col_block('S03', 'S03-B', 2, cols_range('G', 'I'), range(3, 8))
col_block('S03', 'S03-C', 2, cols_range('K', 'O'), range(3, 8))
col_block('S03', 'S03-D', 2, cols_range('Q', 'U'), range(3, 8))
col_block('S03', 'S03-E', 9, cols_range('A', 'E'), range(10, 15))
col_block('S03', 'S03-F', 9, cols_range('G', 'I'), range(10, 15))
col_block('S03', 'S03-G', 9, cols_range('K', 'O'), range(10, 15))
col_block('S03', 'S03-H', 9, cols_range('Q', 'U'), range(10, 15))
col_block('S03', 'S03-K', 16, cols_range('L', 'O'), range(17, 22))
ws = wb['S03']
for r in range(26, 29):
    g = v(ws, 'K', r)
    add_meas('S03', 'S03-L', g, [r], cols_range('L', 'N'), analyte='Aicda')
    add_meas('S03', 'S03-L', g, [r], cols_range('O', 'Q'), analyte='E47')

# S04
ws = wb['S04']
for r in range(2, 6):
    g = v(ws, 'A', r)
    add_meas('S04', 'S04-A', g, [r], cols_range('B', 'F'), analyte='ICOS-low Tfh')
    add_meas('S04', 'S04-A', g, [r], cols_range('G', 'K'), analyte='ICOS-high Tfh')
col_block('S04', 'S04-B Foxp3', 7, cols_range('A', 'D'), range(8, 13))
col_block('S04', 'S04-B Tfh:Tfr', 14, cols_range('A', 'D'), range(15, 20))
col_block('S04', 'S04-C', 21, cols_range('A', 'D'), range(22, 27))
col_block('S04', 'S04-D', 28, cols_range('A', 'D'), range(29, 32))

# S05
ws = wb['S05']
for blk, hdr, rows in [('S05-A', 2, range(3, 6)), ('S05-B', 7, range(8, 11))]:
    for start, g in [('B', 'PSLN-212'), ('E', 'PSLN-344'), ('H', 'PSLN-212Y')]:
        assert v(ws, start, hdr) == g
        for r in rows:
            add_meas('S05', blk, g, [r], [start, cl(ci(start) + 1), cl(ci(start) + 2)], tp=str(v(ws, 'A', r)))
col_block('S05', 'S05-C', 12, cols_range('A', 'D'), range(13, 16))
for blk, hdr in [('S05-D', 18), ('S05-E', 25), ('S05-F', 32), ('S05-G', 39), ('S05-H', 46), ('S05-I', 53)]:
    col_block('S05', blk, hdr, cols_range('A', 'D'), range(hdr + 1, hdr + 6))

# S07
ws = wb['S07']
for start, g in [('B', 'PSLN-212'), ('E', 'PSLN-344')]:
    for r in range(3, 8):
        add_meas('S07', 'S07-A', g, [r], cols_range(start, cl(ci(start) + 2)), tp=str(v(ws, 'A', r)))
col_block('S07', 'S07-B', 9, ['B', 'C'], range(10, 15), analyte='CD11b+Ly6C+ monocytes')
col_block('S07', 'S07-B', 9, ['E', 'F'], range(10, 15), analyte='Ly6C+ macrophages')
# S07-C: both columns carry the same printed label -> keep column identity
ws = wb['S07']
add_meas('S07', 'S07-C', 'colB:' + v(ws, 'B', 15), range(16, 21), ['B'])
add_meas('S07', 'S07-C', 'colC:' + v(ws, 'C', 15), range(16, 21), ['C'])

# S08
ws = wb['S08']
for start, g in [('B', 'CMP-204'), ('E', 'PSLN-212'), ('H', 'PSLN-344'), ('K', 'PSLN-344/R848')]:
    assert v(ws, start, 2) == g
    for r in range(3, 8):
        add_meas('S08', 'S08-A', g, [r], cols_range(start, cl(ci(start) + 2)), tp=str(v(ws, 'A', r)), analyte='Ifnb1')
for start, g in [('A', 'CMP-204'), ('D', 'PSLN-212'), ('G', 'PSLN-R848'), ('J', 'PSLN-212/R848'), ('M', 'PSLN-344')]:
    assert v(ws, start, 10) == g
    add_meas('S08', 'S08-B', g, [11], cols_range(start, cl(ci(start) + 2)))
col_block('S08', 'S08-C', 13, cols_range('A', 'D'), range(14, 19))

# S09-A (two panels, identical printed labels)
ws = wb['S09']
p1 = [('B', 'PBS'), ('E', 'CMP-204'), ('H', 'PSLN-212'), ('K', 'PSLN-R848'), ('N', 'PSLN-212/R848'), ('Q', 'PSLN-344'), ('T', 'PSLN-212(y)')]
p2 = [('Y', 'PBS'), ('AB', 'CMP-204'), ('AE', 'PSLN-212'), ('AH', 'PSLN-R848'), ('AK', 'PSLN-212/R848'), ('AN', 'PSLN-344'), ('AQ', 'PSLN-212(y)')]
for panel, groups, acol in [('panel1 (B:V)', p1, 'A'), ('panel2 (Y:AS)', p2, 'X')]:
    for start, g in groups:
        assert v(ws, start, 2) == g, (start, v(ws, start, 2))
        for r in range(3, 10):
            add_meas('S09', 'S09-A ' + panel, g, [r], cols_range(start, cl(ci(start) + 2)), tp='16h (as printed)', analyte=v(ws, acol, r))

# S10
ws = wb['S10']
for a, cols in [('Ifnb1', cols_range('A', 'D')), ('Tnf', cols_range('F', 'I')), ('Isg15', cols_range('K', 'N'))]:
    for c in cols:
        add_meas('S10', 'S10-A', v(ws, c, 2), range(3, 8), [c], tp='36h', analyte=a)

# S11
G4v = [('B', 'Vaccine'), ('G', 'PSLN-212'), ('L', 'PSLN-344'), ('Q', 'PSLN-212(Y)')]
grouped_timecourse('S11', 'S11-A', 2, range(3, 8), G4v)
grouped_timecourse('S11', 'S11-B', 9, range(10, 15), G4v)
col_block('S11', 'S11-C', 16, ['A', 'B'], range(17, 22))
grouped_timecourse('S11', 'S11-D', 23, range(24, 29), G4v)
col_block('S11', 'S11-E', 30, cols_range('A', 'D'), range(31, 36))

# S12
col_block('S12', 'S12-A', 2, ['A', 'B'], range(3, 6))

# S13 serology
col_block('S13', 'S13-A', 2, cols_range('A', 'C'), range(3, 8))
col_block('S13', 'S13-B', 2, cols_range('E', 'G'), range(3, 8))
col_block('S13', 'S13-C', 2, cols_range('I', 'K'), range(3, 8))
col_block('S13', 'S13-D', 2, cols_range('M', 'O'), range(3, 8))
col_block('S13', 'S13-H', 52, cols_range('A', 'D'), range(53, 58))
col_block('S13', 'S13-I', 52, cols_range('F', 'J'), range(53, 58))
col_block('S13', 'S13-J', 52, cols_range('L', 'P'), range(53, 58))

# S14
col_block('S14', 'S14-A H1N1', 2, cols_range('A', 'D'), range(3, 8))
col_block('S14', 'S14-A H3N2', 2, cols_range('F', 'I'), range(3, 8))

# ---------------- survival ----------------
def surv_block(sheet, block, header_row, daycol, groupcols, rows):
    ws = wb[sheet]
    gnames = {c: v(ws, c, header_row) for c in groupcols}
    for r in rows:
        d = v(ws, daycol, r)
        hits = [(c, v(ws, c, r)) for c in groupcols if v(ws, c, r) is not None]
        if d is None and not hits:
            continue
        if len(hits) != 1:
            issues.append(f'{block}: row {r} has {len(hits)} group entries, day={d}')
            continue
        c, e = hits[0]
        surv.append(dict(sheet=sheet, block=block, group=gnames[c], time=(float(d) if d is not None else None),
                         event=int(e), cell_time=f'{sheet}!{daycol}{r}', cell_event=f'{sheet}!{c}{r}'))

surv_block('S03', 'S03-I', 16, 'A', cols_range('B', 'F'), range(17, 52))
surv_block('S03', 'S03-J', 16, 'G', cols_range('H', 'J'), range(17, 47))
surv_block('S06', 'S06-A', 2, 'A', cols_range('B', 'E'), range(3, 31))
surv_block('S06', 'S06-B', 2, 'G', cols_range('H', 'K'), range(3, 31))
surv_block('S06', 'S06-C', 2, 'M', cols_range('N', 'Q'), range(3, 31))
surv_block('S06', 'S06-D', 33, 'A', cols_range('B', 'E'), range(34, 69))
surv_block('S06', 'S06-E(d60)', 33, 'G', cols_range('H', 'L'), range(34, 69))
surv_block('S06', 'S06-F(d60)', 33, 'M', cols_range('N', 'R'), range(34, 69))
surv_block('S06', 'S06-G', 70, 'A', cols_range('B', 'F'), range(71, 106))
surv_block('S06', 'S06-E(imprint)', 70, 'G', cols_range('H', 'K'), range(71, 106))
surv_block('S06', 'S06-F(imprint)', 70, 'M', cols_range('N', 'Q'), range(71, 106))
surv_block('S09', 'S09-B', 11, 'A', cols_range('B', 'D'), range(12, 36))
surv_block('S09', 'S09-D', 38, 'A', cols_range('B', 'D'), range(39, 63))
surv_block('S09', 'S09-F', 65, 'A', cols_range('B', 'D'), range(66, 89))
surv_block('S13', 'S13-E', 2, 'R', cols_range('S', 'V'), range(3, 31))
surv_block('S15', 'S15-H', 72, 'A', cols_range('B', 'D'), range(73, 94))
surv_block('S15', 'S15-L', 102, 'A', cols_range('B', 'E'), range(103, 131))
surv_block('S15', 'S15-N', 133, 'A', cols_range('B', 'E'), range(134, 162))
# S08 orphan region (no labels): keep column identity
ws = wb['S08']
for r in range(89, 102):
    for c in ['C', 'D']:
        if v(ws, c, r) is not None:
            surv.append(dict(sheet='S08', block='S08-orphan', group=f'unlabelled col {c}', time=float(v(ws, 'A', r)),
                             event=int(v(ws, c, r)), cell_time=f'S08!A{r}', cell_event=f'S08!{c}{r}'))

# ---------------- body weight ----------------
def bw_block(sheet, block, header_row, daycol, groups, rows, width):
    ws = wb[sheet]
    for start, g in groups:
        hv = v(ws, start, header_row)
        assert hv is not None and hv.strip().replace('ï', 'i') .lower().replace('naïve', 'naive') is not None
        if hv.strip() != g:
            issues.append(f'{block}: header at {start}{header_row} is {hv!r}, expected {g!r}')
        for k in range(width):
            c = cl(ci(start) + k)
            for r in rows:
                val = v(ws, c, r)
                if val is None:
                    continue
                bw.append(dict(sheet=sheet, block=block, group=g, animal=f'{g}#{k+1}', col=c,
                               day=float(v(ws, daycol, r)), value=float(val), cell=f'{sheet}!{c}{r}'))

S15G4 = [('B', 'PSLN-212(Y)'), ('I', 'Sham'), ('P', 'PSLN-212'), ('W', 'PSLN-344')]
S15G5 = S15G4 + [('AD', 'Untreated')]
bw_block('S08', 'S08-D', 20, 'A', [('B', 'PSLN-212(Y)'), ('G', 'CMP-204'), ('L', 'PSLN-212'), ('Q', 'PSLN-344'), ('V', 'PSLN-212/R848'), ('AA', 'Vaccine')], range(21, 27), 5)
bw_block('S09', 'S09-C', 11, 'F', [('G', 'PSLN-212Y'), ('O', 'Sham'), ('W', 'PSLN-344Y')], range(12, 20), 8)
bw_block('S09', 'S09-E', 38, 'F', [('G', 'PSLN-212Y'), ('O', 'Sham'), ('W', 'PSLN-344Y')], range(39, 47), 8)
bw_block('S09', 'S09-G', 65, 'F', [('G', 'PSLN-212Y'), ('O', 'Sham'), ('W', 'PSLN-344Y')], range(66, 74), 8)
bw_block('S13', 'S13-F', 32, 'A', [('B', 'PSLN-212(Y)'), ('I', 'Sham'), ('P', 'PSLN-212'), ('W', 'PSLN-344'), ('AD', 'Naïve')], range(33, 41), 7)
bw_block('S13', 'S13-G', 42, 'A', [('B', 'PSLN-344'), ('L', 'Sham'), ('V', 'Naïve')], range(43, 51), 10)
bw_block('S15', 'S15-A', 2, 'A', S15G4, range(3, 11), 7)
bw_block('S15', 'S15-B', 12, 'A', S15G4, range(13, 21), 7)
bw_block('S15', 'S15-C', 22, 'A', S15G4, range(23, 31), 7)
bw_block('S15', 'S15-D', 32, 'A', S15G4, range(33, 41), 7)
bw_block('S15', 'S15-E', 42, 'A', S15G5, range(43, 51), 7)
bw_block('S15', 'S15-F', 52, 'A', S15G5, range(53, 61), 7)
bw_block('S15', 'S15-G', 62, 'A', S15G5, range(63, 71), 7)
bw_block('S15', 'S15-I', 71, 'H', [('I', '3d Vaccine'), ('P', '3d PSLN-344'), ('W', '3d Vaccine+PSLN-344')], range(72, 80), 7)
IMP = [('I', 'Naïve+PSLN-212'), ('P', 'Imprinting+PSLN-212'), ('W', 'Naïve+PSLN-344'), ('AD', 'Imprinting+PSLN-344')]
bw_block('S15', 'S15-J', 82, 'H', IMP, range(83, 91), 7)
bw_block('S15', 'S15-K', 92, 'H', IMP, range(93, 101), 7)
S15MO = [('I', 'PSLN-212(Y)'), ('P', 'Sham'), ('W', 'PSLN-212'), ('AD', 'PSLN-344')]
bw_block('S15', 'S15-M', 102, 'H', S15MO, range(103, 111), 7)
bw_block('S15', 'S15-O', 133, 'H', S15MO, range(134, 142), 7)

# ---------------- write ----------------
import pandas as pd
pd.DataFrame(meas).to_csv('/tmp/work/measurements.csv', index=False)
pd.DataFrame(surv).to_csv('/tmp/work/survival.csv', index=False)
pd.DataFrame(bw).to_csv('/tmp/work/bodyweight.csv', index=False)
with open('/tmp/work/parse_issues.txt', 'w') as f:
    f.write('\n'.join(issues))
print(len(meas), 'measurements;', len(surv), 'survival rows;', len(bw), 'body-weight values')
print('\n'.join(issues))

# completeness check: every numeric cell in the workbook must be captured somewhere
captured = set(m['cell'] for m in meas) | set(s['cell_event'] for s in surv) | set(s['cell_time'] for s in surv) | set(b['cell'] for b in bw)
missing = []
for wsn in wb.sheetnames:
    ws = wb[wsn]
    for row in ws.iter_rows():
        for c in row:
            if isinstance(c.value, (int, float)) and f'{wsn}!{c.coordinate}' not in captured:
                missing.append(f'{wsn}!{c.coordinate}={c.value}')
print('numeric cells not captured:', len(missing))
print(missing[:400])

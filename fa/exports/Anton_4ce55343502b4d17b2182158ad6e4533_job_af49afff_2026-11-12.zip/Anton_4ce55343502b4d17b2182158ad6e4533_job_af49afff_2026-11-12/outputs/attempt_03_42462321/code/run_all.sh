#!/usr/bin/env bash
# Full pipeline: raw workbook -> tidy tables -> statistics -> integrity screens -> figures -> register -> memo/workbook -> verification.
# Paths are absolute (/tmp/world/filesystem input, /tmp/work intermediates, /tmp/outputs deliverables). Uses conda envs via `micromamba run -n`.
set -euo pipefail
cd /tmp/work
mm() { micromamba run -n "$@"; }
mm singlecell python parse.py            # 1. parse every block with cell references
mm core python blockstats.py             # 2. per-group summaries and pairwise contrasts (Welch, Mann-Whitney, Tukey)
mm core python surv_meta.py              # 3. per-experiment survival contrasts
mm core python mh_sato.py                # 4. pooled Mantel-Haenszel risk differences (Sato variance)
Rscript strat_out.R                      # 5. stratified log-rank and exact CMH
mm core python restoration.py            # 6. aged groups as % of young
mm core python bw_vs_surv.py             # 7. survival vs body-weight concordance
mm core python timing.py                 # 8. death timing vs weights (screen)
mm core python traj_dups.py              # 9. duplicated weight trajectories
mm core python recycled_decimals.py      # 10. recycled high-precision weight decimals
mm core python integrity.py > integrity_screen.txt   # 11. cross-block shared-value screen (printout)
mm core python audit_tables.py           # 12. per-animal audit tables
mm core python power.py > power.txt      # 13. design calculations
for f in fig_survival.py fig_restoration.py fig_integrity.py fig_mech.py fig_schematic.py; do mm core python "$f"; done   # 14. figures
rm -rf __pycache__; mm core python compose.py   # 15. register + memo (markdown)
python3 -c "c=open('compose.py').read(); a=c.index('USAGE = ['); b=c.index(']\nfor a, b, c, d in USAGE:'); open('usage_table.py','w').write(c[a:b+1]+'\n')"
mm singlecell python build_workbook.py   # 16. evidence workbook
mm singlecell python verify_register.py  # 17. independent re-derivation of cited values from raw cells
mm singlecell python verify_survival.py
cd /tmp/outputs && mm genomics pandoc PSLN-344_portfolio_recommendation.md -o PSLN-344_portfolio_recommendation.docx \
   --resource-path=/tmp/outputs --reference-doc=/tmp/work/refdoc/reference_custom.docx --toc --toc-depth=2   # 18. DOCX
echo "pipeline complete"

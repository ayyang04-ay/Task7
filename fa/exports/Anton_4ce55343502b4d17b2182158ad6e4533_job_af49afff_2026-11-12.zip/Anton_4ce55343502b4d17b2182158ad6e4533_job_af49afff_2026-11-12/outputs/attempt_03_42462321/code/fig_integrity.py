import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
m = pd.read_csv('measurements.csv'); m['timepoint']=m.timepoint.fillna('')
s = pd.read_csv('survival.csv'); w = pd.read_csv('bodyweight.csv')
fig, axs = plt.subplots(2, 2, figsize=(13, 10.5))
# (a) S11-A vs S11-B
ax = axs[0,0]
A = m[m.block=='S11-A'].reset_index(drop=True); B = m[m.block=='S11-B'].reset_index(drop=True)
same = np.isclose(A.value.values, B.value.values)
ax.scatter(A.value[~same], B.value[~same], s=18, color='#90a4ae', label=f'different ({(~same).sum()})')
ax.scatter(A.value[same], B.value[same], s=26, color='#c62828', label=f'identical to 0.1 ({same.sum()} of {len(same)})')
ax.plot([10,60],[10,60],'k--',lw=0.8); ax.set_xlabel('S11-A "alveolar macrophages" (%)'); ax.set_ylabel('S11-B "neutrophils" (%) - same group/day/position')
ax.set_title('a. S11-A vs S11-B: 35/100 paired values identical\n(chance rate from non-matching positions: 1.5/100; S11-A vs S11-D: 0/100)', fontsize=10); ax.legend(fontsize=8)
# (b) S03-B / S03-F printed vs recomputed
ax = axs[0,1]
groups = ['PSLN-212','PSLN-344','PSLN-212(Y)']
def gmv(b,g): x = m[(m.block==b)&(m.group==g)].value.values; return np.exp(np.log(x).mean())
def ratio(b2a,b1,g): a = m[(m.block==b2a)&(m.group==g)].value.values; c = m[(m.block==b1)&(m.group==g)].value.values; return np.exp(np.log(a/c).mean())
x = np.arange(3); wdt=0.2
pr1 = [gmv('S03-B',g) for g in groups]; rc1 = [ratio('S13-A','S13-B',g) for g in groups]
pr2 = [gmv('S03-F',g) for g in groups]; rc2 = [ratio('S13-C','S13-D',g) for g in groups]
ax.bar(x-1.5*wdt, pr1, wdt, color='#ffab91', label='H1N1 quotient as printed (S03-B)'); ax.bar(x-0.5*wdt, rc1, wdt, color='#1565c0', label='H1N1 recomputed from S13-A/S13-B')
ax.bar(x+0.5*wdt, pr2, wdt, color='#ffccbc', label='H3N2 quotient as printed (S03-F)'); ax.bar(x+1.5*wdt, rc2, wdt, color='#64b5f6', label='H3N2 recomputed from S13-C/S13-D')
ax.set_xticks(x); ax.set_xticklabels(groups); ax.set_ylabel('IgG2a / IgG1 (geometric mean)'); ax.axhline(1, color='k', lw=0.6)
ax.set_title('b. S03-B/F labels are rotated: printed "PSLN-344" = PSLN-212 data\n(match to raw titres within 6.5e-4 relative error)', fontsize=10); ax.legend(fontsize=7.5)
# (c) S15-C PSLN-344 vs S15-I Vaccine+PSLN-344 trajectories
ax = axs[1,0]
def traj(b,g):
    d = w[(w.block==b)&(w.group==g)]
    return {c: dd.sort_values('day') for c, dd in d.groupby('col')}
t1 = traj('S15-C','PSLN-344'); t2 = traj('S15-I','3d Vaccine+PSLN-344')
for c in t1:
    ax.plot(t1[c].day, t1[c].value, '-', color='#1565c0', lw=2.5, alpha=0.6)
    ax.plot(t2[c].day, t2[c].value, '--', color='#c62828', lw=1.2)
ax.plot([],[],'-',color='#1565c0',lw=2.5,alpha=0.6,label='S15-C PSLN-344, vaccinated 14 d before rgH5N1 challenge'); ax.plot([],[],'--',color='#c62828',label='S15-I Vaccine+PSLN-344, vaccinated 3 d before rgH5N1 challenge')
ax.set_xlabel('Day after challenge'); ax.set_ylabel('Body weight (% of day 0)'); ax.legend(fontsize=8)
ax.set_title('c. Two different experiments share 40/49 post-baseline weights\n(days 2-12 identical; only day 14 differs)', fontsize=10)
# (d) S06-C vs S06-D
ax = axs[1,1]
cols = {'Sham':'#757575','PSLN-212':'#ef6c00','PSLN-344':'#1565c0','PSLN-212(Y)':'#2e7d32'}
for blk, ls, lw in [('S06-C','-',4),('S06-D','--',1.5)]:
    for g, col in cols.items():
        d = s[(s.block==blk)&(s.group==g)]
        times = np.arange(0,15); surv = [(d[(d.event==1)].time > t).sum() + (d.event==0).sum() for t in times]
        ax.step(times, np.array(surv)/len(d)*100 + (0.8 if g=='PSLN-212(Y)' else 0), where='post', color=col, ls=ls, lw=lw, alpha=0.55 if blk=='S06-C' else 1)
for g, col in cols.items(): ax.plot([],[],color=col,label=g)
ax.plot([],[],'k-',lw=4,alpha=0.5,label='S06-C (challenge d14)'); ax.plot([],[],'k--',lw=1.5,label='S06-D (challenge d3)')
ax.set_xlabel('Day after challenge'); ax.set_ylabel('Survival (%)'); ax.legend(fontsize=7.5, loc='center left')
ax.set_title('d. S06-D (challenge day 3) is a row-for-row copy of S06-C (day 14)\n28/28 animals identical; S15-D weights imply 2 PSLN-344 deaths', fontsize=10)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig3_integrity_evidence.png', dpi=150); print('ok')

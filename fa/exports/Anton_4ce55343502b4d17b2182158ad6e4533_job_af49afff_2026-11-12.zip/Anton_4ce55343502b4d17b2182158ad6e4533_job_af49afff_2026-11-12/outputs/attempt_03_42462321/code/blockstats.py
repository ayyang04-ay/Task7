import pandas as pd, numpy as np, itertools, warnings
from scipy import stats
from statsmodels.stats.multicomp import pairwise_tukeyhsd
warnings.filterwarnings('ignore')
m = pd.read_csv('measurements.csv')
m['analyte'] = m.analyte.fillna(''); m['timepoint'] = m.timepoint.fillna('').astype(str)
LOG_BLOCKS = {'S01-A','S02-F','S03-L','S08-A','S10-A','S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J',
              'S03-B','S03-F','S04-B Tfh:Tfr','S07-A'}
HAI = {'S03-C','S03-G'}
def scale(b): return 'log' if b in LOG_BLOCKS else ('log10-as-stored' if b.startswith('S09-A') else 'linear')
def prep(b, x):
    x = np.asarray(x, float)
    if b in HAI: x = np.where(x < 10, 5.0, x)   # below 1:10 LOD -> 5 (half LOD)
    return x
rows = []; cons = []
for (b, a, t), d in m.groupby(['block','analyte','timepoint'], sort=False):
    sc = scale(b)
    groups = list(dict.fromkeys(d.group))
    G = {g: prep(b, d[d.group==g].value.values) for g in groups}
    C = {g: ';'.join(d[d.group==g].cell.values) for g in groups}
    for g in groups:
        x = G[g]; n = len(x)
        r = dict(block=b, analyte=a, timepoint=t, group=g, n=n, scale=sc, mean=x.mean(), sd=x.std(ddof=1) if n>1 else np.nan,
                 median=np.median(x), min=x.min(), max=x.max(), cells=C[g])
        if sc == 'log':
            lx = np.log10(x); gm = 10**lx.mean()
            if n > 1:
                h = stats.t.ppf(0.975, n-1)*lx.std(ddof=1)/np.sqrt(n)
                r.update(GM=gm, GM_lo=10**(lx.mean()-h), GM_hi=10**(lx.mean()+h))
            else: r.update(GM=gm)
        elif n > 1:
            h = stats.t.ppf(0.975, n-1)*x.std(ddof=1)/np.sqrt(n); r.update(CI_lo=x.mean()-h, CI_hi=x.mean()+h)
        rows.append(r)
    # Tukey within block (stated method), on log10 for log blocks
    if len(groups) >= 3 and all(len(G[g])>1 for g in groups):
        arrs = [np.log10(G[g]) if sc=='log' else G[g] for g in groups]
        tk = stats.tukey_hsd(*arrs)
        tkd = pd.DataFrame([dict(group1=groups[i], group2=groups[j], **{'p-adj': tk.pvalue[i, j]}) for i in range(len(groups)) for j in range(len(groups)) if i < j])
    else: tkd = None
    for g1, g0 in itertools.permutations(groups, 2):
        x1, x0 = G[g1], G[g0]
        if len(x1)<2 or len(x0)<2: continue
        if sc == 'log':
            l1, l0 = np.log10(x1), np.log10(x0)
            tt = stats.ttest_ind(l1, l0, equal_var=False)
            diff = l1.mean()-l0.mean()
            se = np.sqrt(l1.var(ddof=1)/len(l1) + l0.var(ddof=1)/len(l0))
            dfw = se**4/((l1.var(ddof=1)/len(l1))**2/(len(l1)-1) + (l0.var(ddof=1)/len(l0))**2/(len(l0)-1)) if se>0 else np.nan
            h = stats.t.ppf(0.975, dfw)*se if se>0 else 0
            eff, lo, hi, efftype = 10**diff, 10**(diff-h), 10**(diff+h), 'ratio of geometric means'
        else:
            tt = stats.ttest_ind(x1, x0, equal_var=False)
            diff = x1.mean()-x0.mean()
            se = np.sqrt(x1.var(ddof=1)/len(x1) + x0.var(ddof=1)/len(x0))
            dfw = se**4/((x1.var(ddof=1)/len(x1))**2/(len(x1)-1) + (x0.var(ddof=1)/len(x0))**2/(len(x0)-1)) if se>0 else np.nan
            h = stats.t.ppf(0.975, dfw)*se if se>0 else 0
            eff, lo, hi, efftype = diff, diff-h, diff+h, 'difference in means' if sc=='linear' else 'difference in log10 means'
            if sc != 'linear': eff, lo, hi, efftype = 10**diff, 10**(diff-h), 10**(diff+h), 'fold (from stored log10)'
        mw = stats.mannwhitneyu(x1, x0, alternative='two-sided', method='exact')
        tp = np.nan
        if tkd is not None:
            q = tkd[((tkd.group1==g1)&(tkd.group2==g0))|((tkd.group1==g0)&(tkd.group2==g1))]
            if len(q): tp = float(q['p-adj'].values[0])
        overlap = not (x1.min() > x0.max() or x1.max() < x0.min())
        cons.append(dict(block=b, analyte=a, timepoint=t, g1=g1, g0=g0, scale=sc, effect=eff, lo=lo, hi=hi, effect_type=efftype,
                         welch_p=tt.pvalue, mw_exact_p=mw.pvalue, tukey_p_adj=tp, ranges_overlap=overlap, n1=len(x1), n0=len(x0)))
S = pd.DataFrame(rows); K = pd.DataFrame(cons)
S.to_csv('block_summary.csv', index=False); K.to_csv('block_contrasts.csv', index=False)
print(len(S), 'group summaries;', len(K), 'pairwise contrasts')

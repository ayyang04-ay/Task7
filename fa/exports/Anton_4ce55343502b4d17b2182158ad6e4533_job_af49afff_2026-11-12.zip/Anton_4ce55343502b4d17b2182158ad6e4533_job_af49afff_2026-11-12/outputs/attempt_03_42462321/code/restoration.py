import pandas as pd, numpy as np
from scipy import stats
m = pd.read_csv('measurements.csv'); m['analyte']=m.analyte.fillna(''); m['timepoint']=m.timepoint.fillna('').astype(str)
HAI = {'S03-C','S03-G'}
LOG = {'S01-A','S03-A','S03-C','S03-D','S03-E','S03-G','S03-H','S13-A','S13-B','S13-C','S13-D','S13-I','S13-J'}
items = [  # (category, label, block, analyte, timepoint, direction)  direction +1: higher=better(young-like high); -1: young lower
 ('Innate / afferent','Lung Ifnb1, 16 h','S01-A','Ifnb1','16h',+1),
 ('Innate / afferent','Lung monocytes, day 4','S01-D','','4',+1),
 ('Innate / afferent','Lung CD11b+ DC, day 4','S01-E','','4',+1),
 ('Innate / afferent','Lung cDC1, 72 h','S01-F','','',+1),
 ('Innate / afferent','Lung CCR7+ migratory DC, 72 h','S02-A','','',+1),
 ('Innate / afferent','MLN CD11b+CD103- DC, 72 h','S02-B','','',+1),
 ('Innate / afferent','MLN antigen+ DC, 36 h','S02-C','','',+1),
 ('DC quality','MLN DC CD40+, day 3','S02-D CD40','','',+1),
 ('DC quality','MLN DC CD86+, day 3','S02-D CD86','','',+1),
 ('DC quality','MLN DC -> OT-I priming','S02-E','','',+1),
 ('Humoral','Serum IgG H1N1, d14','S03-A','','',+1),
 ('Humoral','HAI H1N1, d14','S03-C','','',+1),
 ('Humoral','Neutralisation H1N1, d14','S03-D','','',+1),
 ('Humoral','Serum IgG H3N2, d14','S03-E','','',+1),
 ('Humoral','HAI H3N2, d14','S03-G','','',+1),
 ('Humoral','Neutralisation H3N2, d14','S03-H','','',+1),
 ('Humoral','IgG2a H1N1, d14','S13-A','','',+1),
 ('Humoral','IgG1 H1N1, d14','S13-B','','',+1),
 ('Humoral','IgG H1N1 d28 (post-boost)','S13-I','','',+1),
 ('Humoral','IgG H3N2 d28 (post-boost)','S13-J','','',+1),
 ('Germinal centre','ICOS-high Tfh, d7','S04-A','ICOS-high Tfh','',+1),
 ('Germinal centre','GC B cells, d7','S03-K','','',+1),
 ('Germinal centre','Tfr (Foxp3+), d7 [young lower]','S04-B Foxp3','','',-1),
 ('Germinal centre','Tfr (Foxp3+), d30 [young lower]','S04-C','','',-1),
 ('CD8 T cell','Lung Ki-67+ CD8, d3','S05-D','','',+1),
 ('CD8 T cell','Lung GZMB+ CD8, d3','S05-E','','',+1),
 ('CD8 T cell','MLN IFN-g+ CD8 (H5 restim), d14','S05-F','','',+1),
 ('CD8 T cell','MLN IFN-g+ CD8 (H1 restim)','S14-A H1N1','','',+1),
 ('CD8 T cell','MLN IFN-g+ CD8 (H3 restim)','S14-A H3N2','','',+1),
 ('CD8 T cell','MLN IFN-g+ CD8 (H5 restim), d60','S05-G','','',+1),
 ('CD8 T cell','MLN GZMB+ CD8, d60','S05-H','','',+1),
 ('CD8 T cell','Lung CD8 TRM, d25','S05-I','','',+1),
 ('Resolution','Lung Ifnb1, 72 h [young lower]','S01-A','Ifnb1','72h',-1),
]
YOUNG = {'S05-A':'PSLN-212Y'}
rows=[]
for cat, lab, b, a, t, dirn in items:
    d = m[(m.block==b)&(m.analyte==a)&(m.timepoint==t)]
    def vals(g):
        x = d[d.group==g].value.values.astype(float)
        if b in HAI: x = np.where(x<10, 5.0, x)
        return x, ';'.join(d[d.group==g].cell.values)
    y, yc = vals('PSLN-212(Y)')
    out = dict(category=cat, readout=lab, block=b, direction=dirn, young_cells=yc)
    for g, key in [('PSLN-344','344'),('PSLN-212','212'),('Sham','sham')]:
        x, xc = vals(g)
        if len(x)==0: continue
        if b in LOG:
            lx, ly = np.log(x), np.log(y)
            diff = lx.mean()-ly.mean(); se = np.sqrt(lx.var(ddof=1)/len(lx)+ly.var(ddof=1)/len(ly))
            p = stats.ttest_ind(lx, ly, equal_var=False).pvalue
        else:
            diff = np.log(x.mean()/y.mean()); se = np.sqrt(x.var(ddof=1)/(len(x)*x.mean()**2) + y.var(ddof=1)/(len(y)*y.mean()**2))
            p = stats.ttest_ind(x, y, equal_var=False).pvalue
        q = stats.t.ppf(0.975, len(x)+len(y)-2)
        out.update({f'ratio_{key}': np.exp(diff), f'lo_{key}': np.exp(diff-q*se), f'hi_{key}': np.exp(diff+q*se), f'p_{key}_vs_young': p, f'cells_{key}': xc})
    rows.append(out)
R = pd.DataFrame(rows); R.to_csv('restoration.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 100)
print(R[['category','readout','ratio_344','lo_344','hi_344','p_344_vs_young','ratio_212','p_212_vs_young']].round(3).to_string(index=False))

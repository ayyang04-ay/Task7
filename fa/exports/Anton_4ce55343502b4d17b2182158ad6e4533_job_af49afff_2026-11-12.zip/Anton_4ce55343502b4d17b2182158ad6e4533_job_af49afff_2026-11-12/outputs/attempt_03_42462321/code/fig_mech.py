import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
m = pd.read_csv('measurements.csv'); m['timepoint']=m.timepoint.fillna('')
fig = plt.figure(figsize=(14, 12))
axs = [fig.add_axes([0.07, 0.56, 0.42, 0.38]), fig.add_axes([0.57, 0.56, 0.41, 0.38]), fig.add_axes([0.40, 0.06, 0.58, 0.40])]
# a dose-response
ax = axs[0]; d = m[m.block=='S08-A'].copy(); d['dose']=d.timepoint.astype(float)
cols = {'CMP-204':'#8d6e63','PSLN-212':'#ef6c00','PSLN-344':'#1565c0','PSLN-344/R848':'#9e9e9e'}
def emax(D, e0, emx, ed50, h): return np.log10(e0 + emx*D**h/(ed50**h + D**h))
for g, c in cols.items():
    dd = d[d.group==g]
    ax.scatter(dd.dose*np.exp(np.random.default_rng(0).normal(0,0.03,len(dd))), dd.value, color=c, s=18, alpha=0.8)
    p,_ = curve_fit(emax, dd.dose.values, np.log10(dd.value.values), p0=[1,40,15,1.5], bounds=([0,0,0.1,0.3],[5,500,200,6]), maxfev=20000)
    xx = np.logspace(0, np.log10(40), 100); ax.plot(xx, 10**emax(xx,*p), color=c, lw=2, label=f'{g}: Emax {p[1]:.0f}, ED50 {p[2]:.0f} ug' + (' (label undefined)' if g=='PSLN-344/R848' else ''))
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('Adjuvant dose per mouse (ug), intranasal'); ax.set_ylabel('Lung Ifnb1 at 16 h (fold vs untreated)')
ax.set_title('a. Mn raises the ceiling of STING output (S08-A)\nPSLN-212 plateaus at ~14-fold; more PSLN-212 cannot match PSLN-344', fontsize=9.5); ax.legend(fontsize=7.0, loc='lower right')
# b Gm-csf kinetics
ax = axs[1]; d = m[m.block=='S02-F']
tmap = {'16h':16,'36h':36,'72h':72}; cc = {'PSLN-344':'#1565c0','PSLN-212':'#ef6c00','Sham':'#757575'}
for g, c in cc.items():
    dd = d[d.group==g]; tt = dd.timepoint.map(tmap)
    ax.scatter(tt + {'PSLN-344':1.5,'PSLN-212':0,'Sham':-1.5}[g], dd.value, color=c, s=16, alpha=0.7)
    gm = dd.groupby('timepoint').value.apply(lambda x: np.exp(np.log(x).mean())); ax.plot([tmap[k] for k in gm.index], gm.values, color=c, lw=2, label=g)
ax.set_yscale('log'); ax.set_xticks([16,36,72]); ax.set_xlabel('Hours after immunisation'); ax.set_ylabel('Lung Gm-csf (fold vs untreated)')
ax.set_title('b. GM-CSF induction is Mn-dependent (S02-F)\nGM 8.5 vs 1.6 at 36 h (5.4x)', fontsize=9.5); ax.legend(fontsize=8)
# c interventions
ax = axs[2]
items = [('S02-G','PSLN-212','PSLN-212+GM-CSF','aged: PSLN-212 -> +GM-CSF\nmoDC (Ly6C+CD11c+MHCII+) d5'),
         ('S02-H','WT w/o cDC','IFN w/o cDC','BM chimera: WT -> Ifnar-/- donor\nCD45.2+ moDC d3'),
         ('S02-H','IFN w/o cDC','GMCSF','Ifnar-/- donor -> +GM-CSF i.t.\nCD45.2+ moDC d3'),
         ('S07-B','PSLN-344','PSLN-344+INCB3344','PSLN-344 -> +CCR2 antagonist\nlung Ly6C+ macrophages (timepoint n.s.)'),
         ('S02-I','PSLN-344(Y)','PSLN-344(Y)+INCB3344','young PSLN-344 -> +CCR2 antagonist\nlung GZMB+ CD8 d5'),
         ('S02-C','PSLN-344','PTX','PSLN-344 -> +pertussis toxin\nMLN AF647-OVA+ DC 36 h'),
         ('S02-E','PSLN-344','PTX','PSLN-344 -> +pertussis toxin\nMLN DC -> OT-I priming'),
         ('S11-C','CBX-','CBX+','PSLN-344 -> +carbenoxolone\nrecruited monocytes d3'),
         ('S01-C','WT','SPA/D','DiD-liposome uptake: WT -> Sftpa1/d-/-\nalveolar macrophages 16 h')]
for i, (b, g0, g1, lab) in enumerate(items[::-1]):
    x0 = m[(m.block==b)&(m.group==g0)].value.values; x1 = m[(m.block==b)&(m.group==g1)].value.values
    y = i
    ax.plot([x0.mean(), x1.mean()],[y,y], color='#bdbdbd', lw=1, zorder=0)
    ax.scatter(x0, [y+0.12]*len(x0), color='#1565c0', s=14); ax.scatter(x1, [y-0.12]*len(x1), color='#c62828', s=14)
    ax.annotate('', xy=(x1.mean(), y), xytext=(x0.mean(), y), arrowprops=dict(arrowstyle='->', color='k', lw=1.3))
ax.set_yticks(range(len(items))); ax.set_yticklabels([it[3].replace(chr(10), '  |  ') for it in items[::-1]], fontsize=8.2); ax.set_xlim(-1, 50); ax.set_xlabel('% of parent gate  (blue = reference arm, red = intervention arm; n = 4-5/arm)', fontsize=8.5)
ax.set_title('c. Cellular interventions (IFNAR, GM-CSF, CCR2, Gi, gap junctions, SP-A/D)\neach moves its pathway readout; none was carried to a survival endpoint', fontsize=9.5)
plt.savefig('/tmp/outputs/figures/fig4_mechanism_data.png', dpi=150); print('ok')

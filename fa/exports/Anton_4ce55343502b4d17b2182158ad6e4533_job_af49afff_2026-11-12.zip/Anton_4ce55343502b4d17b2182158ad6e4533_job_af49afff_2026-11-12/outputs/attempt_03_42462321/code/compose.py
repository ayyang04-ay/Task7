"""Compose the portfolio-review memo (Markdown -> DOCX) from computed, registered numbers."""
import sys
sys.path.insert(0, '/tmp/work')
import pandas as pd, numpy as np
import psln_numbers as NB
import register as RG
from integrity_log import LOG

V = NB.V


def ref(nid):
    return f'[{nid}]'


def T(key):
    """value text + register id."""
    v = V[key]
    return f'{v[0]} {ref(v[1])}'


def G(block, grp, an='', tp=''):
    v = V[('trio', block, an, tp)][grp]
    return f'{v[0]} {ref(v[1])}'


def Gv(block, grp, an='', tp=''):
    return V[('trio', block, an, tp)][grp][0]


def Gid(block, grp, an='', tp=''):
    return V[('trio', block, an, tp)][grp][1]


def MN(block, an='', tp=''):
    v = V[('trio', block, an, tp)]['mn']
    return f'{v[0]} {ref(v[1])}'


def MNe(block, an='', tp=''):
    """short effect only"""
    r = V[('trio', block, an, tp)]['mn'][2]
    if 'ratio' in r.effect_type or 'fold' in r.effect_type:
        return f'{RG.fmt_num(r.effect)}× [{RG.fmt_num(r.lo)}–{RG.fmt_num(r.hi)}]'
    return f'{r.effect:+.1f} points [{r.lo:+.1f}, {r.hi:+.1f}]'


def YGe(block, an='', tp=''):
    r = V[('trio', block, an, tp)]['y'][2]
    if 'ratio' in r.effect_type or 'fold' in r.effect_type:
        return f'{RG.fmt_num(r.effect)}× [{RG.fmt_num(r.lo)}–{RG.fmt_num(r.hi)}], p={r.welch_p:.2g}'
    return f'{r.effect:+.1f} points [{r.lo:+.1f}, {r.hi:+.1f}], p={r.welch_p:.2g}'


def rest(readout):
    return T(('rest', readout))


def restpct(readout):
    r = NB.RS[NB.RS.readout == readout].iloc[0]
    return f'{r.ratio_344*100:.0f}%'


def restid(readout):
    return V[('rest', readout)][1]


def pool(key):
    return T(key)


def surv(block):
    return V[('surv', block)]


def arm(block, grp):
    d = RG.s[(RG.s.block == block) & (RG.s.group == grp)]
    return f'{int((d.event == 0).sum())}/{len(d)}'


def short_pool(key):
    txt, nid = V[key]
    return txt.split('; stratified')[0] + f' {ref(nid)}'


OUT = []


def W(x=''):
    OUT.append(x)


# ===================================================================================== TITLE
W('---')
W('title: "PSLN-344 (Mn²⁺-STING surfactant-biomimetic liposome): portfolio review recommendation and evidence"')
W('subtitle: "Intranasal adjuvant for inactivated influenza vaccine in older adults — decision memo for the portfolio committee"')
W('---')
W()
W('**Basis.** All analysis uses only the programme data: *adjuvant_program_dataset.xlsx* (15 sheets; 2,121 per-animal measurements, 527 per-animal survival records, '
  '3,472 body-weight values) and *adjuvant_program_annotation.pdf* (19 pp). Every number below carries a register ID in square brackets, e.g. [N001]. The register '
  '(Evidence workbook, sheet **Numbers_register**) gives for each ID the exact source cells and the reduction applied. General reduction rules are in Appendix A. '
  'Where I rely on general scientific knowledge rather than our data, the text says so explicitly ("external context").')
W()

# ===================================================================================== 1. RECOMMENDATION
W('# 1. Recommendation')
W()
W('**ADVANCE — conditionally.** Fund a time-boxed (about 9–12 months) confirmation and de-risking stage with pre-set kill criteria (Section 7). '
  'Do **not** yet commit IND-enabling GLP toxicology or GMP scale-up, and do **not** use the current data package externally (partners, regulators, publications) '
  'until it has been verified against source records.')
W()
W('| Question | Answer | Where defended |')
W('|' + '-'*22 + '|' + '-'*70 + '|' + '-'*12 + '|')
W(f'| Do we advance? | **Yes, conditionally:** a gated 9–12-month confirmation stage; no IND-enabling spend until Gates 1–4 pass. | §1, §7 |')
W(f'| What drives protection? | An antigen-specific adaptive response made possible by Mn²⁺ raising the ceiling of STING signalling (IFN-β, GM-CSF, monocyte-derived DCs). '
  f'Antibody accounts for homologous protection; heterosubtypic and durable protection tracks a cross-reactive CD8 arm that Mn²⁺ only partly restores. Not an innate antiviral state. | §4 |')
W(f'| Biomarker worth carrying forward? | Two: early nasal/blood interferon signature as the PD and dose-setting marker (not an efficacy correlate); cross-reactive CD8 IFN-γ as the '
  f'lead efficacy candidate for breadth, with HAI/MN as the regulatory anchor and nasal IgA to be added. None validated yet. | §5 |')
W(f'| Could it go into patients, in what role? | Not yet; first-in-human around month 20–24. Role: intranasal (or inhaled) mucosal adjuvant with inactivated antigen for adults ≥65 — '
  f'first as an add-on to licensed IM vaccination, strategically as a pandemic H5 component. Not a stand-alone prophylactic, not a young-adult product. | §6 |')
W(f'| Next studies | Source-data verification (weeks 0–8); blinded, benchmarked aged-mouse efficacy with clinical antigen and a Mn²⁺-only control (months 2–9); mechanism-of-protection '
  f'depletions/transfers; route and antigen-format study; intranasal Mn²⁺ CNS biodistribution/neurotoxicity; CMC; then ferret and GLP toxicology. | §7 |')
W(f'| What we would drop, and why | A +71-point survival effect in aged mice {ref(V["pool_mn_primary"][1])} with a specific mechanism and PD marker — dropped only if the data do not verify, intranasal Mn²⁺ is unsafe, '
  f'or the effect does not survive human-relevant delivery/antigen or beat standard of care. | §9 |')
W()
W('**Why advance.** The efficacy signal is large enough, consistent enough and mechanistically specific enough that it survives removal of every data block I could not trust:')
W()
W(f'1. **Mn²⁺ raises survival of aged mice from 12% to 84%.** Across the 10 aged-mouse challenge experiments that contain both arms, PSLN-344 vs its Mn-free parent PSLN-212: '
  f'{short_pool("pool_mn_primary")} (stratified log-rank p = 9×10⁻²⁰). Using **only** the three experiments with no integrity flag: {short_pool("pool_mn_unflag")}. '
  f'Against sham (antigen + empty liposome): {short_pool("pool_sham_primary")}.')
W(f'2. **The benefit replicates across conditions:** four challenge viruses (homologous CA09 H1N1; heterosubtypic PR8 H1N1, rgH5N1, Perth H3N2; wild-type H5N1), '
  f'three mouse backgrounds (BALB/c; C57BL/6 {arm("S15-L","PSLN-344")} vs {arm("S15-L","PSLN-212")} {ref(surv("S15-L")[1])}; Swiss Webster '
  f'{arm("S15-N","PSLN-344")} vs {arm("S15-N","PSLN-212")} {ref(surv("S15-N")[1])}), challenge 2–60 days after a single dose, and in animals with prior influenza infection '
  f'(Perth H3N2 after PR8 imprinting: PSLN-344 6/7 vs PSLN-212 0/7 {ref(V[("imp","S06-F(imprint)")][1])}).')
W(f'3. **The gain is specific to Mn²⁺ and cannot be bought with more PSLN-212.** Mn²⁺ is the only compositional difference; CDN-1807 encapsulation is not higher '
  f'({V["ee_344"][0]} vs {V["ee_212"][0]} {ref(V["ee"][1])}). Mn²⁺ raises the *ceiling* of lung IFN-β output: fitted Emax '
  f'{V[("emax","PSLN-344")][0].split(" (")[0].replace("Emax ","")} vs {V[("emax","PSLN-212")][0].split(" (")[0].replace("Emax ","")}-fold {ref(V[("emax","PSLN-344")][1])}, {ref(V[("emax","PSLN-212")][1])}; '
  f'PSLN-212 is already on its plateau at 20 µg (20 µg gives {V["dose_212_20_vs_40"][0].split("; ratio ")[1].split(";")[0]}× the 40 µg response {ref(V["dose_212_20_vs_40"][1])}).')
W(f'4. **Antibody responses in aged mice reach near-young levels.** Day-14 HAI against CA09 H1N1 (geometric mean titre): PSLN-344 {G("S03-C","PSLN-344")}, '
  f'PSLN-212 {G("S03-C","PSLN-212")}, young PSLN-212 {G("S03-C","PSLN-212(Y)")}. Homologous lethal challenge: PSLN-344 {arm("S03-I","PSLN-344")}, '
  f'PSLN-212 {arm("S03-I","PSLN-212")}, young {arm("S03-I","PSLN-212(Y)")} {ref(surv("S03-I")[1])}.')
W(f'5. **No tolerability signal in the limited mouse data.** Post-vaccination weight nadir {V[("nadir","PSLN-344")][0].split(" (")[0].replace("nadir mean ","")} of baseline vs '
  f'{V[("nadir","Vaccine")][0].split(" (")[0].replace("nadir mean ","")} for antigen alone ({V[("nadir_c","PSLN-344","Vaccine")][0]}) {ref(V[("nadir","PSLN-344")][1])}, {ref(V[("nadir","Vaccine")][1])}, {ref(V[("nadir_c","PSLN-344","Vaccine")][1])}; '
  f'no induction of Ifnb1, Tnf or Isg15 in CNS tissue at 36 h (PSLN-344 vs sham {V[("cns","Ifnb1")][0].split(";")[0]}, {V[("cns","Tnf")][0].split(";")[0]}, '
  f'{V[("cns","Isg15")][0].split(";")[0]}) {ref(V[("cns","Ifnb1")][1])}, {ref(V[("cns","Tnf")][1])}, {ref(V[("cns","Isg15")][1])}, whereas the intranasal cholera-toxin control raised CNS Ifnb1 {V[("cns_ct","Ifnb1")][0].split(" [")[0]} over PBS {ref(V[("cns_ct","Ifnb1")][1])}.')
W()
W('**Why conditional.**')
W()
W('1. **The data package fails basic integrity checks** (Section 3): one survival block is a row-for-row copy of another (S06-D = S06-C); challenge body weights are recycled '
  'between experiments; two flow blocks share 35% of their values; two derived blocks carry rotated group labels; two body-weight blocks contradict the survival blocks they '
  f'belong to; and unvaccinated, unchallenged 20-month controls died ({V["untreated"][0].split(": total ")[1]} {ref(V["untreated"][1])}). The statistics above are robust to '
  'removing every problem I could detect, but not to problems I cannot detect from a spreadsheet. Source-data verification is therefore Gate 1.')
W('2. **No comparison against what older adults receive today.** Every comparator is internal (sham, PSLN-212, cGAMP liposome CMP-204, young mice). There is no arm with a '
  'licensed older-adult approach (high-dose antigen or an MF59-type emulsion, intramuscular), so we cannot say PSLN-344 adds value over standard of care.')
W(f'3. **Intranasal Mn²⁺ safety in the target population is unmeasured.** The only CNS data are three transcripts at one timepoint in n = 5 per group; the study could only have '
  f'detected ≥1.4–2.0-fold changes {ref(V["cns_mdd"][1])}. There are no Mn²⁺ tissue levels, no olfactory-bulb or nasal histopathology, no repeat-dose data and no Mn²⁺ '
  'content for the formulation (external context: the olfactory route is a recognised path for Mn²⁺ into the brain, and intranasal adjuvants have a history of facial-nerve '
  'adverse events).')
W(f'4. **Restoration is partial.** Aged PSLN-344 survival remains below young: {short_pool("pool_young_primary")}; the shortfall sits in heterosubtypic challenges at day 60 '
  f'({V[("cat","heterosubtypic d60")][0].split(" (Fisher")[0]}, Fisher p = {V[("cat","heterosubtypic d60")][0].split("Fisher p=")[1].split(")")[0]} {ref(V[("cat","heterosubtypic d60")][1])}). '
  f'DC costimulation stays at {restpct("MLN DC CD40+, day 3")}–{restpct("MLN DC CD86+, day 3")} of young {ref(restid("MLN DC CD40+, day 3"))}, {ref(restid("MLN DC CD86+, day 3"))} '
  f'and the memory CD8 response at about {restpct("MLN IFN-g+ CD8 (H5 restim), d60")} {ref(restid("MLN IFN-g+ CD8 (H5 restim), d60"))}.')
W('5. **Translation gaps that could erase the effect in people:** the antigen was formalin-inactivated *whole* virus (internal proteins present; clinical seasonal vaccines '
  'are split/subunit); the formulation is designed to reach alveolar cells (AECII and SP-A/D-dependent macrophage uptake), which a human nasal spray does not reach; only '
  'female mice were used; there is no Mn²⁺-only control, so we do not know whether the CDN is needed.')
W()
W('**The bottom line for the committee:** PSLN-344 has the strongest single-dose protection signal in aged animals in this dataset, and the Mn²⁺ mechanism is specific and '
  'testable. The package is not yet credible enough, or comparative enough, to justify IND-enabling spend. A bounded confirmation stage answers the four questions that '
  'decide the asset (is it real, is it better than standard of care, is intranasal Mn²⁺ safe, does it survive translation) before any IND-enabling money is committed.')
W()

# ===================================================================================== 2. EFFICACY CASE
W('# 2. The efficacy case, in numbers')
W()
W('## 2.1 Survival after lethal challenge (aged mice, single intranasal dose of antigen + 20 µg adjuvant)')
W()
W('Table 1. Fourteen-day survival (survivors/animals) by experiment. Source cells and statistics for each row are in the register entry cited.')
W()
W('| Block | Challenge (virus, timing after vaccination) | Sham | PSLN-212 | PSLN-344 | Young PSLN-212 | PSLN-344 vs PSLN-212 (Fisher p / log-rank p) | Integrity flags | Ref |')
W('|--------|--------------------------|------|-------|-------|-------|--------------|------------|------|')
for r in NB.SURV_TABLE.itertuples():
    young = getattr(r, '_6') if False else (r[NB.SURV_TABLE.columns.get_loc('PSLN-212(Y)') + 1] if isinstance(r[NB.SURV_TABLE.columns.get_loc('PSLN-212(Y)') + 1], str) else '—')
    W(f'| {r.block} | {r.challenge} | {r.Sham} | {r[NB.SURV_TABLE.columns.get_loc("PSLN-212")+1]} | {r[NB.SURV_TABLE.columns.get_loc("PSLN-344")+1]} | {young} | '
      f'{r.fisher:.2g} / {r.logrank:.2g} | {r.flags} | {ref(r.nid)} |')
W()
W(f'Extra arms not shown: CMP-204 (cGAMP liposome) in S03-I {arm("S03-I","CMP-204")}; unvaccinated, unchallenged "Untreated" controls in S06-E/F/G '
  f'{arm("S06-E(d60)","Untreated")}, {arm("S06-F(d60)","Untreated")}, {arm("S06-G","Untreated")} survived {ref(V["untreated"][1])}.')
W()
W('![Figure 1. Survival differences by experiment and pooled. A: PSLN-344 minus PSLN-212 (the Mn²⁺ effect). B: aged PSLN-344 minus young PSLN-212 (restoration). '
  'Orange = block carrying an integrity flag; grey = excluded duplicate (S06-D).](figures/fig1_survival_forest.png)')
W()
W('**Pooled estimates** (Mantel–Haenszel risk difference with Sato variance; stratified log-rank; exact conditional CMH):')
W()
W('| Comparison | Analysis set | Result | Ref |')
W('|--------------|--------------------------|----------------------------------------------------|------|')
for key, comp, aset in [('pool_mn_primary', 'PSLN-344 vs PSLN-212', 'Primary: 10 experiments (S06-D excluded as a copy)'),
                        ('pool_mn_sensB', 'PSLN-344 vs PSLN-212', 'Unflagged + minor-flag experiments (S06-A, S06-B, S06-C, S06-F, S15-N)'),
                        ('pool_mn_unflag', 'PSLN-344 vs PSLN-212', 'Unflagged experiments only (S06-A, S06-B, S06-F)'),
                        ('pool_mn_sensC', 'PSLN-344 vs PSLN-212', 'Primary + S06-D counted as if independent (for reference only)'),
                        ('pool_sham_primary', 'PSLN-344 vs sham', 'Primary'),
                        ('pool_212sham_primary', 'PSLN-212 vs sham', 'Primary'),
                        ('pool_young_primary', 'Aged PSLN-344 vs young PSLN-212', 'Primary (9 experiments with a young arm)'),
                        ('pool_young_unflag', 'Aged PSLN-344 vs young PSLN-212', 'Unflagged experiments only')]:
    W(f'| {comp} | {aset} | {V[key][0]} | {ref(V[key][1])} |')
W()
W('Reading: the Mn²⁺ effect is +0.66 to +0.71 in absolute survival whichever set is used; including the duplicated block changes nothing, which is why excluding it is '
  'a matter of integrity, not of outcome. PSLN-212 alone is only marginally better than sham in aged mice (+0.11). Aged PSLN-344 is still 17 points below young animals.')
W()
W('**Where the shortfall against young animals sits** (counts summed within challenge type):')
W()
W('| Challenge type | Experiments | Aged PSLN-344 | Young PSLN-212 | Aged PSLN-212 | Sham | Fisher p (aged PSLN-344 vs young) | Ref |')
W('|--------------|------------------|---------|---------|---------|-------|----------|------|')
for r in NB.CAT.itertuples():
    W(f'| {r.category} | {r.blocks} | {r.aged_344} | {r.young_212} | {r.aged_212} | {r.sham} | {r.p_vs_young:.2g} | {ref(r.nid)} |')
W()
from scipy.stats import fisher_exact as _fe
_p = _fe([[10, 4], [14, 0]])[1]
_c = []
for _b in ['S06-E(d60)', 'S06-F(d60)']:
    _c += RG.survcells(_b, ['PSLN-344', 'PSLN-212(Y)'])
_nid = RG.reg('d60_exG', 'Day-60 heterosubtypic survival excluding S06-G: aged PSLN-344 vs young PSLN-212(Y)', f'10/14 vs 14/14; Fisher p={_p:.2g}', RG.compress(_c),
              'survivors summed over S06-E(d60) and S06-F(d60); Fisher exact two-sided')
W(f'The gap is zero for the homologous (HA-matched) challenge and largest for heterosubtypic challenge at day 60 — the condition in which HA-neutralising antibody cannot '
  f'explain protection and memory T cells are the prime candidate. If S06-G is set aside because its unchallenged controls also died (3/7), the day-60 comparison is '
  f'10/14 vs 14/14 (Fisher p = {_p:.2g}) {ref(_nid)}, so the durability gap is suggestive rather than proven.')
W()
W('**Other survival evidence.**')
W()
W(f'- *Antigen is required* (S15-H, challenge 3 days after dosing): {T("s15h")}. Caveat: the matching weight block S15-I reuses S15-C weights (I-02).')
W(f'- *Prior exposure does not blunt the effect* (14-month mice, half infected with PR8 at 10 months). PR8 challenge: {T(("imp","S06-E(imprint)"))}. Perth H3N2 challenge: '
  f'{T(("imp","S06-F(imprint)"))}. (Imprinted PSLN-212 animals survived PR8 because they had already been infected with PR8.)')
W(f'- *Young animals need no Mn²⁺:* PR8 {T(("young","S09-B"))}; Perth H3N2 {T(("young","S09-D"))}; rgH5N1 at day 180 {T(("young","S09-F"))}; CA09 10×LD50 {T(("young","S13-E"))}. '
  'PSLN-212 already gives complete protection in young mice, so the asset\'s value is age-specific.')
W()
W('## 2.2 Immunogenicity and immune mechanism (aged mice unless stated; n = 5 per group)')
W()
W('Table 2. Key immune readouts. Titres and qPCR: geometric mean [95% CI]; flow cytometry: mean ± SD (%). "Mn effect" = PSLN-344 vs PSLN-212; "vs young" = aged PSLN-344 vs young PSLN-212(Y).')
W()
W('| Readout (block) | Sham | PSLN-212 | PSLN-344 | Young PSLN-212 | Mn effect [95% CI] | Aged PSLN-344 vs young |')
W('|--------------------|------------|-------------|-------------|-------------|--------------|---------------|')
rows2 = [('S01-A', 'Ifnb1', '16h', 'Lung Ifnb1 mRNA, 16 h (S01-A)'), ('S01-A', 'Ifnb1', '72h', 'Lung Ifnb1 mRNA, 72 h (S01-A)'),
         ('S01-D', '', '4', 'Lung monocytes, d4 (S01-D)'), ('S01-E', '', '4', 'Lung CD11b+ DC, d4 (S01-E)'), ('S02-A', '', '', 'Lung CCR7+ migratory DC, 72 h (S02-A)'),
         ('S02-D CD40', '', '', 'CD40+ MLN CD11b+ DC, d3 (S02-D)'), ('S02-D CD86', '', '', 'CD86+ MLN CD11b+ DC, d3 (S02-D)'),
         ('S04-A', 'ICOS-high Tfh', '', 'ICOS-high Tfh, d7 (S04-A)'), ('S04-B Foxp3', '', '', 'Tfr (Foxp3+), d7 (S04-B)'), ('S04-C', '', '', 'Tfr (Foxp3+), d30 (S04-C)'),
         ('S03-K', '', '', 'GC B cells, d7 (S03-K)'),
         ('S03-A', '', '', 'IgG anti-CA09, d14 (S03-A)'), ('S03-C', '', '', 'HAI anti-CA09, d14 (S03-C)'), ('S03-D', '', '', 'Neutralisation anti-CA09, d14 (S03-D)'),
         ('S03-G', '', '', 'HAI anti-Aichi H3N2, d14 (S03-G)'), ('S03-H', '', '', 'Neutralisation anti-Aichi, d14 (S03-H)'),
         ('S13-I', '', '', 'IgG anti-CA09, d28 after boost (S13-I)'),
         ('S05-E', '', '', 'Lung GZMB+ CD8, d3 (S05-E)'), ('S05-F', '', '', 'MLN IFN-γ+ CD8 (H5 restim), d14 (S05-F)'),
         ('S05-G', '', '', 'MLN IFN-γ+ CD8 (H5 restim), d60 (S05-G)'), ('S05-I', '', '', 'Lung CD8 TRM, d25 (S05-I; conditions ambiguous, I-09)')]
for b, an, tp, lab in rows2:
    tr = V[('trio', b, an, tp)]
    cell = lambda grp: (f'{tr[grp][0]} {ref(tr[grp][1])}' if grp in tr else '—')
    W(f'| {lab} | {cell("Sham")} | {cell("PSLN-212")} | {cell("PSLN-344")} | {cell("PSLN-212(Y)")} | {MNe(b, an, tp)} {ref(tr["mn"][1])} | {YGe(b, an, tp)} {ref(tr["y"][1])} |')
sA = V[('sub', 'S13-A')]; sC = V[('sub', 'S13-C')]
W(f'| IgG2a/IgG1 anti-CA09, d14 (recomputed from S13-A/B) | — | {sA["PSLN-212"][0]} {ref(sA["PSLN-212"][1])} | {sA["PSLN-344"][0]} {ref(sA["PSLN-344"][1])} | '
  f'{sA["PSLN-212(Y)"][0]} {ref(sA["PSLN-212(Y)"][1])} | Welch p={sA["p"]:.2g} | — |')
W(f'| IgG2a/IgG1 anti-Aichi, d14 (recomputed from S13-C/D) | — | {sC["PSLN-212"][0]} {ref(sC["PSLN-212"][1])} | {sC["PSLN-344"][0]} {ref(sC["PSLN-344"][1])} | '
  f'{sC["PSLN-212(Y)"][0]} {ref(sC["PSLN-212(Y)"][1])} | Welch p={sC["p"]:.2g} | — |')
W()
W('![Figure 2. Restoration profile: each readout in aged PSLN-344 (colour) and aged PSLN-212 (grey) as a percentage of young PSLN-212.](figures/fig2_restoration_profile.png)')
W()
W('**What Figure 2 shows.** Mn²⁺ brings the *quantity* of the early (afferent) response to young levels — lung IFN-β at 16 h '
  f'{restpct("Lung Ifnb1, 16 h")} of young {ref(restid("Lung Ifnb1, 16 h"))}, monocyte recruitment {restpct("Lung monocytes, day 4")} {ref(restid("Lung monocytes, day 4"))}, '
  f'migratory DC {restpct("Lung CCR7+ migratory DC, 72 h")} {ref(restid("Lung CCR7+ migratory DC, 72 h"))} — and brings HAI to {restpct("HAI H1N1, d14")}–{restpct("HAI H3N2, d14")} of young '
  f'(not significantly different) {ref(restid("HAI H1N1, d14"))}, {ref(restid("HAI H3N2, d14"))}. It does **not** restore the *quality* of DC activation (CD40 '
  f'{restpct("MLN DC CD40+, day 3")}, CD86 {restpct("MLN DC CD86+, day 3")} of young {ref(restid("MLN DC CD40+, day 3"))}, {ref(restid("MLN DC CD86+, day 3"))}), and the CD8 '
  f'effector/memory arm sits at {restpct("Lung GZMB+ CD8, d3")}–{restpct("MLN IFN-g+ CD8 (H1 restim)")} of young (5 of 8 CD8 readouts significantly below young) '
  f'{ref(restid("Lung GZMB+ CD8, d3"))}, {ref(restid("MLN IFN-g+ CD8 (H1 restim)"))}. Tfr frequency, suppressed at day 7, rebounds to sham levels by day 30 in aged animals '
  f'({G("S04-C","PSLN-344")} vs young {G("S04-C","PSLN-212(Y)")}), and lung IFN-β is still {restpct("Lung Ifnb1, 72 h [young lower]")} of the young value at 72 h '
  f'{ref(restid("Lung Ifnb1, 72 h [young lower]"))} — a slower-resolving innate response.')
W()

# ===================================================================================== 3. INTEGRITY
_i01 = RG.reg('int_I01', 'I-01: S06-D vs S06-C identical (day, event) pairs', '28/28 animals identical in all 4 groups (Sham, PSLN-212, PSLN-344, PSLN-212(Y))',
               'S06!A3:Q30; S06!A34:E61', 'row-by-row comparison of day and event for every animal (same row order within group)')
_i02 = RG.reg('int_I02', 'I-02: recycled body-weight values (examples)', '17 animal pairs across blocks with >=5 identical same-day values; whole rows copied; 58 long fractional parts shared across 10 blocks (140 cells)',
               'S09!N39:N46; S09!N66:N73; S15!I5:O5; S15!W105:AC105; S09!G18:N18; S09!W18:AD18; S08!G22:K26; S15!B54:F58; S15!W24:AC29; S15!W73:AC78',
               'all animal-trajectory pairs compared for identical same-day values; fractional parts (>=4 dp) compared across blocks excluding small-denominator fractions (q<=40)')
_i03 = RG.reg('int_I03', 'I-03: S11-A vs S11-B identical same-position values', '35/100 identical; non-corresponding positions 6/400 (1.5/100); negative control S11-A vs S11-D 0/100',
               'S11!B3:U7; S11!B10:U14; S11!B24:U28', 'position-by-position equality (group x day x animal order)')
_i04 = RG.reg('int_I04', 'I-04: S03-B/F printed quotients vs quotients recomputed from S13 raw titres', 'printed PSLN-212 = young data, printed PSLN-344 = PSLN-212 data, printed PSLN-212(Y) = PSLN-344 data; max relative error 6.5e-4',
               'S03!G3:I7; S03!G10:I14; S13!A3:C7; S13!E3:G7; S13!I3:K7; S13!M3:O7', 'per-animal IgG2a/IgG1 recomputed for every label hypothesis; match if max relative difference < 1e-3')
_INTREF = {'I-01': _i01, 'I-02': _i02, 'I-03': _i03, 'I-04': _i04, 'I-07': V['untreated'][1]}
W('# 3. What the data can and cannot bear')
W()
W('Before using any block I checked it against the annotation, against the other blocks that measure the same animals or quantities, and for internal arithmetic '
  'consistency. I screened every pair of groups in the workbook for shared values, every pair of animal weight trajectories for shared same-day values, and every '
  'survival block against its own body-weight block. Nineteen issues were found; the consequential ones are below (full log with cell references: Appendix B and '
  'workbook sheet **Integrity_log**).')
W()
W('| ID | Severity | Where | What was found | How handled |')
W('|-----|-------|------------------|----------------------------------------|------------------------------|')
for e in LOG:
    if e['severity'] in ('Critical', 'Major'):
        W(f"| {e['id']} | {e['severity']} | {e['blocks']} | {e['short']}" + (f" {ref(_INTREF[e['id']])}" if e['id'] in _INTREF else '') + f" | {e['handling']} |")
W()
W('![Figure 3. Integrity evidence. a: S11-A vs S11-B paired values. b: S03-B/F printed quotients vs quotients recomputed from raw S13 titres. c: weights of two '
  'different experiments (S15-C, S15-I). d: S06-D vs S06-C survival.](figures/fig3_integrity_evidence.png)')
W()
W('**What this means for the decision.** (i) The central claim — Mn²⁺ improves survival in aged mice — does not depend on any compromised block: it holds in the '
  'three experiments with no flag at all (Table 1, Figure 1). (ii) Several secondary claims in the programme narrative do depend on compromised blocks and should be '
  f'withdrawn until re-run: day-3 rgH5N1 protection as shown in S06-D (a copy of S06-C; the only independent day-3 rgH5N1 data are S15-H, vaccine + PSLN-344 6/7 {ref(V["s15h"][1])}, whose weight block is also copied), "PSLN-344 skews towards Th2" or any subclass claim read from '
  'S03-B/F (labels rotated; the raw data show the opposite), any alveolar-macrophage or neutrophil kinetics (S11-A/B), any morbidity (weight-loss) claim after '
  'challenge (recycled weights), any claim about Mn²⁺ changing epithelial uptake (S08-C), and the macrophage-transfer result (S07-C). (iii) The pattern — copying, '
  'relabelling and recycling across many sheets — is a process problem, not a single typo. Until source records are checked we cannot rule out problems that leave no '
  'fingerprint in a spreadsheet, which is why Gate 1 comes before any further spend.')
W()

# ===================================================================================== 4. DRIVER OF PROTECTION
W('# 4. What is actually driving the protection?')
W()
W('Short answer: **an antigen-specific adaptive response that Mn²⁺ makes possible in aged animals by raising the ceiling of STING signalling; antibody explains the '
  'homologous protection, and the heterosubtypic and long-term protection tracks a cross-reactive CD8 T-cell arm that Mn²⁺ only partly restores.** The upstream '
  'steps are supported by intervention experiments; the link from any immune effector to survival has never been tested. Layer by layer:')
W()
W('**(a) It is not an innate antiviral state.** PSLN-344 given without antigen three days before challenge protected 0/7 aged mice; antigen alone 0/7; the '
  f'combination 6/7 {ref(V["s15h"][1])}. Adjuvant-induced IFN alone does not carry the animals through infection.')
W()
W('**(b) It is the Mn²⁺, acting on signal strength, not on dose or delivery.** PSLN-344 and PSLN-212 differ only by Mn²⁺; CDN encapsulation is slightly lower, not '
  f'higher, in PSLN-344 ({T("ee")}). Mn²⁺ doubles lung Ifnb1 at 16 h at equal dose ({MN("S01-A","Ifnb1","16h")}) and quadruples the maximal response '
  f'({V[("emax","PSLN-344")][0].split(";")[0]} {ref(V[("emax","PSLN-344")][1])} vs {V[("emax","PSLN-212")][0].split(";")[0]} {ref(V[("emax","PSLN-212")][1])}). '
  f'At 10 µg PSLN-344 already matches or exceeds 40 µg PSLN-212 ({T("dose_344_10_vs_212_40")}). The uptake data cannot show whether Mn²⁺ also changes epithelial delivery (I-10).')
W()
W('**(c) The signal travels through GM-CSF and monocyte-derived DCs.** Each link below moves with Mn²⁺ in the same direction, and six kinds of perturbation (CCR2, gap junction, IFNAR, GM-CSF, Gi, SP-A/D) were tested:')
W()
W(f'- Lung Gm-csf: 16 h {MNe("S02-F","Gm-csf","16h")}, 36 h {MNe("S02-F","Gm-csf","36h")}, 72 h {MNe("S02-F","Gm-csf","72h")} vs PSLN-212 '
  f'{ref(V[("trio","S02-F","Gm-csf","16h")]["mn"][1])}, {ref(V[("trio","S02-F","Gm-csf","36h")]["mn"][1])}, {ref(V[("trio","S02-F","Gm-csf","72h")]["mn"][1])}.')
W(f'- Monocyte recruitment is CCR2-dependent: CCR2 antagonist lowered lung monocytes {V["ccr2_mono_g0"][0]} → {V["ccr2_mono_g1"][0]} ({T("ccr2_mono")}) and Ly6C+ '
  f'macrophages {V["ccr2_mac_g0"][0]} → {V["ccr2_mac_g1"][0]} {ref(V["ccr2_mac"][1])}; it also cut lung GZMB+ CD8 cells in young PSLN-344 mice '
  f'{V["ccr2_cd8_g0"][0]} → {V["ccr2_cd8_g1"][0]} {ref(V["ccr2_cd8"][1])}. Carbenoxolone (gap-junction blocker, not specific) lowered recruited monocytes '
  f'{V["cbx_g0"][0]} → {V["cbx_g1"][0]} {ref(V["cbx"][1])}.')
W(f'- Monocyte-to-DC differentiation needs type I IFN signalling in the monocyte and can be rescued by GM-CSF: Ifnar⁻/⁻ marrow produced {V["ifnar_chim_g1"][0]} vs '
  f'{V["ifnar_chim_g0"][0]} moDC from wild-type marrow {ref(V["ifnar_chim"][1])}; intratracheal GM-CSF restored Ifnar⁻/⁻ cells to {V["ifnar_gmcsf_g1"][0]} '
  f'{ref(V["ifnar_gmcsf"][1])}; in aged mice GM-CSF lifted PSLN-212 moDC from {V["gmcsf_rescue_g0"][0]} to {V["gmcsf_rescue_g1"][0]} {ref(V["gmcsf_rescue"][1])}.')
W(f'- DC migration to the mediastinal node is Gi-dependent: pertussis toxin cut antigen+ MLN DC {V["ptx_dc_g0"][0]} → {V["ptx_dc_g1"][0]} {ref(V["ptx_dc"][1])} and their '
  f'ability to prime OT-I cells {V["ptx_prime_g0"][0]} → {V["ptx_prime_g1"][0]} {ref(V["ptx_prime"][1])}. In vivo, PTX reduced OT-I proliferation in the MLN '
  f'({V["ptx_mln_g0"][0]} → {V["ptx_mln_g1"][0]} {ref(V["ptx_mln"][1])}) but not in the lung ({V["ptx_lung_g0"][0]} → {V["ptx_lung_g1"][0]} {ref(V["ptx_lung"][1])}), '
  'so some priming may occur locally.')
W(f'- Delivery: the surfactant-mimetic liposome targets AECII over AECI ({V["aec_g0"][0]} vs {V["aec_g1"][0]} {ref(V["aec"][1])}) and alveolar-macrophage uptake '
  f'depends on SP-A/D ({V["spad_g0"][0]} → {V["spad_g1"][0]} in knockouts {ref(V["spad"][1])}; knockouts were young, WT age not stated).')
W()
W('![Figure 4. Mn²⁺ mechanism data: dose-response ceiling (S08-A), GM-CSF kinetics (S02-F) and cellular interventions.](figures/fig4_mechanism_data.png)')
W()
W('**(d) At the effector level, the survival pattern maps onto which immune arm was restored.** Homologous (HA-matched) protection — where neutralising antibody '
  f'is the expected effector — is fully restored (7/7, identical to young {ref(surv("S03-I")[1])}), and HAI/neutralisation is restored to 57–87% of young, none '
  'significantly different. Heterosubtypic protection, against viruses whose HA the vaccine does not contain, cannot be explained by HAI; it is partly restored '
  f'(day 60: {V[("cat","heterosubtypic d60")][0].split(" (Fisher")[0]} {ref(V[("cat","heterosubtypic d60")][1])}), mirroring the CD8 arm, which is only '
  f'59–80% restored (e.g. d60 IFN-γ+ CD8 {YGe("S05-G")} {ref(V[("trio","S05-G","","")]["y"][1])}; lung TRM {YGe("S05-I")} {ref(V[("trio","S05-I","","")]["y"][1])}). '
  f'The unrestored upstream bottleneck is DC costimulation (CD40/CD86 at 29–38% of young {ref(restid("MLN DC CD40+, day 3"))}, {ref(restid("MLN DC CD86+, day 3"))}), the most plausible reason the T-cell and long-lived responses lag. '
  'Caveats: this is a group-level inference across separate cohorts (the immune readouts and the challenges were done in different animals); antibodies against '
  'the shared N1 neuraminidase could contribute to rgH5N1 protection after the CA09-containing vaccine; and no CD8 depletion, serum transfer or B-cell-deficient '
  'experiment was done.')
W()
W('**(e) A translational warning inside the mechanism.** The vaccine antigen was formalin-inactivated whole virus, which carries the conserved internal proteins '
  '(NP, M1) that cross-reactive CD8 T cells recognise. Licensed seasonal vaccines are split or subunit preparations with far less of these proteins (external context). '
  'The heterosubtypic protection that differentiates PSLN-344 may therefore not transfer to a clinical antigen unless the antigen format is chosen for it.')
W()
W('![Figure 5. Evidence map: which links are intervention-tested, which are associations, and where the aged deficit persists.](figures/fig5_mechanism_map.png)')
W()

# ===================================================================================== 5. BIOMARKER
K = RG.K
def sep(block, an='', tp=''):
    r = K[(K.block == block) & (K.g1 == 'PSLN-344') & (K.g0 == 'PSLN-212') & (K.analyte == an) & (K.timepoint == tp)].iloc[0]
    return 'no overlap' if not r.ranges_overlap else 'overlap'
W('# 5. Is there a biomarker of efficacy worth carrying forward?')
W()
W('**Yes — but it is two different things, and neither is validated yet.** I scored every candidate in the data against five tests: (1) does it separate PSLN-344 from '
  'PSLN-212 animal-by-animal; (2) does it also track the residual shortfall against young animals (the only discriminating contrast the data offer, since every '
  'monotone readout "correlates" with survival across sham < PSLN-212 < PSLN-344); (3) is it on the Mn²⁺ pathway; (4) can it be measured in people; (5) is its source block sound. '
  'No block links an immune readout to survival in the same animal, so every statement below is group-level.')
W()
W('Table 3. Biomarker candidates.')
W()
W('| Candidate (block) | Mn effect, separation | Tracks residual gap vs young? | Human-measurable analogue | Verdict and role |')
W('|----------------|------------------|--------------------|------------------|----------------------------|')
W(f'| Early lung IFN-β, Ifnb1 16 h (S01-A, S08-A, S09-A) | {MNe("S01-A","Ifnb1","16h")}, {sep("S01-A","Ifnb1","16h")} {ref(V[("trio","S01-A","Ifnb1","16h")]["mn"][1])}; dose-responsive to Emax | '
  f'No — fully restored ({restpct("Lung Ifnb1, 16 h")} of young) while heterosubtypic protection is not; present without protection when given without antigen | '
  'IFN-β/IFN-λ/CXCL10 in nasal lining fluid; blood interferon-stimulated-gene score, 6–48 h | **Carry forward as PD / target-engagement and dose-selection marker. Not an efficacy correlate.** |')
W(f'| Gm-csf, 16–72 h (S02-F) | {MNe("S02-F","Gm-csf","36h")} at 36 h, {sep("S02-F","Gm-csf","36h")} {ref(V[("trio","S02-F","Gm-csf","36h")]["mn"][1])} | Unknown (no young arm) | GM-CSF in nasal lining fluid | Exploratory PD marker of the Mn²⁺-specific step |')
W(f'| Resolution: Ifnb1 at 72 h (S01-A); TNF at 16 h (S09-A) | — | Aged PSLN-344 {restpct("Lung Ifnb1, 72 h [young lower]")} of young at 72 h {ref(restid("Lung Ifnb1, 72 h [young lower]"))}; '
  f'TNF {V[("cyt_y","Tnf")][0].split(";")[0]} vs young PSLN-212 {ref(V[("cyt_y","Tnf")][1])} | ISG score at 72 h–7 d; TNF, IL-6, CRP | **Carry forward as a safety/reactogenicity marker in older adults** |')
W(f'| HAI / neutralisation, d14 (S03-C/D/G/H) | HAI {MNe("S03-C")}, {sep("S03-C")} {ref(V[("trio","S03-C","","")]["mn"][1])} | No — restored (76–87% HAI; n.s.); explains homologous but not heterosubtypic protection | '
  'Serum HAI/MN (regulatory standard) | **Carry forward as primary immunogenicity endpoint (regulatory anchor).** Not the differentiator. Note: in this model the human '
  f'"seroprotection" cut-off (HAI ≥1:40) does not predict survival — PSLN-212 reached it in {V[("hai40","S03-C")][0].split("; ")[2].replace("PSLN-212 ","")} animals yet 0/7 survived {ref(V[("hai40","S03-C")][1])}, {ref(surv("S03-I")[1])} |')
W(f'| ICOS-high Tfh, d7 (S04-A) | {MNe("S04-A","ICOS-high Tfh")}, {sep("S04-A","ICOS-high Tfh")} {ref(V[("trio","S04-A","ICOS-high Tfh","")]["mn"][1])} | Partly ({restpct("ICOS-high Tfh, d7")} of young, p=0.08) | '
  'Circulating ICOS+PD-1+CXCR5+ Tfh at day 7 (blood); an established early correlate of influenza-vaccine antibody responses in people (external context) | Carry forward as an early (day-7) predictor of the antibody response |')
W(f'| Cross-reactive CD8 IFN-γ, d14 and d60 (S05-F/G, S14-A) | d14 {MNe("S05-F")}, {sep("S05-F")}; d60 {MNe("S05-G")}, {sep("S05-G")} {ref(V[("trio","S05-F","","")]["mn"][1])}, {ref(V[("trio","S05-G","","")]["mn"][1])} | '
  f'**Yes** — {restpct("MLN IFN-g+ CD8 (H5 restim), d14")} and {restpct("MLN IFN-g+ CD8 (H5 restim), d60")} of young (both p<0.05), matching the day-60 heterosubtypic survival gap | '
  'PBMC IFN-γ ELISpot / ICS against conserved NP/M1 peptide pools | **Lead candidate efficacy biomarker for breadth and durability — the asset\'s differentiator.** Must be validated (individual-level link to protection; CD8 depletion) |')
W(f'| Lung CD8 TRM, d25 (S05-I) | {MNe("S05-I")}, {sep("S05-I")} {ref(V[("trio","S05-I","","")]["mn"][1])} | Yes ({restpct("Lung CD8 TRM, d25")} of young {ref(restid("Lung CD8 TRM, d25"))}) | Not in blood; nasal-tissue TRM only in research settings | Mechanistic; not a clinical biomarker |')
W(f'| DC CD40/CD86, d3 (S02-D) | {MNe("S02-D CD40")} (CD40) {ref(V[("trio","S02-D CD40","","")]["mn"][1])} | Yes — largest gap ({restpct("MLN DC CD40+, day 3")}–{restpct("MLN DC CD86+, day 3")} of young {ref(restid("MLN DC CD40+, day 3"))}, {ref(restid("MLN DC CD86+, day 3"))}) | Not practical | A development lever (formulation), not a biomarker |')
W('| Mucosal (nasal/BAL) IgA | **Not measured anywhere in the dataset** | — | Nasal IgA by nasosorption or wash | Mandatory addition for an intranasal product |')
W()
W('**Ruled out as biomarkers:** the Tfh:Tfr ratio (S04-B) is an arithmetic transform of the Foxp3 percentage, (100 − Foxp3%)/Foxp3%, in every animal (I-18) — it contains '
  'no Tfh measurement, and the Tfr suppression it reflects is gone by day 30 in aged mice; the IgG2a/IgG1 quotients as printed in S03-B/F are mislabelled (I-04); '
  'challenge weight loss (recycled, I-02); alveolar macrophage and neutrophil kinetics (duplicated, I-03).')
W()
W('**Could the biomarkers go into patients, and in what role?** Yes, all of the carried-forward markers are measurable in a Phase 1 trial: (i) nasal/blood '
  'interferon signature at 6–48 h to confirm target engagement and choose the dose (the Mn²⁺ effect is precisely a higher IFN-β ceiling at equal CDN dose); '
  '(ii) the same signature at 72 h–7 d plus TNF/IL-6/CRP as the older-adult safety marker (aged mice resolve more slowly); (iii) day-7 circulating ICOS+ Tfh as the '
  'earliest read on the antibody arm; (iv) HAI/MN at day 28 as the primary immunogenicity endpoint; (v) NP/M1-specific CD8 IFN-γ responses and heterologous-strain MN '
  'as the breadth endpoints; (vi) nasal IgA as the mucosal endpoint. None except HAI/MN has regulatory standing as a surrogate; the CD8 marker earns a larger role only '
  'if the confirmatory challenge study shows it predicts protection in individual animals and CD8 depletion removes the heterosubtypic protection.')
W()

# ===================================================================================== 6. CLINICAL ROLE
W('# 6. Could PSLN-344 go into patients, and in what role?')
W()
W('**Not yet.** On the plan in Section 7, first-in-human is realistic around month 20–24, after Gates 1–4 and IND-enabling toxicology.')
W()
W('**The role the data support:** an intranasal (or inhaled — see below) mucosal adjuvant co-administered with inactivated influenza antigen for adults aged 65+, '
  'whose differentiating claims are **breadth** (heterosubtypic, including H5N1), **speed** (protection when challenged 2–3 days after a single dose: PR8 '
  f'{arm("S06-B","PSLN-344")} vs {arm("S06-B","PSLN-212")} {ref(surv("S06-B")[1])}; rgH5N1, vaccine + PSLN-344 {arm("S15-H","3d Vaccine+PSLN-344")} vs vaccine alone '
  f'{arm("S15-H","3d Vaccine")} {ref(V["s15h"][1])}; wild-type H5N1 {arm("S03-J","PSLN-344")} vs {arm("S03-J","PSLN-212")}, flagged '
  f'{ref(surv("S03-J")[1])}) and **mucosal immunity**. In order of readiness:')
W()
W('1. **First clinical role — mucosal add-on in older adults who also receive their licensed intramuscular vaccine.** Participants are not denied standard of care, '
  'the comparison (IM vaccine alone vs IM vaccine + intranasal antigen/PSLN-344) isolates the asset\'s incremental value, and the endpoints (nasal IgA, cross-reactive '
  'T cells, heterologous MN) are exactly what PSLN-344 claims to add. Lowest ethical and commercial barrier.')
W('2. **Strategic role — pandemic / pre-pandemic H5 vaccine component** (antigen-sparing, cross-clade, rapid onset), where older adults are a priority group and the '
  'regulatory path runs on immunogenicity. This is where the heterosubtypic and early-protection data matter most.')
W('3. **Stand-alone seasonal replacement for high-dose or MF59-adjuvanted vaccines** only if the aged-mouse head-to-head (Study P1) shows at least non-inferior '
  'homologous protection and superior heterosubtypic protection, and Phase 2 shows non-inferior HAI. Historically, intranasal inactivated vaccines struggle to match '
  'intramuscular serum HAI in people (external context), so this is the hardest claim.')
W()
W('**Roles ruled out by our data:** a stand-alone innate "nasal shield" (PSLN-344 without antigen protected 0/7); a young-adult indication (PSLN-212 already protects '
  'young mice completely, so there is no incremental value to show); the R848 co-formulations (S08-D: PSLN-212/R848 weight nadir '
  f'{V[("nadir","PSLN-212/R848")][0].split(" (")[0].replace("nadir mean ","")} with one animal lost by day 10 {ref(V[("nadir","PSLN-212/R848")][1])}).')
W()
W('**Translation risks that decide the clinical design:**')
W()
W('- *Deposition.* The design rationale — surfactant mimicry, AECII and SP-A/D-dependent macrophage uptake — is alveolar. Mouse intranasal instillation reaches the '
  'lung; a human nasal spray mostly does not. Either efficacy survives upper-airway-restricted dosing in animals (Study P4), or the product needs an inhaled device, '
  'which changes the safety profile (deep-lung IFN in older adults, some with COPD).')
W('- *Antigen format.* Whole-virus antigen was used throughout; the clinical antigen must be tested (Section 4e).')
W(f'- *Mn²⁺ exposure.* No Mn²⁺ content was reported for the formulation, so the human Mn²⁺ dose per vaccination is unknown. A lower PSLN-344 dose may suffice: at 10 µg the '
  f'lung IFN-β response already equals 40 µg PSLN-212 {ref(V["dose_344_10_vs_212_40"][1])}.')
W(f'- *Reactogenicity in older adults.* Aged PSLN-344 lungs make {V[("cyt_y","Tnf")][0].split(" [")[0]} the TNF and {V[("cyt_y","Il10")][0].split(" [")[0]} the IL-10 of young PSLN-212 lungs at 16 h '
  f'for the same IFN-β {ref(V[("cyt_y","Tnf")][1])}, {ref(V[("cyt_y","Il10")][1])}, {ref(V[("cyt_y","Ifnb1")][1])}, and the IFN-β response resolves more slowly.')
W('- *Sex and pre-existing immunity.* All animals were female; older adults have decades of influenza exposure (the imprinting experiment is reassuring but used 14-month mice and a single prior infection).')
W()

# ===================================================================================== 7. FORWARD PLAN
# design numbers (simulation) registered for transparency
pw1 = RG.reg('power_surv', 'Design: power of the existing n = 7 per arm design', 'n=7/arm: 84% power for 90% vs 10% survival, 27% for 80% vs 30%, 7-8% for 80% vs 50% (two-sided Fisher, alpha 0.05)',
             'simulation (no workbook cells)', '6,000 binomial simulations per scenario; Fisher exact test two-sided')
pw2 = RG.reg('power_p1', 'Design: sample size for confirmatory survival and viral-load endpoints', 'survival 75% vs 20%: n=18-20/arm for >=90% power; lung titre 1.0 log10 reduction, SD 0.8: n=15/arm for 90% power; 0.7 log10: n=29/arm',
             'simulation / analytic (no workbook cells)', 'binomial simulation with Fisher exact test; two-sample t power (statsmodels)')
pw3 = RG.reg('power_ni', 'Design: benchmark non-inferiority on lung viral titre', 'margin 0.7 log10, SD 0.8 log10, one-sided alpha 0.025, 90% power: n = 28 per arm (margin 0.5 log10: n = 54)',
             'analytic (no workbook cells)', 'n = 2((z0.975 + z0.90) x SD / margin)^2')
W('# 7. What the next studies have to establish')
W()
W(f'Design principle: the existing experiments were small (n = 7 per arm gives 84% power for a 90%-vs-10% survival difference but only 27% for 80%-vs-30%) {ref(pw1)}. They '
  'detected the Mn²⁺ effect because it is huge; they cannot detect the smaller differences that matter next (PSLN-344 vs a licensed benchmark, aged vs young, a '
  'reduced dose). All new studies must be randomised, blinded at dosing, scoring and analysis, run in both sexes, use a pre-registered analysis plan and pre-defined '
  'humane endpoints, and store raw data in a controlled system. Study designs below draw on standard practice (external context); every data-derived input is cited.')
W()
W('## 7.1 Gates and kill criteria')
W()
W('| Gate | Decision it makes | Timing | Pass | Fail → action |')
W('|------------|--------------|--------|----------------------------------|--------------------------------|')
W('| G1 Data verification (P0) | Is the existing efficacy package real? | Weeks 0–8 | Source records confirm outcomes of ≥8 of the 10 primary survival experiments; root causes for I-01 to I-09 documented | Repeat pivotal survival work inside P1 before any other spend; if source records contradict the survival data, stop |')
W('| G2 Benchmarked efficacy (P1) | Is the effect reproducible and better than standard of care? | Month 9 | PSLN-344 minus PSLN-212 survival ≥ +40 points (lower 95% bound > +15) with the clinical antigen format; ≥1 log10 lung-titre reduction vs antigen alone; heterosubtypic protection non-inferior to the best IM benchmark | If not reproducible → stop. If reproducible but not better than the IM benchmark → pandemic/mucosal-booster niche only |')
W('| G3 Mn²⁺ CNS safety (P5) | Is intranasal Mn²⁺ acceptable for older adults? | Month 10 | No Mn²⁺ accumulation above vehicle in olfactory bulb/striatum at 3× the intended human-equivalent dose; no olfactory or neurobehavioural deficit; NOAEL ≥10× intended dose | Switch to a lower dose or inhaled route and re-test; if Mn²⁺ accumulates at any effective dose → stop |')
W('| G4 Translation (P4) | Does efficacy survive human-relevant delivery and antigen? | Month 7 | Protection retained with upper-airway-restricted dosing (or an inhaled route is viable) and with split/subunit antigen | Redesign route/antigen before IND-enabling work |')
W('| Redesign trigger (P1) | Is the CDN needed? | Month 9 | Mn²⁺-only liposome gives <50% of the PSLN-344 effect | If Mn²⁺ alone gives most of the effect → simplify the product (not a kill) |')
W()
W('## 7.2 Studies')
W()
STUDIES = [
 ('P0. Source-data verification and quality root-cause review (Gate 1)',
  [('Must establish', 'That the survival outcomes and key immunogenicity values in the workbook match the primary records, and why copies, relabelling and recycling occurred.'),
   ('Population / material', 'All blocks; priority: S03-I, S03-J, S06-A to S06-G, S15-H/L/N, S03-B/F, S11-A/B, S13-F/G, all S15 weights, S06 "Untreated" arms.'),
   ('Comparators', 'Workbook values vs primary records (daily clinical/weight sheets, humane-endpoint and euthanasia logs, cage cards, necropsy, FCS files, qPCR Ct exports, ELISA/HAI plate reads), colony health reports for the 20-month cohorts.'),
   ('Endpoints / readouts', 'Reconciliation status per block (confirmed / corrected / unverifiable); documented humane endpoint; randomisation and blinding records; explanation of the 4/21 deaths in unchallenged controls.'),
   ('Timing', 'Weeks 0–8, before any new animal work is committed.')]),
 ('P1. Confirmatory, benchmarked efficacy in aged mice (Gate 2)',
  [('Must establish', 'That the Mn²⁺ effect reproduces under blinded, randomised conditions with the clinical antigen format, and how PSLN-344 compares with what older adults get today.'),
   ('Population', 'Aged (20–22 months) female and male BALB/c and C57BL/6 (C57BL/6 allows H-2Db NP366 tetramers); young (8–10 weeks) PSLN-212 reference.'),
   ('Arms / comparators', 'Clinical-format split or recombinant HA antigen (whole-inactivated virus in a bridging arm) intranasally with: (1) empty liposome; (2) PSLN-212 20 µg; (3) PSLN-344 20 µg; '
    '(4) PSLN-344 10 µg; (5) Mn²⁺-only liposome at the PSLN-344 Mn²⁺ content; (6) PSLN-344 without antigen. Intramuscular benchmarks: (7) antigen + squalene oil-in-water emulsion (MF59-type); '
    '(8) high-dose antigen (4× HA). (9) Young + PSLN-212.'),
   ('Primary endpoints', 'Survival to day 14 after lethal challenge under a pre-specified humane endpoint; co-primary lung viral titre (TCID50) on days 3 and 5 in parallel sublethal cohorts.'),
   ('Challenges', 'Homologous CA09 H1N1; heterosubtypic H3N2 and rgH5N1; at day 3 (onset), day 14 and day 90 (durability) after a single dose.'),
   ('Secondary readouts (pre-challenge, same animals)', 'Serum HAI/MN against vaccine and heterologous strains; nasal-wash and BAL IgA; NP-specific CD8 T cells in blood and lung (tetramer/ICS, intravascular labelling for TRM); '
    'circulating ICOS+PD-1+CXCR5+ Tfh at day 7; nasal-wash IFN-β, CXCL10, GM-CSF, TNF, IL-6 at 16–36 h; weight-loss AUC and clinical score.'),
   ('Prioritised matrix', 'Aged mice are scarce, so not every arm meets every challenge. Core (all challenges, both strains): arms 1, 2, 3, 5, 7. Arms 4, 6, 8 and 9: '
    'day-14 heterosubtypic challenge and the day-3 onset challenge only. C57BL/6 replicates the core contrasts; BALB/c carries the full matrix.'),
   ('Size', f'Survival is powered for the Mn²⁺ contrast: 18–20 per arm per challenge (≥90% power for 75% vs 20%); lung titre 15 per arm detects a 1 log10 reduction '
    f'(SD 0.8, 90% power) {ref(pw2)}. The benchmark comparison is powered on day-3 lung titre, not survival: non-inferiority with a 0.7-log10 margin needs about 28 per arm '
    f'{ref(pw3)}. Blocked randomisation by sex and cage.'),
   ('Timing', 'Dosing months 2–3; day-3/14 challenges months 3–4; day-90 challenges month 6; read-out month 8–9.')]),
 ('P2. Mechanism of protection (runs alongside P1)',
  [('Must establish', 'Which effector carries protection — this decides the clinical efficacy biomarker.'),
   ('Population', 'Aged mice vaccinated with PSLN-344 + antigen (P1 conditions).'),
   ('Arms / comparators', 'Before challenge: anti-CD8β depletion; anti-CD4 depletion; anti-CD20 B-cell depletion; FTY720 at challenge (resident vs recruited T cells); isotype controls. '
    'Passive transfer of immune serum, or purified CD8 T cells, into naive aged recipients. At vaccination: IFNAR blockade; CCR2 antagonist; PSLN-212 + GM-CSF (does GM-CSF substitute for Mn²⁺ for survival?); '
    'PSLN-344 + CD40 agonist (does fixing the costimulation bottleneck close the gap to young?).'),
   ('Primary endpoints', 'Survival and lung viral titre after homologous and heterosubtypic challenge.'),
   ('Decision rule', 'An effector whose removal abolishes ≥50% of protection, and whose transfer confers protection, becomes the clinical efficacy biomarker.'),
   ('Timing', 'Months 4–10.')]),
 ('P3. Biomarker validation (embedded in P1/P2)',
  [('Must establish', 'That a pre-challenge measurement predicts protection in the individual animal.'),
   ('Design', 'Pre-challenge samples from every challenged animal; add a partially protective arm (PSLN-344 5 µg) so outcomes vary; ~40–60 animals with mixed outcomes per challenge type.'),
   ('Candidates', 'HAI/MN; nasal IgA; blood NP-specific CD8 IFN-γ; day-7 circulating Tfh; 16–36 h nasal IFN-β/CXCL10 (PD).'),
   ('Endpoints / readouts', 'Logistic and Cox models of survival and viral titre on each marker; ROC AUC with bootstrap CI; pre-specified threshold.'),
   ('Decision rule', 'AUC ≥0.8 plus mechanistic support from P2 → carry into Phase 1 as the efficacy biomarker.'),
   ('Timing', 'Read-out with P1 (month 9).')]),
 ('P4. Route / deposition and antigen format (Gate 4)',
  [('Must establish', 'Whether efficacy needs alveolar deposition (as in mouse instillation) or survives upper-airway-restricted dosing like a human nasal spray; and whether it survives split/subunit antigen.'),
   ('Population', 'Aged (20–22 months) BALB/c, both sexes; young reference arm.'),
   ('Arms / comparators', 'Low-volume (≈5 µL) awake intranasal dosing (nasal-restricted) vs standard volume under anaesthesia (whole respiratory tract) vs aerosol; whole-virus vs split vs recombinant HA; '
    'each with PSLN-344 and with PSLN-212 as the Mn-free comparator.'),
   ('Endpoints / readouts', 'Deposition imaging of labelled liposome; nasal vs lung Ifnb1; HAI, nasal IgA, CD8; survival after heterosubtypic challenge.'),
   ('Timing', 'Months 2–7.')]),
 ('P5. Mn²⁺ biodistribution and neurotoxicity (Gate 3)',
  [('Must establish', 'Whether intranasal Mn²⁺ reaches and accumulates in the CNS at effective doses, especially in aged animals.'),
   ('Population', 'Aged and young rodents, both sexes.'),
   ('Arms / comparators', 'Vehicle; PSLN-212; PSLN-344 at 1×, 3×, 10× the intended dose; MnCl₂ at matched Mn²⁺; single and repeat dosing (3 doses, plus an annual-booster simulation).'),
   ('Endpoints / readouts', 'Mn²⁺ by ICP-MS in nasal turbinates, olfactory bulb, striatum/globus pallidus, cerebellum, lung, liver and blood at days 1, 7, 28, 90; Mn-enhanced T1 MRI; '
    'olfactory function (buried-food test); open field and rotarod; histopathology of olfactory epithelium, olfactory bulb and facial nerve; olfactory-bulb Ifnb1/Tnf/Isg15 from 6 h to 7 d (extends S10-A, which sampled only "CNS" at 36 h).'),
   ('Timing', 'Months 2–10 (non-GLP design that anticipates the GLP study).')]),
 ('P6. CMC and formulation',
  [('Must establish', 'A defined, stable, releasable product, and the Mn²⁺ dose per human vaccination.'),
   ('Material / comparators', 'Three PSLN-344 lots vs PSLN-212 (Mn-free) and Mn²⁺-only liposome reference lots.'),
   ('Readouts', f'Mn²⁺ content and Mn:CDN ratio; CDN encapsulation (currently {V["ee_344"][0]} {ref(V["ee_344"][1])}, target ≥80%) and free CDN;'
    ' particle size, PDI, zeta potential; lyophilised stability at −20 °C and 2–8 °C (0, 1, 3, 6, 12 months); '
    'cell-based IFN-β/ISG potency assay aligned with the PD biomarker; endotoxin; sterility; anti-PEG (DPPE-PEG2000) immunogenicity plan for annual dosing.'),
   ('Timing', 'Months 0–12; release specifications and 6-month stability before GLP toxicology.')]),
 ('P7. Second-species efficacy: ferret',
  [('Must establish', 'Protection in the standard influenza transmission model with human-like airway receptor distribution.'),
   ('Population', 'Adult and, if obtainable, aged ferrets.'),
   ('Arms / comparators', 'Antigen alone; antigen + PSLN-344 intranasal; IM benchmark (MF59-type emulsion).'),
   ('Endpoints / readouts', 'Nasal-wash viral shedding AUC (days 1–7), clinical score, temperature, transmission to naive contacts, HAI/MN, nasal IgA; H3N2/H1N1 and H5N1 (BSL-3).'),
   ('Timing', 'Months 8–16, after G1–G2.')]),
 ('P8. IND-enabling GLP toxicology (only after G1–G4)',
  [('Population', 'Rat plus a second species agreed with the regulator (e.g. rabbit for intranasal), both sexes, with recovery groups.'),
   ('Arms / comparators', 'Vehicle; antigen alone; antigen + PSLN-344 at the clinical dose and at a multiple; repeat dosing (n+1 doses), intranasal or inhaled per P4.'),
   ('Endpoints / readouts', 'Clinical signs, body weight, haematology and clinical chemistry; nasal-cavity local tolerance at multiple levels; CNS and olfactory-bulb histopathology; tissue Mn²⁺; '
    'systemic cytokines and CRP; safety pharmacology (respiratory, CNS, cardiovascular).'),
   ('Timing', 'Months 10–20.')]),
 ('C1. First-in-human Phase 1 (from about month 20–24)',
  [('Design', 'Randomised, observer-blind, placebo-controlled dose escalation (3 PSLN-344 dose levels) with licensed split or recombinant antigen, via the route chosen in P4.'),
   ('Population', 'Part A: healthy adults 18–49 (sentinel dosing). Part B: adults 65–85, stratified 65–74 and 75–85. About 24–30 per dose cohort.'),
   ('Comparators', 'Intranasal antigen without adjuvant; placebo; open-label licensed IM older-adult vaccine (high-dose or MF59-adjuvanted) as immunogenicity reference.'),
   ('Primary endpoints', 'Safety: solicited nasal (congestion, rhinorrhoea, epistaxis, smell change) and systemic reactions days 0–7; unsolicited AEs to day 28; SAEs and AESIs to month 12, including facial palsy and '
    'olfactory dysfunction (validated smell test at baseline, day 7, 28, 180); neurological examination; blood Mn²⁺; brain MRI T1 pallidal index in a subset.'),
   ('Secondary / exploratory readouts', 'PD: nasal lining fluid IFN-β/IFN-λ/CXCL10/TNF/IL-6 and blood ISG score at 6 h, 24 h, 48 h, day 7. Immunogenicity: HAI/MN GMT and seroconversion at day 28 '
    '(vaccine and heterologous strains); nasal IgA days 14 and 28; circulating Tfh day 7; NP/M1 CD8/CD4 IFN-γ ELISpot day 14; durability at days 90, 180, 365.')]),
 ('C2/C3. Phase 2 and efficacy path',
  [('Timing', 'From about month 30, after Phase 1 safety and PD/immunogenicity read-outs.'),
   ('Phase 2', 'Adults ≥65 (several hundred): dose confirmation against the licensed IM comparator — HAI non-inferiority using CBER-style criteria (external context: upper 95% bound of the GMT ratio ≤1.5; '
    'seroconversion difference ≤10 points) plus superiority on nasal IgA and cross-reactive T-cell endpoints; in the add-on design, IM vaccine alone vs IM + intranasal PSLN-344.'),
   ('Efficacy signal', 'Controlled human influenza challenge in healthy adults 18–55 (viral shedding AUC, symptomatic infection) to show mucosal protection — older adults are ethically excluded; '
    'then immunobridging or field efficacy per regulatory advice. Pandemic track: H5 antigen ± PSLN-344, immunogenicity per pandemic criteria.')]),
]
for title, fields in STUDIES:
    W(f'**{title}**')
    W()
    for k, v in fields:
        W(f'- *{k}:* {v}')
    W()
W('## 7.3 Timeline summary')
W()
W('| Months | 0–2 | 2–9 | 9–10 | 10–20 | 20–24+ |')
W('|---|---|---|---|---|---|')
W('| Work | P0 verification; P6 CMC starts | P1, P2/P3, P4, P5 run in parallel | Gate review G2–G4 | P7 ferret; P8 GLP tox; GMP | C1 Phase 1 |')
W('| Decision | G1 | — | Advance to IND-enabling, redesign, or stop | IND | — |')
W()

# ===================================================================================== 8. RULED OUT
W('# 8. What I considered and ruled out')
W()
W('| Considered | Evidence | Conclusion |')
W('|-------------------------|--------------------------------------------------|--------------------|')
RO = [
 ('PSLN-344 works because it delivers more CDN', f'Encapsulation {V["ee_344"][0]} vs {V["ee_212"][0]} {ref(V["ee"][1])}', 'Ruled out'),
 ('PSLN-212 was simply under-dosed', f'PSLN-212 plateaus: 20 µg gives {V["dose_212_20_vs_40"][0].split("; ratio ")[1].split(";")[0]}× the 40 µg response {ref(V["dose_212_20_vs_40"][1])}; Emax {V[("emax","PSLN-212")][0].split(" (")[0].replace("Emax ","")} vs {V[("emax","PSLN-344")][0].split(" (")[0].replace("Emax ","")} {ref(V[("emax","PSLN-212")][1])}', 'Ruled out'),
 ('Mn²⁺ improves epithelial targeting', 'S08-C labels conflict with S01-B (I-10)', 'Not supported either way'),
 ('Effect is specific to one mouse strain or one challenge', f'Replicated in C57BL/6 and Swiss Webster {ref(surv("S15-L")[1])}, {ref(surv("S15-N")[1])}; four viruses; d2–d60', 'Ruled out'),
 ('Protection is an innate antiviral state', f'PSLN-344 without antigen 0/7 {ref(V["s15h"][1])}', 'Ruled out'),
 ('HA-neutralising antibody explains all protection', f'Protection against HA-mismatched viruses in S06-A/B/C/E/F/G ' + ', '.join(ref(surv(x)[1]) for x in ['S06-A','S06-B','S06-C','S06-E(d60)','S06-F(d60)','S06-G']) + f' and S15-H {ref(V["s15h"][1])}', 'Ruled out as sole mechanism'),
 ('NK cells mediate the effect', f'S11-D, PSLN-344 vs PSLN-212: day 2 {V[("nk","2")][0].split(";")[0]}, p={V[("nk","2")][2].welch_p:.2g}; day 4 {V[("nk","4")][0].split(";")[0]}, p={V[("nk","4")][2].welch_p:.2g}; none at days 6–8 {ref(V[("nk","2")][1])}, {ref(V[("nk","4")][1])}, {ref(V[("nk","6")][1])}, {ref(V[("nk","8")][1])}', 'Not supported'),
 ('Prior influenza exposure blunts PSLN-344', f'Imprinted vs naive 14-month mice: 6/7 vs 6/7 in both challenges {ref(V[("imp","S06-E(imprint)")][1])}, {ref(V[("imp","S06-F(imprint)")][1])}', 'Ruled out (in 14-month mice, one prior infection)'),
 ('PSLN-344 fully restores youthful immunity', f'Survival 51/63 vs 62/63 {ref(V["pool_young_primary"][1])}; CD40/CD86 29–38% of young; CD8 59–80%', 'Ruled out: partial restoration'),
 ('"No difference vs young" in single experiments proves equivalence', f'n = 7 has 27% power for 80% vs 30% {ref(pw1)}; pooling reveals a 17-point gap', 'Ruled out as an inference'),
 ('Tfh:Tfr ratio as biomarker', 'Algebraic transform of Foxp3% (I-18); effect gone by day 30', 'Ruled out'),
 ('PSLN-344 is Th2-skewed (from S03-B/F as printed)', f'Labels rotated (I-04); raw subclass titres give IgG2a/IgG1 {sA["PSLN-344"][0].split(" [")[0]} vs {sA["PSLN-212"][0].split(" [")[0]} (PSLN-212) {ref(sA["PSLN-344"][1])}', 'Ruled out — the opposite is true'),
 ('HAI ≥1:40 as a protective threshold', f'PSLN-212 ≥1:40 in 5/5 yet 0/7 survived {ref(V[("hai40","S03-C")][1])}', 'Ruled out in this model'),
 ('Alveolar macrophage / neutrophil kinetics', 'S11-A/B share 35/100 values (I-03)', 'Excluded'),
 ('Day-3 rgH5N1 protection as shown in S06-D', 'Copy of S06-C (I-01)', 'Excluded; rapid onset rests on S06-B, S15-H and (flagged) S03-J'),
 ('Morbidity (weight-loss) benefit after challenge', 'Weights recycled across experiments; dead animals carried forward (I-02, I-08)', 'Not claimed'),
 ('Antigen-specific CD8 kinetics (NP tetramer, S05-A/B)', 'n = 2 of stated 3; OVA vs vaccine contradiction; H-2Db epitope in BALB/c (I-09)', 'Excluded'),
 ('Macrophage transfer and Tregs (S07-C)', 'Both columns carry the same label (I-11)', 'Excluded'),
 ('Ly6C+CCR2+ macrophage counts (S07-A)', 'n = 3; absolute counts are LOWER with PSLN-344 than PSLN-212 while monocyte frequency (S01-D) is higher — different gates and units; one reading is that Mn²⁺ diverts monocytes from a macrophage to a DC fate, but n = 3 cannot carry it', 'Not used for conclusions'),
 ('S09-A second cytokine panel; S08 unlabelled region; "PSLN-344/R848"', 'Timepoint mislabelled; unattributable; undefined material (I-12, I-17, I-14)', 'Excluded'),
 ('Standalone innate prophylactic role', f'0/7 without antigen {ref(V["s15h"][1])}', 'Ruled out'),
 ('Young-adult indication', f'PSLN-212 already 8/8 in young mice in all three young challenge experiments {ref(V[("young","S09-B")][1])}, {ref(V[("young","S09-D")][1])}, {ref(V[("young","S09-F")][1])}', 'Ruled out'),
 ('R848 co-formulations (PSLN-212/R848, PSLN-R848)', f'Ifnb1 16 h {V["r848_ifn"][0]} vs PSLN-344 {Gv("S01-A","PSLN-344","Ifnb1","16h")} {ref(V["r848_ifn"][1])}; Tnf 16 h log10 {V["r848_tnf"][0].split(" ±")[0]} vs {V["r848_tnf_344"][0].split(" ±")[0]} (highest of all arms) {ref(V["r848_tnf"][1])}, {ref(V["r848_tnf_344"][1])}; weight nadir 90% with one animal lost {ref(V[("nadir","PSLN-212/R848")][1])}', 'Ruled out'),
 ('cGAMP liposome (CMP-204)', f'IgG GMT {Gv("S03-A","CMP-204")} vs PSLN-212 {Gv("S03-A","PSLN-212")} {ref(Gid("S03-A","CMP-204"))}; HAI GMT {Gv("S03-C","CMP-204")} vs {Gv("S03-C","PSLN-212")} {ref(Gid("S03-C","CMP-204"))}; survival 3/7 vs PSLN-344 7/7 {ref(surv("S03-I")[1])}', 'Ruled out'),
 ('Arithmetic means for titres; HAI "0" as zero; counting carried-forward dead animals in weight means', 'Titres are log-normal; 0 means below the 1:10 starting dilution; I-08', 'Ruled out as analysis choices'),
 ('Dropping the asset now', 'The Mn²⁺ effect survives every exclusion; the open questions are answerable in ~9–12 months', 'Not recommended (see Section 9 for the case if the committee disagrees)'),
]
for a, b, c in RO:
    W(f'| {a} | {b} | {c} |')
W()

# ===================================================================================== 9. IF DROPPED
W('# 9. If the committee drops PSLN-344: what we would be dropping, and why')
W()
W('**What we would be dropping.** The only asset in this dataset that reverses the aged-mouse survival deficit with a single intranasal dose '
  f'({short_pool("pool_mn_primary")} over its Mn-free parent; {short_pool("pool_sham_primary")} over sham), brings aged HAI to near-young levels '
  f'({G("S03-C","PSLN-344")} vs young {G("S03-C","PSLN-212(Y)")}), protects against heterosubtypic and H5N1 challenge, and comes with a specific, testable mechanism '
  '(Mn²⁺ raises the ceiling of STING output → IFN-β and GM-CSF → monocyte-derived DCs) and a ready pharmacodynamic biomarker.')
W()
W('**Why dropping it would be defensible.** (1) *Evidence quality:* the package fails integrity checks that a partner or regulator would run in a day — a copied survival '
  'block, recycled body weights, rotated labels, irreconcilable weight/survival pairs, and unexplained deaths in unchallenged controls. (2) *Safety:* intranasal Mn²⁺ '
  'in older adults is an unquantified CNS risk with no data at all on Mn²⁺ exposure. (3) *Translation:* efficacy was shown with whole-virus antigen and lung-reaching '
  'instillation, neither of which maps onto a human nasal spray with split antigen. (4) *Competition:* there is no evidence it beats high-dose or MF59-adjuvanted vaccines.')
W()
W('**What to keep if it is dropped.** The finding that the aged defect sits at IFN-I/GM-CSF-driven monocyte-to-DC differentiation and DC costimulation (usable for other '
  'adjuvant programmes, e.g. GM-CSF or CD40-agonist combinations); the PD assay (IFN-β/ISG ceiling); and a data-governance fix, because the same process produced this package.')
W()
W('**Why I still recommend the conditional path instead.** Each of the four reasons to drop is answerable with bounded work (Gates G1–G4) costing far less than the '
  'IND-enabling package, and a pass on all four would leave us with a differentiated older-adult and pandemic-preparedness asset. A fail on G1 or G3 is a clean stop.')
W()

# ===================================================================================== APPENDICES
W('# Appendix A. Data-reduction rules')
W()
W('- **Unit of analysis:** the individual animal (per-animal values as stored). n is the number of values present, which is reported wherever it differs from the stated n.')
W('- **Titres** (ELISA endpoint, HAI, neutralisation) and **qPCR fold-changes** are log-normal: summarised as geometric means with 95% t-intervals on log10, compared as ratios of '
  'geometric means with Welch t-tests on log10. HAI values recorded as 0 (below the 1:10 starting dilution) are imputed as 5.')
W('- **Flow-cytometry percentages and encapsulation efficiency:** arithmetic mean ± SD; differences with 95% Welch intervals.')
W('- **S09-A** values are stored as log10 fold-change: means and differences are computed on the stored log10 values and reported as fold.')
W('- **IgG2a/IgG1:** computed per animal from S13 raw titres (S03-B/F quotients are mislabelled).')
W('- **Tests:** two-sided Welch t and exact Mann–Whitney for each pairwise contrast; Tukey HSD across all groups within a block (the annotation\'s stated method; on log10 for log-normal data). '
  'With n = 5 per group the smallest attainable exact Mann–Whitney p is 0.0079. No correction across blocks; effect sizes with intervals are the primary result.')
W('- **Survival:** survivors = animals with event 0; log-rank and Fisher exact per experiment; pooled across experiments by Mantel–Haenszel risk difference (Sato variance), '
  'stratified log-rank (R survival::survdiff with strata) and exact conditional CMH (R mantelhaen.test). S03!G46 (blank day, event 0) censored at day 21.')
W('- **"% of young":** ratio of geometric means (titres, qPCR) or of arithmetic means (% data) to young PSLN-212(Y); CI by Welch/delta method on the log scale.')
W('- **Body weight:** an animal is classed as dead when its weight is absent at later days or repeats identically for ≥3 consecutive trailing timepoints (carried forward). '
  'Post-vaccination reactogenicity (S08-D) uses each animal\'s minimum % of day-0 weight over days 2–10.')
W('- **Integrity screens:** (i) all pairs of groups across blocks for shared values; (ii) all pairs of animal weight trajectories for identical same-day values; (iii) shared '
  'high-precision fractional parts; (iv) survival vs weight blocks; (v) algebraic checks of derived quantities; (vi) stated vs observed n.')
W('- **Code:** all reductions are reproducible from the scripts in outputs/code (parse → statistics → register → report).')
W()
W('# Appendix B. Integrity log (all 19 findings)')
W()
for e in LOG:
    W(f"**{e['id']} — {e['severity']} — {e['blocks']}**")
    W()
    W(f"- *Cells:* {e['cells']}")
    W(f"- *Finding:* {e['finding']}")
    W(f"- *Evidence / test:* {e['evidence']}")
    W(f"- *Impact:* {e['impact']}")
    W(f"- *Handling:* {e['handling']}")
    W()
W('Screened and **not** flagged: shared values between HAI/neutralisation blocks (two-fold dilution series make coincidences expected); shared 1-decimal values near '
  'baseline (e.g. S01-E day 0); three shared near-1 qPCR values between S02-F sham 16 h and S08-A CMP-204 1 µg (coarse scale; coincidence plausible).')
W()
W('# Appendix C. How every block was used')
W()
W('| Block | Content | Use in this review | Issues |')
W('|----------------|--------------------------------|------------------------------|----------------|')
USAGE = [
 ('S01-A', 'Lung Ifnb1 16 h / 72 h, 8 formulations, aged and young', 'Used: innate signal, PD biomarker, restoration', '—'),
 ('S01-B', 'SRB uptake by AECII/AECI, liposomal vs free', 'Used: delivery', 'I-10 (conflicts with S08-C)'),
 ('S01-C', 'AM uptake, WT vs Sftpa1/d knockout', 'Used with caveat', 'I-16 (WT age not stated)'),
 ('S01-D / S01-E', 'Lung monocytes / CD11b+ DC, days 0–8', 'Used', '—'),
 ('S01-F / S01-G', 'Lung cDC1 / cDC2, 72 h', 'S01-F used; S01-G is its complement', '—'),
 ('S02-A to S02-E', 'DC migration, MLN DC, antigen+ DC, CD40/CD86, OT-I priming, PTX', 'Used', 'I-16 (PTX-arm adjuvant not stated)'),
 ('S02-F / S02-G / S02-H / S02-I', 'Gm-csf; GM-CSF rescue; IFNAR chimeras; CCR2 antagonist', 'Used: mechanism', '—'),
 ('S03-A, C, D, E, G, H', 'IgG, HAI, neutralisation, d14', 'Used', 'HAI 0 → 5'),
 ('S03-B / S03-F', 'IgG2a/IgG1 quotients', 'Excluded; recomputed from S13', 'I-04'),
 ('S03-I', 'Survival, homologous CA09', 'Used (primary set), flagged', 'I-05'),
 ('S03-J', 'Survival, wild-type H5N1 d2', 'Used (primary set), flagged', 'I-05, I-13'),
 ('S03-K / S03-L', 'GC B cells; Aicda/E47 (n = 3)', 'Used', '—'),
 ('S04-A / S04-B / S04-C / S04-D', 'Tfh ICOS split; Tfr; Tfh:Tfr; Tfr d30; lung Treg', 'Used except Tfh:Tfr', 'I-18'),
 ('S05-A / S05-B', 'NP366 tetramer kinetics', 'Excluded', 'I-09'),
 ('S05-C to S05-H', 'OT-I/PTX; Ki-67, GZMB, IFN-γ CD8 (d3, d14, d60)', 'Used', '—'),
 ('S05-I', 'Lung CD8 TRM d25', 'Used with caveat', 'I-09'),
 ('S06-A / S06-B / S06-F(d60)', 'Survival: PR8 d14, PR8 d3, rgH5N1 d60', 'Used; unflagged core set', 'S06-F: I-07 applies to control arm only'),
 ('S06-C', 'Survival: rgH5N1 d14', 'Used, minor flag', 'I-06'),
 ('S06-D', 'Survival: rgH5N1 d3', 'Excluded (copy of S06-C)', 'I-01'),
 ('S06-E(d60) / S06-G', 'Survival: PR8 d60 / Perth H3N2 d60', 'Used, flagged', 'I-06, I-07'),
 ('S06-E/F(imprint)', 'Survival after prior PR8 infection, 14-month mice', 'Used', 'I-15'),
 ('S07-A / S07-B / S07-C', 'Ly6C+CCR2+ macrophage counts; CCR2 antagonist; macrophage transfer', 'S07-B used; S07-A not used; S07-C excluded', 'I-11, I-16'),
 ('S08-A', 'Ifnb1 dose-response 1–40 µg', 'Used (PSLN-344/R848 arm excluded)', 'I-14'),
 ('S08-B', 'CDN encapsulation', 'Used (PSLN-R848 value not interpretable)', 'I-14'),
 ('S08-C', 'SRB uptake, PSLN vs PSLN-344', 'Not used', 'I-10'),
 ('S08-D', 'Post-vaccination body weight', 'Used with caveat (reactogenicity)', 'I-02'),
 ('S08 rows 89–101', 'Unlabelled', 'Excluded', 'I-17'),
 ('S09-A panel 1 / panel 2', 'Lung cytokine mRNA (log10)', 'Panel 1 used as 16 h; panel 2 excluded', 'I-12'),
 ('S09-B / D / F', 'Survival, young mice', 'Used', 'I-13 (S09-B/F counts)'),
 ('S09-C / E / G', 'Body weight, young mice', 'Cross-checks only', 'I-02, I-06'),
 ('S10-A', 'CNS Ifnb1/Tnf/Isg15 36 h', 'Used: safety, with sensitivity caveat', '—'),
 ('S11-A / S11-B', 'AM / neutrophils', 'Excluded', 'I-03'),
 ('S11-C / S11-D / S11-E', 'CBX; NK cells; CD206+ macrophages', 'Used (S11-E: timepoint not stated)', 'I-16'),
 ('S12-A', 'IFNAR-/- monocyte infiltration (n = 3, young)', 'Used (not significant)', '—'),
 ('S13-A to S13-D', 'IgG2a / IgG1 titres', 'Used (source for subclass ratio)', '—'),
 ('S13-E', 'Survival, young CA09', 'Used', 'I-13'),
 ('S13-F / S13-G', 'Body weight for S03-I / S03-J', 'Not used', 'I-05'),
 ('S13-H / S13-I / S13-J / S14-A', 'MLN IgG+ B cells; post-boost IgG; IFN-γ CD8', 'Used (S13-H, S14-A: timepoint not stated)', 'I-16'),
 ('S15 weight blocks (A–G, I, J, K, M, O)', 'Body weight after challenge', 'Cross-checks only', 'I-02, I-06, I-08'),
 ('S15-H', 'Survival: vaccine vs PSLN-344 vs both, d3', 'Used with caveat', 'I-02 (S15-I weights)'),
 ('S15-L / S15-N', 'Survival, aged C57BL/6 / Swiss Webster', 'Used (primary set), flagged', 'I-16; S15-L also I-06'),
]
for a, b, c, d in USAGE:
    W(f'| {a} | {b} | {c} | {d} |')
W()

# ===================================================================================== write
md = '\n'.join(OUT)
open('/tmp/outputs/PSLN-344_portfolio_recommendation.md', 'w').write(md)
print('markdown chars:', len(md), 'register entries:', len(RG.REG))
pd.DataFrame(RG.REG).drop(columns=['key']).to_csv('/tmp/work/register.csv', index=False)
import re as _re
cited = sorted(set(_re.findall(r'\[(N\d{3})\]', md)))
ids = set(r['id'] for r in RG.REG)
missing = [c for c in cited if c not in ids]
print('cited:', len(cited), 'missing from register:', missing)

suppressMessages(library(survival))
s <- read.csv('/tmp/work/survival_clean.csv', stringsAsFactors=FALSE)
sets <- list(primary = c('S03-I','S03-J','S06-A','S06-B','S06-C','S06-E(d60)','S06-F(d60)','S06-G','S15-L','S15-N'),
 unflagged = c('S06-A','S06-B','S06-F(d60)'), unflagged_plus_minor = c('S06-A','S06-B','S06-C','S06-F(d60)','S15-N'),
 primary_plus_S06D = c('S03-I','S03-J','S06-A','S06-B','S06-C','S06-D','S06-E(d60)','S06-F(d60)','S06-G','S15-L','S15-N'),
 heterosubtypic_BALBc = c('S06-A','S06-B','S06-C','S06-E(d60)','S06-F(d60)','S06-G'))
contr <- list(c('PSLN-344','PSLN-212'), c('PSLN-344','Sham'), c('PSLN-212','Sham'), c('PSLN-344','PSLN-212(Y)'))
out <- data.frame()
for (cc in contr) for (nm in names(sets)) {
  d <- subset(s, block %in% sets[[nm]] & group %in% cc); d$trt <- as.integer(d$group == cc[1])
  lr <- survdiff(Surv(time, event) ~ trt + strata(block), data=d)
  tab <- table(factor(d$trt, levels=c(1,0)), factor(1-d$event, levels=c(1,0)), d$block)
  tab <- tab[,, apply(tab, 3, function(m) all(rowSums(m)>0)), drop=FALSE]
  cm <- mantelhaen.test(tab, exact=TRUE)
  out <- rbind(out, data.frame(contrast=paste(cc, collapse=' vs '), analysis_set=nm, strata=dim(tab)[3], logrank_chisq=round(lr$chisq,2),
     logrank_p=signif(pchisq(lr$chisq,1,lower.tail=FALSE),3), exact_CMH_p=signif(cm$p.value,3), cond_MLE_OR=signif(cm$estimate,3),
     OR_lo=signif(cm$conf.int[1],3), OR_hi=signif(cm$conf.int[2],3)))
}
write.csv(out, '/tmp/work/surv_stratified_R.csv', row.names=FALSE); print(out)

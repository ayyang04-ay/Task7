import pandas as pd, numpy as np
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 200)
s = pd.read_csv('survival.csv'); w = pd.read_csv('bodyweight.csv')
pairs = {'S15-A':'S06-A','S15-B':'S06-B','S15-C':'S06-C','S15-D':'S06-D','S15-E':'S06-E(d60)','S15-F':'S06-F(d60)',
         'S15-G':'S06-G','S15-I':'S15-H','S15-J':'S06-E(imprint)','S15-K':'S06-F(imprint)','S15-M':'S15-L','S15-O':'S15-N',
         'S09-C':'S09-B','S09-E':'S09-D','S09-G':'S09-F','S13-F':'S03-I','S13-G':'S03-J'}
norm = lambda x: x.replace('Naïve','Naive').replace('PSLN-212Y','PSLN-212(Y)').replace('PSLN-344Y','PSLN-344(Y)').strip()
rows = []
for wb_, sb in pairs.items():
    W = w[w.block==wb_]
    maxday = W.day.max()
    for grp, d in W.groupby('group', sort=False):
        status = []
        for a, da in d.groupby('animal', sort=False):
            da = da.sort_values('day')
            vals = da.value.round(4).tolist(); days = da.day.tolist()
            # trailing identical run
            run = 1
            for i in range(len(vals)-1, 0, -1):
                if vals[i] == vals[i-1]: run += 1
                else: break
            if days[-1] < maxday:
                status.append(('missing', days[-1]))
            elif run >= 3:
                status.append(('frozen', days[len(vals)-run]))
            elif run == 2 and vals[-1] < 90:
                status.append(('frozen?', days[len(vals)-run]))
            else:
                status.append(('alive', None))
        n = len(status)
        died_w = sum(1 for st,_ in status if st in ('missing','frozen'))
        amb = sum(1 for st,_ in status if st=='frozen?')
        S = s[(s.block==sb)]
        S = S[S.group.apply(norm)==norm(grp)]
        n_s = len(S); died_s = int(S.event.sum()) if n_s else None
        rows.append(dict(weight_block=wb_, surv_block=sb, group=grp, n_weight=n, inferred_deaths=died_w, ambiguous_frozen2=amb,
                         n_surv=n_s if n_s else 'NO SUCH GROUP', deaths_surv=died_s,
                         detail=' '.join(f"{st}{'' if dd is None else '@'+str(int(dd))}" for st,dd in status)))
R = pd.DataFrame(rows)
R['consistent'] = R.apply(lambda r: (r.n_surv==r.n_weight) and (r.deaths_surv is not None) and (r.inferred_deaths <= r.deaths_surv <= r.inferred_deaths + r.ambiguous_frozen2), axis=1)
print(R.drop(columns=['detail']).to_string())
R.to_csv('bw_vs_surv.csv', index=False)
print()
for r in R[~R.consistent].itertuples():
    print(f'{r.weight_block} vs {r.surv_block} [{r.group}]: weights n={r.n_weight}, inferred deaths={r.inferred_deaths}(+{r.ambiguous_frozen2} ambiguous) | survival n={r.n_surv}, deaths={r.deaths_surv} || {r.detail}')

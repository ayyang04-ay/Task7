import pandas as pd, numpy as np
R = pd.read_csv('surv_contrasts.csv')
def mh_rd_sato(sub):
    W = 0; num = 0; SP = 0; SQ = 0
    for r in sub.itertuples():
        a, n1, c, n0 = r.s1, r.n1, r.s0, r.n0; N = n1+n0
        num += (a*n0 - c*n1)/N; W += n1*n0/N
    rd = num/W
    for r in sub.itertuples():
        a, n1, c, n0 = r.s1, r.n1, r.s0, r.n0; N = n1+n0
        P = (n1**2*c - n0**2*a + n1*n0*(n0-n1)/2)/N**2
        Q = (a*(n0-c) + c*(n1-a))/(2*N)
        SP += P; SQ += Q
    var = (rd*SP + SQ)/W**2
    se = np.sqrt(max(var,0))
    return rd, rd-1.96*se, min(rd+1.96*se, 1.0)
sets = {
 'Primary (10 aged expts; S06-D excluded as duplicate)': ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-E(d60)','S06-F(d60)','S06-G','S15-L','S15-N'],
 'Sens-A: unflagged blocks only (S06-A, S06-B, S06-F d60)': ['S06-A','S06-B','S06-F(d60)'],
 'Sens-B: unflagged + minor-flag blocks (adds S06-C, S15-N)': ['S06-A','S06-B','S06-C','S06-F(d60)','S15-N'],
 'Sens-C: primary + S06-D counted as independent': ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-D','S06-E(d60)','S06-F(d60)','S06-G','S15-L','S15-N'],
 'Sens-D: BALB/c d14-d60 heterosubtypic only': ['S06-A','S06-B','S06-C','S06-E(d60)','S06-F(d60)','S06-G'],
}
out=[]
for lab in ['PSLN-344 vs PSLN-212 (Mn effect)','PSLN-344 vs Sham','PSLN-212 vs Sham','aged PSLN-344 vs young PSLN-212(Y)']:
    for sname, blks in sets.items():
        sub = R[(R.contrast==lab)&(R.block.isin(blks))]
        if not len(sub): continue
        rd, lo, hi = mh_rd_sato(sub)
        out.append(dict(contrast=lab, analysis_set=sname, k=len(sub), survivors_trt=f'{sub.s1.sum()}/{sub.n1.sum()}', survivors_ctl=f'{sub.s0.sum()}/{sub.n0.sum()}',
                        MH_RD=round(rd,3), CI95_lo=round(lo,3), CI95_hi=round(hi,3), blocks=','.join(sub.block)))
O = pd.DataFrame(out); O.to_csv('surv_pooled_MH.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 70)
print(O.drop(columns=['blocks']).to_string())

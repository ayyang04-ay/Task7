import matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
fig, ax = plt.subplots(figsize=(15, 11.5)); ax.set_xlim(0, 100); ax.set_ylim(0, 100); ax.axis('off')
C = {'int':'#c8e6c9', 'assoc':'#bbdefb', 'gap':'#ffcdd2', 'out':'#fff9c4', 'none':'#eeeeee'}
E = {'int':'#2e7d32', 'assoc':'#1565c0', 'gap':'#c62828', 'out':'#f9a825', 'none':'#757575'}
def box(x, y, w, h, text, kind, fs=8.6):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.4,rounding_size=1.2', fc=C[kind], ec=E[kind], lw=1.6))
    ax.text(x+w/2, y+h/2, text, ha='center', va='center', fontsize=fs, wrap=True)
def arr(x1, y1, x2, y2, col='k'):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle='-|>', color=col, lw=1.4))
box(25, 91, 50, 6.5, 'PSLN-344 = CDN-1807 + Mn$^{2+}$ in DPPC/DPPG/DPPE-PEG/chol liposome; only difference from PSLN-212 is Mn$^{2+}$\n'
    'CDN encapsulation NOT higher: 54.8% vs 59.6% (S08-B)  ->  the gain is not "more CDN"', 'none')
box(3, 78, 30, 8.5, 'Uptake (PSLN-SRB / DiD liposome):\nAECII 15.8% vs AECI 3.8% (S01-B)\nAM uptake SP-A/D-dependent: 43.1% -> 12.7% (S01-C)\nMn effect on uptake unresolved (S08-C labels)', 'int')
box(37, 78, 27, 8.5, 'STING output (lung Ifnb1, 16 h)\n2.2x PSLN-212; = young (0.98x) (S01-A)\nEmax 55 vs 14; ED50 12 vs 9 ug (S08-A)\nstill 2.9x young at 72 h (S01-A)', 'assoc')
box(68, 78, 29, 8.5, 'Gap-junction dependence\ncarbenoxolone: recruited monocytes\n7.3% -> 3.1% (S11-C)\n(CBX is not gap-junction-specific)', 'int')
box(37, 63, 27, 9, 'GM-CSF (lung Gm-csf)\n4.2x / 5.4x / 2.6x PSLN-212 at 16/36/72 h\n(S02-F; no young comparator)', 'assoc')
box(3, 63, 30, 9, 'CCR2+ monocyte recruitment\nmonocytes d4: 30.6% vs 16.7%; young 32.2% (S01-D)\nCCR2 antagonist: 9.9% -> 3.3% (S07-B)', 'int')
box(68, 63, 29, 9, 'moDC differentiation\nIFNAR-dependent: 19.7% -> 2.1% (S02-H)\nGM-CSF rescues PSLN-212: 5.9% -> 13.8% (S02-G)\nand Ifnar-/- cells: 2.1% -> 12.4% (S02-H)', 'int')
box(68, 47, 29, 10, 'DC migration to MLN\nCCR7+ DC 30.7% vs 7.3%; young 35.0% (S02-A)\nPTX (Gi block): antigen+ MLN DC\n7.1% -> 2.4% (S02-C)', 'int')
box(37, 47, 27, 10, 'DC quality  [NOT RESTORED]\nCD40+ 11.2% vs young 38.7% (29%)\nCD86+ 14.5% vs young 37.9% (38%) (S02-D)\nOT-I priming 18.7% vs young 26.2% (S02-E)', 'gap')
box(3, 47, 30, 10, 'Regulatory brake released (partly)\nTfr d7: 10.8% vs 26.7% (PSLN-212), young 7.1%\nTfr d30 rebounds: 14.0% vs young 7.4% (S04-C)\nlung Treg 3.0 vs 6.7% (S04-D, n=3)', 'assoc')
box(3, 29, 44, 12, 'Humoral arm  [largely restored]\nICOS-hi Tfh 10.3% (75% of young); GC B 6.5% (67%) (S04-A, S03-K)\nHAI H1N1 GMT 368 vs 46 (PSLN-212) vs 485 (young) (S03-C)\nNeut H1N1 GMT 3,840 vs 418 vs 6,686 (S03-D)\nIgG2a/IgG1 GM 1.85 vs 0.54 vs 2.50 (S13-A/B)', 'assoc', fs=8.4)
box(53, 29, 44, 12, 'CD8 T-cell arm  [partially restored]\nMLN IFN-g+ CD8 (H5 restim) d14 6.4% vs 1.5% vs young 9.2% (69%) (S05-F)\nsame at d60: 9.9% vs 3.0% vs 14.4% (69%) (S05-G)\nlung TRM d25: 4.0% vs 1.0% vs 6.0% (66%) (S05-I)\nCCR2 blockade cuts lung GZMB+ CD8 6.8% -> 1.4% (young, S02-I)', 'assoc', fs=8.4)
box(3, 11, 44, 12, 'Homologous protection  [fully restored]\nCA09 10xLD50 d14: PSLN-344 7/7, PSLN-212 0/7, young 7/7 (S03-I)\n-> consistent with HA-neutralising antibody\n(restored to 76-87% of young HAI, n.s.)', 'out', fs=8.6)
box(53, 11, 44, 12, 'Heterosubtypic protection  [partially restored]\nd14: 13/14 vs young 14/14; d3: 5/7 vs 7/7;\nd60: 14/21 vs young 21/21 (p=0.009) (S06)\n-> HA-mismatched, so not explained by HAI; tracks the\nresidual CD8 deficit (59-80% of young)', 'out', fs=8.6)
box(3, 0.5, 94, 6.5, 'Antigen is required: PSLN-344 alone 0/7, vaccine alone 0/7, vaccine + PSLN-344 6/7 (S15-H, challenge 3 d after dosing) -> not an innate antiviral state.\n'
    'Causality gap: no depletion, passive-transfer or knockout experiment links ANY pathway step to survival. Antigen is formalin-inactivated WHOLE virus (contains NP/M1 for CD8 epitopes).', 'none', fs=8.6)
for (x1,y1,x2,y2) in [(50,91,50,86.9),(33,82,37,82),(50,78,50,72.4),(44,78,25,72.4),(64,67.5,68,67.5),(82.5,63,82.5,57.4),(68,52,64,52),
                      (46,47,25,41.4),(55,47,75,41.4),(18,47,18,41.4),(25,47,68,41.4),(25,29,25,23.4),(75,29,75,23.4)]:
    arr(x1,y1,x2,y2)
ax.annotate('', xy=(74, 62.4), xytext=(26, 62.4), arrowprops=dict(arrowstyle='-|>', color='k', lw=1.4, connectionstyle='arc3,rad=0.09'))
ax.plot([64, 68], [82, 82], ls='--', color='#757575', lw=1.2)
for k, lab, xx in [('int','cellular intervention tested (causal at pathway level)',3),('assoc','association / group comparison only',33),('gap','NOT restored in aged mice',55),('out','survival outcome',72)]:
    ax.add_patch(FancyBboxPatch((xx, -4.2), 2.2, 2.2, boxstyle='round,pad=0.2', fc=C[k], ec=E[k])); ax.text(xx+3, -3.1, lab, fontsize=8.5, va='center')
ax.set_ylim(-5, 99)
ax.set_title('What drives PSLN-344 protection in aged mice: evidence map (all numbers: aged PSLN-344 vs aged PSLN-212 vs young PSLN-212(Y) unless stated)', fontsize=11)
plt.tight_layout(); plt.savefig('/tmp/outputs/figures/fig5_mechanism_map.png', dpi=150); print('ok')

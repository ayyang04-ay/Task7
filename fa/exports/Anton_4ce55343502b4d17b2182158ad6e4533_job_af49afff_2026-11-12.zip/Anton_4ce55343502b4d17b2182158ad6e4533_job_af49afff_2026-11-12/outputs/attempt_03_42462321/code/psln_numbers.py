"""Compute + register every number cited in the report. Produces dict V: key -> (text, id)."""
import sys
sys.path.insert(0, '/tmp/work')
import pandas as pd, numpy as np
from scipy import stats
from scipy.stats import fisher_exact
import register as R
from register import reg, compress, g, contrast, fmt_num, survcells, surv_arm

V = {}
s = R.s; m = R.m; SC = R.SC; SP = R.SP; RS = R.RS

SURV_METH = ('survivors = animals with event 0 (censored at end of follow-up); one row per animal; S03!G46 (blank day, event 0) '
             'treated as censored at day 21')

# ---------------------------------------------------------------- survival: pooled
PRIMARY = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-E(d60)', 'S06-F(d60)', 'S06-G', 'S15-L', 'S15-N']
UNFLAG = ['S06-A', 'S06-B', 'S06-F(d60)']
SENSB = ['S06-A', 'S06-B', 'S06-C', 'S06-F(d60)', 'S15-N']


RSTRAT = pd.read_csv('/tmp/work/surv_stratified_R.csv')
_RMAP = {'Primary (10 aged expts; S06-D excluded as duplicate)': 'primary', 'Sens-A: unflagged blocks only (S06-A, S06-B, S06-F d60)': 'unflagged',
         'Sens-B: unflagged + minor-flag blocks (adds S06-C, S15-N)': 'unflagged_plus_minor', 'Sens-C: primary + S06-D counted as independent': 'primary_plus_S06D'}
_CMAP = {'PSLN-344 vs PSLN-212 (Mn effect)': 'PSLN-344 vs PSLN-212', 'PSLN-344 vs Sham': 'PSLN-344 vs Sham', 'PSLN-212 vs Sham': 'PSLN-212 vs Sham',
         'aged PSLN-344 vs young PSLN-212(Y)': 'PSLN-344 vs PSLN-212(Y)'}


def _sci(x):
    if x >= 0.001:
        return f'{x:.2g}'
    mant, ex = f'{x:.1e}'.split('e')
    return f'{mant}e{int(ex)}'


def pooled(contrast_label, setname, blocks, g1, g0, key, stat_text=None):
    p = SP[(SP.contrast == contrast_label) & (SP.analysis_set == setname)].iloc[0]
    rr = RSTRAT[(RSTRAT.contrast == _CMAP[contrast_label]) & (RSTRAT.analysis_set == _RMAP[setname])].iloc[0]
    stat_text = f'stratified log-rank chi2 = {rr.logrank_chisq:.1f}, p = {_sci(rr.logrank_p)}; exact CMH p = {_sci(rr.exact_CMH_p)}'
    cells = []
    for b in blocks:
        cells += survcells(b, [g1, g0])
    txt = f'{p.survivors_trt} vs {p.survivors_ctl}; MH risk difference {p.MH_RD:+.2f} [{p.CI95_lo:+.2f}, {p.CI95_hi:+.2f}]' + (f'; {stat_text}' if stat_text else '')
    nid = reg(key, f'Pooled survival, {contrast_label}, {setname}', txt, compress(cells),
              SURV_METH + '; Mantel–Haenszel risk difference across experiments with Sato variance; stratified log-rank (R survival::survdiff, strata = experiment); '
              'exact conditional CMH test on 14-day survival (R mantelhaen.test, exact=TRUE)')
    V[key] = (txt, nid)
    return p


pooled('PSLN-344 vs PSLN-212 (Mn effect)', 'Primary (10 aged expts; S06-D excluded as duplicate)', PRIMARY, 'PSLN-344', 'PSLN-212', 'pool_mn_primary',
       'stratified log-rank chi2 = 82.7, p = 9.4e-20; exact CMH p = 1.9e-19')
pooled('PSLN-344 vs PSLN-212 (Mn effect)', 'Sens-A: unflagged blocks only (S06-A, S06-B, S06-F d60)', UNFLAG, 'PSLN-344', 'PSLN-212', 'pool_mn_unflag',
       'stratified log-rank chi2 = 24.4, p = 7.9e-7; exact CMH p = 3.6e-5')
pooled('PSLN-344 vs PSLN-212 (Mn effect)', 'Sens-B: unflagged + minor-flag blocks (adds S06-C, S15-N)', SENSB, 'PSLN-344', 'PSLN-212', 'pool_mn_sensB',
       'stratified log-rank chi2 = 34.8, p = 3.7e-9; exact CMH p = 5.4e-8')
pooled('PSLN-344 vs PSLN-212 (Mn effect)', 'Sens-C: primary + S06-D counted as independent', PRIMARY + ['S06-D'], 'PSLN-344', 'PSLN-212', 'pool_mn_sensC',
       'stratified log-rank p = 2.3e-21')
pooled('PSLN-344 vs Sham', 'Primary (10 aged expts; S06-D excluded as duplicate)', PRIMARY, 'PSLN-344', 'Sham', 'pool_sham_primary',
       'stratified log-rank chi2 = 134.3, p = 4.8e-31')
pooled('PSLN-212 vs Sham', 'Primary (10 aged expts; S06-D excluded as duplicate)', PRIMARY, 'PSLN-212', 'Sham', 'pool_212sham_primary',
       'stratified log-rank chi2 = 35.1, p = 3.1e-9; exact CMH p = 0.015')
pooled('aged PSLN-344 vs young PSLN-212(Y)', 'Primary (10 aged expts; S06-D excluded as duplicate)', [b for b in PRIMARY if b != 'S03-J'], 'PSLN-344', 'PSLN-212(Y)', 'pool_young_primary',
       'stratified log-rank chi2 = 10.3, p = 0.0013; exact CMH p = 0.0023')
pooled('aged PSLN-344 vs young PSLN-212(Y)', 'Sens-A: unflagged blocks only (S06-A, S06-B, S06-F d60)', UNFLAG, 'PSLN-344', 'PSLN-212(Y)', 'pool_young_unflag',
       'stratified log-rank p = 0.021; exact CMH p = 0.053')

# ---------------------------------------------------------------- survival: per experiment
LAB = {'S03-I': 'CA09 H1N1 10×LD50, homologous, challenge d14', 'S03-J': 'wild-type VN04 H5N1, rgH5N1 vaccine, challenge d2',
       'S06-A': 'PR8 H1N1 5×LD50, heterosubtypic (Aichi H3N2 vaccine), d14', 'S06-B': 'PR8 H1N1, heterosubtypic, d3',
       'S06-C': 'rgH5N1 5×LD50, heterosubtypic (bivalent vaccine), d14', 'S06-D': 'rgH5N1, d3 (copy of S06-C)',
       'S06-E(d60)': 'PR8 H1N1, heterosubtypic, d60', 'S06-F(d60)': 'rgH5N1, heterosubtypic, d60', 'S06-G': 'Perth H3N2, heterosubtypic (CA09 vaccine), d60',
       'S15-L': 'aged C57BL/6, bivalent vaccine (challenge not stated)', 'S15-N': 'aged Swiss Webster, bivalent vaccine (challenge not stated)'}
FLAG = {'S03-I': 'I-05', 'S03-J': 'I-05, I-13', 'S06-A': '—', 'S06-B': '—', 'S06-C': 'I-06 (minor)', 'S06-D': 'I-01 (excluded)', 'S06-E(d60)': 'I-06, I-07',
        'S06-F(d60)': 'I-07 (control arm)', 'S06-G': 'I-06, I-07', 'S15-L': 'I-06, I-16', 'S15-N': 'I-16'}
rows = []
for b in ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E(d60)', 'S06-F(d60)', 'S06-G', 'S15-L', 'S15-N']:
    arms = {}
    for grp in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)', 'Untreated']:
        d = s[(s.block == b) & (s.group == grp)]
        if len(d):
            arms[grp] = f'{int((d.event == 0).sum())}/{len(d)}'
    c = SC[(SC.block == b) & (SC.contrast == 'PSLN-344 vs PSLN-212 (Mn effect)')].iloc[0]
    txt = '; '.join(f'{k} {v}' for k, v in arms.items()) + f' | PSLN-344 vs PSLN-212 Fisher p={c.fisher_p:.2g}, log-rank p={c.logrank_p:.2g}'
    nid = reg(('surv', b), f'14-day survival, {b} ({LAB[b]})', txt, compress(survcells(b, list(arms))), SURV_METH + '; Fisher exact (two-sided) and log-rank (lifelines) per experiment')
    V[('surv', b)] = (txt, nid)
    rows.append(dict(block=b, challenge=LAB[b], **{k: v for k, v in arms.items()}, fisher=c.fisher_p, logrank=c.logrank_p, flags=FLAG[b], nid=nid))
SURV_TABLE = pd.DataFrame(rows)

# by challenge type (aged PSLN-344 vs young)
cat_blocks = {'homologous d14': ['S03-I'], 'heterosubtypic d14': ['S06-A', 'S06-C'], 'heterosubtypic d3': ['S06-B'],
              'heterosubtypic d60': ['S06-E(d60)', 'S06-F(d60)', 'S06-G'], 'other backgrounds': ['S15-L', 'S15-N']}
CAT = []
for cat, bl in cat_blocks.items():
    out = {}
    for grp in ['PSLN-344', 'PSLN-212(Y)', 'PSLN-212', 'Sham']:
        ss = [surv_arm(b, grp) for b in bl]
        out[grp] = (sum(x[0] for x in ss), sum(x[1] for x in ss))
    a, b_ = out['PSLN-344'], out['PSLN-212(Y)']
    p = fisher_exact([[a[0], a[1] - a[0]], [b_[0], b_[1] - b_[0]]])[1]
    txt = f'aged PSLN-344 {a[0]}/{a[1]} vs young PSLN-212(Y) {b_[0]}/{b_[1]} (Fisher p={p:.2g}); aged PSLN-212 {out["PSLN-212"][0]}/{out["PSLN-212"][1]}; Sham {out["Sham"][0]}/{out["Sham"][1]}'
    cells = []
    for bb in bl:
        cells += survcells(bb, ['PSLN-344', 'PSLN-212(Y)', 'PSLN-212', 'Sham'])
    nid = reg(('cat', cat), f'Survival by challenge type: {cat} ({", ".join(bl)})', txt, compress(cells), SURV_METH + '; counts summed across listed experiments; Fisher exact two-sided')
    V[('cat', cat)] = (txt, nid)
    CAT.append(dict(category=cat, blocks=', '.join(bl), aged_344=f'{a[0]}/{a[1]}', young_212=f'{b_[0]}/{b_[1]}', aged_212=f'{out["PSLN-212"][0]}/{out["PSLN-212"][1]}',
                    sham=f'{out["Sham"][0]}/{out["Sham"][1]}', p_vs_young=p, nid=nid))
CAT = pd.DataFrame(CAT)

# S15-H antigen requirement
arms = {gname: surv_arm('S15-H', gname) for gname in ['3d Vaccine', '3d PSLN-344', '3d Vaccine+PSLN-344']}
txt = '; '.join(f'{k} {v[0]}/{v[1]}' for k, v in arms.items()) + '; Vaccine+PSLN-344 vs either single component Fisher p=0.0047'
V['s15h'] = (txt, reg('s15h', 'S15-H: antigen requirement, challenge (VN04 rgH5N1 5×LD50) 3 days after dosing, aged BALB/c', txt,
                       compress(survcells('S15-H', list(arms))), SURV_METH + '; Fisher exact two-sided'))
# imprinting
for b, virus in [('S06-E(imprint)', 'PR8 H1N1 (same virus as the prior infection)'), ('S06-F(imprint)', 'Perth H3N2 d14')]:
    arms = {gname: surv_arm(b, gname) for gname in ['Naive+PSLN-212', 'Imprinting+PSLN-212', 'Naive+PSLN-344', 'Imprinting+PSLN-344']}
    txt = '; '.join(f'{k} {v[0]}/{v[1]}' for k, v in arms.items())
    V[('imp', b)] = (txt, reg(('imp', b), f'{b}: 14-month mice with (Imprinting) or without (Naive) prior PR8 infection at 10 months; challenge {virus}', txt,
                               compress(survcells(b, list(arms))), SURV_METH))
# young-only experiments
for b, lab in [('S09-B', 'young, Aichi H3N2 vaccine, PR8 d21'), ('S09-D', 'young, CA09 vaccine, Perth H3N2 d21'), ('S09-F', 'young, bivalent, rgH5N1 d180')]:
    arms = {gname: surv_arm(b, gname) for gname in ['Sham', 'PSLN-344Y', 'PSLN-212Y']}
    txt = '; '.join(f'{k} {v[0]}/{v[1]}' for k, v in arms.items())
    V[('young', b)] = (txt, reg(('young', b), f'{b}: {lab}', txt, compress(survcells(b, list(arms))), SURV_METH))
arms = {gname: surv_arm('S13-E', gname) for gname in ['Naive', 'Sham', 'CMP-204(Y)', 'PSLN-344(Y)']}
txt = '; '.join(f'{k} {v[0]}/{v[1]}' for k, v in arms.items())
V[('young', 'S13-E')] = (txt, reg(('young', 'S13-E'), 'S13-E: young BALB/c, CA09 10×LD50 d14', txt, compress(survcells('S13-E', list(arms))), SURV_METH))
# untreated deaths
cells = []
for b in ['S06-E(d60)', 'S06-F(d60)', 'S06-G']:
    cells += survcells(b, ['Untreated'])
ud = [surv_arm(b, 'Untreated') for b in ['S06-E(d60)', 'S06-F(d60)', 'S06-G']]
txt = f'deaths 1/7 (S06-E, day 4), 0/7 (S06-F), 3/7 (S06-G, days 3, 7, 10): total {sum(x[1]-x[0] for x in ud)}/{sum(x[1] for x in ud)} within 14 days'
V['untreated'] = (txt, reg('untreated', 'Deaths among unvaccinated, UNCHALLENGED 20-month "Untreated" controls', txt, compress(cells), 'count of rows with event = 1'))
# CMP-204 S03-I
V['cmp_s03i'] = ('CMP-204 3/7 survivors', V[('surv', 'S03-I')][1])

# ---------------------------------------------------------------- immunogenicity (aged, d14) & others
def trio(block, label, analyte='', timepoint='', young=True, sham=True, cmp=False):
    out = {}
    for grp in (['Sham'] if sham else []) + (['CMP-204'] if cmp else []) + ['PSLN-212', 'PSLN-344'] + (['PSLN-212(Y)'] if young else []):
        out[grp] = g(block, grp, analyte, timepoint, label=label)
    out['mn'] = contrast(block, 'PSLN-344', 'PSLN-212', analyte, timepoint, label=label)
    if young:
        out['y'] = contrast(block, 'PSLN-344', 'PSLN-212(Y)', analyte, timepoint, label=label)
    V[('trio', block, analyte, timepoint)] = out
    return out

IMM = [('S03-A', 'Serum IgG anti-CA09 H1N1, d14 (endpoint titre)', True), ('S03-C', 'HAI anti-CA09 H1N1, d14', True), ('S03-D', 'Neutralising titre anti-CA09 H1N1, d14', True),
       ('S03-E', 'Serum IgG anti-Aichi H3N2, d14', True), ('S03-G', 'HAI anti-Aichi H3N2, d14', True), ('S03-H', 'Neutralising titre anti-Aichi H3N2, d14', True),
       ('S13-I', 'Serum IgG anti-CA09, d28 after d14 boost', True), ('S13-J', 'Serum IgG anti-Aichi, d28 after d14 boost', True)]
for b, lab, cmp_ in IMM:
    trio(b, lab, cmp=cmp_)
for b, lab in [('S03-K', 'MLN GC B cells (CXCR5+GL7+ of B), d7'), ('S05-F', 'MLN IFN-γ+ CD8, rgH5N1-vaccine restim, cells from d14'), ('S05-G', 'MLN IFN-γ+ CD8, rgH5N1 restim, d60'),
               ('S05-H', 'MLN GZMB+ CD8, d60'), ('S05-I', 'Lung CD8 TRM (CD69+CD103+, iv-label negative), d25'), ('S05-D', 'Lung Ki-67+ CD8, d3'), ('S05-E', 'Lung GZMB+ CD8, d3'),
               ('S14-A H1N1', 'MLN IFN-γ+ CD8, CA09 restim (timepoint not stated)'), ('S14-A H3N2', 'MLN IFN-γ+ CD8, Aichi restim (timepoint not stated)'),
               ('S04-B Foxp3', 'Tfr (Foxp3+ of CXCR5+ICOShi CD4), d7'), ('S04-C', 'Tfr, d30'), ('S02-A', 'Lung CCR7+ migratory CD11b+ DC, 72 h'),
               ('S02-B', 'MLN CD11b+CD103- DC, 72 h'), ('S02-D CD40', 'CD40+ of MLN CD11b+ DC, d3'), ('S02-D CD86', 'CD86+ of MLN CD11b+ DC, d3'),
               ('S01-F', 'Lung cDC1, 72 h'), ('S13-H', 'IgG+ of MLN B220+ cells (timepoint not stated)'), ('S11-E', 'Lung CD206+ macrophages (timepoint not stated)'),
               ('S04-D', 'Lung Treg (CD4+Foxp3+), d7, n=3')]:
    trio(b, lab)
trio('S04-A', 'MLN ICOS-high Tfh (CXCR5+PD1+ICOShi of CD4), d7', analyte='ICOS-high Tfh')
trio('S01-A', 'Lung Ifnb1 mRNA 16 h (fold vs untreated)', analyte='Ifnb1', timepoint='16h')
trio('S01-A', 'Lung Ifnb1 mRNA 72 h (fold vs untreated)', analyte='Ifnb1', timepoint='72h')
trio('S01-D', 'Lung monocytes (CD11b+Ly6C+), day 4', timepoint='4')
trio('S01-D', 'Lung monocytes, day 8', timepoint='8')
trio('S01-E', 'Lung CD11b+ DC, day 4', timepoint='4')
trio('S01-E', 'Lung CD11b+ DC, day 8', timepoint='8')
trio('S02-E', 'MLN CD11b+ DC -> OT-I proliferation (CFSE dilution)', sham=False)
trio('S02-C', 'MLN AF647-OVA+ DC, 36 h', sham=False)
for tp in ['16h', '36h', '72h']:
    trio('S02-F', f'Lung Gm-csf mRNA {tp}', analyte='Gm-csf', timepoint=tp, young=False)
trio('S03-L', 'MLN B-cell Aicda mRNA, d5, n=3', analyte='Aicda', young=False)
# young PSLN-344 vs young PSLN-212 Ifnb1
V['y344_ifn16'] = contrast('S01-A', 'PSLN-344(Y)', 'PSLN-212(Y)', 'Ifnb1', '16h', label='Lung Ifnb1 16 h, young')
V['y344_ifn72'] = contrast('S01-A', 'PSLN-344(Y)', 'PSLN-212(Y)', 'Ifnb1', '72h', label='Lung Ifnb1 72 h, young')
V['g_y344_ifn16'] = g('S01-A', 'PSLN-344(Y)', 'Ifnb1', '16h', label='Lung Ifnb1 16 h')

# IgG2a/IgG1 recomputed from S13 (raw titres)
def subclass_ratio(a_blk, b_blk, label):
    out = {}
    for grp in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        a = m[(m.block == a_blk) & (m.group == grp)]; b = m[(m.block == b_blk) & (m.group == grp)]
        r = a.value.values / b.value.values
        lr = np.log10(r); h = stats.t.ppf(.975, len(r) - 1) * lr.std(ddof=1) / np.sqrt(len(r))
        txt = f'{10**lr.mean():.2f} [{10**(lr.mean()-h):.2f}–{10**(lr.mean()+h):.2f}] (n={len(r)})'
        nid = reg(('sub', a_blk, grp), f'{label} — {grp} (recomputed from raw subclass titres; S03-B/F mislabelled)', txt, compress(list(a.cell) + list(b.cell)),
                  'per-animal quotient IgG2a/IgG1 (same row = same animal), geometric mean, 95% t-interval on log10')
        out[grp] = (txt, nid, r)
    # test PSLN-344 vs PSLN-212
    t = stats.ttest_ind(np.log10(out['PSLN-344'][2]), np.log10(out['PSLN-212'][2]), equal_var=False)
    out['p'] = t.pvalue
    V[('sub', a_blk)] = out
    return out
subclass_ratio('S13-A', 'S13-B', 'IgG2a/IgG1 anti-CA09 H1N1, d14')
subclass_ratio('S13-C', 'S13-D', 'IgG2a/IgG1 anti-Aichi H3N2, d14')
# printed (mislabelled) S03-B PSLN-344 GM for the integrity statement
V['s03b_printed'] = g('S03-B', 'PSLN-344', label='IgG2a/IgG1 H1N1 AS PRINTED (mislabelled)')
V['s03f_printed'] = g('S03-F', 'PSLN-344', label='IgG2a/IgG1 H3N2 AS PRINTED (mislabelled)')

# HAI seroprotection counts
def sp_counts(block):
    out = {}
    for grp in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        d = m[(m.block == block) & (m.group == grp)]
        out[grp] = (int((d.value >= 40).sum()), len(d), list(d.cell))
    txt = '; '.join(f'{k} {v[0]}/{v[1]}' for k, v in out.items())
    cells = sum([v[2] for v in out.values()], [])
    V[('hai40', block)] = (txt, reg(('hai40', block), f'Animals with HAI >= 1:40 ({block})', txt, compress(cells), 'count of animals with reciprocal HAI titre >= 40'))
sp_counts('S03-C'); sp_counts('S03-G')

# ---------------------------------------------------------------- mechanism interventions
INTERV = {
    'gmcsf_rescue': ('S02-G', 'PSLN-212+GM-CSF', 'PSLN-212', 'Lung Ly6C+CD11c+MHC-II+ moDC, d5, aged', ''),
    'ifnar_chim': ('S02-H', 'IFN w/o cDC', 'WT w/o cDC', 'CD45.2+ moDC d3, bone-marrow transfer (cDC precursors removed)', ''),
    'ifnar_chim2': ('S02-H', 'IFN w/ cDC', 'WT w/ cDC', 'CD45.2+ moDC d3, bone-marrow transfer (cDC precursors retained)', ''),
    'ifnar_gmcsf': ('S02-H', 'GMCSF', 'IFN w/o cDC', 'CD45.2+ moDC d3: Ifnar-/- marrow + i.t. GM-CSF vs Ifnar-/- marrow', ''),
    'ccr2_mono': ('S07-B', 'PSLN-344+INCB3344', 'PSLN-344', 'Lung CD11b+Ly6C+ monocytes (timepoint not stated)', 'CD11b+Ly6C+ monocytes'),
    'ccr2_mac': ('S07-B', 'PSLN-344+INCB3344', 'PSLN-344', 'Lung Ly6C+ macrophages (timepoint not stated)', 'Ly6C+ macrophages'),
    'ccr2_cd8': ('S02-I', 'PSLN-344(Y)+INCB3344', 'PSLN-344(Y)', 'Lung GZMB+ CD8, d5, young', ''),
    'ptx_dc': ('S02-C', 'PTX', 'PSLN-344', 'MLN AF647-OVA+ DC, 36 h', ''),
    'ptx_prime': ('S02-E', 'PTX', 'PSLN-344', 'MLN DC -> OT-I priming', ''),
    'ptx_mln': ('S05-C', 'MLN+PTX', 'MLN', 'OT-I proliferation in MLN, d4, n=3', ''),
    'ptx_lung': ('S05-C', 'Lung+PTX', 'Lung', 'OT-I proliferation in lung, d4, n=3', ''),
    'cbx': ('S11-C', 'CBX+', 'CBX-', 'Lung recruited monocytes d3 with carbenoxolone', ''),
    'spad': ('S01-C', 'SPA/D', 'WT', 'Alveolar macrophage uptake of DiD liposome, 16 h (knockouts 7-8 weeks; WT age not stated)', ''),
    'aec': ('S01-B', 'AECI/PSLN-SRB', 'AECII/PSLN-SRB', 'SRB+ alveolar epithelial cells, 16 h, aged', ''),
    'free': ('S01-B', 'AECII/PSLN-SRB', 'AECII/FreeSRB', 'SRB+ AECII: liposomal vs free SRB', ''),
    'ifnar_mono': ('S12-A', 'IFNAR-/- to WT', 'WT to WT', 'Infiltrating CD45.2+ monocytes d3, young, n=3', ''),
}
for key, (b, g1, g0, lab, an) in INTERV.items():
    V[key] = contrast(b, g1, g0, an, '', label=lab)
    V[key + '_g1'] = g(b, g1, an, '', label=lab); V[key + '_g0'] = g(b, g0, an, '', label=lab)
V['s02g_gmcsf_alone'] = g('S02-G', 'GM-CSF', label='Lung moDC d5, GM-CSF without adjuvant')

# ---------------------------------------------------------------- dose response & CMC
d = m[m.block == 'S08-A'].copy(); d['dose'] = d.timepoint.astype(float)
from scipy.optimize import curve_fit
def emax(D, e0, emx, ed50, h): return np.log10(e0 + emx * D**h / (ed50**h + D**h))
for grp in ['PSLN-212', 'PSLN-344', 'CMP-204']:
    dd = d[d.group == grp]
    p, cov = curve_fit(emax, dd.dose.values, np.log10(dd.value.values), p0=[1, 40, 15, 1.5], bounds=([0, 0, 0.1, 0.3], [5, 500, 200, 6]), maxfev=20000)
    se = np.sqrt(np.diag(cov))
    txt = f'Emax {p[1]:.1f} (SE {se[1]:.1f})-fold above baseline; ED50 {p[2]:.1f} ug (SE {se[2]:.1f}); Hill {p[3]:.2f}'
    V[('emax', grp)] = (txt, reg(('emax', grp), f'S08-A Ifnb1 16 h dose-response (1-40 ug), {grp}', txt, compress(list(dd.cell)),
                                  'Emax model E0 + Emax*D^h/(ED50^h + D^h) fitted to log10 per-animal values (scipy curve_fit, 3 animals x 5 doses)'))
for key, (g1, d1, g0, d0) in {'dose_344_10_vs_212_40': ('PSLN-344', 10, 'PSLN-212', 40), 'dose_344_20_vs_212_20': ('PSLN-344', 20, 'PSLN-212', 20),
                              'dose_212_20_vs_40': ('PSLN-212', 20, 'PSLN-212', 40), 'dose_344_20_vs_40': ('PSLN-344', 20, 'PSLN-344', 40)}.items():
    a = d[(d.group == g1) & (d.dose == d1)]; b = d[(d.group == g0) & (d.dose == d0)]
    la, lb = np.log10(a.value.values), np.log10(b.value.values)
    se = np.sqrt(la.var(ddof=1) / 3 + lb.var(ddof=1) / 3); dfw = se**4 / ((la.var(ddof=1) / 3)**2 / 2 + (lb.var(ddof=1) / 3)**2 / 2)
    hh = stats.t.ppf(.975, dfw) * se; diff = la.mean() - lb.mean(); pv = stats.ttest_ind(la, lb, equal_var=False).pvalue
    txt = f'GM {10**la.mean():.1f} vs {10**lb.mean():.1f}; ratio {10**diff:.2f} [{10**(diff-hh):.2f}–{10**(diff+hh):.2f}]; Welch p={pv:.2g}'
    V[key] = (txt, reg(key, f'S08-A Ifnb1 16 h: {g1} {d1} ug vs {g0} {d0} ug', txt, compress(list(a.cell) + list(b.cell)), 'ratio of geometric means, Welch t on log10 (n=3 per dose)'))
V['ee'] = contrast('S08-B', 'PSLN-344', 'PSLN-212', label='CDN-1807 encapsulation efficiency (A260), %')
V['ee_344'] = g('S08-B', 'PSLN-344', label='Encapsulation efficiency'); V['ee_212'] = g('S08-B', 'PSLN-212', label='Encapsulation efficiency')

# ---------------------------------------------------------------- safety
w = R.w
sd = w[w.block == 'S08-D']
nad = {}
for grp, dg in sd.groupby('group', sort=False):
    x = dg.groupby('col').value.min()
    n10 = int((dg.day == 10).sum())
    txt = f'nadir mean {x.mean():.1f}% (SD {x.std():.1f}; lowest animal {x.min():.1f}%); animals weighed on day 10: {n10}/5; day-10 mean {dg[dg.day==10].value.mean():.1f}%'
    nad[grp] = x.values
    V[('nadir', grp)] = (txt, reg(('nadir', grp), f'S08-D post-vaccination body weight (CA09 vaccine + 20 ug adjuvant, intranasal), {grp}', txt, compress(list(dg.cell)),
                                   'per-animal minimum of % day-0 weight over days 2-10; arithmetic mean; NOTE S08-D values were recycled into S15-F (I-02)'))
for a_, b_ in [('PSLN-344', 'Vaccine'), ('PSLN-344', 'PSLN-212')]:
    t = stats.ttest_ind(nad[a_], nad[b_], equal_var=False)
    txt = f'difference {nad[a_].mean() - nad[b_].mean():+.1f} points; Welch p={t.pvalue:.2g}'
    V[('nadir_c', a_, b_)] = (txt, reg(('nadir_c', a_, b_), f'S08-D nadir {a_} vs {b_}', txt, compress(list(sd[sd.group.isin([a_, b_])].cell)), 'Welch t-test on per-animal nadirs'))
for an in ['Ifnb1', 'Tnf', 'Isg15']:
    V[('cns', an)] = contrast('S10-A', 'PSLN-344', 'Sham', an, '36h', label=f'CNS {an} mRNA 36 h')
    V[('cns_ct', an)] = contrast('S10-A', 'CT', 'PBS', an, '36h', label=f'CNS {an} mRNA 36 h, cholera toxin positive control')
V['cns_mdd'] = ('minimal detectable fold-change at 80% power (n=5 vs 5, two-sided alpha 0.05): Ifnb1 1.98x, Tnf 1.84x, Isg15 1.43x',
                reg('cns_mdd', 'S10-A sensitivity: smallest CNS induction the study could detect', 'Ifnb1 1.98x; Tnf 1.84x; Isg15 1.43x',
                    compress(list(m[(m.block == 'S10-A') & (m.group.isin(['Sham', 'PSLN-344']))].cell)),
                    'pooled SD of log10 values (Sham, PSLN-344); statsmodels TTestIndPower, d for 80% power = 2.02'))
for an in ['Tnf', 'Il10', 'Il6', 'Ccl2', 'Ifnb1']:
    V[('cyt_y', an)] = contrast('S09-A panel1 (B:V)', 'PSLN-344', 'PSLN-212(y)', an, '16h (as printed)', label=f'Lung {an} 16 h (S09-A panel 1, stored as log10)')
    V[('cyt_212', an)] = contrast('S09-A panel1 (B:V)', 'PSLN-344', 'PSLN-212', an, '16h (as printed)', label=f'Lung {an} 16 h (S09-A panel 1, stored as log10)')

# ---------------------------------------------------------------- restoration summary (fraction of young)
for r in RS.itertuples():
    txt = f'aged PSLN-344 = {r.ratio_344*100:.0f}% of young [{r.lo_344*100:.0f}–{r.hi_344*100:.0f}%], p={r.p_344_vs_young:.2g}; aged PSLN-212 = {r.ratio_212*100:.0f}% of young'
    V[('rest', r.readout)] = (txt, reg(('rest', r.readout), f'Restoration: {r.readout} [{r.block}]', txt, compress(r.cells_344.split(';') + r.young_cells.split(';') + r.cells_212.split(';')),
                                        'ratio of geometric means (titres/qPCR) or of arithmetic means (% data) vs young PSLN-212(Y); 95% CI by Welch/delta method on log scale; p = Welch t'))
print(len(R.REG), 'register entries')

# ---- extra registrations for Section 8
for tp in ['2', '4', '6', '8']:
    V[('nk', tp)] = contrast('S11-D', 'PSLN-344', 'PSLN-212', '', tp, label=f'Lung NK cells day {tp}')
V['r848_ifn'] = g('S01-A', 'PSLN-212/R848', 'Ifnb1', '16h', label='Lung Ifnb1 mRNA 16 h (fold vs untreated)')
V['r848_tnf'] = g('S09-A panel1 (B:V)', 'PSLN-212/R848', 'Tnf', '16h (as printed)', label='Lung Tnf 16 h, stored log10 fold')
V['r848_tnf_344'] = g('S09-A panel1 (B:V)', 'PSLN-344', 'Tnf', '16h (as printed)', label='Lung Tnf 16 h, stored log10 fold')

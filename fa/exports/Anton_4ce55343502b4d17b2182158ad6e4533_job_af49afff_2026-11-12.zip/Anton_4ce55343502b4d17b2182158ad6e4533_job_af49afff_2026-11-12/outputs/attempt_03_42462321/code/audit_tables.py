import pandas as pd, numpy as np, sys
sys.path.insert(0, '/tmp/work')
import register as RG
m = RG.m; s = RG.s
# S11-A vs S11-B paired
A = m[m.block=='S11-A'].reset_index(drop=True); B = m[m.block=='S11-B'].reset_index(drop=True)
P = pd.DataFrame(dict(group=A.group, day=A.timepoint, cell_S11A=A.cell, value_S11A=A.value, cell_S11B=B.cell, value_S11B=B.value))
P['identical'] = np.isclose(P.value_S11A, P.value_S11B)
P.to_csv('audit_S11AB_pairs.csv', index=False)
# S03-B/F printed vs recomputed
rows = []
for printed_blk, (a_blk, b_blk) in {'S03-B': ('S13-A', 'S13-B'), 'S03-F': ('S13-C', 'S13-D')}.items():
    for grp in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
        pr = m[(m.block == printed_blk) & (m.group == grp)].reset_index(drop=True)
        for src in ['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
            a = m[(m.block == a_blk) & (m.group == src)].reset_index(drop=True); b = m[(m.block == b_blk) & (m.group == src)].reset_index(drop=True)
            q = a.value / b.value
            for i in range(len(pr)):
                rows.append(dict(printed_block=printed_blk, printed_label=grp, printed_cell=pr.cell[i], printed_value=pr.value[i], recomputed_from_group=src,
                                 IgG2a_cell=a.cell[i], IgG1_cell=b.cell[i], recomputed_value=q[i], rel_diff=abs(q[i] - pr.value[i]) / pr.value[i]))
Q = pd.DataFrame(rows)
best = Q.groupby(['printed_block', 'printed_label', 'recomputed_from_group']).rel_diff.max().reset_index()
best['match'] = best.rel_diff < 1e-3
Q.to_csv('audit_subclass_relabel.csv', index=False); best.to_csv('audit_subclass_relabel_summary.csv', index=False)
print(best)
# Tfh:Tfr vs Foxp3
f = m[m.block == 'S04-B Foxp3'].reset_index(drop=True); r = m[m.block == 'S04-B Tfh:Tfr'].reset_index(drop=True)
T = pd.DataFrame(dict(group=f.group, foxp3_cell=f.cell, foxp3=f.value, ratio_cell=r.cell, ratio_printed=r.value, ratio_from_foxp3=(100 - f.value) / f.value))
T['abs_diff'] = (T.ratio_printed - T.ratio_from_foxp3).abs(); T.to_csv('audit_TfhTfr.csv', index=False); print('TfhTfr max diff', T.abs_diff.max())
# survival by group
rows = []
for (b, g), d in s.groupby(['block', 'group'], sort=False):
    rows.append(dict(block=b, group=g, n=len(d), survivors=int((d.event == 0).sum()), deaths=int(d.event.sum()),
                     death_days=','.join(str(int(x)) for x in sorted(d[d.event == 1].time.dropna())), censor_days=','.join(sorted(set(str(int(x)) if not np.isnan(x) else 'blank' for x in d[d.event == 0].time))),
                     time_cells=RG.compress(list(d.cell_time)), event_cells=RG.compress(list(d.cell_event))))
pd.DataFrame(rows).to_csv('audit_survival_by_group.csv', index=False)
print('ok')

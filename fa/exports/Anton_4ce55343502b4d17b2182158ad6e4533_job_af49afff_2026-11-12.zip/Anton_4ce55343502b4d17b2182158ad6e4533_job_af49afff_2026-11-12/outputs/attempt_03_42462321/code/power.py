"""Design calculations quoted in Section 7 (not data-derived)."""
import numpy as np
from scipy.stats import fisher_exact, norm
from statsmodels.stats.power import TTestIndPower
rng = np.random.default_rng(7)
def power_fisher(p1, p0, n, sims=6000, alpha=0.05):
    a = rng.binomial(n, p1, sims); b = rng.binomial(n, p0, sims)
    return np.mean([fisher_exact([[x, n - x], [y, n - y]])[1] < alpha for x, y in zip(a, b)])
for p1, p0 in [(0.9, 0.1), (0.8, 0.3), (0.7, 0.4), (0.8, 0.5)]:
    print(f'n=7: {p1:.0%} vs {p0:.0%} power {power_fisher(p1, p0, 7):.2f}')
print('75% vs 20%:', {n: round(power_fisher(0.75, 0.2, n), 2) for n in [12, 14, 16, 18, 20]})
tp = TTestIndPower()
for d, sd in [(1.0, 0.8), (0.7, 0.8)]:
    print(f'lung titre {d} log10, SD {sd}: n/arm = {np.ceil(tp.solve_power(effect_size=d/sd, alpha=0.05, power=0.9)):.0f}')
for margin in [0.5, 0.7]:
    print(f'NI margin {margin}: n/arm = {2*((norm.ppf(0.975)+norm.ppf(0.9))*0.8/margin)**2:.1f}')

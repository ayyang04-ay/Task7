import pandas as pd, numpy as np, itertools
w = pd.read_csv('bodyweight.csv')
w = w[w.day > 0]
traj = {}
for (b, g, c), d in w.groupby(['block','group','col']):
    traj[(b,g,c)] = dict(zip(d.day, d.value.round(6)))
keys = list(traj)
hits = []
for k1, k2 in itertools.combinations(keys, 2):
    t1, t2 = traj[k1], traj[k2]
    common = [dd for dd in t1 if dd in t2]
    same = [dd for dd in common if t1[dd] == t2[dd]]
    # exclude trivially-identical carried-forward runs within the same animal
    distinct_vals = len(set(t1[dd] for dd in same))
    if len(same) >= 3 and distinct_vals >= 2:
        hits.append(dict(a=f'{k1[0]} {k1[1]} col {k1[2]}', b=f'{k2[0]} {k2[1]} col {k2[2]}', n_identical=len(same), n_common_days=len(common),
                         days=','.join(str(int(x)) for x in same), same_block=k1[0]==k2[0]))
H = pd.DataFrame(hits).sort_values(['n_identical'], ascending=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 300); pd.set_option('display.max_colwidth', 60)
print(H.to_string(index=False))
H.to_csv('trajectory_duplicates.csv', index=False)
print('\nblocks involved:', sorted(set([x.split()[0] for x in H.a] + [x.split()[0] for x in H.b])))

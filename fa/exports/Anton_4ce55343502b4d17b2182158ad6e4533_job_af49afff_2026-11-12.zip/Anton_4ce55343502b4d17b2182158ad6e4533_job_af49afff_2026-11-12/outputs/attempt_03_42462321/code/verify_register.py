import openpyxl, re, pandas as pd, numpy as np
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx', data_only=True)
reg = pd.read_csv('/tmp/work/register.csv')
def colnum(c):
    n=0
    for ch in c: n = n*26 + ord(ch)-64
    return n
def colstr(n):
    s=''
    while n: n, r = divmod(n-1, 26); s = chr(65+r)+s
    return s
def expand(spec):
    cells = []
    for part in spec.split('; '):
        sh, refs = part.split('!')
        for rr in refs.split(','):
            if ':' in rr:
                a, b = rr.split(':')
                ma, mb = re.match(r'([A-Z]+)(\d+)', a), re.match(r'([A-Z]+)(\d+)', b)
                for c in range(colnum(ma.group(1)), colnum(mb.group(1))+1):
                    for r in range(int(ma.group(2)), int(mb.group(2))+1):
                        cells.append((sh, f'{colstr(c)}{r}'))
            else:
                cells.append((sh, rr))
    return cells
bad = []; checked = 0
for r in reg.itertuples():
    if r.source_cells.startswith(('simulation', 'analytic')): continue
    cells = expand(r.source_cells)
    vals = [wb[sh][c].value for sh, c in cells]
    # group summaries: "X [lo-hi] (n=k)" or "X% ± sd (n=k)"
    mm = re.match(r'^([\d,\.]+)%? (?:\[|±)', r.value)
    if mm and '(n=' in r.value and 'quotient' not in r.reduction:
        x = np.array([float(v) for v in vals if v is not None], float)
        n = int(re.search(r'\(n=(\d+)\)', r.value).group(1))
        if len(x) != n: bad.append((r.id, 'n mismatch', len(x), n)); continue
        if 'half the lowest dilution' in r.reduction: x = np.where(x < 10, 5, x)
        est = np.exp(np.log(x).mean()) if 'geometric' in r.reduction else x.mean()
        rep = float(mm.group(1).replace(',', ''))
        if abs(est - rep) / max(abs(rep), 1e-9) > 0.006 and abs(est-rep) > 0.006: bad.append((r.id, r.statement, est, rep))
        checked += 1
    elif r.reduction.startswith('survivors = animals with event 0') and r.statement.startswith('14-day survival'):
        # recount survivors per group from raw cells: events are in event cells; group header from row 2/16/33/70 etc. -> count zeros
        ev = [v for (sh, c), v in zip(cells, vals) if v in (0, 1) and not re.match(r'^[AGMR]\d', c) ]
        checked += 1
print('checked', checked, 'entries; problems:', len(bad))
for b in bad[:20]: print(b)

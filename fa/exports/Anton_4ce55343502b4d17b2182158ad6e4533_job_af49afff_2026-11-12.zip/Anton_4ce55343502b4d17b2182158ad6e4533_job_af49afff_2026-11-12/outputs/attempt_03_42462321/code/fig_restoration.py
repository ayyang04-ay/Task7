import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
R = pd.read_csv('restoration.csv')
cats = list(dict.fromkeys(R.category))
colors = {'Innate / afferent':'#2e7d32','DC quality':'#c62828','Humoral':'#1565c0','Germinal centre':'#6a1b9a','CD8 T cell':'#ef6c00','Resolution':'#5d4037'}
fig, ax = plt.subplots(figsize=(11.5, 12))
y = 0; yt=[]; yl=[]
for c in cats[::-1]:
    d = R[R.category==c].iloc[::-1]
    for r in d.itertuples():
        ax.plot([r.lo_212, r.hi_212],[y-0.16]*2, color='#9e9e9e', lw=1.5); ax.plot(r.ratio_212, y-0.16, 's', color='#9e9e9e', ms=6)
        ax.plot([r.lo_344, r.hi_344],[y+0.16]*2, color=colors[c], lw=2.2); ax.plot(r.ratio_344, y+0.16, 'o', color=colors[c], ms=7)
        sig = '' if r.p_344_vs_young >= 0.05 else ('*' if r.p_344_vs_young >= 0.01 else '**')
        ax.text(7.2, y+0.16, f'{r.ratio_344*100:.0f}% {sig}', va='center', fontsize=8.5, color=colors[c])
        ax.text(14.5, y-0.16, f'{r.ratio_212*100:.0f}%', va='center', fontsize=8.5, color='#757575')
        yt.append(y); yl.append(f'{r.readout}  [{r.block}]'); y += 1
    ax.text(0.012, y-0.35, c, fontsize=10, weight='bold', color=colors[c]); y += 0.9
ax.axvline(1, color='k', lw=1); ax.axvspan(0.5, 2.0, color='#e8f5e9', alpha=0.5, zorder=0)
ax.set_xscale('log'); ax.set_xlim(0.01, 25); ax.set_yticks(yt); ax.set_yticklabels(yl, fontsize=8.3)
ax.set_xticks([0.01,0.03,0.1,0.3,1,3,10]); ax.set_xticklabels(['1%','3%','10%','30%','100%\n(young)','300%','1000%'])
ax.set_xlabel('Aged group as % of young PSLN-212(Y) (ratio of geometric means for titres/qPCR; ratio of means for %), 95% CI', fontsize=9)
ax.text(7.2, y-0.2, 'aged\nPSLN-344', fontsize=8.5, weight='bold'); ax.text(14.5, y-0.2, 'aged\nPSLN-212', fontsize=8.5, color='#757575', weight='bold')
ax.set_title('Which arms of the response does Mn2+ restore in aged mice?\ncircles = aged PSLN-344; grey squares = aged PSLN-212; 100% = young PSLN-212(Y) level;\n'
             '* p<0.05, ** p<0.01 aged PSLN-344 vs young (Welch t, log scale for titres/qPCR); shaded band = within 2-fold of young', fontsize=9.5)
ax.set_ylim(-1, y+0.8)
fig.text(0.01, 0.005, 'For Tfr and Ifnb1-72h young values are LOWER than aged, so a ratio >100% is worse. Subclass titres taken from raw S13 data (S03-B/F quotients are mislabelled). '
         'HAI <1:10 imputed as 5. n = 5 per group throughout.', fontsize=7.5)
plt.tight_layout(rect=[0,0.015,1,1]); plt.savefig('/tmp/outputs/figures/fig2_restoration_profile.png', dpi=160); print('ok')

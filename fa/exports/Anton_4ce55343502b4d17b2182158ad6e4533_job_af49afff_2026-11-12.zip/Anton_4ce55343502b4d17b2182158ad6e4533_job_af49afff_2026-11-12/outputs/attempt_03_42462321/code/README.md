# Reproducible pipeline for the PSLN-344 portfolio review

Run `./run_all.sh` (bash). Inputs: `/tmp/world/filesystem/adjuvant_program_dataset.xlsx`. Intermediates go to `/tmp/work`, deliverables to `/tmp/outputs`.
Paths are absolute inside the scripts; edit them if you move the files. Conda envs used: `singlecell` (openpyxl), `core` (pandas/scipy/statsmodels/lifelines/matplotlib),
`genomics` (pandoc); R with the `survival` package.

| Step | Script | Output |
|---|---|---|
| Parse every block with its source cell | parse.py (dump.py prints raw cells) | measurements.csv, survival.csv, bodyweight.csv |
| Group summaries and within-block contrasts | blockstats.py | block_summary.csv, block_contrasts.csv |
| Survival per experiment; pooled MH (Sato); stratified log-rank and exact CMH | surv_meta.py, mh_sato.py, strat_out.R | surv_contrasts.csv, surv_pooled_MH.csv, surv_stratified_R.csv |
| Aged vs young restoration | restoration.py | restoration.csv |
| Integrity screens | bw_vs_surv.py, timing.py, traj_dups.py, recycled_decimals.py, integrity.py, audit_tables.py | bw_vs_surv.csv, trajectory_duplicates.csv, recycled_decimals_highentropy.csv, audit_*.csv |
| Design calculations | power.py | power.txt |
| Figures | fig_*.py | /tmp/outputs/figures/*.png |
| Numbers register and memo | register.py, psln_numbers.py, integrity_log.py, compose.py | register.csv, PSLN-344_portfolio_recommendation.md |
| Evidence workbook | usage_table.py, build_workbook.py | PSLN-344_evidence_workbook.xlsx |
| Independent verification (re-reads raw cells, recomputes cited values) | verify_register.py, verify_survival.py | printout: 0 problems |
| DOCX | pandoc with reference_custom.docx | PSLN-344_portfolio_recommendation.docx |

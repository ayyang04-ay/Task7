import openpyxl, re, pandas as pd, numpy as np
exec(open('verify_register.py').read().split("bad = []; checked = 0")[0])   # reuse expand(), wb, reg
def header(sh, col, row):
    ws = wb[sh]
    for r in range(row-1, 0, -1):
        v = ws[f'{col}{r}'].value
        if isinstance(v, str): return v.replace('Naïve', 'Naive').strip()
    return None
norm = lambda g: g.replace('PSLN-212Y','PSLN-212(Y)').replace('PSLN-344Y','PSLN-344(Y)')
probs = 0; n = 0
for r in reg.itertuples():
    if not (r.reduction.startswith('survivors = animals with event 0') and ('14-day survival' in r.statement or r.statement.startswith('S09') or r.statement.startswith('S13-E') or r.statement.startswith('S06-') or r.statement.startswith('S15-H'))):
        continue
    cells = expand(r.source_cells); counts = {}
    for sh, c in cells:
        col = re.match(r'[A-Z]+', c).group(0); row = int(c[len(col):])
        v = wb[sh][c].value
        h = header(sh, col, row)
        if h is None or h.lower().startswith('days') or v not in (0, 1): continue
        k = counts.setdefault(norm(h), [0, 0]); k[1] += 1; k[0] += (v == 0)
    claimed = dict((norm(g.strip()), (int(a), int(b))) for g, a, b in re.findall(r'([A-Za-z0-9\-\+\(\)\. ]+?) (\d+)/(\d+)', r.value.split(' | ')[0]))
    for g, (a, b) in claimed.items():
        g2 = g.replace('3d ', '3d ')
        if g2 in counts:
            n += 1
            if tuple(counts[g2]) != (a, b): probs += 1; print('MISMATCH', r.id, g2, counts[g2], (a, b))
print('survival group counts verified:', n, 'mismatches:', probs)

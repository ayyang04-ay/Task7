import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
R = pd.read_csv('surv_contrasts.csv'); P = pd.read_csv('surv_pooled_MH.csv')
def wilson(x, n, z=1.959964):
    p = x/n; den = 1+z*z/n; c = (p + z*z/(2*n))/den; h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/den
    return c-h, c+h
def newcombe(x1,n1,x0,n0):
    p1,p0 = x1/n1, x0/n0; l1,u1 = wilson(x1,n1); l0,u0 = wilson(x0,n0); d = p1-p0
    return d - np.sqrt((p1-l1)**2 + (u0-p0)**2), d + np.sqrt((u1-p1)**2 + (p0-l0)**2)
label = {'S03-I':'S03-I  CA09 H1N1 homologous, d14 *','S03-J':'S03-J  wild-type H5N1, d2 *','S06-A':'S06-A  PR8 H1N1 heterosubtypic, d14','S06-B':'S06-B  PR8 H1N1 heterosubtypic, d3',
         'S06-C':'S06-C  rgH5N1 heterosubtypic, d14','S06-D':'S06-D  rgH5N1, d3  [EXCLUDED: copy of S06-C]','S06-E(d60)':'S06-E  PR8 H1N1 heterosubtypic, d60 *','S06-F(d60)':'S06-F  rgH5N1 heterosubtypic, d60',
         'S06-G':'S06-G  Perth H3N2 heterosubtypic, d60 *','S15-L':'S15-L  aged C57BL/6 (challenge n.s.) *','S15-N':'S15-N  aged Swiss Webster (challenge n.s.)'}
flag = {'S03-I':'M','S03-J':'M','S06-A':'','S06-B':'','S06-C':'m','S06-D':'X','S06-E(d60)':'M','S06-F(d60)':'','S06-G':'M','S15-L':'M','S15-N':'m'}
order = ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-D','S06-E(d60)','S06-F(d60)','S06-G','S15-L','S15-N']
rowsY = {b: i for i, b in enumerate(order[::-1])}
pooled = [('Primary (10 aged expts; S06-D excluded as duplicate)', 'POOLED: primary set'), ('Sens-A: unflagged blocks only (S06-A, S06-B, S06-F d60)', 'POOLED: unflagged blocks only')]
pY = {pooled[0][0]: len(order)+1.0, pooled[1][0]: len(order)+2.0}
fig, axes = plt.subplots(1, 2, figsize=(15, 7.4), sharey=True, gridspec_kw={'wspace':0.08})
for ax, con, title, xl in [(axes[0], 'PSLN-344 vs PSLN-212 (Mn effect)', 'A. Mn effect in aged mice\nPSLN-344 minus PSLN-212 (survivors: PSLN-344 vs PSLN-212)', (-0.6, 1.55)),
                           (axes[1], 'aged PSLN-344 vs young PSLN-212(Y)', 'B. Restoration to young\naged PSLN-344 minus young PSLN-212(Y) (survivors: aged vs young)', (-1.05, 0.95))]:
    for b in order:
        r = R[(R.block==b)&(R.contrast==con)]
        if not len(r): 
            ax.text(xl[0]+0.05, rowsY[b], 'no young arm', va='center', fontsize=8, color='grey'); continue
        r = r.iloc[0]; lo, hi = newcombe(r.s1, r.n1, r.s0, r.n0); y = rowsY[b]
        f = flag[b]; col = {'':'#1f4e79','m':'#1f4e79','M':'#c55a11','X':'#a6a6a6'}[f]; mk = {'':'o','m':'o','M':'D','X':'x'}[f]
        ax.plot([lo,hi],[y,y], color=col, lw=2); ax.plot(r.RD, y, mk, color=col, ms=8)
        ax.text(xl[1]-0.02, y, f'{r.surv_trt} vs {r.surv_ctl}', va='center', ha='right', fontsize=8.5, family='monospace')
    for key, lab in pooled:
        p = P[(P.contrast==con)&(P.analysis_set==key)].iloc[0]; y = pY[key]
        ax.fill_between([p.CI95_lo, p.CI95_hi],[y-0.3]*2,[y+0.3]*2, color='#2e7d32', alpha=0.85); ax.plot(p.MH_RD, y, 'D', color='white', ms=5)
        ax.text(xl[1]-0.02, y, f'{p.survivors_trt} vs {p.survivors_ctl}', va='center', ha='right', fontsize=8.5, family='monospace', weight='bold')
        ax.text(p.CI95_lo-0.03, y, f'{p.MH_RD:+.2f} [{p.CI95_lo:+.2f}, {p.CI95_hi:+.2f}]', va='center', ha='right', fontsize=8, color='#2e7d32', weight='bold')
    ax.axvline(0, color='k', lw=0.8); ax.set_xlim(*xl); ax.set_title(title, fontsize=10)
    ax.set_xticks([t for t in [-1.0, -0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75, 1.0] if xl[0] <= t <= min(xl[1], 1.0)])
    ax.set_xlabel('Difference in 14-day survival (95% CI)', fontsize=9); ax.axhline(len(order)+0.45, color='grey', lw=0.5, ls=':')
yt = list(rowsY.values()) + list(pY.values()); yl = [label[b] for b in rowsY] + [lab for _, lab in pooled]
axes[0].set_yticks(yt); axes[0].set_yticklabels(yl, fontsize=8.5)
fig.text(0.01, 0.012, 'Per-experiment CIs: Newcombe hybrid score. Pooled: Mantel-Haenszel risk difference, Sato variance (k = number of experiments). '
         '* / orange diamond = block carrying a survival-vs-weight or provenance flag (see integrity log); grey x = excluded duplicate.\n'
         'Source cells: S03!A17:J46, S06!A3:R105, S15!A103:E161 (one row per animal, event 1 = death). n = 7 per arm except S03-J (10 per arm).', fontsize=7.8)
plt.subplots_adjust(left=0.255, right=0.99, bottom=0.14, top=0.9)
plt.savefig('/tmp/outputs/figures/fig1_survival_forest.png', dpi=170); print('ok')

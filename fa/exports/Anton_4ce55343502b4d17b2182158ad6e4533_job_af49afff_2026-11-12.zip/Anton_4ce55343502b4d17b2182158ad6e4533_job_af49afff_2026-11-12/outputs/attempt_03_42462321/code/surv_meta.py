import pandas as pd, numpy as np
from scipy.stats import fisher_exact, norm
from lifelines.statistics import logrank_test
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 120)
s = pd.read_csv('survival.csv')
s['time'] = s.time.fillna(21.0)   # S03-J PSLN-344 animal with blank day (S03!G46), event=0 -> censored at end of follow-up
norm_ = lambda x: x.replace('Naïve','Naive').strip()
s['group'] = s.group.apply(norm_)

EXP = {  # block: (description, virus, challenge day post-vacc, model, flags)
 'S03-I': ('CA09 H1N1 10xLD50 (homologous), bivalent vaccine', 'd14', 'aged BALB/c', 'companion weights S13-F irreconcilable (different group set; PSLN-212 alive in weights vs 7/7 dead)'),
 'S03-J': ('wt VN04 H5N1 (BSL-3), rgH5N1 vaccine', 'd2', 'aged BALB/c', 'stated n=9 vs 10 observed; one PSLN-344 time blank (S03!G46); 22-d follow-up stated vs max 21; companion weights S13-G irreconcilable'),
 'S06-A': ('PR8 H1N1 5xLD50 (heterosubtypic), Aichi H3N2 vaccine', 'd14', 'aged BALB/c', ''),
 'S06-B': ('PR8 H1N1 5xLD50 (heterosubtypic), Aichi H3N2 vaccine', 'd3', 'aged BALB/c', ''),
 'S06-C': ('rgH5N1 5xLD50 (heterosubtypic), bivalent vaccine', 'd14', 'aged BALB/c', 'PSLN-212 deaths 5 (survival) vs 6 (weights S15-C)'),
 'S06-D': ('rgH5N1 5xLD50 (heterosubtypic), bivalent vaccine', 'd3', 'aged BALB/c', 'EXACT row-for-row copy of S06-C; companion weights S15-D imply 2 PSLN-344 and 2 young deaths'),
 'S06-E(d60)': ('PR8 H1N1 5xLD50 (heterosubtypic), Aichi H3N2 vaccine', 'd60', 'aged BALB/c', 'counts disagree with weights S15-E (PSLN-212 7 vs 6; PSLN-344 2 vs 1); unchallenged Untreated 1/7 died'),
 'S06-F(d60)': ('rgH5N1 5xLD50 (heterosubtypic), bivalent vaccine', 'd60', 'aged BALB/c', ''),
 'S06-G': ('Perth H3N2 5xLD50 (heterosubtypic), CA09 H1N1 vaccine', 'd60', 'aged BALB/c', 'unchallenged Untreated 3/7 died; PSLN-344 3 deaths d8-11 vs weights S15-G all 7 weighed to d12'),
 'S15-L': ('challenge not stated, bivalent vaccine', 'n.s.', 'aged C57BL/6 (20 mo)', 'challenge virus/dose/day not stated; companion weights S15-M partly copied from S09-E/S15-A'),
 'S15-N': ('challenge not stated, bivalent vaccine', 'n.s.', 'aged Swiss Webster (20 mo)', 'challenge virus/dose/day not stated'),
 'S06-E(imprint)': ('PR8 5xLD50; prior PR8 infection or saline at 10 mo', 'n.s.', 'BALB/c 14 mo at vaccination', 'duplicate block label (S06-E used twice); challenge day not stated'),
 'S06-F(imprint)': ('Perth H3N2 5xLD50 d14; prior PR8 infection or saline', 'd14', 'BALB/c 14 mo at vaccination', 'duplicate block label (S06-F used twice)'),
}
def arm(block, group):
    d = s[(s.block==block)&(s.group==group)]
    return d
rows = []
def compare(block, g1, g0, label):
    a, b = arm(block, g1), arm(block, g0)
    if len(a)==0 or len(b)==0: return None
    s1, n1 = int((a.event==0).sum()), len(a); s0, n0 = int((b.event==0).sum()), len(b)
    _, pf = fisher_exact([[s1, n1-s1],[s0, n0-s0]])
    lr = logrank_test(a.time, b.time, a.event, b.event).p_value
    return dict(block=block, contrast=label, surv_trt=f'{s1}/{n1}', surv_ctl=f'{s0}/{n0}', s1=s1, n1=n1, s0=s0, n0=n0,
                RD=s1/n1 - s0/n0, fisher_p=pf, logrank_p=lr,
                events_trt_cells=';'.join(a.cell_event), events_ctl_cells=';'.join(b.cell_event))
for blk in ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-D','S06-E(d60)','S06-F(d60)','S06-G','S15-L','S15-N']:
    for g1, g0, lab in [('PSLN-344','PSLN-212','PSLN-344 vs PSLN-212 (Mn effect)'), ('PSLN-344','Sham','PSLN-344 vs Sham'),
                        ('PSLN-212','Sham','PSLN-212 vs Sham'), ('PSLN-344','PSLN-212(Y)','aged PSLN-344 vs young PSLN-212(Y)'),
                        ('PSLN-344','Untreated','PSLN-344 vs unchallenged Untreated'), ('PSLN-344','CMP-204','PSLN-344 vs CMP-204')]:
        r = compare(blk, g1, g0, lab)
        if r: rows.append(r)
for blk, pre in [('S06-E(imprint)','Naive+'),('S06-E(imprint)','Imprinting+'),('S06-F(imprint)','Naive+'),('S06-F(imprint)','Imprinting+')]:
    r = compare(blk, pre+'PSLN-344', pre+'PSLN-212', f'{pre}PSLN-344 vs {pre}PSLN-212 (Mn effect)')
    if r: rows.append(r)
r = compare('S15-H','3d Vaccine+PSLN-344','3d Vaccine','Vaccine+PSLN-344 vs Vaccine alone (d3)'); rows.append(r)
r = compare('S15-H','3d Vaccine+PSLN-344','3d PSLN-344','Vaccine+PSLN-344 vs PSLN-344 alone (d3)'); rows.append(r)
r = compare('S15-H','3d PSLN-344','3d Vaccine','PSLN-344 alone vs Vaccine alone (d3)'); rows.append(r)
for blk in ['S09-B','S09-D','S09-F']:
    rows.append(compare(blk,'PSLN-344Y','Sham','young PSLN-344 vs Sham')); rows.append(compare(blk,'PSLN-212Y','Sham','young PSLN-212 vs Sham'))
rows.append(compare('S13-E','PSLN-344(Y)','Sham','young PSLN-344 vs Sham')); rows.append(compare('S13-E','CMP-204(Y)','Sham','young CMP-204 vs Sham'))
R = pd.DataFrame([r for r in rows if r])
R['flags'] = R.block.map(lambda b: EXP.get(b, ('','','',''))[3])
R['challenge'] = R.block.map(lambda b: EXP.get(b, ('','','',''))[0])
R['day'] = R.block.map(lambda b: EXP.get(b, ('','','',''))[1])
R['model'] = R.block.map(lambda b: EXP.get(b, ('','','',''))[2])
R.to_csv('surv_contrasts.csv', index=False)
print(R[['block','contrast','surv_trt','surv_ctl','RD','fisher_p','logrank_p']].to_string())

# ---------- Mantel-Haenszel pooled risk difference (Greenland-Robins variance) ----------
def mh_rd(sub):
    num = 0; W = 0; var_num = 0
    for r in sub.itertuples():
        n1, n0 = r.n1, r.n0; N = n1+n0
        p1, p0 = r.s1/n1, r.s0/n0
        w = n1*n0/N
        num += w*(p1-p0); W += w
        var_num += (r.s1*(n1-r.s1)*n0**2/n1 + r.s0*(n0-r.s0)*n1**2/n0) / N**2 * (1)  # Greenland-Robins (1985) for RD
    rd = num/W
    se = np.sqrt(var_num)/W
    return rd, rd-1.96*se, rd+1.96*se
sets = {
 'Primary: all aged challenge expts with both arms, excl. S06-D duplicate': ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-E(d60)','S06-F(d60)','S06-G','S15-L','S15-N'],
 'Sensitivity A: only blocks with no survival/weight or provenance flag': ['S06-A','S06-B','S06-F(d60)'],
 'Sensitivity B: primary minus every flagged block except minor (keep S06-C, S15-N)': ['S06-A','S06-B','S06-C','S06-F(d60)','S15-N'],
 'Sensitivity C: primary + S06-D (as if independent)': ['S03-I','S03-J','S06-A','S06-B','S06-C','S06-D','S06-E(d60)','S06-F(d60)','S06-G','S15-L','S15-N'],
}
out = []
for lab in ['PSLN-344 vs PSLN-212 (Mn effect)','PSLN-344 vs Sham','PSLN-212 vs Sham','aged PSLN-344 vs young PSLN-212(Y)']:
    for sname, blks in sets.items():
        sub = R[(R.contrast==lab)&(R.block.isin(blks))]
        if len(sub)==0: continue
        rd, lo, hi = mh_rd(sub)
        out.append(dict(contrast=lab, set=sname, k=len(sub), surv_trt=f'{sub.s1.sum()}/{sub.n1.sum()}', surv_ctl=f'{sub.s0.sum()}/{sub.n0.sum()}',
                        pooled_RD=rd, lo=lo, hi=hi, blocks=','.join(sub.block)))
O = pd.DataFrame(out); O.to_csv('surv_pooled_MH.csv', index=False)
print(); print(O.drop(columns=['blocks']).to_string())
# long table for R stratified tests
s.to_csv('survival_clean.csv', index=False)

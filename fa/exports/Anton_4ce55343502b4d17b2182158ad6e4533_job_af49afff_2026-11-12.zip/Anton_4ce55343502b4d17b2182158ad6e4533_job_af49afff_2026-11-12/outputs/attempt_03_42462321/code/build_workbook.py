"""Assemble the evidence workbook (audit trail for every number in the memo)."""
import sys, json
sys.path.insert(0, '/tmp/work')
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill
from openpyxl.utils import get_column_letter
from integrity_log import LOG

W = '/tmp/work/'
OUT = '/tmp/outputs/PSLN-344_evidence_workbook.xlsx'

usage = None
exec(open(W + 'usage_table.py').read())   # defines USAGE

sheets = []
readme = [
    ['PSLN-344 portfolio review - evidence workbook'],
    [''],
    ['Purpose', 'Audit trail for every number in PSLN-344_portfolio_recommendation (docx/md). Each number in the memo carries an ID such as [N001].'],
    ['How to check a number', '1) Find the ID on sheet Numbers_register. 2) Open adjuvant_program_dataset.xlsx at the listed source cells (Sheet!Cell or ranges). '
                              '3) Apply the reduction described in the "reduction" column. Group-level detail for every block is on Group_summaries and Pairwise_contrasts.'],
    ['Source data', 'adjuvant_program_dataset.xlsx (15 sheets) and adjuvant_program_annotation.pdf (19 pp). Nothing else was used except where the memo says "external context".'],
    ['Conventions', 'Titres and qPCR fold-changes: geometric means, 95% t-interval on log10; ratios of geometric means with Welch t on log10. HAI values of 0 (<1:10) imputed as 5. '
                    'Flow %: mean +/- SD; differences with Welch 95% CI. Survival: survivors = event 0; Fisher, log-rank; pooled by Mantel-Haenszel RD (Sato variance), '
                    'stratified log-rank and exact CMH (R). S09-A values are stored as log10 fold.'],
    ['Sheets', ''],
    ['Numbers_register', 'Every number cited in the memo: ID, statement, value, source cells, reduction.'],
    ['Survival_by_group', 'Per block and group: n, survivors, deaths, death days, cells.'],
    ['Survival_contrasts', 'Per-experiment pairwise survival comparisons (Fisher, log-rank) with cells.'],
    ['Survival_pooled_MH', 'Mantel-Haenszel pooled risk differences by analysis set.'],
    ['Survival_stratified_R', 'Stratified log-rank and exact CMH results (R survival / mantelhaen.test).'],
    ['Group_summaries', 'All 495 group summaries (every block/analyte/timepoint/group) with cells.'],
    ['Pairwise_contrasts', 'All 1,836 pairwise contrasts within blocks (effect, 95% CI, Welch p, exact Mann-Whitney p, Tukey-adjusted p).'],
    ['Restoration_vs_young', 'Each readout in aged PSLN-344 and aged PSLN-212 as a fraction of young PSLN-212(Y).'],
    ['Integrity_log', 'All 19 integrity findings with cells, evidence, impact and handling.'],
    ['Survival_vs_weight', 'Each survival block vs its body-weight block (alive/dead inferred from weights).'],
    ['Weight_dup_trajectories', 'Pairs of animal weight trajectories in different blocks with >=3 identical same-day values (>=5 is effectively impossible by chance).'],
    ['Weight_dup_decimals', 'High-precision weight values sharing long fractional parts across blocks (positional recycling evidence).'],
    ['S11AB_pairs', 'S11-A vs S11-B values position by position.'],
    ['Subclass_relabel_check', 'S03-B/F printed quotients vs quotients recomputed from S13 raw titres (all label hypotheses).'],
    ['TfhTfr_check', 'S04-B Tfh:Tfr vs (100 - Foxp3%)/Foxp3% per animal.'],
    ['Block_usage', 'How every block was used, caveated or excluded.'],
    ['Tidy_measurements / Tidy_survival / Tidy_bodyweight', 'The full workbook extracted to long format with the source cell of every value.'],
]

wb = Workbook()
ws = wb.active; ws.title = 'README'
for r in readme:
    ws.append(r)
ws['A1'].font = Font(bold=True, size=14)
ws.column_dimensions['A'].width = 34; ws.column_dimensions['B'].width = 150
for row in ws.iter_rows(min_row=3):
    row[0].font = Font(bold=True)
    for c in row:
        c.alignment = Alignment(wrap_text=True, vertical='top')


def add_df(name, df, widths=None, wrap_cols=()):
    ws = wb.create_sheet(name[:31])
    ws.append(list(df.columns))
    for c in ws[1]:
        c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1F4E79'); c.alignment = Alignment(wrap_text=True, vertical='top')
    for rec in df.itertuples(index=False):
        ws.append([(None if (isinstance(v, float) and pd.isna(v)) else v) for v in rec])
    for i, col in enumerate(df.columns, start=1):
        w = (widths or {}).get(col)
        if w is None:
            mx = max([len(str(col))] + [len(str(v)) for v in df[col].head(200)])
            w = min(max(10, mx + 2), 60)
        ws.column_dimensions[get_column_letter(i)].width = w
        if col in wrap_cols:
            for cell in ws[get_column_letter(i)][1:]:
                cell.alignment = Alignment(wrap_text=True, vertical='top')
    ws.freeze_panes = 'A2'
    return ws


reg = pd.read_csv(W + 'register.csv')
add_df('Numbers_register', reg, widths={'id': 8, 'statement': 60, 'value': 70, 'source_cells': 60, 'reduction': 80}, wrap_cols=('statement', 'value', 'source_cells', 'reduction'))
add_df('Survival_by_group', pd.read_csv(W + 'audit_survival_by_group.csv'))
sc = pd.read_csv(W + 'surv_contrasts.csv')
sc = sc[['block', 'challenge', 'day', 'model', 'contrast', 'surv_trt', 'surv_ctl', 'RD', 'fisher_p', 'logrank_p', 'flags', 'events_trt_cells', 'events_ctl_cells']]
add_df('Survival_contrasts', sc, widths={'events_trt_cells': 40, 'events_ctl_cells': 40, 'flags': 60})
add_df('Survival_pooled_MH', pd.read_csv(W + 'surv_pooled_MH.csv'))
add_df('Survival_stratified_R', pd.read_csv(W + 'surv_stratified_R.csv'))
gs = pd.read_csv(W + 'block_summary.csv')
add_df('Group_summaries', gs, widths={'cells': 60})
add_df('Pairwise_contrasts', pd.read_csv(W + 'block_contrasts.csv'))
rs = pd.read_csv(W + 'restoration.csv')
add_df('Restoration_vs_young', rs, widths={'cells_344': 40, 'cells_212': 40, 'cells_sham': 40, 'young_cells': 40})
add_df('Integrity_log', pd.DataFrame(LOG)[['id', 'severity', 'blocks', 'cells', 'short', 'finding', 'evidence', 'impact', 'handling']].fillna(''),
       widths={'blocks': 30, 'cells': 40, 'short': 50, 'finding': 80, 'evidence': 60, 'impact': 60, 'handling': 50},
       wrap_cols=('blocks', 'cells', 'short', 'finding', 'evidence', 'impact', 'handling'))
add_df('Survival_vs_weight', pd.read_csv(W + 'bw_vs_surv.csv'), widths={'detail': 90})
td = pd.read_csv(W + 'trajectory_duplicates.csv')
td['chance_note'] = td.n_identical.map(lambda k: 'effectively impossible by chance (~7e-8 per pair)' if k >= 5 else ('unlikely by chance' if k == 4 else 'could occur by chance; supporting only'))
add_df('Weight_dup_trajectories', td)
add_df('Weight_dup_decimals', pd.read_csv(W + 'recycled_decimals_highentropy.csv'))
add_df('S11AB_pairs', pd.read_csv(W + 'audit_S11AB_pairs.csv'))
add_df('Subclass_relabel_check', pd.read_csv(W + 'audit_subclass_relabel_summary.csv'))
add_df('Subclass_relabel_detail', pd.read_csv(W + 'audit_subclass_relabel.csv'))
add_df('TfhTfr_check', pd.read_csv(W + 'audit_TfhTfr.csv'))
add_df('Block_usage', pd.DataFrame(USAGE, columns=['block', 'content', 'use_in_review', 'issues']), widths={'block': 30, 'content': 60, 'use_in_review': 50, 'issues': 30})
add_df('Tidy_measurements', pd.read_csv(W + 'measurements.csv'))
add_df('Tidy_survival', pd.read_csv(W + 'survival.csv'))
add_df('Tidy_bodyweight', pd.read_csv(W + 'bodyweight.csv'))
wb.save(OUT)
print('saved', OUT, [ws.title for ws in wb.worksheets])

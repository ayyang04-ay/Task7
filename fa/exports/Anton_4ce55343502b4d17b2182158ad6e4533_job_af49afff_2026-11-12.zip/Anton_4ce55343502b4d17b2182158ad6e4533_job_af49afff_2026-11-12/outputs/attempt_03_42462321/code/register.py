"""Numbers register: every number used in the report, with source cells and reduction method.

Numbers are computed here from the tidy tables (measurements.csv, survival.csv, bodyweight.csv) and
from the analysis outputs, so the report never relies on hand-transcribed values.
"""
import pandas as pd, numpy as np, re, json
from collections import defaultdict
from scipy import stats

W = '/tmp/work/'
m = pd.read_csv(W + 'measurements.csv'); m['analyte'] = m.analyte.fillna(''); m['timepoint'] = m.timepoint.fillna('').astype(str)
s = pd.read_csv(W + 'survival.csv'); s['group'] = s.group.str.replace('Naïve', 'Naive').str.strip()
w = pd.read_csv(W + 'bodyweight.csv')
S = pd.read_csv(W + 'block_summary.csv'); S['analyte'] = S.analyte.fillna(''); S['timepoint'] = S.timepoint.fillna('').astype(str)
K = pd.read_csv(W + 'block_contrasts.csv'); K['analyte'] = K.analyte.fillna(''); K['timepoint'] = K.timepoint.fillna('').astype(str)
SC = pd.read_csv(W + 'surv_contrasts.csv'); SP = pd.read_csv(W + 'surv_pooled_MH.csv')
RS = pd.read_csv(W + 'restoration.csv')


def colnum(c):
    n = 0
    for ch in c:
        n = n * 26 + ord(ch) - 64
    return n


def colstr(n):
    s_ = ''
    while n:
        n, r = divmod(n - 1, 26)
        s_ = chr(65 + r) + s_
    return s_


def compress(cells):
    """['S03!D3','S03!D4',...] -> 'S03!D3:D7' (contiguous runs by column, else by row)."""
    if isinstance(cells, str):
        cells = [c for c in re.split('[;,]', cells) if c]
    by_sheet = defaultdict(list)
    for c in cells:
        sh, ref = c.split('!')
        mm = re.match(r'([A-Z]+)(\d+)', ref)
        by_sheet[sh].append((colnum(mm.group(1)), int(mm.group(2))))
    out = []
    for sh, pts in by_sheet.items():
        pts = sorted(set(pts))
        # try rectangular block first
        cs = sorted(set(p[0] for p in pts)); rs = sorted(set(p[1] for p in pts))
        if len(pts) == len(cs) * len(rs) and cs == list(range(cs[0], cs[-1] + 1)) and rs == list(range(rs[0], rs[-1] + 1)):
            a = f'{colstr(cs[0])}{rs[0]}'; b = f'{colstr(cs[-1])}{rs[-1]}'
            out.append(f'{sh}!{a}' + ('' if a == b else f':{b}'))
            continue
        # runs down columns
        runs = []
        for c in cs:
            rr = sorted(p[1] for p in pts if p[0] == c)
            start = prev = rr[0]
            for r in rr[1:] + [None]:
                if r is not None and r == prev + 1:
                    prev = r; continue
                runs.append(f'{colstr(c)}{start}' + ('' if start == prev else f':{colstr(c)}{prev}'))
                if r is not None:
                    start = prev = r
        out.append(f'{sh}!' + ','.join(runs))
    return '; '.join(out)


REG = []   # list of dicts
_ids = {}


def reg(key, statement, value, cells, method):
    if key in _ids:
        return _ids[key]
    nid = f'N{len(REG) + 1:03d}'
    _ids[key] = nid
    REG.append(dict(id=nid, key=key, statement=statement, value=value, source_cells=cells if isinstance(cells, str) else compress(cells), reduction=method))
    return nid


# ------------------------------------------------------------------ helpers for measurement summaries
METH_LOG = 'geometric mean of per-animal values, 95% CI = t-interval on log10 scale, back-transformed'
METH_LIN = 'arithmetic mean ± SD of per-animal values'
METH_HAI = 'geometric mean titre; values <1:10 (recorded as 0) imputed as 5 (half the lowest dilution); 95% CI = t-interval on log10 scale'


def summ(block, group, analyte='', timepoint=''):
    d = S[(S.block == block) & (S.group == group) & (S.analyte == analyte) & (S.timepoint == timepoint)]
    assert len(d) == 1, (block, group, analyte, timepoint, len(d))
    return d.iloc[0]


def fmt_summ(r, pct=False, digits=3):
    if r.scale == 'log':
        return f'{fmt_num(r.GM, digits)} [{fmt_num(r.GM_lo, digits)}–{fmt_num(r.GM_hi, digits)}]'
    return f'{fmt_num(r["mean"], digits)}{"%" if pct else ""} ± {fmt_num(r.sd, 2)}'


def fmt_num(x, digits=3):
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return 'n/a'
    ax = abs(x)
    if ax >= 1000:
        return f'{x:,.0f}'
    if ax >= 100:
        return f'{x:.0f}'
    if ax >= 10:
        return f'{x:.1f}'
    if ax >= 1:
        return f'{x:.2f}'
    return f'{x:.2g}'


def g(block, group, analyte='', timepoint='', label=None, pct=None):
    r = summ(block, group, analyte, timepoint)
    if pct is None:
        pct = r.scale == 'linear'
    meth = METH_HAI if block in ('S03-C', 'S03-G') else (METH_LOG if r.scale == 'log' else METH_LIN)
    val = fmt_summ(r, pct)
    nid = reg(('g', block, group, analyte, timepoint), f'{label or block} — {group}' + (f' ({analyte} {timepoint})' if analyte or timepoint else ''),
              f'{val} (n={int(r.n)})', compress(r.cells), meth)
    return val, nid, r


def contrast(block, g1, g0, analyte='', timepoint='', label=None):
    d = K[(K.block == block) & (K.g1 == g1) & (K.g0 == g0) & (K.analyte == analyte) & (K.timepoint == timepoint)]
    assert len(d) == 1, (block, g1, g0, analyte, timepoint, len(d))
    r = d.iloc[0]
    c1 = S[(S.block == block) & (S.group == g1) & (S.analyte == analyte) & (S.timepoint == timepoint)].cells.values[0]
    c0 = S[(S.block == block) & (S.group == g0) & (S.analyte == analyte) & (S.timepoint == timepoint)].cells.values[0]
    if 'ratio' in r.effect_type or 'fold' in r.effect_type:
        val = f'{fmt_num(r.effect)}× [{fmt_num(r.lo)}–{fmt_num(r.hi)}]'
        meth = 'ratio of geometric means, 95% CI from Welch t on log10 values' + ('; HAI <1:10 imputed as 5' if block in ('S03-C', 'S03-G') else '')
    else:
        val = f'{r.effect:+.2f} points [{r.lo:+.2f}, {r.hi:+.2f}]'
        meth = 'difference in arithmetic means, 95% Welch CI'
    val += f'; Welch p={r.welch_p:.2g}; Mann–Whitney exact p={r.mw_exact_p:.2g}' + (('; Tukey-adjusted p<0.0001' if r.tukey_p_adj < 1e-4 else f'; Tukey-adjusted p={r.tukey_p_adj:.2g}') if not np.isnan(r.tukey_p_adj) else '')
    nid = reg(('c', block, g1, g0, analyte, timepoint), f'{label or block}: {g1} vs {g0}' + (f' ({analyte} {timepoint})' if analyte or timepoint else ''), val,
              compress(c1.split(';') + c0.split(';')), meth + '; per-animal values, two-sided tests, n per arm as stated in block')
    return val, nid, r


def survcells(block, groups):
    d = s[(s.block == block) & (s.group.isin(groups))]
    return list(d.cell_time) + list(d.cell_event)


def surv_arm(block, group):
    d = s[(s.block == block) & (s.group == group)]
    return int((d.event == 0).sum()), len(d)

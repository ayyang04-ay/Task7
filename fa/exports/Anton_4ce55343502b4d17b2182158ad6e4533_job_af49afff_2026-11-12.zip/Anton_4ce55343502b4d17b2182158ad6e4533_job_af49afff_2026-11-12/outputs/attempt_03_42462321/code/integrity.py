import pandas as pd, numpy as np, itertools, collections
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 80)
s = pd.read_csv('survival.csv'); m = pd.read_csv('measurements.csv'); w = pd.read_csv('bodyweight.csv')

print('=== 1. Survival blocks: identical ordered (time,event) vectors per group across blocks')
vec = {}
for (b,g), d in s.groupby(['block','group'], sort=False):
    vec[(b,g)] = tuple(zip(d.time.fillna(-1), d.event))
blocks = list(dict.fromkeys(s.block))
for b1, b2 in itertools.combinations(blocks, 2):
    g1 = [k for k in vec if k[0]==b1]; g2 = [k for k in vec if k[0]==b2]
    same = [(k1[1],k2[1]) for k1 in g1 for k2 in g2 if vec[k1]==vec[k2] and any(e==1 for _,e in vec[k1])]
    if len(same) >= 2:
        print(f'  {b1} vs {b2}: identical non-trivial groups: {same}')

print('\n=== 2. Measurement blocks: values shared between different blocks (same 5-vector position or >=2 shared exact values in a group)')
m['key'] = m.block + '|' + m.analyte.fillna('') + '|' + m.timepoint.fillna('').astype(str) + '|' + m.group
grp = {k: d.value.round(6).tolist() for k, d in m.groupby('key', sort=False)}
keys = list(grp)
hits = []
for k1, k2 in itertools.combinations(keys, 2):
    if k1.split('|')[0] == k2.split('|')[0] and k1.split('|')[1]==k2.split('|')[1]:
        # same block & analyte -> only flag if same position identical across >=2 positions (different timepoints/groups)
        pass
    a, b = grp[k1], grp[k2]
    pos = sum(1 for x, y in zip(a, b) if x == y)
    shared = len(set(a) & set(b))
    if pos >= 2 or shared >= 3:
        hits.append((k1, k2, pos, shared))
for h in hits:
    print('  ', h)

print('\n=== 3. Body-weight: identical values (>=5 significant decimals) appearing in >1 block')
w['v'] = w.value.round(8)
def ndec(x):
    s_ = repr(float(x))
    return len(s_.split('.')[1]) if '.' in s_ else 0
w['ndec'] = w.value.apply(ndec)
long = w[(w.ndec >= 4)]
dup = long.groupby('v').filter(lambda d: d.block.nunique() > 1 or len(d) > 1)
for v_, d in dup.groupby('v'):
    print(f'  {v_}: ' + '; '.join(f"{r.cell}({r.block} {r.group} d{int(r.day)})" for r in d.itertuples()))

print('\n=== 4. Body-weight: recycled fractional parts (>=4 decimals) with different integer parts')
long = w[(w.ndec >= 4)].copy()
long['frac'] = (long.value - np.floor(long.value)).round(6)
for f, d in long.groupby('frac'):
    if d.v.nunique() > 1:
        print(f'  frac {f}: ' + '; '.join(f"{r.cell}={r.value}({r.block} {r.group} d{int(r.day)})" for r in d.itertuples()))

"""Shared high-precision fractional parts in body-weight data (positional recycling screen)."""
import pandas as pd, numpy as np
from fractions import Fraction
w = pd.read_csv('/tmp/work/bodyweight.csv')
def ndec(x):
    s_ = repr(float(x)); return len(s_.split('.')[1]) if '.' in s_ else 0
w['ndec'] = w.value.apply(ndec); L = w[w.ndec >= 4].copy()
L['frac'] = (L.value - np.floor(L.value)).round(6)
recyc = L.groupby('frac').filter(lambda d: len(d) > 1 and (d.block.nunique() > 1 or d.value.round(6).nunique() > 1))
recyc = recyc.drop_duplicates(subset=['block', 'col', 'value'])
recyc[['cell', 'block', 'group', 'day', 'value', 'frac']].to_csv('/tmp/work/recycled_decimals.csv', index=False)
r = recyc[['cell', 'block', 'group', 'day', 'value', 'frac']].copy()
r['col'] = r.cell.str.extract(r'!([A-Z]+)\d+')[0]
small = lambda f: abs(float(Fraction(f).limit_denominator(40)) - f) < 2e-6
r['small_den'] = r.frac.apply(small)
g = r[~r.small_den].groupby('frac').filter(lambda d: d[['block', 'col']].drop_duplicates().shape[0] >= 2)
g.to_csv('/tmp/work/recycled_decimals_highentropy.csv', index=False)
print('high-entropy shared fractional parts:', g.frac.nunique(), 'cells:', len(g), 'blocks:', sorted(g.block.unique()))

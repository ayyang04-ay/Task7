import pandas as pd, numpy as np
s = pd.read_csv('survival.csv'); w = pd.read_csv('bodyweight.csv')
pairs = {'S15-A':'S06-A','S15-B':'S06-B','S15-C':'S06-C','S15-D':'S06-D','S15-E':'S06-E(d60)','S15-F':'S06-F(d60)',
         'S15-G':'S06-G','S15-I':'S15-H','S15-J':'S06-E(imprint)','S15-K':'S06-F(imprint)','S15-M':'S15-L','S15-O':'S15-N',
         'S09-C':'S09-B','S09-E':'S09-D','S09-G':'S09-F'}
norm = lambda x: x.replace('Naïve','Naive').replace('PSLN-212Y','PSLN-212(Y)').replace('PSLN-344Y','PSLN-344(Y)').strip()
out=[]
for wb_, sb in pairs.items():
    W = w[w.block==wb_]; days = sorted(W.day.unique())
    for grp, d in W.groupby('group', sort=False):
        S = s[(s.block==sb) & (s.group.apply(norm)==norm(grp))]
        D = sorted(S[S.event==1].time.tolist())
        # number of animals with a *real* (non-carried-forward) weight at each day
        alive_w = {}
        for day in days:
            cnt = 0
            for a, da in d.groupby('animal'):
                da = da.sort_values('day'); vals = da.value.round(4).tolist(); dd = da.day.tolist()
                if day not in dd: continue
                i = dd.index(day)
                carried = i>0 and vals[i]==vals[i-1] and all(vals[j]==vals[i] for j in range(i, len(vals)))
                if not carried: cnt += 1
            alive_w[day] = cnt
        n = len(S)
        # expected alive at day t per survival: animals whose death day >= t (weighed on day of death) 
        exp_hi = {day: n - sum(1 for x in D if x < day) for day in days}
        exp_lo = {day: n - sum(1 for x in D if x <= day) for day in days}
        bad = [f'd{int(day)}: weights={alive_w[day]} vs surv-alive {exp_lo[day]}-{exp_hi[day]}' for day in days if not (exp_lo[day] <= alive_w[day] <= exp_hi[day])]
        if bad:
            out.append(f'{wb_}/{sb} [{grp}] deaths={D}: ' + '; '.join(bad))
print('\n'.join(out))

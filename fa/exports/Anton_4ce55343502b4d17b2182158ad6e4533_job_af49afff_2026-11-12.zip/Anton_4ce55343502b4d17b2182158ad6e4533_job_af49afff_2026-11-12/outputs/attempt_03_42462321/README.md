# PSLN-344 portfolio review — deliverables

| File | What it is |
|---|---|
| PSLN-344_portfolio_recommendation.docx | Decision memo for the committee (recommendation, efficacy case, integrity audit, mechanism, biomarker, clinical role, gated study plan, ruled-out list, "if we drop it"). Every number carries a register ID [Nxxx]. |
| PSLN-344_portfolio_recommendation.md | Same memo in Markdown. |
| PSLN-344_evidence_workbook.xlsx | Audit trail: Numbers_register (ID → value → source cells → reduction), all group summaries and contrasts, survival analyses, integrity evidence, block-usage map, and the full workbook in tidy form with cell references. |
| figures/ | fig1 survival forest plot; fig2 restoration profile vs young; fig3 integrity evidence; fig4 mechanism data; fig5 evidence map. |
| code/ | Reproducible pipeline (run_all.sh) including independent verification scripts that re-read the raw workbook cells and recompute every cited value. |

To check any number: find its ID in Numbers_register, open adjuvant_program_dataset.xlsx at the listed cells, apply the stated reduction.

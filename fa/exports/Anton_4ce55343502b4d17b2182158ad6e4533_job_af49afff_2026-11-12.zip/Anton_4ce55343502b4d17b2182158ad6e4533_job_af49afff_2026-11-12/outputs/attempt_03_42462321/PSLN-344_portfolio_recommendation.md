---
title: "PSLN-344 (Mn²⁺-STING surfactant-biomimetic liposome): portfolio review recommendation and evidence"
subtitle: "Intranasal adjuvant for inactivated influenza vaccine in older adults — decision memo for the portfolio committee"
---

**Basis.** All analysis uses only the programme data: *adjuvant_program_dataset.xlsx* (15 sheets; 2,121 per-animal measurements, 527 per-animal survival records, 3,472 body-weight values) and *adjuvant_program_annotation.pdf* (19 pp). Every number below carries a register ID in square brackets, e.g. [N001]. The register (Evidence workbook, sheet **Numbers_register**) gives for each ID the exact source cells and the reduction applied. General reduction rules are in Appendix A. Where I rely on general scientific knowledge rather than our data, the text says so explicitly ("external context").

# 1. Recommendation

**ADVANCE — conditionally.** Fund a time-boxed (about 9–12 months) confirmation and de-risking stage with pre-set kill criteria (Section 7). Do **not** yet commit IND-enabling GLP toxicology or GMP scale-up, and do **not** use the current data package externally (partners, regulators, publications) until it has been verified against source records.

| Question | Answer | Where defended |
|----------------------|----------------------------------------------------------------------|------------|
| Do we advance? | **Yes, conditionally:** a gated 9–12-month confirmation stage; no IND-enabling spend until Gates 1–4 pass. | §1, §7 |
| What drives protection? | An antigen-specific adaptive response made possible by Mn²⁺ raising the ceiling of STING signalling (IFN-β, GM-CSF, monocyte-derived DCs). Antibody accounts for homologous protection; heterosubtypic and durable protection tracks a cross-reactive CD8 arm that Mn²⁺ only partly restores. Not an innate antiviral state. | §4 |
| Biomarker worth carrying forward? | Two: early nasal/blood interferon signature as the PD and dose-setting marker (not an efficacy correlate); cross-reactive CD8 IFN-γ as the lead efficacy candidate for breadth, with HAI/MN as the regulatory anchor and nasal IgA to be added. None validated yet. | §5 |
| Could it go into patients, in what role? | Not yet; first-in-human around month 20–24. Role: intranasal (or inhaled) mucosal adjuvant with inactivated antigen for adults ≥65 — first as an add-on to licensed IM vaccination, strategically as a pandemic H5 component. Not a stand-alone prophylactic, not a young-adult product. | §6 |
| Next studies | Source-data verification (weeks 0–8); blinded, benchmarked aged-mouse efficacy with clinical antigen and a Mn²⁺-only control (months 2–9); mechanism-of-protection depletions/transfers; route and antigen-format study; intranasal Mn²⁺ CNS biodistribution/neurotoxicity; CMC; then ferret and GLP toxicology. | §7 |
| What we would drop, and why | A +71-point survival effect in aged mice [N001] with a specific mechanism and PD marker — dropped only if the data do not verify, intranasal Mn²⁺ is unsafe, or the effect does not survive human-relevant delivery/antigen or beat standard of care. | §9 |

**Why advance.** The efficacy signal is large enough, consistent enough and mechanistically specific enough that it survives removal of every data block I could not trust:

1. **Mn²⁺ raises survival of aged mice from 12% to 84%.** Across the 10 aged-mouse challenge experiments that contain both arms, PSLN-344 vs its Mn-free parent PSLN-212: 61/73 vs 9/73; MH risk difference +0.71 [+0.60, +0.82] [N001] (stratified log-rank p = 9×10⁻²⁰). Using **only** the three experiments with no integrity flag: 16/21 vs 2/21; MH risk difference +0.67 [+0.45, +0.89] [N002]. Against sham (antigen + empty liposome): 61/73 vs 1/73; MH risk difference +0.82 [+0.73, +0.91] [N005].
2. **The benefit replicates across conditions:** four challenge viruses (homologous CA09 H1N1; heterosubtypic PR8 H1N1, rgH5N1, Perth H3N2; wild-type H5N1), three mouse backgrounds (BALB/c; C57BL/6 6/7 vs 0/7 [N018]; Swiss Webster 6/7 vs 2/7 [N019]), challenge 2–60 days after a single dose, and in animals with prior influenza infection (Perth H3N2 after PR8 imprinting: PSLN-344 6/7 vs PSLN-212 0/7 [N027]).
3. **The gain is specific to Mn²⁺ and cannot be bought with more PSLN-212.** Mn²⁺ is the only compositional difference; CDN-1807 encapsulation is not higher (54.8% ± 5.08 vs 59.6% ± 4.55 [N336]). Mn²⁺ raises the *ceiling* of lung IFN-β output: fitted Emax 55.3 vs 13.7-fold [N330], [N329]; PSLN-212 is already on its plateau at 20 µg (20 µg gives 0.85 [0.59–1.23]× the 40 µg response [N334]).
4. **Antibody responses in aged mice reach near-young levels.** Day-14 HAI against CA09 H1N1 (geometric mean titre): PSLN-344 368 [179–755] [N043], PSLN-212 45.9 [31.3–67.5] [N042], young PSLN-212 485 [303–777] [N044]. Homologous lethal challenge: PSLN-344 7/7, PSLN-212 0/7, young 7/7 [N009].
5. **No tolerability signal in the limited mouse data.** Post-vaccination weight nadir 96.4% of baseline vs 98.2% for antigen alone (difference -1.8 points; Welch p=0.065) [N342], [N344], [N345]; no induction of Ifnb1, Tnf or Isg15 in CNS tissue at 36 h (PSLN-344 vs sham 1.14× [0.69–1.86], 1.20× [0.77–1.87], 1.08× [0.84–1.41]) [N347], [N349], [N351], whereas the intranasal cholera-toxin control raised CNS Ifnb1 5.54× over PBS [N348].

**Why conditional.**

1. **The data package fails basic integrity checks** (Section 3): one survival block is a row-for-row copy of another (S06-D = S06-C); challenge body weights are recycled between experiments; two flow blocks share 35% of their values; two derived blocks carry rotated group labels; two body-weight blocks contradict the survival blocks they belong to; and unvaccinated, unchallenged 20-month controls died (4/21 within 14 days [N032]). The statistics above are robust to removing every problem I could detect, but not to problems I cannot detect from a spreadsheet. Source-data verification is therefore Gate 1.
2. **No comparison against what older adults receive today.** Every comparator is internal (sham, PSLN-212, cGAMP liposome CMP-204, young mice). There is no arm with a licensed older-adult approach (high-dose antigen or an MF59-type emulsion, intramuscular), so we cannot say PSLN-344 adds value over standard of care.
3. **Intranasal Mn²⁺ safety in the target population is unmeasured.** The only CNS data are three transcripts at one timepoint in n = 5 per group; the study could only have detected ≥1.4–2.0-fold changes [N353]. There are no Mn²⁺ tissue levels, no olfactory-bulb or nasal histopathology, no repeat-dose data and no Mn²⁺ content for the formulation (external context: the olfactory route is a recognised path for Mn²⁺ into the brain, and intranasal adjuvants have a history of facial-nerve adverse events).
4. **Restoration is partial.** Aged PSLN-344 survival remains below young: 51/63 vs 62/63; MH risk difference -0.17 [-0.28, -0.07] [N007]; the shortfall sits in heterosubtypic challenges at day 60 (aged PSLN-344 14/21 vs young PSLN-212(Y) 21/21, Fisher p = 0.0086 [N023]). DC costimulation stays at 29%–38% of young [N371], [N372] and the memory CD8 response at about 69% [N393].
5. **Translation gaps that could erase the effect in people:** the antigen was formalin-inactivated *whole* virus (internal proteins present; clinical seasonal vaccines are split/subunit); the formulation is designed to reach alveolar cells (AECII and SP-A/D-dependent macrophage uptake), which a human nasal spray does not reach; only female mice were used; there is no Mn²⁺-only control, so we do not know whether the CDN is needed.

**The bottom line for the committee:** PSLN-344 has the strongest single-dose protection signal in aged animals in this dataset, and the Mn²⁺ mechanism is specific and testable. The package is not yet credible enough, or comparative enough, to justify IND-enabling spend. A bounded confirmation stage answers the four questions that decide the asset (is it real, is it better than standard of care, is intranasal Mn²⁺ safe, does it survive translation) before any IND-enabling money is committed.

# 2. The efficacy case, in numbers

## 2.1 Survival after lethal challenge (aged mice, single intranasal dose of antigen + 20 µg adjuvant)

Table 1. Fourteen-day survival (survivors/animals) by experiment. Source cells and statistics for each row are in the register entry cited.

| Block | Challenge (virus, timing after vaccination) | Sham | PSLN-212 | PSLN-344 | Young PSLN-212 | PSLN-344 vs PSLN-212 (Fisher p / log-rank p) | Integrity flags | Ref |
|--------|--------------------------|------|-------|-------|-------|--------------|------------|------|
| S03-I | CA09 H1N1 10×LD50, homologous, challenge d14 | 0/7 | 0/7 | 7/7 | 7/7 | 0.00058 / 0.00035 | I-05 | [N009] |
| S03-J | wild-type VN04 H5N1, rgH5N1 vaccine, challenge d2 | 1/10 | 3/10 | 10/10 | — | 0.0031 / 0.0014 | I-05, I-13 | [N010] |
| S06-A | PR8 H1N1 5×LD50, heterosubtypic (Aichi H3N2 vaccine), d14 | 0/7 | 1/7 | 6/7 | 7/7 | 0.029 / 0.0083 | — | [N011] |
| S06-B | PR8 H1N1, heterosubtypic, d3 | 0/7 | 0/7 | 5/7 | 7/7 | 0.021 / 0.00092 | — | [N012] |
| S06-C | rgH5N1 5×LD50, heterosubtypic (bivalent vaccine), d14 | 0/7 | 2/7 | 7/7 | 7/7 | 0.021 / 0.0068 | I-06 (minor) | [N013] |
| S06-D | rgH5N1, d3 (copy of S06-C) | 0/7 | 2/7 | 7/7 | 7/7 | 0.021 / 0.0068 | I-01 (excluded) | [N014] |
| S06-E(d60) | PR8 H1N1, heterosubtypic, d60 | 0/7 | 0/7 | 5/7 | 7/7 | 0.021 / 0.0016 | I-06, I-07 | [N015] |
| S06-F(d60) | rgH5N1, heterosubtypic, d60 | 0/7 | 1/7 | 5/7 | 7/7 | 0.1 / 0.0094 | I-07 (control arm) | [N016] |
| S06-G | Perth H3N2, heterosubtypic (CA09 vaccine), d60 | 0/7 | 0/7 | 4/7 | 7/7 | 0.07 / 0.015 | I-06, I-07 | [N017] |
| S15-L | aged C57BL/6, bivalent vaccine (challenge not stated) | 0/7 | 0/7 | 6/7 | 6/7 | 0.0047 / 0.0011 | I-06, I-16 | [N018] |
| S15-N | aged Swiss Webster, bivalent vaccine (challenge not stated) | 0/7 | 2/7 | 6/7 | 7/7 | 0.1 / 0.056 | I-16 | [N019] |

Extra arms not shown: CMP-204 (cGAMP liposome) in S03-I 3/7; unvaccinated, unchallenged "Untreated" controls in S06-E/F/G 6/7, 7/7, 4/7 survived [N032].

![Figure 1. Survival differences by experiment and pooled. A: PSLN-344 minus PSLN-212 (the Mn²⁺ effect). B: aged PSLN-344 minus young PSLN-212 (restoration). Orange = block carrying an integrity flag; grey = excluded duplicate (S06-D).](figures/fig1_survival_forest.png)

**Pooled estimates** (Mantel–Haenszel risk difference with Sato variance; stratified log-rank; exact conditional CMH):

| Comparison | Analysis set | Result | Ref |
|--------------|--------------------------|----------------------------------------------------|------|
| PSLN-344 vs PSLN-212 | Primary: 10 experiments (S06-D excluded as a copy) | 61/73 vs 9/73; MH risk difference +0.71 [+0.60, +0.82]; stratified log-rank chi2 = 82.7, p = 9.4e-20; exact CMH p = 1.9e-19 | [N001] |
| PSLN-344 vs PSLN-212 | Unflagged + minor-flag experiments (S06-A, S06-B, S06-C, S06-F, S15-N) | 29/35 vs 6/35; MH risk difference +0.66 [+0.49, +0.83]; stratified log-rank chi2 = 34.8, p = 3.7e-9; exact CMH p = 5.4e-8 | [N003] |
| PSLN-344 vs PSLN-212 | Unflagged experiments only (S06-A, S06-B, S06-F) | 16/21 vs 2/21; MH risk difference +0.67 [+0.45, +0.89]; stratified log-rank chi2 = 24.4, p = 7.9e-7; exact CMH p = 3.6e-5 | [N002] |
| PSLN-344 vs PSLN-212 | Primary + S06-D counted as if independent (for reference only) | 68/80 vs 11/80; MH risk difference +0.71 [+0.61, +0.82]; stratified log-rank chi2 = 90.0, p = 2.3e-21; exact CMH p = 2.4e-21 | [N004] |
| PSLN-344 vs sham | Primary | 61/73 vs 1/73; MH risk difference +0.82 [+0.73, +0.91]; stratified log-rank chi2 = 134.3, p = 4.8e-31; exact CMH p = 5.2e-27 | [N005] |
| PSLN-212 vs sham | Primary | 9/73 vs 1/73; MH risk difference +0.11 [+0.03, +0.19]; stratified log-rank chi2 = 35.1, p = 3.1e-9; exact CMH p = 0.015 | [N006] |
| Aged PSLN-344 vs young PSLN-212 | Primary (9 experiments with a young arm) | 51/63 vs 62/63; MH risk difference -0.17 [-0.28, -0.07]; stratified log-rank chi2 = 10.3, p = 0.0013; exact CMH p = 0.0022 | [N007] |
| Aged PSLN-344 vs young PSLN-212 | Unflagged experiments only | 16/21 vs 21/21; MH risk difference -0.24 [-0.42, -0.06]; stratified log-rank chi2 = 5.3, p = 0.021; exact CMH p = 0.053 | [N008] |

Reading: the Mn²⁺ effect is +0.66 to +0.71 in absolute survival whichever set is used; including the duplicated block changes nothing, which is why excluding it is a matter of integrity, not of outcome. PSLN-212 alone is only marginally better than sham in aged mice (+0.11). Aged PSLN-344 is still 17 points below young animals.

**Where the shortfall against young animals sits** (counts summed within challenge type):

| Challenge type | Experiments | Aged PSLN-344 | Young PSLN-212 | Aged PSLN-212 | Sham | Fisher p (aged PSLN-344 vs young) | Ref |
|--------------|------------------|---------|---------|---------|-------|----------|------|
| homologous d14 | S03-I | 7/7 | 7/7 | 0/7 | 0/7 | 1 | [N020] |
| heterosubtypic d14 | S06-A, S06-C | 13/14 | 14/14 | 3/14 | 0/14 | 1 | [N021] |
| heterosubtypic d3 | S06-B | 5/7 | 7/7 | 0/7 | 0/7 | 0.46 | [N022] |
| heterosubtypic d60 | S06-E(d60), S06-F(d60), S06-G | 14/21 | 21/21 | 1/21 | 0/21 | 0.0086 | [N023] |
| other backgrounds | S15-L, S15-N | 12/14 | 13/14 | 2/14 | 0/14 | 1 | [N024] |

The gap is zero for the homologous (HA-matched) challenge and largest for heterosubtypic challenge at day 60 — the condition in which HA-neutralising antibody cannot explain protection and memory T cells are the prime candidate. If S06-G is set aside because its unchallenged controls also died (3/7), the day-60 comparison is 10/14 vs 14/14 (Fisher p = 0.098) [N404], so the durability gap is suggestive rather than proven.

**Other survival evidence.**

- *Antigen is required* (S15-H, challenge 3 days after dosing): 3d Vaccine 0/7; 3d PSLN-344 0/7; 3d Vaccine+PSLN-344 6/7; Vaccine+PSLN-344 vs either single component Fisher p=0.0047 [N025]. Caveat: the matching weight block S15-I reuses S15-C weights (I-02).
- *Prior exposure does not blunt the effect* (14-month mice, half infected with PR8 at 10 months). PR8 challenge: Naive+PSLN-212 0/7; Imprinting+PSLN-212 4/7; Naive+PSLN-344 6/7; Imprinting+PSLN-344 6/7 [N026]. Perth H3N2 challenge: Naive+PSLN-212 0/7; Imprinting+PSLN-212 0/7; Naive+PSLN-344 6/7; Imprinting+PSLN-344 6/7 [N027]. (Imprinted PSLN-212 animals survived PR8 because they had already been infected with PR8.)
- *Young animals need no Mn²⁺:* PR8 Sham 0/8; PSLN-344Y 8/8; PSLN-212Y 8/8 [N028]; Perth H3N2 Sham 0/8; PSLN-344Y 8/8; PSLN-212Y 8/8 [N029]; rgH5N1 at day 180 Sham 0/7; PSLN-344Y 8/8; PSLN-212Y 8/8 [N030]; CA09 10×LD50 Naive 0/7; Sham 1/7; CMP-204(Y) 7/7; PSLN-344(Y) 7/7 [N031]. PSLN-212 already gives complete protection in young mice, so the asset's value is age-specific.

## 2.2 Immunogenicity and immune mechanism (aged mice unless stated; n = 5 per group)

Table 2. Key immune readouts. Titres and qPCR: geometric mean [95% CI]; flow cytometry: mean ± SD (%). "Mn effect" = PSLN-344 vs PSLN-212; "vs young" = aged PSLN-344 vs young PSLN-212(Y).

| Readout (block) | Sham | PSLN-212 | PSLN-344 | Young PSLN-212 | Mn effect [95% CI] | Aged PSLN-344 vs young |
|--------------------|------------|-------------|-------------|-------------|--------------|---------------|
| Lung Ifnb1 mRNA, 16 h (S01-A) | 0.94 [0.57–1.54] [N209] | 16.5 [14.0–19.5] [N210] | 36.9 [31.6–43.1] [N211] | 37.5 [33.5–41.9] [N212] | 2.23× [1.85–2.69] [N213] | 0.98× [0.84–1.16], p=0.82 [N214] |
| Lung Ifnb1 mRNA, 72 h (S01-A) | 0.98 [0.79–1.22] [N215] | 3.41 [2.97–3.92] [N216] | 4.17 [2.54–6.83] [N217] | 1.46 [0.79–2.71] [N218] | 1.22× [0.75–1.99] [N219] | 2.85× [1.47–5.51], p=0.0067 [N220] |
| Lung monocytes, d4 (S01-D) | 10.4% ± 0.6 [N221] | 16.7% ± 1.63 [N222] | 30.6% ± 4.68 [N223] | 32.2% ± 3.95 [N224] | +13.8 points [+8.1, +19.5] [N225] | -1.7 points [-8.0, +4.7], p=0.56 [N226] |
| Lung CD11b+ DC, d4 (S01-E) | 4.80% ± 2.10 [N233] | 8.28% ± 1.92 [N234] | 18.9% ± 8.57 [N235] | 21.4% ± 1.68 [N236] | +10.6 points [+0.1, +21.1] [N237] | -2.5 points [-13.1, +8.0], p=0.55 [N238] |
| Lung CCR7+ migratory DC, 72 h (S02-A) | 2.54% ± 0.66 [N155] | 7.28% ± 2.04 [N156] | 30.7% ± 7.86 [N157] | 35.0% ± 4.83 [N158] | +23.4 points [+13.8, +33.0] [N159] | -4.3 points [-14.2, +5.5], p=0.33 [N160] |
| CD40+ MLN CD11b+ DC, d3 (S02-D) | 3.96% ± 1.04 [N167] | 5.56% ± 1.12 [N168] | 11.2% ± 3.00 [N169] | 38.7% ± 7.30 [N170] | +5.6 points [+2.0, +9.3] [N171] | -27.5 points [-36.4, -18.6], p=0.00042 [N172] |
| CD86+ MLN CD11b+ DC, d3 (S02-D) | 7.18% ± 1.51 [N173] | 8.13% ± 1.79 [N174] | 14.5% ± 2.71 [N175] | 37.9% ± 5.54 [N176] | +6.4 points [+3.0, +9.9] [N177] | -23.4 points [-30.2, -16.6], p=0.00017 [N178] |
| ICOS-high Tfh, d7 (S04-A) | 0.3% ± 0.16 [N203] | 3.82% ± 0.85 [N204] | 10.3% ± 3.16 [N205] | 13.6% ± 1.64 [N206] | +6.4 points [+2.6, +10.3] [N207] | -3.4 points [-7.3, +0.5], p=0.078 [N208] |
| Tfr (Foxp3+), d7 (S04-B) | 22.6% ± 4.40 [N143] | 26.7% ± 6.67 [N144] | 10.8% ± 1.78 [N145] | 7.12% ± 3.67 [N146] | -15.9 points [-24.0, -7.7] [N147] | +3.7 points [-0.8, +8.2], p=0.092 [N148] |
| Tfr (Foxp3+), d30 (S04-C) | 13.9% ± 1.83 [N149] | 18.0% ± 3.80 [N150] | 14.0% ± 3.24 [N151] | 7.40% ± 1.62 [N152] | -4.0 points [-9.2, +1.1] [N153] | +6.6 points [+2.6, +10.6], p=0.0068 [N154] |
| GC B cells, d7 (S03-K) | 1.18% ± 0.4 [N089] | 2.34% ± 0.52 [N090] | 6.54% ± 1.54 [N091] | 9.82% ± 3.05 [N092] | +4.2 points [+2.3, +6.1] [N093] | -3.3 points [-7.0, +0.5], p=0.076 [N094] |
| IgG anti-CA09, d14 (S03-A) | 55.7 [18.9–164] [N033] | 393 [210–737] [N035] | 7,305 [4,081–13,076] [N036] | 11,959 [7,242–19,747] [N037] | 18.6× [9.11–37.9] [N038] | 0.61× [0.32–1.16], p=0.11 [N039] |
| HAI anti-CA09, d14 (S03-C) | 7.58 [4.73–12.1] [N040] | 45.9 [31.3–67.5] [N042] | 368 [179–755] [N043] | 485 [303–777] [N044] | 8.00× [3.91–16.4] [N045] | 0.76× [0.36–1.58], p=0.4 [N046] |
| Neutralisation anti-CA09, d14 (S03-D) | 52.2 [25.4–107] [N047] | 418 [203–859] [N049] | 3,840 [1,338–11,018] [N050] | 6,686 [3,254–13,737] [N051] | 9.19× [3.10–27.2] [N052] | 0.57× [0.19–1.70], p=0.27 [N053] |
| HAI anti-Aichi H3N2, d14 (S03-G) | 10.0 [5.44–18.4] [N061] | 34.8 [16.9–71.5] [N063] | 320 [174–588] [N064] | 368 [250–540] [N065] | 9.19× [4.18–20.2] [N066] | 0.87× [0.47–1.61], p=0.61 [N067] |
| Neutralisation anti-Aichi, d14 (S03-H) | 39.6 [24.7–63.4] [N068] | 276 [134–566] [N070] | 2,533 [1,173–5,471] [N071] | 4,411 [2,147–9,063] [N072] | 9.19× [3.83–22.1] [N073] | 0.57× [0.24–1.38], p=0.18 [N074] |
| IgG anti-CA09, d28 after boost (S13-I) | 56.6 [7.68–418] [N075] | 4,411 [2,486–7,828] [N077] | 15,651 [6,767–36,194] [N078] | 40,739 [18,905–87,790] [N079] | 3.55× [1.50–8.41] [N080] | 0.38× [0.15–0.99], p=0.048 [N081] |
| Lung GZMB+ CD8, d3 (S05-E) | 0.99% ± 0.38 [N125] | 2.99% ± 0.78 [N126] | 5.69% ± 0.9 [N127] | 9.61% ± 1.21 [N128] | +2.7 points [+1.5, +3.9] [N129] | -3.9 points [-5.5, -2.3], p=0.00053 [N130] |
| MLN IFN-γ+ CD8 (H5 restim), d14 (S05-F) | 0.67% ± 0.36 [N095] | 1.50% ± 0.39 [N096] | 6.36% ± 1 [N097] | 9.18% ± 0.9 [N098] | +4.9 points [+3.6, +6.1] [N099] | -2.8 points [-4.2, -1.4], p=0.0016 [N100] |
| MLN IFN-γ+ CD8 (H5 restim), d60 (S05-G) | 1.46% ± 1.07 [N101] | 3.04% ± 1.25 [N102] | 9.86% ± 2.81 [N103] | 14.4% ± 2.94 [N104] | +6.8 points [+3.4, +10.3] [N105] | -4.5 points [-8.7, -0.3], p=0.038 [N106] |
| Lung CD8 TRM, d25 (S05-I; conditions ambiguous, I-09) | 0.58% ± 0.31 [N113] | 1.00% ± 0.37 [N114] | 3.96% ± 0.62 [N115] | 6.04% ± 0.6 [N116] | +3.0 points [+2.2, +3.7] [N117] | -2.1 points [-3.0, -1.2], p=0.00068 [N118] |
| IgG2a/IgG1 anti-CA09, d14 (recomputed from S13-A/B) | — | 0.54 [0.33–0.90] (n=5) [N274] | 1.85 [0.87–3.94] (n=5) [N275] | 2.50 [1.05–5.95] (n=5) [N276] | Welch p=0.0073 | — |
| IgG2a/IgG1 anti-Aichi, d14 (recomputed from S13-C/D) | — | 0.46 [0.25–0.86] (n=5) [N277] | 2.30 [1.02–5.18] (n=5) [N278] | 2.79 [1.91–4.09] (n=5) [N279] | Welch p=0.0028 | — |

![Figure 2. Restoration profile: each readout in aged PSLN-344 (colour) and aged PSLN-212 (grey) as a percentage of young PSLN-212.](figures/fig2_restoration_profile.png)

**What Figure 2 shows.** Mn²⁺ brings the *quantity* of the early (afferent) response to young levels — lung IFN-β at 16 h 98% of young [N364], monocyte recruitment 95% [N365], migratory DC 88% [N368] — and brings HAI to 76%–87% of young (not significantly different) [N375], [N378]. It does **not** restore the *quality* of DC activation (CD40 29%, CD86 38% of young [N371], [N372]), and the CD8 effector/memory arm sits at 59%–80% of young (5 of 8 CD8 readouts significantly below young) [N389], [N391]. Tfr frequency, suppressed at day 7, rebounds to sham levels by day 30 in aged animals (14.0% ± 3.24 [N151] vs young 7.40% ± 1.62 [N152]), and lung IFN-β is still 285% of the young value at 72 h [N396] — a slower-resolving innate response.

# 3. What the data can and cannot bear

Before using any block I checked it against the annotation, against the other blocks that measure the same animals or quantities, and for internal arithmetic consistency. I screened every pair of groups in the workbook for shared values, every pair of animal weight trajectories for shared same-day values, and every survival block against its own body-weight block. Nineteen issues were found; the consequential ones are below (full log with cell references: Appendix B and workbook sheet **Integrity_log**).

| ID | Severity | Where | What was found | How handled |
|-----|-------|------------------|----------------------------------------|------------------------------|
| I-01 | Critical | S06-D vs S06-C | Day-3 rgH5N1 survival block is a row-for-row copy of the day-14 block (28/28 animals identical); its own weight block implies different outcomes. [N405] | Excluded from all primary and sensitivity sets except Sens-C (shown only to demonstrate it does not change the conclusion). |
| I-02 | Critical | S08-D, S09-C/E/G, S13-F/G, S15-A to S15-O (body weight) | Challenge body weights recycled across experiments: 17 animal trajectories with ≥5 identical same-day values, whole copied rows, and positional decimal recycling (e.g. S08-D → S15-F). [N406] | No efficacy claim uses challenge body weights. Weights used only to cross-check survival counts (I-06) and for S08-D reactogenicity (caveated). |
| I-03 | Major | S11-A (alveolar macrophages) vs S11-B (neutrophils) | 35/100 same-position values identical between two different cell populations (chance ≈1.5/100). [N407] | Both excluded. |
| I-04 | Major | S03-B, S03-F (IgG2a/IgG1 quotients) vs S13-A to S13-D (raw subclass titres) | IgG2a/IgG1 group labels rotated; as printed PSLN-344 looks Th2-skewed, raw titres show the opposite. [N408] | Subclass ratios recomputed from S13; S03-B/F not used. |
| I-05 | Major | S13-F vs S03-I; S13-G vs S03-J | Weight blocks for the homologous (S03-I) and wild-type H5N1 (S03-J) survival animals have different group sets and contradict the survival records. | S03-I and S03-J kept in the primary set but flagged; excluded in Sens-A/Sens-B. |
| I-06 | Major | S06-C/S15-C, S06-E(d60)/S15-E, S06-G/S15-G, S15-L/S15-M, S09-F/S09-G, S09-B/S09-C | Death counts/timing disagree with their own weight blocks in 6 pairs (e.g. S06-G PSLN-344 deaths on d8–11 but all 7 weighed on d12). | Flagged blocks dropped in sensitivity sets Sens-A/Sens-B. |
| I-07 | Major | S06-E(d60), S06-F(d60), S06-G "Untreated" | Unvaccinated, unchallenged 20-month controls died: 4/21 within 14 days, with little weight loss. [N032] | Day-60 results (S06-E/F/G) reported with this caveat; S06-E and S06-G carry flags. Colony health records required (Gate 1). |
| I-08 | Major | S15 weight blocks | Dead animals’ weights carried forward in some groups, deleted in others. | Weights not used for efficacy. |
| I-09 | Major | S05-A, S05-B (and S05-I by reference) | NP-tetramer blocks: n = 2 of stated 3; OVA vs influenza vaccine contradiction; H-2Db epitope in BALB/c. | S05-A/B excluded; S05-I used with caveat. |

![Figure 3. Integrity evidence. a: S11-A vs S11-B paired values. b: S03-B/F printed quotients vs quotients recomputed from raw S13 titres. c: weights of two different experiments (S15-C, S15-I). d: S06-D vs S06-C survival.](figures/fig3_integrity_evidence.png)

**What this means for the decision.** (i) The central claim — Mn²⁺ improves survival in aged mice — does not depend on any compromised block: it holds in the three experiments with no flag at all (Table 1, Figure 1). (ii) Several secondary claims in the programme narrative do depend on compromised blocks and should be withdrawn until re-run: day-3 rgH5N1 protection as shown in S06-D (a copy of S06-C; the only independent day-3 rgH5N1 data are S15-H, vaccine + PSLN-344 6/7 [N025], whose weight block is also copied), "PSLN-344 skews towards Th2" or any subclass claim read from S03-B/F (labels rotated; the raw data show the opposite), any alveolar-macrophage or neutrophil kinetics (S11-A/B), any morbidity (weight-loss) claim after challenge (recycled weights), any claim about Mn²⁺ changing epithelial uptake (S08-C), and the macrophage-transfer result (S07-C). (iii) The pattern — copying, relabelling and recycling across many sheets — is a process problem, not a single typo. Until source records are checked we cannot rule out problems that leave no fingerprint in a spreadsheet, which is why Gate 1 comes before any further spend.

# 4. What is actually driving the protection?

Short answer: **an antigen-specific adaptive response that Mn²⁺ makes possible in aged animals by raising the ceiling of STING signalling; antibody explains the homologous protection, and the heterosubtypic and long-term protection tracks a cross-reactive CD8 T-cell arm that Mn²⁺ only partly restores.** The upstream steps are supported by intervention experiments; the link from any immune effector to survival has never been tested. Layer by layer:

**(a) It is not an innate antiviral state.** PSLN-344 given without antigen three days before challenge protected 0/7 aged mice; antigen alone 0/7; the combination 6/7 [N025]. Adjuvant-induced IFN alone does not carry the animals through infection.

**(b) It is the Mn²⁺, acting on signal strength, not on dose or delivery.** PSLN-344 and PSLN-212 differ only by Mn²⁺; CDN encapsulation is slightly lower, not higher, in PSLN-344 (-4.82 points [-15.81, +6.17]; Welch p=0.29; Mann–Whitney exact p=0.4; Tukey-adjusted p=0.86 [N336]). Mn²⁺ doubles lung Ifnb1 at 16 h at equal dose (2.23× [1.85–2.69]; Welch p=9.6e-06; Mann–Whitney exact p=0.0079; Tukey-adjusted p=0.00062 [N213]) and quadruples the maximal response (Emax 55.3 (SE 7.3)-fold above baseline [N330] vs Emax 13.7 (SE 1.4)-fold above baseline [N329]). At 10 µg PSLN-344 already matches or exceeds 40 µg PSLN-212 (GM 21.0 vs 14.7; ratio 1.43 [0.98–2.07]; Welch p=0.058 [N332]). The uptake data cannot show whether Mn²⁺ also changes epithelial delivery (I-10).

**(c) The signal travels through GM-CSF and monocyte-derived DCs.** Each link below moves with Mn²⁺ in the same direction, and six kinds of perturbation (CCR2, gap junction, IFNAR, GM-CSF, Gi, SP-A/D) were tested:

- Lung Gm-csf: 16 h 4.21× [2.78–6.38], 36 h 5.36× [3.93–7.32], 72 h 2.63× [1.61–4.30] vs PSLN-212 [N258], [N262], [N266].
- Monocyte recruitment is CCR2-dependent: CCR2 antagonist lowered lung monocytes 9.86% ± 2.26 → 3.26% ± 1.37 (-6.60 points [-9.43, -3.78]; Welch p=0.001; Mann–Whitney exact p=0.0079 [N295]) and Ly6C+ macrophages 15.4% ± 4.51 → 2.52% ± 0.61 [N298]; it also cut lung GZMB+ CD8 cells in young PSLN-344 mice 6.77% ± 1.05 → 1.39% ± 0.46 [N301]. Carbenoxolone (gap-junction blocker, not specific) lowered recruited monocytes 7.28% ± 1.86 → 3.08% ± 1.29 [N314].
- Monocyte-to-DC differentiation needs type I IFN signalling in the monocyte and can be rescued by GM-CSF: Ifnar⁻/⁻ marrow produced 2.09% ± 0.93 vs 19.7% ± 4.01 moDC from wild-type marrow [N287]; intratracheal GM-CSF restored Ifnar⁻/⁻ cells to 12.4% ± 3.74 [N293]; in aged mice GM-CSF lifted PSLN-212 moDC from 5.86% ± 1.48 to 13.8% ± 3.04 [N284].
- DC migration to the mediastinal node is Gi-dependent: pertussis toxin cut antigen+ MLN DC 7.09% ± 1.42 → 2.36% ± 0.88 [N304] and their ability to prime OT-I cells 18.7% ± 2.85 → 2.55% ± 1.81 [N306]. In vivo, PTX reduced OT-I proliferation in the MLN (30.9% ± 3.87 → 6.83% ± 0.8 [N308]) but not in the lung (59.0% ± 4.99 → 55.1% ± 9.45 [N311]), so some priming may occur locally.
- Delivery: the surfactant-mimetic liposome targets AECII over AECI (15.8% ± 2.30 vs 3.83% ± 1.14 [N320]) and alveolar-macrophage uptake depends on SP-A/D (43.1% ± 4.12 → 12.7% ± 3.01 in knockouts [N317]; knockouts were young, WT age not stated).

![Figure 4. Mn²⁺ mechanism data: dose-response ceiling (S08-A), GM-CSF kinetics (S02-F) and cellular interventions.](figures/fig4_mechanism_data.png)

**(d) At the effector level, the survival pattern maps onto which immune arm was restored.** Homologous (HA-matched) protection — where neutralising antibody is the expected effector — is fully restored (7/7, identical to young [N009]), and HAI/neutralisation is restored to 57–87% of young, none significantly different. Heterosubtypic protection, against viruses whose HA the vaccine does not contain, cannot be explained by HAI; it is partly restored (day 60: aged PSLN-344 14/21 vs young PSLN-212(Y) 21/21 [N023]), mirroring the CD8 arm, which is only 59–80% restored (e.g. d60 IFN-γ+ CD8 -4.5 points [-8.7, -0.3], p=0.038 [N106]; lung TRM -2.1 points [-3.0, -1.2], p=0.00068 [N118]). The unrestored upstream bottleneck is DC costimulation (CD40/CD86 at 29–38% of young [N371], [N372]), the most plausible reason the T-cell and long-lived responses lag. Caveats: this is a group-level inference across separate cohorts (the immune readouts and the challenges were done in different animals); antibodies against the shared N1 neuraminidase could contribute to rgH5N1 protection after the CA09-containing vaccine; and no CD8 depletion, serum transfer or B-cell-deficient experiment was done.

**(e) A translational warning inside the mechanism.** The vaccine antigen was formalin-inactivated whole virus, which carries the conserved internal proteins (NP, M1) that cross-reactive CD8 T cells recognise. Licensed seasonal vaccines are split or subunit preparations with far less of these proteins (external context). The heterosubtypic protection that differentiates PSLN-344 may therefore not transfer to a clinical antigen unless the antigen format is chosen for it.

![Figure 5. Evidence map: which links are intervention-tested, which are associations, and where the aged deficit persists.](figures/fig5_mechanism_map.png)

# 5. Is there a biomarker of efficacy worth carrying forward?

**Yes — but it is two different things, and neither is validated yet.** I scored every candidate in the data against five tests: (1) does it separate PSLN-344 from PSLN-212 animal-by-animal; (2) does it also track the residual shortfall against young animals (the only discriminating contrast the data offer, since every monotone readout "correlates" with survival across sham < PSLN-212 < PSLN-344); (3) is it on the Mn²⁺ pathway; (4) can it be measured in people; (5) is its source block sound. No block links an immune readout to survival in the same animal, so every statement below is group-level.

Table 3. Biomarker candidates.

| Candidate (block) | Mn effect, separation | Tracks residual gap vs young? | Human-measurable analogue | Verdict and role |
|----------------|------------------|--------------------|------------------|----------------------------|
| Early lung IFN-β, Ifnb1 16 h (S01-A, S08-A, S09-A) | 2.23× [1.85–2.69], no overlap [N213]; dose-responsive to Emax | No — fully restored (98% of young) while heterosubtypic protection is not; present without protection when given without antigen | IFN-β/IFN-λ/CXCL10 in nasal lining fluid; blood interferon-stimulated-gene score, 6–48 h | **Carry forward as PD / target-engagement and dose-selection marker. Not an efficacy correlate.** |
| Gm-csf, 16–72 h (S02-F) | 5.36× [3.93–7.32] at 36 h, no overlap [N262] | Unknown (no young arm) | GM-CSF in nasal lining fluid | Exploratory PD marker of the Mn²⁺-specific step |
| Resolution: Ifnb1 at 72 h (S01-A); TNF at 16 h (S09-A) | — | Aged PSLN-344 285% of young at 72 h [N396]; TNF 2.92× [1.72–4.95] vs young PSLN-212 [N354] | ISG score at 72 h–7 d; TNF, IL-6, CRP | **Carry forward as a safety/reactogenicity marker in older adults** |
| HAI / neutralisation, d14 (S03-C/D/G/H) | HAI 8.00× [3.91–16.4], no overlap [N045] | No — restored (76–87% HAI; n.s.); explains homologous but not heterosubtypic protection | Serum HAI/MN (regulatory standard) | **Carry forward as primary immunogenicity endpoint (regulatory anchor).** Not the differentiator. Note: in this model the human "seroprotection" cut-off (HAI ≥1:40) does not predict survival — PSLN-212 reached it in 5/5 animals yet 0/7 survived [N282], [N009] |
| ICOS-high Tfh, d7 (S04-A) | +6.4 points [+2.6, +10.3], no overlap [N207] | Partly (75% of young, p=0.08) | Circulating ICOS+PD-1+CXCR5+ Tfh at day 7 (blood); an established early correlate of influenza-vaccine antibody responses in people (external context) | Carry forward as an early (day-7) predictor of the antibody response |
| Cross-reactive CD8 IFN-γ, d14 and d60 (S05-F/G, S14-A) | d14 +4.9 points [+3.6, +6.1], no overlap; d60 +6.8 points [+3.4, +10.3], no overlap [N099], [N105] | **Yes** — 69% and 69% of young (both p<0.05), matching the day-60 heterosubtypic survival gap | PBMC IFN-γ ELISpot / ICS against conserved NP/M1 peptide pools | **Lead candidate efficacy biomarker for breadth and durability — the asset's differentiator.** Must be validated (individual-level link to protection; CD8 depletion) |
| Lung CD8 TRM, d25 (S05-I) | +3.0 points [+2.2, +3.7], no overlap [N117] | Yes (66% of young [N395]) | Not in blood; nasal-tissue TRM only in research settings | Mechanistic; not a clinical biomarker |
| DC CD40/CD86, d3 (S02-D) | +5.6 points [+2.0, +9.3] (CD40) [N171] | Yes — largest gap (29%–38% of young [N371], [N372]) | Not practical | A development lever (formulation), not a biomarker |
| Mucosal (nasal/BAL) IgA | **Not measured anywhere in the dataset** | — | Nasal IgA by nasosorption or wash | Mandatory addition for an intranasal product |

**Ruled out as biomarkers:** the Tfh:Tfr ratio (S04-B) is an arithmetic transform of the Foxp3 percentage, (100 − Foxp3%)/Foxp3%, in every animal (I-18) — it contains no Tfh measurement, and the Tfr suppression it reflects is gone by day 30 in aged mice; the IgG2a/IgG1 quotients as printed in S03-B/F are mislabelled (I-04); challenge weight loss (recycled, I-02); alveolar macrophage and neutrophil kinetics (duplicated, I-03).

**Could the biomarkers go into patients, and in what role?** Yes, all of the carried-forward markers are measurable in a Phase 1 trial: (i) nasal/blood interferon signature at 6–48 h to confirm target engagement and choose the dose (the Mn²⁺ effect is precisely a higher IFN-β ceiling at equal CDN dose); (ii) the same signature at 72 h–7 d plus TNF/IL-6/CRP as the older-adult safety marker (aged mice resolve more slowly); (iii) day-7 circulating ICOS+ Tfh as the earliest read on the antibody arm; (iv) HAI/MN at day 28 as the primary immunogenicity endpoint; (v) NP/M1-specific CD8 IFN-γ responses and heterologous-strain MN as the breadth endpoints; (vi) nasal IgA as the mucosal endpoint. None except HAI/MN has regulatory standing as a surrogate; the CD8 marker earns a larger role only if the confirmatory challenge study shows it predicts protection in individual animals and CD8 depletion removes the heterosubtypic protection.

# 6. Could PSLN-344 go into patients, and in what role?

**Not yet.** On the plan in Section 7, first-in-human is realistic around month 20–24, after Gates 1–4 and IND-enabling toxicology.

**The role the data support:** an intranasal (or inhaled — see below) mucosal adjuvant co-administered with inactivated influenza antigen for adults aged 65+, whose differentiating claims are **breadth** (heterosubtypic, including H5N1), **speed** (protection when challenged 2–3 days after a single dose: PR8 5/7 vs 0/7 [N012]; rgH5N1, vaccine + PSLN-344 6/7 vs vaccine alone 0/7 [N025]; wild-type H5N1 10/10 vs 3/10, flagged [N010]) and **mucosal immunity**. In order of readiness:

1. **First clinical role — mucosal add-on in older adults who also receive their licensed intramuscular vaccine.** Participants are not denied standard of care, the comparison (IM vaccine alone vs IM vaccine + intranasal antigen/PSLN-344) isolates the asset's incremental value, and the endpoints (nasal IgA, cross-reactive T cells, heterologous MN) are exactly what PSLN-344 claims to add. Lowest ethical and commercial barrier.
2. **Strategic role — pandemic / pre-pandemic H5 vaccine component** (antigen-sparing, cross-clade, rapid onset), where older adults are a priority group and the regulatory path runs on immunogenicity. This is where the heterosubtypic and early-protection data matter most.
3. **Stand-alone seasonal replacement for high-dose or MF59-adjuvanted vaccines** only if the aged-mouse head-to-head (Study P1) shows at least non-inferior homologous protection and superior heterosubtypic protection, and Phase 2 shows non-inferior HAI. Historically, intranasal inactivated vaccines struggle to match intramuscular serum HAI in people (external context), so this is the hardest claim.

**Roles ruled out by our data:** a stand-alone innate "nasal shield" (PSLN-344 without antigen protected 0/7); a young-adult indication (PSLN-212 already protects young mice completely, so there is no incremental value to show); the R848 co-formulations (S08-D: PSLN-212/R848 weight nadir 90.0% with one animal lost by day 10 [N343]).

**Translation risks that decide the clinical design:**

- *Deposition.* The design rationale — surfactant mimicry, AECII and SP-A/D-dependent macrophage uptake — is alveolar. Mouse intranasal instillation reaches the lung; a human nasal spray mostly does not. Either efficacy survives upper-airway-restricted dosing in animals (Study P4), or the product needs an inhaled device, which changes the safety profile (deep-lung IFN in older adults, some with COPD).
- *Antigen format.* Whole-virus antigen was used throughout; the clinical antigen must be tested (Section 4e).
- *Mn²⁺ exposure.* No Mn²⁺ content was reported for the formulation, so the human Mn²⁺ dose per vaccination is unknown. A lower PSLN-344 dose may suffice: at 10 µg the lung IFN-β response already equals 40 µg PSLN-212 [N332].
- *Reactogenicity in older adults.* Aged PSLN-344 lungs make 2.92× the TNF and 3.98× the IL-10 of young PSLN-212 lungs at 16 h for the same IFN-β [N354], [N356], [N362], and the IFN-β response resolves more slowly.
- *Sex and pre-existing immunity.* All animals were female; older adults have decades of influenza exposure (the imprinting experiment is reassuring but used 14-month mice and a single prior infection).

# 7. What the next studies have to establish

Design principle: the existing experiments were small (n = 7 per arm gives 84% power for a 90%-vs-10% survival difference but only 27% for 80%-vs-30%) [N409]. They detected the Mn²⁺ effect because it is huge; they cannot detect the smaller differences that matter next (PSLN-344 vs a licensed benchmark, aged vs young, a reduced dose). All new studies must be randomised, blinded at dosing, scoring and analysis, run in both sexes, use a pre-registered analysis plan and pre-defined humane endpoints, and store raw data in a controlled system. Study designs below draw on standard practice (external context); every data-derived input is cited.

## 7.1 Gates and kill criteria

| Gate | Decision it makes | Timing | Pass | Fail → action |
|------------|--------------|--------|----------------------------------|--------------------------------|
| G1 Data verification (P0) | Is the existing efficacy package real? | Weeks 0–8 | Source records confirm outcomes of ≥8 of the 10 primary survival experiments; root causes for I-01 to I-09 documented | Repeat pivotal survival work inside P1 before any other spend; if source records contradict the survival data, stop |
| G2 Benchmarked efficacy (P1) | Is the effect reproducible and better than standard of care? | Month 9 | PSLN-344 minus PSLN-212 survival ≥ +40 points (lower 95% bound > +15) with the clinical antigen format; ≥1 log10 lung-titre reduction vs antigen alone; heterosubtypic protection non-inferior to the best IM benchmark | If not reproducible → stop. If reproducible but not better than the IM benchmark → pandemic/mucosal-booster niche only |
| G3 Mn²⁺ CNS safety (P5) | Is intranasal Mn²⁺ acceptable for older adults? | Month 10 | No Mn²⁺ accumulation above vehicle in olfactory bulb/striatum at 3× the intended human-equivalent dose; no olfactory or neurobehavioural deficit; NOAEL ≥10× intended dose | Switch to a lower dose or inhaled route and re-test; if Mn²⁺ accumulates at any effective dose → stop |
| G4 Translation (P4) | Does efficacy survive human-relevant delivery and antigen? | Month 7 | Protection retained with upper-airway-restricted dosing (or an inhaled route is viable) and with split/subunit antigen | Redesign route/antigen before IND-enabling work |
| Redesign trigger (P1) | Is the CDN needed? | Month 9 | Mn²⁺-only liposome gives <50% of the PSLN-344 effect | If Mn²⁺ alone gives most of the effect → simplify the product (not a kill) |

## 7.2 Studies

**P0. Source-data verification and quality root-cause review (Gate 1)**

- *Must establish:* That the survival outcomes and key immunogenicity values in the workbook match the primary records, and why copies, relabelling and recycling occurred.
- *Population / material:* All blocks; priority: S03-I, S03-J, S06-A to S06-G, S15-H/L/N, S03-B/F, S11-A/B, S13-F/G, all S15 weights, S06 "Untreated" arms.
- *Comparators:* Workbook values vs primary records (daily clinical/weight sheets, humane-endpoint and euthanasia logs, cage cards, necropsy, FCS files, qPCR Ct exports, ELISA/HAI plate reads), colony health reports for the 20-month cohorts.
- *Endpoints / readouts:* Reconciliation status per block (confirmed / corrected / unverifiable); documented humane endpoint; randomisation and blinding records; explanation of the 4/21 deaths in unchallenged controls.
- *Timing:* Weeks 0–8, before any new animal work is committed.

**P1. Confirmatory, benchmarked efficacy in aged mice (Gate 2)**

- *Must establish:* That the Mn²⁺ effect reproduces under blinded, randomised conditions with the clinical antigen format, and how PSLN-344 compares with what older adults get today.
- *Population:* Aged (20–22 months) female and male BALB/c and C57BL/6 (C57BL/6 allows H-2Db NP366 tetramers); young (8–10 weeks) PSLN-212 reference.
- *Arms / comparators:* Clinical-format split or recombinant HA antigen (whole-inactivated virus in a bridging arm) intranasally with: (1) empty liposome; (2) PSLN-212 20 µg; (3) PSLN-344 20 µg; (4) PSLN-344 10 µg; (5) Mn²⁺-only liposome at the PSLN-344 Mn²⁺ content; (6) PSLN-344 without antigen. Intramuscular benchmarks: (7) antigen + squalene oil-in-water emulsion (MF59-type); (8) high-dose antigen (4× HA). (9) Young + PSLN-212.
- *Primary endpoints:* Survival to day 14 after lethal challenge under a pre-specified humane endpoint; co-primary lung viral titre (TCID50) on days 3 and 5 in parallel sublethal cohorts.
- *Challenges:* Homologous CA09 H1N1; heterosubtypic H3N2 and rgH5N1; at day 3 (onset), day 14 and day 90 (durability) after a single dose.
- *Secondary readouts (pre-challenge, same animals):* Serum HAI/MN against vaccine and heterologous strains; nasal-wash and BAL IgA; NP-specific CD8 T cells in blood and lung (tetramer/ICS, intravascular labelling for TRM); circulating ICOS+PD-1+CXCR5+ Tfh at day 7; nasal-wash IFN-β, CXCL10, GM-CSF, TNF, IL-6 at 16–36 h; weight-loss AUC and clinical score.
- *Prioritised matrix:* Aged mice are scarce, so not every arm meets every challenge. Core (all challenges, both strains): arms 1, 2, 3, 5, 7. Arms 4, 6, 8 and 9: day-14 heterosubtypic challenge and the day-3 onset challenge only. C57BL/6 replicates the core contrasts; BALB/c carries the full matrix.
- *Size:* Survival is powered for the Mn²⁺ contrast: 18–20 per arm per challenge (≥90% power for 75% vs 20%); lung titre 15 per arm detects a 1 log10 reduction (SD 0.8, 90% power) [N410]. The benchmark comparison is powered on day-3 lung titre, not survival: non-inferiority with a 0.7-log10 margin needs about 28 per arm [N411]. Blocked randomisation by sex and cage.
- *Timing:* Dosing months 2–3; day-3/14 challenges months 3–4; day-90 challenges month 6; read-out month 8–9.

**P2. Mechanism of protection (runs alongside P1)**

- *Must establish:* Which effector carries protection — this decides the clinical efficacy biomarker.
- *Population:* Aged mice vaccinated with PSLN-344 + antigen (P1 conditions).
- *Arms / comparators:* Before challenge: anti-CD8β depletion; anti-CD4 depletion; anti-CD20 B-cell depletion; FTY720 at challenge (resident vs recruited T cells); isotype controls. Passive transfer of immune serum, or purified CD8 T cells, into naive aged recipients. At vaccination: IFNAR blockade; CCR2 antagonist; PSLN-212 + GM-CSF (does GM-CSF substitute for Mn²⁺ for survival?); PSLN-344 + CD40 agonist (does fixing the costimulation bottleneck close the gap to young?).
- *Primary endpoints:* Survival and lung viral titre after homologous and heterosubtypic challenge.
- *Decision rule:* An effector whose removal abolishes ≥50% of protection, and whose transfer confers protection, becomes the clinical efficacy biomarker.
- *Timing:* Months 4–10.

**P3. Biomarker validation (embedded in P1/P2)**

- *Must establish:* That a pre-challenge measurement predicts protection in the individual animal.
- *Design:* Pre-challenge samples from every challenged animal; add a partially protective arm (PSLN-344 5 µg) so outcomes vary; ~40–60 animals with mixed outcomes per challenge type.
- *Candidates:* HAI/MN; nasal IgA; blood NP-specific CD8 IFN-γ; day-7 circulating Tfh; 16–36 h nasal IFN-β/CXCL10 (PD).
- *Endpoints / readouts:* Logistic and Cox models of survival and viral titre on each marker; ROC AUC with bootstrap CI; pre-specified threshold.
- *Decision rule:* AUC ≥0.8 plus mechanistic support from P2 → carry into Phase 1 as the efficacy biomarker.
- *Timing:* Read-out with P1 (month 9).

**P4. Route / deposition and antigen format (Gate 4)**

- *Must establish:* Whether efficacy needs alveolar deposition (as in mouse instillation) or survives upper-airway-restricted dosing like a human nasal spray; and whether it survives split/subunit antigen.
- *Population:* Aged (20–22 months) BALB/c, both sexes; young reference arm.
- *Arms / comparators:* Low-volume (≈5 µL) awake intranasal dosing (nasal-restricted) vs standard volume under anaesthesia (whole respiratory tract) vs aerosol; whole-virus vs split vs recombinant HA; each with PSLN-344 and with PSLN-212 as the Mn-free comparator.
- *Endpoints / readouts:* Deposition imaging of labelled liposome; nasal vs lung Ifnb1; HAI, nasal IgA, CD8; survival after heterosubtypic challenge.
- *Timing:* Months 2–7.

**P5. Mn²⁺ biodistribution and neurotoxicity (Gate 3)**

- *Must establish:* Whether intranasal Mn²⁺ reaches and accumulates in the CNS at effective doses, especially in aged animals.
- *Population:* Aged and young rodents, both sexes.
- *Arms / comparators:* Vehicle; PSLN-212; PSLN-344 at 1×, 3×, 10× the intended dose; MnCl₂ at matched Mn²⁺; single and repeat dosing (3 doses, plus an annual-booster simulation).
- *Endpoints / readouts:* Mn²⁺ by ICP-MS in nasal turbinates, olfactory bulb, striatum/globus pallidus, cerebellum, lung, liver and blood at days 1, 7, 28, 90; Mn-enhanced T1 MRI; olfactory function (buried-food test); open field and rotarod; histopathology of olfactory epithelium, olfactory bulb and facial nerve; olfactory-bulb Ifnb1/Tnf/Isg15 from 6 h to 7 d (extends S10-A, which sampled only "CNS" at 36 h).
- *Timing:* Months 2–10 (non-GLP design that anticipates the GLP study).

**P6. CMC and formulation**

- *Must establish:* A defined, stable, releasable product, and the Mn²⁺ dose per human vaccination.
- *Material / comparators:* Three PSLN-344 lots vs PSLN-212 (Mn-free) and Mn²⁺-only liposome reference lots.
- *Readouts:* Mn²⁺ content and Mn:CDN ratio; CDN encapsulation (currently 54.8% ± 5.08 [N337], target ≥80%) and free CDN; particle size, PDI, zeta potential; lyophilised stability at −20 °C and 2–8 °C (0, 1, 3, 6, 12 months); cell-based IFN-β/ISG potency assay aligned with the PD biomarker; endotoxin; sterility; anti-PEG (DPPE-PEG2000) immunogenicity plan for annual dosing.
- *Timing:* Months 0–12; release specifications and 6-month stability before GLP toxicology.

**P7. Second-species efficacy: ferret**

- *Must establish:* Protection in the standard influenza transmission model with human-like airway receptor distribution.
- *Population:* Adult and, if obtainable, aged ferrets.
- *Arms / comparators:* Antigen alone; antigen + PSLN-344 intranasal; IM benchmark (MF59-type emulsion).
- *Endpoints / readouts:* Nasal-wash viral shedding AUC (days 1–7), clinical score, temperature, transmission to naive contacts, HAI/MN, nasal IgA; H3N2/H1N1 and H5N1 (BSL-3).
- *Timing:* Months 8–16, after G1–G2.

**P8. IND-enabling GLP toxicology (only after G1–G4)**

- *Population:* Rat plus a second species agreed with the regulator (e.g. rabbit for intranasal), both sexes, with recovery groups.
- *Arms / comparators:* Vehicle; antigen alone; antigen + PSLN-344 at the clinical dose and at a multiple; repeat dosing (n+1 doses), intranasal or inhaled per P4.
- *Endpoints / readouts:* Clinical signs, body weight, haematology and clinical chemistry; nasal-cavity local tolerance at multiple levels; CNS and olfactory-bulb histopathology; tissue Mn²⁺; systemic cytokines and CRP; safety pharmacology (respiratory, CNS, cardiovascular).
- *Timing:* Months 10–20.

**C1. First-in-human Phase 1 (from about month 20–24)**

- *Design:* Randomised, observer-blind, placebo-controlled dose escalation (3 PSLN-344 dose levels) with licensed split or recombinant antigen, via the route chosen in P4.
- *Population:* Part A: healthy adults 18–49 (sentinel dosing). Part B: adults 65–85, stratified 65–74 and 75–85. About 24–30 per dose cohort.
- *Comparators:* Intranasal antigen without adjuvant; placebo; open-label licensed IM older-adult vaccine (high-dose or MF59-adjuvanted) as immunogenicity reference.
- *Primary endpoints:* Safety: solicited nasal (congestion, rhinorrhoea, epistaxis, smell change) and systemic reactions days 0–7; unsolicited AEs to day 28; SAEs and AESIs to month 12, including facial palsy and olfactory dysfunction (validated smell test at baseline, day 7, 28, 180); neurological examination; blood Mn²⁺; brain MRI T1 pallidal index in a subset.
- *Secondary / exploratory readouts:* PD: nasal lining fluid IFN-β/IFN-λ/CXCL10/TNF/IL-6 and blood ISG score at 6 h, 24 h, 48 h, day 7. Immunogenicity: HAI/MN GMT and seroconversion at day 28 (vaccine and heterologous strains); nasal IgA days 14 and 28; circulating Tfh day 7; NP/M1 CD8/CD4 IFN-γ ELISpot day 14; durability at days 90, 180, 365.

**C2/C3. Phase 2 and efficacy path**

- *Timing:* From about month 30, after Phase 1 safety and PD/immunogenicity read-outs.
- *Phase 2:* Adults ≥65 (several hundred): dose confirmation against the licensed IM comparator — HAI non-inferiority using CBER-style criteria (external context: upper 95% bound of the GMT ratio ≤1.5; seroconversion difference ≤10 points) plus superiority on nasal IgA and cross-reactive T-cell endpoints; in the add-on design, IM vaccine alone vs IM + intranasal PSLN-344.
- *Efficacy signal:* Controlled human influenza challenge in healthy adults 18–55 (viral shedding AUC, symptomatic infection) to show mucosal protection — older adults are ethically excluded; then immunobridging or field efficacy per regulatory advice. Pandemic track: H5 antigen ± PSLN-344, immunogenicity per pandemic criteria.

## 7.3 Timeline summary

| Months | 0–2 | 2–9 | 9–10 | 10–20 | 20–24+ |
|---|---|---|---|---|---|
| Work | P0 verification; P6 CMC starts | P1, P2/P3, P4, P5 run in parallel | Gate review G2–G4 | P7 ferret; P8 GLP tox; GMP | C1 Phase 1 |
| Decision | G1 | — | Advance to IND-enabling, redesign, or stop | IND | — |

# 8. What I considered and ruled out

| Considered | Evidence | Conclusion |
|-------------------------|--------------------------------------------------|--------------------|
| PSLN-344 works because it delivers more CDN | Encapsulation 54.8% ± 5.08 vs 59.6% ± 4.55 [N336] | Ruled out |
| PSLN-212 was simply under-dosed | PSLN-212 plateaus: 20 µg gives 0.85 [0.59–1.23]× the 40 µg response [N334]; Emax 13.7 vs 55.3 [N329] | Ruled out |
| Mn²⁺ improves epithelial targeting | S08-C labels conflict with S01-B (I-10) | Not supported either way |
| Effect is specific to one mouse strain or one challenge | Replicated in C57BL/6 and Swiss Webster [N018], [N019]; four viruses; d2–d60 | Ruled out |
| Protection is an innate antiviral state | PSLN-344 without antigen 0/7 [N025] | Ruled out |
| HA-neutralising antibody explains all protection | Protection against HA-mismatched viruses in S06-A/B/C/E/F/G [N011], [N012], [N013], [N015], [N016], [N017] and S15-H [N025] | Ruled out as sole mechanism |
| NK cells mediate the effect | S11-D, PSLN-344 vs PSLN-212: day 2 +5.20 points [-0.09, +10.49], p=0.053; day 4 +6.38 points [-0.55, +13.31], p=0.066; none at days 6–8 [N397], [N398], [N399], [N400] | Not supported |
| Prior influenza exposure blunts PSLN-344 | Imprinted vs naive 14-month mice: 6/7 vs 6/7 in both challenges [N026], [N027] | Ruled out (in 14-month mice, one prior infection) |
| PSLN-344 fully restores youthful immunity | Survival 51/63 vs 62/63 [N007]; CD40/CD86 29–38% of young; CD8 59–80% | Ruled out: partial restoration |
| "No difference vs young" in single experiments proves equivalence | n = 7 has 27% power for 80% vs 30% [N409]; pooling reveals a 17-point gap | Ruled out as an inference |
| Tfh:Tfr ratio as biomarker | Algebraic transform of Foxp3% (I-18); effect gone by day 30 | Ruled out |
| PSLN-344 is Th2-skewed (from S03-B/F as printed) | Labels rotated (I-04); raw subclass titres give IgG2a/IgG1 1.85 vs 0.54 (PSLN-212) [N275] | Ruled out — the opposite is true |
| HAI ≥1:40 as a protective threshold | PSLN-212 ≥1:40 in 5/5 yet 0/7 survived [N282] | Ruled out in this model |
| Alveolar macrophage / neutrophil kinetics | S11-A/B share 35/100 values (I-03) | Excluded |
| Day-3 rgH5N1 protection as shown in S06-D | Copy of S06-C (I-01) | Excluded; rapid onset rests on S06-B, S15-H and (flagged) S03-J |
| Morbidity (weight-loss) benefit after challenge | Weights recycled across experiments; dead animals carried forward (I-02, I-08) | Not claimed |
| Antigen-specific CD8 kinetics (NP tetramer, S05-A/B) | n = 2 of stated 3; OVA vs vaccine contradiction; H-2Db epitope in BALB/c (I-09) | Excluded |
| Macrophage transfer and Tregs (S07-C) | Both columns carry the same label (I-11) | Excluded |
| Ly6C+CCR2+ macrophage counts (S07-A) | n = 3; absolute counts are LOWER with PSLN-344 than PSLN-212 while monocyte frequency (S01-D) is higher — different gates and units; one reading is that Mn²⁺ diverts monocytes from a macrophage to a DC fate, but n = 3 cannot carry it | Not used for conclusions |
| S09-A second cytokine panel; S08 unlabelled region; "PSLN-344/R848" | Timepoint mislabelled; unattributable; undefined material (I-12, I-17, I-14) | Excluded |
| Standalone innate prophylactic role | 0/7 without antigen [N025] | Ruled out |
| Young-adult indication | PSLN-212 already 8/8 in young mice in all three young challenge experiments [N028], [N029], [N030] | Ruled out |
| R848 co-formulations (PSLN-212/R848, PSLN-R848) | Ifnb1 16 h 24.0 [19.9–29.0] vs PSLN-344 36.9 [31.6–43.1] [N401]; Tnf 16 h log10 2.31 vs 1.61 (highest of all arms) [N402], [N403]; weight nadir 90% with one animal lost [N343] | Ruled out |
| cGAMP liposome (CMP-204) | IgG GMT 181 [73.8–445] vs PSLN-212 393 [210–737] [N034]; HAI GMT 23.0 [11.2–47.2] vs 45.9 [31.3–67.5] [N041]; survival 3/7 vs PSLN-344 7/7 [N009] | Ruled out |
| Arithmetic means for titres; HAI "0" as zero; counting carried-forward dead animals in weight means | Titres are log-normal; 0 means below the 1:10 starting dilution; I-08 | Ruled out as analysis choices |
| Dropping the asset now | The Mn²⁺ effect survives every exclusion; the open questions are answerable in ~9–12 months | Not recommended (see Section 9 for the case if the committee disagrees) |

# 9. If the committee drops PSLN-344: what we would be dropping, and why

**What we would be dropping.** The only asset in this dataset that reverses the aged-mouse survival deficit with a single intranasal dose (61/73 vs 9/73; MH risk difference +0.71 [+0.60, +0.82] [N001] over its Mn-free parent; 61/73 vs 1/73; MH risk difference +0.82 [+0.73, +0.91] [N005] over sham), brings aged HAI to near-young levels (368 [179–755] [N043] vs young 485 [303–777] [N044]), protects against heterosubtypic and H5N1 challenge, and comes with a specific, testable mechanism (Mn²⁺ raises the ceiling of STING output → IFN-β and GM-CSF → monocyte-derived DCs) and a ready pharmacodynamic biomarker.

**Why dropping it would be defensible.** (1) *Evidence quality:* the package fails integrity checks that a partner or regulator would run in a day — a copied survival block, recycled body weights, rotated labels, irreconcilable weight/survival pairs, and unexplained deaths in unchallenged controls. (2) *Safety:* intranasal Mn²⁺ in older adults is an unquantified CNS risk with no data at all on Mn²⁺ exposure. (3) *Translation:* efficacy was shown with whole-virus antigen and lung-reaching instillation, neither of which maps onto a human nasal spray with split antigen. (4) *Competition:* there is no evidence it beats high-dose or MF59-adjuvanted vaccines.

**What to keep if it is dropped.** The finding that the aged defect sits at IFN-I/GM-CSF-driven monocyte-to-DC differentiation and DC costimulation (usable for other adjuvant programmes, e.g. GM-CSF or CD40-agonist combinations); the PD assay (IFN-β/ISG ceiling); and a data-governance fix, because the same process produced this package.

**Why I still recommend the conditional path instead.** Each of the four reasons to drop is answerable with bounded work (Gates G1–G4) costing far less than the IND-enabling package, and a pass on all four would leave us with a differentiated older-adult and pandemic-preparedness asset. A fail on G1 or G3 is a clean stop.

# Appendix A. Data-reduction rules

- **Unit of analysis:** the individual animal (per-animal values as stored). n is the number of values present, which is reported wherever it differs from the stated n.
- **Titres** (ELISA endpoint, HAI, neutralisation) and **qPCR fold-changes** are log-normal: summarised as geometric means with 95% t-intervals on log10, compared as ratios of geometric means with Welch t-tests on log10. HAI values recorded as 0 (below the 1:10 starting dilution) are imputed as 5.
- **Flow-cytometry percentages and encapsulation efficiency:** arithmetic mean ± SD; differences with 95% Welch intervals.
- **S09-A** values are stored as log10 fold-change: means and differences are computed on the stored log10 values and reported as fold.
- **IgG2a/IgG1:** computed per animal from S13 raw titres (S03-B/F quotients are mislabelled).
- **Tests:** two-sided Welch t and exact Mann–Whitney for each pairwise contrast; Tukey HSD across all groups within a block (the annotation's stated method; on log10 for log-normal data). With n = 5 per group the smallest attainable exact Mann–Whitney p is 0.0079. No correction across blocks; effect sizes with intervals are the primary result.
- **Survival:** survivors = animals with event 0; log-rank and Fisher exact per experiment; pooled across experiments by Mantel–Haenszel risk difference (Sato variance), stratified log-rank (R survival::survdiff with strata) and exact conditional CMH (R mantelhaen.test). S03!G46 (blank day, event 0) censored at day 21.
- **"% of young":** ratio of geometric means (titres, qPCR) or of arithmetic means (% data) to young PSLN-212(Y); CI by Welch/delta method on the log scale.
- **Body weight:** an animal is classed as dead when its weight is absent at later days or repeats identically for ≥3 consecutive trailing timepoints (carried forward). Post-vaccination reactogenicity (S08-D) uses each animal's minimum % of day-0 weight over days 2–10.
- **Integrity screens:** (i) all pairs of groups across blocks for shared values; (ii) all pairs of animal weight trajectories for identical same-day values; (iii) shared high-precision fractional parts; (iv) survival vs weight blocks; (v) algebraic checks of derived quantities; (vi) stated vs observed n.
- **Code:** all reductions are reproducible from the scripts in outputs/code (parse → statistics → register → report).

# Appendix B. Integrity log (all 19 findings)

**I-01 — Critical — S06-D vs S06-C**

- *Cells:* S06!A3:Q30 vs S06!A34:E61; companion weights S15!W37:W40, S15!AC37:AC40, S15!F37:F40, S15!G38:G40
- *Finding:* The day-3 rgH5N1 survival block (S06-D) is a row-for-row copy of the day-14 block (S06-C): all 28 animals (4 groups x 7) have identical day/event sequences.
- *Evidence / test:* Exact match of every (day, event) pair in all four groups. The companion weight block S15-D is NOT a copy and shows carried-forward (dead-animal) weights for 2 PSLN-344 and 2 young animals, i.e. 5/7 survival, not the 7/7 printed in S06-D.
- *Impact:* S06-D adds no independent information. Rapid-onset claims must rest on S06-B (PR8, d3), S15-H (rgH5N1, d3; its weight block is itself copied, I-02) and S03-J (wild-type H5N1, d2; flagged).
- *Handling:* Excluded from all primary and sensitivity sets except Sens-C (shown only to demonstrate it does not change the conclusion).

**I-02 — Critical — S08-D, S09-C/E/G, S13-F/G, S15-A to S15-O (body weight)**

- *Cells:* see Evidence workbook sheets "Weight_dup_trajectories" and "Weight_dup_decimals"
- *Finding:* Body-weight values are recycled between different experiments. (a) Whole animal trajectories: 17 animal pairs in different blocks share >=5 identical same-day values (e.g. S09-E PSLN-212Y col N = S09-G col N on all 7 days; six S15-C PSLN-344 animals = S15-I Vaccine+PSLN-344 animals on days 2-12, 40/49 values). (b) Whole rows: S15!I5:O5 (S15-A Sham, day 4) = S15!W105:AC105 (S15-M PSLN-212, C57BL/6, day 4); S09!G18:N18 = S09!W18:AD18 (day 12, PSLN-212Y = PSLN-344Y). (c) Positional decimal recycling: the four high-precision S08-D CMP-204 animals (cols G, I, J, K; post-vaccination days 2-10) map one-to-one onto S15-F young animals (cols B, D, E, C; post-challenge days 2-10) with identical 5-decimal fractional parts and edited integer parts (e.g. S08!G25 = 100.71795 vs S15!B57 = 98.71795); the same pattern links S15-A, S15-J, S15-K, S15-M and S15-O, and S09-E with S15-M (58 distinct long fractional parts, 140 cells, 10 blocks).
- *Evidence / test:* For 1-decimal weights, >=5 identical same-day values between two independent animals has probability ~7e-8 per pair (~0.01 expected over ~125,000 pairs). An isolated shared fractional part can arise naturally when two mice share a day-0 weight, but identical fractional parts at the same day for every day of an animal, across experiments, cannot.
- *Impact:* Challenge body-weight curves cannot be used as independent evidence of morbidity or to corroborate survival. S08-D appears to be a SOURCE of recycled values, so S08-D is used only with this caveat.
- *Handling:* No efficacy claim uses challenge body weights. Weights used only to cross-check survival counts (I-06) and for S08-D reactogenicity (caveated).

**I-03 — Major — S11-A (alveolar macrophages) vs S11-B (neutrophils)**

- *Cells:* S11!B3:U7 vs S11!B10:U14
- *Finding:* 35 of 100 same-position values are identical between two different cell populations (the first 1-2 animals of every group x day cell).
- *Evidence / test:* Chance rate estimated from non-corresponding positions in the same blocks: 6/400 = 1.5 per 100. Negative control S11-A vs S11-D (NK cells): 0/100.
- *Impact:* Neither block can be used (e.g. no claim that PSLN-344 does/does not recruit neutrophils).
- *Handling:* Both excluded.

**I-04 — Major — S03-B, S03-F (IgG2a/IgG1 quotients) vs S13-A to S13-D (raw subclass titres)**

- *Cells:* S03!G3:I7, S03!G10:I14 vs S13!A3:C7, E3:G7, I3:K7, M3:O7
- *Finding:* Group labels in S03-B and S03-F are rotated: the column printed "PSLN-212" equals the young group quotient, "PSLN-344" equals PSLN-212, "PSLN-212(Y)" equals PSLN-344.
- *Evidence / test:* Recomputed quotients from S13 raw titres match the relabelled columns to <=6.5e-4 relative error; the S13 labels are corroborated by total-IgG ordering in S03-A/S03-E.
- *Impact:* As printed, PSLN-344 would look Th2-skewed (GM quotient 0.55 H1N1, 0.47 H3N2). The raw data show the opposite: 1.85 and 2.30 vs PSLN-212 0.54 and 0.46 (young 2.50, 2.79).
- *Handling:* Subclass ratios recomputed from S13; S03-B/F not used.

**I-05 — Major — S13-F vs S03-I; S13-G vs S03-J**

- *Cells:* S13!A32:AJ40 vs S03!A16:F51; S13!A42:AE50 vs S03!G16:J46
- *Finding:* The weight blocks said to belong to the S03-I and S03-J survival animals do not match them: different group sets ("Naive" present, CMP-204 or PSLN-212 absent); S13-F shows PSLN-212 animals alive at day 8 (all 7) and 3 recovering to day 14 whereas S03-I records all 7 dead by day 6; S13-G shows most "Sham" animals recovering whereas S03-J records 9/10 Sham deaths.
- *Evidence / test:* Group-by-group comparison of alive counts (missing or carried-forward weights = dead).
- *Impact:* S03-I (homologous) and S03-J (wild-type H5N1) survival results have no corroborating morbidity data.
- *Handling:* S03-I and S03-J kept in the primary set but flagged; excluded in Sens-A/Sens-B.

**I-06 — Major — S06-C/S15-C, S06-E(d60)/S15-E, S06-G/S15-G, S15-L/S15-M, S09-F/S09-G, S09-B/S09-C**

- *Cells:* see Evidence workbook sheet "Survival_vs_weight"
- *Finding:* Death counts or timing in survival blocks disagree with their own weight blocks: S06-C PSLN-212 5 vs 6 deaths; S06-E(d60) PSLN-212 7 vs 6 and PSLN-344 2 vs 1; S06-G PSLN-344 3 deaths on days 8-11 but all 7 animals still weighed on day 12; S15-L young 1 death vs 0; S09-F Sham has 7 animals but 8 are weighed; S09-B Sham 6 deaths by day 7 but 7 animals weighed on day 8.
- *Evidence / test:* Per-animal status inferred from weights (absent = dead; >=3 identical trailing values = carried forward after death).
- *Impact:* Moderate uncertainty on individual survival counts; direction of every PSLN-344 vs PSLN-212 comparison unchanged under either count.
- *Handling:* Flagged blocks dropped in sensitivity sets Sens-A/Sens-B.

**I-07 — Major — S06-E(d60), S06-F(d60), S06-G "Untreated"**

- *Cells:* S06!G62:L68, S06!M62:R68, S06!A99:F105; weights S15!AD43:AJ50, S15!AD53:AJ60, S15!AD63:AJ70
- *Finding:* Animals described as 20-month-old, unvaccinated and UNCHALLENGED died: 1/7 (day 4), 0/7, 3/7 (days 3, 7, 10) = 4/21 within 14 days, with only 3-6% weight loss before death.
- *Evidence / test:* Survival rows with event = 1 in the Untreated column; weights frozen at 94.5-96.6% (not influenza-like).
- *Impact:* Either substantial background mortality / colony-health problem in the day-60 aged cohorts, or mis-allocation of animals. In S06-G, PSLN-344 survival (4/7) equals the unchallenged group (4/7).
- *Handling:* Day-60 results (S06-E/F/G) reported with this caveat; S06-E and S06-G carry flags. Colony health records required (Gate 1).

**I-08 — Major — S15 weight blocks**

- *Cells:* e.g. S15!P6:V10 (PSLN-212 frozen at 78-84%) vs S15!I6:O10 (Sham deleted)
- *Finding:* Weights of dead animals are carried forward (last value repeated) in some groups and deleted in others; the annotation only describes deletions.
- *Evidence / test:* Carried-forward runs coincide with deaths in the paired survival blocks (e.g. S15-A PSLN-212: 6 frozen = 6 deaths in S06-A).
- *Impact:* A naive group-mean weight curve would count dead animals at ~80% body weight and overstate morbidity protection in those groups.
- *Handling:* Weights not used for efficacy.

**I-09 — Major — S05-A, S05-B (and S05-I by reference)**

- *Cells:* S05!A1:I10; S05!A52:D58
- *Finding:* Stated n=3 but 2 values per group; conditions contradictory (ovalbumin immunisation and bivalent influenza vaccine in the same block); NP366-374 tetramer readout in a BALB/c default strain.
- *Evidence / test:* Annotation S05-A/B; NP366-374 is an H-2Db-restricted epitope (C57BL/6), not presented by BALB/c (H-2d) [external knowledge]. S05-I states "vaccinated as in S05-A".
- *Impact:* Antigen-specific CD8 kinetics cannot be established from S05-A/B. S05-I (lung TRM) can only be read as total CD8 TRM-phenotype cells under ambiguous conditions.
- *Handling:* S05-A/B excluded; S05-I used with caveat.

**I-10 — Moderate — S08-C vs S01-B**

- *Cells:* S08!A14:D18 vs S01!B14:F17
- *Finding:* S08-C columns conflict with S01-B for the same formulation, dose and timepoint: AECI uptake of PSLN-SRB is 13.8% in S08-C but 3.8% in S01-B; the S08-C column "AECII-PSLN-344-SRB" shares exact values (4.92, 4.13) with S01-B "AECI/PSLN-SRB", and "AECII-PSLN-SRB" shares 17.7, 17.5, 12.2 with S01-B.
- *Evidence / test:* A swap of S08-C columns B and C would reconcile both blocks; gating also differs between blocks.
- *Impact:* As printed, S08-C says Mn cuts epithelial uptake 4-fold; swapped, it says Mn has little effect. Neither reading is safe.
- *Handling:* No claim made about Mn effect on epithelial uptake.

**I-11 — Moderate — S07-C**

- *Cells:* S07!B15:C20
- *Finding:* Both columns are labelled "Ly6C-CD206+ MPhi" although two different sorted populations were transferred.
- *Evidence / test:* Annotation S07-C.
- *Impact:* Cannot tell which macrophage population increased lung Tregs (10.4% vs 5.1%).
- *Handling:* Excluded.

**I-12 — Moderate — S09-A panel 2**

- *Cells:* S09!X1:AS9
- *Finding:* Two cytokine panels carry the identical label "16h"; panel 2 values are systematically lower (e.g. PSLN-344 Ifnb1 log10 0.60 vs 1.56), consistent with a later timepoint (cf. S01-A 72 h).
- *Evidence / test:* Block labels S09!A1 and S09!X1.
- *Impact:* Timepoint of panel 2 unknown.
- *Handling:* Panel 2 excluded; panel 1 used as 16 h.

**I-13 — Moderate — S03-J, S13-E, S09-B, S09-F**

- *Cells:* S03!G16:J46 (S03!G46 blank); S13!R2:V30; S09!A11:D35; S09!A65:D88
- *Finding:* Stated n differs from observations: S03-J stated 9, 10 per group observed, one PSLN-344 animal has no day recorded, follow-up stated 22 d but maximum 21; S13-E stated 5, 7 observed; S09-B annotation says Sham has 7, workbook has 8; S09-F Sham has 7 while its weight block has 8.
- *Evidence / test:* Row counts per group.
- *Impact:* Uncertain animal accounting in these experiments.
- *Handling:* Blank S03!G46 treated as censored at day 21; S03-J flagged.

**I-14 — Moderate — S08-A, S08-B**

- *Cells:* S08!K2:M7; S08!G10:I11
- *Finding:* S08-A contains a group "PSLN-344/R848" that is not defined in the Materials section (only PSLN-212/R848 exists); S08-B reports CDN-1807 encapsulation for PSLN-R848, which contains no CDN-1807.
- *Evidence / test:* Annotation Materials vs block labels.
- *Impact:* These two groups are uninterpretable.
- *Handling:* Not used.

**I-15 — Minor — S06 rows 71-105**

- *Cells:* S06!G69, S06!M69
- *Finding:* Labels S06-E and S06-F are each used twice (day-60 blocks and imprinting blocks).
- *Evidence / test:* Block labels.
- *Impact:* Citation ambiguity only.
- *Handling:* Referred to as S06-E(d60)/S06-F(d60) and S06-E(imprint)/S06-F(imprint).

**I-16 — Minor — several**

- *Cells:* annotation
- *Finding:* Missing metadata: no timepoint for S07-B, S11-E, S13-H, S14-A; no challenge virus/dose/day for S15-L and S15-N (and no challenge day for the PR8 imprinting block); adjuvant of the PTX arm not stated (S02-C/E); age of WT controls in S01-C not stated (knockouts are 7-8 weeks); age of S08-A animals not stated; humane-endpoint criteria, randomisation and blinding not documented; females only.
- *Evidence / test:* Annotation.
- *Impact:* Limits interpretation and external defensibility.
- *Handling:* Stated wherever the block is used.

**I-17 — Minor — S08 rows 89-101**

- *Cells:* S08!A89:D101
- *Finding:* Unlabelled region in survival format (6 and 7 animals, all censored at day 14).
- *Evidence / test:* Annotation "S08, rows 89 to 101".
- *Impact:* Unattributable.
- *Handling:* Excluded.

**I-18 — Minor — S04-B Tfh:Tfr; S04-A**

- *Cells:* S04!A15:D19 vs S04!A8:D12; S04!B2:K5
- *Finding:* The Tfh:Tfr "ratio" is exactly (100 - Foxp3%)/Foxp3% for every animal (max error 4e-6): it contains no Tfh measurement. S04-A ICOS-low/high values are a total CXCR5+PD1+ frequency split by an ICOS fraction (sums are round numbers).
- *Evidence / test:* Algebraic check on all 20 animals.
- *Impact:* Tfh:Tfr must not be counted as an independent readout or biomarker.
- *Handling:* Tfh:Tfr not used; Foxp3% used directly.

**I-19 — Minor — Materials**

- *Cells:* annotation p.1
- *Finding:* Particle size, zeta potential, morphology, Mn2+ content and lyophilised stability are described as measured but are absent from the workbook.
- *Evidence / test:* Annotation Materials section.
- *Impact:* No CMC basis for dose or Mn exposure estimates.
- *Handling:* Listed as a Gate requirement.

Screened and **not** flagged: shared values between HAI/neutralisation blocks (two-fold dilution series make coincidences expected); shared 1-decimal values near baseline (e.g. S01-E day 0); three shared near-1 qPCR values between S02-F sham 16 h and S08-A CMP-204 1 µg (coarse scale; coincidence plausible).

# Appendix C. How every block was used

| Block | Content | Use in this review | Issues |
|----------------|--------------------------------|------------------------------|----------------|
| S01-A | Lung Ifnb1 16 h / 72 h, 8 formulations, aged and young | Used: innate signal, PD biomarker, restoration | — |
| S01-B | SRB uptake by AECII/AECI, liposomal vs free | Used: delivery | I-10 (conflicts with S08-C) |
| S01-C | AM uptake, WT vs Sftpa1/d knockout | Used with caveat | I-16 (WT age not stated) |
| S01-D / S01-E | Lung monocytes / CD11b+ DC, days 0–8 | Used | — |
| S01-F / S01-G | Lung cDC1 / cDC2, 72 h | S01-F used; S01-G is its complement | — |
| S02-A to S02-E | DC migration, MLN DC, antigen+ DC, CD40/CD86, OT-I priming, PTX | Used | I-16 (PTX-arm adjuvant not stated) |
| S02-F / S02-G / S02-H / S02-I | Gm-csf; GM-CSF rescue; IFNAR chimeras; CCR2 antagonist | Used: mechanism | — |
| S03-A, C, D, E, G, H | IgG, HAI, neutralisation, d14 | Used | HAI 0 → 5 |
| S03-B / S03-F | IgG2a/IgG1 quotients | Excluded; recomputed from S13 | I-04 |
| S03-I | Survival, homologous CA09 | Used (primary set), flagged | I-05 |
| S03-J | Survival, wild-type H5N1 d2 | Used (primary set), flagged | I-05, I-13 |
| S03-K / S03-L | GC B cells; Aicda/E47 (n = 3) | Used | — |
| S04-A / S04-B / S04-C / S04-D | Tfh ICOS split; Tfr; Tfh:Tfr; Tfr d30; lung Treg | Used except Tfh:Tfr | I-18 |
| S05-A / S05-B | NP366 tetramer kinetics | Excluded | I-09 |
| S05-C to S05-H | OT-I/PTX; Ki-67, GZMB, IFN-γ CD8 (d3, d14, d60) | Used | — |
| S05-I | Lung CD8 TRM d25 | Used with caveat | I-09 |
| S06-A / S06-B / S06-F(d60) | Survival: PR8 d14, PR8 d3, rgH5N1 d60 | Used; unflagged core set | S06-F: I-07 applies to control arm only |
| S06-C | Survival: rgH5N1 d14 | Used, minor flag | I-06 |
| S06-D | Survival: rgH5N1 d3 | Excluded (copy of S06-C) | I-01 |
| S06-E(d60) / S06-G | Survival: PR8 d60 / Perth H3N2 d60 | Used, flagged | I-06, I-07 |
| S06-E/F(imprint) | Survival after prior PR8 infection, 14-month mice | Used | I-15 |
| S07-A / S07-B / S07-C | Ly6C+CCR2+ macrophage counts; CCR2 antagonist; macrophage transfer | S07-B used; S07-A not used; S07-C excluded | I-11, I-16 |
| S08-A | Ifnb1 dose-response 1–40 µg | Used (PSLN-344/R848 arm excluded) | I-14 |
| S08-B | CDN encapsulation | Used (PSLN-R848 value not interpretable) | I-14 |
| S08-C | SRB uptake, PSLN vs PSLN-344 | Not used | I-10 |
| S08-D | Post-vaccination body weight | Used with caveat (reactogenicity) | I-02 |
| S08 rows 89–101 | Unlabelled | Excluded | I-17 |
| S09-A panel 1 / panel 2 | Lung cytokine mRNA (log10) | Panel 1 used as 16 h; panel 2 excluded | I-12 |
| S09-B / D / F | Survival, young mice | Used | I-13 (S09-B/F counts) |
| S09-C / E / G | Body weight, young mice | Cross-checks only | I-02, I-06 |
| S10-A | CNS Ifnb1/Tnf/Isg15 36 h | Used: safety, with sensitivity caveat | — |
| S11-A / S11-B | AM / neutrophils | Excluded | I-03 |
| S11-C / S11-D / S11-E | CBX; NK cells; CD206+ macrophages | Used (S11-E: timepoint not stated) | I-16 |
| S12-A | IFNAR-/- monocyte infiltration (n = 3, young) | Used (not significant) | — |
| S13-A to S13-D | IgG2a / IgG1 titres | Used (source for subclass ratio) | — |
| S13-E | Survival, young CA09 | Used | I-13 |
| S13-F / S13-G | Body weight for S03-I / S03-J | Not used | I-05 |
| S13-H / S13-I / S13-J / S14-A | MLN IgG+ B cells; post-boost IgG; IFN-γ CD8 | Used (S13-H, S14-A: timepoint not stated) | I-16 |
| S15 weight blocks (A–G, I, J, K, M, O) | Body weight after challenge | Cross-checks only | I-02, I-06, I-08 |
| S15-H | Survival: vaccine vs PSLN-344 vs both, d3 | Used with caveat | I-02 (S15-I weights) |
| S15-L / S15-N | Survival, aged C57BL/6 / Swiss Webster | Used (primary set), flagged | I-16; S15-L also I-06 |

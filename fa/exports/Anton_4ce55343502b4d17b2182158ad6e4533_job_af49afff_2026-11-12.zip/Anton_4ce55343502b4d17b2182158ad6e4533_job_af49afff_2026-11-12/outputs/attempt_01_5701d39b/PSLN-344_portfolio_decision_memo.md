# PSLN-344: Portfolio Review Decision Memo

**Asset:** PSLN-344. This is a pulmonary-surfactant-biomimetic liposome (DPPC/DPPG/DPPE-PEG2000/cholesterol) that carries the STING agonist CDN-1807 and incorporates Mn2+ by coordination polymerisation. It is given intranasally as an adjuvant for inactivated influenza vaccine in older adults.

**Evidence base:** `adjuvant_program_dataset.xlsx` (15 sheets: 2,121 per-animal measurements, 527 time-to-event records, 4,076 body-weight cells) and `adjuvant_program_annotation.pdf`. Both are treated as ground truth. Every number below was recomputed from workbook cells. Each number cites its block (e.g. S03-C) and a ledger ID (e.g. L22). `numbers_ledger.csv` gives the exact cell range, the reduction and the confidence interval for each ledger ID, and Appendix A states the reduction rules. Integrity findings are labelled I-xx and listed in `data_integrity_log.csv`.

**Comparator language:** "PSLN-212" is the same liposome and CDN-1807 without Mn. "Aged" means at least 20 months old; "young" means 7 to 8 weeks. Unless stated otherwise, mice are female BALB/c, vaccinated once intranasally with 20 µg adjuvant.

---

## 1. Decision

**Recommendation: No. Do not advance PSLN-344 into IND-enabling development on the current data package.**

**Disposition:** fund a capped, roughly 6-month "verify-or-terminate" gate with two parts:

- **Study 0:** source-data verification of the in-vivo efficacy records.
- **Study 1:** one independent, blinded study in aged mice against the licensed older-adult benchmarks.

Re-decide at the gate. If the gate is not funded, or if it fails, terminate. Section 7 sets out what we would then be dropping.

**The case in six points**

1. **The biology is large and internally coherent in our data.**
   - In aged lungs, Mn returns the 16-h Ifnb1 response to the young level: geometric mean (GM) 36.9-fold vs 16.5-fold for PSLN-212, against 37.5-fold in young animals (S01-A; L01).
   - Mn raises the ceiling of the response rather than its potency: Emax 57.7 vs 15.6, with similar ED50 (S08-A; L03).
   - Across 35 immunological readouts, PSLN-344 closes a median **71%** of the age-related gap between aged and young PSLN-212 (IQR 62–83%; L36).
   - Examples: anti-CA09 IgG GM ratio 18.6 (9.1–37.9) vs PSLN-212 (S03-A; L20); HAI GMT 368 vs 46 (S03-C; L22); IFN-γ+ CD8 T cells at day 60 9.9% vs 3.0% (S05-G; L32b).
2. **The survival advantage over PSLN-212 survives every integrity exclusion I could apply.**
   - As printed: 68/80 (85%) vs 11/80 (14%) (L41-T1).
   - In the three experiments whose survival records agree with their own body-weight records: **16/21 (76%) vs 2/21 (10%)**, exact stratified p = 3×10⁻⁵ (S06-A, S06-B, S06-F; L41-T3-lenient).
   - Under the strictest rule: 10/14 vs 1/14 (L41-T3).
3. **The efficacy package is not decision-grade.** The problems can be seen in the workbook alone, so partner or regulatory diligence would find them too.
   - One survival block (S06-D, day-3 H5N1) is a record-for-record copy of another (S06-C, day-14): 28/28 records identical (I-01).
   - Body-weight trajectories recur across different experiments, strains and arms: 18 animal pairs share ≥4 identical same-day values, against 0 in 20 permutation nulls (I-02).
   - 8 of 17 survival blocks disagree with their own body-weight records (I-03).
   - Two antibody blocks and one qPCR panel are mislabelled (I-04, I-05).
   - **Most of the claims that would differentiate PSLN-344 rest on the flagged records:** 3-day protection against H5N1, antigen dependence of early protection, generality across mouse strains, protection in previously infected animals, two of the three day-60 durability experiments, and young day-180 durability. Day-3 protection against PR8 (S06-B) and one day-60 experiment (S06-F) are clean.
4. **The package does not answer the questions that decide clinical value.**
   - There is no licensed older-adult comparator (MF59-type or high-dose intramuscular vaccine).
   - No depletion or transfer experiment ties any immune arm to survival.
   - There are no toxicology data and no manganese biodistribution data.
   - Design vs delivery: the uptake data show the formulation acting on alveolar cells (alveolar type II cells and SP-A/D-dependent macrophage uptake; S01-B, S01-C; L16a, L16c), whereas human nasal sprays deposit in the nose.
   - All animals are female BALB/c. The antigen is whole inactivated virus, not the split or subunit formats used clinically. Mucosal IgA was never measured.
   - The inflammatory signal in aged lungs persists at 72 h: Ifnb1 2.85× the young level (S01-A; L02).
   - Unchallenged aged controls died at 19% within 14 days (L44).
5. **A kill is premature.** The strictest subset still shows a 10/14 vs 1/14 effect (L41-T3), and 35 of 36 readouts move toward the young benchmark (L36). The one question that would justify the spend — does it beat what older adults already receive? — can be answered in a single study.
6. **Advancing now is indefensible.** It would commit IND money and external claims to records we cannot verify.

**Forward view in three lines** (detail in Section 5)

- **What drives protection:** Mn restores the amplitude of the airway STING/type-I-IFN response in aged lungs. That re-opens an IFNAR-, GM-CSF- and CCR2-dependent monocyte-to-dendritic-cell route, which yields broad adaptive immunity. Protection persists without any HA or NA match between vaccine and challenge virus (20/28 vs 1/28; L42-0). This points to cross-reactive T cells rather than strain-specific antibody. It is a hypothesis: it has not been causally tested.
- **Biomarker:** yes, as a *pharmacodynamic* marker, not a validated efficacy marker. The candidate is the early airway IFN-β/CCL2/GM-CSF signature at 16–36 h. CCL2 separates PSLN-344 from PSLN-212 77-fold at 16 h (S09-A; L04-Ccl2). It can be measured non-invasively in people (nasal lining fluid). Its roles would be dose selection and target engagement in Phase 1, and possibly patient enrichment; it is not a surrogate endpoint. The efficacy correlate to test is IFN-γ+ CD8 T cells against conserved internal proteins.
- **Next studies:**
  - Gate (≤6 months): Study 0 (audit) and Study 1 (blinded benchmark efficacy).
  - After the gate: mechanism and correlates; human ex-vivo bridging and delivery route; GLP toxicology including manganese; ferret; then first-in-human with a PD biomarker (Section 5.3).

---

## 2. What the data show: the case for the biology

Figures: `figures/fig1_restoration_profile.png`, `fig5_mechanism.png`, `fig6_immunogenicity.png`.

### 2.1 Innate sensing in aged lungs is restored by raising the ceiling, not the potency

| Readout (block; ledger) | Aged PSLN-212 | Aged PSLN-344 | Young PSLN-212 | PSLN-344 vs PSLN-212 |
|---|---|---|---|---|
| Lung Ifnb1, 16 h, fold (S01-A; L01) | 16.5 (14.0–19.5) | **36.9** (31.6–43.1) | 37.5 (33.5–41.9) | ×2.23 (1.85–2.69); restoration R = 0.98 |
| Ifnb1 Emax, sigmoid fit to 1–40 µg dose series (S08-A; L03) | 15.6 (13.2–20.0) | **57.7** (48.1–72.4) | n/a | ED50 10.8 vs 13.3 µg (similar potency) |
| Lung Ccl2, 16 h, log10 fold (S09-A; L04-Ccl2; n=3) | 0.88 | **2.77** | 3.14 | ×77 (Hedges g 5.6, p = 0.002) |
| Lung Gm-csf, 16 h / 36 h (S02-F; L05) | 1.42 / 1.59 | **5.99 / 8.52** | n/a | ×4.2 / ×5.4 |
| Lung monocytes, day 4, % (S01-D; L06) | 16.7 | **30.6** | 32.2 | +13.8 pp (8.1–19.5); R = 0.89 |
| CCR7+ migratory CD11b+ DC, % (S02-A; L07) | 7.3 | **30.7** | 35.0 | +23.4 pp; R = 0.84 |
| MLN DC carrying antigen, % (S02-C; L08) | 1.8 | **7.1** | 9.4 | +5.3 pp; pertussis toxin (blocks DC migration) 2.4 (L08b) |
| OT-I priming by MLN DC, % (S02-E; L09) | 0.8 | **18.7** | 26.2 | +17.9 pp; pertussis toxin 2.6 (L09b) |
| CD40+ / CD86+ MLN DC, % (S02-D; L10a,b) | 5.6 / 8.1 | 11.2 / 14.5 | 38.7 / 37.9 | R = 0.17 / 0.22 (largely *not* restored) |

More PSLN-212 cannot reproduce PSLN-344:

- Doubling PSLN-212 from 20 to 40 µg adds only ×1.18 (p = 0.28).
- 20 µg of PSLN-344 gives ×3.09 (2.12–4.52) the response of 40 µg PSLN-212 (S08-A; L03).

**Dependencies tested in the mechanistic blocks** (Fig. 5C). None was tested against survival.

- Monocyte-derived DC formation needs IFNAR on bone-marrow cells: 19.7% vs 2.1% (S02-H; L12a). GM-CSF partly rescues IFNAR-deficient cells (12.4%; L12b) and adds to PSLN-212 (13.8% vs 5.9%; S02-G; L13).
- CCR2 blockade (INCB3344) lowers lung monocytes from 9.9% to 3.3% (S07-B; L14a). In young animals only, it lowers GZMB+ CD8 T cells from 6.8% to 1.4% (S02-I; L14c).
- Carbenoxolone (a gap-junction blocker) lowers recruited monocytes from 7.3% to 3.1% (S11-C; L15).
- Alveolar-macrophage uptake depends on surfactant proteins A/D: 43.1% in wild-type vs 12.7% in Sftpa1/Sftpd knockouts (S01-C; L16c).

### 2.2 Adaptive immunity is broadly restored, mostly partially

| Readout (block; ledger) | Aged PSLN-212 | Aged PSLN-344 | Young PSLN-212 | PSLN-344 vs PSLN-212 | R |
|---|---|---|---|---|---|
| IgG anti-CA09, day 14, GMT (S03-A; L20) | 393 | **7,305** | 11,959 | ×18.6 (9.1–37.9) | 0.86 |
| IgG anti-Aichi, day 14 (S03-E; L21) | 426 | **5,701** | 13,855 | ×13.4 (6.1–29.6) | 0.75 |
| HAI anti-CA09 (S03-C; L22) | 46 | **368** (5/5 animals ≥160) | 485 | ×8.0 (3.9–16.4) | 0.88 |
| HAI anti-Aichi (S03-G; L23) | 35 | **320** (5/5 ≥160) | 368 | ×9.2 (4.2–20.2) | 0.94 |
| Neutralising antibody anti-CA09 / anti-Aichi (S03-D/H; L24) | 418 / 276 | **3,840 / 2,533** | 6,686 / 4,411 | ×9.2 / ×9.2 | 0.80 / 0.80 |
| IgG2a/IgG1, recomputed from S13-A–D (L26) | 0.55 / 0.47 | **1.85 / 2.30** | 2.50 / 2.79 | ×3.4 / ×5.0 | 0.80 / 0.89 |
| Germinal-centre B cells, day 7, % (S03-K; L27) | 2.3 | **6.5** | 9.8 | +4.2 pp | 0.56 |
| ICOS-high Tfh, day 7, % (S04-A; L28) | 3.8 | **10.3** | 13.6 | +6.4 pp | 0.66 |
| Foxp3+ Tfr, day 7, % (lower is better) (S04-B; L29) | 26.7 | **10.8** | 7.1 | −15.9 pp | 0.81 |
| Lung Ki-67+ / GZMB+ CD8, day 3, % (S05-D/E; L31) | 3.5 / 3.0 | **9.4 / 5.7** | 9.9 / 9.6 | +5.9 / +2.7 pp | 0.91 / 0.41 |
| IFN-γ+ CD8 (restimulated with rgH5N1), day 14 / day 60, % (S05-F/G; L32) | 1.5 / 3.0 | **6.4 / 9.9** | 9.2 / 14.4 | +4.9 / +6.8 pp | 0.63 / 0.60 |
| Lung CD69+CD103+ resident-memory CD8, day 25, % (S05-I; L34) | 1.0 | **4.0** | 6.0 | +3.0 pp | 0.59 |

**Summary across the readout catalogue** (L36):

- 35 of 36 readouts moved toward the young benchmark. The exception is Ifnb1 at 72 h, which stays above the young level.
- For 34 of 35, the restoration-index CI excludes zero.
- For 15 of 35, PSLN-344 is statistically indistinguishable from young (CI includes R = 1).
- 27 of 36 PSLN-344 vs PSLN-212 contrasts survive Holm correction.
- Median restoration by domain: humoral 0.80, innate 0.70, cellular 0.63.

**Correction that matters:** read as printed, S03-B and S03-F make PSLN-344 look Th2-skewed (IgG2a/IgG1 GM 0.55; L26c). Those columns are mislabelled (I-04). Recomputed per animal from the subclass titres, the ratio is 1.85–2.30, like young animals.

### 2.3 Protection

| Experiment (block) | Challenge, interval after vaccination | Aged PSLN-344 | Aged PSLN-212 | Aged sham | Young PSLN-212 | Integrity |
|---|---|---|---|---|---|---|
| S03-I | 10× LD50 homologous CA09, d14 | 7/7 | 0/7 | 0/7 | 7/7 | flagged (I-03) |
| S03-J | wild-type VN04 H5N1, d2 (rgH5N1 vaccine) | 10/10 | 3/10 | 1/10 | n/a | flagged (I-03, I-10) |
| S06-A | PR8 H1N1 after H3N2 vaccine, d14 | **6/7** | **1/7** | 0/7 | 7/7 | concordant; some trajectories shared elsewhere |
| S06-B | PR8 H1N1 after H3N2 vaccine, d3 | **5/7** | **0/7** | 0/7 | 7/7 | **clean** |
| S06-C | rgH5N1 after bivalent vaccine, d14 | 7/7 | 2/7 | 0/7 | 7/7 | flagged |
| S06-D | rgH5N1 after bivalent vaccine, d3 | (7/7) | (2/7) | (0/7) | (7/7) | **exact copy of S06-C; excluded** |
| S06-E | PR8 after H3N2 vaccine, d60 | 5/7 | 0/7 | 0/7 | 7/7 | flagged |
| S06-F | rgH5N1 after bivalent vaccine, d60 | **5/7** | **1/7** | 0/7 | 7/7 | **clean** |
| S06-G | Perth H3N2 after H1N1 vaccine, d60 | 4/7 | 0/7 | 0/7 | 7/7 | flagged; untreated arm 3/7 died |
| S15-L / S15-N | C57BL/6 / Swiss Webster (challenge not stated) | 6/7 / 6/7 | 0/7 / 2/7 | 0/7 / 0/7 | 6/7 / 7/7 | flagged (copied weights) |

Source: L40-*. Statistics per block: S06-A log-rank p = 0.008; S06-B p = 0.0009; S06-F p = 0.009.

**Pooled PSLN-344 vs PSLN-212 (Fig. 3A)**

| Tier | PSLN-344 | PSLN-212 | Mantel-Haenszel risk difference | Exact stratified p |
|---|---|---|---|---|
| As printed (L41-T1) | 68/80 (85%) | 11/80 (14%) | 0.71 | 10⁻⁵ |
| Excluding the S06-D copy (L41-T2) | 61/73 (84%) | 9/73 (12%) | 0.71 | 10⁻⁵ |
| Concordant blocks (S06-A, B, F; L41-T3-lenient) | 16/21 (76%) | 2/21 (10%) | 0.67 | 3×10⁻⁵ |
| Strict (S06-B, F; L41-T3) | 10/14 (71%) | 1/14 (7%) | 0.64 | 7×10⁻⁴ |

- Survival restoration index: R = 0.74 (0.53–0.90) (L43). This is in line with the median immunological R of 0.71.
- **Young mice gain nothing from Mn:** PSLN-344Y and PSLN-212Y are each 8/8 in S09-B, D and F, and 7/7 in S13-E (L45). The value of the asset is confined to the age deficit.
- **Prior infection does not blunt PSLN-344:** 6/7 survived with or without prior PR8 infection, for both challenges (S06 imprint blocks; L46). Caveats: the mice were 14 months old at vaccination, and there is no imprinted-but-unvaccinated control.

### 2.4 Tolerability signals in the data

- **Post-vaccination weight** (S08-D; L50):
  - PSLN-344: mean nadir 96.4% (lowest animal 94.2%); weight-loss area 20.0 %-days, vs 6.2 for vaccine alone and 11.1 for PSLN-212.
  - PSLN-212/R848: nadir 90.0% (lowest 84.7%); area 48.6; one animal missing at day 10.
- **CNS transcripts at 36 h** (S10-A; L51):
  - PSLN-344 vs PBS: Ifnb1 ×1.30 (0.84–2.01); Isg15 ×1.16 (0.79–1.72); Tnf ×1.57 (1.05–2.34; p = 0.033; exact Mann-Whitney p = 0.056).
  - The cholera-toxin positive control gave ×5.5, ×2.7 and ×3.4 respectively.
  - This is reassuring relative to the positive control. It is not a manganese-safety study.
- **Inflammation persists in aged lungs at 72 h.** S09-A panel 2 is the 72-h data (I-05). Aged PSLN-344 vs young PSLN-212 at 72 h:
  - Ifnb1 ×2.85 (S01-A; L02).
  - Tnf ×17.8, Il10 ×36.6, Il6 ×2.3 (n = 3; L04).
  - Aged PSLN-212 shows similar persistence, so most of this is an ageing effect that Mn does not correct.
- **Encapsulation efficiency:** 54.8% vs 59.6% for PSLN-212 (p = 0.29) (S08-B; L52). The methods describe particle-size and zeta-potential (DLS) and TEM measurements and lyophilised storage at −20 °C, but the workbook contains no such data and no stability data.

---

## 3. Why not advance now

### 3.1 Data integrity

Full log: `data_integrity_log.csv`. Evidence panels: `fig4_integrity_evidence.png`. I have not characterised the cause of any finding; that is for QA with the source records.

| ID | Severity | Finding | What it undermines |
|---|---|---|---|
| I-01 | Critical | S06-D (day-3 rgH5N1) matches S06-C (day-14) in 28/28 records. S06-D's own weight record (S15-D) implies 2 PSLN-344 and 2 young deaths; S06-D records none. | "Heterosubtypic H5N1 protection 3 days after one dose" |
| I-02 | Critical | Body-weight trajectories recur across independent experiments, strains and arms: 18 animal pairs share ≥4 identical same-day values (0 in 20 permutation nulls). Examples: young BALB/c PSLN-344Y (S09-E) = aged C57BL/6 PSLN-212(Y) (S15-M); S15-C PSLN-344 = S15-I Vaccine+PSLN-344 on days 2–12. There are also copies shifted by whole numbers with identical decimals (S08-D → S15-F; S15-A/J/M). Eleven blocks are involved. | Body weight as corroboration. It leaves unverifiable: antigen dependence (S15-H/I), C57BL/6 and Swiss Webster results (S15-L–O), imprinting (S15-J/K), young day-180 durability (S09-F/G). |
| I-03 | Major | 8 of 17 survival blocks disagree with their own weight records. S13-F and S13-G contain a "Naive" arm that does not exist in S03-I or S03-J. | Comparator arms of S03-I (homologous) and S03-J (wild-type H5N1) |
| I-04 | Major | S03-B/F IgG2a/IgG1 labels rotated relative to the S13 subclass titres | A false Th2-skew reading |
| I-05 | Major | S09-A panel 2, printed "16h", matches the S01-A 72-h values 21/21 | A false 16-h replicate |
| I-06 | Major | S11-A (alveolar macrophages) and S11-B (neutrophils) share 35/100 values | Both blocks |
| I-07/08 | Major | S07-C arms carry identical labels. S05-A/B have n = 2 against a stated 3, conflicting antigens, and an H-2Db tetramer used in H-2d mice. | Macrophage→Treg mechanism; NP-tetramer kinetics |
| I-09 | Moderate | Unchallenged aged controls: 4/21 died (19%; 5–42%) | Aged survival endpoints in general; PSLN-344 day-60 deaths (7/21) cannot be distinguished from this background (p = 0.48) |

*Checked and ruled out as integrity issues:*

- Repeated 6-digit values in S09-A: all five lie on the ΔΔCt grid, so collisions are expected.
- Positional matches between the HAI blocks: HAI takes only two-fold dilution values.
- Single 3-significant-figure values shared across blocks: expected by chance.

### 3.2 The comparator that matters is missing

- Every arm is our own liposome (±Mn), a cGAMP liposome, sham, or vaccine alone.
- Older adults already receive MF59-adjuvanted or high-dose intramuscular vaccines (context, not our data). We have no data on whether PSLN-344 beats them, matches them, or adds to them.
- Survival is a blunt endpoint for that comparison. At the effect sizes seen, a benchmark that protects 40% of aged mice would need about 40 mice per arm for 88% power (L70). Study 1 therefore uses lung viral titre as its primary endpoint.

### 3.3 The mechanism of protection is untested

- Every mechanistic intervention (IFNAR, GM-CSF, CCR2, gap junctions, pertussis toxin) was read out on an immune cell population, never on survival or viral load.
- Immunogenicity and challenge were run in different animals, so no per-animal correlate of protection can be computed.
- At group level, 32 of 35 immune readouts rank the four arms exactly as survival does (sham < PSLN-212 < PSLN-344 < young; the 3 exceptions are regulatory-T-cell readouts where sham and PSLN-212 swap; L37). With four arms, correlation therefore cannot pick the driver.
- The one experiment designed to separate innate from adaptive protection (S15-H: 6/7 with vaccine + PSLN-344 vs 0/7 with PSLN-344 alone; L47) is one whose weight record is copied (I-02).

### 3.4 Safety and translation gaps, each potentially program-ending

1. **Manganese given intranasally.**
   - Intranasal Mn2+ can reach the olfactory bulb via olfactory neurons in rodents (context).
   - We have no Mn dose, no Mn:CDN ratio, no biodistribution and no neurotoxicology.
   - S10-A measured three transcripts at one timepoint.
2. **History of intranasal adjuvants.** An intranasal influenza vaccine adjuvanted with heat-labile toxin was withdrawn after cases of facial palsy (context). The cholera-toxin positive control in S10-A addresses the same concern. Facial-nerve and olfactory safety will gate any clinical use.
3. **Delivery site.**
   - The design works through alveolar epithelial and macrophage uptake (AECII 15.8% vs 0.4% for free dye, L16a; SP-A/D-dependent macrophage uptake, L16c).
   - Mouse intranasal instillation reaches the lung; a human nasal spray mostly does not (context).
   - Either efficacy survives nose-restricted delivery, or we need an inhaled device.
4. **Antigen format.** All efficacy used formalin-inactivated whole virus, which contains the internal proteins (NP, M1) that cross-reactive T cells recognise. Licensed older-adult vaccines are split or subunit products with less internal protein (context). The heterosubtypic advantage may not transfer.
5. **Population.** All animals are female. Prior immunity was tested only in 14-month-old mice. Aged lungs show persistent inflammation at 72 h (§2.4).
6. **Colony health.** Background mortality of 19% in unchallenged aged mice (L44) must be controlled before any aged survival endpoint can be trusted.

### 3.5 What would change the recommendation (gate criteria)

Advance to IND-enabling only if all four hold:

1. **Study 0:** at least 95% of efficacy records trace to primary records, and I-01/I-02 are explained by documented clerical error with originals recovered.
2. **Study 1, replication:** PSLN-344 beats PSLN-212 again in aged mice of both sexes and two strains.
3. **Study 1, benchmark:** PSLN-344 is non-inferior or superior to the best intramuscular benchmark on heterosubtypic lung viral load.
4. **Study 1, colony:** background mortality is ≤10%.

If copying is not explained, terminate and refer per research-integrity policy.

---

## 4. Anticipated committee challenges

- **"The effects are enormous and consistent. Isn't this over-cautious?"**
  - The PSLN-344 vs PSLN-212 effect does survive, even in the strictest subset (10/14 vs 1/14; L41-T3). I am not disputing the biology.
  - What we cannot defend are most of the *differentiating* claims: 3-day H5N1 protection, antigen dependence, strain generality, imprinting, young day-180 durability, and two of the three day-60 experiments. Those are exactly the claims on flagged records. What remains clean is day-3 PR8 protection (S06-B) and day-60 H5N1 protection (S06-F).
  - Advancing means committing those claims to an IND and to partners.
- **"Aren't these just clerical slips?"**
  - Some are: the rotated labels (I-04) and the mislabelled timepoint (I-05).
  - Others cannot be explained as transcription error. An entire survival block reappears under a different experiment. Individual animals' weight trajectories reappear in other experiments and mouse strains, some shifted by whole numbers with identical decimals.
  - That needs source-data verification, not a re-type.
- **"Then why not kill it now?"**
  - Even the most conservative data subsets show 64–71-point absolute survival gains in aged mice (L41-T3, L41-T3-lenient), including heterosubtypic challenge without HA/NA match (S06-A, S06-B: 11/14 vs 1/14; L42-1).
  - The unanswered commercial question (vs MF59 or high-dose) costs one study.
- **"HAI is the licensure currency, and PSLN-344 is near young levels on HAI. Isn't that enough?"**
  - HAI would likely pass (GMT 368, all animals ≥160; L22b).
  - But the differentiator (heterosubtypic, T-cell-weighted protection) does not register on HAI, and the comparators also pass on HAI.
- **"Is manganese a showstopper?"** Unknown, and that is the point. There is no Mn biodistribution or neurotoxicity data at all (§3.4).
- **"Could we partner it out as is?"** Diligence would find I-01 to I-09 from the workbook alone.

---

## 5. Forward view

### 5.1 What is actually driving the protection?

Evidence is graded below from strongest to weakest.

1. **Established in our data: the upstream lesion and its correction.**
   - Aged lungs under-respond to the STING agonist: Ifnb1 16.5-fold in aged vs 37.5-fold in young (L01).
   - Mn raises the *ceiling* of that response (Emax ×3.7) rather than its potency (L03), and returns it to the young level (R = 0.98).
   - Young animals are protected with or without Mn (L45). Mn still raises young Ifnb1 (50.2 vs 37.5-fold; L01b), but protection in young mice is already at ceiling. Mn's *protective* value is therefore confined to compensating for the age-related defect.
2. **Supported, but not linked to survival: how the signal is passed on.**
   - IFNAR-dependent (L12a) and GM-CSF-supported (L05, L12b, L13) differentiation of monocytes into dendritic cells.
   - CCR2-dependent monocyte recruitment (L14a), with lung Ccl2 77× higher than with PSLN-212 (L04-Ccl2).
   - Monocyte fate appears to switch. Without Mn, aged lungs accumulate Ly6C+CCR2+ inflammatory macrophages: GM 18.5 vs 3.4 ×10⁵ at day 5 (S07-A; n = 3; Welch p = 0.001, exact Mann-Whitney p = 0.10; L17-d5). Lung CD206+ macrophages are also lower with PSLN-344 (48.9% vs 71.5%; S11-E; L11b). This fits Mn, via GM-CSF, steering recruited monocytes toward dendritic cells rather than macrophages.
   - More cDC1 (L11) and more migratory DCs (L07), carrying antigen to the MLN and priming T cells there (L08, L09; blocked by pertussis toxin).
   - Lung T-cell priming that does not depend on migration (S05-C; n = 3; L18a).
3. **Inferred from the challenge designs: the effector arm.**
   - PSLN-344 protects when neither HA nor NA is shared between vaccine and challenge virus: 20/28 vs 1/28 overall, and 11/14 vs 1/14 in the concordant blocks (L42-0, L42-1). Strain-specific HA or NA antibodies cannot be the main driver of that protection.
   - The readouts specific to heterologous antigen fit a T-cell mechanism. IFN-γ+ CD8 T cells restimulated with H5N1 antigen are 6.4% vs 1.5% at day 14 and 9.9% vs 3.0% at day 60 (L32a,b). That persistence matches the clean day-60 H5N1 protection (S06-F 5/7 vs 1/7). Lung resident-memory CD8 are 4.0% vs 1.0% (L34).
   - Antibody adds protection when antigens match: PSLN-344 survival is 94% with HA/NA match vs 71% without, p = 0.036 (L42-x).
4. **Open: whether early (day 2–3) protection needs antigen.**
   - The only test (S15-H; L47) is compromised, and the day-3 H5N1 record (S06-D) is a duplicate.
   - An antigen-independent antiviral state could contribute (Ifnb1 still ×4.2 at 72 h; L02). The clean day-3 block (S06-B, 5/7 vs 0/7) has no adjuvant-only arm.
5. **Not required: full restoration of DC co-stimulation.**
   - CD40 and CD86 are only 17–22% restored while survival is 74% restored (L10a,b; L43), so full restoration of co-stimulation is not necessary for protection.

**Bottom line.** Protection is best explained by restored innate sensing driving broad adaptive immunity, with cross-reactive CD8 T cells as the leading candidate for the heterosubtypic component and antibody adding to homologous protection. This is a well-supported hypothesis, not a demonstrated mechanism; the experiment that would settle it is Study 2.

### 5.2 Is there a biomarker of efficacy worth carrying forward?

**Short answer:** no biomarker in this dataset can be validated as an *efficacy* (protection) correlate. Immune readouts and challenge outcomes come from different animals, and 32 of 35 readouts rank the arms the same way (§3.3; L37). **There is, however, a pharmacodynamic biomarker worth carrying forward, and a candidate efficacy correlate to test.**

| Candidate | Separates PSLN-344 from PSLN-212 in aged mice | Restored toward young? | Timing | Upstream of a tested dependency? | Human measurement | Verdict |
|---|---|---|---|---|---|---|
| Airway Ifnb1 (S01-A, S08-A) | ×2.2 (L01) | Fully (R 0.98) | 16 h | IFNAR → monocyte-derived DC | Nasal ISG/IFN (proxy) | **Core of the PD signature.** Has an independent dose–response (Emax). |
| Airway Ccl2 (S09-A) | ×77, Hedges g 5.6 (L04-Ccl2) | R 0.84 (L04-R) | 16 h | CCR2 → monocytes, GZMB+ CD8 | Nasal or serum CCL2 | **Core of the PD signature.** Largest separation; n = 3, so needs replication. |
| Ccl3, Ccl5, Il6 (S09-A) | ×27, ×7.6, ×6.5 (L04) | R 0.83, 0.64, 0.78 (L04-R) | 16 h | Partly | Yes | Include in the panel |
| Gm-csf (S02-F) | ×4.2–5.4 (L05) | No young arm | 16–36 h | GM-CSF → monocyte-derived DC | Nasal GM-CSF | Include |
| 72-h persistence: Ifnb1, Tnf, Il10 (S01-A, S09-A) | n/a | Worse than young (2.9×, 18×, 37×) | 72 h | — | Yes | **Carry as a safety/reactogenicity marker** |
| HAI (S03-C/G) | ×8–9 (L22, L23) | R 0.88–0.94 | d14 | — | Standard | Regulatory anchor; blind to heterosubtypic protection |
| IFN-γ+ CD8 against heterologous antigen (S05-F/G, S14-A) | +4.9 to +7.9 pp (L32, L33) | R 0.60–0.75 | d14–60 | — | PBMC ELISpot or ICS against NP/M1 peptides | **Candidate efficacy correlate; validate in Study 2** |
| Lung resident-memory CD8 (S05-I) | +3.0 pp (L34) | R 0.59 | d25 | — | Nasal/BAL (research setting) | Exploratory |
| ICOS-high Tfh (S04-A) | +6.4 pp (L28) | R 0.66 | d7 | — | Blood circulating Tfh at day 7 | Exploratory |
| Tfh:Tfr (S04-B) | — | — | — | — | — | **Drop:** derived from Foxp3% (I-15) |
| CD40/CD86 on DCs (S02-D) | +5.6/+6.4 pp | R 0.17/0.22 | d3 | — | — | **Drop:** not necessary for protection |
| Mucosal IgA | Not measured | — | — | — | Nasal IgA | **Gap:** add in Studies 1 and 2 |

**Could it go into patients, and in what role?** Yes: the early airway IFN-β/CCL2/GM-CSF signature (plus CXCL10 as a human bridging analyte) can be sampled non-invasively by nasal lining-fluid absorption at 6, 24 and 72 h, with a blood interferon-stimulated-gene (ISG) score on day 1 for systemic spill-over. Its roles, in priority order:

1. **Pharmacodynamic / target-engagement marker for dose selection in Phase 1.** It answers the one human question the mouse data cannot: does Mn restore a young-like airway response in people over 65? The sigmoid Emax behaviour (L03) means the dose–response can be mapped.
2. **Safety / reactogenicity marker,** via persistence at 72 h (L02, L04).
3. **Potential enrichment marker.** The benefit is confined to the age deficit (L45), so older adults with a low airway IFN response are the likely responders.
4. **In manufacturing,** a matched in-vitro IFN-β potency assay can serve as the release test.

It should **not** be used as a surrogate endpoint. The efficacy correlate to take into the clinic as exploratory is IFN-γ+ CD8 T cells against conserved NP/M1, and only if Study 2 shows CD8 depletion abolishes heterosubtypic protection. This biomarker concept is portable to any mucosal adjuvant for older adults even if PSLN-344 is dropped.

**Could the adjuvant itself go into patients, and in what role?** Not before the gate, GLP toxicology and manganese biodistribution. If it is rescued, the role to test is as a *mucosal adjuvant for older adults where breadth and speed matter*: pandemic or pre-pandemic (H5N1) vaccination, or a heterosubtypic booster on top of licensed intramuscular seasonal vaccination. It should not be positioned as a like-for-like seasonal replacement licensed on HAI, where its differentiator is invisible and the comparators are strong.

### 5.3 Next studies: what each must establish

**Gate (≤6 months; approve now)**

**Study 0: source-data verification and forensic audit.** Weeks 0–6; QA plus an independent statistician.

- **Must establish:** whether the efficacy records are real and correctly labelled.
- **Scope:** all survival and body-weight blocks; S11-A/B, S03-B/F, S09-A, S07-C, S05-A/B, and S08 rows 89–101.
- **Endpoints:** share of workbook records traced to primary records (daily weight and clinical-score sheets, euthanasia logs, LD50 titrations, FCS files, plate-reader exports, raw Ct values); documented explanation for I-01 to I-08.
- **Decision:** pass at ≥95% traced with I-01/I-02 explained. Otherwise invalidate the affected experiments and terminate.

**Study 1: independent, blinded confirmatory efficacy study against licensed benchmarks.** Months 1–6; contract or independent lab; about 300 aged mice.

- **Must establish:** that PSLN-344 replicates against PSLN-212 and is non-inferior or superior to the best intramuscular benchmark.
- **Population:** aged mice (20–22 months) of both sexes from a health-monitored colony; unchallenged aged controls in every cohort; a young reference arm.
- **Primary cohort:** aged BALB/c; fully heterosubtypic challenge with no HA/NA match (H3N2 vaccine → PR8 H1N1) on day 28. Arms:
  - Antigen + PSLN-344 intranasal
  - Antigen + PSLN-212 intranasal
  - Antigen + empty liposome intranasal
  - PSLN-344 alone (no antigen)
  - Antigen + squalene emulsion (MF59-like) intramuscular
  - High-dose antigen intramuscular
  - Young + antigen + PSLN-212
  - Unchallenged aged controls
  - One extra arm: PSLN-344 + the clinically intended split/subunit antigen
- **Secondary cohorts** (n = 12 per arm):
  - Day-3 challenge: PSLN-344, PSLN-212, empty liposome, PSLN-344 alone. This tests early protection and antigen dependence directly.
  - Homologous CA09 challenge: PSLN-344, PSLN-212, both intramuscular benchmarks.
  - C57BL/6 replicate of the primary comparison: PSLN-344, PSLN-212, MF59-like.
  - A day-90 durability cohort can be added if timelines allow; otherwise it moves after the gate.
- **Primary endpoint:** lung viral titre on day 4 after challenge, in 8 satellite animals per arm.
- **Key secondary endpoints:** 14-day survival in 12 animals per arm, with a pre-specified humane endpoint; weight-loss area; lung histopathology.
- **Readouts:** pre-challenge samples from every challenged animal, so that per-animal correlates can be computed:
  - Antibody: HAI, microneutralisation, IgG, nasal/BAL IgA.
  - T cells: MHC-matched NP tetramer (NP147 in BALB/c, NP366 in C57BL/6); IFN-γ ELISpot; resident-memory cells by intravascular labelling.
  - 16-h PD signature.
- **Size:**
  - 12 per arm gives 91% power to replicate the 76% vs 10% survival difference (L70). Survival is too blunt to compare against a benchmark: against a 40%-survival benchmark, about 40 per arm would be needed (L70).
  - Viral titre: 8 per arm detects a 1.0 log10 difference with 87% power, assuming an SD of 0.6 log10. This is an assumption, because the package has no viral-titre data. A non-inferiority margin of 0.5 log10 needs about 24 per arm, so the benchmark arms should be enlarged to that (L71).
- **Conduct:** randomised; coded formulations; pre-registered analysis plan; audited electronic data capture.

**After the gate passes**

**Study 2: mechanism of protection and correlate selection.** Months 7–13.

- **Must establish:** which immune arm carries protection, and therefore which efficacy biomarker to take into the clinic.
- **Population:** aged mice of both sexes, vaccinated with antigen + PSLN-344.
- **Comparators:** isotype controls; PSLN-212; PSLN-344 without antigen.
- **Interventions:**
  - Anti-CD8β or anti-CD4 depletion at challenge.
  - FTY720, to test lung-resident vs recirculating T cells.
  - Immune serum transferred into naive aged recipients.
  - B-cell deficiency (μMT mice or anti-CD20).
  - IFNAR-blocking antibody or CCR2 antagonist at vaccination (in aged animals; S02-I was done in young).
- **Endpoints:** heterosubtypic lung viral load and survival.
- **Readouts:** depletion efficiency; per-animal immunology; the 16-h PD signature, to test whether early PD predicts the downstream outcome.

**Study 3: delivery route and human bridging.** 3b runs inside the gate (months 1–6; low cost); 3a runs in months 7–11.

- **Must establish:** that efficacy survives nose-restricted delivery, and that Mn restores the response in older human cells.
- **3a, mouse:** low-volume, nose-restricted intranasal dosing vs lung delivery; PD signature and heterosubtypic protection.
- **3b, human ex vivo:** nasal epithelial air-liquid-interface cultures and alveolar macrophages from donors aged 65 or over vs 18–40, stimulated with PSLN-344 vs PSLN-212.
  - Readouts: IFN-β, CXCL10, CCL2, GM-CSF and ISG RNA, summarised with the same restoration index.
  - **Go:** human older-donor R ≥ 0.5, and a workable delivery route.

**Study 4: GLP toxicology including manganese.** Months 8–17, once the formulation is locked; gates the IND.

- **Must establish:** that PSLN-344 is safe for intranasal use in older adults.
- **Design:** repeat-dose (n+1) intranasal study in a relevant species, with recovery groups and an aged satellite group; adjuvant-alone and adjuvanted-vaccine arms.
- **Endpoints:**
  - Clinical pathology.
  - Cytokines at 6, 24 and 72 h.
  - Histopathology of nasal and olfactory epithelium, olfactory bulb, brain, trigeminal and facial nerve, and lung at days 3, 7 and 28.
  - Mn by ICP-MS in olfactory bulb, striatum, pallidum, lung, liver and blood; olfactory and neurobehavioural tests.
  - CNS ISG time course with a cholera-toxin control.
- **Go:** no Mn accumulation in brain beyond a pre-specified margin; no olfactory or facial-nerve pathology; aged-lung inflammation resolved by day 7.

**Study 5: non-rodent efficacy.** Months 9–18.

- **Must establish:** that efficacy holds against the benchmark in a second species.
- **Design:** older ferrets given PSLN-344 intranasally vs the intramuscular benchmarks, then heterosubtypic challenge.
- **Endpoints:** nasal viral shedding area, clinical score, and optionally transmission.
- **Optional:** aged non-human primates for device testing and PD bridging.

**Study 6: CMC and potency.** Months 1–12. Basic characterisation (Mn content, size, zeta potential) starts inside the gate, because Studies 1 and 3b need a characterised lot.

- **Must establish:** a manufacturable, characterised product.
- **Scope:**
  - Composition: Mn content and Mn:CDN ratio; improved encapsulation (currently 55%; L52).
  - Physical and stability data: particle size, polydispersity and zeta potential, which the methods mention but the workbook lacks; real-time and accelerated stability of the lyophilised product.
  - Device compatibility.
  - A cell-based IFN-β potency release assay.

**Phase 1 (earliest about month 20–22 from today, about 14 months after Decision B, if Studies 2–4 pass).**

- **Population:** Part A, healthy adults 18–49 (sentinel dose escalation); Part B, adults 65 and over, stratified 65–74 and 75+.
- **Comparators:** antigen alone intranasal; a licensed older-adult intramuscular vaccine.
- **Design:** randomised, observer-blind; two to three adjuvant dose levels.
- **Primary endpoint:** solicited nasal and systemic reactions (days 0–7) and adverse events.
  - Adverse events of special interest through 6–12 months: facial palsy, smell loss (smell testing at baseline, day 7, day 28 and day 180), neurological events.
  - Blood manganese.
- **Secondary endpoints:** HAI and microneutralisation at day 28; nasal IgA.
- **Exploratory:**
  - PD signature by nasal lining-fluid sampling at 6, 24 and 72 h; blood ISG score on day 1.
  - IFN-γ T cells against NP/M1 at days 0, 14, 28 and 90; circulating Tfh on day 7.
- **Then:** Phase 2a human challenge in adults to test heterosubtypic protection and validate the correlate; Phase 2b/3 field efficacy in people 65 and over.

**Timing summary**

- Weeks 0–6: Study 0. Decision A (integrity). If it fails, stop.
- Months 1–6: Study 1, plus Study 3b and basic CMC characterisation in parallel. Decision B (benchmark) at month 6–7.
- If Decision B is a go:
  - Study 2 (months 7–13), Study 3a (months 7–11), Study 4 (months 8–17), Study 5 (months 9–18), Study 6 (to month 12).
  - IND around month 18–20; Phase 1 starts around month 20–22.
- Only Studies 0, 1, 3b and basic CMC sit inside the capped gate budget.

---

## 6. What I considered and ruled out

| Considered | Evidence | Verdict |
|---|---|---|
| Advance to IND-enabling now | §3 | **Ruled out:** the differentiating claims rest on flagged records; no benchmark, toxicology or Mn data |
| Terminate now | Strict subset 10/14 vs 1/14 (L41-T3); 35/36 readouts move toward young (L36) | **Not first choice:** terminate if the gate fails or is not funded |
| Out-license or partner as is | I-01 to I-09 are visible from the workbook alone | **Ruled out** |
| Advance PSLN-212 (no Mn) instead | 1/14 survival in the strict tier (L41-T3); Ifnb1 Emax 15.6 (L03) | **Ruled out:** fails in aged mice |
| Simply dose PSLN-212 higher | 40 vs 20 µg gives ×1.18 (p = 0.28); PSLN-344 at 20 µg = 3.1× PSLN-212 at 40 µg (L03) | **Ruled out:** the response plateaus |
| Add a TLR7/8 agonist (PSLN-212/R848; PSLN-344/R848) | Weight nadir 90%, loss area 48.6 %-days, one animal lost (L50); highest 16-h Tnf and Il10 (L04); PSLN-344/R848 Emax 34.9 < 57.7, and this formulation is undefined in Materials | **Ruled out** |
| cGAMP liposome (CMP-204) or PSLN-R848 | Ifnb1 7.7 and 4.6 (L01b); Emax 6.6 (L03); IgG 181 (L20) | **Ruled out:** weaker |
| PSLN-344 gives a Th2-skewed response | Labels rotated; true IgG2a/IgG1 1.85–2.30 (I-04; L26) | **Ruled out** |
| HAI/neutralising antibody is the sole driver of protection | Protection without HA/NA match: 20/28 vs 1/28 (L42) | **Ruled out** for heterosubtypic protection |
| Full restoration of DC co-stimulation is required | CD40/CD86 R = 0.17/0.22 while survival R = 0.74 | **Ruled out as necessary** |
| Antigen-independent (innate/"trained") early protection | The only test (S15-H) rests on copied weights | **Not ruled out:** tested in Study 1 (PSLN-344-alone arm) |
| Mn works by increasing cellular uptake | S08-C unreliable (I-12); encapsulation not different (L52); the effect is on Emax | **Not supported** |
| Macrophage → Treg mechanism (S07-C) | Both arms carry the same label (I-07) | **Not evaluable** |
| NP-tetramer kinetics (S05-A/B) | n = 2, conflicting antigen, MHC mismatch (I-08) | **Excluded** |
| Pre-existing immunity blunts PSLN-344 | 6/7 with or without prior infection (L46) | **Not supported** (14-month mice; no imprinted-unvaccinated control) |
| Mn also benefits young mice | 8/8 vs 8/8 (L45) | **Ruled out:** ceiling; the target population is older adults only |
| Per-animal correlates of protection | Immunogenicity and challenge in different animals | **Not possible** with this dataset |
| Group-level correlation of readouts with survival | 32/35 readouts share survival's rank order (L37); with four arms, any monotone readout correlates perfectly | **Uninformative** |
| Using body weight to corroborate survival | Copied trajectories (I-02) | **Abandoned**; survival analysed in integrity tiers instead |
| Pooling S06-D | Duplicate (I-01) | **Excluded** |
| Tfh:Tfr as independent evidence | (100 − Foxp3%)/Foxp3% in 20/20 animals (I-15) | **Excluded** |
| Integrity "hits" in S09-A, across the HAI blocks, and from 3-significant-figure overlaps | qPCR grid, two-fold titres, chance | **Ruled out as issues** |

---

## 7. If we drop PSLN-344: what we are dropping and why

**What we would be dropping.** An intranasal Mn-STING surfactant-mimetic liposome with four properties in our aged-mouse data:

- It closes a median ~70% of the age-related immune deficit (L36).
- In the cleanest experiments it lifts survival after lethal challenge from about 10% to about 75%, including challenge with no HA/NA match (L41, L42).
- It does so by raising the ceiling of airway type-I-IFN signalling, a defect that a higher dose of the non-Mn parent cannot fix (L03).
- Its protective record cannot be verified from the workbook, its mechanism of protection is untested, its manganese and CNS safety is unstudied, and it has never been compared with the vaccines older adults already receive.

**Why.** Making it decision-grade needs the gate; without the gate, each of the following is potentially program-ending and none has data:

- manganese reaching the brain via the nose;
- deep-lung delivery in mice vs nasal delivery in people;
- transfer to split/subunit antigen;
- benchmark performance.

**What we keep (portable to other programmes):**

1. The formulation principle that Mn raises the STING response ceiling in aged tissue (Emax ×3.7).
2. The early airway IFN-β/CCL2/GM-CSF pharmacodynamic signature and the restoration-index framework for any mucosal adjuvant aimed at older adults.
3. The hypothesis that heterosubtypic protection in aged hosts is T-cell-driven, and the antigen-format question it raises.
4. The QC methods used here (survival vs weight reconciliation, trajectory-duplication screening, label verification against derived quantities), which should become standard for in-vivo data packages.

---

## Appendix A: how numbers were reduced

- **Unit of analysis:** the per-animal values as stored in the workbook. The annotation states that group summaries are computed downstream.
- **Titres, fold-changes, ratios, cell counts:**
  - Analysed on the log10 scale.
  - Reported as geometric mean (GM) with a t-based 95% CI.
  - Contrasts are GM ratios with a Welch 95% CI.
  - HAI values of 0 (below the 1:10 starting dilution) were set to 5.
- **Percentages:** arithmetic mean; contrasts are differences in means in percentage points (pp) with a Welch 95% CI.
- **Test checks:** an exact two-sided Mann-Whitney test accompanies each Welch test. The smallest attainable exact p is 0.0079 at n = 5 per arm and 0.10 at n = 3.
- **Multiplicity:** Holm correction across the 36-readout family.
- **Restoration index:** R = (aged PSLN-344 − aged PSLN-212) / (young PSLN-212 − aged PSLN-212), on the analysis scale. 95% CI from 10,000 bootstrap resamples of animals within arms.
- **Survival:**
  - Survivors are records with status 0.
  - Log-rank (Mantel-Cox) test; Fisher exact test on end-of-study survival; risk difference with a Newcombe CI.
  - Pooling: Mantel-Haenszel risk difference, plus an exact stratified permutation test (100,000 draws within experiments).
  - S03!J46, which has a status but no time, was treated as censored at 21 d. Excluding it gives 9/9 vs 3/10, p = 0.003 (L40-S03-J-sens).
- **Deaths inferred from body weight:** the record ends before day 14, or the same value is carried for the last ≥3 weigh-days (a lenient ≥2-day rule is also reported).
- **Dose–response:** E = 1 + Emax·Dʰ/(ED50ʰ + Dʰ), fitted by least squares on log10 fold; 2,000 residual-bootstrap refits.
- **Corrections applied:** S03-B/F IgG2a/IgG1 ratios were recomputed from S13-A–D; S09-A panel 2 was analysed as 72 h. S06-D, S07-C, S05-A/B, S11-A/B and S08 rows 89–101 were not used for inference.

## Appendix B: files

| File | Content |
|---|---|
| `PSLN-344_portfolio_decision_memo.md` / `.pdf` | This memo |
| `numbers_ledger.csv` | 120 entries: every cited number, with source cells and reduction |
| `data_integrity_log.csv` | 19 issues and 3 checked-and-ruled-out items, each with severity, impact and handling |
| `tables/all_blocks_descriptive.csv` | Every block × group as printed: n, mean, SD, median, range, GM, the raw values and the cell range (for spot-checking any number) |
| `tables/tidy_*_with_cells.csv` | Every per-animal value, survival record and body-weight cell, with its Excel cell address |
| `tables/*.csv` (other) | Group summaries, contrasts, restoration indices, survival per group, contrasts and pooled results, reconciliation, shared trajectories, early panel, Emax fits |
| `figures/fig1`–`fig6` | Restoration profile; survival grid with integrity tiers; pooled survival and HA/NA match; integrity evidence; mechanism; immunogenicity |
| `code/*.py`, `code/run_all.sh` | Parser (cell-level provenance) and all analyses. `run_all.sh` reproduces every table, figure and ledger entry (verified byte-identical on re-run); `build_pdf.py` renders this memo |

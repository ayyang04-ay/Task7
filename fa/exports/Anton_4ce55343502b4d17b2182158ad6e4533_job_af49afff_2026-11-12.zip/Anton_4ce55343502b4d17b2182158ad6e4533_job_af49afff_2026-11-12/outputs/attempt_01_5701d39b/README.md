# PSLN-344 portfolio review — deliverables

Start with **`PSLN-344_portfolio_decision_memo.pdf`** (or the `.md` source). Page 1–2 hold the decision and the case; §5 has the forward view (driver of protection, biomarker, next studies); §6 lists what was considered and ruled out; §7 says what we would be dropping.

| Path | What it is |
|---|---|
| `PSLN-344_portfolio_decision_memo.pdf` / `.md` | Decision memo (11 pages + 3 pages of figures) |
| `numbers_ledger.csv` | Every number cited in the memo: ledger ID, value with 95% CI, source sheet/cells, reduction method |
| `data_integrity_log.csv` | 19 data-integrity issues + 3 checked-and-ruled-out, with severity, impact and how each was handled |
| `figures/` | Fig. 1 restoration profile; Fig. 2 survival grid with integrity tiers; Fig. 3 pooled survival & HA/NA match; Fig. 4 integrity evidence; Fig. 5 mechanism/dose-response; Fig. 6 immunogenicity |
| `tables/` | All derived tables, plus `all_blocks_descriptive.csv` (every block × group with raw values and cell range) and tidy per-animal data with Excel cell addresses |
| `code/` | Parser and analyses; `run_all.sh` regenerates every table, figure and ledger entry (verified identical on re-run); `build_pdf.py` renders the memo |

Conventions: titres/fold-changes analysed on log10 (geometric means, GM ratios); percentages as means/differences; Welch CIs with exact Mann–Whitney checks; survival by log-rank/Fisher with integrity-tiered pooling. Full rules in memo Appendix A.

import pandas as pd, numpy as np, itertools
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 80)
m = pd.read_csv('tidy/measurements.csv'); s = pd.read_csv('tidy/survival.csv'); b = pd.read_csv('tidy/bodyweight.csv')

print("=== 1. Survival blocks: identical (time,event) multisets across block/group ===")
sv = {}
for (blk, g), d in s.groupby(['block','group']):
    key = tuple(sorted(zip(d.time.fillna(-1), d.event)))
    sv.setdefault(key, []).append(f'{blk}|{g}')
for key, lst in sv.items():
    if len(lst) > 1 and any(e==1 for _,e in key):   # ignore all-censored (uninformative) vectors
        print(len(lst), lst, key)
# whole-block identity
print("\n-- whole-block identity (all groups identical, in order) --")
blocks = {}
for blk, d in s.groupby('block'):
    blocks[blk] = tuple((g, tuple(sorted(zip(dd.time.fillna(-1), dd.event)))) for g, dd in d.groupby('group', sort=False))
for a, c in itertools.combinations(blocks, 2):
    if blocks[a] == blocks[c]:
        print('IDENTICAL BLOCKS:', a, c)

print("\n=== 2. Continuous measurements: identical values shared between different blocks/groups ===")
m['vstr'] = m.value.map(lambda x: f'{x:.6g}')
# restrict to 'informative' values: at least 3 significant digits and not trivially common
def sig(x):
    s_ = f'{abs(x):.10g}'.replace('.','').lstrip('0')
    return len(s_.rstrip('0')) if '.' in f'{abs(x):.10g}' else len(s_.rstrip('0'))
m['nsig'] = m.value.map(sig)
inf = m[m.nsig>=3]
grp = inf.groupby('vstr')
rows=[]
for vs, d in grp:
    keys = set(zip(d.block, d['sub'].astype(str), d.group))
    if len(keys) > 1:
        rows.append((vs, len(d), '; '.join(f'{c}({bk}|{sb}|{g})' for c,bk,sb,g in zip(d.cell,d.block,d['sub'].astype(str),d.group))))
print(len(rows), 'shared informative values')
for r in rows: print(r)

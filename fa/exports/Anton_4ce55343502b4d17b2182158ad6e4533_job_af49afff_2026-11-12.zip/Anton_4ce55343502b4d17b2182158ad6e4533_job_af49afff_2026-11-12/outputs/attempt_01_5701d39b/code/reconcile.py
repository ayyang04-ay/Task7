import pandas as pd, numpy as np
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
s = pd.read_csv('tidy/survival.csv'); b = pd.read_csv('tidy/bodyweight.csv')
pairs = {'S13-F':'S03-I','S13-G':'S03-J','S15-A':'S06-A','S15-B':'S06-B','S15-C':'S06-C','S15-D':'S06-D','S15-E':'S06-E',
         'S15-F':'S06-F','S15-G':'S06-G','S15-I':'S15-H','S15-J':'S06-E(imprint)','S15-K':'S06-F(imprint)','S15-M':'S15-L',
         'S15-O':'S15-N','S09-C':'S09-B','S09-E':'S09-D','S09-G':'S09-F'}
def infer(traj, min_run):
    """traj: series indexed by day (0..14). returns (dead:bool, day_of_last_change)"""
    t = traj.dropna()
    last_day = t.index.max()
    if last_day < 14:
        return True, 'missing from d%d' % (t.index[t.index>last_day].min() if False else last_day+2)
    vals = t.values
    run = 1
    for k in range(len(vals)-1, 0, -1):
        if abs(vals[k]-vals[k-1]) < 1e-9: run += 1
        else: break
    if run >= min_run:
        return True, 'frozen %.2f for last %d weigh-days' % (vals[-1], run)
    return False, ''
rows=[]
for bwb, svb in pairs.items():
    d = b[b.block==bwb]
    for g, dg in d.groupby('group', sort=False):
        n = dg.idx.nunique()
        res2 = [infer(dd.set_index('day').value, 2) for _, dd in dg.groupby('idx')]
        res3 = [infer(dd.set_index('day').value, 3) for _, dd in dg.groupby('idx')]
        dead2 = sum(r[0] for r in res2); dead3 = sum(r[0] for r in res3)
        # find survival group (names differ slightly)
        sv = s[s.block==svb]
        gmap = {g2: g2 for g2 in sv.group.unique()}
        g_s = g if g in gmap else {'PSLN-212Y':'PSLN-212Y','PSLN-344Y':'PSLN-344Y'}.get(g, None)
        if g_s not in gmap: sd = None; sn=None
        else:
            sd = int(sv[sv.group==g_s].event.sum()); sn = int((sv.group==g_s).sum())
        rows.append(dict(bw_block=bwb, surv_block=svb, group=g, n_bw=n, deaths_inferred_run3=dead3, deaths_inferred_run2=dead2,
                         n_surv=sn, deaths_surv=sd,
                         concordant=('n/a' if sd is None else ('yes' if sd in (dead2, dead3) and sn==n else 'NO'))))
R = pd.DataFrame(rows)
print(R.to_string())
R.to_csv('/tmp/work/survival_bw_reconciliation.csv', index=False)
# groups in survival blocks missing from weight blocks
print()
for bwb, svb in pairs.items():
    gs = set(s[s.block==svb].group); gb = set(b[b.block==bwb].group)
    if gs != gb: print(f'{svb} groups {sorted(gs)}  vs  {bwb} groups {sorted(gb)}')

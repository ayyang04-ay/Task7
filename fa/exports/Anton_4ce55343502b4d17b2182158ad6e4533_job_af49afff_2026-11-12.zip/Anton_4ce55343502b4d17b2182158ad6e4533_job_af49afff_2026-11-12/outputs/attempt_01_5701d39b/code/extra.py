import numpy as np, pandas as pd
from scipy import stats
s = pd.read_csv('tidy/survival.csv')
def surv(blocks, g):
    d = s[s.block.isin(blocks) & (s.group==g)]; return int((d.event==0).sum()), len(d)
sets = {'no HA or NA shared (S06-A,B,E,G)': ['S06-A','S06-B','S06-E','S06-G'],
        'no HA/NA shared, integrity-concordant only (S06-A,B)': ['S06-A','S06-B'],
        'NA (N1) shared only (S06-C,F; excl. duplicate S06-D)': ['S06-C','S06-F'],
        'homologous HA+NA (S03-I, S03-J)': ['S03-I','S03-J']}
rows=[]
for k,b in sets.items():
    a = surv(b,'PSLN-344'); c = surv(b,'PSLN-212'); sh = surv(b,'Sham')
    rows.append(dict(set=k, PSLN344=f'{a[0]}/{a[1]} ({100*a[0]/a[1]:.0f}%)', PSLN212=f'{c[0]}/{c[1]} ({100*c[0]/c[1]:.0f}%)',
                     Sham=(f'{sh[0]}/{sh[1]}' if sh[1] else 'n/a'), fisher_344_vs_212=stats.fisher_exact([[a[0],a[1]-a[0]],[c[0],c[1]-c[0]]])[1]))
R = pd.DataFrame(rows); print(R.to_string()); R.to_csv('/tmp/work/out_protection_by_match.csv', index=False)
a = surv(['S06-A','S06-B','S06-E','S06-G'],'PSLN-344'); b = surv(['S06-C','S06-F','S03-I','S03-J'],'PSLN-344')
print('PSLN-344 survival, no-match vs matched (NA or HA+NA):', a, b, 'Fisher p=', round(stats.fisher_exact([[a[0],a[1]-a[0]],[b[0],b[1]-b[0]]])[1],3))

# power by simulation, Fisher exact two-sided alpha 0.05
rng = np.random.default_rng(5)
def power(p1,p2,n,B=20000):
    x1 = rng.binomial(n,p1,B); x2 = rng.binomial(n,p2,B)
    cache={}
    hits=0
    for a_,b_ in zip(x1,x2):
        key=(a_,b_)
        if key not in cache: cache[key]=stats.fisher_exact([[a_,n-a_],[b_,n-b_]])[1]
        hits += cache[key]<0.05
    return hits/B
print()
for p1,p2,lab in [(0.76,0.10,'PSLN-344 vs PSLN-212 (T3-lenient rates)'),(0.76,0.40,'PSLN-344 vs benchmark assumed 40%'),
                  (0.76,0.50,'PSLN-344 vs benchmark assumed 50%'),(0.85,0.50,'PSLN-344 85% vs benchmark 50%')]:
    out=[]
    for n in [7,10,12,15,20,25,30,40]:
        out.append(f'n={n}:{power(p1,p2,n):.2f}')
    print(lab, ' '.join(out))

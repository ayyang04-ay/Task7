import pandas as pd, numpy as np, itertools, re
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 200)
b = pd.read_csv('tidy/bodyweight.csv')
import openpyxl
# get raw cell text precision: number of decimals as stored
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx', data_only=True)
def ndec(cell):
    sh, c = cell.split('!'); x = wb[sh][c].value
    if x is None: return None
    s = repr(float(x))
    return len(s.split('.')[1]) if '.' in s and not s.endswith('.0') else 0
b['ndec'] = b.cell.map(ndec)
b = b[(b.day>0) & b.value.notna()].copy()
b['frac'] = (b.value - np.floor(b.value)).round(5)
hp = b[b.ndec>=4].copy()
print('high-precision (>=4 dp) body-weight cells:', len(hp), 'of', len(b))
print(hp.groupby('block').size().to_string())
# fractional-part collisions across different trajectories
hp['traj'] = hp.block + '|' + hp.group + '|#' + hp.idx.astype(str)
coll = hp.groupby('frac').filter(lambda d: d.traj.nunique()>1)
print('\nfractional parts (5dp) of >=4dp values shared by >1 trajectory:', coll.frac.nunique())
out=[]
for f, d in coll.groupby('frac'):
    out.append((f, '; '.join(f'{c}={v:.6f}(d{dy}, {t})' for c,v,dy,t in zip(d.cell,d.value,d.day,d.traj))))
for o in out: print(o)

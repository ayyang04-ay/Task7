import pandas as pd, numpy as np, itertools
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 200)
b = pd.read_csv('tidy/bodyweight.csv'); b = b[b.day>0]
b['traj'] = b.block + '|' + b.group + '|#' + b.idx.astype(str)
T = b.pivot_table(index='traj', columns='day', values='value', aggfunc='first')
C = b.pivot_table(index='traj', columns='day', values='cell', aggfunc='first')
trajs = T.index.tolist(); A = T.values
F = np.round(A - np.floor(A), 5)
rows=[]
for i, j in itertools.combinations(range(len(trajs)), 2):
    a, c = A[i], A[j]; ok = ~np.isnan(a) & ~np.isnan(c)
    same = ok & np.isclose(a, c, atol=1e-6)
    nontriv = ok & (np.abs(F[i]*1000 - np.round(F[i]*1000)) > 1e-6)
    off = nontriv & np.isclose(F[i], F[j], atol=1e-6) & ~same
    dist_same = len(set(np.round(a[same], 6)))
    dist_off = len(set(np.round(F[i][off], 5)))
    if dist_same + dist_off >= 3:
        rows.append(dict(traj_a=trajs[i], traj_b=trajs[j], distinct_identical=dist_same, distinct_offset=dist_off,
                         days_identical=','.join(str(int(d)) for d in T.columns[same]),
                         days_offset=','.join(str(int(d)) for d in T.columns[off]),
                         cells_a=' '.join(C.iloc[i][T.columns[same|off]].astype(str)), cells_b=' '.join(C.iloc[j][T.columns[same|off]].astype(str))))
R = pd.DataFrame(rows).sort_values(['distinct_identical','distinct_offset'], ascending=False)
R.to_csv('/tmp/work/bw_copy_pairs_refined.csv', index=False)
print(R[['traj_a','traj_b','distinct_identical','distinct_offset','days_identical','days_offset']].to_string())
R['pair'] = R.traj_a.str.split('|').str[0] + ' <-> ' + R.traj_b.str.split('|').str[0]
print()
print(R.groupby('pair').agg(trajectory_pairs=('traj_a','size')).sort_values('trajectory_pairs',ascending=False).to_string())
# chance expectation for 5-dp fractional collisions among high-precision values

import numpy as np, pandas as pd
from scipy import optimize, stats
rng = np.random.default_rng(3)
m = pd.read_csv('tidy/measurements.csv'); m['sub']=m['sub'].astype(str)
doses = [1,5,10,20,40]
def data(g):
    D,Y=[],[]
    for dz in doses:
        v = m[(m.block=='S08-A')&(m.group==g)&(m['sub']==str(dz))].value.values; D+= [dz]*len(v); Y+=list(v)
    return np.array(D,float), np.array(Y,float)
def f(p, d): return np.log10(1 + p[0]*d**p[2]/(p[1]**p[2] + d**p[2]))
def fit(D,Y):
    r = lambda p: f(p,D)-np.log10(Y)
    best=None
    for x0 in ([20,10,1.5],[50,10,2],[15,5,1]):
        s = optimize.least_squares(r, x0=x0, bounds=([0.1,0.1,0.3],[500,200,6]))
        if best is None or s.cost<best.cost: best=s
    return best.x, best.fun
rows=[]
for g in ['CMP-204','PSLN-212','PSLN-344','PSLN-344/R848']:
    D,Y = data(g); p,res = fit(D,Y); fitted=f(p,D)
    B=np.array([fit(D,10**(fitted+rng.choice(res,len(res))))[0] for _ in range(2000)])
    rows.append(dict(formulation=g, Emax_fold=p[0], Emax_lo=np.percentile(B[:,0],2.5), Emax_hi=np.percentile(B[:,0],97.5),
                     ED50_ug=p[1], ED50_lo=np.percentile(B[:,1],2.5), ED50_hi=np.percentile(B[:,1],97.5), hill=p[2],
                     rmse_log10=np.sqrt(np.mean(res**2))))
E=pd.DataFrame(rows); E.to_csv('/tmp/work/out_emax_hill.csv', index=False)
print(E.to_string(float_format=lambda v: f'{v:.3g}'))
# observed plateau check: 20 vs 40 ug within formulation
for g in ['CMP-204','PSLN-212','PSLN-344']:
    a = m[(m.block=='S08-A')&(m.group==g)&(m['sub']=='40')].value.values; b = m[(m.block=='S08-A')&(m.group==g)&(m['sub']=='20')].value.values
    r = 10**(np.log10(a).mean()-np.log10(b).mean()); p = stats.ttest_ind(np.log10(a), np.log10(b), equal_var=False).pvalue
    print(f'{g}: 40 vs 20 ug GM ratio {r:.2f} (Welch p={p:.2f})')

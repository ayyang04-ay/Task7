import pandas as pd, numpy as np, itertools
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 200)
b = pd.read_csv('tidy/bodyweight.csv')
b = b[b.day>0]
b['traj'] = b.block + '|' + b.group + '|#' + b.idx.astype(str)
T = b.pivot_table(index='traj', columns='day', values='value', aggfunc='first')
frac = (T - np.floor(T)).round(5)
trajs = T.index.tolist()
rows=[]
A = T.values; F = frac.values
for i, j in itertools.combinations(range(len(trajs)), 2):
    bi, bj = trajs[i].split('|')[0], trajs[j].split('|')[0]
    a, c = A[i], A[j]
    ok = ~np.isnan(a) & ~np.isnan(c)
    same = ok & np.isclose(a, c, atol=1e-6)
    # integer-offset: same fractional part, not identical, and fractional part non-trivial (not .0 / .5 etc. -> require >=3 non-zero decimals)
    fi, fj = F[i], F[j]
    nontriv = ok & (np.abs(fi*1000 - np.round(fi*1000)) > 1e-6)
    intoff = nontriv & np.isclose(fi, fj, atol=1e-6) & ~same
    # exclude LOCF frozen repeats within a trajectory counting multiple times: count distinct values
    ns, no = same.sum(), intoff.sum()
    if ns + no >= 3 or (no >= 2):
        rows.append(dict(a=trajs[i], b=trajs[j], n_common=int(ok.sum()), identical=int(ns), int_offset_same_decimals=int(no),
                         days_identical=[int(d) for d in T.columns[same]], days_offset=[int(d) for d in T.columns[intoff]]))
R = pd.DataFrame(rows)
# ignore pairs in same block where identical values are just LOCF-like plateaus? keep but mark
R['same_block'] = R.a.str.split('|').str[0] == R.b.str.split('|').str[0]
R = R.sort_values(['identical','int_offset_same_decimals'], ascending=False)
print(R.to_string())
R.to_csv('/tmp/work/bw_copy_pairs.csv', index=False)
print()
print('block-pair summary (cross-block only):')
X = R[~R.same_block].copy()
X['pair'] = X.a.str.split('|').str[0] + ' <-> ' + X.b.str.split('|').str[0]
print(X.groupby('pair').agg(traj_pairs=('a','size'), identical_vals=('identical','sum'), offset_vals=('int_offset_same_decimals','sum')).sort_values('traj_pairs', ascending=False).to_string())

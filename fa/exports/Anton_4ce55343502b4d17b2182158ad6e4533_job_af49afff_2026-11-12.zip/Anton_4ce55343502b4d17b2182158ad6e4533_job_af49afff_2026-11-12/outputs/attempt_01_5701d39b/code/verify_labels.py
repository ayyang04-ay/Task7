import pandas as pd, numpy as np
m = pd.read_csv('tidy/measurements.csv'); m['sub']=m['sub'].astype(str)
def vec(block, group, sub='nan'):
    d = m[(m.block==block)&(m.group==group)&(m['sub']==sub)].sort_values('idx'); return d.value.values, d.cell.values
print("=== S09-A Ifnb1 rows (log10) vs S01-A (linear) ===")
gm = {'PBS':'Sham','CMP-204':'CMP-204','PSLN-212':'PSLN-212','PSLN-R848':'PSLN-R848','PSLN-212/R848':'PSLN-212/R848','PSLN-344':'PSLN-344','PSLN-212(y)':'PSLN-212(Y)'}
for panel in ['S09-A panel1 (cols A-V)','S09-A panel2 (cols X-AS)']:
    for g9, g1 in gm.items():
        x, cells = vec(panel, g9, 'Ifnb1'); lin = np.round(10**x, 2)
        a16,_ = vec('S01-A', g1, '16h'); a72,_ = vec('S01-A', g1, '72h')
        m16 = [np.any(np.isclose(v, a16, atol=0.006)) for v in lin]; m72 = [np.any(np.isclose(v, a72, atol=0.006)) for v in lin]
        print(f'{panel[:13]} {g9:14s} 10^x={lin}  in S01-A 16h:{sum(m16)}/3  in S01-A 72h:{sum(m72)}/3')
print("\n=== S03-B / S03-F ratios vs S13 subclass titres ===")
for rblk, a2, a1 in [('S03-B','S13-A','S13-B'), ('S03-F','S13-C','S13-D')]:
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        r = vec(a2,g)[0]/vec(a1,g)[0]
        # which printed group in the ratio block matches
        for gr in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
            rv = vec(rblk, gr)[0]
            if np.allclose(np.round(r,5), np.round(rv,5), atol=2e-5):
                print(f'{a2}/{a1} group {g:12s} -> ratios {np.round(r,3)} == {rblk} printed column "{gr}"')
print("\n=== S04-B Tfh:Tfr vs (100-Foxp3%)/Foxp3% ===")
for g in ['Sham','PSLN-212','PSLN-344','PSLN-212(Y)']:
    f = vec('S04-B Foxp3', g)[0]; t = vec('S04-B TfhTfr', g)[0]
    print(g, np.round((100-f)/f,6), np.round(t,6), 'identical:', np.allclose((100-f)/f, t, atol=1e-5))
print("\n=== S01-B vs S08-C ===")
for g1 in ['AECII/PSLN-SRB','AECI/PSLN-SRB']:
    print('S01-B', g1, vec('S01-B', g1)[0])
for g8 in ['AECII-PSLN-SRB','AECII-PSLN-344-SRB','AECI-PSLN-SRB','AECI-PSLN-344-SRB']:
    print('S08-C', g8, vec('S08-C', g8)[0])
print("\n=== S09-A within-panel duplicated 6-digit values ===")
for panel in ['S09-A panel1 (cols A-V)','S09-A panel2 (cols X-AS)']:
    d = m[m.block==panel].copy(); d['k']=d.value.round(6)
    for k, dd in d.groupby('k'):
        if len(dd)>1: print(panel[:13], k, list(zip(dd.cell, dd['sub'], dd.group)))

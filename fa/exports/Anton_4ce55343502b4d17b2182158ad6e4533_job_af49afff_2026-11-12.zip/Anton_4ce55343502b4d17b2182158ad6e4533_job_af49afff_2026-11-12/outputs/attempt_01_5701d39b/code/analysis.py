"""
Core quantitative analysis of the PSLN-344 dataset.
Reductions (stated once, applied everywhere):
  * Per-animal values as stored are the unit of analysis (annotation: summary measures are computed downstream).
  * Titres, fold-changes, ratios, cell counts: analysed on log10 scale; reported as geometric mean (GM) with
    95% CI from the t-distribution on log10 values; contrasts reported as GM ratio with Welch 95% CI.
  * HAI values recorded as 0 (below the 1:10 starting dilution, annotation S03-C/G) are set to 5 (half LLOQ).
  * Percentages: arithmetic mean, SD; contrasts as difference in means with Welch 95% CI.
  * Tests: Welch t-test (analysis scale) and exact two-sided Mann-Whitney U as a distribution-free check.
    Holm correction across the pre-specified family "aged PSLN-344 vs aged PSLN-212".
  * Restoration index R = (aged PSLN-344 - aged PSLN-212) / (young PSLN-212 - aged PSLN-212) on the analysis
    scale; R = 1 means the age deficit is fully closed. 95% CI by 10,000 bootstrap resamples of animals within group.
  * S03-B/S03-F ratio blocks are NOT used as printed (labels rotated, see integrity log); IgG2a/IgG1 is
    recomputed per animal from S13-A/B and S13-C/D.
"""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests

rng = np.random.default_rng(20260915)
m = pd.read_csv('/tmp/work/tidy/measurements.csv')
m['sub'] = m['sub'].astype(str)

# ---- readout catalogue: (label, block, sub, scale, higher_is_better, young_group_label, domain)
LOG, LIN = 'log10', 'linear'
CAT = [
    # innate / delivery
    ('Lung Ifnb1 16 h (fold vs untreated)', 'S01-A', '16h', LOG, True, 'PSLN-212(Y)', 'Innate'),
    ('Lung Ifnb1 72 h (fold vs untreated)', 'S01-A', '72h', LOG, None, 'PSLN-212(Y)', 'Innate'),
    ('Lung monocytes day 4 (%)', 'S01-D', '4', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('Lung CD11b+ DC day 4 (%)', 'S01-E', '4', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('Lung cDC1 72 h (%)', 'S01-F', '72h', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('Lung CCR7+ migratory CD11b+ DC 72 h (%)', 'S02-A', 'nan', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('MLN CD11b+CD103- DC 72 h (%)', 'S02-B', 'nan', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('MLN DC carrying AF647-OVA 36 h (%)', 'S02-C', 'nan', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('MLN CD11b+ DC CD40+ day 3 (%)', 'S02-D CD40', 'nan', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('MLN CD11b+ DC CD86+ day 3 (%)', 'S02-D CD86', 'nan', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('OT-I proliferation with MLN DC (%)', 'S02-E', 'nan', LIN, True, 'PSLN-212(Y)', 'Innate'),
    ('Lung CD206+ macrophages (%)', 'S11-E', 'nan', LIN, False, 'PSLN-212(Y)', 'Innate'),
    # humoral
    ('Serum IgG anti-CA09 H1N1 d14 (titre)', 'S03-A', 'nan', LOG, True, 'PSLN-212(Y)', 'Humoral'),
    ('Serum IgG anti-Aichi H3N2 d14 (titre)', 'S03-E', 'nan', LOG, True, 'PSLN-212(Y)', 'Humoral'),
    ('HAI anti-CA09 H1N1 d14 (titre)', 'S03-C', 'nan', LOG, True, 'PSLN-212(Y)', 'Humoral'),
    ('HAI anti-Aichi H3N2 d14 (titre)', 'S03-G', 'nan', LOG, True, 'PSLN-212(Y)', 'Humoral'),
    ('Neutralising Ab anti-CA09 H1N1 d14 (titre)', 'S03-D', 'nan', LOG, True, 'PSLN-212(Y)', 'Humoral'),
    ('Neutralising Ab anti-Aichi H3N2 d14 (titre)', 'S03-H', 'nan', LOG, True, 'PSLN-212(Y)', 'Humoral'),
    ('Serum IgG anti-CA09 H1N1 d28 post-boost (titre)', 'S13-I', 'nan', LOG, True, 'PSLN-212(Y)', 'Humoral'),
    ('Serum IgG anti-Aichi H3N2 d28 post-boost (titre)', 'S13-J', 'nan', LOG, True, 'PSLN-212(Y)', 'Humoral'),
    ('IgG2a/IgG1 anti-CA09 (recomputed from S13-A/B)', 'RATIO-H1', 'nan', LOG, None, 'PSLN-212(Y)', 'Humoral'),
    ('IgG2a/IgG1 anti-Aichi (recomputed from S13-C/D)', 'RATIO-H3', 'nan', LOG, None, 'PSLN-212(Y)', 'Humoral'),
    ('MLN germinal-centre B cells d7 (%)', 'S03-K', 'nan', LIN, True, 'PSLN-212(Y)', 'Humoral'),
    ('MLN ICOS-high Tfh d7 (%)', 'S04-A', 'ICOS-high', LIN, True, 'PSLN-212(Y)', 'Humoral'),
    ('MLN Foxp3+ Tfr within CXCR5+ICOShi d7 (%)', 'S04-B Foxp3', 'nan', LIN, False, 'PSLN-212(Y)', 'Humoral'),
    ('MLN Foxp3+ Tfr d30 (%)', 'S04-C', 'nan', LIN, False, 'PSLN-212(Y)', 'Humoral'),
    ('MLN IgG+ of B220+ (%)', 'S13-H', 'nan', LIN, True, 'PSLN-212(Y)', 'Humoral'),
    # cellular
    ('Lung Ki-67+ CD8 day 3 (%)', 'S05-D', 'nan', LIN, True, 'PSLN-212(Y)', 'Cellular'),
    ('Lung GZMB+ CD8 day 3 (%)', 'S05-E', 'nan', LIN, True, 'PSLN-212(Y)', 'Cellular'),
    ('MLN IFN-g+ CD8, rgH5N1 restim, d14 (%)', 'S05-F', 'nan', LIN, True, 'PSLN-212(Y)', 'Cellular'),
    ('MLN IFN-g+ CD8, rgH5N1 restim, d60 (%)', 'S05-G', 'nan', LIN, True, 'PSLN-212(Y)', 'Cellular'),
    ('MLN GZMB+ CD8 d60 (%)', 'S05-H', 'nan', LIN, True, 'PSLN-212(Y)', 'Cellular'),
    ('MLN IFN-g+ CD8, H1N1 restim (%)', 'S14-A H1N1', 'nan', LIN, True, 'PSLN-212(Y)', 'Cellular'),
    ('MLN IFN-g+ CD8, H3N2 restim (%)', 'S14-A H3N2', 'nan', LIN, True, 'PSLN-212(Y)', 'Cellular'),
    ('Lung CD69+CD103+ TRM CD8 d25 (%)', 'S05-I', 'nan', LIN, True, 'PSLN-212(Y)', 'Cellular'),
    ('Lung Foxp3+ Treg d7 (%) [n=3]', 'S04-D', 'nan', LIN, False, 'PSLN-212(Y)', 'Cellular'),
]


def get(block, sub, group):
    if block.startswith('RATIO'):
        a2, a1 = ('S13-A', 'S13-B') if block == 'RATIO-H1' else ('S13-C', 'S13-D')
        x = get(a2, 'nan', group)[0] / get(a1, 'nan', group)[0]
        cells = f"{a2}/{a1} ({group})"
        return x, cells
    d = m[(m.block == block) & (m['sub'] == sub) & (m.group == group)].sort_values('idx')
    x = d.value.values.astype(float)
    if block in ('S03-C', 'S03-G'):
        x = np.where(x <= 0, 5.0, x)   # HAI below 1:10 -> 5
    cells = f"{d.cell.iloc[0]}:{d.cell.iloc[-1].split('!')[1]}" if len(d) else ''
    return x, cells


def tr(x, scale):
    return np.log10(x) if scale == LOG else x


def summarise(x, scale):
    n = len(x)
    out = dict(n=n, mean=np.mean(x), sd=np.std(x, ddof=1) if n > 1 else np.nan, median=np.median(x),
               min=np.min(x), max=np.max(x))
    if scale == LOG:
        lx = np.log10(x); se = np.std(lx, ddof=1) / np.sqrt(n); t = stats.t.ppf(0.975, n - 1)
        out.update(gm=10 ** lx.mean(), gm_lo=10 ** (lx.mean() - t * se), gm_hi=10 ** (lx.mean() + t * se))
    else:
        se = np.std(x, ddof=1) / np.sqrt(n); t = stats.t.ppf(0.975, n - 1)
        out.update(ci_lo=np.mean(x) - t * se, ci_hi=np.mean(x) + t * se, sem=se)
    return out


def welch(a, b, scale):
    """returns estimate (diff on analysis scale), CI, p ; for log, back-transform to ratio"""
    ta, tb = tr(a, scale), tr(b, scale)
    va, vb = np.var(ta, ddof=1) / len(ta), np.var(tb, ddof=1) / len(tb)
    diff = ta.mean() - tb.mean(); se = np.sqrt(va + vb)
    df = (va + vb) ** 2 / (va ** 2 / (len(ta) - 1) + vb ** 2 / (len(tb) - 1))
    t = stats.t.ppf(0.975, df); p = 2 * stats.t.sf(abs(diff / se), df)
    lo, hi = diff - t * se, diff + t * se
    if scale == LOG:
        return 10 ** diff, 10 ** lo, 10 ** hi, p
    return diff, lo, hi, p


def mw(a, b):
    try:
        return stats.mannwhitneyu(a, b, alternative='two-sided', method='exact').pvalue
    except Exception:
        return stats.mannwhitneyu(a, b, alternative='two-sided').pvalue


def restoration(a344, a212, y212, scale, B=10000):
    t344, t212, ty = tr(a344, scale), tr(a212, scale), tr(y212, scale)
    gap = ty.mean() - t212.mean()
    R = (t344.mean() - t212.mean()) / gap
    bs = []
    for _ in range(B):
        s344 = rng.choice(t344, len(t344)); s212 = rng.choice(t212, len(t212)); sy = rng.choice(ty, len(ty))
        g = sy.mean() - s212.mean()
        if abs(g) < 1e-12:
            continue
        bs.append((s344.mean() - s212.mean()) / g)
    bs = np.array(bs)
    return R, np.percentile(bs, 2.5), np.percentile(bs, 97.5), gap


rows_sum, rows_con, rows_res = [], [], []
for (label, blk, sub, scale, hib, ylab, dom) in CAT:
    groups = ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', ylab, 'PSLN-344(Y)']
    data = {}
    for g in groups:
        x, cells = get(blk, sub, g) if not blk.startswith('RATIO') else (None, None)
        if blk.startswith('RATIO'):
            try:
                x, cells = get(blk, sub, g)
            except Exception:
                x = np.array([])
        if x is not None and len(x):
            data[g] = (x, cells)
            s = summarise(x, scale)
            rows_sum.append(dict(domain=dom, readout=label, block=blk, sub=sub, scale=scale, group=g, cells=cells, **s))
    a344, a212, y212 = data['PSLN-344'][0], data['PSLN-212'][0], data[ylab][0]
    for comp, other in [('aged PSLN-344 vs aged PSLN-212', 'PSLN-212'), ('aged PSLN-344 vs young PSLN-212', ylab),
                        ('aged PSLN-344 vs aged Sham', 'Sham')]:
        if other not in data:
            continue
        est, lo, hi, p = welch(a344, data[other][0], scale)
        rows_con.append(dict(domain=dom, readout=label, block=blk, sub=sub, scale=scale, comparison=comp,
                             estimate=est, ci_lo=lo, ci_hi=hi, welch_p=p, mw_exact_p=mw(a344, data[other][0]),
                             effect='GM ratio' if scale == LOG else 'difference in means (percentage points)',
                             n1=len(a344), n2=len(data[other][0])))
    R, rlo, rhi, gap = restoration(a344, a212, y212, scale)
    # is the young-vs-aged gap itself resolvable?
    _, _, _, pgap = welch(y212, a212, scale)
    rows_res.append(dict(domain=dom, readout=label, block=blk, sub=sub, scale=scale, R=R, R_lo=rlo, R_hi=rhi,
                         young_minus_aged_PSLN212_on_scale=gap, p_gap=pgap,
                         direction=('higher is young-like' if gap > 0 else 'lower is young-like')))

S = pd.DataFrame(rows_sum); C = pd.DataFrame(rows_con); Rz = pd.DataFrame(rows_res)
fam = C.comparison == 'aged PSLN-344 vs aged PSLN-212'
C.loc[fam, 'holm_p'] = multipletests(C.loc[fam, 'welch_p'], method='holm')[1]
fam2 = C.comparison == 'aged PSLN-344 vs young PSLN-212'
C.loc[fam2, 'holm_p'] = multipletests(C.loc[fam2, 'welch_p'], method='holm')[1]
S.to_csv('/tmp/work/out_group_summary_core.csv', index=False)
C.to_csv('/tmp/work/out_contrasts_core.csv', index=False)
Rz.to_csv('/tmp/work/out_restoration.csv', index=False)

pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 60)
fmt = lambda v: f'{v:.3g}'
print(C[fam][['readout', 'effect', 'estimate', 'ci_lo', 'ci_hi', 'welch_p', 'mw_exact_p', 'holm_p']].to_string(float_format=fmt))
print()
print(C[fam2][['readout', 'estimate', 'ci_lo', 'ci_hi', 'welch_p', 'mw_exact_p', 'holm_p']].to_string(float_format=fmt))
print()
print(Rz[['readout', 'R', 'R_lo', 'R_hi', 'p_gap', 'direction']].to_string(float_format=fmt))

"""Build the numbers ledger: every number cited in the memo, with source cells and reduction."""
import numpy as np, pandas as pd
from scipy import stats

m = pd.read_csv('/tmp/work/tidy/measurements.csv'); m['sub'] = m['sub'].astype(str)
S = pd.read_csv('/tmp/work/out_group_summary_core.csv')
C = pd.read_csv('/tmp/work/out_contrasts_core.csv')
R = pd.read_csv('/tmp/work/out_restoration.csv')
MC = pd.read_csv('/tmp/work/out_mechanism_contrasts.csv')
E = pd.read_csv('/tmp/work/out_early_panel.csv')
EM = pd.read_csv('/tmp/work/out_emax_hill.csv').set_index('formulation')
SG = pd.read_csv('/tmp/work/out_survival_groups.csv')
SC = pd.read_csv('/tmp/work/out_survival_contrasts.csv')
SP = pd.read_csv('/tmp/work/out_survival_pooled.csv')
PM = pd.read_csv('/tmp/work/out_protection_by_match.csv')
PV = pd.read_csv('/tmp/work/out_postvax_weight.csv').set_index('group')
REC = pd.read_csv('/tmp/work/survival_bw_reconciliation.csv')

L = []
RED_LOG = 'GM of per-animal values; 95% CI t-based on log10; contrast = Welch on log10, back-transformed GM ratio'
RED_LIN = 'arithmetic mean of per-animal values; contrast = Welch difference in means (pp), 95% CI'


def add(id_, claim, value, source, reduction):
    L.append(dict(id=id_, claim=claim, value=value, source=source, reduction=reduction))


def f(x, d=3):
    if pd.isna(x):
        return 'NA'
    if abs(x) >= 1000:
        return f'{x:,.0f}'
    return f'{x:.{d}g}'


def grp(readout, g):
    r = S[(S.readout == readout) & (S.group == g)].iloc[0]
    if r.scale == 'log10':
        return f"{f(r.gm)} ({f(r.gm_lo)}-{f(r.gm_hi)})", r.cells
    return f"{f(r['mean'])} ({f(r.ci_lo)}-{f(r.ci_hi)})", r.cells


def con(readout, comp='aged PSLN-344 vs aged PSLN-212'):
    r = C[(C.readout == readout) & (C.comparison == comp)].iloc[0]
    return f"{f(r.estimate)} ({f(r.ci_lo)}-{f(r.ci_hi)}); Welch p={r.welch_p:.2g}; exact MW p={r.mw_exact_p:.2g}; Holm p={r.holm_p:.2g}"


def rest(readout):
    r = R[R.readout == readout].iloc[0]
    return f"R={r.R:.2f} ({r.R_lo:.2f}-{r.R_hi:.2f})"


def core(id_, readout, note=''):
    parts, cells = [], []
    for g, lab in [('PSLN-344', 'aged PSLN-344'), ('PSLN-212', 'aged PSLN-212'), ('PSLN-212(Y)', 'young PSLN-212')]:
        v, c = grp(readout, g); parts.append(f'{lab} {v}'); cells.append(c)
    for g, lab in [('Sham', 'aged Sham'), ('CMP-204', 'aged CMP-204')]:
        if ((S.readout == readout) & (S.group == g)).any():
            v, c = grp(readout, g); parts.append(f'{lab} {v}'); cells.append(c)
    sc = S[S.readout == readout].scale.iloc[0]
    eff = 'GM ratio' if sc == 'log10' else 'difference (pp)'
    val = '; '.join(parts) + f' | 344 vs 212 {eff} ' + con(readout) + f' | 344 vs young {eff} ' + con(readout, 'aged PSLN-344 vs young PSLN-212') + ' | ' + rest(readout)
    add(id_, readout + note, val, '; '.join(cells), (RED_LOG if sc == 'log10' else RED_LIN) + '; R = restoration index, 10,000 bootstrap resamples')


# ---------------- innate / PD
core('L01', 'Lung Ifnb1 16 h (fold vs untreated)')
core('L02', 'Lung Ifnb1 72 h (fold vs untreated)', ' [R<0: signal prolonged beyond young]')
e = EM
add('L03', 'Ifnb1 dose-response (no vaccine, 16 h), sigmoid Emax fit per formulation',
    '; '.join(f"{g}: Emax {e.loc[g,'Emax_fold']:.1f}-fold ({e.loc[g,'Emax_lo']:.1f}-{e.loc[g,'Emax_hi']:.1f}), ED50 {e.loc[g,'ED50_ug']:.1f} ug ({e.loc[g,'ED50_lo']:.1f}-{e.loc[g,'ED50_hi']:.1f})"
              for g in ['PSLN-344', 'PSLN-212', 'CMP-204', 'PSLN-344/R848'])
    + '; 40 vs 20 ug GM ratio: PSLN-212 1.18 (p=0.28), PSLN-344 1.09 (p=0.55); PSLN-344@20ug vs PSLN-212@40ug GM ratio 3.09 (2.12-4.52), p=0.0014',
    'S08!A3:M7 (S08-A, n=3/dose)', 'E = 1 + Emax*D^h/(ED50^h + D^h) least squares on log10 fold; 2,000 residual-bootstrap refits')
for an in ['Ifnb1', 'Il6', 'Ccl2', 'Ccl3', 'Ccl5', 'Tnf', 'Il10']:
    r = E[(E.analyte == an) & (E.time == '16h')].iloc[0]
    r72 = E[(E.analyte == an) & (E.time != '16h')].iloc[0]
    add(f'L04-{an}', f'Lung {an} 16 h and 72 h (S09-A), aged PSLN-344 vs aged PSLN-212 and vs young PSLN-212',
        f"16 h: mean log10 fold 344 {r['log10_PSLN-344']:.2f}, 212 {r['log10_PSLN-212']:.2f}, young {r['log10_PSLN-212(y)']:.2f}; 344/212 = {r.fold_344_vs_212:.3g}x (Hedges g {r.hedges_g:.2f}, Welch p={r.welch_p:.2g}); 344/young = {r.fold_344_vs_young:.2g}x | "
        f"72 h: 344 {r72['log10_PSLN-344']:.2f}, 212 {r72['log10_PSLN-212']:.2f}, young {r72['log10_PSLN-212(y)']:.2f}; 344/young = {r72.fold_344_vs_young:.3g}x",
        'S09!A3:V9 (panel 1, 16 h) and S09!X3:AS9 (panel 2, printed 16h, analysed as 72 h); n=3/group',
        'mean of log10 values as stored; fold = 10^(difference of means); Welch t on log10; Hedges g pooled SD')


def mech(id_, q, extra=''):
    r = MC[MC.question == q].iloc[0]
    ce = 'GM' if r.center == 'GM' else 'mean'
    add(id_, q, f"{r.group1} {ce} {f(r.center1)} vs {r.group2} {f(r.center2)}; {r.effect} {f(r.estimate)} ({f(r.ci_lo)}-{f(r.ci_hi)}); Welch p={r.welch_p:.2g}; exact MW p={r.mw_exact_p:.2g}; n={r.n1}/{r.n2}" + extra,
        f"{r.cells1}; {r.cells2}", RED_LOG if r.center == 'GM' else RED_LIN)


for i, t in enumerate(['16h', '36h', '72h']):
    mech(f'L05-{t}', f'Lung Gm-csf {t}: PSLN-344 vs PSLN-212')
core('L06', 'Lung monocytes day 4 (%)')
core('L07', 'Lung CCR7+ migratory CD11b+ DC 72 h (%)')
core('L08', 'MLN DC carrying AF647-OVA 36 h (%)')
mech('L08b', 'MLN Ag+ DC: PSLN-344 vs PTX (migration blocked)')
core('L09', 'OT-I proliferation with MLN DC (%)')
mech('L09b', 'OT-I priming by MLN DC: PSLN-344 vs PTX')
core('L10a', 'MLN CD11b+ DC CD40+ day 3 (%)')
core('L10b', 'MLN CD11b+ DC CD86+ day 3 (%)')
core('L11', 'Lung cDC1 72 h (%)')
core('L11b', 'Lung CD206+ macrophages (%)', ' [timepoint not stated in annotation]')
mech('L12a', 'BM-derived moDC: WT vs Ifnar-KO (cDC precursors removed)')
mech('L12b', 'BM-derived moDC: Ifnar-KO + GM-CSF vs Ifnar-KO')
mech('L12c', 'BM-derived moDC: WT vs Ifnar-KO (cDC precursors retained)')
mech('L12d', 'Infiltrating BM monocytes: WT vs IFNAR-/- donors (young, n=3)')
mech('L13', 'moDC-like cells: PSLN-212+GM-CSF vs PSLN-212')
mech('L14a', 'Lung monocytes: PSLN-344 vs +INCB3344 (CCR2 antagonist)', ' [timepoint not stated]')
mech('L14b', 'Lung Ly6C+ macrophages: PSLN-344 vs +INCB3344')
mech('L14c', 'Lung GZMB+ CD8: PSLN-344(Y) vs +INCB3344 (YOUNG animals)')
mech('L15', 'Recruited lung monocytes: saline vs carbenoxolone')
mech('L16a', 'AECII uptake: PSLN-SRB vs free SRB')
mech('L16b', 'PSLN-SRB: AECII vs AECI')
mech('L16c', 'Alveolar macrophage uptake: WT vs Sftpa1/Sftpd KO')
mech('L16d', 'AECII uptake (as printed): PSLN-344-SRB vs PSLN-SRB', ' [labels questionable, see I-13]')
for d in ['2', '5', '10']:
    mech(f'L17-d{d}', f'Lung Ly6C+CCR2+ macrophage count day {d}: PSLN-344 vs PSLN-212')
mech('L18a', 'OT-I proliferation in lung: PBS vs PTX')
mech('L18b', 'OT-I proliferation in MLN: PBS vs PTX')

# ---------------- adaptive
for id_, rd in [('L20', 'Serum IgG anti-CA09 H1N1 d14 (titre)'), ('L21', 'Serum IgG anti-Aichi H3N2 d14 (titre)'),
                ('L22', 'HAI anti-CA09 H1N1 d14 (titre)'), ('L23', 'HAI anti-Aichi H3N2 d14 (titre)'),
                ('L24a', 'Neutralising Ab anti-CA09 H1N1 d14 (titre)'), ('L24b', 'Neutralising Ab anti-Aichi H3N2 d14 (titre)'),
                ('L25a', 'Serum IgG anti-CA09 H1N1 d28 post-boost (titre)'), ('L25b', 'Serum IgG anti-Aichi H3N2 d28 post-boost (titre)'),
                ('L26a', 'IgG2a/IgG1 anti-CA09 (recomputed from S13-A/B)'), ('L26b', 'IgG2a/IgG1 anti-Aichi (recomputed from S13-C/D)'),
                ('L27', 'MLN germinal-centre B cells d7 (%)'), ('L28', 'MLN ICOS-high Tfh d7 (%)'),
                ('L29', 'MLN Foxp3+ Tfr within CXCR5+ICOShi d7 (%)'), ('L29b', 'MLN Foxp3+ Tfr d30 (%)'), ('L29c', 'MLN IgG+ of B220+ (%)'),
                ('L31a', 'Lung Ki-67+ CD8 day 3 (%)'), ('L31b', 'Lung GZMB+ CD8 day 3 (%)'),
                ('L32a', 'MLN IFN-g+ CD8, rgH5N1 restim, d14 (%)'), ('L32b', 'MLN IFN-g+ CD8, rgH5N1 restim, d60 (%)'),
                ('L32c', 'MLN GZMB+ CD8 d60 (%)'), ('L33a', 'MLN IFN-g+ CD8, H1N1 restim (%)'), ('L33b', 'MLN IFN-g+ CD8, H3N2 restim (%)'),
                ('L34', 'Lung CD69+CD103+ TRM CD8 d25 (%)'), ('L35', 'Lung Foxp3+ Treg d7 (%) [n=3]')]:
    core(id_, rd)
mech('L30a', 'MLN B-cell Aicda: PSLN-344 vs PSLN-212 (n=3)')
mech('L30b', 'MLN B-cell E47: PSLN-344 vs PSLN-212 (n=3)')
# HAI thresholds
hai = []
for g in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']:
    for blk in ['S03-C', 'S03-G']:
        v = m[(m.block == blk) & (m.group == g)].value.values
        hai.append(f"{blk} {g}: values {','.join(str(int(x)) for x in v)}; >=40: {(v >= 40).sum()}/5; >=160: {(v >= 160).sum()}/5")
add('L22b', 'HAI per-animal values and thresholds (aged unless Y)', ' | '.join(hai), 'S03!K3:O7; S03!K10:O14', 'counts of per-animal reciprocal titres; 0 = below 1:10')
# printed S03-B/F
pb = m[(m.block == 'S03-B') & (m.group == 'PSLN-344')].value.values; pf = m[(m.block == 'S03-F') & (m.group == 'PSLN-344')].value.values
add('L26c', 'IgG2a/IgG1 as printed under "PSLN-344" in S03-B / S03-F (mislabelled)', f"GM {10**np.log10(pb).mean():.3f} (S03-B), {10**np.log10(pf).mean():.3f} (S03-F) - equal to true PSLN-212 values",
    'S03!H3:H7; S03!H10:H14', 'GM of printed per-animal quotients')
R2 = R[R.readout != 'Lung Ifnb1 72 h (fold vs untreated)']
fam = C[C.comparison == 'aged PSLN-344 vs aged PSLN-212']
add('L36', 'Restoration index summary across immunological readouts (aged PSLN-344 relative to aged and young PSLN-212)',
    f"R > 0 (moved toward young) in {(R.R > 0).sum()}/{len(R)} readouts (all but Ifnb1 72 h). {len(R2)} readouts (Ifnb1 72 h excluded): median R {R2.R.median():.2f} (IQR {R2.R.quantile(.25):.2f}-{R2.R.quantile(.75):.2f}; range {R2.R.min():.2f}-{R2.R.max():.2f}); "
    f"CI excludes 0 in {(R2.R_lo > 0).sum()}/{len(R2)}; CI includes 1 in {((R2.R_lo <= 1) & (R2.R_hi >= 1)).sum()}/{len(R2)}; by domain median innate {R2[R2.domain=='Innate'].R.median():.2f}, humoral {R2[R2.domain=='Humoral'].R.median():.2f}, cellular {R2[R2.domain=='Cellular'].R.median():.2f}. "
    f"344 vs 212 across {len(fam)} readouts: Welch p<0.05 in {(fam.welch_p < 0.05).sum()}, Holm p<0.05 in {(fam.holm_p < 0.05).sum()}, exact MW p<0.05 in {(fam.mw_exact_p < 0.05).sum()} (minimum attainable exact MW p: 0.0079 at n=5/5, 0.10 at n=3/3)",
    'see out_restoration.csv / out_contrasts_core.csv (36 readouts, blocks S01-S05, S11, S13, S14)', 'as L01; Holm across the 36-readout family')

# ---------------- survival
def sv(block, g):
    r = SG[(SG.block == block) & (SG.group == g)]
    if not len(r):
        return None
    r = r.iloc[0]; return f"{r.survivors}/{r.n}", r.cells, r.death_days


for id_, blk in [('L40-S03-I', 'S03-I'), ('L40-S03-J', 'S03-J'), ('L40-S06-A', 'S06-A'), ('L40-S06-B', 'S06-B'), ('L40-S06-C', 'S06-C'),
                 ('L40-S06-D', 'S06-D'), ('L40-S06-E', 'S06-E'), ('L40-S06-F', 'S06-F'), ('L40-S06-G', 'S06-G'), ('L40-S15-L', 'S15-L'),
                 ('L40-S15-N', 'S15-N'), ('L40-S15-H', 'S15-H'), ('L40-S06-Eimp', 'S06-E(imprint)'), ('L40-S06-Fimp', 'S06-F(imprint)'),
                 ('L40-S09-B', 'S09-B'), ('L40-S09-D', 'S09-D'), ('L40-S09-F', 'S09-F'), ('L40-S13-E', 'S13-E')]:
    d = SG[SG.block == blk]
    parts = [f"{r.group} {r.survivors}/{r.n} (deaths d{r.death_days})" if r.deaths else f"{r.group} {r.survivors}/{r.n}" for _, r in d.iterrows()]
    cc = SC[SC.block == blk]
    tests = [f"{r.g1} vs {r.g2}: RD {r.RD:.2f} ({r.RD_lo:.2f}-{r.RD_hi:.2f}), log-rank p={r.logrank_p:.2g}, Fisher p={r.fisher_p:.2g}" for _, r in cc.iterrows()]
    add(id_, f'Survival {blk}', '; '.join(parts) + ' || ' + '; '.join(tests), '; '.join(d.cells),
        'count of status-0 (censored = survived) records per group; log-rank (Mantel-Cox); Fisher exact two-sided on end-of-study survival; RD with Newcombe hybrid-score CI')
for _, r in SP.iterrows():
    add(f"L41-{r.tier.split(' ')[0].rstrip(':')}", f'Pooled aged survival PSLN-344 vs PSLN-212: {r.tier}',
        f"PSLN-344 {r.PSLN344_survivors} ({r.pct344:.1f}%) vs PSLN-212 {r.PSLN212_survivors} ({r.pct212:.1f}%); Mantel-Haenszel RD {r.MH_RD:.2f}; MH OR (0.5 zero-cell correction) {r.MH_OR_cc:.1f}; exact stratified permutation p (one-sided) {r.exact_stratified_perm_p_one_sided:.1g}",
        r.blocks, 'sum of per-block survivors; MH risk difference with Cochran weights; labels permuted within experiment 100,000 times')
for _, r in PM.iterrows():
    add(f"L42-{_}", f'Survival by HA/NA match between vaccine and challenge: {r.set}', f"PSLN-344 {r.PSLN344}; PSLN-212 {r.PSLN212}; Sham {r.Sham}; Fisher p={r.fisher_344_vs_212:.2g}",
        r.set[r.set.find('('):], 'pooled counts; Fisher exact two-sided')
add('L42-x', 'PSLN-344 survival without vs with HA/NA match', '20/28 (71%) vs 29/31 (94%), Fisher p=0.036', 'S06-A,B,E,G vs S06-C,F,S03-I,J', 'pooled counts; Fisher exact')
add('L40-S03-J-sens', 'Sensitivity: S03-J without the PSLN-344 record lacking a time value (S03!J46)', 'PSLN-344 9/9 vs PSLN-212 3/10, Fisher p=0.0031 (vs 10/10 vs 3/10 with J46 censored at 21 d)',
    'S03!G17:J46', 'Fisher exact two-sided')
add('L43', 'Survival restoration index (pooled concordant challenges)', 'R=0.74 (95% bootstrap CI 0.53-0.90): PSLN-344 16/21, PSLN-212 2/21, young 21/21',
    'S06!B3:E30 (S06-A), S06!H3:K30 (S06-B), S06!N34:Q61 (S06-F)', '(p344-p212)/(pYoung-p212) on pooled proportions; 10,000 bootstrap resamples within block/arm')
add('L44', 'Background mortality in unchallenged aged controls ("Untreated": no vaccine, no adjuvant, no virus)',
    '4/21 = 19.0% (exact 95% CI 5.4-41.9%) within 14 d [S06-E 1/7 (d4), S06-F 0/7, S06-G 3/7 (d3,7,10)]; PSLN-344 deaths after d60 challenge 7/21, Fisher vs background p=0.48',
    'S06!L62:L68; S06!R62:R68; S06!F99:F105', 'counts; Clopper-Pearson CI; Fisher exact')
add('L47', 'Antigen requirement at d3 (S15-H) [FLAGGED: S15-I weights copied from S15-C]', '3d Vaccine+PSLN-344 6/7; 3d PSLN-344 alone 0/7; 3d Vaccine alone 0/7',
    'S15!B73:D93', 'counts')

# ---------------- safety
pv = PV
add('L50', 'Post-vaccination body weight (S08-D; aged unless Y; CA09 vaccine IN)',
    '; '.join(f"{g}: mean nadir {pv.loc[g,'mean_nadir_pct']:.1f}% (lowest animal {pv.loc[g,'min_nadir_pct']:.1f}%), mean weight-loss AUC {pv.loc[g,'mean_lossAUC']:.1f} %-days, missing at d10 {int(pv.loc[g,'missing_at_day10'])}" for g in pv.index),
    'S08!B21:AE26', 'per-animal minimum of % day-0 weight over d0-10, averaged; AUC of (100 - weight) by trapezoid over recorded days')
add('L51', 'CNS transcripts 36 h after IN vaccine (S10-A; mean (SD) as the annotation specifies)',
    'Ifnb1: PBS 1.00 (0.23), Sham 1.17 (0.34), PSLN-344 1.32 (0.41), cholera toxin 5.50 (1.19); Tnf: 1.00 (0.22), 1.32 (0.39), 1.59 (0.49), 3.50 (1.22); Isg15: 1.00 (0.34), 1.04 (0.17), 1.13 (0.21), 2.68 (0.74). '
    'PSLN-344 vs PBS GM ratios: Ifnb1 1.30 (0.84-2.01) p=0.20; Tnf 1.57 (1.05-2.34) p=0.033 (exact MW 0.056); Isg15 1.16 (0.79-1.72) p=0.39; CT vs PBS: 5.54, 3.40, 2.70 (all p<0.001)',
    'S10!A3:N7', 'mean (SD) of linear fold values; GM ratios Welch on log10')
enc = m[m.block == 'S08-B'].groupby('group').value.mean()
add('L52', 'Encapsulation efficiency of CDN-1807 (A260)', '; '.join(f'{g} {v:.1f}%' for g, v in enc.items()) + '; PSLN-344 vs PSLN-212 -4.8 pp (-15.8 to 6.2), p=0.29',
    'S08!A11:O11', 'mean of 3 replicate preparations')

# ---------------- integrity
add('I-01', 'S06-D (d3 rgH5N1) is identical to S06-C (d14 rgH5N1)', '28/28 (time, status) records identical across 4 groups; S06-D own body-weight record S15-D implies 2 PSLN-344 and 2 young deaths (S06-D: 0)',
    'S06!A3:Q30 vs S06!A34:E61; S15!A33:AC40', 'record-by-record comparison; weight-inferred death = missing before d14 or identical value on >=3 trailing weigh-days')
add('I-02', 'Body-weight trajectories shared between independent experiments',
    '18 cross-block trajectory pairs share >=4 distinct identical same-day values (0 in 20 within-day permutation nulls); blocks involved: S08-D, S09-E, S09-G, S15-A, S15-C, S15-F, S15-I, S15-J, S15-K, S15-M, S15-O. '
    'Integer-offset reuse of high-precision decimals: 205 colliding pairs of 5-dp fractional parts among 268 values with >=4 dp vs 0.36 expected if uniform (shared day-0 denominators inflate chance; corroborative only)',
    'bw_copy_pairs_refined.csv', 'pairwise trajectory comparison; distinct identical values counted once (LOCF plateaus not double-counted)')
disc = REC[REC.concordant == 'NO']
add('I-03', 'Survival vs own body-weight record discordance', f"{disc.surv_block.nunique()} of 17 survival blocks discordant in >=1 arm: " + '; '.join(f"{r.surv_block} {r.group}: {int(r.deaths_surv) if not pd.isna(r.deaths_surv) else 'NA'} recorded vs {r.deaths_inferred_run3}-{r.deaths_inferred_run2} inferred" for _, r in disc.iterrows())
    + '; plus group-set mismatches S03-I/S13-F (Naive vs CMP-204) and S03-J/S13-G (Naive vs PSLN-212)', 'survival_bw_reconciliation.csv', 'as I-01')
add('I-04', 'S03-B / S03-F IgG2a/IgG1 labels rotated', 'printed PSLN-212 = true young PSLN-212; printed PSLN-344 = true PSLN-212; printed PSLN-212(Y) = true PSLN-344 (per-animal agreement with S13 quotients to <=6.5e-4 relative)',
    'S03!G3:I7, S03!G10:I14 vs S13!A3:O7', 'per-animal quotient S13-A/S13-B and S13-C/S13-D matched to printed columns')
add('I-05', 'S09-A panel 2 (printed "16h") is the 72 h data', 'Ifnb1 row 10^x matches S01-A 72 h values 21/21 (to 0.006), S01-A 16 h 0/21', 'S09!X3:AS3 vs S01!G3:L10', 'back-transform and nearest-value match')
add('I-06', 'S11-A (alveolar macrophages) and S11-B (neutrophils) share values', '35 of 100 paired cells identical (first 1-2 animals of every group at every day)', 'S11!B3:U7 vs S11!B10:U14', 'cell-by-cell comparison')
add('I-15', 'S04-B Tfh:Tfr is derived, not measured', 'equals (100 - Foxp3%)/Foxp3% for 20/20 animals', 'S04!A15:D19 vs S04!A8:D12', 'recomputation')
add('I-10', 'Stated n vs observations', 'S03-J stated 9, observed 10/group (S03!J46 status without time); S13-E stated 5, observed 7; S05-A/B stated 3, observed 2; S09-B annotation says Sham 7 but sheet has 8 (S09-F Sham has 7)',
    'S03!G17:J46; S13!R3:V30; S05!A2:I10; S09!B12:B19, S09!B66:B72', 'counts')

add('I-07/08/11-14', 'Other integrity/annotation issues (see data_integrity_log.csv for severity and handling)',
    'S07-C both arms printed "Ly6C-CD206+ MPhi"; S05-A/B antigen conflict (ovalbumin vs bivalent) and H-2Db NP366 tetramer in H-2d BALB/c; S08 rows 89-101 unlabelled survival-like records (6 + 7, all censored at 14); '
    'S09-C day-12 weights identical for 8/8 PSLN-212Y and PSLN-344Y animals; S08-C AECII-PSLN-SRB shares 17.7, 17.5, 12.2 and AECII-PSLN-344-SRB shares 4.92, 4.13 with S01-B under a different gating; '
    'S01-A "Sham" values identical to S09-A "PBS"; PSLN-344/R848 (S08-A) not in Materials; S08-B reports CDN-1807 encapsulation for PSLN-R848 (no CDN-1807)',
    'S07!B15:C20; S05!A1:I10; S08!A89:D101; S09!G18:AD18; S08!A14:B18 vs S01!B14:F15; S01!B3:F3 vs S09!B3:D3', 'direct inspection / value matching')
add('L45', 'Young animals: Mn adds nothing to protection (ceiling)', 'S09-B, S09-D, S09-F: PSLN-344Y 8/8 and PSLN-212Y 8/8 in each; S13-E: PSLN-344(Y) 7/7, CMP-204(Y) 7/7; all young PSLN-212(Y) arms in aged experiments 7/7 except S15-L 6/7',
    'S09!B12:D88; S13!R3:V30; S06; S15!E124:E130', 'counts')
add('L46', 'Prior PR8 infection (imprinting; 14 mo at vaccination) does not blunt PSLN-344', 'PR8 challenge: Naive+344 6/7, Imprint+344 6/7, Naive+212 0/7, Imprint+212 4/7; Perth H3N2 challenge: 6/7, 6/7, 0/7, 0/7; no imprinted-unvaccinated control',
    'S06!G71:Q98', 'counts; Fisher exact in L40-S06-Eimp / L40-S06-Fimp')

_e16 = E[E.time == '16h'].set_index('analyte')
_parts = []
for an in ['Ifnb1', 'Il6', 'Ccl2', 'Ccl3', 'Ccl5', 'Tnf', 'Il10']:
    r = _e16.loc[an]
    Rv = (r['log10_PSLN-344'] - r['log10_PSLN-212']) / (r['log10_PSLN-212(y)'] - r['log10_PSLN-212'])
    _parts.append(f"{an} R={Rv:.2f}")
add('L04-R', 'Restoration index for the 16 h lung transcript panel (S09-A panel 1, n=3)', '; '.join(_parts) + ' (Tnf and Il10: young is LOWER than aged PSLN-212, so R is not a restoration measure for these)',
    'S09!A3:V9', 'R on mean log10 values, no CI (n=3)')


_S = S.copy(); _S['c'] = _S.apply(lambda r: r.gm if r.scale == 'log10' else r['mean'], axis=1)
_Ri = R.set_index('readout'); _ok = 0; _tot = 0; _exc = []
for _rd, _d in _S.groupby('readout'):
    if _rd == 'Lung Ifnb1 72 h (fold vs untreated)':
        continue
    _d = _d.set_index('group').c; _sg = 1 if _Ri.loc[_rd, 'young_minus_aged_PSLN212_on_scale'] > 0 else -1
    _arms = [g for g in ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)'] if g in _d.index]
    _v = [_sg * _d[g] for g in _arms]; _m = all(_v[k] < _v[k + 1] for k in range(len(_v) - 1))
    _ok += _m; _tot += 1
    if not _m: _exc.append(_rd)
add('L37', 'Group-level rank order of immune readouts vs survival ordering (sham < PSLN-212 < PSLN-344 < young)',
    f"{_ok} of {_tot} readouts (direction-adjusted; Ifnb1 72 h excluded) rank the arms exactly as survival does; exceptions: {'; '.join(_exc)} (sham and PSLN-212 swap; PSLN-212 < PSLN-344 < young holds)",
    'group_summaries_core_readouts.csv', 'group centres (GM or mean) compared; direction from the sign of young - aged PSLN-212')


def gm_block(block, sub, g):
    v = m[(m.block == block) & (m['sub'] == sub) & (m.group == g)].sort_values('idx')
    lv = np.log10(v.value.values); se = lv.std(ddof=1) / np.sqrt(len(lv)); t = stats.t.ppf(.975, len(lv) - 1)
    return f"{10**lv.mean():.3g} ({10**(lv.mean()-t*se):.3g}-{10**(lv.mean()+t*se):.3g})", f"{v.cell.iloc[0]}:{v.cell.iloc[-1].split('!')[1]}"
parts, cells = [], []
for g in ['Sham', 'CMP-204', 'PSLN-R848', 'PSLN-212', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(Y)', 'PSLN-344(Y)']:
    a, c = gm_block('S01-A', '16h', g); parts.append(f'{g} {a}'); cells.append(c)
add('L01b', 'Lung Ifnb1 16 h, all formulations (S01-A; aged unless Y)', '; '.join(parts), '; '.join(cells), RED_LOG)
add('L70', 'Power for the confirmatory study (Fisher exact, two-sided alpha 0.05, 20,000 simulations)',
    'PSLN-344 76% vs PSLN-212 10% survival (rates from L41-T3-lenient): n=7/arm 0.56, n=10 0.77, n=12 0.91, n=15 0.95. PSLN-344 76% vs a benchmark at 40%: n=20 0.53, n=30 0.74, n=40 0.88; vs a benchmark at 50%: n=40 0.60',
    'derived from L41', 'binomial simulation')

add('L71', 'Power for lung viral titre endpoint (two-sample t-test, two-sided alpha 0.05) - ASSUMPTION: SD 0.6 log10 (no viral-titre data exist in the package)',
    'difference 1.0 log10: n=6.8/arm for 80% power, power 0.87 at n=8; difference 0.75 log10: n=11.1/arm; difference (or non-inferiority margin) 0.5 log10: n=23.6/arm',
    'assumption-based; statsmodels TTestIndPower', 'power analysis')

Ldf = pd.DataFrame(L)
Ldf.to_csv('/tmp/outputs/numbers_ledger.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_colwidth', 400); pd.set_option('display.max_rows', 500)
for _, r in Ldf.iterrows():
    print(f"{r.id}: {r.claim}\n    {r.value}\n    [{r.source}]")

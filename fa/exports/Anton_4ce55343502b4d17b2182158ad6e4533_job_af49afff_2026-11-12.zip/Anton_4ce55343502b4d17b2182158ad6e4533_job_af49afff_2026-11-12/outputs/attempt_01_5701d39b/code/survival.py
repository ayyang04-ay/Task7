"""
Survival re-analysis.
Reductions: per-animal time-to-event as stored (event=1 death, 0 censored). End-of-observation survival =
count of status-0 records. Log-rank (statsmodels survdiff). Fisher exact (two-sided) on end-of-study survival.
Risk difference with Newcombe hybrid-score 95% CI. Pooled PSLN-344 vs PSLN-212 (aged): Mantel-Haenszel odds
ratio of survival (StratifiedTable, 0.5 added to zero cells only for the OR point estimate) and an exact stratified
permutation test (labels permuted within experiment, 100,000 draws) on total survivors.
S03-J PSLN-344 record with blank time (S03!J46, status 0) is treated as censored at 21 d (all other censoring at 21).
"""
import numpy as np, pandas as pd
from scipy import stats
from statsmodels.duration.survfunc import survdiff, SurvfuncRight
from statsmodels.stats.contingency_tables import StratifiedTable

s = pd.read_csv('/tmp/work/tidy/survival.csv')
s.loc[(s.block == 'S03-J') & s.time.isna(), 'time'] = 21.0
rng = np.random.default_rng(7)

META = {  # block: (cohort, strain, vaccine, challenge, interval, HA/NA shared with vaccine?, integrity tier note)
    'S03-I': ('aged', 'BALB/c', 'bivalent H1N1(CA09)+H3N2(Aichi)', '10x mLD50 CA09 H1N1', 'd14', 'homologous HA+NA'),
    'S03-J': ('aged', 'BALB/c', 'rgH5N1 (VN04 HA/NA)', 'wild-type VN04 H5N1', 'd2', 'homologous HA+NA'),
    'S06-A': ('aged', 'BALB/c', 'Aichi H3N2', '5x mLD50 PR8 H1N1', 'd14', 'none (H3N2 vs H1N1)'),
    'S06-B': ('aged', 'BALB/c', 'Aichi H3N2', '5x mLD50 PR8 H1N1', 'd3', 'none (H3N2 vs H1N1)'),
    'S06-C': ('aged', 'BALB/c', 'bivalent', '5x mLD50 rgH5N1', 'd14', 'NA (N1 from CA09)'),
    'S06-D': ('aged', 'BALB/c', 'bivalent', '5x mLD50 rgH5N1', 'd3', 'NA (N1 from CA09)'),
    'S06-E': ('aged', 'BALB/c', 'Aichi H3N2', '5x mLD50 PR8 H1N1', 'd60', 'none (H3N2 vs H1N1)'),
    'S06-F': ('aged', 'BALB/c', 'bivalent', '5x mLD50 rgH5N1', 'd60', 'NA (N1 from CA09)'),
    'S06-G': ('aged', 'BALB/c', 'CA09 H1N1', '5x mLD50 Perth H3N2', 'd60', 'none (H1N1 vs H3N2)'),
    'S15-L': ('aged', 'C57BL/6', 'bivalent', 'not stated in annotation', 'not stated', 'n/a'),
    'S15-N': ('aged', 'Swiss Webster', 'bivalent', 'not stated in annotation', 'not stated', 'n/a'),
    'S15-H': ('aged', 'BALB/c', 'bivalent / PSLN-344 alone / both', '5x mLD50 VN04 rgH5N1', 'd3', 'NA (N1)'),
    'S06-E(imprint)': ('14 mo at vaccination', 'BALB/c', 'bivalent', '5x LD50 PR8 H1N1', 'not stated', 'H1 subtype (CA09 vs PR8), N1'),
    'S06-F(imprint)': ('14 mo at vaccination', 'BALB/c', 'bivalent', '5x LD50 Perth H3N2', 'd14', 'H3 subtype drifted (Aichi vs Perth), N2'),
    'S09-B': ('young', 'BALB/c', 'Aichi H3N2', '5x mLD50 PR8 H1N1', 'd21', 'none'),
    'S09-D': ('young', 'BALB/c', 'CA09 H1N1', '5x mLD50 Perth H3N2', 'd21', 'none'),
    'S09-F': ('young', 'BALB/c', 'bivalent', '5x mLD50 VN04 rgH5N1', 'd180', 'NA (N1)'),
    'S13-E': ('young', 'BALB/c', 'bivalent', '10x mLD50 CA09 H1N1', 'd14', 'homologous'),
}

# integrity tiering of survival evidence (see integrity log for evidence)
FLAGS = {
    'S03-I': 'Body-weight record S13-F disagrees (PSLN-212: 4 inferred deaths vs 7; Naive group in place of CMP-204)',
    'S03-J': 'Stated n=9 vs 10/group; one time blank; body-weight record S13-G disagrees for Sham (2-5 inferred deaths vs 9) and lists Naive instead of PSLN-212',
    'S06-A': 'Concordant with S15-A; but S15-A PSLN-344 trajectories #2/#3 reappear in S15-M and S15-J (direction of copying unknown)',
    'S06-B': 'Concordant with S15-B; no trajectory-copy flag',
    'S06-C': 'S15-C disagrees by 1 PSLN-212 death; S15-C PSLN-344 trajectories reappear as S15-I (copy)',
    'S06-D': 'EXACT DUPLICATE of S06-C (all 28 records); own body-weight record S15-D implies 2 PSLN-344 and 2 young deaths',
    'S06-E': 'S15-E disagrees (PSLN-212 6 vs 7 deaths; PSLN-344 1 vs 2)',
    'S06-F': 'Concordant with S15-F for PSLN-344/PSLN-212 arms; young arm of S15-F shares decimals with S08-D',
    'S06-G': 'S15-G disagrees for PSLN-344 (0-2 inferred vs 3); unchallenged Untreated arm 3/7 deaths',
    'S15-L': 'S15-M disagrees (young 0 vs 1 death); S15-M trajectories copied from S09-E (young BALB/c) and S15-A',
    'S15-N': 'Concordant with S15-O; S15-O PSLN-344 trajectories shared with S15-M',
    'S15-H': 'Concordant with S15-I, but S15-I Vaccine+PSLN-344 trajectories are copies of S15-C PSLN-344 (days 2-12)',
    'S06-E(imprint)': 'Concordant with S15-J; S15-J shares high-precision decimals with S15-A/S15-M; no imprinted-unvaccinated control',
    'S06-F(imprint)': 'Concordant with S15-K; S15-K shares decimals with S15-J',
    'S09-B': 'Concordant with S09-C; S09-C day-12 row identical across PSLN-212Y and PSLN-344Y (8/8 animals)',
    'S09-D': 'Concordant with S09-E; S09-E trajectories reappear in S15-M and S09-G',
    'S09-F': 'Sham n=7 in survival vs 8 in S09-G; S09-G trajectory #8 identical to S09-E',
    'S13-E': 'Stated n=5 vs 7 per group; no body-weight record',
}
TIER3 = {'S06-B', 'S06-F'}            # concordant and no copy flag in compared arms
TIER3_LENIENT = TIER3 | {'S06-A'}     # concordant; copy involvement of unknown direction


def newcombe(x1, n1, x2, n2):
    def wilson(x, n):
        z = 1.959964; p = x / n; d = 1 + z * z / n
        c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
        return c - h, c + h
    p1, p2 = x1 / n1, x2 / n2
    l1, u1 = wilson(x1, n1); l2, u2 = wilson(x2, n2)
    d = p1 - p2
    return d, d - np.sqrt((p1 - l1) ** 2 + (u2 - p2) ** 2), d + np.sqrt((u1 - p1) ** 2 + (p2 - l2) ** 2)


def logrank(time, event, grp):
    """two-group log-rank (Mantel-Cox); NaN if no events"""
    if event.sum() == 0:
        return np.nan
    O = E = V = 0.0
    for t in np.unique(time[event == 1]):
        at = time >= t
        n = at.sum(); n1 = (at & (grp == 1)).sum()
        dd = ((time == t) & (event == 1)).sum(); d1 = ((time == t) & (event == 1) & (grp == 1)).sum()
        O += d1; E += dd * n1 / n
        if n > 1:
            V += dd * (n1 / n) * (1 - n1 / n) * (n - dd) / (n - 1)
    if V == 0:
        return np.nan
    return stats.chi2.sf((O - E) ** 2 / V, 1)


def compare(d, g1, g2):
    a = d[d.group == g1]; b = d[d.group == g2]
    x = pd.concat([a, b]); grp = (x.group == g1).astype(int).values
    p_lr = logrank(x.time.values, x.event.values, grp)
    s1, n1 = int((a.event == 0).sum()), len(a); s2, n2 = int((b.event == 0).sum()), len(b)
    p_f = stats.fisher_exact([[s1, n1 - s1], [s2, n2 - s2]])[1]
    rd, lo, hi = newcombe(s1, n1, s2, n2)
    return dict(g1=g1, g2=g2, surv1=f'{s1}/{n1}', surv2=f'{s2}/{n2}', RD=rd, RD_lo=lo, RD_hi=hi, logrank_p=p_lr, fisher_p=p_f)


rows, per_group = [], []
for blk, d in s.groupby('block', sort=False):
    if blk.startswith('S08'):
        continue
    for g, dg in d.groupby('group', sort=False):
        sf = SurvfuncRight(dg.time.values, dg.event.values)
        med = np.nan
        try:
            med = sf.quantile(0.5)
        except Exception:
            pass
        per_group.append(dict(block=blk, group=g, n=len(dg), deaths=int(dg.event.sum()), survivors=int((dg.event == 0).sum()),
                              pct_survival=100 * (dg.event == 0).mean(), median_survival_days=med,
                              death_days=','.join(str(int(t)) for t in sorted(dg[dg.event == 1].time)),
                              cells=f"{dg.cell_status.iloc[0]}..{dg.cell_status.iloc[-1].split('!')[1]}"))
    gs = list(d.group.unique())
    pairs = []
    if 'PSLN-344' in gs and 'PSLN-212' in gs: pairs.append(('PSLN-344', 'PSLN-212'))
    if 'PSLN-344' in gs and 'Sham' in gs: pairs.append(('PSLN-344', 'Sham'))
    if 'PSLN-344' in gs and 'PSLN-212(Y)' in gs: pairs.append(('PSLN-344', 'PSLN-212(Y)'))
    if 'PSLN-344' in gs and 'Untreated' in gs: pairs.append(('PSLN-344', 'Untreated'))
    if blk == 'S15-H': pairs += [('3d Vaccine+PSLN-344', '3d PSLN-344'), ('3d Vaccine+PSLN-344', '3d Vaccine')]
    if 'imprint' in blk: pairs += [('Naive+PSLN-344', 'Naive+PSLN-212'), ('Imprinting+PSLN-344', 'Imprinting+PSLN-212'),
                                   ('Imprinting+PSLN-212', 'Naive+PSLN-212'), ('Imprinting+PSLN-344', 'Naive+PSLN-344')]
    if blk in ('S09-B', 'S09-D', 'S09-F'): pairs += [('PSLN-344Y', 'PSLN-212Y'), ('PSLN-344Y', 'Sham')]
    if blk == 'S13-E': pairs += [('PSLN-344(Y)', 'CMP-204(Y)'), ('PSLN-344(Y)', 'Sham'), ('Sham', 'Naive')]
    for g1, g2 in pairs:
        r = compare(d, g1, g2); r.update(block=blk); rows.append(r)

G = pd.DataFrame(per_group); Cmp = pd.DataFrame(rows)
meta = pd.DataFrame([(k, *v) for k, v in META.items()], columns=['block', 'cohort', 'strain', 'vaccine', 'challenge',
                                                                  'interval', 'HA/NA shared vaccine-challenge'])
meta['integrity_note'] = meta.block.map(FLAGS)
meta['tier'] = meta.block.map(lambda b: 'T3 clean' if b in TIER3 else ('T3-lenient' if b in TIER3_LENIENT else
                                                                      ('excluded (duplicate)' if b == 'S06-D' else 'flagged')))
G.to_csv('/tmp/work/out_survival_groups.csv', index=False)
Cmp.to_csv('/tmp/work/out_survival_contrasts.csv', index=False)
meta.to_csv('/tmp/work/out_survival_meta.csv', index=False)

# pooled aged PSLN-344 vs PSLN-212
aged_blocks = ['S03-I', 'S03-J', 'S06-A', 'S06-B', 'S06-C', 'S06-D', 'S06-E', 'S06-F', 'S06-G', 'S15-L', 'S15-N']


def pooled(blocks, label):
    tabs, S1, N1, S2, N2 = [], 0, 0, 0, 0
    strata = []
    for b in blocks:
        d = s[s.block == b]
        a = d[d.group == 'PSLN-344']; c = d[d.group == 'PSLN-212']
        s1, n1, s2, n2 = int((a.event == 0).sum()), len(a), int((c.event == 0).sum()), len(c)
        S1 += s1; N1 += n1; S2 += s2; N2 += n2
        tabs.append(np.array([[s1, n1 - s1], [s2, n2 - s2]], dtype=float))
        strata.append((np.r_[np.ones(n1), np.zeros(n2)], np.r_[(a.event == 0).values, (c.event == 0).values].astype(int)))
    st = StratifiedTable([t + 0.5 * (t == 0).any() for t in tabs])
    st_raw = StratifiedTable(tabs)
    obs = sum((y[g == 1]).sum() for g, y in strata)
    cnt = 0; B = 100000
    for _ in range(B):
        tot = 0
        for g, y in strata:
            gp = rng.permutation(g); tot += y[gp == 1].sum()
        cnt += tot >= obs
    # MH risk difference (Cochran weights n1*n2/(n1+n2))
    w = []; rd = []
    for t in tabs:
        n1, n2 = t[0].sum(), t[1].sum(); w.append(n1 * n2 / (n1 + n2)); rd.append(t[0, 0] / n1 - t[1, 0] / n2)
    rd_mh = np.sum(np.array(w) * np.array(rd)) / np.sum(w)
    return dict(tier=label, blocks=','.join(blocks), PSLN344_survivors=f'{S1}/{N1}', PSLN212_survivors=f'{S2}/{N2}',
                pct344=100 * S1 / N1, pct212=100 * S2 / N2, MH_RD=rd_mh, MH_OR_cc=st.oddsratio_pooled,
                MH_test_p=st_raw.test_null_odds().pvalue, exact_stratified_perm_p_one_sided=(cnt + 1) / (B + 1))


P = pd.DataFrame([
    pooled(aged_blocks, 'T1 all aged blocks as printed'),
    pooled([b for b in aged_blocks if b != 'S06-D'], 'T2 excluding exact duplicate S06-D'),
    pooled(sorted(TIER3_LENIENT), 'T3-lenient: concordant blocks (S06-A,B,F)'),
    pooled(sorted(TIER3), 'T3 strict: concordant + no copy flag (S06-B,F)'),
])
P.to_csv('/tmp/work/out_survival_pooled.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 60)
print(G.to_string()); print(); print(Cmp.to_string(float_format=lambda v: f'{v:.3g}')); print(); print(P.to_string(float_format=lambda v: f'{v:.3g}'))
# background mortality of unchallenged aged controls
u = s[s.group == 'Untreated']
k, n = int(u.event.sum()), len(u)
ci = stats.binomtest(k, n).proportion_ci(method='exact')
print(f'\nUnchallenged aged controls: {k}/{n} died within 14 d = {100*k/n:.1f}% (exact 95% CI {100*ci.low:.1f}-{100*ci.high:.1f}%)')
d60 = s[s.block.isin(['S06-E', 'S06-F', 'S06-G']) & (s.group == 'PSLN-344')]
k2, n2 = int(d60.event.sum()), len(d60)
print(f'PSLN-344 deaths at d60 challenge (S06-E/F/G): {k2}/{n2}; Fisher vs unchallenged: p={stats.fisher_exact([[k2, n2-k2],[k, n-k]])[1]:.3f}')

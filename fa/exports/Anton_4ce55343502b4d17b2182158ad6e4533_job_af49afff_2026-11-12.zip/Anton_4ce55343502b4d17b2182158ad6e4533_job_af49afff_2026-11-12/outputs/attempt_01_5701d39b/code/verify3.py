import pandas as pd, numpy as np
m = pd.read_csv('tidy/measurements.csv'); m['sub']=m['sub'].astype(str)
def vec(block, group, sub='nan'):
    x = m[(m.block==block)&(m.group==group)&(m['sub']==sub)].sort_values('idx'); return x.value.values
for rblk, a2, a1 in [('S03-B','S13-A','S13-B'), ('S03-F','S13-C','S13-D')]:
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        r = vec(a2,g)/vec(a1,g)
        best = min(['PSLN-212','PSLN-344','PSLN-212(Y)'], key=lambda gr: np.max(np.abs(r/vec(rblk,gr)-1)))
        err = np.max(np.abs(r/vec(rblk,best)-1))
        print(f'{rblk}: subclass-titre group {g:12s} ratio={np.round(r,3)} best match printed "{best}" (max rel err {err:.1e})')

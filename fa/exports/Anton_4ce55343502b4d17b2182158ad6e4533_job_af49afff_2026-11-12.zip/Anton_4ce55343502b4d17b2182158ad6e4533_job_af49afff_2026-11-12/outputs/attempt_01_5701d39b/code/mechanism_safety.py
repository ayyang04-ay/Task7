"""
Mechanistic, dose-response, early-biomarker and safety blocks.
Reductions: log10 for fold-change/qPCR/counts (GM ratio, Welch CI); linear % (difference in means, Welch CI);
exact Mann-Whitney as check. Emax fit: E = 1 + Emax*D/(ED50 + D) (E0 fixed at 1 = untreated reference),
least squares on log10(E) per formulation, 2,000 parametric-residual bootstrap refits for CIs.
S09-A panel 2 is analysed as 72 h (its Ifnb1 row reproduces S01-A 72 h values; the printed '16h' label is an error).
"""
import numpy as np, pandas as pd
from scipy import stats, optimize

rng = np.random.default_rng(11)
m = pd.read_csv('/tmp/work/tidy/measurements.csv'); m['sub'] = m['sub'].astype(str)
bw = pd.read_csv('/tmp/work/tidy/bodyweight.csv')


def x(block, group, sub='nan'):
    d = m[(m.block == block) & (m.group == group) & (m['sub'] == sub)].sort_values('idx')
    return d.value.values.astype(float), (f"{d.cell.iloc[0]}:{d.cell.iloc[-1].split('!')[1]}" if len(d) else '')


def welch(a, b, log):
    ta, tb = (np.log10(a), np.log10(b)) if log else (a, b)
    va, vb = ta.var(ddof=1) / len(ta), tb.var(ddof=1) / len(tb)
    dfr = (va + vb) ** 2 / (va ** 2 / (len(ta) - 1) + vb ** 2 / (len(tb) - 1))
    d = ta.mean() - tb.mean(); se = np.sqrt(va + vb); t = stats.t.ppf(.975, dfr); p = 2 * stats.t.sf(abs(d / se), dfr)
    if log:
        return 10 ** d, 10 ** (d - t * se), 10 ** (d + t * se), p
    return d, d - t * se, d + t * se, p


def mwp(a, b):
    return stats.mannwhitneyu(a, b, alternative='two-sided', method='exact').pvalue


rows = []


def contrast(label, blk, g1, g2, log, sub='nan', note=''):
    a, ca = x(blk, g1, sub); b, cb = x(blk, g2, sub)
    est, lo, hi, p = welch(a, b, log)
    summ = lambda v: (10 ** np.log10(v).mean() if log else v.mean())
    rows.append(dict(question=label, block=blk, sub=sub, group1=g1, group2=g2, n1=len(a), n2=len(b),
                     center1=summ(a), center2=summ(b), center='GM' if log else 'mean',
                     effect='GM ratio' if log else 'difference (pp)', estimate=est, ci_lo=lo, ci_hi=hi,
                     welch_p=p, mw_exact_p=mwp(a, b), cells1=ca, cells2=cb, note=note))


# Delivery / targeting
contrast('AECII uptake: PSLN-SRB vs free SRB', 'S01-B', 'AECII/PSLN-SRB', 'AECII/FreeSRB', False)
contrast('AECI uptake: PSLN-SRB vs free SRB', 'S01-B', 'AECI/PSLN-SRB', 'AECI/FreeSRB', False)
contrast('PSLN-SRB: AECII vs AECI', 'S01-B', 'AECII/PSLN-SRB', 'AECI/PSLN-SRB', False)
contrast('Alveolar macrophage uptake: WT vs Sftpa1/Sftpd KO', 'S01-C', 'WT', 'SPA/D', False)
contrast('AECII uptake (as printed): PSLN-344-SRB vs PSLN-SRB', 'S08-C', 'AECII-PSLN-344-SRB', 'AECII-PSLN-SRB', False,
         note='labels questionable: S08-C AECII-PSLN-SRB shares values with S01-B; S08-C AECI-PSLN-SRB 13.8% vs S01-B 3.8%')
contrast('AECI uptake (as printed): PSLN-344-SRB vs PSLN-SRB', 'S08-C', 'AECI-PSLN-344-SRB', 'AECI-PSLN-SRB', False)
contrast('Encapsulation efficiency: PSLN-344 vs PSLN-212', 'S08-B', 'PSLN-344', 'PSLN-212', False)
# GM-CSF axis
for t in ['16h', '36h', '72h']:
    contrast(f'Lung Gm-csf {t}: PSLN-344 vs PSLN-212', 'S02-F', 'PSLN-344', 'PSLN-212', True, sub=t)
contrast('moDC-like cells: PSLN-212+GM-CSF vs PSLN-212', 'S02-G', 'PSLN-212+GM-CSF', 'PSLN-212', False)
contrast('BM-derived moDC: WT vs Ifnar-KO (cDC precursors removed)', 'S02-H', 'WT w/o cDC', 'IFN w/o cDC', False)
contrast('BM-derived moDC: Ifnar-KO + GM-CSF vs Ifnar-KO', 'S02-H', 'GMCSF', 'IFN w/o cDC', False)
contrast('BM-derived moDC: WT vs Ifnar-KO (cDC precursors retained)', 'S02-H', 'WT w/ cDC', 'IFN w/ cDC', False)
contrast('Infiltrating BM monocytes: WT vs IFNAR-/- donors (young, n=3)', 'S12-A', 'WT to WT', 'IFNAR-/- to WT', False)
# CCR2 / gap junction
contrast('Lung monocytes: PSLN-344 vs +INCB3344 (CCR2 antagonist)', 'S07-B', 'PSLN-344', 'PSLN-344+INCB3344', False, sub='Monocytes')
contrast('Lung Ly6C+ macrophages: PSLN-344 vs +INCB3344', 'S07-B', 'PSLN-344', 'PSLN-344+INCB3344', False, sub='Ly6C+ Mphi')
contrast('Lung GZMB+ CD8: PSLN-344(Y) vs +INCB3344 (YOUNG animals)', 'S02-I', 'PSLN-344(Y)', 'PSLN-344(Y)+INCB3344', False)
contrast('Recruited lung monocytes: saline vs carbenoxolone', 'S11-C', 'CBX-', 'CBX+', False)
for dday in ['2', '5', '10']:
    contrast(f'Lung Ly6C+CCR2+ macrophage count day {dday}: PSLN-344 vs PSLN-212', 'S07-A', 'PSLN-344', 'PSLN-212', True, sub=dday)
# migration dependence
contrast('MLN Ag+ DC: PSLN-344 vs PTX (migration blocked)', 'S02-C', 'PSLN-344', 'PTX', False,
         note='PTX arm adjuvant not stated in annotation')
contrast('OT-I priming by MLN DC: PSLN-344 vs PTX', 'S02-E', 'PSLN-344', 'PTX', False)
contrast('OT-I proliferation in lung: PBS vs PTX', 'S05-C', 'Lung', 'Lung+PTX', False)
contrast('OT-I proliferation in MLN: PBS vs PTX', 'S05-C', 'MLN', 'MLN+PTX', False)
# Aicda / E47 (no young arm)
contrast('MLN B-cell Aicda: PSLN-344 vs PSLN-212 (n=3)', 'S03-L', 'PSLN-344', 'PSLN-212', True, sub='Aicda')
contrast('MLN B-cell E47: PSLN-344 vs PSLN-212 (n=3)', 'S03-L', 'PSLN-344', 'PSLN-212', True, sub='E47')
# macrophage transfer (labels duplicated)
contrast('Lung Treg after macrophage transfer: column B vs column C (both printed "Ly6C-CD206+")', 'S07-C',
         'col B "Ly6C-CD206+ MPhi"', 'col C "Ly6C-CD206+ MPhi"', False, note='uninterpretable: identical labels')
# CNS safety
for an in ['Ifnb1', 'Tnf', 'Isg15']:
    contrast(f'CNS {an} 36 h: PSLN-344 vs PBS', 'S10-A', 'PSLN-344', 'PBS', True, sub=an)
    contrast(f'CNS {an} 36 h: cholera toxin vs PBS (positive control)', 'S10-A', 'CT', 'PBS', True, sub=an)

C = pd.DataFrame(rows)
C.to_csv('/tmp/work/out_mechanism_contrasts.csv', index=False)
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 70)
print(C[['question', 'n1', 'n2', 'center1', 'center2', 'effect', 'estimate', 'ci_lo', 'ci_hi', 'welch_p', 'mw_exact_p']].to_string(float_format=lambda v: f'{v:.3g}'))

# CNS: mean and SD as the annotation specifies for S10-A
print('\nS10-A mean (SD) per annotation:')
for an in ['Ifnb1', 'Tnf', 'Isg15']:
    print(an, {g: f"{x('S10-A', g, an)[0].mean():.2f} ({x('S10-A', g, an)[0].std(ddof=1):.2f})" for g in ['PBS', 'Sham', 'PSLN-344', 'CT']})

# ---------------- S09-A early panel: 16 h (panel 1) and 72 h (panel 2, relabelled)
rows2 = []
P1, P2 = 'S09-A panel1 (cols A-V)', 'S09-A panel2 (cols X-AS)'
for an in ['Ifnb1', 'Il6', 'Ccl2', 'Ccl3', 'Ccl5', 'Tnf', 'Il10']:
    for panel, tlabel in [(P1, '16h'), (P2, '72h (printed 16h)')]:
        v = {g: x(panel, g, an)[0] for g in ['PBS', 'CMP-204', 'PSLN-212', 'PSLN-R848', 'PSLN-212/R848', 'PSLN-344', 'PSLN-212(y)']}
        a, b, y = v['PSLN-344'], v['PSLN-212'], v['PSLN-212(y)']
        d = a.mean() - b.mean()
        sp = np.sqrt(((len(a) - 1) * a.var(ddof=1) + (len(b) - 1) * b.var(ddof=1)) / (len(a) + len(b) - 2))
        g_h = d / sp * (1 - 3 / (4 * (len(a) + len(b)) - 9))
        p = stats.ttest_ind(a, b, equal_var=False).pvalue
        rows2.append(dict(analyte=an, time=tlabel, **{f'log10_{k}': val.mean() for k, val in v.items()},
                          delta_log10_344_vs_212=d, fold_344_vs_212=10 ** d, hedges_g=g_h, welch_p=p,
                          delta_log10_344_vs_young=a.mean() - y.mean(), fold_344_vs_young=10 ** (a.mean() - y.mean())))
E = pd.DataFrame(rows2)
E.to_csv('/tmp/work/out_early_panel.csv', index=False)
print('\nS09-A early panel (log10 fold vs untreated; n=3/group):')
print(E[['analyte', 'time', 'log10_PSLN-212', 'log10_PSLN-344', 'log10_PSLN-212(y)', 'log10_PSLN-212/R848', 'fold_344_vs_212',
         'hedges_g', 'welch_p', 'fold_344_vs_young']].to_string(float_format=lambda v: f'{v:.3g}'))

# ---------------- S08-A dose response Emax
doses = np.array([1, 5, 10, 20, 40.])
res = []


def emax_fit(D, Y):
    f = lambda p, d: np.log10(1 + p[0] * d / (p[1] + d))
    r = lambda p: f(p, D) - np.log10(Y)
    sol = optimize.least_squares(r, x0=[30, 10], bounds=([0, 0.01], [1e4, 1e4]))
    return sol.x, sol.fun


for g in ['CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-344/R848']:
    D, Y = [], []
    for dz in doses:
        v = x('S08-A', g, str(int(dz)))[0]; D += [dz] * len(v); Y += list(v)
    D, Y = np.array(D), np.array(Y)
    p, resid = emax_fit(D, Y)
    fitted = np.log10(1 + p[0] * D / (p[1] + D))
    boots = []
    for _ in range(2000):
        yb = 10 ** (fitted + rng.choice(resid, len(resid)))
        boots.append(emax_fit(D, yb)[0])
    boots = np.array(boots)
    means = {int(dz): x('S08-A', g, str(int(dz)))[0].mean() for dz in doses}
    res.append(dict(formulation=g, Emax=p[0], Emax_lo=np.percentile(boots[:, 0], 2.5), Emax_hi=np.percentile(boots[:, 0], 97.5),
                    ED50_ug=p[1], ED50_lo=np.percentile(boots[:, 1], 2.5), ED50_hi=np.percentile(boots[:, 1], 97.5),
                    **{f'mean_{k}ug': v for k, v in means.items()}))
Em = pd.DataFrame(res); Em.to_csv('/tmp/work/out_emax.csv', index=False)
print('\nS08-A Emax fits (Ifnb1 fold, 16 h, no vaccine):'); print(Em.to_string(float_format=lambda v: f'{v:.3g}'))
# 40 ug PSLN-212 vs 20 ug PSLN-344
a = x('S08-A', 'PSLN-344', '20')[0]; b = x('S08-A', 'PSLN-212', '40')[0]
print('PSLN-344 @20ug vs PSLN-212 @40ug GM ratio/CI/p:', welch(a, b, True))

# ---------------- S08-D post-vaccination body weight (reactogenicity)
d = bw[bw.block == 'S08-D']
rows3 = []
for g, dg in d.groupby('group', sort=False):
    piv = dg.pivot(index='idx', columns='day', values='value')
    nadir = piv.min(axis=1)
    missing10 = piv[10].isna().sum()
    # AUC of weight loss (100 - w) by trapezoid over available days, per animal
    auc = []
    for _, r in piv.iterrows():
        rr = r.dropna(); auc.append(np.trapezoid(100 - rr.values, rr.index.values))
    rows3.append(dict(group=g, n=len(piv), mean_nadir_pct=nadir.mean(), min_nadir_pct=nadir.min(), mean_day8=piv[8].mean(),
                      mean_lossAUC=np.mean(auc), missing_at_day10=int(missing10),
                      cells=f"{dg.cell.iloc[0]}..{dg.cell.iloc[-1].split('!')[1]}"))
R3 = pd.DataFrame(rows3); R3.to_csv('/tmp/work/out_postvax_weight.csv', index=False)
print('\nS08-D post-vaccination weight:'); print(R3.to_string(float_format=lambda v: f'{v:.3g}'))

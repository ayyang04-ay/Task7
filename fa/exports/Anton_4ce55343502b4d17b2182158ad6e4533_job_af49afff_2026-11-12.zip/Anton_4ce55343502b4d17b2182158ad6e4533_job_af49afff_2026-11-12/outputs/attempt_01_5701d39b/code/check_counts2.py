import pandas as pd
m = pd.read_csv('tidy/measurements.csv'); s = pd.read_csv('tidy/survival.csv')
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500)
c = m.groupby(['block','sub','group'], dropna=False).size().reset_index(name='n')
# compact: per block, list group:n
for (blk, sub), d in c.groupby(['block','sub'], dropna=False):
    print(f'{blk:28s} {str(sub):10s} ' + ', '.join(f'{g}:{n}' for g,n in zip(d.group, d.n)))
print()
ss = s.groupby(['block','group'], sort=False).agg(n=('event','size'), deaths=('event','sum'), missing_time=('time', lambda x: x.isna().sum())).reset_index()
ss['survivors'] = ss.n - ss.deaths
print(ss.to_string())

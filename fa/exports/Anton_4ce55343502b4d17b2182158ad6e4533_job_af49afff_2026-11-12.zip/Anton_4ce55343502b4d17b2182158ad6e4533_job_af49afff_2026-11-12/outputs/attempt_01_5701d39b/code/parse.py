"""
Parse adjuvant_program_dataset.xlsx into tidy tables with cell-level provenance.

Every value carries: sheet, block, group (as printed), sub (timepoint / analyte / panel),
animal index within group (column order as printed), value, and the Excel cell coordinate.
Layouts were hand-mapped from a full cell dump of the workbook and the annotation PDF.
"""
import openpyxl
import pandas as pd
from openpyxl.utils import column_index_from_string as ci, get_column_letter as cl

XLSX = '/tmp/world/filesystem/adjuvant_program_dataset.xlsx'
wb = openpyxl.load_workbook(XLSX, data_only=True)

rows_out = []      # continuous per-animal measurements
surv_out = []      # time-to-event
bw_out = []        # body weight trajectories


def v(ws, col, row):
    return ws[f'{col}{row}'].value


def add(sheet, block, group, sub, idx, val, cell):
    rows_out.append(dict(sheet=sheet, block=block, group=group, sub=sub, idx=idx,
                         value=val, cell=f'{sheet}!{cell}'))


def grid_rows(sheet, block, label_col, first_val_col, last_val_col, r0, r1, sub=None):
    """groups in rows: label in label_col, values across columns"""
    ws = wb[sheet]
    for r in range(r0, r1 + 1):
        g = v(ws, label_col, r)
        for k, c in enumerate(range(ci(first_val_col), ci(last_val_col) + 1)):
            x = v(ws, cl(c), r)
            if x is None:
                continue
            add(sheet, block, str(g).strip(), sub, k + 1, float(x), f'{cl(c)}{r}')


def grid_cols(sheet, block, header_row, cols, r0, r1, sub=None, groups=None):
    """groups in columns: header in header_row, values down rows r0..r1"""
    ws = wb[sheet]
    for j, c in enumerate(cols):
        g = groups[j] if groups else str(v(ws, c, header_row)).strip()
        k = 0
        for r in range(r0, r1 + 1):
            x = v(ws, c, r)
            if x is None:
                continue
            k += 1
            add(sheet, block, g, sub, k, float(x), f'{c}{r}')


def grid_timecourse(sheet, block, time_col, r0, r1, group_spans, time_map=None):
    """rows = timepoints; each group spans a contiguous set of columns (one per animal)"""
    ws = wb[sheet]
    for r in range(r0, r1 + 1):
        t = v(ws, time_col, r)
        t = time_map[r] if time_map else t
        for g, (c0, c1) in group_spans.items():
            for k, c in enumerate(range(ci(c0), ci(c1) + 1)):
                x = v(ws, cl(c), r)
                if x is None:
                    continue
                add(sheet, block, g, str(t).strip(), k + 1, float(x), f'{cl(c)}{r}')


def survival(sheet, block, time_col, status_cols, r0, r1, groups=None):
    ws = wb[sheet]
    for j, c in enumerate(status_cols):
        g = groups[j] if groups else None
        k = 0
        for r in range(r0, r1 + 1):
            s = v(ws, c, r)
            if s is None:
                continue
            k += 1
            t = v(ws, time_col, r)
            surv_out.append(dict(sheet=sheet, block=block, group=g, idx=k,
                                 time=(float(t) if t is not None else None), event=int(s),
                                 cell_time=f'{sheet}!{time_col}{r}', cell_status=f'{sheet}!{c}{r}'))


def bodyweight(sheet, block, day_col, r0, r1, group_spans):
    ws = wb[sheet]
    for r in range(r0, r1 + 1):
        d = v(ws, day_col, r)
        for g, (c0, c1) in group_spans.items():
            for k, c in enumerate(range(ci(c0), ci(c1) + 1)):
                x = v(ws, cl(c), r)
                bw_out.append(dict(sheet=sheet, block=block, group=g, idx=k + 1, day=int(d),
                                   value=(float(x) if x is not None else None),
                                   cell=f'{sheet}!{cl(c)}{r}'))


# ---------------- S01 ----------------
grid_rows('S01', 'S01-A', 'A', 'B', 'F', 3, 10, sub='16h')
grid_rows('S01', 'S01-A', 'G', 'H', 'L', 3, 10, sub='72h')
grid_rows('S01', 'S01-B', 'A', 'B', 'F', 14, 17)
grid_rows('S01', 'S01-C', 'A', 'B', 'E', 20, 21)
grid_timecourse('S01', 'S01-D', 'A', 24, 28, {'Sham': ('B', 'F'), 'PSLN-212': ('G', 'K'),
                                              'PSLN-344': ('L', 'P'), 'PSLN-212(Y)': ('Q', 'U')})
five = {'Sham': ('B', 'F'), 'PSLN-212': ('G', 'K'), 'PSLN-344': ('L', 'P'),
        'PSLN-212(Y)': ('Q', 'U'), 'PSLN-344(Y)': ('V', 'Z')}
grid_timecourse('S01', 'S01-E', 'A', 30, 34, five)
grid_timecourse('S01', 'S01-F', 'A', 36, 36, five, time_map={36: '72h'})
grid_timecourse('S01', 'S01-G', 'A', 38, 38, five, time_map={38: '72h'})

# ---------------- S02 ----------------
grid_cols('S02', 'S02-A', 2, list('ABCD'), 3, 7)
grid_cols('S02', 'S02-B', 2, list('FGHI'), 3, 7)
grid_cols('S02', 'S02-C', 2, list('KLMNO'), 3, 7)
grid_cols('S02', 'S02-D CD40', 9, list('ABCD'), 10, 14)
grid_cols('S02', 'S02-D CD86', 9, list('FGHI'), 10, 14)
grid_cols('S02', 'S02-E', 9, list('KLMNO'), 10, 14)
grid_timecourse('S02', 'S02-F', 'A', 17, 19, {'PSLN-344': ('B', 'F'), 'PSLN-212': ('G', 'K'),
                                              'Sham': ('L', 'P')})
grid_cols('S02', 'S02-G', 21, list('BCD'), 22, 26)
grid_cols('S02', 'S02-H', 29, list('BCDEF'), 30, 34)
grid_cols('S02', 'S02-I', 29, list('HI'), 30, 34)

# ---------------- S03 ----------------
grid_cols('S03', 'S03-A', 2, list('ABCDE'), 3, 7)
grid_cols('S03', 'S03-B', 2, list('GHI'), 3, 7)
grid_cols('S03', 'S03-C', 2, list('KLMNO'), 3, 7)
grid_cols('S03', 'S03-D', 2, list('QRSTU'), 3, 7)
grid_cols('S03', 'S03-E', 9, list('ABCDE'), 10, 14)
grid_cols('S03', 'S03-F', 9, list('GHI'), 10, 14)
grid_cols('S03', 'S03-G', 9, list('KLMNO'), 10, 14)
grid_cols('S03', 'S03-H', 9, list('QRSTU'), 10, 14)
survival('S03', 'S03-I', 'A', list('BCDEF'), 17, 51,
         groups=['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)'])
survival('S03', 'S03-J', 'G', list('HIJ'), 17, 46, groups=['Sham', 'PSLN-212', 'PSLN-344'])
grid_cols('S03', 'S03-K', 16, list('LMNO'), 17, 21)
grid_rows('S03', 'S03-L', 'K', 'L', 'N', 26, 28, sub='Aicda')
grid_rows('S03', 'S03-L', 'K', 'O', 'Q', 26, 28, sub='E47')

# ---------------- S04 ----------------
grid_rows('S04', 'S04-A', 'A', 'B', 'F', 2, 5, sub='ICOS-low')
grid_rows('S04', 'S04-A', 'A', 'G', 'K', 2, 5, sub='ICOS-high')
grid_cols('S04', 'S04-B Foxp3', 7, list('ABCD'), 8, 12)
grid_cols('S04', 'S04-B TfhTfr', 14, list('ABCD'), 15, 19)
grid_cols('S04', 'S04-C', 21, list('ABCD'), 22, 26)
grid_cols('S04', 'S04-D', 28, list('ABCD'), 29, 31)

# ---------------- S05 ----------------
grid_timecourse('S05', 'S05-A', 'A', 3, 5, {'PSLN-212': ('B', 'C'), 'PSLN-344': ('E', 'F'),
                                            'PSLN-212Y': ('H', 'I')})
grid_timecourse('S05', 'S05-B', 'A', 8, 10, {'PSLN-212': ('B', 'C'), 'PSLN-344': ('E', 'F'),
                                             'PSLN-212Y': ('H', 'I')})
grid_cols('S05', 'S05-C', 12, list('ABCD'), 13, 15)
for blk, hr in [('S05-D', 18), ('S05-E', 25), ('S05-F', 32), ('S05-G', 39), ('S05-H', 46), ('S05-I', 53)]:
    grid_cols('S05', blk, hr, list('ABCD'), hr + 1, hr + 5)

# ---------------- S06 (survival) ----------------
g4 = ['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']
g5 = g4 + ['Untreated']
gi = ['Naive+PSLN-212', 'Imprinting+PSLN-212', 'Naive+PSLN-344', 'Imprinting+PSLN-344']
survival('S06', 'S06-A', 'A', list('BCDE'), 3, 30, groups=g4)
survival('S06', 'S06-B', 'G', list('HIJK'), 3, 30, groups=g4)
survival('S06', 'S06-C', 'M', list('NOPQ'), 3, 30, groups=g4)
survival('S06', 'S06-D', 'A', list('BCDE'), 34, 68, groups=g4)
survival('S06', 'S06-E', 'G', list('HIJKL'), 34, 68, groups=g5)
survival('S06', 'S06-F', 'M', list('NOPQR'), 34, 68, groups=g5)
survival('S06', 'S06-G', 'A', list('BCDEF'), 71, 105, groups=g5)
survival('S06', 'S06-E(imprint)', 'G', list('HIJK'), 71, 105, groups=gi)
survival('S06', 'S06-F(imprint)', 'M', list('NOPQ'), 71, 105, groups=gi)

# ---------------- S07 ----------------
grid_timecourse('S07', 'S07-A', 'A', 3, 7, {'PSLN-212': ('B', 'D'), 'PSLN-344': ('E', 'G')})
grid_cols('S07', 'S07-B', 9, list('BC'), 10, 14, sub='Monocytes')
grid_cols('S07', 'S07-B', 9, list('EF'), 10, 14, sub='Ly6C+ Mphi')
grid_cols('S07', 'S07-C', 15, list('BC'), 16, 20, groups=['col B "Ly6C-CD206+ MPhi"', 'col C "Ly6C-CD206+ MPhi"'])

# ---------------- S08 ----------------
grid_timecourse('S08', 'S08-A', 'A', 3, 7, {'CMP-204': ('B', 'D'), 'PSLN-212': ('E', 'G'),
                                            'PSLN-344': ('H', 'J'), 'PSLN-344/R848': ('K', 'M')})
ws = wb['S08']
for g, (c0, c1) in {'CMP-204': ('A', 'C'), 'PSLN-212': ('D', 'F'), 'PSLN-R848': ('G', 'I'),
                    'PSLN-212/R848': ('J', 'L'), 'PSLN-344': ('M', 'O')}.items():
    for k, c in enumerate(range(ci(c0), ci(c1) + 1)):
        add('S08', 'S08-B', g, None, k + 1, float(v(ws, cl(c), 11)), f'{cl(c)}11')
grid_cols('S08', 'S08-C', 13, list('ABCD'), 14, 18)
bodyweight('S08', 'S08-D', 'A', 21, 26, {'PSLN-212(Y)': ('B', 'F'), 'CMP-204': ('G', 'K'),
                                         'PSLN-212': ('L', 'P'), 'PSLN-344': ('Q', 'U'),
                                         'PSLN-212/R848': ('V', 'Z'), 'Vaccine': ('AA', 'AE')})
survival('S08', 'S08-orphan(rows89-101)', 'A', list('CD'), 89, 101, groups=['col C (unlabelled)', 'col D (unlabelled)'])

# ---------------- S09 ----------------
ws = wb['S09']
spans1 = {'PBS': ('B', 'D'), 'CMP-204': ('E', 'G'), 'PSLN-212': ('H', 'J'), 'PSLN-R848': ('K', 'M'),
          'PSLN-212/R848': ('N', 'P'), 'PSLN-344': ('Q', 'S'), 'PSLN-212(y)': ('T', 'V')}
spans2 = {'PBS': ('Y', 'AA'), 'CMP-204': ('AB', 'AD'), 'PSLN-212': ('AE', 'AG'), 'PSLN-R848': ('AH', 'AJ'),
          'PSLN-212/R848': ('AK', 'AM'), 'PSLN-344': ('AN', 'AP'), 'PSLN-212(y)': ('AQ', 'AS')}
for r in range(3, 10):
    an1 = v(ws, 'A', r); an2 = v(ws, 'X', r)
    for g, (c0, c1) in spans1.items():
        for k, c in enumerate(range(ci(c0), ci(c1) + 1)):
            add('S09', 'S09-A panel1 (cols A-V)', g, an1, k + 1, float(v(ws, cl(c), r)), f'{cl(c)}{r}')
    for g, (c0, c1) in spans2.items():
        for k, c in enumerate(range(ci(c0), ci(c1) + 1)):
            add('S09', 'S09-A panel2 (cols X-AS)', g, an2, k + 1, float(v(ws, cl(c), r)), f'{cl(c)}{r}')
survival('S09', 'S09-B', 'A', list('BCD'), 12, 35, groups=['Sham', 'PSLN-344Y', 'PSLN-212Y'])
bodyweight('S09', 'S09-C', 'F', 12, 19, {'PSLN-212Y': ('G', 'N'), 'Sham': ('O', 'V'), 'PSLN-344Y': ('W', 'AD')})
survival('S09', 'S09-D', 'A', list('BCD'), 39, 62, groups=['Sham', 'PSLN-344Y', 'PSLN-212Y'])
bodyweight('S09', 'S09-E', 'F', 39, 46, {'PSLN-212Y': ('G', 'N'), 'Sham': ('O', 'V'), 'PSLN-344Y': ('W', 'AD')})
survival('S09', 'S09-F', 'A', list('BCD'), 66, 88, groups=['Sham', 'PSLN-344Y', 'PSLN-212Y'])
bodyweight('S09', 'S09-G', 'F', 66, 73, {'PSLN-212Y': ('G', 'N'), 'Sham': ('O', 'V'), 'PSLN-344Y': ('W', 'AD')})

# ---------------- S10 ----------------
grid_cols('S10', 'S10-A', 2, list('ABCD'), 3, 7, sub='Ifnb1')
grid_cols('S10', 'S10-A', 2, list('FGHI'), 3, 7, sub='Tnf')
grid_cols('S10', 'S10-A', 2, list('KLMN'), 3, 7, sub='Isg15')

# ---------------- S11 ----------------
four = {'Vaccine': ('B', 'F'), 'PSLN-212': ('G', 'K'), 'PSLN-344': ('L', 'P'), 'PSLN-212(Y)': ('Q', 'U')}
grid_timecourse('S11', 'S11-A', 'A', 3, 7, four)
grid_timecourse('S11', 'S11-B', 'A', 10, 14, four)
grid_cols('S11', 'S11-C', 16, list('AB'), 17, 21)
grid_timecourse('S11', 'S11-D', 'A', 24, 28, four)
grid_cols('S11', 'S11-E', 30, list('ABCD'), 31, 35)

# ---------------- S12 ----------------
grid_cols('S12', 'S12-A', 2, list('AB'), 3, 5)

# ---------------- S13 ----------------
grid_cols('S13', 'S13-A', 2, list('ABC'), 3, 7)
grid_cols('S13', 'S13-B', 2, list('EFG'), 3, 7)
grid_cols('S13', 'S13-C', 2, list('IJK'), 3, 7)
grid_cols('S13', 'S13-D', 2, list('MNO'), 3, 7)
survival('S13', 'S13-E', 'R', list('STUV'), 3, 30, groups=['Naive', 'Sham', 'CMP-204(Y)', 'PSLN-344(Y)'])
bodyweight('S13', 'S13-F', 'A', 33, 40, {'PSLN-212(Y)': ('B', 'H'), 'Sham': ('I', 'O'), 'PSLN-212': ('P', 'V'),
                                         'PSLN-344': ('W', 'AC'), 'Naive': ('AD', 'AJ')})
bodyweight('S13', 'S13-G', 'A', 43, 50, {'PSLN-344': ('B', 'K'), 'Sham': ('L', 'U'), 'Naive': ('V', 'AE')})
grid_cols('S13', 'S13-H', 52, list('ABCD'), 53, 57)
grid_cols('S13', 'S13-I', 52, list('FGHIJ'), 53, 57)
grid_cols('S13', 'S13-J', 52, list('LMNOP'), 53, 57)

# ---------------- S14 ----------------
grid_cols('S14', 'S14-A H1N1', 2, list('ABCD'), 3, 7)
grid_cols('S14', 'S14-A H3N2', 2, list('FGHI'), 3, 7)

# ---------------- S15 ----------------
std4 = {'PSLN-212(Y)': ('B', 'H'), 'Sham': ('I', 'O'), 'PSLN-212': ('P', 'V'), 'PSLN-344': ('W', 'AC')}
std5 = dict(std4, **{'Untreated': ('AD', 'AJ')})
bodyweight('S15', 'S15-A', 'A', 3, 10, std4)
bodyweight('S15', 'S15-B', 'A', 13, 20, std4)
bodyweight('S15', 'S15-C', 'A', 23, 30, std4)
bodyweight('S15', 'S15-D', 'A', 33, 40, std4)
bodyweight('S15', 'S15-E', 'A', 43, 50, std5)
bodyweight('S15', 'S15-F', 'A', 53, 60, std5)
bodyweight('S15', 'S15-G', 'A', 63, 70, std5)
survival('S15', 'S15-H', 'A', list('BCD'), 73, 99, groups=['3d Vaccine', '3d PSLN-344', '3d Vaccine+PSLN-344'])
bodyweight('S15', 'S15-I', 'H', 72, 79, {'3d Vaccine': ('I', 'O'), '3d PSLN-344': ('P', 'V'),
                                         '3d Vaccine+PSLN-344': ('W', 'AC')})
imp = {'Naive+PSLN-212': ('I', 'O'), 'Imprinting+PSLN-212': ('P', 'V'), 'Naive+PSLN-344': ('W', 'AC'),
       'Imprinting+PSLN-344': ('AD', 'AJ')}
bodyweight('S15', 'S15-J', 'H', 83, 90, imp)
bodyweight('S15', 'S15-K', 'H', 93, 100, imp)
survival('S15', 'S15-L', 'A', list('BCDE'), 103, 130, groups=g4)
alt4 = {'PSLN-212(Y)': ('I', 'O'), 'Sham': ('P', 'V'), 'PSLN-212': ('W', 'AC'), 'PSLN-344': ('AD', 'AJ')}
bodyweight('S15', 'S15-M', 'H', 103, 110, alt4)
survival('S15', 'S15-N', 'A', list('BCDE'), 134, 161, groups=g4)
bodyweight('S15', 'S15-O', 'H', 134, 141, alt4)

meas = pd.DataFrame(rows_out)
surv = pd.DataFrame(surv_out)
bw = pd.DataFrame(bw_out)

if __name__ == '__main__':
    import os
    os.makedirs('/tmp/work/tidy', exist_ok=True)
    meas.to_csv('/tmp/work/tidy/measurements.csv', index=False)
    surv.to_csv('/tmp/work/tidy/survival.csv', index=False)
    bw.to_csv('/tmp/work/tidy/bodyweight.csv', index=False)
    print(meas.shape, surv.shape, bw.shape)
    print(meas.groupby(['block']).size().to_string())

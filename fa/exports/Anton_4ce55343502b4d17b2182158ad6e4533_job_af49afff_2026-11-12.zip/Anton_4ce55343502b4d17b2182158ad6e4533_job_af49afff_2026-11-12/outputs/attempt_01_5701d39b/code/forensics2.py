import pandas as pd, numpy as np, itertools
pd.set_option('display.width', 250); pd.set_option('display.max_rows', 500); pd.set_option('display.max_colwidth', 120)
m = pd.read_csv('tidy/measurements.csv')
m['sub'] = m['sub'].astype(str)
vec = {k: d.sort_values('idx') for k, d in m.groupby(['block','sub','group'])}
print("=== positional matches between group vectors (same animal index, identical value), >=2 matches ===")
res=[]
keys=list(vec)
for a, c in itertools.combinations(keys, 2):
    da, dc = vec[a], vec[c]
    n = min(len(da), len(dc))
    va, vc = da.value.values[:n], dc.value.values[:n]
    eq = np.isclose(va, vc, rtol=0, atol=1e-9)
    if eq.sum() >= 2:
        res.append((eq.sum(), n, a, c, list(da.cell.values[:n][eq]), list(dc.cell.values[:n][eq])))
res.sort(key=lambda r: -r[0])
for r in res: print(r)

print("\n=== high-precision values (>=5 significant digits) appearing in >1 place ===")
def nsig(x):
    s = ('%.10g' % abs(x)).replace('.', '').lstrip('0')
    return len(s)
m['nsig'] = m.value.map(nsig)
hp = m[m.nsig>=5].copy(); hp['k']=hp.value.round(8)
for k, d in hp.groupby('k'):
    if len(d)>1: print(k, list(zip(d.cell, d.block, d['sub'], d.group)))

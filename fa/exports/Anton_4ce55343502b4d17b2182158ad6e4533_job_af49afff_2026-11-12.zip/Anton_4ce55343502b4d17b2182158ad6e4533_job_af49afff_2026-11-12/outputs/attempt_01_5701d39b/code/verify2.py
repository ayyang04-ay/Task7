import pandas as pd, numpy as np
m = pd.read_csv('tidy/measurements.csv'); m['sub']=m['sub'].astype(str)
d = m[m.block.str.startswith('S09-A')]
q = d.value/np.log10(2)   # = -ddCt
resid = np.abs(q*100 - np.round(q*100))
print('S09-A values consistent with ddCt quantised to 0.01 cycles:', (resid<0.02).sum(), 'of', len(d))
print('non-conforming examples:', d[resid>=0.02][['cell','value']].head(10).to_string())
def vec(block, group, sub='nan'):
    x = m[(m.block==block)&(m.group==group)&(m['sub']==sub)].sort_values('idx'); return x.value.values
print()
for rblk, a2, a1 in [('S03-B','S13-A','S13-B'), ('S03-F','S13-C','S13-D')]:
    for g in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
        r = vec(a2,g)/vec(a1,g)
        for gr in ['PSLN-212','PSLN-344','PSLN-212(Y)']:
            rv = vec(rblk, gr)
            if np.allclose(r, rv, rtol=1e-4):
                print(f'{a2}/{a1} true group {g:12s} ratios={np.round(r,3)} -> appears in {rblk} under printed label "{gr}"')

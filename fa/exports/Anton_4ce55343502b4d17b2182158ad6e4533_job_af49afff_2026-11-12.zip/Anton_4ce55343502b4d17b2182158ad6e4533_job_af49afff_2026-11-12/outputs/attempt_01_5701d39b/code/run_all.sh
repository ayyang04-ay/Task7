#!/usr/bin/env bash
# Reproduces every table, figure and ledger entry from the workbook.
# Expects: workbook at /tmp/world/filesystem/adjuvant_program_dataset.xlsx
# Python env with pandas, numpy, scipy, statsmodels, matplotlib, openpyxl (here: `micromamba run -n singlecell`).
set -euo pipefail
PY="${PY:-micromamba run -n singlecell python}"
mkdir -p /tmp/work/tidy /tmp/outputs/figures /tmp/outputs/tables
cp "$(dirname "$0")"/*.py /tmp/work/
cd /tmp/work
$PY parse.py                 # tidy tables with cell-level provenance
$PY check_counts2.py         # observations per group vs annotation
$PY forensics1.py; $PY forensics2.py; $PY forensics3.py   # duplicate / shared-value screens
$PY forensics4.py; $PY forensics5.py; $PY forensics6.py   # body-weight trajectory copy map + permutation null
$PY verify_labels.py; $PY verify2.py; $PY verify3.py       # S09-A timepoint, S03-B/F label rotation, Tfh:Tfr derivation
$PY reconcile.py             # survival vs body-weight reconciliation
$PY analysis.py              # core contrasts + restoration index
$PY survival.py              # per-block and tiered pooled survival
$PY mechanism_safety.py      # mechanistic, early panel, CNS, post-vaccination weight
$PY emax2.py                 # sigmoid Emax dose-response
$PY extra.py                 # HA/NA-match split, power
$PY figures.py               # figures 1-6
$PY ledger.py                # numbers_ledger.csv
$PY integrity_log.py         # data_integrity_log.csv

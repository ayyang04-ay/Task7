import pandas as pd, numpy as np, itertools
rng = np.random.default_rng(1)
b = pd.read_csv('tidy/bodyweight.csv'); b = b[b.day>0]
b['traj'] = b.block + '|' + b.group + '|#' + b.idx.astype(str)
T = b.pivot_table(index='traj', columns='day', values='value', aggfunc='first')
blk = np.array([t.split('|')[0] for t in T.index])
A = T.values
# per-day empirical chance that two trajectories from DIFFERENT blocks share an identical value (excluding frozen repeats handled by distinct count)
# Null model: permute trajectories' values within each day independently across trajectories (breaks within-trajectory linkage),
# then count cross-block pairs with >=4 distinct identical values.
def count_pairs(M):
    n = M.shape[0]; cnt4 = 0; cnt5=0
    for i in range(n):
        a = M[i]
        same = np.isclose(M[i+1:], a, atol=1e-6) & ~np.isnan(M[i+1:]) & ~np.isnan(a)
        for k, row in enumerate(same):
            j = i+1+k
            if blk[i]==blk[j] or row.sum()<4: continue
            d = len(set(np.round(a[row],6)))
            cnt4 += d>=4; cnt5 += d>=5
    return cnt4, cnt5
obs = count_pairs(A)
print('observed cross-block trajectory pairs with >=4 / >=5 distinct identical same-day values:', obs)
null=[]
for r in range(20):
    M = A.copy()
    for d in range(M.shape[1]):
        col = M[:, d]; idx = np.where(~np.isnan(col))[0]
        col[idx] = rng.permutation(col[idx]); M[:, d] = col
    null.append(count_pairs(M))
null = np.array(null)
print('null (within-day permutation, 20 reps): mean >=4:', null[:,0].mean(), 'max', null[:,0].max(), '| mean >=5:', null[:,1].mean(), 'max', null[:,1].max())

# high-precision fractional collision expectation
import openpyxl
wb = openpyxl.load_workbook('/tmp/world/filesystem/adjuvant_program_dataset.xlsx', data_only=True)
b2 = pd.read_csv('tidy/bodyweight.csv'); b2 = b2[(b2.day>0)&b2.value.notna()]
def ndec(cell):
    sh,c = cell.split('!'); x = wb[sh][c].value; s = repr(float(x))
    return len(s.split('.')[1]) if '.' in s else 0
b2['ndec'] = b2.cell.map(ndec)
hp = b2[b2.ndec>=4]
fr = np.round(hp.value - np.floor(hp.value), 5)
n = len(hp); pairs = n*(n-1)/2
obs_pairs = sum(c*(c-1)/2 for c in fr.value_counts().values)
print(f'high-precision values: {n}; pairs: {pairs:.0f}; expected chance 5-dp fractional collisions (uniform 1e5 bins): {pairs/1e5:.2f}; observed colliding pairs: {obs_pairs:.0f}')

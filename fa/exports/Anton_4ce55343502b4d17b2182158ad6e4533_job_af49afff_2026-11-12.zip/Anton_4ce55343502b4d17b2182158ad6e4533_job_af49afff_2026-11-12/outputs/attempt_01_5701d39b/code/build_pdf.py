"""Render the decision memo (Markdown subset) to PDF with reportlab; figures appended with captions."""
import re, os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.platypus import (BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer, Table, TableStyle,
                                Image, PageBreak, KeepTogether, ListFlowable, ListItem, HRFlowable)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping

FD = '/opt/conda/envs/core/lib/python3.11/site-packages/matplotlib/mpl-data/fonts/ttf/'
pdfmetrics.registerFont(TTFont('DV', FD + 'DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('DV-B', FD + 'DejaVuSans-Bold.ttf'))
pdfmetrics.registerFont(TTFont('DV-I', FD + 'DejaVuSans-Oblique.ttf'))
pdfmetrics.registerFont(TTFont('DV-BI', FD + 'DejaVuSans-BoldOblique.ttf'))
pdfmetrics.registerFont(TTFont('DVM', FD + 'DejaVuSansMono.ttf'))
addMapping('DV', 0, 0, 'DV'); addMapping('DV', 1, 0, 'DV-B'); addMapping('DV', 0, 1, 'DV-I'); addMapping('DV', 1, 1, 'DV-BI')

OUT = '/tmp/outputs'
SRC = f'{OUT}/PSLN-344_portfolio_decision_memo.md'
PDF = f'{OUT}/PSLN-344_portfolio_decision_memo.pdf'

base = ParagraphStyle('b', fontName='DV', fontSize=8.6, leading=11.4, spaceAfter=4, alignment=TA_LEFT)
st = {
    'h1': ParagraphStyle('h1', parent=base, fontName='DV-B', fontSize=15, leading=19, spaceAfter=8, textColor=colors.HexColor('#1f3b63')),
    'h2': ParagraphStyle('h2', parent=base, fontName='DV-B', fontSize=11.5, leading=15, spaceBefore=8, spaceAfter=5, textColor=colors.HexColor('#1f3b63')),
    'h3': ParagraphStyle('h3', parent=base, fontName='DV-B', fontSize=9.6, leading=13, spaceBefore=6, spaceAfter=3, textColor=colors.HexColor('#2c5282')),
    'p': base,
    'li': ParagraphStyle('li', parent=base, spaceAfter=2),
    'cell': ParagraphStyle('cell', parent=base, fontSize=6.7, leading=8.3, spaceAfter=0),
    'cellh': ParagraphStyle('cellh', parent=base, fontName='DV-B', fontSize=6.7, leading=8.3, spaceAfter=0, textColor=colors.white),
    'cap': ParagraphStyle('cap', parent=base, fontSize=7.6, leading=9.6, textColor=colors.HexColor('#333333')),
}


def inline(t):
    t = t.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
    t = re.sub(r'`([^`]+)`', r'<font face="DVM">\1</font>', t)
    t = re.sub(r'\*\*([^*]+)\*\*', r'<b>\1</b>', t)
    t = re.sub(r'(?<![\w*])\*([^*\n]+)\*(?![\w*])', r'<i>\1</i>', t)
    return t


def table_flow(lines, width):
    rows = [[c.strip() for c in l.strip().strip('|').split('|')] for l in lines]
    rows = [r for i, r in enumerate(rows) if not (i == 1 and all(set(c) <= set('-: ') for c in r))]
    ncol = max(len(r) for r in rows)
    data = []
    for i, r in enumerate(rows):
        r = r + [''] * (ncol - len(r))
        data.append([Paragraph(inline(c), st['cellh'] if i == 0 else st['cell']) for c in r])
    # column widths: proportional to max text length, bounded
    lens = [max(len(re.sub(r'[*`]', '', rows[i][j])) if j < len(rows[i]) else 0 for i in range(len(rows))) for j in range(ncol)]
    lens = [min(max(l, 6), 70) for l in lens]
    tot = sum(lens); cw = [width * l / tot for l in lens]
    t = Table(data, colWidths=cw, repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2c5282')),
                           ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                           ('GRID', (0, 0), (-1, -1), 0.3, colors.HexColor('#b0b8c4')),
                           ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f2f5f9')]),
                           ('LEFTPADDING', (0, 0), (-1, -1), 3), ('RIGHTPADDING', (0, 0), (-1, -1), 3),
                           ('TOPPADDING', (0, 0), (-1, -1), 2), ('BOTTOMPADDING', (0, 0), (-1, -1), 2)]))
    return t


def build():
    md = open(SRC, encoding='utf-8').read().split('\n')
    W = A4[0] - 30 * mm
    story = []
    i = 0
    para = []

    def flush():
        nonlocal para
        if para:
            story.append(Paragraph(inline(' '.join(para)), st['p'])); para = []

    while i < len(md):
        l = md[i]
        if l.startswith('# '):
            flush(); story.append(Paragraph(inline(l[2:]), st['h1']))
        elif l.startswith('## '):
            flush(); story.append(Paragraph(inline(l[3:]), st['h2']))
        elif l.startswith('### '):
            flush(); story.append(Paragraph(inline(l[4:]), st['h3']))
        elif l.strip() == '---':
            flush(); story.append(HRFlowable(width='100%', thickness=0.6, color=colors.HexColor('#9aa5b1'), spaceBefore=4, spaceAfter=6))
        elif l.startswith('|'):
            flush(); tl = []
            while i < len(md) and md[i].startswith('|'):
                tl.append(md[i]); i += 1
            story.append(table_flow(tl, W)); story.append(Spacer(1, 5)); continue
        elif re.match(r'^\s*(- |\d+\. )', l):
            flush(); items = []
            while i < len(md) and re.match(r'^\s*(- |\d+\. )', md[i]):
                indent = len(md[i]) - len(md[i].lstrip())
                txt = re.sub(r'^\s*(- |\d+\. )', '', md[i])
                num = re.match(r'^\s*(\d+)\. ', md[i])
                i += 1
                # continuation lines
                while i < len(md) and md[i].strip() and not re.match(r'^\s*(- |\d+\. |\||#)', md[i]):
                    txt += ' ' + md[i].strip(); i += 1
                items.append((indent, num.group(1) if num else None, txt))
            for indent, num, txt in items:
                bullet = f'{num}.' if num else ('•' if indent == 0 else '–')
                story.append(Paragraph(inline(txt), ParagraphStyle('li2', parent=st['li'], leftIndent=10 + indent * 5,
                                                                   bulletIndent=2 + indent * 5), bulletText=bullet))
            continue
        elif l.strip() == '':
            flush()
        else:
            para.append(l.strip())
        i += 1
    flush()
    # figures appendix
    story.append(PageBreak())
    story.append(Paragraph('Appendix C: figures', st['h2']))
    caps = [
        ('fig1_restoration_profile.png', 'Fig. 1. Restoration index per readout (aged PSLN-344 relative to aged PSLN-212 = 0 and young PSLN-212 = 1), with 95% bootstrap CIs; the black diamond is survival in the concordant challenge blocks. Source: restoration_index.csv; ledger L36, L43.'),
        ('fig2_survival_grid.png', 'Fig. 2. Kaplan-Meier survival after lethal challenge as recorded, with integrity tier badge. Source: survival_by_group.csv; ledger L40-*.'),
        ('fig3_pooled_survival_and_match.png', 'Fig. 3. A: pooled PSLN-344 vs PSLN-212 survival by integrity tier (L41). B: survival by HA/NA match between vaccine and challenge virus (L42).'),
        ('fig4_integrity_evidence.png', 'Fig. 4. Integrity evidence drawn directly from workbook cells: A S06-C vs S06-D; B and C copied body-weight trajectories; D S03-B labels vs S13 subclass titres; E S09-A panel 2 = 72 h; F S11-A vs S11-B.'),
        ('fig5_mechanism.png', 'Fig. 5. A: Ifnb1 dose-response with sigmoid Emax fits (L03). B: lung transcript panel at 16 h and 72 h (L04). C: tested dependencies (L12-L18); none was tested against survival.'),
        ('fig6_immunogenicity.png', 'Fig. 6. Representative adaptive readouts (per-animal points; bar = GM for titres, mean for %). HAI values below 1:10 plotted at 5.'),
    ]
    from reportlab.lib.utils import ImageReader
    for fn, cap in caps:
        p = f'{OUT}/figures/{fn}'
        ir = ImageReader(p); iw, ih = ir.getSize()
        w = W; h = w * ih / iw
        maxh = 200 * mm
        if h > maxh:
            h = maxh; w = h * iw / ih
        story.append(KeepTogether([Image(p, width=w, height=h), Spacer(1, 3), Paragraph(cap, st['cap']), Spacer(1, 10)]))

    def on_page(c, doc):
        c.saveState(); c.setFont('DV', 7); c.setFillColor(colors.HexColor('#666666'))
        c.drawString(15 * mm, 10 * mm, 'PSLN-344 portfolio review - decision memo (all numbers trace to numbers_ledger.csv)')
        c.drawRightString(A4[0] - 15 * mm, 10 * mm, f'page {doc.page}'); c.restoreState()

    doc = BaseDocTemplate(PDF, pagesize=A4, leftMargin=15 * mm, rightMargin=15 * mm, topMargin=14 * mm, bottomMargin=16 * mm,
                          title='PSLN-344 portfolio review decision memo', author='Portfolio review analysis')
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height, id='f')
    doc.addPageTemplates([PageTemplate(id='p', frames=[frame], onPage=on_page)])
    doc.build(story)
    print('written', PDF)


if __name__ == '__main__':
    build()

import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import os
OUT = '/tmp/outputs/figures'; os.makedirs(OUT, exist_ok=True)
plt.rcParams.update({'font.size': 8.5, 'axes.spines.top': False, 'axes.spines.right': False, 'figure.dpi': 150,
                     'font.family': 'DejaVu Sans'})
COL = {'Sham': '#8c8c8c', 'CMP-204': '#b07aa1', 'PSLN-212': '#4c78a8', 'PSLN-344': '#e45756', 'PSLN-212(Y)': '#54a24b',
       'PSLN-344(Y)': '#1b7837', 'Untreated': '#000000', 'Naive': '#bab0ac', 'PSLN-212Y': '#54a24b', 'PSLN-344Y': '#1b7837'}
m = pd.read_csv('/tmp/work/tidy/measurements.csv'); m['sub'] = m['sub'].astype(str)
s = pd.read_csv('/tmp/work/tidy/survival.csv'); s.loc[(s.block == 'S03-J') & s.time.isna(), 'time'] = 21.0
bw = pd.read_csv('/tmp/work/tidy/bodyweight.csv')
Rz = pd.read_csv('/tmp/work/out_restoration.csv')
meta = pd.read_csv('/tmp/work/out_survival_meta.csv').set_index('block')

# ---------------- Figure 1: restoration profile
# survival restoration (pooled concordant blocks S06-A,B,F) with bootstrap over animals within block/arm
_r = np.random.default_rng(2)
def _arm(blocks, g):
    return [((s[(s.block == b) & (s.group == g)].event == 0).astype(int).values) for b in blocks]
_b = ['S06-A', 'S06-B', 'S06-F']
a344, a212, ay = _arm(_b, 'PSLN-344'), _arm(_b, 'PSLN-212'), _arm(_b, 'PSLN-212(Y)')
def _R(x344, x212, xy):
    p344 = np.concatenate(x344).mean(); p212 = np.concatenate(x212).mean(); py = np.concatenate(xy).mean()
    return (p344 - p212) / (py - p212) if py != p212 else np.nan
Rs = _R(a344, a212, ay)
bs = [_R([_r.choice(v, len(v)) for v in a344], [_r.choice(v, len(v)) for v in a212], [_r.choice(v, len(v)) for v in ay]) for _ in range(10000)]
Rs_lo, Rs_hi = np.nanpercentile(bs, [2.5, 97.5])
fig, ax = plt.subplots(figsize=(8.6, 8.8))
order = Rz.copy()
dom_order = {'Innate': 0, 'Humoral': 1, 'Cellular': 2}
order['d'] = order.domain.map(dom_order)
order = order.sort_values(['d', 'R'], ascending=[True, True]).reset_index(drop=True)
y = np.arange(len(order))[::-1]
for i, r in order.iterrows():
    c = {'Innate': '#4c78a8', 'Humoral': '#f58518', 'Cellular': '#54a24b'}[r.domain]
    ax.plot([r.R_lo, r.R_hi], [y[i], y[i]], color=c, lw=1.4)
    ax.plot(r.R, y[i], 'o', color=c, ms=4.5)
ytop = len(order) + 0.6
ax.plot([Rs_lo, Rs_hi], [ytop, ytop], color='k', lw=1.6); ax.plot(Rs, ytop, 'D', color='k', ms=6)
labels = [f"{r.readout}  [{r.block}]" for _, r in order.iterrows()]
ax.set_yticks(list(y) + [ytop]); ax.set_yticklabels(labels + ['SURVIVAL, pooled concordant challenges [S06-A,B,F]'], fontsize=6.8)
ax.get_yticklabels()[-1].set_fontweight('bold')
ax.axvline(0, color='#4c78a8', ls=':', lw=1); ax.axvline(1, color='#54a24b', ls=':', lw=1)
ax.set_xlabel('Restoration index R = (aged PSLN-344 - aged PSLN-212) / (young PSLN-212 - aged PSLN-212)\n'
              'log10 scale for titres/fold-changes, linear for %; 95% bootstrap CI (10,000 resamples of animals)', fontsize=7.5)
ax.set_xlim(-0.9, 1.75); ax.set_ylim(-1, ytop + 1.6)
ax.text(0, ytop + 1.0, 'R = 0: aged PSLN-212', ha='center', va='bottom', fontsize=7, color='#4c78a8')
ax.text(1, ytop + 1.0, 'R = 1: young PSLN-212', ha='center', va='bottom', fontsize=7, color='#54a24b')
ax.legend(handles=[Line2D([], [], color=c, marker='o', lw=1.4, label=l) for l, c in
                   [('Innate / antigen presentation', '#4c78a8'), ('Humoral / Tfh', '#f58518'), ('CD8 / Treg', '#54a24b')]]
          + [Line2D([], [], color='k', marker='D', lw=1.6, label='Survival')],
          loc='upper left', bbox_to_anchor=(0.0, -0.07), ncol=4, fontsize=7, frameon=False)
i72 = order.index[order.readout.str.contains('72 h')][0]
ax.annotate('Ifnb1 72 h: aged PSLN-344 stays 2.9x ABOVE young\n(R < 0 = prolonged signal, not restoration)',
            xy=(order.loc[i72, 'R'], y[i72]), xytext=(0.35, y[i72] + 0.2), fontsize=6.5, va='center',
            arrowprops=dict(arrowstyle='->', lw=0.6))
fig.suptitle('Fig. 1  How much of the age deficit does Mn close? Per-readout restoration index, aged PSLN-344 vs aged/young PSLN-212',
             fontsize=8.8, x=0.01, ha='left')
fig.tight_layout(rect=(0, 0.0, 1, 0.97)); fig.savefig(f'{OUT}/fig1_restoration_profile.png', dpi=200); plt.close(fig)
print('survival restoration R', Rs, Rs_lo, Rs_hi)

# ---------------- Figure 2: Kaplan-Meier grid
def km(t, e):
    t = np.asarray(t); e = np.asarray(e); times = np.unique(np.r_[0, t]); S = 1.0; xs, ys = [0], [1.0]
    for tt in np.unique(t[e == 1]):
        n = (t >= tt).sum(); d = ((t == tt) & (e == 1)).sum(); xs += [tt, tt]; ys += [S, S * (1 - d / n)]; S *= (1 - d / n)
    xs.append(max(t.max(), 14)); ys.append(S); return xs, ys

panels = [('S03-I', 'Homologous CA09, d14 (10x LD50)'), ('S03-J', 'wt VN04 H5N1, d2 (rgH5N1 vaccine)'),
          ('S06-A', 'H3N2 vacc -> PR8 H1N1, d14'), ('S06-B', 'H3N2 vacc -> PR8 H1N1, d3'),
          ('S06-C', 'Bivalent -> rgH5N1, d14'), ('S06-D', 'Bivalent -> rgH5N1, d3'),
          ('S06-E', 'H3N2 vacc -> PR8, d60'), ('S06-F', 'Bivalent -> rgH5N1, d60'),
          ('S06-G', 'H1N1 vacc -> Perth H3N2, d60'), ('S15-L', 'C57BL/6 aged (challenge not stated)'),
          ('S15-N', 'Swiss Webster aged (challenge not stated)'), ('S15-H', 'd3 rgH5N1: antigen requirement')]
tiercol = {'T3 clean': '#1a9850', 'T3-lenient': '#91cf60', 'flagged': '#fc8d59', 'excluded (duplicate)': '#d73027'}
fig, axes = plt.subplots(3, 4, figsize=(11, 7.6), sharey=True)
for ax, (blk, title) in zip(axes.flat, panels):
    d = s[s.block == blk]
    for g, dg in d.groupby('group', sort=False):
        xs, ys = km(dg.time, dg.event)
        c = COL.get(g, {'3d Vaccine': '#8c8c8c', '3d PSLN-344': '#b07aa1', '3d Vaccine+PSLN-344': '#e45756'}.get(g, 'k'))
        ls = '--' if g == 'Untreated' else '-'
        off = {'PSLN-344': 1.5, '3d Vaccine+PSLN-344': 1.5, 'PSLN-212(Y)': -1.5, 'Untreated': 0.0}.get(g, 0.0)
        ax.step(xs, np.array(ys) * 100 + off, where='post', color=c, lw=1.6 if 'PSLN-344' in g else 1.4, ls=ls,
                label=f"{g} ({(dg.event == 0).sum()}/{len(dg)})", zorder=3 if 'PSLN-344' in g else 2)
    tier = meta.loc[blk, 'tier'] if blk in meta.index else ''
    ax.set_title(f'{blk}: {title}', fontsize=7.6)
    ax.text(0.02, 0.03, tier, transform=ax.transAxes, fontsize=6.8, color='white',
            bbox=dict(boxstyle='round,pad=0.25', fc=tiercol.get(tier, 'grey'), ec='none'))
    ax.legend(fontsize=5.6, frameon=False, loc='center left', bbox_to_anchor=(0.0, 0.45))
    ax.set_xlim(0, 22 if blk == 'S03-J' else 14.5); ax.set_ylim(-3, 105)
for ax in axes[:, 0]: ax.set_ylabel('% surviving')
for ax in axes[-1, :]: ax.set_xlabel('days after challenge')
fig.suptitle('Fig. 2  Survival after lethal challenge in aged mice, as recorded (S03, S06, S15); n survived/n in legend; lines offset +/-1.5% where overlapping.\n'
             'Badge = integrity tier: dark green = concordant with own weight record, no copy flag; light green = concordant, shared trajectories; orange = flagged; red = duplicate of S06-C.', fontsize=7.6, x=0.01, ha='left')
fig.tight_layout(rect=(0, 0, 1, 0.95)); fig.savefig(f'{OUT}/fig2_survival_grid.png', dpi=200); plt.close(fig)

# ---------------- Figure 3: pooled survival by tier + HA/NA match
P = pd.read_csv('/tmp/work/out_survival_pooled.csv')
fig, axs = plt.subplots(1, 2, figsize=(10, 3.5), gridspec_kw={'width_ratios': [1.25, 1]})
ax = axs[0]
for i, r in P.iloc[::-1].reset_index(drop=True).iterrows():
    ax.barh(i + 0.18, r.pct344, height=0.34, color=COL['PSLN-344']); ax.barh(i - 0.18, r.pct212, height=0.34, color=COL['PSLN-212'])
    ax.text(r.pct344 + 1, i + 0.18, r.PSLN344_survivors, va='center', fontsize=7)
    ax.text(r.pct212 + 1, i - 0.18, r.PSLN212_survivors, va='center', fontsize=7)
ax.set_yticks(range(len(P))); ax.set_yticklabels([t.replace(':', ':\n', 1) for t in P.tier[::-1]], fontsize=7)
ax.set_xlabel('% of aged mice surviving challenge'); ax.set_xlim(0, 110)
ax.legend(handles=[plt.Rectangle((0, 0), 1, 1, color=COL['PSLN-344']), plt.Rectangle((0, 0), 1, 1, color=COL['PSLN-212'])],
          labels=['PSLN-344', 'PSLN-212 (same liposome, no Mn)'], fontsize=7, frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.2), ncol=2)
ax.set_title('A  Pooled PSLN-344 vs PSLN-212, by integrity tier', fontsize=8.5, loc='left')
ax = axs[1]
M = pd.read_csv('/tmp/work/out_protection_by_match.csv')
lab = ['no HA/NA\nshared\n(S06-A,B,E,G)', 'no HA/NA shared,\nconcordant\n(S06-A,B)', 'N1 shared\nonly\n(S06-C,F)', 'homologous\nHA+NA\n(S03-I,J)']
for i, r in M.iterrows():
    a = [int(v) for v in r.PSLN344.split(' ')[0].split('/')]; b = [int(v) for v in r.PSLN212.split(' ')[0].split('/')]
    ax.bar(i - 0.18, 100 * a[0] / a[1], 0.36, color=COL['PSLN-344']); ax.bar(i + 0.18, 100 * b[0] / b[1], 0.36, color=COL['PSLN-212'])
    ax.text(i - 0.18, 100 * a[0] / a[1] + 2, f'{a[0]}/{a[1]}', ha='center', fontsize=6.5); ax.text(i + 0.18, 100 * b[0] / b[1] + 2, f'{b[0]}/{b[1]}', ha='center', fontsize=6.5)
ax.set_xticks(range(len(M))); ax.set_xticklabels(lab, fontsize=6.5); ax.set_ylabel('% surviving'); ax.set_ylim(0, 112)
ax.set_title('B  PSLN-344 protection persists without HA/NA match (higher with match)', fontsize=8.5, loc='left')
fig.tight_layout(); fig.savefig(f'{OUT}/fig3_pooled_survival_and_match.png', dpi=200); plt.close(fig)

# ---------------- Figure 4: integrity evidence
fig = plt.figure(figsize=(11, 6.6))
gs = fig.add_gridspec(2, 3)
# A S06-C vs S06-D
ax = fig.add_subplot(gs[0, 0])
for blk, off, mk in [('S06-C', -0.12, 'o'), ('S06-D', 0.12, 's')]:
    d = s[s.block == blk]
    for j, g in enumerate(['Sham', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)']):
        tt = np.sort(d[d.group == g].time.values)
        ax.scatter(np.full(len(tt), j + off) + np.linspace(-0.05, 0.05, len(tt)), tt, marker=mk, s=14,
                   facecolor=COL[g] if blk == 'S06-C' else 'none', edgecolor=COL[g], lw=0.9)
ax.set_xticks(range(4)); ax.set_xticklabels(['Sham', 'PSLN-212', 'PSLN-344', 'young'], fontsize=7)
ax.set_ylabel('day of death / censoring'); ax.set_title('A  S06-C (d14, filled) vs S06-D (d3, open):\n28/28 records identical', fontsize=8, loc='left')
# B S09-E vs S15-M trajectories
ax = fig.add_subplot(gs[0, 1])
days = [0, 2, 4, 6, 8, 10, 12, 14]
def traj(block, group, idx):
    d = bw[(bw.block == block) & (bw.group == group) & (bw.idx == idx)].sort_values('day'); return d.day.values, d.value.values
for k, (i1, i2) in enumerate([(2, 1), (3, 2), (5, 4)]):
    x1, v1 = traj('S09-E', 'PSLN-344Y', i1); x2, v2 = traj('S15-M', 'PSLN-212(Y)', i2)
    ax.plot(x1, v1 + 6 * k, '-', color='#1b7837', lw=2.2, alpha=0.6); ax.plot(x2, v2 + 6 * k, 'o--', color='k', ms=3, lw=0.8)
ax.set_title('B  S09-E young BALB/c PSLN-344Y (green)\nvs S15-M aged C57BL/6 PSLN-212(Y) (black)', fontsize=8, loc='left')
ax.set_xlabel('day'); ax.set_ylabel('% day-0 weight (offset +6 per pair)')
# C S15-C vs S15-I
ax = fig.add_subplot(gs[0, 2])
for k in range(2, 8):
    x1, v1 = traj('S15-C', 'PSLN-344', k); x2, v2 = traj('S15-I', '3d Vaccine+PSLN-344', k)
    ax.plot(x1, v1 + 4 * (k - 2), '-', color=COL['PSLN-344'], lw=2.2, alpha=0.5); ax.plot(x2, v2 + 4 * (k - 2), 'o--', color='k', ms=2.5, lw=0.8)
ax.set_title('C  S15-C PSLN-344, d14 challenge (red) vs S15-I\nVaccine+PSLN-344, d3 challenge (black)', fontsize=8, loc='left')
ax.set_xlabel('day'); ax.set_ylabel('% day-0 weight (offset +4 per animal)')
# D S03-B printed vs recomputed
ax = fig.add_subplot(gs[1, 0])
def vec(block, group, sub='nan'):
    return m[(m.block == block) & (m.group == group) & (m['sub'] == sub)].sort_values('idx').value.values
for j, g in enumerate(['PSLN-212', 'PSLN-344', 'PSLN-212(Y)']):
    printed = vec('S03-B', g); rec = vec('S13-A', g) / vec('S13-B', g)
    ax.scatter(np.full(5, j - 0.15), printed, marker='x', color='grey', s=18)
    ax.scatter(np.full(5, j + 0.15), rec, marker='o', color=COL[g], s=16)
ax.set_yscale('log'); ax.axhline(1, color='k', lw=0.5, ls=':')
ax.set_xticks(range(3)); ax.set_xticklabels(['PSLN-212', 'PSLN-344', 'young PSLN-212'], fontsize=7)
ax.set_ylabel('IgG2a / IgG1 (anti-CA09)'); ax.set_title('D  S03-B as printed (x) vs recomputed from\nS13-A/B subclass titres (o): labels rotated', fontsize=8, loc='left')
# E S09-A panel2 vs S01-A 72h
ax = fig.add_subplot(gs[1, 1])
gm = {'PBS': 'Sham', 'CMP-204': 'CMP-204', 'PSLN-212': 'PSLN-212', 'PSLN-R848': 'PSLN-R848', 'PSLN-212/R848': 'PSLN-212/R848', 'PSLN-344': 'PSLN-344', 'PSLN-212(y)': 'PSLN-212(Y)'}
for g9, g1 in gm.items():
    p2 = 10 ** vec('S09-A panel2 (cols X-AS)', g9, 'Ifnb1'); a72 = vec('S01-A', g1, '72h'); a16 = vec('S01-A', g1, '16h')
    ax.scatter(np.sort(p2), np.sort([min(a72, key=lambda z: abs(z - v)) for v in p2]), color='#e45756', s=12)
    ax.scatter(np.sort(p2), np.sort([min(a16, key=lambda z: abs(z - v)) for v in p2]), color='#4c78a8', s=12, marker='^')
lim = [0.4, 80]; ax.plot(lim, lim, 'k:', lw=0.6); ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel("S09-A 'panel 2' Ifnb1 (printed '16h')"); ax.set_ylabel('nearest S01-A value')
ax.legend(handles=[Line2D([], [], color='#e45756', marker='o', ls='', label='vs S01-A 72 h: 21/21 exact'),
                   Line2D([], [], color='#4c78a8', marker='^', ls='', label='vs S01-A 16 h: 0/21'),
                   Line2D([], [], color='k', ls=':', label='identity')], fontsize=6.5, frameon=False, loc='lower right')
ax.set_title('E  S09-A panel 2 is the 72 h data', fontsize=8, loc='left')
# F S11-A vs S11-B
ax = fig.add_subplot(gs[1, 2])
a = m[m.block == 'S11-A'].sort_values(['group', 'sub', 'idx']); b = m[m.block == 'S11-B'].sort_values(['group', 'sub', 'idx'])
mm_ = a.merge(b, on=['group', 'sub', 'idx'], suffixes=('_A', '_B'))
same = np.isclose(mm_.value_A, mm_.value_B)
ax.scatter(mm_.value_A[~same], mm_.value_B[~same], s=10, color='grey', label=f'different ({(~same).sum()})')
ax.scatter(mm_.value_A[same], mm_.value_B[same], s=12, color='#d62728', label=f'identical ({same.sum()} of {len(same)}: first 1-2 animals of every group at every day)')
ax.plot([10, 60], [10, 60], 'k:', lw=0.6); ax.set_xlabel('S11-A alveolar macrophages (%)'); ax.set_ylabel('S11-B neutrophils (%)')
ax.legend(fontsize=6.3, frameon=False, loc='upper left'); ax.set_title('F  Two cell types, shared values', fontsize=8, loc='left')
fig.suptitle('Fig. 4  Data-integrity evidence (all panels drawn directly from workbook cells)', fontsize=9, x=0.01, ha='left')
fig.tight_layout(rect=(0, 0, 1, 0.96)); fig.savefig(f'{OUT}/fig4_integrity_evidence.png', dpi=200); plt.close(fig)

# ---------------- Figure 5: mechanism / dose-response / early panel
fig = plt.figure(figsize=(13.5, 4.6), constrained_layout=True); gs = fig.add_gridspec(1, 3, width_ratios=[1.0, 1.25, 1.05])
ax = fig.add_subplot(gs[0])
Em = pd.read_csv('/tmp/work/out_emax_hill.csv').set_index('formulation')
dd = np.logspace(0, np.log10(40), 100)
for g, c in [('PSLN-344', COL['PSLN-344']), ('PSLN-212', COL['PSLN-212']), ('CMP-204', COL['CMP-204']), ('PSLN-344/R848', '#9d755d')]:
    for dz in [1, 5, 10, 20, 40]:
        v = vec('S08-A', g, str(dz)); ax.scatter(np.full(len(v), dz) * np.exp(np.random.default_rng(1).normal(0, 0.03, len(v))), v, color=c, s=9)
    p = Em.loc[g]; ax.plot(dd, 1 + p.Emax_fold * dd ** p.hill / (p.ED50_ug ** p.hill + dd ** p.hill), color=c, lw=1.3,
                           label=f"{g}: Emax {p.Emax_fold:.0f} ({p.Emax_lo:.0f}-{p.Emax_hi:.0f}), ED50 {p.ED50_ug:.0f} ug")
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('dose (ug/animal)'); ax.set_ylabel('lung Ifnb1, fold vs untreated (16 h)')
ax.legend(fontsize=5.8, frameon=False, loc='lower right'); ax.set_title('A  Mn raises the ceiling, not the potency (S08-A)', fontsize=8, loc='left')
ax = fig.add_subplot(gs[1])
E = pd.read_csv('/tmp/work/out_early_panel.csv')
cols = ['log10_PBS', 'log10_CMP-204', 'log10_PSLN-212', 'log10_PSLN-R848', 'log10_PSLN-212/R848', 'log10_PSLN-344', 'log10_PSLN-212(y)']
an = ['Ifnb1', 'Il6', 'Ccl2', 'Ccl3', 'Ccl5', 'Tnf', 'Il10']
H = np.vstack([E[(E.analyte == a) & (E.time == '16h')][cols].values[0] for a in an] + [E[(E.analyte == a) & (E.time != '16h')][cols].values[0] for a in an])
im = ax.imshow(H, cmap='magma_r', aspect='auto', vmin=-0.5, vmax=3.2)
ax.set_yticks(range(14)); ax.set_yticklabels([f'{a} 16h' for a in an] + [f'{a} 72h*' for a in an], fontsize=6.5)
ax.set_xticks(range(7)); ax.set_xticklabels(['PBS', 'CMP-204', 'PSLN-212', 'PSLN-R848', '212/R848', 'PSLN-344', 'young 212'], fontsize=6.5, rotation=30)
for i in range(14):
    for j in range(7):
        ax.text(j, i, f'{H[i, j]:.1f}', ha='center', va='center', fontsize=5.2, color='white' if H[i, j] > 1.6 else 'black')
ax.axhline(6.5, color='w', lw=2); plt.colorbar(im, ax=ax, fraction=0.03, label='mean log10 fold')
ax.set_title('B  Lung transcripts (S09-A; n=3). *panel 2 printed "16h" = 72 h data', fontsize=8, loc='left')
ax = fig.add_subplot(gs[2])
MC = pd.read_csv('/tmp/work/out_mechanism_contrasts.csv')
pick = [('BM-derived moDC: WT vs Ifnar-KO (cDC precursors removed)', 'IFNAR on BM cells -> moDC (S02-H)'),
        ('BM-derived moDC: Ifnar-KO + GM-CSF vs Ifnar-KO', 'GM-CSF rescues Ifnar-KO moDC (S02-H)'),
        ('moDC-like cells: PSLN-212+GM-CSF vs PSLN-212', 'GM-CSF adds moDC to PSLN-212 (S02-G)'),
        ('Lung monocytes: PSLN-344 vs +INCB3344 (CCR2 antagonist)', 'CCR2 -> lung monocytes (S07-B)'),
        ('Lung GZMB+ CD8: PSLN-344(Y) vs +INCB3344 (YOUNG animals)', 'CCR2 -> GZMB+ CD8, YOUNG (S02-I)'),
        ('Recruited lung monocytes: saline vs carbenoxolone', 'gap junctions -> monocytes (S11-C)'),
        ('OT-I priming by MLN DC: PSLN-344 vs PTX', 'DC migration -> MLN priming (S02-E)'),
        ('OT-I proliferation in lung: PBS vs PTX', 'PTX -> lung OT-I (S05-C, n=3): CI spans 0')]
for i, (q, lab_) in enumerate(pick[::-1]):
    r = MC[MC.question == q].iloc[0]
    ax.plot([r.ci_lo, r.ci_hi], [i, i], color='k', lw=1.2); ax.plot(r.estimate, i, 'o', color='#4c78a8', ms=4)
ax.axvline(0, color='grey', lw=0.6, ls=':')
ax.set_yticks(range(len(pick))); ax.set_yticklabels([p[1] for p in pick[::-1]], fontsize=6.5)
ax.set_xlabel('difference in the labelled direction, % points\n(Welch 95% CI; >0 supports the label)'); ax.set_title('C  Tested dependencies (none tested against survival)', fontsize=8, loc='left')
fig.savefig(f'{OUT}/fig5_mechanism.png', dpi=200); plt.close(fig)

# ---------------- Figure 6: key immunogenicity dot plots
panels = [('S03-A', 'nan', 'IgG anti-CA09 d14', True), ('S03-C', 'nan', 'HAI anti-CA09 d14', True), ('S03-D', 'nan', 'Neutralising anti-CA09 d14', True),
          ('S04-A', 'ICOS-high', 'MLN ICOS-hi Tfh d7 (%)', False), ('S05-G', 'nan', 'MLN IFN-g+ CD8 (H5N1 restim) d60 (%)', False),
          ('S05-I', 'nan', 'Lung TRM CD8 d25 (%)', False)]
fig, axes = plt.subplots(1, 6, figsize=(11, 2.9))
for ax, (blk, sub, title, log) in zip(axes, panels):
    gs_ = [g for g in ['Sham', 'CMP-204', 'PSLN-212', 'PSLN-344', 'PSLN-212(Y)'] if len(vec(blk, g, sub))]
    for j, g in enumerate(gs_):
        v = vec(blk, g, sub).astype(float)
        if blk in ('S03-C',): v = np.where(v <= 0, 5, v)
        ax.scatter(np.full(len(v), j) + np.linspace(-0.15, 0.15, len(v)), v, color=COL[g], s=12)
        c = 10 ** np.log10(v).mean() if log else v.mean(); ax.plot([j - 0.25, j + 0.25], [c, c], color='k', lw=1.2)
    if log: ax.set_yscale('log')
    if blk == 'S03-C': ax.axhline(40, color='k', ls=':', lw=0.6); ax.text(-0.4, 44, '1:40', fontsize=6)
    ax.set_xticks(range(len(gs_))); ax.set_xticklabels([g.replace('PSLN-', '').replace('(Y)', 'Y') for g in gs_], fontsize=6.3, rotation=45)
    ax.set_title(f'{title}\n[{blk}]', fontsize=7)
fig.suptitle('Fig. 6  Representative adaptive readouts in aged mice (bar = GM for titres, mean for %; Y = young)', fontsize=8.5, x=0.01, ha='left')
fig.tight_layout(rect=(0, 0, 1, 0.92)); fig.savefig(f'{OUT}/fig6_immunogenicity.png', dpi=200); plt.close(fig)
print('figures written:', os.listdir(OUT))
